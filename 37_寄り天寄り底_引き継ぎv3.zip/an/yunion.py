# 案3（窓埋め S17・S18・S19 と同じ決め方）と前向き検証
#   分類＝向き×売買（逆張り売り・逆張り買い・順張り売り・順張り買い）
#   1. 前の付け方：確かめる年 t のルールでの選ぶ期間（t より前）の1回平均（15件以上）。前向き記録（2022〜t−1）の合計がマイナスの候補は外す（記録がまだない候補は残す）
#   2. 新しい付け方：前向き記録のリカバリーファクター（合計÷最大DD）。前向き20件以上・前向き合計プラス・選ぶ期間（2017〜21、2022年のルール）プラス
#   3. どちらも同じグループ（区切り0.5）の候補はグループ内の最上位だけ。上位 N 本ずつを合わせる。優先順位：①両方に入る ②良い方の順位 ③前の付け方の順位
#   4. 入る日が75%以上重なる候補（共通 ÷ 少ない方）は1本にまとめる（前向きの合計÷最大DDの良い方を残す）
#   5. 前向きPFが1.2以上（記録がまだない候補は残す）
#   前向き検証：t＝2024〜2026。候補の集まりと順位は t より前のデータだけ。t 年のトレードを方針ごとに1口座で動かす（同じセッションで一度手じまったら入り直さない）
#   方針：A1 先着1本／B 両建て（買い1・売り1）／C1 同じ向き2本／D1 両建て＋2本目（合計2本）
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/an'); import engt
O = '/home/claude/yt/out/'
C = pd.read_pickle(O + 'YC.pkl'); FT = pd.read_pickle(O + 'YCT.pkl').sort_values(['cid', 'te'], kind='stable'); YM = pd.read_pickle(O + 'YM.pkl')
C['grp'] = np.where(C.指標 == 'なし', -1 - C.id, C['g0.5'])
C['分類'] = C.向き + C.売買
def record(t):
    F = FT[FT.年 < t]
    def st(g):
        v = g.損益.values; eq = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, eq])[1:] - eq).max(); gp = v[v > 0].sum(); gl = -v[v < 0].sum()
        return pd.Series(dict(件数=len(v), 合計=v.sum(), DD=dd, RF=v.sum() / dd if dd > 0 else (np.inf if v.sum() > 0 else 0), PF=gp / gl if gl > 0 else np.inf))
    R = F.groupby('cid').apply(st) if len(F) else pd.DataFrame(columns=['件数', '合計', 'DD', 'RF', 'PF'])
    days = F.groupby('cid').sid.apply(set) if len(F) else pd.Series(dtype=object)
    return R, days
def choose(t, N, rule_year=None, groups=None):
    ry = rule_year or t; R, days = record(t)
    X = C[C['分類'].isin(groups)].join(R, on='cid')
    out = []
    for kb, g in X.groupby('分類'):
        a = g[(g['選ぶ期間件数_%d' % ry] >= 15) & g['選ぶ期間平均_%d' % ry].notna() & ~(g.合計 <= 0)].sort_values('選ぶ期間平均_%d' % ry, ascending=False).drop_duplicates('grp')
        b = g[(g.件数 >= 20) & (g.合計 > 0) & (g.選ぶ期間2017_21合計 > 0)].sort_values('RF', ascending=False).drop_duplicates('grp')
        ra = {c: i for i, c in enumerate(a.cid.values[:N])}; rb = {c: i for i, c in enumerate(b.cid.values[:N])}
        ids = list(dict.fromkeys(list(ra) + list(rb)))
        sel = g.set_index('cid').loc[ids].copy(); sel['前の順位'] = [ra.get(c, 99) for c in ids]; sel['新の順位'] = [rb.get(c, 99) for c in ids]
        sel['両方'] = (sel.前の順位 < 99) & (sel.新の順位 < 99); sel['良い方'] = sel[['前の順位', '新の順位']].min(axis=1)
        # 4. 重なり75%：前向きの合計÷最大DDの良い方を残す
        sel = sel.sort_values('RF', ascending=False, na_position='last'); keep = []; why = {}
        for c in sel.index:
            dc = days.get(c, set()); hit = None
            for k in keep:
                dk = days.get(k, set())
                if dc and dk and len(dc & dk) / min(len(dc), len(dk)) >= .75: hit = k; break
            if hit is None: keep.append(c)
            else: why[c] = '重なり75%以上（' + str(hit) + ' と）'
        sel['扱い'] = [why.get(c, '') for c in sel.index]
        sel.loc[(sel.扱い == '') & (sel.PF < 1.2), '扱い'] = 'PF1.2未満'
        out.append(sel.reset_index())
    S = pd.concat(out); S['確かめる年'] = t
    return S.sort_values(['両方', '良い方', '前の順位'], ascending=[False, True, True])
EXT = {}
def exit_time(row, e):
    if row not in EXT:
        r = YM.iloc[row]; EXT[row] = engt.sim_t((r.d, r.te, r.mv, r.tcap, r.tam if r.tam == r.tam else None, 'D'))[1]
    return EXT[row][e]
def simulate(t, sel, pol):
    sel = sel[sel.扱い == ''].reset_index(drop=True); pr = {c: i for i, c in enumerate(sel.cid)}
    tr = FT[(FT.年 == t) & FT.cid.isin(pr)].copy(); tr['pr'] = tr.cid.map(pr); tr['d'] = YM.d.values[tr.row.values]
    tr = tr.sort_values(['sid', 'te', 'pr']); out = []
    for s, g in tr.groupby('sid', sort=False):
        held = []; closed = False
        for r in g.itertuples():
            still = []
            for h in held:
                if h[1] <= r.te: closed = True; out.append(h)
                else: still.append(h)
            held = still
            if closed: continue
            same = [h for h in held if h[2] == r.d]; opp = [h for h in held if h[2] != r.d]
            if pol == 'A1' and held: continue
            if pol == 'B' and same: continue
            if pol == 'C1' and (opp or len(held) >= 2): continue
            if pol == 'D1' and len(held) >= 2: continue
            if same and same[0][3] == r.cid: continue
            if pol in ('C1', 'D1') and len(same) >= 1 and len(held) >= 2: continue
            held.append((r.te, exit_time(r.row, r.e), r.d, r.cid, r.損益, s, '2本目' if same else ('両建て' if opp else '1本目')))
        out += held
    return pd.DataFrame(out, columns=['入る', '手じまう', 'd', 'cid', '損益', 'sid', '種類'])
def summ(H):
    if not len(H): return dict(件数=0, 合計=0.0)
    H = H.sort_values('手じまう'); v = H.損益.values; eq = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, eq])[1:] - eq).max()
    return dict(件数=len(v), 合計=v.sum(), 最大DD=dd, 合計割る最大DD=v.sum() / dd if dd > 0 else np.nan, 一回平均=v.mean(), 最悪の1日=H.groupby('sid').損益.sum().min(), 二本目=int((H.種類 == '2本目').sum()))
POOLS = {'売りのみ（逆張り＋順張り）': ['逆張り売り', '順張り売り'], '買いのみ（逆張り＋順張り）': ['逆張り買い', '順張り買い'], '逆張り売りだけ': ['逆張り売り'], '逆張り（売り＋買い）': ['逆張り売り', '逆張り買い'],
         '全部（4区分）': ['逆張り売り', '逆張り買い', '順張り売り', '順張り買い'], '順張り（売り＋買い）': ['順張り売り', '順張り買い']}
if __name__ == '__main__':
    rows = []; SELS = {}
    for pn, grp in POOLS.items():
        for N in (3, 5):
            for t in (2024, 2025, 2026):
                SELS[(pn, N, t)] = choose(t, N, groups=grp)
            for pol in ('A1', 'B', 'C1', 'D1'):
                Hs = []
                for t in (2024, 2025, 2026):
                    H = simulate(t, SELS[(pn, N, t)], pol); H['年'] = t; Hs.append(H)
                H = pd.concat(Hs); r = dict(候補の集まり=pn, N=N, 方針=pol, **summ(H))
                for t in (2024, 2025, 2026): r[str(t)] = H[H.年 == t].損益.sum()
                r['本数_平均'] = np.mean([(SELS[(pn, N, t)].扱い == '').sum() for t in (2024, 2025, 2026)])
                rows.append(r)
            print(pn, N, flush=True)
    V = pd.DataFrame(rows); V.to_pickle(O + 'YV.pkl'); pd.to_pickle(SELS, O + 'YVSEL.pkl')
    pd.set_option('display.width', 250); print(V.round(1).to_string(index=False))
    # 今の採用候補（ルールは 2026年、前向き記録は 2022〜2026/10/8）
    NOW = {N: choose(2027, N, rule_year=2026, groups=POOLS['全部（4区分）']) for N in (3, 5)}
    pd.to_pickle(NOW, O + 'YNOW.pkl')
    for N, S in NOW.items(): print('今', N, S.groupby(['分類', '扱い']).size().to_string())
