# 確認：条件つきの候補1件を、元の評価コード（evalu2.evaluate）で別に計算して YE2 と比べる
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/an'); import evalu2
O = '/home/claude/yt/out/'
side, bs, ind, kub, use, ob, en = sys.argv[1:8]
YM = pd.read_pickle(O + 'YM.pkl'); F = pd.read_pickle(O + 'YF.pkl')
m2 = pd.read_pickle(O + 'E2_D_meta.pkl'); R2 = np.load(O + 'E2_D_R.npy', mmap_mode='r')
v = F[ind].values.astype(float); base = (YM.向き.values == side) & (YM.売買.values == bs); sel = base & (YM.yr.values <= 2021) & ~np.isnan(v)
q3 = np.quantile(v[sel], [1 / 3, 2 / 3]); q5 = np.quantile(v[sel], [.2, .4, .6, .8]); lo, hi = np.quantile(v[sel], [.1, .9]); fin = ~np.isnan(v)
if kub.startswith('3分割'): mk = fin & (np.searchsorted(q3, v, side='right') == ['3分割:低', '3分割:中', '3分割:高'].index(kub))
elif kub.startswith('5分割'): mk = fin & (np.searchsorted(q5, v, side='right') == int(kub[-1]) - 1)
elif kub == '下位10%': mk = fin & (v <= lo)
elif kub == '上位10%': mk = fin & (v >= hi)
else: mk = v == float(kub[1:])
if use == '避ける': mk = ~mk
# 対象の E2 行（観察・向き・入る・売買が一致し、条件を満たす）
tgt = YM[(YM.src == 'E2') & base & (YM.観察 == ob) & (YM.入る == en) & mk].row.values
M = m2[m2.観察 == ob].copy(); M.loc[tgt, '入る'] = en + '*'
np.save(O + 'CHK_D_R.npy', np.asarray(R2[M.index.values])); M.reset_index(drop=True).to_pickle(O + 'CHK_D_meta.pkl')
T = evalu2.evaluate('D', tag='CHK'); r = T[(T.入る == en + '*')]
Y = pd.read_pickle(O + 'YE2.pkl'); y = Y[(Y.向き == side) & (Y.売買 == bs) & (Y.指標 == ind) & (Y.区分 == kub) & (Y.使い方 == use) & (Y.観察 == ob) & (Y.入る == en)]
for how in ('単点', '周辺'):
    a = r[r.選び方 == how].iloc[0]; b = y[y.選び方 == how].iloc[0]
    print(how, '元のコード', round(a.中央, 2), a.プラスの数, round(a.前向き合計, 1), a.今の手じまい, '| 高速版', round(b.中央, 2), b.プラスの数, round(b.前向き合計, 1), b.今の手じまい)
