# 案3の材料：残った候補（単点・周辺の別）ごとに
#   ・確かめる年 t（2022〜2026）のルール k_t（WF全期間：t より前のデータで選んだ強さ×手じまい）
#   ・そのルールでの選ぶ期間（t より前の年）の1回平均・件数（前の付け方）、2017〜21年の合計（2022年に使ったルール）
#   ・前向きのトレード一覧（各年 y はその年のルール k_y）：日・入る時刻・損益・行番号・手じまいの番号
#   出力：out/YC.pkl（候補表）、out/YCT.pkl（前向きトレード）
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/an')
from yeval import YM, YR, QL, YRS, nE, scs, yi, YEARS, O
T = pd.read_pickle(O + 'YE2.pkl'); G = pd.read_pickle(O + 'YG.pkl'); BINS = pd.read_pickle(O + 'YBINS.pkl'); S0 = pd.read_pickle(O + 'YS.pkl')
T['残す'] = (T.プラスの数 >= 3) & (T.中央 >= 20) & (T.年件数_中央 >= 10)
U = ['向き', '売買', '指標', '区分', '使い方', '観察', '入る']
C = T[T.残す].merge(G[U + ['id', 'g0.4', 'g0.5', 'g0.6', '代表', '2番目', '安定', 'グループの大きさ']], on=U).reset_index(drop=True)
C['cid'] = np.arange(len(C)); LATE = set(S0[S0.後半のみ].指標)
def cmask(side, bs, ind, kub, use):
    if ind == 'なし': return np.ones(len(YM), bool)
    keys, packed, nn = BINS[(side, bs, ind in LATE)]; i = keys.index((ind, kub)); m = np.unpackbits(packed[i])[:nn].astype(bool); return m if use == '入る' else ~m
TY = list(range(2022, 2027)); ins = {t: np.full(len(C), np.nan) for t in TY}; insn = {t: np.zeros(len(C)) for t in TY}; s1721 = np.full(len(C), np.nan)
FT = []
for (side, bs, ob, en), g in C.groupby(['向き', '売買', '観察', '入る']):
    base = (YM.向き.values == side) & (YM.売買.values == bs) & (YM.観察.values == ob) & (YM.入る.values == en); idx = np.flatnonzero(base)
    conds = g[['指標', '区分', '使い方']].drop_duplicates().reset_index(drop=True); ck = {tuple(r): i for i, r in enumerate(conds.itertuples(index=False))}
    M = np.array([cmask(side, bs, *r)[idx] for r in conds.itertuples(index=False)])
    S, Cn, NG = scs(idx, M)
    yr = YRS[idx]; ql = QL[idx]
    for r in g.itertuples():
        i = ck[(r.指標, r.区分, r.使い方)]; ks = r.WF全期間_k
        for t, k in zip(TY, ks):
            if k < 0: continue
            a = [yi[y] for y in YEARS if y < t]; n_ = Cn[i, k, a].sum(); insn[t][r.cid] = n_
            if n_ > 0: ins[t][r.cid] = S[i, k, a].sum() / n_
            if t == 2022: s1721[r.cid] = S[i, k, a].sum()
            q, e = divmod(k, nE); w = idx[M[i] & (yr == t) & (ql >= q)]
            x = np.asarray(YR[w, e], np.float32); ok = ~np.isnan(x)
            for row, v in zip(w[ok], x[ok]): FT.append((r.cid, t, int(YM.sid.values[row]), int(YM.te.values[row]), float(v), int(row), int(e)))
    print(side, bs, ob, en, len(g), flush=True) if False else None
for t in TY: C['選ぶ期間平均_%d' % t] = ins[t]; C['選ぶ期間件数_%d' % t] = insn[t]
C['選ぶ期間2017_21合計'] = s1721
FTd = pd.DataFrame(FT, columns=['cid', '年', 'sid', 'te', '損益', 'row', 'e'])
chk = FTd.groupby('cid').損益.sum().reindex(C.cid).fillna(0).values
print('前向き合計の一致', np.abs(chk - C.前向き_合計.fillna(0).values).max())
C.to_pickle(O + 'YC.pkl'); FTd.to_pickle(O + 'YCT.pkl'); print(len(C), len(FTd))
