# 指標の段階のまとめ：残す基準を当て、残ったものに前向き（2022〜、WF全期間の選び方）の成績を付ける
#   条件なしとの差：同じ向き・売買・入る形・選び方の「方向だけの条件なし」の中央との差（参考。基準には使わない）
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/an')
from yeval import YM, YR, QL, YRS, nE, EXd, FORMS, O
T = pd.read_pickle(O + 'YE.pkl'); BINS = pd.read_pickle(O + 'YBINS.pkl'); S0 = pd.read_pickle(O + 'YS.pkl')
T['残す'] = (T.プラスの数 >= 3) & (T.中央 >= 20) & (T.年件数_中央 >= 10)
key = ['向き', '売買', '観察', '入る', '選び方']
base = T[T.指標 == 'なし'].set_index(key)[['中央', '前向き合計', '残す']].rename(columns={'中央': '条件なし_中央', '前向き合計': '条件なし_前向き合計', '残す': '条件なしも残る'})
T = T.join(base, on=key); T['条件なしとの差'] = T.中央 - T.条件なし_中央
T = T.join(S0.set_index(['向き', '売買', '指標', '区分'])[['該当率', '前半t', '後半t', '後半上乗せ', '前半も同じ向き', '後半のみ']], on=['向き', '売買', '指標', '区分'])
K = T[T.残す].copy()
# 条件の行のマスク
MK = {}
def mask(side, bs, ind, kub, use):
    if ind == 'なし': return np.ones(len(YM), bool)
    k = (side, bs, ind, kub, use)
    if k not in MK:
        late = bool(S0[(S0.向き == side) & (S0.売買 == bs) & (S0.指標 == ind) & (S0.区分 == kub)].後半のみ.iloc[0])
        keys, packed, nn = BINS[(side, bs, late)]; i = keys.index((ind, kub)); m = np.unpackbits(packed[i])[:nn].astype(bool); MK[k] = m if use == '入る' else ~m
    return MK[k]
WFY = [te[0] for _, te in FORMS['WF全期間']]
P = pd.read_pickle(O + 'P.pkl'); PM = P.m.values.astype('int64'); ENTP = P.open.values[np.minimum(np.searchsorted(PM, YM.te.values.astype('int64')), len(PM) - 1)]
GI = YM.groupby(['向き', '売買', '観察', '入る']).indices
def fwd(r):
    idx = GI[(r.向き, r.売買, r.観察, r.入る)]; sel = mask(r.向き, r.売買, r.指標, r.区分, r.使い方)[idx]; yr = YRS[idx]; ql = QL[idx]
    v = []; tt = []; pp = []
    for y, k in zip(WFY, r.WF全期間_k):
        if k < 0: continue
        q, e = divmod(k, nE); w = idx[sel & (yr == y) & (ql >= q)]
        x = np.asarray(YR[w, e], np.float32); ok = ~np.isnan(x); v.append(x[ok]); tt.append(YM.te.values[w][ok]); pp.append(ENTP[w][ok])
    if not v: return dict()
    v = np.concatenate(v); t = np.concatenate(tt); p_ = np.concatenate(pp); o = np.argsort(t, kind='stable'); v = v[o]; p_ = p_[o]
    if len(v) == 0: return dict(前向き_件数=0)
    eq = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, eq])[1:] - eq).max(); gp = v[v > 0].sum(); gl = -v[v < 0].sum()
    return dict(前向き_件数=len(v), 前向き_勝率=(v > 0).mean() * 100, 前向き_PF=gp / gl if gl > 0 else np.inf, 前向き_平均=v.mean(), 前向き_合計=v.sum(), 前向き_最大DD=dd,
                前向き_RF=v.sum() / dd if dd > 0 else np.inf, 前向き_最悪=v.min(), 前向き_平均_20pt=(v - 7 / p_ * 68800).mean())
F_ = pd.DataFrame([fwd(r) for r in K.itertuples()], index=K.index)
K = K.join(F_)
assert np.allclose(K.前向き_合計.fillna(0), K.前向き合計.fillna(0), atol=1)
T = T.join(F_)
T.to_pickle(O + 'YE2.pkl')
both = K.groupby(['向き', '売買', '指標', '区分', '使い方', '観察', '入る']).選び方.transform('nunique') == 2
K['両方で残る'] = both
print(K.groupby(['向き', '売買', '使い方']).agg(残る=('残す', 'size'), 両方=('両方で残る', 'sum'), 条件なしより良い=('条件なしとの差', lambda z: (z > 0).sum()), 前向きプラス=('前向き_合計', lambda z: (z > 0).sum())).to_string())
