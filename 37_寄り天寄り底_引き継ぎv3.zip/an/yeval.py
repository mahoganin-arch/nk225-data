# 5つの評価の形（evalu2.py と同じ計算）を、多数の条件にまとめて当てはめる高速版
#   戦略＝(向き, 売買, 条件, 使い方, 観察, 入る)。選ぶもの＝強さ(5段) × 手じまい(506)。単点／周辺
#   python3 yeval.py check  … 条件なし（買い売り両方）で EV2_D と一致するか確かめる
#   python3 yeval.py        … ふるいを通った条件＋方向だけの条件なしを評価 → out/YE.pkl
import sys, numpy as np, pandas as pd, scipy.sparse as sp
sys.path.insert(0, '/home/claude/yt/an')
from evalu import YEARS, QS, QN, FORMS, neighbors, O
YM = pd.read_pickle(O + 'YM.pkl'); YR = np.load(O + 'YR.npy', mmap_mode='r')
EXd = pd.read_pickle(O + 'EXITS.pkl')['D']; nE = len(EXd); NQ = len(QS); NK = NQ * nE
NB = neighbors(EXd)
NBm = sp.csr_matrix((np.ones(sum(len(z) for z in NB)), (np.repeat(np.arange(NK), [len(z) for z in NB]), np.concatenate(NB))), shape=(NK, NK))
m2 = pd.read_pickle(O + 'E2_D_meta.pkl'); cutmap = {}
for ob, g in m2.drop_duplicates(['観察', 'sid']).groupby('観察'):
    a = np.abs(g.x.values)[g.t.dt.year.values <= 2021]; cutmap[ob] = [np.quantile(a, q) if q > 0 else 0 for q in QS]
yi = {y: k for k, y in enumerate(YEARS)}
QL = np.zeros(len(YM), np.int8); ax = np.abs(YM.x.values)
for ob, cuts in cutmap.items():
    w = YM.観察.values == ob
    for qi, c in enumerate(cuts): QL[w & (ax >= c)] = qi        # 満たす最も強い段
YRS = YM.yr.values
def scs(idx, masks):
    """idx：入る形の行。masks：(K, len(idx)) bool → S, C, NEG：(K, NK, 年)"""
    K = masks.shape[0]; S = np.zeros((K, NK, len(YEARS)), np.float32); C = np.zeros_like(S); NG = np.zeros_like(S)
    R = np.asarray(YR[idx], np.float32); ok = ~np.isnan(R); R0 = np.where(ok, R, 0); neg = (R < -1000).astype(np.float32); okf = ok.astype(np.float32)
    ql = QL[idx]; yr = YRS[idx]
    for y in np.unique(yr):
        ry = yr == y; k = yi[y]; r0 = R0[ry]; o_ = okf[ry]; n_ = neg[ry]
        for q in range(NQ):
            Mq = (masks[:, ry] & (ql[ry] >= q)[None, :]).astype(np.float32)
            if not Mq.any(): continue
            S[:, q * nE:(q + 1) * nE, k] = Mq @ r0; C[:, q * nE:(q + 1) * nE, k] = Mq @ o_; NG[:, q * nE:(q + 1) * nE, k] = Mq @ n_
    return S, C, NG
def select(S, C, NG):
    """(K, NK, 年) → 各形・各分け方の選んだ点と成績"""
    K = S.shape[0]; out = {}
    for how in ('単点', '周辺'):
        res = {}
        for fn, splits in FORMS.items():
            ts = np.zeros(K); tc = np.zeros(K); ty = np.zeros(K); ch = []
            for tr, te in splits:
                a = [yi[y] for y in tr]; b = [yi[y] for y in te]
                sm = S[:, :, a].sum(2, dtype=np.float64); cn = C[:, :, a].sum(2); ng = NG[:, :, a].sum(2)
                with np.errstate(all='ignore'): mean = np.where(cn > 0, sm / np.maximum(cn, 1), np.nan)
                ok = (cn >= 15) & (ng == 0)
                if how == '単点': score = np.where(ok, mean, -np.inf)
                else:
                    fin = np.isfinite(mean); num = (NBm @ np.where(fin, mean, 0).T).T; den = (NBm @ fin.T.astype(float)).T
                    with np.errstate(all='ignore'): nbm = np.where(den > 0, num / den, np.nan)
                    score = np.where(ok, nbm, -np.inf)
                score = np.nan_to_num(score, nan=-np.inf); has = np.isfinite(score.max(1)); k = np.argmax(score, 1)
                ch.append(np.where(has, k, -1))
                sb = S[np.arange(K), k][:, b].sum(1); cb = C[np.arange(K), k][:, b].sum(1)
                ts += np.where(has, sb, 0); tc += np.where(has, cb, 0); ty += np.where(has, len(b), 0)
            part = 2026 in [y for _, te in splits for y in te]
            yrs_eff = np.where(part, ty - (1 - 280 / 365), ty)
            with np.errstate(all='ignore'): res[fn] = (np.where(tc > 0, ts / np.maximum(tc, 1), np.nan), tc / np.maximum(yrs_eff, 1e-9), np.array(ch).T)
        out[how] = res
    return out
def rows_from(sel, S, C, info):
    out = []
    for how, res in sel.items():
        vals = np.array([res[f][0] for f in FORMS]).T; K = vals.shape[0]
        for i in range(K):
            row = dict(info[i], 選び方=how)
            for j, f in enumerate(FORMS): row[f + '_平均'] = vals[i, j]; row[f + '_年件数'] = res[f][1][i]
            row['プラスの数'] = int(np.nansum(vals[i] > 0)); row['中央'] = np.nanmedian(vals[i]); row['年件数_中央'] = np.nanmedian([res[f][1][i] for f in FORMS])
            tot = 0; cnt = 0
            for (tr, te), k in zip(FORMS['WF全期間'], res['WF全期間'][2][i]):
                b = yi[te[0]]
                if k < 0: row[f'前向き{te[0]}'] = np.nan; continue
                row[f'前向き{te[0]}'] = S[i, k, b] / C[i, k, b] if C[i, k, b] else np.nan; tot += S[i, k, b]; cnt += C[i, k, b]
            row['前向き合計'] = tot; row['前向き件数'] = cnt
            for lab, f, j in [('今', 'WF全期間', -1), ('前半で選んだ', '前半→後半', 0)]:
                k = res[f][2][i][j]
                if k >= 0:
                    qi, ei = divmod(int(k), nE); e = EXd.iloc[ei]
                    row[lab + 'の強さ'] = QN[qi]; row[lab + 'の手じまい'] = f"{e.型}:利確{e.利確}/損切り{e.損切り}/時間{e.時間}"; row[lab + '_k'] = int(k)
            row['WF全期間_k'] = list(map(int, res['WF全期間'][2][i]))
            out.append(row)
    return out
def check():
    EV = pd.read_pickle(O + 'EV2_D.pkl'); sh = YM[YM.src == 'E2'].groupby(['観察', '向き', '入る']).indices; out = []
    for (ob, dn, en), idx in sh.items():
        S, C, NG = scs(idx, np.ones((1, len(idx)), bool)); out += rows_from(select(S, C, NG), S, C, [dict(観察=ob, 向き=dn, 入る=en)])
    T = pd.DataFrame(out); M = T.merge(EV, on=['観察', '向き', '入る', '選び方'], suffixes=('', '_旧'))
    for c in ['中央', 'プラスの数', '年件数_中央', '前向き合計', '前向き件数']:
        d = (M[c] - M[c + '_旧']).abs(); print(c, '最大の差', round(float(d.max()), 4), '一致しない', int((d > 0.01).sum()), '/', len(M))
    print('今の手じまい 一致', (M['今の手じまい'] == M['今の手じまい_旧']).mean(), '今の強さ 一致', (M['今の強さ'] == M['今の強さ_旧']).mean())
    bad = M[(M['中央'] - M['中央_旧']).abs() > 0.01]; print(bad[['観察', '向き', '入る', '選び方', '中央', '中央_旧']].head(10).to_string())
if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'check': check(); sys.exit()
    S0 = pd.read_pickle(O + 'YS.pkl'); BINS = pd.read_pickle(O + 'YBINS.pkl'); out = []
    for (side, bs), g in S0[S0.通過].groupby(['向き', '売買']):
        base = (YM.向き.values == side) & (YM.売買.values == bs)
        conds = [('なし', '', '入る', np.ones(len(YM), bool))]
        for late in (False, True):
            keys, packed, nn = BINS[(side, bs, late)]; kix = {k: i for i, k in enumerate(keys)}
            for r in g[g.後半のみ == late].itertuples():
                mk = np.unpackbits(packed[kix[(r.指標, r.区分)]])[:nn].astype(bool)
                conds.append((r.指標, r.区分, r.使い方, mk if r.使い方 == '入る' else ~mk))
        Mall = np.array([c[3] for c in conds])
        for (ob, en), idx in YM[base].groupby(['観察', '入る']).indices.items():
            idx = np.flatnonzero(base)[idx]          # YM の行番号
            S, C, NG = scs(idx, Mall[:, idx])
            info = [dict(向き=side, 売買=bs, 指標=c[0], 区分=c[1], 使い方=c[2], 観察=ob, 入る=en) for c in conds]
            out += rows_from(select(S, C, NG), S, C, info)
        print(side, bs, len(conds), len(out), flush=True)
    T = pd.DataFrame(out); T.to_pickle(O + 'YE.pkl')
