# 偶然の目安との比較（参考）：該当率の帯ごとに、残る割合・「残る かつ 条件なしより良い」割合
import pandas as pd, numpy as np
O='/home/claude/yt/out/'; COV=[.1,.2,.33,.5,.67,.8,.9]
N=pd.read_pickle(O+'YNULL.pkl'); T=pd.read_pickle(O+'YE2.pkl')
for D in (N,T): D['残す']=(D.プラスの数>=3)&(D.中央>=20)&(D.年件数_中央>=10)
key=['向き','売買','観察','入る','選び方']
b=T[T.指標=='なし'].set_index(key).中央.rename('b')
N=N.join(b,on=key); N['良い']=N.残す&(N.中央>N.b); T['良い']=T.残す&(T.条件なしとの差>0)
c=T[T.指標!='なし'].copy()
c['cov']=np.where(c.使い方=='入る',c.該当率,1-c.該当率); c['帯']=pd.cut(c['cov'],[0,.15,.27,.42,.58,.73,.85,1],labels=COV).astype(float)
r1=N.groupby(['向き','売買','該当率']).agg(偶然_残る=('残す','mean'),偶然_良い=('良い','mean'))
r2=c.groupby(['向き','売買','帯']).agg(実際_残る=('残す','mean'),実際_良い=('良い','mean'),件数=('残す','size'))
r2.index=r2.index.set_names(['向き','売買','該当率'])
R=r1.join(r2); R[['偶然_残る','偶然_良い','実際_残る','実際_良い']]*=100; R.round(1).to_pickle(O+'YCMP.pkl'); print(R.round(1).to_string())
