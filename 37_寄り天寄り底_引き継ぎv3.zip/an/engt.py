# 売買エンジン（eng.py の sim）に手じまいの時刻を加えた版。損益は sim と同じ
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/an')
from eng import P, PM, PO, PH, PL, IND, INF, SPREAD, UNIT, TPp, SLp, TPk, SLk, TIMES, INDS, ISL, ITM, EX, ind_exit
def sim_t(args):
    d, te, mv, tcap, tam, sess = args
    T = TIMES[sess]; nE = len(EX[sess])
    out = np.full(nE, np.nan, np.float32); tout = np.full(nE, np.nan)
    j0 = np.searchsorted(PM, te)
    if j0 >= len(PM) or PM[j0] - te >= 5 or te >= tcap: return out, tout
    e = PO[j0]; jc = np.searchsorted(PM, tcap)
    if jc <= j0: return out, tout
    hi = PH[j0:jc]; lo = PL[j0:jc]; op = PO[j0:jc + 1] if jc < len(PO) else np.r_[PO[j0:jc], PO[-1]]
    mm = PM[j0:jc]
    if d > 0: fav = np.maximum.accumulate(hi - e); adv = np.maximum.accumulate(e - lo)
    else: fav = np.maximum.accumulate(e - lo); adv = np.maximum.accumulate(hi - e)
    n = len(mm)
    # 時間の打ち切り（足の番号）
    def tix(tm):
        if tm == 'C': return n
        if tm == 'AM':
            if tam is None or tam <= te: return -1
            return min(np.searchsorted(mm, tam), n)
        return min(np.searchsorted(mm, te + tm), n)
    tI = np.array([tix(tm) for tm in T])
    def pnl(xp): return ((xp - e) * d - SPREAD) / e * UNIT
    def grid(tps, sls):
        tpi = np.array([np.searchsorted(fav, v, 'left') if np.isfinite(v) else n for v in tps])
        sli = np.array([np.searchsorted(adv, v, 'left') if np.isfinite(v) else n for v in sls])
        res = np.full((len(tps), len(sls), len(T)), np.nan); rt = np.full_like(res, np.nan)
        for a in range(len(tps)):
            for b in range(len(sls)):
                for c in range(len(T)):
                    ti = tI[c]
                    if ti < 0: continue
                    ki = min(tpi[a], sli[b])
                    if ki < ti and ki < n:
                        rt[a, b, c] = mm[ki]
                        if sli[b] <= tpi[a]:   # 同じ足は損切りを先
                            lvl = e - d * sls[b]; o = op[ki]
                            xp = min(o, lvl) if d > 0 else max(o, lvl)
                        else:
                            lvl = e + d * tps[a]; o = op[ki]
                            xp = max(o, lvl) if d > 0 else min(o, lvl)
                    else:
                        xp = op[min(ti, n)]; rt[a, b, c] = mm[ti] if ti < n else tcap
                    res[a, b, c] = pnl(xp)
        TT.append(rt.ravel()); return res.ravel()
    TT = []
    r1 = grid([v / 100 * e for v in TPp], [v / 100 * e for v in SLp])
    r2 = grid([v * mv for v in TPk], [v * mv for v in SLk])
    # 指標
    r3 = []; t3 = []
    for (nm, tf, lv) in INDS:
        ti_t, ti_p = ind_exit(tf, nm, lv, d, te, tcap)
        for sl in ISL:
            sli = np.searchsorted(adv, sl / 100 * e, 'left') if np.isfinite(sl) else n
            for tm in ITM:
                tlim = tI[T.index(tm)] if tm in T else n
                tl_time = mm[tlim] if tlim < n else tcap
                if tf == 1 and ti_t == INF and te < IND[1]['m'][0] + 1440: r3.append(np.nan); t3.append(np.nan); continue
                slt = mm[sli] if sli < n else INF
                cand = [(slt, 0), (ti_t, 1), (tl_time, 2)]
                tmin, kind = min(cand, key=lambda z: (z[0], z[1]))
                if kind == 0:
                    lvl = e - d * sl / 100 * e; o = op[sli]; xp = min(o, lvl) if d > 0 else max(o, lvl)
                elif kind == 1:
                    if ti_p is not None and not (isinstance(ti_p, float) and np.isnan(ti_p)): xp = ti_p
                    else: xp = op[min(np.searchsorted(mm, ti_t), n)]
                else:
                    xp = op[min(tlim, n)]
                r3.append(pnl(xp)); t3.append(min(tmin, tcap) if kind != 2 else tl_time)
    out[:] = np.r_[r1, r2, np.array(r3)]; tout[:] = np.r_[TT[0], TT[1], np.array(t3)]
    return out, tout

