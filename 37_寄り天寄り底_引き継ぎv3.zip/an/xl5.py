# Excel 出力：Y5_寄り天寄り底_重なりと採用候補.xlsx
import pandas as pd, numpy as np
O='/home/claude/yt/out/'; F=O+'Y5_寄り天寄り底_重なりと採用候補.xlsx'
G=pd.read_pickle(O+'YG.pkl'); V=pd.read_pickle(O+'YV.pkl'); NOW=pd.read_pickle(O+'YNOW.pkl')
desc=[['寄り天・寄り底：重なりでまとめる・採用候補（案3）（2026-10-17）',''],
 ['対象','指標の段階で残った候補（単点・周辺のどちらか）14,738件（＋方向だけの条件なし）。祝日取引日は含めたまま（まろの決定）'],
 ['重なり','2022年以降に入る日の集合の Ochiai。避けるは外す日どうし。向き×売買×入る/避けるごとに平均連結、区切り0.5（感度0.4・0.6）。代表は ①両方の選び方 ②5つの形の最悪 ③年件数。入る形の違う2番目にも印'],
 ['案3','分類（向き×売買）ごとに、前の付け方（その年のルールでの選ぶ期間の1回平均、15件以上、前向き記録がマイナスなら外す）と新しい付け方（前向きRF、20件以上・前向きプラス・2017〜21プラス）の上位N本を合わせる。同じグループは最上位だけ'],
 ['絞り込み','入る日が75%以上重なる候補は1本（前向きRFの良い方）、前向きPF1.2未満は記録だけ'],
 ['前向き検証','2024〜26年。各年の候補と順位はその年より前のデータだけで決める。同じセッションで一度手じまったら入り直さない。A1 先着1本／B 両建て／C1 同じ向き2本／D1 両建て＋2本目'],
 ['注意','候補自体は2026年までのデータで残したもの（ふるいに2022年以降を使用）。前向き検証も当てはめの影響を受ける。最終判断はフォワード'],
 ['注意','「全部（4区分）」が売り・買い別の合計より良いのは、同じ日に逆の売買のシグナルが出る日に先に出た方だけを持つため（どちらが先かに左右される）']]
c=['分類','指標','区分','使い方','観察','入る','選び方','前の順位','新の順位','件数','合計','PF','RF','今の強さ','今の手じまい','扱い','グループの大きさ','安定','中央','年件数_中央','前向き_平均_20pt']
with pd.ExcelWriter(F,engine='openpyxl') as w:
    pd.DataFrame(desc,columns=['項目','内容']).to_excel(w,sheet_name='説明',index=False)
    V.round(1).to_excel(w,sheet_name='前向き検証',index=False)
    for N in (5,3):
        S=NOW[N].rename(columns={'件数':'件数','合計':'合計'}); S[[x for x in c if x in S]].round(2).to_excel(w,sheet_name=f'今の採用候補(上位{N})',index=False)
    gc=['向き','売買','使い方','g0.5','代表','2番目','安定','グループの大きさ','指標','区分','観察','入る','選び方','最悪','年件数','中央','日数']
    G.sort_values(['向き','売買','使い方','g0.5','代表'],ascending=[True,True,True,True,False])[gc].round(2).to_excel(w,sheet_name='候補とグループ',index=False)
from openpyxl import load_workbook
wb=load_workbook(F)
for ws in wb.worksheets:
    ws.freeze_panes='A2'
    for col in ws.columns:
        L=max(len(str(x.value)) if x.value is not None else 0 for x in col[:200]); ws.column_dimensions[col[0].column_letter].width=min(max(8,L*1.2),50)
wb['説明'].column_dimensions['B'].width=120; wb.save(F); print(F)
