# 寄り（日中 8:45〜）のトレードに指標を付ける。判定の時点＝入る足の始まり（te）。確定した足だけを使う（先読みしない）
#   向きのある指標は「寄りの動き（8:45→観察の終わり）と同じ向き＝プラス」（s＝観察の動きの符号）
#   基準の値段 B＝8:45 の CFD の値段、入る値段 entp＝te の足の CFD 始値（売買エンジンと同じ）
#   ① F6 相当：CFD 5分足から 5分・15分・60分・4時間・日足・週足の指標（indlib）、前日高安まで、節目（1000円）
#   ② F7 相当：一目の位置関係、平均足の形、価格の節目（前日・前週・前月、20/60日高安、ピボット、SQ値、キリ番）、出来高、
#      BB・ストキャス・CCI・60本高安の位置、実現ボラ比、時期
#   ③ 寄り特有：夜間・前日日中の形、寄りの窓、8:45 前の CFD、観察中の動きのきれいさ（先物5分足）、天井の時刻と伸び、
#      直近の寄り後の戻り率、寄りの動きの連続、SQ・祝日・月末月初の印
#   出力：out/YF.pkl（YM と同じ行順）
import sys, glob, datetime as dt, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/code'); import indlib
O = '/home/claude/yt/out/'; REPO = '/root/nk225-data'; U = '2026-10-09'
YM = pd.read_pickle(O + 'YM.pkl'); n = len(YM)
P = pd.read_pickle(O + 'P.pkl'); PM = P.m.values.astype('int64'); PO = P.open.values; PH = P.high.values; PL = P.low.values
c5 = pd.read_pickle(O + 'c5.pkl'); f5 = pd.read_pickle(O + 'f5.pkl')
FM = f5.m.values.astype('int64'); FO = f5.open.values; FH = f5.high.values; FL_ = f5.low.values; FC = f5.close.values
cal = pd.read_pickle(O + 'cal.pkl'); lib, nodata = cal['lib'], cal['nodata']
def pxa(M, Op, t, tol=5):
    i = np.searchsorted(M, t); i2 = np.minimum(i, len(M) - 1); ok = (i < len(M)) & ((M[i2] - t) < tol); return np.where(ok, Op[i2], np.nan)
s = YM.sx.values.astype(float); te = YM.te.values.astype('int64'); m0 = YM.m0.values.astype('int64')
L = YM.観察.map(lambda z: {'9:00': 15, '9:05': 20, '9:10': 25, '9:15': 30, '9:30': 45}[z.split('→')[1]]).values; bt = m0 + L
B = pxa(PM, PO, m0); entp = PO[np.minimum(np.searchsorted(PM, te), len(PM) - 1)]
X = {}
# ---------------------------------------------------------------- ① F6 相当
x = c5.rename(columns={'open': 'o', 'high': 'h', 'low': 'l', 'close': 'c'})[['m', 'o', 'h', 'l', 'c']].copy(); x['m'] = x.m.astype('int64')
agg = dict(o=('o', 'first'), h=('h', 'max'), l=('l', 'min'), c=('c', 'last')); dayk = (x.m + 120) // 1440
TFS = {'5m': (x.m // 5, lambda k: (k + 1) * 5, [20, 25, 75, 100, 200]), '15m': (x.m // 15, lambda k: (k + 1) * 15, [20, 25, 75, 100, 200]),
       '60m': (x.m // 60, lambda k: (k + 1) * 60, [20, 25, 75, 100, 200]), '4h': (x.m // 240, lambda k: (k + 1) * 240, [20, 25, 75, 100, 200]),
       'D': (dayk, lambda k: (k + 1) * 1440 - 120, [20, 25, 75, 100, 200, 13, 26]), 'W': ((dayk + 3) // 7, lambda k: ((k + 1) * 7 - 3) * 1440 - 120, [20, 25, 75, 100, 13, 26])}
BARS = {}
for k, (key, av, _) in TFS.items():
    b = x.groupby(key).agg(**agg); b['avail'] = av(b.index.values); BARS[k] = b.sort_values('avail').reset_index(drop=True)
order = np.argsort(te, kind='stable')
def asof(df, cols, M=te):
    o_ = np.argsort(M, kind='stable')
    r = pd.merge_asof(pd.DataFrame({'m': M[o_]}), df[['avail'] + cols].dropna(subset=['avail']).sort_values('avail'), left_on='m', right_on='avail', direction='backward')
    out = {}
    for c_ in cols:
        v = np.full(len(M), np.nan); v[o_] = r[c_].values; out[c_] = v
    return out
NOND = ('adx', 'atr')
for k, (key, av, mas) in TFS.items():
    b = BARS[k]; i_ = indlib.ind(b[['o', 'h', 'l', 'c']], mas); i_['avail'] = b.avail.values
    A = asof(i_, [c for c in i_.columns if c != 'avail'])
    for c_, v in A.items(): X[c_ + '_' + k] = v if c_ in NOND else v * s
atrD = X['atr_D']
dd = BARS['D']
A = asof(dd, ['h', 'l']); ext_ = np.where(s > 0, A['h'], A['l']); X['前日高安まで'] = (ext_ - entp) / B * 100 * s
X['節目まで'] = np.minimum(entp % 1000, 1000 - entp % 1000) / B * 100; X['節目を越えた'] = (np.floor(B / 1000) != np.floor(entp / 1000)).astype(float)
# ---------------------------------------------------------------- ② F7 相当
between = lambda Lv: ((Lv - B) * (Lv - entp) < 0).astype(float)      # 8:45 の値段と入る値段の間にある
ahead = lambda Lv: (Lv - entp) / B * 100 * s                          # プラス＝まだ先（寄りの動きの向き）、マイナス＝越えた
for k in ('15m', '60m', '4h', 'D', 'W'):
    b = BARS[k].copy(); h, l, c = b.h, b.l, b.c; mid = lambda q: (h.rolling(q).max() + l.rolling(q).min()) / 2
    tk, kj = mid(9), mid(26); sa = ((tk + kj) / 2).shift(26); sb = mid(52).shift(26); saf = (tk + kj) / 2; sbf = mid(52)
    b['tk'] = tk; b['kj'] = kj; b['top'] = np.maximum(sa, sb); b['bot'] = np.minimum(sa, sb); b['tw'] = np.sign(sa - sb); b['twf'] = np.sign(saf - sbf); b['chi'] = (c - c.shift(26)) / c * 100; b['cc'] = c
    A = asof(b, ['tk', 'kj', 'top', 'bot', 'tw', 'twf', 'chi', 'cc'])
    v = sum(np.nan_to_num(between(A[q])) for q in ('tk', 'kj', 'top', 'bot')); v[np.isnan(A['bot'])] = np.nan; X['一目線またぎ数_' + k] = v
    X['エントリー雲位置_' + k] = np.where(np.isnan(A['bot']), np.nan, np.where(entp > A['top'], 1.0, np.where(entp < A['bot'], -1.0, 0.0)) * s)
    X['雲の厚さ_' + k] = (A['top'] - A['bot']) / A['cc'] * 100; X['先の雲の向き_' + k] = A['twf'] * s
    X['ねじれ前_' + k] = np.where(np.isnan(A['tw']) | np.isnan(A['twf']), np.nan, (A['tw'] != A['twf']).astype(float)); X['遅行スパン_' + k] = A['chi'] * s
for k in ('60m', '4h', 'D', 'W'):
    b = BARS[k].copy(); hc = ((b.o + b.h + b.l + b.c) / 4).values; ho = np.empty(len(b)); ho[0] = (b.o.iloc[0] + b.c.iloc[0]) / 2
    for i in range(1, len(b)): ho[i] = (ho[i - 1] + hc[i - 1]) / 2
    hh = np.maximum.reduce([b.h.values, ho, hc]); hl = np.minimum.reduce([b.l.values, ho, hc]); col = np.sign(hc - ho)
    b['body'] = np.abs(hc - ho) / np.maximum(hh - hl, 1e-9); b['strong'] = np.where((col > 0) & (hl >= ho - 1e-9), 1.0, np.where((col < 0) & (hh <= ho + 1e-9), -1.0, 0.0))
    A = asof(b, ['body', 'strong']); X['平均足実体比_' + k] = A['body']; X['平均足ヒゲなし_' + k] = A['strong'] * s
dd2 = dd.copy(); dd2['pdc'] = dd2.c; dd2['h20'] = dd2.h.rolling(20).max(); dd2['l20'] = dd2.l.rolling(20).min(); dd2['h60'] = dd2.h.rolling(60).max(); dd2['l60'] = dd2.l.rolling(60).min()
P_ = (dd2.h + dd2.l + dd2.c) / 3; dd2['P'] = P_; dd2['R1'] = 2 * P_ - dd2.l; dd2['S1'] = 2 * P_ - dd2.h; dd2['R2'] = P_ + dd2.h - dd2.l; dd2['S2'] = P_ - dd2.h + dd2.l
A = asof(dd2, ['pdc', 'h20', 'l20', 'h60', 'l60', 'P', 'R1', 'S1', 'R2', 'S2'])
X['前日終値まで'] = ahead(A['pdc']); X['20日高安まで'] = np.where(s > 0, ahead(A['h20']), ahead(A['l20'])); X['60日高安まで'] = np.where(s > 0, ahead(A['h60']), ahead(A['l60']))
PV = np.vstack([A[q] for q in ('S2', 'S1', 'P', 'R1', 'R2')]); X['ピボットまたぎ数'] = np.where(np.isnan(PV).any(0), np.nan, between(PV).sum(0))
dist = np.where(((PV - entp) * s) > 0, np.abs(PV - entp), np.inf).min(0); X['先のピボットまで'] = np.where(np.isfinite(dist), dist / B * 100, np.nan)
A = asof(BARS['W'], ['h', 'l', 'c']); X['前週高安まで'] = np.where(s > 0, ahead(A['h']), ahead(A['l'])); X['前週安高まで'] = np.where(s > 0, ahead(A['l']), ahead(A['h'])); X['前週終値まで'] = ahead(A['c'])
dkey = (dd.avail.values - 1440 + 120) // 1440   # 日足の番号
dts = pd.to_datetime(dkey * 1440 * 60 + 16 * 3600, unit='s'); mk = dts.year * 12 + dts.month - 1
mo = dd.groupby(mk.values).agg(h=('h', 'max'), l=('l', 'min'), c=('c', 'last'), avail=('avail', 'last')); A = asof(mo.reset_index(drop=True), ['h', 'l', 'c'])
X['前月高安まで'] = np.where(s > 0, ahead(A['h']), ahead(A['l'])); X['前月終値まで'] = ahead(A['c'])
LV = np.vstack([X[q] for q in ('前日終値まで', '前週終値まで', '前月終値まで')] + [ahead(A['h']), ahead(A['l'])]); X['またいだ節目数(終値・高安)'] = np.nansum(LV < 0, 0).astype(float)
def isbiz(z): return z.weekday() < 5 and z not in nodata and not (z > dt.date(2026, 10, 8) and z in lib)
def sqdate(y, m_):
    first = dt.date(y, m_, 1); z = first + dt.timedelta(days=(4 - first.weekday()) % 7 + 7)
    while not isbiz(z): z -= dt.timedelta(days=1)
    return z
fdate = f5.t.dt.date.values; fhm = f5.t.dt.strftime('%H:%M').values; sq = []
for y in range(2016, 2027):
    for m_ in range(1, 13):
        z = sqdate(y, m_); w = np.flatnonzero((fdate == z) & (fhm == '08:45'))
        if len(w): sq.append((int(FM[w[0]]) + 135, float(FO[w[0]]), m_ in (3, 6, 9, 12)))
sq = pd.DataFrame(sq, columns=['avail', 'v', 'major']); A = asof(sq, ['v']); X['SQ値まで'] = ahead(A['v']); X['SQ値をまたいだ'] = between(A['v'])
A = asof(sq[sq.major].reset_index(drop=True), ['v']); X['メジャーSQ値まで'] = ahead(A['v'])
for u, nm in ((250, '250'), (500, '500')):
    X['キリ%sまで' % nm] = np.minimum(entp % u, u - entp % u) / B * 100; X['キリ%sを越えた' % nm] = (np.floor(B / u) != np.floor(entp / u)).astype(float)
q = (entp - 250) % 500; X['キリ250・750のみまで'] = np.minimum(q, 500 - q) / B * 100; X['キリ250・750のみを越えた'] = (np.floor((B - 250) / 500) != np.floor((entp - 250) / 500)).astype(float)
fd = pd.read_csv(glob.glob(REPO + '/OSE_NK225M1!, 1D 6.csv')[0]); fd['date'] = pd.to_datetime(fd.time, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.date
fd['t0'] = fd.time; fd = fd.groupby('date').agg(v=('Volume', 'sum'), t0=('t0', 'first')).reset_index(); fd['r20'] = fd.v / fd.v.shift(1).rolling(20).mean(); fd['r5'] = fd.v / fd.v.shift(1).rolling(5).mean()
fd['avail'] = fd.t0.shift(-1) // 60; fd = fd.dropna(subset=['avail']).copy(); fd['avail'] = fd['avail'].astype('int64'); A = asof(fd, ['r20', 'r5']); X['日足出来高比20'] = A['r20']; X['日足出来高比5'] = A['r5']
for k in ('15m', '60m', '4h', 'D'):
    b = BARS[k].copy(); c = b.c; h = b.h; l = b.l; ma = c.rolling(20).mean(); sd = c.rolling(20).std()
    b['bb'] = (c - ma) / sd; bw = 4 * sd / ma * 100; b['bwr'] = bw.rolling(120, min_periods=60).rank(pct=True)
    b['st'] = (c - l.rolling(14).min()) / (h.rolling(14).max() - l.rolling(14).min()).replace(0, np.nan) * 100 - 50
    tp = (h + l + c) / 3; md = tp.rolling(20).apply(lambda z: np.abs(z - z.mean()).mean(), raw=True); b['cci'] = (tp - tp.rolling(20).mean()) / (0.015 * md)
    b['p60'] = (c - l.rolling(60).min()) / (h.rolling(60).max() - l.rolling(60).min()).replace(0, np.nan) - .5
    A = asof(b, ['bb', 'bwr', 'st', 'cci', 'p60'])
    X['BBσ位置_' + k] = A['bb'] * s; X['BB幅順位_' + k] = A['bwr']; X['ストキャス_' + k] = A['st'] * s; X['CCI_' + k] = A['cci'] * s; X['60本高安の位置_' + k] = A['p60'] * s
for k, (ns, nl) in (('5m', (12, 288)), ('60m', (6, 120))):
    b = BARS[k].copy(); r = np.log(b.c).diff(); b['rv'] = r.rolling(ns).std() / r.rolling(nl).std(); X['実現ボラ比_' + k] = asof(b, ['rv'])['rv']
# ---------------------------------------------------------------- ③ 寄り特有（セッション単位）
ss = pd.read_pickle(O + 'sess.pkl'); ss = ss[ss.t >= pd.Timestamp('2017-03-16', tz='Asia/Tokyo')].reset_index(drop=True)
ss_all = pd.read_pickle(O + 'sess.pkl')
def sess_ohlc(a, e):
    i0 = np.searchsorted(FM, a); i1 = np.searchsorted(FM, e)
    if i1 <= i0: return (np.nan,) * 6
    return FO[i0], FH[i0:i1].max(), FL_[i0:i1].min(), FC[i1 - 1], i0, i1
# すべてのセッションの OHLC
SO = np.array([sess_ohlc(r.m, r.end)[:4] for r in ss_all.itertuples()], float)
SA = ss_all.reset_index(drop=True); SA[['o', 'h', 'l', 'c']] = SO
SA['c60'] = pxa(FM, FO, SA.end.values - 60)
Dn = SA[SA.kind == 'D'].copy(); Dn['p900'] = pxa(FM, FO, Dn.m.values + 15)
mv9 = Dn.p900 - Dn.o; Dn['sg9'] = np.sign(mv9); Dn['rev'] = (np.sign(Dn.c - Dn.p900) == -Dn.sg9).astype(float)
Dn['rng'] = (Dn.h - Dn.l) / Dn.c * 100
Dn['戻り率20'] = Dn.rev.shift(1).rolling(20, min_periods=15).mean(); Dn['前日戻り'] = Dn.rev.shift(1)
run = np.zeros(len(Dn)); sgv = Dn.sg9.values
for j in range(1, len(Dn)): run[j] = (run[j - 1] + sgv[j - 1]) if (j > 1 and sgv[j - 1] == sgv[j - 2] and sgv[j - 1] != 0) else sgv[j - 1]
Dn['連続'] = run; Dn['平均値幅20'] = Dn.rng.shift(1).rolling(20, min_periods=15).mean()
Dn['前日o'] = Dn.o.shift(1); Dn['前日h'] = Dn.h.shift(1); Dn['前日l'] = Dn.l.shift(1); Dn['前日c'] = Dn.c.shift(1)
# 夜間（その日の寄りの直前のセッション）
SA['prev_kind'] = SA.kind.shift(1);
for c_ in ('m', 'end', 'o', 'h', 'l', 'c', 'c60'): SA['n_' + c_] = SA[c_].shift(1)
Dn = Dn.join(SA[['prev_kind', 'n_m', 'n_end', 'n_o', 'n_h', 'n_l', 'n_c', 'n_c60']])
Dn.loc[Dn.prev_kind != 'N', ['n_m', 'n_end', 'n_o', 'n_h', 'n_l', 'n_c', 'n_c60']] = np.nan
Dn['gap'] = (Dn.o - Dn.n_c) / Dn.n_c * 100
ag = Dn.gap.abs().values; rk = np.full(len(ag), np.nan)
for j in range(60, len(ag)):
    w_ = ag[j - 60:j]; w_ = w_[~np.isnan(w_)]
    if len(w_) >= 40 and not np.isnan(ag[j]): rk[j] = (w_ < ag[j]).mean()
Dn['窓順位60'] = rk
# 8:45 前の CFD（夜間の引け〜8:45、8:00〜8:45）
CMa = PM;
def crange(a, e):
    i0 = np.searchsorted(CMa, a); i1 = np.searchsorted(CMa, e)
    return (PH[i0:i1].max() - PL[i0:i1].min()) if i1 > i0 else np.nan
Dn['c845'] = pxa(PM, PO, Dn.m.values); PCl = P.close.values; jN = np.searchsorted(PM, np.nan_to_num(Dn.n_end.values, nan=0).astype('int64')) - 1
Dn['cNend'] = np.where(np.isfinite(Dn.n_end.values) & (jN >= 0), PCl[np.maximum(jN, 0)], np.nan)   # 夜間の引けの直前の CFD 足の終値
Dn['c800'] = pxa(PM, PO, Dn.m.values - 45)
Dn['cpre_rng'] = [crange(a, e) if a == a else np.nan for a, e in zip(Dn.n_end.values, Dn.m.values)]
Dn['date'] = Dn.t.dt.date
Dn = Dn.set_index('m')
G = Dn.loc[m0]           # 各トレードのその日の行
gv = lambda c_: G[c_].values.astype(float)
X['夜間騰落'] = (gv('n_c') - gv('n_o')) / gv('n_o') * 100 * s
X['夜間値幅'] = (gv('n_h') - gv('n_l')) / gv('n_c') * 100
X['夜間引け前60分'] = (gv('n_c') - gv('n_c60')) / gv('n_c') * 100 * s
pos = (gv('n_c') - gv('n_l')) / np.maximum(gv('n_h') - gv('n_l'), 1e-9); X['夜間引け位置'] = np.where(s > 0, pos, 1 - pos)
rg = np.maximum(gv('n_h') - gv('n_l'), 1e-9); no, nc, nh, nl = gv('n_o'), gv('n_c'), gv('n_h'), gv('n_l')
X['夜間実体比'] = (nc - no) / rg * s; X['夜間向き側ヒゲ比'] = np.where(s > 0, nh - np.maximum(nc, no), np.minimum(nc, no) - nl) / rg; X['夜間逆側ヒゲ比'] = np.where(s > 0, np.minimum(nc, no) - nl, nh - np.maximum(nc, no)) / rg
po_, ph_, pl_, pc_ = gv('前日o'), gv('前日h'), gv('前日l'), gv('前日c')
X['前日日中騰落'] = (pc_ - po_) / po_ * 100 * s; X['前日日中値幅'] = (ph_ - pl_) / pc_ * 100
pos = (pc_ - pl_) / np.maximum(ph_ - pl_, 1e-9); X['前日日中引け位置'] = np.where(s > 0, pos, 1 - pos)
X['夜間値幅比(前日日中比)'] = (nh - nl) / np.maximum(ph_ - pl_, 1e-9)
o845 = gv('o'); X['寄りの窓'] = gv('gap') * s; X['寄りの窓の大きさ'] = np.abs(gv('gap')); X['寄りの窓÷日ATR'] = gv('gap') * s / atrD; X['寄りの窓順位60'] = gv('窓順位60')
pos = (o845 - pl_) / np.maximum(ph_ - pl_, 1e-9) - .5; X['寄りの位置(前日日中の高安)'] = np.where(s > 0, pos, -pos)
X['前日日中の高安の外で寄った'] = np.where(np.isnan(ph_), np.nan, np.where(o845 > ph_, 1.0, np.where(o845 < pl_, -1.0, 0.0)) * s)
X['夜間の高安の外で寄った'] = np.where(np.isnan(nh), np.nan, np.where(o845 > nh, 1.0, np.where(o845 < nl, -1.0, 0.0)) * s)
X['8:45前のCFD値幅'] = gv('cpre_rng') / B * 100; X['8:45前のCFD値幅÷日ATR'] = X['8:45前のCFD値幅'] / atrD
X['8:45前のCFD騰落(夜間引けから)'] = (gv('c845') - gv('cNend')) / B * 100 * s; X['8:45前のCFD騰落(8:00から)'] = (gv('c845') - gv('c800')) / B * 100 * s
X['平均値幅20'] = gv('平均値幅20'); X['直近20日の寄り後の戻り率'] = gv('戻り率20'); X['前日の寄り後が戻った'] = gv('前日戻り'); X['寄りの動きの連続(向き)'] = gv('連続') * s
# 観察中の動き（先物5分足、8:45〜観察の終わり）
eff = np.full(n, np.nan); upr = np.full(n, np.nan); r2 = np.full(n, np.nan); endp = np.full(n, np.nan); mae = np.full(n, np.nan); fst = np.full(n, np.nan)
key = pd.DataFrame({'m0': m0, 'b': bt, 's': s}); uk = key.drop_duplicates().reset_index(drop=True); res = {}
for r in uk.itertuples():
    i0 = np.searchsorted(FM, r.m0); i1 = np.searchsorted(FM, r.b)
    if i1 - i0 < 2: continue
    pts = np.r_[FO[i0], FC[i0:i1]]; mvp = pts[-1] - pts[0]
    if mvp == 0: continue
    dl = np.diff(pts); e_ = abs(mvp) / np.abs(dl).sum()
    u_ = np.mean(np.sign(FC[i0:i1] - FO[i0:i1]) * r.s > 0)
    tt = np.arange(len(pts)); cc = np.corrcoef(tt, pts)[0, 1]; r2_ = cc ** 2 if np.isfinite(cc) else np.nan
    hi, lo = FH[i0:i1].max(), FL_[i0:i1].min(); p_ = (pts[-1] - lo) / max(hi - lo, 1e-9); p_ = p_ if r.s > 0 else 1 - p_
    adv = (pts[0] - lo) if r.s > 0 else (hi - pts[0]); f_ = (FC[i0] - FO[i0]) * r.s / abs(mvp)
    res[(r.m0, r.b, r.s)] = (e_, u_, r2_, p_, adv / abs(mvp), f_)
V = np.array([res.get(k, (np.nan,) * 6) for k in zip(m0, bt, s)])
X['観察の効率比'], X['観察の上げ足割合'], X['観察のR2'], X['観察の終わりの位置'], X['観察中の最大逆行÷動き'], X['観察の最初の5分の割合'] = V.T
X['観察の動き÷日ATR'] = np.abs(YM.x.values) * 100 / atrD
X['経過分'] = (te - bt).astype(float)
X['天井の時刻'] = YM.tpk.values.astype(float); X['天井の伸び'] = YM.ext.values.astype(float)
c0 = pxa(c5.m.values.astype('int64'), c5.open.values, bt); X['入る値段の戻し(動き比)'] = (entp - c0) * s / YM.mv.values
# 出来高（1時間足、2022/12/30〜）：夜間セッション
f3 = pd.read_csv(glob.glob(REPO + '/OSE_NK225M1!, 3.csv')[0]); f3['m'] = (f3.time // 60).astype('int64'); f3 = f3[f3.m < int(pd.Timestamp(U, tz='Asia/Tokyo').timestamp() // 60)].sort_values('m').reset_index(drop=True)
m3 = f3.m.values; v3 = f3.Volume.values.astype(float); p3 = ((f3.high + f3.low + f3.close) / 3).values.astype(float)
late = {}; poc = {}; hvh = {}; hvl = {}
for mm_, p0, pe in zip(Dn.index.values, Dn.n_m.values, Dn.n_end.values):
    if not np.isfinite(pe) or pe < m3[0] + 7 * 1440: continue
    a = np.searchsorted(m3, p0); b_ = np.searchsorted(m3, pe)
    if b_ - a >= 5: vv = v3[a:b_]; late[mm_] = vv[-1] / vv.mean()
    a5 = np.searchsorted(m3, pe - 10 * 1440)
    if b_ - a5 >= 60:
        bins_ = np.floor(p3[a5:b_] / 100) * 100; df_ = pd.Series(v3[a5:b_]).groupby(bins_).sum(); poc[mm_] = df_.idxmax() + 50
        thr = df_.quantile(.8); hv = df_.index.values[df_.values >= thr] + 50; hvh[mm_] = hv.max(); hvl[mm_] = hv.min()
g_ = lambda D_: np.array([D_.get(z, np.nan) for z in m0])
X['夜間最後1時間の出来高比'] = g_(late); pc0 = g_(poc); X['出来高最多価格まで'] = ahead(pc0); X['出来高最多価格をまたいだ'] = np.where(np.isnan(pc0), np.nan, between(pc0))
X['出来高の多い価格帯の端まで'] = ahead(np.where(s > 0, g_(hvh), g_(hvl)))
# ---------------------------------------------------------------- 時期・印
dts_ = G.date.values
def prevbiz(z):
    z -= dt.timedelta(days=1)
    while not isbiz(z): z -= dt.timedelta(days=1)
    return z
def nextwd(z, step):
    z += dt.timedelta(days=step)
    while z.weekday() >= 5: z += dt.timedelta(days=step)
    return z
BD = {}
def bdays(y, m_):
    if (y, m_) not in BD:
        z = dt.date(y, m_, 1); o_ = []
        while z.month == m_:
            if isbiz(z): o_.append(z)
            z += dt.timedelta(days=1)
        BD[(y, m_)] = o_
    return BD[(y, m_)]
def us_dst(z):
    y = z.year; s2 = dt.date(y, 3, 8); s2 += dt.timedelta(days=(6 - s2.weekday()) % 7); n1 = dt.date(y, 11, 1); n1 += dt.timedelta(days=(6 - n1.weekday()) % 7)
    return s2 <= z < n1
FLG = {}
for z in set(dts_):
    sqd = sqdate(z.year, z.month); major = z.month in (3, 6, 9, 12); sqwk = z.isocalendar()[:2] == sqd.isocalendar()[:2]; bd = bdays(z.year, z.month)
    FLG[z] = {'SQ週(メジャー)': sqwk and major, 'SQ週(ミニ)': sqwk and not major, 'SQ当日': z == sqd, 'SQ前日': z == prevbiz(sqd),
              '祝日前日': nextwd(z, 1) in lib, '祝日翌日(連休明け含む)': nextwd(z, -1) in lib, '祝日取引中': z in lib, '月末3営業日': z in bd[-3:], '月初3営業日': z in bd[:3],
              '曜日': z.weekday(), '月の何週目': (z.day - 1) // 7 + 1, '四半期末月': z.month in (3, 6, 9, 12), '年末年始': (z.month == 12 and z.day >= 20) or (z.month == 1 and z.day <= 10),
              '決算発表期': (4, 20) <= (z.month, z.day) <= (5, 20) or (7, 20) <= (z.month, z.day) <= (8, 15) or (10, 20) <= (z.month, z.day) <= (11, 15) or (1, 20) <= (z.month, z.day) <= (2, 15),
              '配当権利前後': (z.month in (3, 9) and z in bd[-5:]) or (z.month in (4, 10) and z in bd[:3]), '米国夏時間': us_dst(z)}
FD = pd.DataFrame([FLG[z] for z in dts_]).astype(float)
for c_ in FD.columns: X[c_] = FD[c_].values
F = pd.DataFrame(X).astype('float32'); F.index = YM.index
F.to_pickle(O + 'YF.pkl')
na = F.isna().mean(); print(F.shape); print('NaN率 20%超', na[na > .2].round(2).to_dict())
pd.set_option('display.width', 250)
print(F[['寄りの窓', '8:45前のCFD値幅', '観察の効率比', '観察のR2', '観察の終わりの位置', '直近20日の寄り後の戻り率', '寄りの動きの連続(向き)', '入る値段の戻し(動き比)', '前日高安まで', 'SQ当日', '祝日取引中']].describe().round(3).to_string())
