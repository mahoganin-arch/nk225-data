# 指標の段階の対象トレードをまとめる（日中の寄りだけ）
#   逆張り：48候補（うち逆張り47件）の元になった入る形（E2_D）
#   順張り：E2_D の順張りすべて（36通り）＋ E_D の 8:45→9:00 順張り（0/+5/+15/+30/c25/c50）
#   出力：out/YM.pkl（1行＝1トレード、src・行番号つき）、out/YR.npy（float16、円、13pt控除後、506手じまい）
import numpy as np, pandas as pd
O = '/home/claude/yt/out/'
c2 = pd.read_pickle(O + 'cand2.pkl'); c2 = c2[c2.区分 == 'D']
c2 = c2[c2.向き == '逆張り']; REVK = set(zip(c2.観察, c2.入る))   # 48候補のうち逆張り47件の入る形（順張りの1件は順張り側に含まれる）
m2 = pd.read_pickle(O + 'E2_D_meta.pkl'); m2['src'] = 'E2'; m2['row'] = np.arange(len(m2))
m1 = pd.read_pickle(O + 'E_D_meta.pkl'); m1['src'] = 'E'; m1['row'] = np.arange(len(m1)); m1['tpk'] = np.nan; m1['ext'] = np.nan
k2 = list(zip(m2.観察, m2.入る))
s2 = np.array([(k in REVK) for k in k2]) & (m2.向き.values == '逆張り') | (m2.向き.values == '順張り')
s1 = (m1.向き.values == '順張り')
YM = pd.concat([m2[s2], m1[s1]], ignore_index=True)
YM['売買'] = np.where(YM.d > 0, '買い', '売り'); YM['sx'] = np.sign(YM.x).astype(int); YM['yr'] = YM.t.dt.year
R2 = np.load(O + 'E2_D_R.npy', mmap_mode='r'); R1 = np.load(O + 'E_D_R.npy', mmap_mode='r')
YR = np.vstack([np.asarray(R2[np.flatnonzero(s2)], np.float16), np.asarray(R1[np.flatnonzero(s1)], np.float16)])
YM.to_pickle(O + 'YM.pkl'); np.save(O + 'YR.npy', YR)
g = YM.groupby(['向き', '売買']).size(); print(len(YM), YR.shape); print(g.to_string())
print(YM.groupby('向き')[['観察', '入る']].apply(lambda z: len(z.drop_duplicates())).to_string())
