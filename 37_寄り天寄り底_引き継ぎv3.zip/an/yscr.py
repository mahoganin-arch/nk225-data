# ふるい：売りのみ・買いのみ × 逆張り・順張り（窓埋めの方向別 S16 にならう）
#   尺度：1トレードの「506手じまいの平均損益（円、13pt控除後）」。同じ向き・同じ売買・同じ入る形の条件なしとの差＝上乗せ
#   入る形（観察×入る）ごとに t と差を出し、その中央値をとる（60件以上の入る形、区分20件以上、有効な入る形6つ以上）
#   区分の境目は前半（2017〜21）のその売買の向きのデータで決める。1時間足の出来高（2022/12以降）だけは 2023年で決め、2024年以降でふるう
#   通過：後半（2022〜）の中央t の絶対値 ≥ 1（後半のみの指標は 2024年以降で ≥ 1.5）、後半の該当率 3%以上。前半の向きは参考
#   使い方：上乗せプラス→「入る」、マイナス→「避ける」（その区分以外で入る）
import numpy as np, pandas as pd
O = '/home/claude/yt/out/'
LATE = ('夜間最後1時間の出来高比', '出来高最多価格まで', '出来高最多価格をまたいだ', '出来高の多い価格帯の端まで')
YM = pd.read_pickle(O + 'YM.pkl'); F = pd.read_pickle(O + 'YF.pkl'); YR = np.load(O + 'YR.npy', mmap_mode='r')
MN = np.zeros(len(YM), np.float64)
for a in range(0, len(YM), 20000):
    MN[a:a + 20000] = np.nanmean(np.asarray(YR[a:a + 20000], np.float32), 1)
np.save(O + 'YMN.npy', MN)
yr = YM.yr.values; shp = (YM.観察 + '|' + YM.入る).values
def make_bins(F, sel):
    out = {}
    for c in F.columns:
        v = F[c].values.astype(float); fin = ~np.isnan(v); vt = v[sel & fin]; u = np.unique(vt)
        if len(vt) < 100: continue
        if len(u) <= 6:
            for x in u: out[(c, '=%g' % x)] = v == x
            continue
        q3 = np.quantile(vt, [1 / 3, 2 / 3]); b3 = np.searchsorted(q3, v, side='right')
        for i, lab in enumerate(['3分割:低', '3分割:中', '3分割:高']): out[(c, lab)] = fin & (b3 == i)
        q5 = np.quantile(vt, [.2, .4, .6, .8]); b5 = np.searchsorted(q5, v, side='right')
        for i in range(5): out[(c, '5分割:%d' % (i + 1))] = fin & (b5 == i)
        lo, hi = np.quantile(vt, [.1, .9]); out[(c, '下位10%')] = fin & (v <= lo); out[(c, '上位10%')] = fin & (v >= hi)
    return out
def uplift(Bm, base, period):
    T = []; D = []
    for g in np.unique(shp[base]):
        e = base & period & (shp == g)
        if e.sum() < 60: continue
        m = MN[e]; Be = Bm[:, e].astype(np.float64); nn = Be.sum(1); s_ = Be @ m; q = Be @ (m * m)
        mu = np.where(nn > 0, s_ / np.maximum(nn, 1), np.nan); var = np.where(nn > 1, (q - nn * mu ** 2) / np.maximum(nn - 1, 1), np.nan)
        with np.errstate(all='ignore'): t = (mu - m.mean()) / np.sqrt(var / np.maximum(nn, 1))
        d = mu - m.mean(); t[nn < 20] = np.nan; d[nn < 20] = np.nan; T.append(t); D.append(d)
    T = np.array(T); D = np.array(D); good = (~np.isnan(T)).sum(0) >= 6
    with np.errstate(all='ignore'): return np.where(good, np.nanmedian(T, 0), np.nan), np.where(good, np.nanmedian(D, 0), np.nan), (~np.isnan(T)).sum(0)
rows = []; BINS = {}
for side in ('逆張り', '順張り'):
    for bs in ('売り', '買い'):
        base = (YM.向き.values == side) & (YM.売買.values == bs)
        Fa = F.drop(columns=list(LATE)); Fl = F[list(LATE)]
        ba = make_bins(Fa, base & (yr <= 2021)); bl = make_bins(Fl, base & (yr == 2023))
        for bins, late in ((ba, False), (bl, True)):
            keys = list(bins); Bm = np.array([bins[k] for k in keys])
            if late: tA, dA, _ = uplift(Bm, base, yr == 2023); tB, dB, nB = uplift(Bm, base, yr >= 2024); cov = Bm[:, base & (yr >= 2024)].mean(1)
            else: tA, dA, _ = uplift(Bm, base, yr <= 2021); tB, dB, nB = uplift(Bm, base, yr >= 2022); cov = Bm[:, base & (yr >= 2022)].mean(1)
            for i, k in enumerate(keys):
                rows.append(dict(向き=side, 売買=bs, 指標=k[0], 区分=k[1], 後半のみ=late, 該当率=cov[i], 前半t=tA[i], 前半上乗せ=dA[i], 後半t=tB[i], 後半上乗せ=dB[i], 有効な入る形=nB[i]))
            BINS[(side, bs, late)] = (keys, np.packbits(Bm, axis=1), Bm.shape[1])
        print(side, bs, len(rows), flush=True)
S = pd.DataFrame(rows)
S['通過'] = np.where(S.後半のみ, S.後半t.abs() >= 1.5, S.後半t.abs() >= 1.0) & (S.該当率 >= .03)
S['使い方'] = np.where(S.後半上乗せ > 0, '入る', '避ける'); S['前半も同じ向き'] = np.sign(S.前半上乗せ) == np.sign(S.後半上乗せ)
S.to_pickle(O + 'YS.pkl'); pd.to_pickle(BINS, O + 'YBINS.pkl')
print(S.groupby(['向き', '売買'])['通過'].agg(['sum', 'size']).to_string())
print(S[S.通過].groupby(['向き', '売買', '使い方']).size().to_string())
pd.set_option('display.width', 250)
for (a, b), g in S[S.通過].groupby(['向き', '売買']):
    print(a, b); print(g.sort_values('後半t', key=abs, ascending=False).head(12)[['指標', '区分', '使い方', '該当率', '前半t', '前半上乗せ', '後半t', '後半上乗せ']].round(2).to_string(index=False))
