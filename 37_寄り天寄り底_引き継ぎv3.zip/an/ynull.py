# 偶然の目安（参考）：日ごとにランダムに選んだ条件（該当率 10〜90%）を同じ評価にかけ、残る割合と「条件なしより良い」割合を見る
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/an')
from yeval import YM, scs, select, rows_from, O
rng = np.random.default_rng(7); days = YM.sid.values; ud = np.unique(days); out = []
COV = [.1, .2, .33, .5, .67, .8, .9]
for side in ('逆張り', '順張り'):
    for bs in ('売り', '買い'):
        base = (YM.向き.values == side) & (YM.売買.values == bs); conds = []
        for c in COV:
            for j in range(8):
                pick = set(ud[rng.random(len(ud)) < c]); conds.append((c, j, np.isin(days, list(pick))))
        Mall = np.array([z[2] for z in conds])
        for (ob, en), ii in YM[base].groupby(['観察', '入る']).indices.items():
            idx = np.flatnonzero(base)[ii]; S, C, NG = scs(idx, Mall[:, idx])
            out += rows_from(select(S, C, NG), S, C, [dict(向き=side, 売買=bs, 該当率=z[0], 試行=z[1], 観察=ob, 入る=en) for z in conds])
        print(side, bs, flush=True)
N = pd.DataFrame(out); N.to_pickle(O + 'YNULL.pkl')
