# 重なりでまとめる（窓埋めの S9・S21 と同じ考え方）
#   候補＝(向き, 売買, 指標, 区分, 使い方, 観察, 入る)。単点・周辺のどちらかで残ったもの。方向だけの条件なしはまとめの対象外（候補としては残す）
#   似かた：2022年以降に「入る日（セッション）」の集合の Ochiai（共通 ÷ √(Aの数×Bの数)）。「避ける」は外す日の集合どうしで比べる
#   まとめ方：向き×売買×入る/避けるごとに平均連結、区切り 0.5（感度 0.4・0.6）
#   代表：①単点・周辺の両方で残った ②5つの形の最悪が高い ③年件数 の順。入る形（観察×入る）が違う「2番目」も印を付ける。メンバーは候補から外さない
import sys, numpy as np, pandas as pd
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.spatial.distance import squareform
sys.path.insert(0, '/home/claude/yt/an')
O = '/home/claude/yt/out/'
YM = pd.read_pickle(O + 'YM.pkl'); T = pd.read_pickle(O + 'YE2.pkl'); BINS = pd.read_pickle(O + 'YBINS.pkl'); S0 = pd.read_pickle(O + 'YS.pkl')
T['残す'] = (T.プラスの数 >= 3) & (T.中央 >= 20) & (T.年件数_中央 >= 10)
FORMS = ['前半→後半_平均', '22-23→24-26_平均', 'WF後半_平均', 'WF全期間_平均', 'WF直近3年_平均']
T['最悪'] = T[FORMS].min(1)
U = ['向き', '売買', '指標', '区分', '使い方', '観察', '入る']
K = T[T.残す].groupby(U).agg(選び方数=('選び方', 'size'), 選び方=('選び方', lambda z: '・'.join(sorted(z))), 最悪=('最悪', 'max'), 年件数=('年件数_中央', 'max'), 中央=('中央', 'max')).reset_index()
K['id'] = np.arange(len(K))
LATE = set(S0[S0.後半のみ].指標)
def binmask(side, bs, ind, kub):
    keys, packed, nn = BINS[(side, bs, ind in LATE)]; i = keys.index((ind, kub)); return np.unpackbits(packed[i])[:nn].astype(bool)
GI = YM.groupby(['向き', '売買', '観察', '入る']).indices; sid = YM.sid.values; late = YM.yr.values >= 2022
SETS = {}
for r in K.itertuples():
    idx = GI[(r.向き, r.売買, r.観察, r.入る)]; idx = idx[late[idx]]
    if r.指標 == 'なし': SETS[r.id] = set(sid[idx]); continue
    b = binmask(r.向き, r.売買, r.指標, r.区分)[idx]
    SETS[r.id] = set(sid[idx][b])          # 入る：入る日／避ける：外す日（どちらも区分に当たる日）
K['日数'] = K.id.map(lambda i: len(SETS[i]))
for thr in (.4, .5, .6): K['g%g' % thr] = -1
for (side, bs, use), sub in K[K.指標 != 'なし'].groupby(['向き', '売買', '使い方']):
    ids = sub.id.values; days = np.array(sorted(set().union(*[SETS[i] for i in ids]))); pos = {d: j for j, d in enumerate(days)}
    X = np.zeros((len(ids), len(days)), np.float32)
    for a, i in enumerate(ids): X[a, [pos[d] for d in SETS[i]]] = 1
    inter = X @ X.T; nrm = np.sqrt(np.outer(X.sum(1), X.sum(1))); Sm = np.where(nrm > 0, inter / np.maximum(nrm, 1e-9), 0); np.fill_diagonal(Sm, 1)
    Z = linkage(squareform(1 - Sm, checks=False), 'average')
    for thr in (.4, .5, .6): K.loc[sub.index, 'g%g' % thr] = fcluster(Z, 1 - thr, 'distance') + {('逆張り', '売り'): 0, ('逆張り', '買い'): 1, ('順張り', '売り'): 2, ('順張り', '買い'): 3}[(side, bs)] * 100000 + (use == '避ける') * 50000
    print(side, bs, use, len(ids), '→ グループ', len(set(K.loc[sub.index, 'g0.5'])), '(0.4:', len(set(K.loc[sub.index, 'g0.4'])), ' 0.6:', len(set(K.loc[sub.index, 'g0.6'])), ')', flush=True)
# 代表
K['代表'] = False; K['2番目'] = False
K.loc[K.指標 == 'なし', '代表'] = True
for g, sub in K[K.指標 != 'なし'].groupby('g0.5'):
    s = sub.sort_values(['選び方数', '最悪', '年件数'], ascending=False); r1 = s.index[0]; K.loc[r1, '代表'] = True
    oth = s[(s.観察 + s.入る) != (s.loc[r1, '観察'] + s.loc[r1, '入る'])]
    if len(oth): K.loc[oth.index[0], '2番目'] = True
# 感度：0.4 で合わさる／0.6 で分かれる
K['安定'] = np.where(K.groupby('g0.5')['g0.6'].transform('nunique') > 1, '0.6で分かれる', np.where(K.groupby('g0.4')['g0.5'].transform('nunique') > 1, '0.4で合わさる', '安定'))
K.loc[K.指標 == 'なし', '安定'] = ''
K['グループの大きさ'] = K.groupby('g0.5').id.transform('size'); K.loc[K.指標 == 'なし', 'グループの大きさ'] = 1
K.to_pickle(O + 'YG.pkl'); pd.to_pickle(SETS, O + 'YGSETS.pkl')
print('候補', len(K), '代表', K.代表.sum(), '2番目', K['2番目'].sum())
print(K[K.代表].groupby(['向き', '売買', '使い方']).size().to_string())
print(K[K.指標 != 'なし'].drop_duplicates('g0.5').安定.value_counts().to_string())
