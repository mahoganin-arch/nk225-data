# 残った候補の詳しい成績：前向き（WF全期間の各年のルール）と今のルール（2017〜25年で選択）の全期間
#   件数・勝率・PF・平均・最大DD・最悪の1回、コスト20ptでの平均。似た候補はトレードの重なり（Ochiai）でまとめる
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/home/claude/yt/an')
from evalu import YEARS, QS, FORMS, O, neighbors
QN=['全部','上位50%','上位33%','上位20%','上位10%']
def trades(fam, tag, ob, dn, en, k_by_year):
    """k_by_year: {年: 設定番号}。その年のトレード（円）と sid・時刻"""
    meta=pd.read_pickle(O+f'{tag}_{fam}_meta.pkl'); R=np.load(O+f'{tag}_{fam}_R.npy',mmap_mode='r')
    EXd=pd.read_pickle(O+'EXITS.pkl')['D' if fam in ('D','K') else 'N']; nE=len(EXd)
    u=meta[meta.観察==ob].drop_duplicates('sid'); a=np.abs(u.x.values)[u.t.dt.year.values<=2021]
    cuts=[np.quantile(a,q) if q>0 else 0 for q in QS]
    g=meta[(meta.観察==ob)&(meta.向き==dn)&(meta.入る==en)]
    out=[]
    for y,k in k_by_year.items():
        qi,ei=divmod(k,nE); gg=g[(g.t.dt.year==y)&(np.abs(g.x)>=cuts[qi])]
        v=np.asarray(R[gg.index.values,ei],dtype=np.float32)
        out.append(pd.DataFrame(dict(sid=gg.sid.values,t=gg.t.values,te=gg.te.values,v=v,price=gg.mv.values/np.abs(gg.x.values),d=gg.d.values,tpk=gg.tpk.values)))
    d=pd.concat(out).dropna(subset=['v']).sort_values('te'); return d
def stats(d):
    v=d.v.values
    if len(v)==0: return {}
    eq=np.cumsum(v); dd=(np.maximum.accumulate(np.r_[0,eq])[1:]-eq).max()
    gp=v[v>0].sum(); gl=-v[v<0].sum()
    # 20pt：差 7pt 分を価格で換算
    v20=v-7/d.price.values*68800
    return dict(件数=len(v),勝率=(v>0).mean()*100,PF=gp/gl if gl>0 else np.inf,平均=v.mean(),合計=v.sum(),最大DD=dd,最悪=v.min(),平均_20pt=v20.mean())
if __name__=='__main__':
    import os
    EV=pd.concat([pd.read_pickle(O+f) for f in ['EV2_D.pkl','EV2_NC.pkl'] if os.path.exists(O+f)])
    EV['tag']='E2'
    EV=EV[(EV.プラスの数>=3)&(EV.中央>=20)&(EV.年件数_中央>=10)].reset_index(drop=True)
    rows=[]; sets={}
    for i,r in EV.iterrows():
        st=pd.read_pickle(O+f'E2_{r.区分}_store.pkl')[(r.観察,r.向き,r.入る)]
        S,C,M=st; EXd=pd.read_pickle(O+'EXITS.pkl')['D' if r.区分=='D' else 'N']; NB=neighbors(EXd) if r.選び方=='周辺' else None
        yi={y:k for k,y in enumerate(YEARS)}
        def pick(tr):
            a=[yi[y] for y in tr]; sm=S[:,a].sum(1); cn=C[:,a].sum(1); mn=M[:,a].min(1)
            mean=np.where(cn>0,sm/np.maximum(cn,1),np.nan); ok=(cn>=15)&(mn>=-1000)
            sc=mean if NB is None else np.array([np.nanmean(mean[nb]) for nb in NB])
            return int(np.argmax(np.nan_to_num(np.where(ok,sc,-np.inf),nan=-np.inf)))
        fw={y:pick(range(2017,y)) for y in range(2022,2027)}
        now=pick(range(2017,2026))
        dF=trades(r.区分,'E2',r.観察,r.向き,r.入る,fw); dN=trades(r.区分,'E2',r.観察,r.向き,r.入る,{y:now for y in range(2017,2027)})
        row=dict(id=i,区分=r.区分,観察=r.観察,向き=r.向き,入る=r.入る,選び方=r.選び方,プラスの数=r.プラスの数,中央=r.中央,年件数=r.年件数_中央,今の強さ=r.今の強さ,今の手じまい=r.今の手じまい)
        row.update({'前向き_'+k:v for k,v in stats(dF).items()})
        row.update({'今_'+k:v for k,v in stats(dN).items()})
        for y in range(2017,2027):
            dy=dN[pd.to_datetime(dN.t).dt.year==y]; row[f'今{y}']=dy.v.sum()
        rows.append(row); sets[i]=set(dN[pd.to_datetime(dN.t).dt.year>=2022].sid)
    X=pd.DataFrame(rows)
    # 重なりでまとめる（Ochiai≥0.5 をつなぐ）
    ids=list(sets); grp={i:i for i in ids}
    def f(i):
        while grp[i]!=i: i=grp[i]
        return i
    for a in ids:
        for b in ids:
            if a<b and X.loc[a,'区分']==X.loc[b,'区分'] and X.loc[a,'向き']==X.loc[b,'向き']:
                A,B=sets[a],sets[b]
                if A and B and len(A&B)/np.sqrt(len(A)*len(B))>=0.5: grp[f(b)]=f(a)
    X['グループ']=[f(i) for i in ids]
    X=X.sort_values(['区分','前向き_合計'],ascending=[True,False]); X.to_pickle(O+'cand2.pkl')
    pd.set_option('display.width',300); pd.set_option('display.max_rows',200)
    c=['id','グループ','区分','観察','向き','入る','選び方','中央','前向き_件数','前向き_勝率','前向き_PF','前向き_合計','前向き_最大DD','今_PF','今_最大DD','今_最悪','今_平均_20pt']
    print(X[c].round(1).to_string())
    print('グループ数', X.groupby('区分').グループ.nunique().to_dict())
