# yref（独立版）と分析のエンジン（xeng の XR）の照合：2021/1〜2026/10/8、3本のルール（口座の決まりの前の、1本ずつの損益）
import sys, numpy as np, pandas as pd, pickle
sys.path.insert(0, '/home/claude/yt/chk'); import yref
O = '/home/claude/yt/out/'; X = '/home/claude/yt/outx/'
c1 = pd.read_pickle(O + 'c1.pkl'); c5 = pd.read_pickle(O + 'c5.pkl'); f5 = pd.read_pickle(O + 'f5.pkl')
c1 = c1[c1.m >= c1.m.iloc[0] + 1440]
T = yref.run(c1, c5, f5, '2021-01-01', '2026-10-09')
M = pd.read_pickle(X + 'XM.pkl'); R = np.load(X + 'XR.npy', mmap_mode='r'); d = pickle.load(open(X + 'xpick.pkl', 'rb')); SH = d['SH']
import xeval as xv
QL = xv.QL; NE = xv.NE
rows = []
for nm, c in (('①', 8), ('②', 24), ('③', 35)):
    ob, en = SH.loc[c, '観察'], SH.loc[c, '入る']; q, e = divmod(int(SH.loc[c, 'k2027']), NE)
    w = np.flatnonzero((M.観察.values == ob) & (M.入る.values == en) & (QL >= q) & (M.t.dt.year.values >= 2021))
    A = pd.DataFrame(dict(te=M.te.values[w].astype(int), 分析=np.asarray(R[w, e], np.float32))); A['te'] = [yref.te_ts(x) for x in A.te]
    B = T[T.ルール == nm][['入る時刻', '損益']].rename(columns={'入る時刻': 'te', '損益': '独立版'})
    J = A.merge(B, on='te', how='outer'); J['ルール'] = nm; rows.append(J)
J = pd.concat(rows); J['差'] = (J.分析 - J.独立版).abs()
print(J.groupby('ルール').agg(分析の件数=('分析', 'count'), 独立版の件数=('独立版', 'count'), 両方=('差', 'count'), 最大の差=('差', 'max'), 差1円超=('差', lambda z: (z > 1).sum())).to_string())
print(J[J.差.isna() | (J.差 > 1)].head(20).to_string())
