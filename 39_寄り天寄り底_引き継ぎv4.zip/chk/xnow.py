# 9:00・9:05 の観察に絞った比較と、これから使うルール（2027＝2017〜2026/10/8 で選ぶ）
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/chk')
import xeval2 as x2
from xeval import M, EXD, NE, TE, BND, prefix_stats
T = pd.read_pickle(x2.X + 'xeval2.pkl')
OLD = ['0', '+5', 'c25', 'c50', 'pkK25', 'pkK50', 'pkP10', 'pkP20', 'HA1', 'HA5', '前足1', '前足5', 'RSI1', 'RSI5']; OLD = OLD + [c + 'n' for c in OLD[4:]]
T['入る形の種類'] = np.where(T.入る.isin(OLD), '元からある', '新しい'); T['観察の範囲'] = np.where(T.観察.isin(['8:45→9:00', '8:45→9:05']), '9:00・9:05', '9:10〜9:30')
SUMM = T.groupby(['観察の範囲', '入る形の種類', '格子', '指標', '選び方']).agg(形の数=('合計', 'size'), 合計プラスの割合=('合計', lambda z: (z > 0).mean()), 合計_中央=('合計', 'median'),
        PF_中央=('PF', lambda z: z.clip(upper=5).median()), RF_中央=('RF', lambda z: z.clip(upper=20).median()), **{f'{y}_中央': (str(y), 'median') for y in range(2019, 2027)}).reset_index()
QN = ['全部', '上位50%', '上位33%', '上位20%', '上位15%', '上位10%', '上位5%']
G = M.groupby(['観察', '入る']).indices; NOW = []
for (ob, en), idx in G.items():
    if ob not in ('8:45→9:00', '8:45→9:05'): continue
    idx = idx[np.argsort(TE[idx], kind='stable')]; st, P = prefix_stats(idx); t0 = TE[idx[0]]
    for gname, allow in x2.ALLOW.items():
        res = x2.choose2(st[2027], (BND[2027] - t0) / (365.25 * 1440), allow)
        k = res[('平均', '単点')]
        if k < 0: continue
        q, e = divmod(k, NE); r = EXD.iloc[e]
        NOW.append(dict(観察=ob, 入る=en, 格子=gname, 今の強さ=QN[q], 手じまい群=r.群, 利確=f'{r.利確型}:{r.利確}', 損切り=f'{r.損切り型}:{r.損切り}', 時間=r.時間))
NOW = pd.DataFrame(NOW).merge(T[(T.指標 == '平均') & (T.選び方 == '単点')], on=['観察', '入る', '格子'])
pickle.dump(dict(SUMM=SUMM, NOW=NOW, T=T), open(x2.X + 'xnow.pkl', 'wb'))
pd.set_option('display.width', 250)
s = SUMM[(SUMM.指標 == '平均') & (SUMM.選び方 == '単点')]
print(s[['観察の範囲', '入る形の種類', '格子', '形の数', '合計プラスの割合', '合計_中央', 'PF_中央', 'RF_中央']].round(2).to_string(index=False))
n = NOW[NOW.格子 == '全部の格子'].sort_values('合計', ascending=False)
print(n[['観察', '入る', '今の強さ', '手じまい群', '利確', '損切り', '時間', '件数', '合計', 'PF', 'RF', '最大DD']].head(20).round(2).to_string(index=False))
print('手じまいの群（全部の格子、9:00・9:05 の形）', NOW[NOW.格子 == '全部の格子'].手じまい群.value_counts().to_dict(), NOW[NOW.格子 == '全部の格子'].損切り.value_counts().head(5).to_dict())
