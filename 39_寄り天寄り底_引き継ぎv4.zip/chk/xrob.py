# (c) 今の手じまいの頑丈さ（ルールを固定して周りを動かす。2019〜2026 と 2021〜2026）
#   ② 9:05・+5：強さ7段 × 損切り（なし、0.4〜1.5%）× 時間（60〜330分、引け）の細かい格子（入る形 0・+10 も参考に）
#   ①③：拡張エンジンの格子で、RSI の手じまい（1・5・15分 × 30・40）× 損切り（なし・0.3・0.5・0.8%・高値+0.1%）× 時間（120・前場引け・引け）× 強さ
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/chk')
from xeng import PM, PO, PH, PL
import xeval as xv
X = '/home/claude/yt/outx/'; M = xv.M; R = xv.R; QL = xv.QL; NE = xv.NE; EXD = xv.EXD; QN = ['全部', '上位50%', '上位33%', '上位20%', '上位15%', '上位10%', '上位5%']
YR = M.t.dt.year.values
def st(v):
    v = np.asarray(v, float); v = v[~np.isnan(v)]
    if len(v) == 0: return dict(件数=0, 合計=0.0, PF=np.nan, RF=np.nan, 最大DD=0.0)
    eq = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, eq])[1:] - eq).max(); gl = -v[v < 0].sum()
    return dict(件数=len(v), 合計=v.sum(), PF=v[v > 0].sum() / gl if gl > 0 else np.inf, RF=v.sum() / dd if dd > 0 else np.inf, 最大DD=dd, 平均=v.mean())
SLS = [np.inf] + [round(x, 1) for x in np.arange(0.4, 1.55, 0.1)]; TMS = list(range(60, 331, 30)) + ['C']
def fine(ob, en):
    idx = np.flatnonzero((M.観察.values == ob) & (M.入る.values == en)); idx = idx[np.argsort(M.te.values[idx])]
    out = np.full((len(idx), len(SLS), len(TMS)), np.nan, np.float32)
    for n_, i in enumerate(idx):
        r = M.iloc[i]; te = int(r.te); j0 = np.searchsorted(PM, te); jc = np.searchsorted(PM, r.tcap)
        if j0 >= len(PM) or PM[j0] - te >= 5 or jc <= j0: continue
        e = PO[j0]; mm = PM[j0:jc]; hi = PH[j0:jc]; op = PO[j0:jc + 1]; n = len(mm)
        adv = np.maximum.accumulate(hi - e)
        TI = np.array([min(np.searchsorted(mm, mm[0] + t), n) if t != 'C' else n for t in TMS])
        SI = np.array([np.searchsorted(adv, s / 100 * e) if np.isfinite(s) else n for s in SLS])
        for a, s in enumerate(SLS):
            k = SI[a]
            for b, ti in enumerate(TI):
                xp = max(op[k], e * (1 + s / 100)) if k < ti and k < n else op[min(ti, n)]
                out[n_, a, b] = (e - xp) / e * 68800 - 13
    return idx, out
RES = {}
for en in ('+5', '0', '+10'):
    idx, out = fine('8:45→9:05', en); ql = QL[idx]; yr = YR[idx]; rows = []
    for q in range(7):
        for a, s in enumerate(SLS):
            for b, t in enumerate(TMS):
                v = out[:, a, b]; m19 = (ql >= q) & (yr >= 2019); m21 = (ql >= q) & (yr >= 2021)
                s19 = st(v[m19]); s21 = st(v[m21])
                yrs = {str(y): np.nansum(v[(ql >= q) & (yr == y)]) for y in range(2019, 2027)}
                rows.append(dict(入る=en, 強さ=QN[q], 損切り='なし' if not np.isfinite(s) else f'{s}%', 時間=str(t), **{'19_' + k: x for k, x in s19.items()}, **{'21_' + k: x for k, x in s21.items()},
                                 プラスの年=sum(x > 0 for x in yrs.values()), **yrs))
    RES[en] = pd.DataFrame(rows)
# ①③：拡張エンジンの格子
def grid13(ob, en):
    idx = np.flatnonzero((M.観察.values == ob) & (M.入る.values == en)); ql = QL[idx]; yr = YR[idx]; rows = []
    sel = EXD[(EXD.群 == '指標') & (EXD.利確型 == '指標:RSI')]
    Rv = np.asarray(R[idx][:, sel.index.values], np.float32)
    for q in range(7):
        for j, (ei, ex) in enumerate(sel.iterrows()):
            v = Rv[:, j]; s19 = st(v[(ql >= q) & (yr >= 2019)]); s21 = st(v[(ql >= q) & (yr >= 2021)])
            yrs = {str(y): np.nansum(v[(ql >= q) & (yr == y)]) for y in range(2019, 2027)}
            rows.append(dict(強さ=QN[q], 利確=ex.利確, 損切り=f'{ex.損切り型}:{ex.損切り}', 時間=ex.時間, **{'19_' + k: x for k, x in s19.items()}, **{'21_' + k: x for k, x in s21.items()}, プラスの年=sum(x > 0 for x in yrs.values()), **yrs))
    return pd.DataFrame(rows)
RES['①'] = grid13('8:45→9:00', 'RSI5'); RES['③'] = grid13('8:45→9:05', 'c50')
pickle.dump(RES, open(X + 'xrob.pkl', 'wb'))
pd.set_option('display.width', 250)
D = RES['+5']
for q in ('上位20%', '上位15%', '上位10%', '上位5%'):
    print('== ② 9:05・+5', q, '合計（2019〜2026）'); print(D[D.強さ == q].pivot(index='損切り', columns='時間', values='19_合計').reindex(index=['なし'] + [f'{s}%' for s in SLS[1:]], columns=[str(t) for t in TMS]).round(-2).astype(int).to_string())
print('== ② 上位10% PF'); print(D[D.強さ == '上位10%'].pivot(index='損切り', columns='時間', values='19_PF').reindex(index=['なし'] + [f'{s}%' for s in SLS[1:]], columns=[str(t) for t in TMS]).round(2).to_string())
print('== ② 上位10% プラスの年（8年中）'); print(D[D.強さ == '上位10%'].pivot(index='損切り', columns='時間', values='プラスの年').reindex(index=['なし'] + [f'{s}%' for s in SLS[1:]], columns=[str(t) for t in TMS]).to_string())
for en in ('0', '+10'):
    d = RES[en]; print(f'== 9:05・{en} 上位10% 合計'); print(d[d.強さ == '上位10%'].pivot(index='損切り', columns='時間', values='19_合計').reindex(index=['なし'] + [f'{s}%' for s in SLS[1:]], columns=[str(t) for t in TMS]).round(-2).astype(int).to_string())
for k in ('①', '③'):
    d = RES[k]
    for q in ('上位10%', '上位5%'):
        p = d[(d.強さ == q)].pivot_table(index=['利確'], columns=['損切り', '時間'], values='19_合計').round(-2)
        print(f'== {k} {q} 合計'); print(p.to_string())
