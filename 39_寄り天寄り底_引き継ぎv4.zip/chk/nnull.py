# 公平な偶然の目安：本物の条件（区分）を、同じ該当率で「日ごとに続きやすい」でたらめな条件に置き換え、
#   ふるい → 評価・残す → 重なり → 案3 → 運用（全部・上位5本・同じ向き2本）まで、元とまったく同じ手順を通す
#   でたらめな条件：セッションの並びで AR(1)（係数0.9）の潜在値を作り、該当率の分位で切る（指標の続きやすさを真似る）
#   python3 nnull.py <seed>
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/chk')
import nest
seed = int(sys.argv[1]); rng = np.random.default_rng(seed)
ud, inv = np.unique(nest.SID, return_inverse=True); ns = len(ud)
def shuffle(Bm):
    K = Bm.shape[0]; cov = Bm.mean(1)
    z = np.zeros((K, ns), np.float32); e = rng.standard_normal((K, ns)).astype(np.float32); z[:, 0] = e[:, 0]
    for j in range(1, ns): z[:, j] = .9 * z[:, j - 1] + np.sqrt(1 - .81) * e[:, j]
    thr = np.array([np.quantile(z[i], 1 - c) for i, c in enumerate(cov)])
    S = z >= thr[:, None]
    return S[:, inv]
REV = set(zip(*[pd.read_pickle(nest.O + 'YM.pkl').query("向き=='逆張り'")[c] for c in ('観察', '入る')]))
Cd, FT, rs = nest.pipeline(2027, rev_shapes=REV, shuffle=shuffle)
pickle.dump((Cd, FT), open(nest.N + f'null_{seed}.pkl', 'wb'))
print('候補', len(Cd), (Cd.指標 != 'なし').sum())
for pn in ('全部', '売りのみ', '買いのみ'):
    Hs = []
    for t in (2024, 2025, 2026):
        H = nest.simulate(FT, t, nest.choose(Cd, FT, t, 5, nest.POOLS[pn]), 'C1'); H['年'] = t; Hs.append(H)
    H = pd.concat(Hs); print(pn, nest.summ(H), {t: round(H[H.年 == t].損益.sum(), 1) for t in (2024, 2025, 2026)}, flush=True)
