# 本当の前向き：各年 t は、t 年より前のデータだけで選んだ候補の集まり（nest_t.pkl）から案3で選び、t 年を売買
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/chk'); import nest
SUF = nest.SUF
V = pickle.load(open(nest.N + f'nest_2027v{SUF}.pkl', 'rb'))
NS = {t: pickle.load(open(nest.N + f'nest_{t}{SUF}.pkl', 'rb')) for t in (2024, 2025, 2026)}
rows = []; HH = []
POOLS2 = dict(nest.POOLS)
for pn in ('全部', '売りのみ', '買いのみ', '条件なし・全部', '条件なし・売りのみ', '条件なし・買いのみ'):
    for Nn in (3, 5):
        for pol in ('A1', 'C1', 'D1'):
            for lab in ('元の手順', '本当の前向き'):
                tot = {}; Hs = []
                for t in (2024, 2025, 2026):
                    Cd, FT = (V[0], V[1]) if lab == '元の手順' else (NS[t][0], NS[t][1])
                    Cx = Cd[Cd.指標 == 'なし'] if pn.startswith('条件なし') else Cd
                    sel = nest.choose(Cx, FT, t, Nn, nest.POOLS[pn.split('・')[-1]]); H = nest.simulate(FT, t, sel, pol); H['年'] = t; Hs.append(H)
                    tot[t] = H.損益.sum(); tot['本数%d' % t] = int((sel.扱い == '').sum()) if len(sel) else 0
                H = pd.concat(Hs); s = nest.summ(H)
                rows.append(dict(集まり=pn, N=Nn, 方針=pol, 手順=lab, 件数=s['件数'], 合計=s['合計'], 最大DD=s['最大DD'], **{str(k): v for k, v in tot.items()}))
                if pn == '全部' and Nn == 5 and pol == 'C1': H['手順'] = lab; HH.append(H)
R = pd.DataFrame(rows); R.to_pickle(nest.N + f'neval{SUF}.pkl'); pd.concat(HH).to_pickle(nest.N + f'neval_H{SUF}.pkl')
pd.set_option('display.width', 250)
print(R.round(0).to_string(index=False))
