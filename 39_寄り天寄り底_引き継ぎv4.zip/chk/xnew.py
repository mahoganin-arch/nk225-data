# (a) 種類の違う手じまいを足す（9時台 48形のトレードだけ）
#   利確の新しい種類（売り）：
#     MA25_5 / MA25_15 ：5分・15分の25本移動平均（直前に確定した足の値）まで下がったら、その値段で利確（入った値段がすでに下なら利確なし）
#     MH_5 / MH_15     ：5分・15分のMACDヒストがマイナスの中で下げ止まった（前の足より大きくなった）足の終わり → 次の足の始値
#     ST_5 / ST_15     ：5分・15分のストキャス（%K14・%D3）で、%D が30未満から %K が %D を上に抜けた足の終わり → 次の足の始値
#   × 損切り（なし・0.8%・1.2%）× 時間（240分・引け）＝ 36通り
#   出力：outx/XN_rows.npy（XM の行番号）、outx/XN_R.npy、outx/XN_EXITS.pkl
import sys, numpy as np, pandas as pd
from multiprocessing import Pool
sys.path.insert(0, '/home/claude/yt/chk')
import xeng
from xeng import PM, PO, PH, PL, IND, INF
X = '/home/claude/yt/outx/'
OLD = ['0', '+5', 'c25', 'c50', 'pkK25', 'pkK50', 'pkP10', 'pkP20', 'HA1', 'HA5', '前足1', '前足5', 'RSI1', 'RSI5']; OLD = OLD + [c + 'n' for c in OLD[4:]]
for tf in (5, 15):
    I = IND[tf]; c = pd.Series(I['close'])
    I['ma25'] = c.rolling(25).mean().values
    macd = c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean(); I['mh'] = (macd - macd.ewm(span=9, adjust=False).mean()).values
    lo = pd.Series(I['low']).rolling(14).min(); hi = pd.Series(I['high']).rolling(14).max(); K = ((c - lo) / (hi - lo).replace(0, np.nan) * 100); I['K'] = K.values; I['D'] = K.rolling(3).mean().values
TPN = [('MA25', 5), ('MA25', 15), ('MH', 5), ('MH', 15), ('ST', 5), ('ST', 15)]; SLN = [INF, 0.8, 1.2]; TMN = [240, 'C']
EXN = pd.DataFrame([dict(群='新しい指標', 利確型=f'{a}_{b}', 利確=f'{a}{b}分', 損切り型='なし' if not np.isfinite(s) else '%', 損切り=str(s), 時間=str(t), ia=i, ib=j, ic=k)
                    for i, (a, b) in enumerate(TPN) for j, s in enumerate(SLN) for k, t in enumerate(TMN)])
def sig(kind, tf, te, tcap, e):
    I = IND[tf]; m = I['m']; k0 = max(np.searchsorted(m, te), 1); k1 = np.searchsorted(m, tcap)
    if kind == 'MA25':
        for k in range(k0, k1):
            lv = I['ma25'][k - 1]
            if not np.isfinite(lv) or lv >= e: continue
            if I['low'][k] <= lv: return m[k], min(I['open'][k], lv)
        return INF, None
    if kind == 'MH':
        h = I['mh']
        for k in range(k0, k1):
            if h[k - 1] < 0 and h[k] > h[k - 1]: return I['end'][k], None
        return INF, None
    K = I['K']; D = I['D']
    for k in range(k0, k1):
        if np.isfinite(D[k - 1]) and D[k - 1] < 30 and K[k - 1] <= D[k - 1] and K[k] > D[k]: return I['end'][k], None
    return INF, None
def sim_new(args):
    te, fill, tcap = args; out = np.full(len(EXN), np.nan, np.float32)
    j0 = np.searchsorted(PM, te)
    if j0 >= len(PM) or PM[j0] - te >= 5 or te >= tcap: return out
    e = fill if fill is not None else PO[j0]; jc = np.searchsorted(PM, tcap)
    if jc <= j0: return out
    hi = PH[j0:jc]; op = PO[j0:jc + 1] if jc < len(PO) else np.r_[PO[j0:jc], PO[-1]]; mm = PM[j0:jc]; n = len(mm)
    adv = np.maximum.accumulate(hi - e); p = 0
    for (kind, tf) in TPN:
        ts, tp_ = sig(kind, tf, te, tcap, e)
        for s in SLN:
            si = np.searchsorted(adv, s / 100 * e) if np.isfinite(s) else n; slt = mm[si] if si < n else INF
            for t in TMN:
                tl = n if t == 'C' else min(np.searchsorted(mm, mm[0] + t), n); tlt = mm[tl] if tl < n else tcap
                tmin, kd = min([(slt, 0), (ts, 1), (tlt, 2)], key=lambda z: (z[0], z[1]))
                if kd == 0: xp = max(op[si], e * (1 + s / 100))
                elif kd == 1: xp = tp_ if tp_ is not None else op[min(np.searchsorted(mm, ts), n)]
                else: xp = op[min(tl, n)]
                out[p] = (e - xp) / e * 68800 - 13; p += 1
    return out
if __name__ == '__main__':
    M = pd.read_pickle(X + 'XM.pkl')
    rows = np.flatnonzero(M.観察.isin(['8:45→9:00', '8:45→9:05']).values & M.入る.isin(OLD).values)
    args = [(int(M.te.values[i]), None if (M.fill.values[i] is None or (isinstance(M.fill.values[i], float) and np.isnan(M.fill.values[i]))) else float(M.fill.values[i]), M.tcap.values[i]) for i in rows]
    with Pool(2) as pl: RN = np.vstack(pl.map(sim_new, args, chunksize=300))
    np.save(X + 'XN_rows.npy', rows); np.save(X + 'XN_R.npy', RN.astype(np.float16)); EXN.to_pickle(X + 'XN_EXITS.pkl')
    print(len(rows), RN.shape, np.isnan(RN).mean().round(3))
