# 拡張エンジンの本当の前向きのまとめ
#   ① 形×選び方ごとの前向き成績（2019〜2026、2021〜2026）
#   ② 今の中心の形（条件なし・9:05・0・周辺、元のエンジン）と比べる
#   ③ 2段目も前向きで：各年 t の初めに、t より前の前向き記録（2019〜t−1）が良い形を選び、t 年を口座で動かす（2021〜2026）
#   ④ これから記録する候補：③と同じ手順を 2027 年に当てる（2019〜2026/10/8 の前向き記録で選ぶ。ルールは k2027）
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/chk'); import xeng
X = '/home/claude/yt/outx/'; N = '/home/claude/yt/outn/'
M = pd.read_pickle(X + 'XM.pkl'); C = pd.read_pickle(X + 'XC.pkl'); FT = pd.read_pickle(X + 'XFT.pkl'); EXD = pd.read_pickle(X + 'XEXITS.pkl'); NE = len(EXD)
QN = ['全部', '上位50%', '上位33%', '上位20%', '上位15%', '上位10%', '上位5%']
C['cid'] = np.arange(len(C)); key = ['形', '指標', '選び方']
FT = FT.merge(C[key + ['cid']], on=key).sort_values(['cid', 'te'], kind='stable')
def st(v):
    v = np.asarray(v, float)
    if len(v) == 0: return dict(件数=0, 合計=0.0)
    eq = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, eq])[1:] - eq).max(); gl = -v[v < 0].sum()
    return dict(件数=len(v), 勝率=(v > 0).mean(), PF=v[v > 0].sum() / gl if gl > 0 else np.inf, 平均=v.mean(), 平均_20円=v.mean() - 7, 合計=v.sum(), 最大DD=dd, RF=v.sum() / dd if dd > 0 else np.inf, 最悪=v.min())
def rule_text(k):
    if k < 0: return '', '', '', '', '', ''
    q, e = divmod(int(k), NE); r = EXD.iloc[e]; return QN[q], r.群, f'{r.利確型}:{r.利確}', f'{r.損切り型}:{r.損切り}', r.時間, e
# ① 形×選び方
rows = []
for c, g in FT.groupby('cid'):
    r0 = C.loc[c]; v = g.損益.values; y = g.年.values
    d = dict(cid=c, 観察=r0.観察, 入る=r0.入る, 指標=r0.指標, 選び方=r0.選び方, **{'全_' + k: x for k, x in st(v).items()}, **{'21_' + k: x for k, x in st(v[y >= 2021]).items()})
    for yy in range(2019, 2027): d[str(yy)] = v[y == yy].sum(); d[f'{yy}_件数'] = int((y == yy).sum())
    d['プラスの年'] = sum(d[str(yy)] > 0 for yy in range(2019, 2027) if d[f'{yy}_件数'] >= 5); d['5件以上の年'] = sum(d[f'{yy}_件数'] >= 5 for yy in range(2019, 2027))
    q_, grp, tp, sl, tm, e = rule_text(r0.k2027); d.update(今の強さ=q_, 今の手じまい群=grp, 今の利確=tp, 今の損切り=sl, 今の時間=tm)
    rows.append(d)
A = pd.DataFrame(rows)
# ② 今の中心の形（元のエンジン、コスト統一）
Cb, FTb = pickle.load(open(N + 'nlong_flat.pkl', 'rb'))
b = Cb[(Cb.分類 == '逆張り売り') & (Cb.観察 == '8:45→9:05') & (Cb.入る == '0') & (Cb.選び方 == '周辺')].cid.iloc[0]
fb = FTb[FTb.cid == b]; BASE = dict(観察='8:45→9:05', 入る='0', 指標='（元：1回平均）', 選び方='周辺', **{'全_' + k: x for k, x in st(fb.損益.values).items()}, **{'21_' + k: x for k, x in st(fb[fb.年 >= 2021].損益.values).items()})
for yy in range(2019, 2027): BASE[str(yy)] = fb[fb.年 == yy].損益.sum(); BASE[f'{yy}_件数'] = int((fb.年 == yy).sum())
# 偶然の目安：形×選び方 1,000 のうち、前向きで基準に勝つ割合
cmpb = dict(PFが基準より上=(A.全_PF > BASE['全_PF']).mean(), RFが基準より上=(A.全_RF > BASE['全_RF']).mean(), 両方が上=((A.全_PF > BASE['全_PF']) & (A.全_RF > BASE['全_RF'])).mean())
# ③ 2段目も前向き
EXT = {}
def ext_time(row, e):
    if row not in EXT:
        r = M.iloc[row]; fill = None if (r.fill is None or (isinstance(r.fill, float) and np.isnan(r.fill))) else float(r.fill)
        EXT[row] = xeng.sim((int(r.te), fill, r.mv, r.tcap, r.tam, r.peak0, r.B, r.pcl, r.ncl), want_time=True)[1]
    return EXT[row][e]
def simulate(t, cids, maxpos=2):
    pr = {c: i for i, c in enumerate(cids)}; tr = FT[(FT.年 == t) & FT.cid.isin(pr)].copy(); tr['pr'] = tr.cid.map(pr)
    tr = tr.sort_values(['sid', 'te', 'pr']); out = []
    for s, g in tr.groupby('sid', sort=False):
        held = []; closed = False; used = set()
        for r in g.itertuples():
            still = []
            for h in held:
                if h[1] <= r.te: closed = True; out.append(h)
                else: still.append(h)
            held = still
            if closed or len(held) >= maxpos or r.cid in used: continue
            # 同じ入る時刻・同じ手じまいの重複（同じトレード）は1本
            if any(h[0] == r.te and h[5] == r.row and h[6] == r.e for h in held): continue
            held.append((r.te, ext_time(r.row, r.e), r.cid, r.損益, s, r.row, r.e)); used.add(r.cid)
        out += held
    return pd.DataFrame(out, columns=['入る', '手じまう', 'cid', '損益', 'sid', 'row', 'e'])
def pick(t, met, Nn, minn=20):
    """t より前の前向き記録で、形ごとに最良の選び方を1つ、met の順に上位 Nn 形"""
    past = FT[FT.年 < t]
    if not len(past): return []
    S = []
    for c, g in past.groupby('cid'):
        s = st(g.損益.values)
        if s['件数'] >= minn and s['合計'] > 0: S.append((c, C.loc[c, '形'], min(s['PF'], 10), min(s['RF'], 50)))
    if not S: return []
    S = pd.DataFrame(S, columns=['cid', '形', 'PF', 'RF']).sort_values(met, ascending=False).drop_duplicates('形')
    return list(S.cid.values[:Nn])
PORT = []; HS = {}
for met in ('PF', 'RF'):
    for Nn in (1, 3, 5, 10):
        Hs = []; info = {}
        for t in range(2021, 2027):
            cids = pick(t, met, Nn); H = simulate(t, cids); H['年'] = t; Hs.append(H); info[t] = len(cids)
        H = pd.concat(Hs); s = st(H.sort_values('手じまう').損益.values); HS[(met, Nn)] = H
        PORT.append(dict(選ぶ指標=met, 形の数=Nn, **s, **{str(t): H[H.年 == t].損益.sum() for t in range(2021, 2027)}))
# 基準の形だけの口座（同じ期間）
PORT.append(dict(選ぶ指標='（基準：今の中心の形1つ）', 形の数=1, **st(fb[fb.年 >= 2021].損益.values), **{str(t): fb[fb.年 == t].損益.sum() for t in range(2021, 2027)}))
P = pd.DataFrame(PORT)
# ④ これから記録する候補（2027 に同じ手順）
NOW = {}
for met in ('PF', 'RF'):
    cids = pick(2027, met, 10)
    NOW[met] = A.set_index('cid').loc[cids].reset_index()
pickle.dump(dict(A=A, BASE=BASE, cmpb=cmpb, P=P, NOW=NOW, HS=HS), open(X + 'xsum.pkl', 'wb'))
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 40)
print('基準', {k: round(v, 2) if isinstance(v, float) else v for k, v in BASE.items() if k.startswith('全_') or k.startswith('21_')})
print('形×選び方のうち基準に勝つ割合', {k: round(v, 3) for k, v in cmpb.items()})
print(A.sort_values('全_RF', ascending=False).head(15)[['観察', '入る', '指標', '選び方', '全_件数', '全_PF', '全_RF', '全_合計', '全_最大DD', 'プラスの年', '5件以上の年', '今の強さ', '今の利確', '今の損切り', '今の時間']].round(2).to_string(index=False))
print(P.round(1).to_string(index=False))
for met, D in NOW.items():
    print('今の候補', met); print(D[['観察', '入る', '指標', '選び方', '全_件数', '全_PF', '全_RF', '全_合計', 'プラスの年', '今の強さ', '今の手じまい群', '今の利確', '今の損切り', '今の時間']].round(2).to_string(index=False))
