import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/chk'); import xeng
from xeng import PM, PO, PH, PL, EXD
M = pd.read_pickle('/home/claude/yt/outx/XM.pkl'); R = np.load('/home/claude/yt/outx/XR.npy', mmap_mode='r')
def loop(r, tp_kind, tpv, sl_kind, slv, mod=None):
    te = int(r.te); j0 = np.searchsorted(PM, te); jc = np.searchsorted(PM, r.tcap)
    lim = not (r.fill is None or (isinstance(r.fill, float) and np.isnan(r.fill)))
    e = float(r.fill) if lim else PO[j0]; peak = max(r.peak0, e)
    tg = None
    if tp_kind == '戻し': tg = peak - tpv * (peak - r.B)
    if tg is not None and tg >= e: return np.nan
    stop = peak * (1 + slv / 100) if sl_kind == '高値+' else (e * (1 + slv / 100) if sl_kind == '%' else np.inf)
    best = e; armed = False
    for k in range(j0, jc):
        h, l, o = PH[k], PL[k], PO[k]
        if lim and k == j0: l = max(l, e)
        if mod and mod[0] == '追従':
            lvl = best + mod[1] / 100 * e
            if h >= lvl: return (e - max(o, lvl)) / e * 68800 - 13
        if mod and mod[0] == '建値':
            if armed and h >= e: return (e - max(o, e)) / e * 68800 - 13
            if h >= e * 1.008: return (e - max(o, e * 1.008)) / e * 68800 - 13
        if h >= stop: return (e - max(o, stop)) / e * 68800 - 13
        if tg is not None and l <= tg: return (e - min(o, tg)) / e * 68800 - 13
        best = min(best, l)
        if mod and mod[0] == '建値' and e - best >= mod[1] / 100 * e: armed = True
    return (e - PO[jc]) / e * 68800 - 13
def idx(**kw):
    q = EXD
    for k, v in kw.items(): q = q[q[k] == v]
    return q.index[0]
rng = np.random.default_rng(3); S = M.sample(400, random_state=5); bad = {}
tests = [('戻し1.0+高値0.1+C', idx(群='値段', 利確型='戻し', 利確='1.0', 損切り型='高値+', 損切り='0.1', 時間='C'), ('戻し', 1.0, '高値+', 0.1, None)),
         ('戻し0.5+%0.5+C', idx(群='値段', 利確型='戻し', 利確='0.5', 損切り型='%', 損切り='0.5', 時間='C'), ('戻し', 0.5, '%', 0.5, None)),
         ('なし+追従0.5+C', idx(群='建値・追従', 利確型='なし', 損切り型='追従', 損切り='0.5%', 時間='C'), (None, 0, None, 0, ('追従', 0.5))),
         ('なし+建値0.3+C', idx(群='建値・追従', 利確型='なし', 損切り型='建値', 損切り='0.3%', 時間='C'), (None, 0, None, 0, ('建値', 0.3)))]
for nm, j, a in tests:
    d = []
    for r in S.itertuples():
        v1 = float(R[r.Index, j]); v2 = loop(r, *a)
        if np.isnan(v1) and np.isnan(v2): continue
        d.append(abs(v1 - v2) if not (np.isnan(v1) or np.isnan(v2)) else 9e9)
    d = np.array(d); print(nm, '件数', len(d), '最大の差', round(d.max(), 2), '1円超', int((d > 1).sum()))
