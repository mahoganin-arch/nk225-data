# 1年前に選んでいた候補の答え合わせ（全数）
#   各年 t：t より前のデータだけで作った候補の集まり（nest_t）→ 案3で選んだ候補（全部・上位5本）と条件なし・売りのみの上位5本
#   候補1本ずつ：選んだ時点の成績（選ぶ期間の平均・前向き記録）と、t 年の成績（その年のルール、1本単独）
#   候補の集まり全体：t 年にプラスだった割合・1回平均。選んだ候補が全体より良かったか
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/chk'); import nest
U = ['向き', '売買', '指標', '区分', '使い方', '観察', '入る']
NOW = pd.read_pickle(nest.O + 'YNOW.pkl')[5]; now35 = set(map(tuple, NOW[NOW.扱い == ''][U].values)); now40 = set(map(tuple, NOW[U].values))
ENT = nest.YM.mv.values / np.abs(nest.YM.x.values)
def st(v, rows=None):
    v = np.asarray(v, float)
    if len(v) == 0: return dict(件数=0)
    eq = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, eq])[1:] - eq).max(); gp = v[v > 0].sum(); gl = -v[v < 0].sum()
    return dict(件数=len(v), 勝率=(v > 0).mean(), PF=gp / gl if gl > 0 else np.inf, 平均=v.mean(), 合計=v.sum(), 最大DD=dd, 最悪=v.min())
def cond(r): return '条件なし' if r.指標 == 'なし' else f'{r.指標}「{r.区分}」に' + ('入る' if r.使い方 == '入る' else '当たる日は入らない')
SEL = []; POOL = []; PORT = []
for t in (2024, 2025, 2026):
    Cd, FT, _ = pickle.load(open(nest.N + f'nest_{t}.pkl', 'rb'))
    R, _d = nest.record(FT, t)
    cur = FT[FT.年 == t]; g = cur.groupby('cid').損益
    yt = pd.DataFrame(dict(件数_t=g.size(), 合計_t=g.sum(), 平均_t=g.mean()))
    X = Cd.join(R, on='cid').join(yt, on='cid')
    # 候補の集まり全体（その年に5件以上）
    for kb, gg in X.groupby('分類'):
        a = gg[gg.件数_t >= 5]
        POOL.append(dict(確かめる年=t, 分類=kb, 候補の数=len(gg), その年5件以上=len(a), プラスの割合=(a.合計_t > 0).mean(), 一回平均=a.平均_t.mean(),
                         条件なしだけ_プラスの割合=(a[a.指標 == 'なし'].合計_t > 0).mean(), 条件なしだけ_一回平均=a[a.指標 == 'なし'].平均_t.mean()))
    for lab, pool, grp in (('全部・上位5本', Cd, nest.POOLS['全部']), ('条件なし・売りのみ・上位5本', Cd[Cd.指標 == 'なし'], nest.POOLS['売りのみ'])):
        s = nest.choose(pool, FT, t, 5, grp)
        H = nest.simulate(FT, t, s, 'C1'); PORT.append(dict(確かめる年=t, 選び方=lab, 本数=int((s.扱い == '').sum()), **{'口座_' + k: v for k, v in nest.summ(H).items()}))
        for r in s.itertuples():
            f = FT[(FT.cid == r.cid) & (FT.年 == t)].sort_values('te')
            k = tuple(getattr(r, c) for c in U)
            SEL.append(dict(確かめる年=t, 選び方=lab, 分類=r.分類, 扱い='売買する' if r.扱い == '' else '記録だけ（' + r.扱い + '）', 条件=cond(r), 観察=r.観察, 入る=r.入る, 評価の選び方=r.選び方,
                            前の順位=(r.前の順位 + 1) if r.前の順位 < 99 else None, 新の順位=(r.新の順位 + 1) if r.新の順位 < 99 else None,
                            選んだ時_選ぶ期間の1回平均=getattr(r, f'選ぶ期間平均_{t}'), 選んだ時_選ぶ期間の件数=getattr(r, f'選ぶ期間件数_{t}'),
                            選んだ時_前向き記録_件数=r.件数, 選んだ時_前向き記録_合計=r.合計, 選んだ時_前向き記録_PF=r.PF, 選んだ時_前向き記録_RF=r.RF,
                            **{'その年_' + kk: vv for kk, vv in st(f.損益.values).items()}, 今の35本に入る=k in now35, 今の40本に入る=k in now40))
S = pd.DataFrame(SEL); Pl = pd.DataFrame(POOL); Pt = pd.DataFrame(PORT)
# 選んだ候補（単独）と、集まり全体の比較
cmp = []
for (t, lab, kb), g in S[S.扱い == '売買する'].groupby(['確かめる年', '選び方', '分類']):
    p = Pl[(Pl.確かめる年 == t) & (Pl.分類 == kb)].iloc[0]; a = g[g.その年_件数 >= 1]
    cmp.append(dict(確かめる年=t, 選び方=lab, 分類=kb, 選んだ本数=len(g), その年に売買があった=len(a), プラスの本数=int((a.その年_合計 > 0).sum()),
                    選んだ候補_一回平均=(a.その年_合計.sum() / a.その年_件数.sum()) if len(a) else np.nan, 集まり全体_一回平均=p.一回平均, 集まり全体_プラスの割合=p.プラスの割合))
Cm = pd.DataFrame(cmp)
pickle.dump((S, Pl, Pt, Cm), open(nest.N + 'nyear.pkl', 'wb'))
pd.set_option('display.width', 250)
print(Pt.round(0).to_string(index=False)); print(Cm.round(2).to_string(index=False)); print(Pl.round(2).to_string(index=False))
print('今の35本に入る', S.groupby(['確かめる年', '選び方']).今の35本に入る.sum().to_dict())
