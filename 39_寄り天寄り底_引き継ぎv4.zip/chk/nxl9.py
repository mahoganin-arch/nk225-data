# 長い本当の前向き（条件なし、2019〜2026）と、記録する候補（A・B）・判断の基準 → out/Y9_寄り天寄り底_長い前向きと記録の候補.xlsx
import pickle, numpy as np, pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
O = '/home/claude/yt/out/'; N = '/home/claude/yt/outn/'; F = O + 'Y9_寄り天寄り底_長い前向きと記録の候補.xlsx'
FONT = 'Arial'; HEAD = PatternFill('solid', fgColor='DDE4EE'); thin = Side(style='thin', color='BBBBBB'); BOX = Border(top=thin, bottom=thin, left=thin, right=thin)
GOOD = PatternFill('solid', fgColor='E3F1E3'); BAD = PatternFill('solid', fgColor='FBE3E1')
wb = Workbook(); wb.remove(wb.active)
def fmt(c):
    c = str(c)
    if '勝率' in c or '割合' in c: return '0%'
    if c.endswith('PF') or c.endswith('RF'): return '0.00'
    if '1回平均' in c or c.endswith('平均') or '平均_20pt' in c or c.endswith('差'): return '0.0'
    return '#,##0;-#,##0'
def sheet(name, title, notes=()):
    ws = wb.create_sheet(name); ws['A1'] = title; ws['A1'].font = Font(name=FONT, bold=True, size=13); r = 2
    for n in notes: ws.cell(r, 1, n).font = Font(name=FONT, size=10, color='555555'); r += 1
    return ws, r + 1
def table(ws, r, df, widths=None, wrap=(), freeze=1, color_col=None):
    for j, c in enumerate(df.columns, 1):
        x = ws.cell(r, j, str(c)); x.font = Font(name=FONT, bold=True, size=10); x.fill = HEAD; x.border = BOX; x.alignment = Alignment(wrap_text=True, vertical='center')
    ws.row_dimensions[r].height = 40
    for i, row in enumerate(df.itertuples(index=False), r + 1):
        for j, v in enumerate(row, 1):
            c = df.columns[j - 1]
            if isinstance(v, np.generic): v = v.item()
            if isinstance(v, float) and np.isnan(v): v = None
            if isinstance(v, float) and np.isinf(v): v = '∞'
            x = ws.cell(i, j, v); x.border = BOX
            x.font = Font(name=FONT, size=10, color='C00000' if isinstance(v, (int, float)) and not isinstance(v, bool) and v < 0 else '000000')
            x.alignment = Alignment(wrap_text=c in wrap, vertical='top')
            if isinstance(v, (int, float)) and not isinstance(v, bool): x.number_format = fmt(c)
            if color_col and c == color_col and isinstance(v, (int, float)): x.fill = GOOD if v > 0 else BAD
    if widths:
        for j, w in enumerate(widths, 1): ws.column_dimensions[get_column_letter(j)].width = w
    ws.freeze_panes = ws.cell(r + 1, freeze + 1); return r + len(df) + 2
def kv(ws, r, L, w=(22, 120)):
    for k, v in L:
        ws.cell(r, 1, k).font = Font(name=FONT, bold=True, size=10); c = ws.cell(r, 2, v); c.font = Font(name=FONT, size=10); c.alignment = Alignment(wrap_text=True, vertical='top'); r += 1
    ws.column_dimensions['A'].width = w[0]; ws.column_dimensions['B'].width = w[1]; return r + 1

R13, P13, _ = pickle.load(open(N + 'nlong2.pkl', 'rb')); RF_, PF_, _ = pickle.load(open(N + 'nlong2_flat.pkl', 'rb'))
B = pickle.load(open(N + 'nbnow.pkl', 'rb')); A7 = pd.read_pickle(O + 'Y7_now.pkl')

# ---------------------------------------------------------------- 説明と結論
ws, r = sheet('説明と結論', '寄り天・寄り底：長い本当の前向き（条件なし、2019〜2026）と記録する候補（2026-10-17）')
r = kv(ws, r, [
    ('やったこと', '条件（指標）を付けない候補 632件（逆張り116通り・順張り42通りの入る形 × 売り・買い × 単点・周辺）で、2019〜2026年の各年を「その年より前のデータで選んだ強さ×手じまい」で売買。条件を付けないので候補の集まりは最初から決まっており、候補選びに先のデータを使っていない（＝本当の前向き）。2019年は 2017〜18年で選ぶ'),
    ('確かめたこと', '①分類ごとの全体の成績 ②「それまで続けて良かった候補」はその年も良いか（2021〜2026年、4つの基準）③各年の初めに選んで口座で動かした成績 ④これから記録する候補（B）を今のデータで選ぶ'),
    ('コスト', '13pt（値段で割る）と、コスト統一（毎回13円）の両方。まろの方針に合わせて、選ぶのはコスト統一を主にした'),
])
ws.cell(r, 1, '結論').font = Font(name=FONT, bold=True, size=12); r += 1
r = kv(ws, r, [
    ('1. 買い側は無い', '逆張り買い・順張り買いは、どの選び方でも6年合計がマイナス（口座でも）。寄り底を狙う買いは、条件なしでは優位性が見つからない'),
    ('2. 売りは「9:05まで強く上げたら売る」が中心', '逆張り売り・8:45→9:05・動きが上位10%・利確なし・損切り0.8%・240分で手じまう形が、入り方（9:05ちょうど、+5分、天井から0.1%戻し、動きの25%戻し、50%戻して確認）を変えても、2019〜2026年の8年中7年プラス。2021年以降は5つとも毎年プラス'),
    ('3. 続けて良い候補は少し続く（条件なしの場合）', '過去の1回平均が分類内の上位10%の候補は、翌年も分類の平均より良かった組が 13pt で24組中17組（+8円）、コスト統一で16組（+11円）。条件付き候補（2022〜の短い前向き）では見られなかった傾向'),
    ('4. ただし口座の成績はぶれる', '選び方と集まりの組み合わせ20通り×コスト2通りのうち、プラスとマイナスが混ざる。一番良いのは「1年だけマイナス可・逆張り売り」（コスト統一 +20,811円、最大DD 5,082円、6年中5年プラス）。逆張り売りだけの口座はコスト統一で5つの選び方のうち4つがプラス。2026年の比重が大きい点は変わらない'),
    ('5. 記録の提案', 'A：今の35本＋記録だけ5本（条件付き、元の手順）。B1：条件なし・1年だけマイナス可（実質「9:05まで上位10%上げたら売る」の1つの形）。B2：条件なし・過去の合計プラス（売りと買いの各分類、比べる相手として）。10/9以降で A と B を同じ期間で比べる'),
    ('6. 注意', 'B1 の売りは1年あたり 12〜39件しかない（5本は同じ日にほぼ重なる）。判断に十分な件数がたまるまで1〜2年かかる。入る形の違いは同じトレードの言い換えに近いので、5本で1つの戦略として扱う'),
])

# ---------------------------------------------------------------- 分類の平均
def avg_tab(R):
    t = R.drop_duplicates(['確かめる年', '分類']).pivot(index='分類', columns='確かめる年', values='全体_1回平均'); t.columns = [str(c) for c in t.columns]; return t.reset_index()
ws, r = sheet('分類ごとの成績', '条件なしの全候補（その年5件以上）の、その年の1回平均（円）', ['各年のルールはその年より前のデータで選んだもの'])
ws.cell(r - 1, 1, '13pt').font = Font(name=FONT, bold=True); r = table(ws, r, avg_tab(R13), widths=[14] + [10] * 6)
ws.cell(r - 1, 1, 'コスト統一').font = Font(name=FONT, bold=True); table(ws, r, avg_tab(RF_))

# ---------------------------------------------------------------- 続けて良い候補の確かめ
def cons(R, lab):
    t = R.copy(); t.insert(0, 'コスト', lab); t['確かめる年'] = t.確かめる年.astype(str)
    return t[['コスト', '確かめる年', '分類', '基準', '選んだ本数', '選んだ_1回平均', '全体_1回平均', '全体との差', '選んだ_プラスの割合', '全体_プラスの割合', '全体_本数']]
S = []
for lab, R in (('13pt', R13), ('コスト統一', RF_)):
    for nm, g in R.dropna(subset=['選んだ_1回平均']).groupby('基準'):
        S.append([lab, nm, int((g.全体との差 > 0).sum()), len(g), np.average(g.全体との差, weights=g.選んだ本数)])
ws, r = sheet('続けて良い候補の確かめ', '「それまで続けて良かった候補」はその年も良いか（2021〜2026年、各年の初めにそれまでの前向き記録だけで選ぶ）',
              ['基準：毎年プラス＝2019〜前年が毎年プラス（各年5件以上）、1年だけマイナス可、過去の合計プラス（20件以上）、過去の1回平均が分類内の上位10%', '全体＝その分類の条件なしの候補すべて（その年5件以上）'])
r = table(ws, r, pd.DataFrame(S, columns=['コスト', '基準', '全体より良かった組', '組の数', '差の平均（本数で重み、円）']), widths=[12, 30, 14, 9, 16])
table(ws, r, pd.concat([cons(R13, '13pt'), cons(RF_, 'コスト統一')]), widths=[12, 9, 11, 30, 9, 12, 12, 10, 12, 12, 9], color_col='全体との差')

# ---------------------------------------------------------------- 口座
def port(P, lab):
    t = P.copy(); t.insert(0, 'コスト', lab)
    return t[['コスト', '基準', '集まり', '件数', '合計', '最大DD', '一回平均', '勝率', '2021', '2022', '2023', '2024', '2025', '2026']]
ws, r = sheet('口座の成績', '各年の初めに選んで、同じ向き2本で動かした成績（2021〜2026）',
              ['選び方：基準を満たす候補を、分類ごとに過去のRF順（「1回平均順」は過去の1回平均順）で上位5本（同じ入る形は1本）。20通り×コスト2通りを比べているので、一番良いものにも当てはめが混ざる'])
table(ws, r, pd.concat([port(P13, '13pt'), port(PF_, 'コスト統一')]), widths=[12, 28, 12, 7, 11, 11, 9, 8] + [10] * 6, color_col='合計')

# ---------------------------------------------------------------- B の候補
cols = ['記録の組', 'コスト', '分類', '観察', '入る', '選び方', '今の強さ', '手じまいの型', '利確', '損切り', '時間', '前向き_件数', '前向き_勝率', '前向き_PF', '前向き_平均', '前向き_平均_20pt', '前向き_合計', '前向き_最大DD', '前向き_RF', '前向き_最悪', 'プラスの年', '五件以上の年'] + [str(y) for y in range(2019, 2027)] + [f'{y}_件数' for y in range(2019, 2027)]
for lab in ('コスト統一', '13pt'):
    ws, r = sheet(f'B_今の候補_{lab}', f'記録する候補 B（条件なし、今のデータで選ぶ）：{lab}',
                  ['前向き＝2019〜2026/10/8 を各年のルールで売買した記録。今の強さ・手じまい＝2017〜2026/10/8 で選んだ、これから使うルール', 'B1 と B2 の両方に入る候補は同じもの。分類ごとに前向きRF順で上位5本'])
    D = pd.concat([B[(lab, 'B1：1年だけマイナス可')], B[(lab, 'B2：過去の合計プラス')]])
    table(ws, r, D[cols], widths=[18, 10, 11, 10, 7, 6, 9, 7, 9, 6, 6] + [9] * 11 + [9] * 16, freeze=5)
ALL = B[('コスト統一', '全候補')].sort_values(['分類', '前向き_合計'], ascending=[True, False])
ws, r = sheet('条件なし全候補_コスト統一', '条件なしの全候補（632のうちルールが作れたもの）の前向き 2019〜2026（コスト統一）')
table(ws, r, ALL[cols[2:]], widths=[11, 10, 7, 6, 9, 7, 9, 6, 6] + [9] * 27, freeze=3)

# ---------------------------------------------------------------- 記録の一覧
rec = []
for x in A7.itertuples():
    rec.append(['A：今の候補（条件付き）', x.扱い, x.分類, x.条件, x.観察, x.入る, x.強さ, f'{x.手じまいの型}：利確{x.利確}／損切り{x.損切り}／時間{x.時間}', x.優先順位])
for bn in ('B1：1年だけマイナス可', 'B2：過去の合計プラス'):
    for i, x in enumerate(B[('コスト統一', bn)].itertuples(), 1):
        rec.append([bn, '記録だけ', x.分類, '条件なし', x.観察, x.入る, x.今の強さ, f'{x.手じまいの型}：利確{x.利確}／損切り{x.損切り}／時間{x.時間}', i])
ws, r = sheet('記録する一覧', '10/9以降に記録する候補（お金は入れない）', ['A は元の手順（13pt）の今の候補。B はコスト統一で選んだ条件なしの候補。同じ組の中は同じ向き2本・入り直しなしで記録'])
table(ws, r, pd.DataFrame(rec, columns=['組', '扱い', '分類', '条件', '観察', '入る', '強さ', '手じまい', '組の中の順位']), widths=[22, 10, 11, 40, 10, 8, 9, 44, 8], wrap=('条件',))

# ---------------------------------------------------------------- 判断の基準（案）
ws, r = sheet('判断の基準（案）', '10/9以降のデータでの判断の基準（叩き台。まろが決める）', ['後から基準を動かすと当てはめになるので、記録を始める前に決める'])
J = [('見る間隔', '3か月ごと（1月・4月・7月・10月）に、A・B1・B2 を同じ期間・同じ口座の決まり（同じ向き2本）で比べる', '—'),
     ('比べ方', '組ごとの合計・1回平均・勝率・PF・最大DD と、コスト20ptでの1回平均。候補1本ずつではなく組全体で判断する（1本ずつは件数が少なすぎる）', '—'),
     ('判断する件数', 'A は約100件、B1 は約30件（B1 は年20〜40件なので約1年）がたまったら一度判断する', '叩き台'),
     ('売買を検討する条件', '組の1回平均がプラス、かつコスト20ptでもマイナスにならない、かつ最大DDが下の止める基準に届いていない', '叩き台'),
     ('A と B の比べ方', 'A が B1 に勝てば「条件が効いている」。B1 だけが良ければ条件は使わず B1 の形で進める。どちらも悪ければ寄り天の現象自体が弱まったと見る', '—'),
     ('止める（見直す）基準', '最大DD が過去の前向きの最大DD の2倍を超えたら見直す（B1 の5本で過去の最大DD は 約1,750〜2,650円 → 約5,000円）', '叩き台'),
     ('候補の入れ替え', '記録中は候補を入れ替えない。入れ替えは判断の時点で、その時点までの全データで選び直す（今回と同じ手順）', '—')]
table(ws, r, pd.DataFrame(J, columns=['項目', '内容', '数字の扱い']), widths=[20, 110, 12], wrap=('内容',))
wb.save(F); print(F)
