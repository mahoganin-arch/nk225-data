# 逆張り売りの拡張エンジン（日中 8:45〜、先物が上げた日だけ → CFD を売る）
#   観察：8:45→9:00/9:05/9:10/9:15/9:30。入る：50通り。手じまい：2,151通り。コストは毎回13円（コスト統一）
#   出力：outx/XM.pkl（1行＝1トレード）、outx/XR.npy（float16、円）、outx/XEXITS.pkl
import sys, numpy as np, pandas as pd
from multiprocessing import Pool
sys.path.insert(0, '/home/claude/yt/an')
import eng, eng2
from eng import P, PM, PO, PH, PL, IND, FM, FO, CM, CO, px, O
PC = P.close.values; PTF = P.tf.values
X = '/home/claude/yt/outx/'
UNIT = 68800.0; COST = 13.0; INF = np.inf; D = -1          # 売り
DEAD = 90
OBS = [('8:45→9:00', 15), ('8:45→9:05', 20), ('8:45→9:10', 25), ('8:45→9:15', 30), ('8:45→9:30', 45)]
OLD = ['0', '+5', 'c25', 'c50'] + eng2.REV
NEW = ['+10', '+15', '+30', 'LMT10', 'LMT20', 'LMT30', 'LOWB', 'LOWL', 'STL10', 'STL20', 'STL30', 'HA15', 'HA60', 'HTH1', 'HTH5',
       'RSI15', 'R80_1', 'R80_5', 'CK1a', 'CK1b', 'CK5a', 'CK5b', 'CK15a', 'CK15b', 'TK5', 'TK15']
ENTS = OLD + NEW
# ---- 指標の補助（遅行線・転換線）
for tf in (1, 5, 15, 60):
    I = IND[tf]; c = I['close']; h = I['high']; l = I['low']
    c26 = np.r_[np.full(26, np.nan), c[:-26]]; l26 = np.r_[np.full(26, np.nan), l[:-26]]; h26 = np.r_[np.full(26, np.nan), h[:-26]]
    I['ck_dn_a'] = c < c26; I['ck_dn_b'] = c < l26; I['ck_up_a'] = c > c26; I['ck_up_b'] = c > h26
    hh = pd.Series(h).rolling(9).max().values; ll = pd.Series(l).rolling(9).min().values; I['tk'] = (hh + ll) / 2
def first_trans(cond, k0, k1):
    """k0..k1-1 で cond が False→True に変わった最初の番号（k0 の直前が True なら、いったん False になってから）"""
    w = cond[k0:k1].astype(bool); prev = np.r_[cond[k0 - 1] if k0 > 0 else True, w[:-1]]
    hit = np.flatnonzero(w & ~prev)
    return k0 + hit[0] if len(hit) else None
def win(tf, b, dead):
    I = IND[tf]
    if tf == 1 and b < I['m'][0] + 1440: return None
    k0 = np.searchsorted(I['end'], b, 'right'); k1 = np.searchsorted(I['end'], b + dead, 'right')
    return (k0, k1) if k1 > k0 else None

def trigger(code, a, b, c0, mv):
    """戻り値：(入る時刻, 約定値段 or None)。None＝入らない"""
    if code in ('0', '+5', '+10', '+15', '+30'): return b + int(code), None
    if code in ('c25', 'c50'):
        te = eng.confirm(D, b, c0, float(code[1:]) / 100 * mv, 60, D); return (te, None) if te is not None else None
    if code in eng2.REV:
        tr = eng2.trigger(code, 1, a, b, c0, mv); return (tr[0], None) if tr is not None else None
    j0 = np.searchsorted(PM, b); j1 = np.searchsorted(PM, b + DEAD)
    if code.startswith('LMT'):
        lv = c0 * (1 + int(code[3:]) / 10000); j1 = np.searchsorted(PM, b + 60)
        w = np.flatnonzero(PH[j0:j1] >= lv)
        if not len(w): return None
        k = j0 + w[0]; return PM[k], max(PO[k], lv)
    if code in ('LOWB', 'LOWL'):
        if code == 'LOWB':
            ja = np.searchsorted(PM, a)
            if ja >= j0: return None
            ref = PL[ja:j0].min()
        else:
            k5 = np.searchsorted(IND[5]['end'], b, 'right') - 1
            if k5 < 0 or IND[5]['end'][k5] != b: return None
            ref = IND[5]['low'][k5]
        w = np.flatnonzero(PC[j0:j1] < ref)
        if not len(w): return None
        k = j0 + w[0]; return PM[k] + PTF[k], None
    if code.startswith('STL'):
        N = int(code[3:]); ja = np.searchsorted(PM, a)
        if ja >= j0: return None
        hi = PH[ja:j1]; mm = PM[ja:j1]; tf = PTF[ja:j1]
        run = np.maximum.accumulate(hi); nh = np.r_[True, hi[1:] > run[:-1]]
        last = np.maximum.accumulate(np.where(nh, mm, 0))
        end = mm + tf; ok = (end >= b) & (end - last >= N)
        w = np.flatnonzero(ok)
        return (end[w[0]], None) if len(w) else None
    if code in ('HA15', 'HA60'):
        tf = int(code[2:]); ww = win(tf, b, 90 if tf == 15 else 180)
        if ww is None: return None
        I = IND[tf]; w = np.flatnonzero(I['ha'][ww[0]:ww[1]] < 0)
        return (I['end'][ww[0] + w[0]], None) if len(w) else None
    if code in ('HTH1', 'HTH5'):
        tf = int(code[3:]); ww = win(tf, b, DEAD)
        if ww is None: return None
        I = IND[tf]; H = IND[15]
        for k in range(ww[0], ww[1]):
            if I['ha'][k] >= 0: continue
            kh = np.searchsorted(H['end'], I['end'][k], 'right') - 1
            if kh >= 0 and H['ha'][kh] < 0: return I['end'][k], None
        return None
    if code in ('RSI15', 'R80_1', 'R80_5'):
        tf, lv = (15, 70) if code == 'RSI15' else (int(code[-1]), 80)
        ww = win(tf, b, 120 if tf == 15 else DEAD)
        if ww is None: return None
        I = IND[tf]; rs = I['rsi'][ww[0]:ww[1]]; was = np.maximum.accumulate(rs >= lv); sig = was & np.r_[False, was[:-1]] & (rs < lv)
        w = np.flatnonzero(sig); return (I['end'][ww[0] + w[0]], None) if len(w) else None
    if code.startswith('CK') or code.startswith('TK'):
        if code.startswith('CK'): tf = int(code[2:-1]); key = 'ck_dn_' + code[-1]
        else: tf = int(code[2:]); key = None
        ww = win(tf, b, 120 if tf == 15 else DEAD)
        if ww is None: return None
        I = IND[tf]
        cond = I[key] if key else (I['close'] < I['tk'])
        k = first_trans(cond, ww[0], ww[1])
        return (I['end'][k], None) if k is not None else None
    raise ValueError(code)

# ---------------------------------------------------------------- 手じまい
TIMES = [15, 30, 60, 90, 120, 'AM', 180, 240, 'C']
TPS = [('なし', None)] + [('%', v) for v in (0.1, 0.2, 0.3, 0.5, 0.8, 1.2)] + [('倍', v) for v in (0.5, 1, 1.5, 2)] + [('戻し', v) for v in (0.25, 0.5, 0.75, 1.0)] + [('終値', '前日'), ('終値', '夜間')]
SLS = [('なし', None)] + [('%', v) for v in (0.1, 0.2, 0.3, 0.5, 0.8)] + [('倍', v) for v in (0.5, 1, 1.5)] + [('高値+', v) for v in (0.05, 0.1, 0.2)]
INDX = [('RSI', 1, 70), ('RSI', 1, 60), ('RSI', 5, 70), ('RSI', 5, 60), ('RSI', 15, 70), ('RSI', 15, 60), ('HA', 1, 0), ('HA', 5, 0), ('HA', 15, 0), ('HA', 60, 0),
        ('前足', 5, 0), ('前足', 15, 0), ('遅行a', 5, 0), ('遅行b', 5, 0), ('遅行a', 15, 0), ('遅行b', 15, 0)]
ISL = [0, 4, 5, 6, 10]          # SLS の番号（なし、0.3%、0.5%、0.8%、高値+0.1%）
ITM = [4, 5, 8]                  # TIMES の番号（120、AM、C）
MTP = [0, 4, 5, 13, 15]         # TPS の番号（なし、0.5%、0.8%、戻し0.5、戻し1.0＝寄り値）
MODS = [('建値', 0.3), ('建値', 0.5), ('追従', 0.3), ('追従', 0.5), ('追従', 0.8)]
MTM = [4, 7, 8]                  # 120、240、C
def exit_list():
    L = []
    for a, tp in enumerate(TPS):
        for b_, sl in enumerate(SLS):
            for c, tm in enumerate(TIMES):
                L.append(dict(群='値段', 利確型=tp[0], 利確=str(tp[1]), 損切り型=sl[0], 損切り=str(sl[1]), 時間=str(tm), ia=a, ib=b_, ic=c))
    for a, (nm, tf, lv) in enumerate(INDX):
        lab = f'{nm}{tf}分' + ({70: '30', 60: '40'}[lv] if nm == 'RSI' else '')
        for b_, s in enumerate(ISL):
            for c, t in enumerate(ITM):
                L.append(dict(群='指標', 利確型='指標:' + nm, 利確=lab, 損切り型=SLS[s][0], 損切り=str(SLS[s][1]), 時間=str(TIMES[t]), ia=a, ib=b_, ic=c))
    for a, t_ in enumerate(MTP):
        for b_, (mn, mv_) in enumerate(MODS):
            for c, t in enumerate(MTM):
                L.append(dict(群='建値・追従', 利確型=TPS[t_][0], 利確=str(TPS[t_][1]), 損切り型=mn, 損切り=str(mv_) + ('%' if True else ''), 時間=str(TIMES[t]), ia=a, ib=b_, ic=c))
    return pd.DataFrame(L)
EXD = exit_list(); NE = len(EXD)

def ind_exit_time(nm, tf, lv, te, tcap):
    if nm in ('RSI', 'HA', '前足'): return eng.ind_exit(tf, nm, lv, D, te, tcap)
    I = IND[tf]; m = I['m']
    if tf == 1 and te < m[0] + 1440: return INF, np.nan
    k0 = np.searchsorted(m, te); k1 = np.searchsorted(m, tcap)
    if k1 <= k0: return INF, np.nan
    k = first_trans(I['ck_up_' + nm[-1]], k0, k1)
    return (I['end'][k], None) if k is not None else (INF, np.nan)

def sim(args, want_time=False):
    te, fill, mv, tcap, tam, peak0, B, pcl, ncl = args
    out = np.full(NE, np.nan, np.float32); tout = np.full(NE, np.nan) if want_time else None
    j0 = np.searchsorted(PM, te)
    if j0 >= len(PM) or PM[j0] - te >= 5 or te >= tcap: return (out, tout) if want_time else out
    lim = fill is not None; e = fill if lim else PO[j0]; jc = np.searchsorted(PM, tcap)
    if jc <= j0: return (out, tout) if want_time else out
    hi = PH[j0:jc].copy(); lo = PL[j0:jc].copy(); op = PO[j0:jc + 1] if jc < len(PO) else np.r_[PO[j0:jc], PO[-1]]; mm = PM[j0:jc]; n = len(mm)
    if lim: lo[0] = max(lo[0], e)           # 指値で入った足の中の有利な動きは数えない（不利な動きは数える）
    fav = np.maximum.accumulate(e - lo); adv = np.maximum.accumulate(hi - e)
    peak = max(peak0, e)
    def tix(tm):
        if tm == 'C': return n
        if tm == 'AM': return -1 if tam <= mm[0] else min(np.searchsorted(mm, tam), n)
        return min(np.searchsorted(mm, mm[0] + tm), n)
    TI = np.array([tix(t) for t in TIMES])
    def tpd(t):
        k, v = t
        if k == 'なし': return INF
        if k == '%': return v / 100 * e
        if k == '倍': return v * mv
        if k == '戻し': tg = peak - v * (peak - B)
        else: tg = pcl if v == '前日' else ncl
        d_ = e - tg
        return d_ if (np.isfinite(d_) and d_ > 0) else np.nan
    def sld(s):
        k, v = s
        if k == 'なし': return INF
        if k == '%': return v / 100 * e
        if k == '倍': return v * mv
        return peak * (1 + v / 100) - e
    TPD = np.array([tpd(t) for t in TPS]); SLD = np.array([sld(s) for s in SLS])
    def first(arr, dist):
        r = np.full(len(dist), n)
        f = np.isfinite(dist); r[f] = np.searchsorted(arr, dist[f], 'left'); return r
    tpi = first(fav, TPD); sli = first(adv, SLD)
    pnl = lambda xp: (e - xp) / e * UNIT - COST
    # 値段の格子
    A = tpi[:, None, None]; Bi = sli[None, :, None]; T = TI[None, None, :]
    k = np.minimum(A, Bi); hit = (k < T) & (k < n); kc = np.minimum(k, n - 1)
    slp = np.maximum(op[kc], e + SLD[None, :, None]); tpp = np.minimum(op[kc], e - TPD[:, None, None])
    tex = op[np.clip(T, 0, n)]
    xp = np.where(hit, np.where(Bi <= A, slp, tpp), tex)
    r1 = pnl(xp); r1 = np.where(np.isnan(TPD)[:, None, None] | (T < 0), np.nan, r1)
    out[:1836] = r1.ravel()
    if want_time:
        tt = np.where(hit, mm[kc], np.where(T < n, mm[np.clip(T, 0, n - 1)], tcap)); tt = np.where(np.isnan(r1), np.nan, tt); tout[:1836] = tt.ravel()
    # 指標
    p = 1836
    for (nm, tf, lv) in INDX:
        ti_t, ti_p = ind_exit_time(nm, tf, lv, te, tcap)
        for s in ISL:
            si = sli[s]; slt = mm[si] if si < n else INF
            for t in ITM:
                tl = TI[t]
                if tl < 0: p += 1; continue
                tlt = mm[tl] if tl < n else tcap
                cand = [(slt, 0), (ti_t, 1), (tlt, 2)]; tmin, kind = min(cand, key=lambda z: (z[0], z[1]))
                if kind == 0: x_ = max(op[si], e + SLD[s])
                elif kind == 1: x_ = ti_p if (ti_p is not None and not (isinstance(ti_p, float) and np.isnan(ti_p))) else op[min(np.searchsorted(mm, ti_t), n)]
                else: x_ = op[min(tl, n)]
                out[p] = pnl(x_)
                if want_time: tout[p] = min(tmin, tcap)
                p += 1
    # 建値・追従
    ib = np.searchsorted(adv, 0.008 * e, 'left') if True else n
    rmin = np.minimum.accumulate(np.r_[e, lo[:-1]])
    for t_ in MTP:
        tpdist = TPD[t_]; ti_ = tpi[t_]
        for (mn, v) in MODS:
            if mn == '建値':
                ka = np.searchsorted(fav, v / 100 * e, 'left')
                w = np.flatnonzero(hi[ka + 1:] >= e) if ka < n - 1 else np.array([], int)
                kb = ka + 1 + w[0] if len(w) else n
                if ib <= kb: ks, sp = ib, (max(op[min(ib, n - 1)], e * 1.008) if ib < n else np.nan)
                else: ks, sp = kb, max(op[kb], e)
            else:
                w = np.flatnonzero(hi - rmin >= v / 100 * e)
                ks = w[0] if len(w) else n; sp = max(op[ks], rmin[ks] + v / 100 * e) if ks < n else np.nan
            for t in MTM:
                tl = TI[t]
                if np.isnan(tpdist) or tl < 0: p += 1; continue
                kk = min(ks, ti_)
                if kk < tl and kk < n:
                    x_ = sp if ks <= ti_ else min(op[ti_], e - tpdist); tt = mm[kk]
                else:
                    x_ = op[min(tl, n)]; tt = mm[tl] if tl < n else tcap
                out[p] = pnl(x_)
                if want_time: tout[p] = tt
                p += 1
    assert p == NE
    return (out, tout) if want_time else out

def events():
    s = pd.read_pickle(O + 'sess.pkl'); s = s.sort_values('m').reset_index(drop=True)
    last = FM[np.searchsorted(FM, s.end.values - 1) - 1]
    m2 = pd.read_pickle(O + 'E2_D_meta.pkl'); cut = {}
    for ob, g in m2.drop_duplicates(['観察', 'sid']).groupby('観察'):
        a_ = np.abs(g.x.values)[g.t.dt.year.values <= 2021]; cut[ob] = a_
    rows = []
    for i, r in s.iterrows():
        if r.kind != 'D' or r.t < pd.Timestamp('2017-03-16', tz='Asia/Tokyo'): continue
        m0 = r.m; tcap = last[i]; tam = m0 + 165
        # 前日の日中の引け・夜間の引け（CFD）
        pcl = np.nan; ncl = np.nan
        for j in range(i - 1, max(i - 4, -1), -1):
            if s.kind[j] == 'N' and np.isnan(ncl): ncl = PC[max(np.searchsorted(PM, s.end[j]) - 1, 0)]
            if s.kind[j] == 'D': pcl = px(CM, CO, last[j]); break
        B = px(CM, CO, m0)
        for ob, L in OBS:
            a, b = m0, m0 + L
            pa, pb = px(FM, FO, a), px(FM, FO, b)
            if not (np.isfinite(pa) and np.isfinite(pb)) or pb <= pa: continue
            x = pb / pa - 1; c0 = px(CM, CO, b)
            if not np.isfinite(c0) or not np.isfinite(B): continue
            mv = x * c0
            for code in ENTS:
                tr = trigger(code, a, b, c0, mv)
                if tr is None: continue
                te, fill = tr; te = int(te)
                ja = np.searchsorted(PM, a); j0 = np.searchsorted(PM, te)
                peak0 = PH[ja:j0].max() if j0 > ja else -np.inf
                rows.append(dict(sid=i, m0=m0, t=r.t, 観察=ob, 入る=code, x=x, mv=mv, c0=c0, te=te, fill=fill, tcap=tcap, tam=tam, peak0=peak0, B=B, pcl=pcl, ncl=ncl))
    M = pd.DataFrame(rows)
    return M

if __name__ == '__main__':
    import os; os.makedirs(X, exist_ok=True)
    M = events(); print('トレード', len(M), flush=True)
    args = [(r.te, (None if (r.fill is None or (isinstance(r.fill, float) and np.isnan(r.fill))) else float(r.fill)), r.mv, r.tcap, r.tam, r.peak0, r.B, r.pcl, r.ncl) for r in M.itertuples()]
    with Pool(2) as pl: R = np.vstack(pl.map(sim, args, chunksize=500))
    M.to_pickle(X + 'XM.pkl'); np.save(X + 'XR.npy', R.astype(np.float16)); EXD.to_pickle(X + 'XEXITS.pkl')
    print(R.shape, np.isnan(R).mean(), M.groupby('入る').size().to_dict())
