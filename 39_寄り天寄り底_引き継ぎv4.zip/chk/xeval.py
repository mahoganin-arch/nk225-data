# 拡張エンジンの本当の前向き（2019〜2026）
#   形＝観察×入る（逆張り売り、条件なし）。選ぶもの＝強さ（7段）×手じまい（2,151）
#   各年 y のルール＝y より前のデータで選ぶ。選び方4通り：PF・合計÷最大DD（RF）× 単点・周辺
#   制約：選ぶ期間で15件以上、年10件以上、最悪の1回 −1,000円以上、合計プラス
#   出力：outx/XC.pkl（形×選び方の前向き成績と各年のルール）、outx/XFT.pkl（前向きトレード）
import sys, pickle, numpy as np, pandas as pd, scipy.sparse as sp
X = '/home/claude/yt/outx/'; O = '/home/claude/yt/out/'
M = pd.read_pickle(X + 'XM.pkl'); R = np.load(X + 'XR.npy', mmap_mode='r'); EXD = pd.read_pickle(X + 'XEXITS.pkl'); NE = len(EXD)
QS = [0, .5, .67, .8, .85, .9, .95]; QN = ['全部', '上位50%', '上位33%', '上位20%', '上位15%', '上位10%', '上位5%']; NQ = len(QS); NK = NQ * NE
m2 = pd.read_pickle(O + 'E2_D_meta.pkl'); cut = {}
for ob, g in m2.drop_duplicates(['観察', 'sid']).groupby('観察'):
    a = np.abs(g.x.values)[g.t.dt.year.values <= 2021]; cut[ob] = [np.quantile(a, q) if q > 0 else 0 for q in QS]
QL = np.zeros(len(M), np.int8); ax = np.abs(M.x.values)
for ob, cs in cut.items():
    w = M.観察.values == ob
    for qi, c in enumerate(cs): QL[w & (ax >= c)] = qi
YR = M.t.dt.year.values; TE = M.te.values.astype('int64'); SID = M.sid.values
# 周辺：同じ群・同じ利確型（値段の群は損切り型も同じ）で ia・ib・ic が ±1、強さ ±1
fam = np.where(EXD.群 == '値段', EXD.群 + '|' + EXD.利確型 + '|' + EXD.損切り型, EXD.群 + '|' + EXD.利確型)
key = {}
for i, r in enumerate(EXD.itertuples()): key[(fam[i], r.ia, r.ib, r.ic)] = i
rows_ = []; cols_ = []
for q in range(NQ):
    for i, r in enumerate(EXD.itertuples()):
        for dq in (-1, 0, 1):
            q2 = q + dq
            if not 0 <= q2 < NQ: continue
            for da in (-1, 0, 1):
                for db in (-1, 0, 1):
                    for dc in (-1, 0, 1):
                        j = key.get((fam[i], r.ia + da, r.ib + db, r.ic + dc))
                        if j is not None: rows_.append(q * NE + i); cols_.append(q2 * NE + j)
NB = sp.csr_matrix((np.ones(len(rows_), np.float32), (rows_, cols_)), shape=(NK, NK))
YEARS = list(range(2019, 2028))       # 2027＝これから使うルール
BND = {y: int(pd.Timestamp(f'{y}-01-01', tz='Asia/Tokyo').timestamp() // 60) for y in YEARS}
VARS = [('PF', '単点'), ('PF', '周辺'), ('RF', '単点'), ('RF', '周辺')]

def prefix_stats(idx):
    """idx：時刻順の行。各年 y の境目より前のプレフィックスでの (S, C, GP, GL, W, DD) を (NK,) で"""
    Rv = np.asarray(R[idx], np.float32); ok = ~np.isnan(Rv); ql = QL[idx]; te = TE[idx]
    P = {y: np.searchsorted(te, BND[y]) for y in YEARS}
    out = {y: {k: np.zeros(NK, np.float32) for k in ('S', 'C', 'GP', 'GL', 'W', 'DD')} for y in YEARS}
    for q in range(NQ):
        mk = ok & (ql >= q)[:, None]; V = np.where(mk, Rv, 0)
        cum = np.cumsum(V, 0); cnt = np.cumsum(mk, 0, dtype=np.float32); gp = np.cumsum(np.maximum(V, 0), 0); gl = np.cumsum(np.maximum(-V, 0), 0)
        wst = np.minimum.accumulate(np.where(mk, Rv, np.inf), 0)
        dd = np.maximum.accumulate(np.maximum(np.maximum.accumulate(cum, 0), 0) - cum, 0)
        sl = slice(q * NE, (q + 1) * NE)
        for y, p in P.items():
            if p == 0: out[y]['W'][sl] = np.inf; continue
            o = out[y]; o['S'][sl] = cum[p - 1]; o['C'][sl] = cnt[p - 1]; o['GP'][sl] = gp[p - 1]; o['GL'][sl] = gl[p - 1]; o['W'][sl] = wst[p - 1]; o['DD'][sl] = dd[p - 1]
    return out, P

def choose(st, effy):
    S, C, GP, GL, W, DD = (st[k] for k in ('S', 'C', 'GP', 'GL', 'W', 'DD'))
    with np.errstate(all='ignore'):
        pf = np.where(GL > 0, GP / GL, np.where(GP > 0, 10.0, np.nan)); pf = np.minimum(pf, 10.0)
        rf = np.where(DD > 0, S / DD, np.where(S > 0, 50.0, np.nan)); rf = np.minimum(rf, 50.0)
    pf[C < 5] = np.nan; rf[C < 5] = np.nan
    ok = (C >= 15) & (C / max(effy, 1e-9) >= 10) & (W >= -1000) & (S > 0)
    res = {}
    for met, how in VARS:
        v = pf if met == 'PF' else rf
        if how == '周辺':
            fin = np.isfinite(v); num = NB @ np.where(fin, v, 0); den = NB @ fin.astype(np.float32)
            with np.errstate(all='ignore'): v = np.where(den > 0, num / den, np.nan)
        sc = np.where(ok, np.nan_to_num(v, nan=-np.inf), -np.inf)
        res[(met, how)] = int(np.argmax(sc)) if np.isfinite(sc.max()) else -1
    return res

if __name__ == '__main__':
    G = M.groupby(['観察', '入る']).indices
    CAND = []; FT = []; sid_ = 0
    for (ob, en), idx in G.items():
        idx = idx[np.argsort(TE[idx], kind='stable')]
        st, P = prefix_stats(idx); t0 = TE[idx[0]]
        rules = {}
        for y in YEARS:
            effy = (BND[y] - t0) / (365.25 * 1440)
            rules[y] = choose(st[y], effy) if P[y] > 0 else {v: -1 for v in VARS}
        for v in VARS:
            row = dict(形=sid_, 観察=ob, 入る=en, 指標=v[0], 選び方=v[1])
            for y in YEARS:
                k = rules[y][v]; row[f'k{y}'] = k
                if y == 2027 or k < 0: continue
                q, e = divmod(k, NE); w = idx[(YR[idx] == y) & (QL[idx] >= q)]
                x = np.asarray(R[w, e], np.float32); ok = ~np.isnan(x)
                for r_, val in zip(w[ok], x[ok]): FT.append((sid_, v[0], v[1], y, int(SID[r_]), int(TE[r_]), float(val), int(r_), int(e)))
            CAND.append(row)
        sid_ += 1
        if sid_ % 25 == 0: print(sid_, len(G), flush=True)
    C = pd.DataFrame(CAND); FTd = pd.DataFrame(FT, columns=['形', '指標', '選び方', '年', 'sid', 'te', '損益', 'row', 'e'])
    C.to_pickle(X + 'XC.pkl'); FTd.to_pickle(X + 'XFT.pkl'); print(len(C), len(FTd))
