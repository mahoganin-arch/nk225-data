# 逆張り売りのパターン拡張の結果 → out/Y10_寄り天寄り底_逆張り売りのパターン拡張.xlsx
import pickle, numpy as np, pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
X = '/home/claude/yt/outx/'; F = '/home/claude/yt/out/Y10_寄り天寄り底_逆張り売りのパターン拡張.xlsx'
XN = pickle.load(open(X + 'xnow.pkl', 'rb')); XS = pickle.load(open(X + 'xsum.pkl', 'rb'))
T = XN['T']; SUMM = XN['SUMM']; NOW = XN['NOW']; A = XS['A']; BASE = XS['BASE']; P = XS['P']
FONT = 'Arial'; HEAD = PatternFill('solid', fgColor='DDE4EE'); thin = Side(style='thin', color='BBBBBB'); BOX = Border(top=thin, bottom=thin, left=thin, right=thin)
GOOD = PatternFill('solid', fgColor='E3F1E3'); BAD = PatternFill('solid', fgColor='FBE3E1')
wb = Workbook(); wb.remove(wb.active)
def fmt(c):
    c = str(c)
    if '割合' in c or '勝率' in c: return '0%'
    if 'PF' in c or 'RF' in c: return '0.00'
    if '平均' in c: return '0.0'
    return '#,##0;-#,##0'
def sheet(name, title, notes=()):
    ws = wb.create_sheet(name); ws['A1'] = title; ws['A1'].font = Font(name=FONT, bold=True, size=13); r = 2
    for n in notes: ws.cell(r, 1, n).font = Font(name=FONT, size=10, color='555555'); r += 1
    return ws, r + 1
def table(ws, r, df, widths=None, wrap=(), freeze=1, color_col=None):
    for j, c in enumerate(df.columns, 1):
        x = ws.cell(r, j, str(c)); x.font = Font(name=FONT, bold=True, size=10); x.fill = HEAD; x.border = BOX; x.alignment = Alignment(wrap_text=True, vertical='center')
    ws.row_dimensions[r].height = 40
    for i, row in enumerate(df.itertuples(index=False), r + 1):
        for j, v in enumerate(row, 1):
            c = df.columns[j - 1]
            if isinstance(v, np.generic): v = v.item()
            if isinstance(v, float) and np.isnan(v): v = None
            if isinstance(v, float) and np.isinf(v): v = '∞'
            x = ws.cell(i, j, v); x.border = BOX
            x.font = Font(name=FONT, size=10, color='C00000' if isinstance(v, (int, float)) and not isinstance(v, bool) and v < 0 else '000000')
            x.alignment = Alignment(wrap_text=c in wrap, vertical='top')
            if isinstance(v, (int, float)) and not isinstance(v, bool): x.number_format = fmt(c)
            if color_col and c == color_col and isinstance(v, (int, float)): x.fill = GOOD if v > 0 else BAD
    if widths:
        for j, w in enumerate(widths, 1): ws.column_dimensions[get_column_letter(j)].width = w
    ws.freeze_panes = ws.cell(r + 1, freeze + 1); return r + len(df) + 2
def kv(ws, r, L, w=(26, 120)):
    for k, v in L:
        ws.cell(r, 1, k).font = Font(name=FONT, bold=True, size=10); c = ws.cell(r, 2, v); c.font = Font(name=FONT, size=10); c.alignment = Alignment(wrap_text=True, vertical='top'); r += 1
    ws.column_dimensions['A'].width = w[0]; ws.column_dimensions['B'].width = w[1]; return r + 1
YC = [str(y) for y in range(2019, 2027)]

ws, r = sheet('説明と結論', '寄り天・寄り底：逆張り売りのパターン拡張（2026-10-18）')
r = kv(ws, r, [
    ('対象', '日中 8:45 からの先物が上げた日に CFD を売る（逆張り売り）。条件（指標）は付けない。コストは毎回13円。1枚＝68,800円換算'),
    ('増やしたパターン', '観察5（8:45→9:00/9:05/9:10/9:15/9:30）× 入る50通り（元24＋新しい26：待つ10・15・30分、上に指値0.1・0.2・0.3%、安値割れ2、天井の更新が10・20・30分止まる、15分・60分の平均足の陰転、15分が陰線のときの1分・5分の陰転、15分RSI70割れ、1分・5分RSI80割れ、遅行線の下抜け（終値どうし／26本前の安値）1・5・15分、転換線割れ5・15分）＝250の形。強さ7段（全部／上位50・33・20・15・10・5%）。手じまい 2,151通り（利確：%・動きの倍・寄り値までの戻し・前日終値・夜間終値・RSI・平均足・前の足・遅行線の上抜け／損切り：%・動きの倍・観察中の高値＋0.05〜0.2%・建値移動・追従／時間：15分〜引け）'),
    ('照合', '元からある手じまいでは元のエンジンと一致（最大の差0.97円＝保存の丸め）。新しい手じまい4種類を足ごとのループと照合して一致（最大の差0.92円）'),
    ('評価', '2019〜2026年の本当の前向き。各年のルール（強さ×手じまい）はその年より前のデータで選ぶ。選ぶ期間で15件以上・最悪の1回 −1,000円以上（PF・RFで選ぶときは年10件以上・合計プラスも）'),
])
ws.cell(r, 1, '結論').font = Font(name=FONT, bold=True, size=12); r += 1
r = kv(ws, r, [
    ('1. パターンを増やしても精度は上がらなかった', 'PF・合計÷最大DD で選んだ 1,000通り（250形×4つの選び方）のうち、今の中心の形（9:05・上位10%・利確なし・損切り0.8%・240分）の前向きの合計÷最大DD（5.8）を上回るものは0件、PF（1.50）を上回るものは0.7%'),
    ('2. 選ぶ指標は「1回平均」が良い（PF・RF は選ぶのに向かない）', '同じ形・同じ格子で、選ぶ期間の PF や RF の最良を選ぶと、前向きで合計がプラスになる形は28〜35%。1回平均の最良を選ぶと46〜51%。PF・RF は件数が少ない設定や偶然勝った設定を選びやすい。PF・RF は「評価に使う」指標として使い、「選ぶ」のは1回平均がよい'),
    ('3. 効いているのは観察の時刻', '8:45→9:00・9:05 の形は、前向きの合計がプラスの割合が73〜92%（中央 +3,400〜+5,400円）。9:10〜9:30 は12〜43%で、多くがマイナス'),
    ('4. 新しい入り方は上積みにならない', '9:00・9:05 の中で、元からある入り方は92%がプラス、新しい入り方は73%（全部の格子）。指値・待つ・遅行線・上位足の平均足などは、元の入り方を上回らない'),
    ('5. 手じまいを増やす効果は小さい', '元からある入り方では、全部の格子で PF の中央 1.25→1.27、合計÷最大DD の中央 1.45→1.64 と少し良くなる一方、合計の中央は 5,429→4,921円 と少し減る'),
    ('6. 何度も選ばれる形', '今のデータで選ぶと、9:05 の形の多くで「上位10%・利確なし・損切り0.8%・240分」が選ばれる（入り方を変えても同じ）。9:00 では「上位5%・5分RSI40／60分平均足の陽転・引けまで」が多い'),
    ('7. 2段目（形を前向きの記録で選ぶ）も効き目は弱い', '各年の初めに、それまでの前向きが良い形を選んで口座で動かすと、PF・RF で選ぶとほぼマイナス。過去の合計で選ぶとプラスだが、2024年がマイナスで2026年の比重が大きい'),
    ('8. 注意', '今の中心の形の数字（+14,507円）自体も、選び方の細かい違いで変わる（強さの段の切り方を変えると、同じ形が +3,299〜+13,958円）。「9:00・9:05 で強く上げたら売る」という現象は安定しているが、1つの設定の数字は過信しない'),
])

s = SUMM[(SUMM.指標 == '平均') & (SUMM.選び方 == '単点')]
ws, r = sheet('観察と入り方', '観察の時刻・入り方の種類ごとの前向き（1回平均で選ぶ・単点）', ['形ごとに2019〜2026年の本当の前向きの合計を出し、その中央値などを並べた'])
table(ws, r, s[['観察の範囲', '入る形の種類', '格子', '形の数', '合計プラスの割合', '合計_中央', 'PF_中央', 'RF_中央'] + [f'{y}_中央' for y in range(2019, 2027)]], widths=[12, 12, 13, 8, 12, 11, 9, 9] + [10] * 8)

S2 = T.groupby(['格子', '指標', '選び方']).agg(形の数=('合計', 'size'), 合計プラスの割合=('合計', lambda z: (z > 0).mean()), 合計_中央=('合計', 'median'), PF_中央=('PF', lambda z: z.clip(upper=5).median()), RF_中央=('RF', lambda z: z.clip(upper=20).median())).reset_index()
S2['選ぶ指標'] = S2.指標.map({'平均': '1回平均', 'PF': 'PF', 'RF': '合計÷最大DD'})
b = T[(T.観察 == '8:45→9:05') & (T.入る == '0')][['格子', '指標', '選び方', '件数', '合計', 'PF', 'RF', '最大DD']].copy(); b['指標'] = b.指標.map({'平均': '1回平均', 'PF': 'PF', 'RF': '合計÷最大DD'})
ws, r = sheet('選ぶ指標の比較', '選ぶ指標（1回平均・PF・合計÷最大DD）と手じまいの格子の比較（250形、2019〜2026年の本当の前向き）',
              ['元に近い格子＝強さ5段・% と倍の利確損切り・元の時間・元の指標手じまい（499通り）。全部の格子＝強さ7段・2,151通り'])
r = table(ws, r, S2[['格子', '選ぶ指標', '選び方', '形の数', '合計プラスの割合', '合計_中央', 'PF_中央', 'RF_中央']], widths=[13, 14, 8, 8, 12, 11, 9, 9])
ws.cell(r - 1, 1, '今の中心の形（8:45→9:05・入る0）だけで見ると').font = Font(name=FONT, bold=True); r += 1
r = table(ws, r, b.rename(columns={'指標': '選ぶ指標', 'RF': '合計÷最大DD'}))
ws.cell(r - 1, 1, f"参考：元のエンジン（強さ5段・506通り・1回平均・周辺）の同じ形：件数 {BASE['全_件数']}・合計 {BASE['全_合計']:,.0f}円・PF {BASE['全_PF']:.2f}・合計÷最大DD {BASE['全_RF']:.2f}").font = Font(name=FONT, size=10)

n = NOW[NOW.格子 == '全部の格子'].sort_values('合計', ascending=False)
cols = ['観察', '入る', '今の強さ', '手じまい群', '利確', '損切り', '時間', '件数', '合計', 'PF', 'RF', '最大DD'] + YC
ws, r = sheet('9時台の形と今のルール', '8:45→9:00・9:05 の形（100）：本当の前向きの成績と、これから使うルール（全部の格子・1回平均で選ぶ・単点）',
              ['今の強さ・利確・損切り・時間＝2017〜2026/10/8 のデータで選んだルール。成績＝2019〜2026年の本当の前向き（各年はその年より前で選んだルール）', '上位の形は100の中から結果を見て並べたもの。1つの形の数字は過信しない'])
table(ws, r, n[cols].rename(columns={'RF': '合計÷最大DD'}), widths=[11, 8, 9, 10, 18, 14, 6, 7, 10, 7, 9, 9] + [9] * 8, freeze=2, color_col='合計')
n2 = NOW[NOW.格子 == '元に近い格子'].sort_values('合計', ascending=False)
ws, r = sheet('9時台の形（元に近い格子）', '同じ100の形を、元に近い格子（499通り）で選んだ場合')
table(ws, r, n2[cols].rename(columns={'RF': '合計÷最大DD'}), widths=[11, 8, 9, 10, 18, 14, 6, 7, 10, 7, 9, 9] + [9] * 8, freeze=2, color_col='合計')

a = A.sort_values('全_RF', ascending=False)
c2 = ['観察', '入る', '指標', '選び方', '全_件数', '全_勝率', '全_PF', '全_平均', '全_平均_20円', '全_合計', '全_最大DD', '全_RF', '全_最悪', 'プラスの年', '5件以上の年', '今の強さ', '今の手じまい群', '今の利確', '今の損切り', '今の時間'] + YC
ws, r = sheet('PF・RFで選んだ全1000', 'PF・合計÷最大DD で選んだ 250形×4つの選び方 の本当の前向き（全部の格子）', ['指標＝選ぶ指標（PF／RF＝合計÷最大DD）。全_＝2019〜2026年'])
table(ws, r, a[c2], widths=[11, 8, 5, 6] + [9] * 11 + [9, 10, 14, 14, 6] + [9] * 8, freeze=4, color_col='全_合計')

PP = P.copy(); PP['選ぶ指標'] = PP.選ぶ指標.replace({'RF': '合計÷最大DD'})
ws, r = sheet('2段目の口座', '2段目も前向き：各年の初めに、それまでの前向き（2019〜前年）の PF・合計÷最大DD が良い形を選び、同じ向き2本で動かす（2021〜2026）')
table(ws, r, PP[['選ぶ指標', '形の数', '件数', '勝率', 'PF', '平均', '合計', '最大DD', 'RF', '2021', '2022', '2023', '2024', '2025', '2026']].rename(columns={'RF': '合計÷最大DD'}), widths=[24, 7, 7, 7, 7, 8, 10, 10, 10] + [10] * 6, color_col='合計')
wb.save(F); print(F)
