# 切り分け：手じまいの格子（元に近い／全部）× 選ぶ指標（1回平均・PF・RF）× 単点・周辺 で、本当の前向き（2019〜2026）を比べる
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/chk')
import xeval as xv
from xeval import M, R, EXD, NE, NQ, NK, QL, YR, TE, SID, NB, YEARS, BND, prefix_stats
X = xv.X
# 元に近い格子：強さ 全部/50/33/20/10%（0,1,2,3,5）、値段は (なし|%)×(なし|%) と (なし|倍)×(なし|倍)、時間は元の7つ、指標は RSI・平均足・前足で損切り なし/0.3/0.5・時間 120/C
tpT = EXD.利確型.values; slT = EXD.損切り型.values; tm = EXD.時間.values; grp = EXD.群.values
oldE = ((grp == '値段') & ((np.isin(tpT, ['なし', '%']) & np.isin(slT, ['なし', '%'])) | (np.isin(tpT, ['なし', '倍']) & np.isin(slT, ['なし', '倍']))) & ~np.isin(tm, ['90', '180'])) | \
       ((grp == '指標') & np.isin(tpT, ['指標:RSI', '指標:HA', '指標:前足']) & np.isin(EXD.損切り.values, ['None', '0.3', '0.5']) & np.isin(tm, ['120', 'C']))
oldQ = np.isin(np.arange(NQ), [0, 1, 2, 3, 5])
ALLOW = {'元に近い格子': (oldQ[:, None] & oldE[None, :]).ravel(), '全部の格子': np.ones(NK, bool)}
METS = ['平均', 'PF', 'RF']
print('元に近い手じまい', int(oldE.sum()), '／ 全部', NE)
def choose2(st, effy, allow):
    S, C, GP, GL, W, DD = (st[k] for k in ('S', 'C', 'GP', 'GL', 'W', 'DD'))
    with np.errstate(all='ignore'):
        mean = np.where(C > 0, S / np.maximum(C, 1), np.nan)
        pf = np.minimum(np.where(GL > 0, GP / GL, np.where(GP > 0, 10.0, np.nan)), 10.0)
        rf = np.minimum(np.where(DD > 0, S / DD, np.where(S > 0, 50.0, np.nan)), 50.0)
    for v in (pf, rf): v[C < 5] = np.nan
    base_ok = (C >= 15) & (W >= -1000) & allow
    res = {}
    for met, v0 in (('平均', mean), ('PF', pf), ('RF', rf)):
        ok = base_ok & ((C / max(effy, 1e-9) >= 10) & (S > 0) if met != '平均' else True)   # 平均は元のやり方（15件・最悪のみ）
        v = np.where(allow, v0, np.nan)
        for how in ('単点', '周辺'):
            if how == '周辺':
                fin = np.isfinite(v); num = NB @ np.where(fin, v, 0); den = NB @ fin.astype(np.float32)
                with np.errstate(all='ignore'): vv = np.where(den > 0, num / den, np.nan)
            else: vv = v
            sc = np.where(ok, np.nan_to_num(vv, nan=-np.inf), -np.inf)
            res[(met, how)] = int(np.argmax(sc)) if np.isfinite(sc.max()) else -1
    return res
G = M.groupby(['観察', '入る']).indices; OUT = []
for n_, ((ob, en), idx) in enumerate(G.items()):
    idx = idx[np.argsort(TE[idx], kind='stable')]; st, P = prefix_stats(idx); t0 = TE[idx[0]]
    for gname, allow in ALLOW.items():
        rules = {y: (choose2(st[y], (BND[y] - t0) / (365.25 * 1440), allow) if P[y] > 0 else None) for y in YEARS if y <= 2026}
        for met in METS:
            for how in ('単点', '周辺'):
                v = []; yy = []
                for y in range(2019, 2027):
                    if rules[y] is None: continue
                    k = rules[y][(met, how)]
                    if k < 0: continue
                    q, e = divmod(k, NE); w = idx[(YR[idx] == y) & (QL[idx] >= q)]
                    x = np.asarray(R[w, e], np.float32); ok = ~np.isnan(x); v.append(x[ok]); yy.append(np.full(ok.sum(), y))
                v = np.concatenate(v) if v else np.array([]); yy = np.concatenate(yy) if yy else np.array([])
                if len(v):
                    eq = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, eq])[1:] - eq).max(); gl = -v[v < 0].sum()
                    s = dict(件数=len(v), 合計=v.sum(), PF=v[v > 0].sum() / gl if gl > 0 else np.inf, 最大DD=dd, RF=v.sum() / dd if dd > 0 else np.inf, 平均=v.mean())
                else: s = dict(件数=0, 合計=0.0, PF=np.nan, 最大DD=0.0, RF=np.nan, 平均=np.nan)
                OUT.append(dict(観察=ob, 入る=en, 格子=gname, 指標=met, 選び方=how, **s, **{str(y): v[yy == y].sum() for y in range(2019, 2027)}))
    if (n_ + 1) % 50 == 0: print(n_ + 1, flush=True)
T = pd.DataFrame(OUT); T.to_pickle(X + 'xeval2.pkl')
T['RF_c'] = T.RF.clip(upper=20); T['PF_c'] = T.PF.clip(upper=5)
S = T.groupby(['格子', '指標', '選び方']).agg(形の数=('件数', 'size'), 合計プラスの割合=('合計', lambda z: (z > 0).mean()), 合計_中央=('合計', 'median'), 平均_中央=('平均', 'median'),
                                          PF_中央=('PF_c', 'median'), RF_中央=('RF_c', 'median'), 件数_中央=('件数', 'median')).reset_index()
pd.set_option('display.width', 250); print(S.round(2).to_string(index=False))
b = T[(T.観察 == '8:45→9:05') & (T.入る == '0')]; print(b[['格子', '指標', '選び方', '件数', '合計', 'PF', 'RF', '最大DD']].round(2).to_string(index=False))
