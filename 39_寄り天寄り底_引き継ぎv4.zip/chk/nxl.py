# 手法チェックの結果を Excel にまとめる → out/Y6_寄り天寄り底_手法チェック.xlsx
import os, numpy as np, pandas as pd
from scipy.stats import spearmanr
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
O = '/home/claude/yt/out/'; N = '/home/claude/yt/outn/'; F = O + 'Y6_寄り天寄り底_手法チェック.xlsx'
FONT = 'Arial'; HEAD = PatternFill('solid', fgColor='DDE4EE'); BAD = PatternFill('solid', fgColor='FBE3E1'); GOOD = PatternFill('solid', fgColor='E3F1E3')
thin = Side(style='thin', color='BBBBBB'); BOX = Border(top=thin, bottom=thin, left=thin, right=thin)
wb = Workbook(); wb.remove(wb.active)

def sheet(name, title, note=None):
    ws = wb.create_sheet(name); ws['A1'] = title; ws['A1'].font = Font(name=FONT, bold=True, size=13)
    r = 2
    if note:
        for line in note if isinstance(note, list) else [note]:
            ws.cell(r, 1, line).font = Font(name=FONT, size=10, color='555555'); r += 1
    return ws, r + 1

def table(ws, r, df, widths=None, fmt=None, wrap=False):
    for j, c in enumerate(df.columns, 1):
        x = ws.cell(r, j, str(c)); x.font = Font(name=FONT, bold=True, size=10); x.fill = HEAD; x.border = BOX; x.alignment = Alignment(wrap_text=True, vertical='center')
    for i, row in enumerate(df.itertuples(index=False), r + 1):
        for j, v in enumerate(row, 1):
            if isinstance(v, (np.floating, float)) and np.isnan(v): v = None
            if isinstance(v, np.generic): v = v.item()
            x = ws.cell(i, j, v); x.font = Font(name=FONT, size=10); x.border = BOX
            x.alignment = Alignment(wrap_text=wrap, vertical='top')
            if fmt and df.columns[j - 1] in fmt: x.number_format = fmt[df.columns[j - 1]]
            elif isinstance(v, float): x.number_format = '#,##0;-#,##0'
    if widths:
        for j, w in enumerate(widths, 1): ws.column_dimensions[get_column_letter(j)].width = w
    ws.freeze_panes = ws.cell(r + 1, 1)
    return r + len(df) + 2

# ---------------------------------------------------------------- 1. 説明
ws, r = sheet('説明', '寄り天・寄り底：手法のチェック（2026-10-17）')
L = [('このファイル', 'これまでの分析手法（引き継ぎ v3 まで）のリスク・抜け漏れを、計算で確かめた結果。Pine の設計には進んでいない'),
     ('円', '損益は 1枚＝68,800円換算（値動き÷値段×68,800）。13pt のコストを引いた後（「コスト統一」のシートは毎回13円）'),
     ('元の手順', '引き継ぎ v3 までのやり方。候補選び（入る形・ふるい・残す基準・重なり）に2026年までのデータを使い、案3と運用だけを年ごとに前のデータで行う'),
     ('本当の前向き', '確かめる年 t ごとに、候補選びの全段階（逆張りの入る形の絞り込み → ふるい → 評価・残す → 重なり → 案3 → 運用）を t 年より前のデータだけで行い、t 年を売買した成績'),
     ('評価の形（本当の前向き）', 't 年より前に確かめられる部分だけを使う。例：2024年の判断では「22-23→24-26」は確かめる年が無いので除き、4つのうち3つ以上プラス・中央+20円・年10件で残す'),
     ('集まり・本数・方針', '全部＝4分類（逆張り売り・逆張り買い・順張り売り・順張り買い）、売りのみ、買いのみ。本数＝案3の上位N本。方針 A1＝先着1本、C1＝同じ向き2本、D1＝両建て＋2本目'),
     ('再現', '元の手順の数字（全部・5本・C1 で 45,068.9円、売りのみ 23,984.4円、買いのみ 11,708.4円）を書き直したコード（nest.py）で完全に再現してから比べている'),
     ('シート', '指摘一覧／前向き_13pt／前向き_コスト統一／偶然の目安／翌年への持続／コストの重さ／売買の現実性／偏り／設定48通り／評価の形の重なり／問題が小さかったもの／窓埋めの確認に必要なファイル')]
for k, v in L:
    ws.cell(r, 1, k).font = Font(name=FONT, bold=True, size=10); c = ws.cell(r, 2, v); c.font = Font(name=FONT, size=10); c.alignment = Alignment(wrap_text=True, vertical='top'); r += 1
ws.column_dimensions['A'].width = 22; ws.column_dimensions['B'].width = 110

# ---------------------------------------------------------------- 2. 指摘一覧
FLAT = os.path.exists(N + 'neval_flat.pkl')
E13 = pd.read_pickle(N + 'neval.pkl')
def get(E, pn, Nn, pol, lab): return E[(E.集まり == pn) & (E.N == Nn) & (E.方針 == pol) & (E.手順 == lab)].iloc[0]
a = get(E13, '全部', 5, 'C1', '元の手順'); b = get(E13, '全部', 5, 'C1', '本当の前向き')
flat_txt = ''
if FLAT:
    EF = pd.read_pickle(N + 'neval_flat.pkl'); af = get(EF, '全部', 5, 'C1', '元の手順'); bf = get(EF, '全部', 5, 'C1', '本当の前向き')
    flat_txt = f'コスト統一でも：元の手順 {af.合計:+,.0f}円 → 本当の前向き {bf.合計:+,.0f}円'
I = [
 ('A', '最重要', '7章 1・5', '候補選びに確かめる期間のデータを使っている', '入る形の絞り込み・ふるい（後半2022〜26のt）・残す基準（5つの形は2022〜26の成績）・重なりのまとめが、すべて2026年までのデータを使う。前向き検証はその年の結果を見て残した候補から選んでいる',
  f'全部・5本・同じ向き2本：元 {a.合計:+,.0f}円 → 本当の前向き {b.合計:+,.0f}円（2024 {b["2024"]:+,.0f}／2025 {b["2025"]:+,.0f}／2026 {b["2026"]:+,.0f}）。試した設定はすべてマイナス。最大DD {a.最大DD:,.0f} → {b.最大DD:,.0f}円。{flat_txt}',
  '手順全体を書き直して元の数字を完全再現 → 年ごとに t より前のデータだけでやり直し（シート「前向き_13pt」）', '評価を「入れ子の前向き」に変える。元の手順の前向きの数字は採用の判断に使わない'),
 ('B', '重大', '7章 1・2', '偶然でも大きなプラスが出る作り', '今の偶然の目安（ynull）はふるいも案3も通さないので比べ方が公平でない',
  'でたらめな条件（日ごとに続きやすい）を元とまったく同じ手順に通すと、全部 +24,470円・売りのみ +15,711円・買いのみ +10,448円。ふるい通過率・残る数も本物と同程度', '本物の区分を同じ該当率の AR(1) 乱数条件に置き換え、全段階を通す（シート「偶然の目安」）', '偶然の目安は同じ手順を全部通して作る。種を5〜10に増やして幅を見る'),
 ('C', '重大', '7章 4', '前向きの成績は翌年に続かない', '案3は前向きRF・選ぶ期間の平均の順位で選ぶが、その順位が翌年を当てるかは確かめていない',
  '候補ごとの「前の記録」と「その年」の順位相関 −0.29〜+0.17（12組中10組マイナス）。記録の上位10%の成績は候補全体とほぼ同じ', '候補ごとに t 年より前の記録と t 年の1回平均の順位相関（シート「翌年への持続」）', '順位で上位N本を選ぶ方法は、本当の前向きで効き目が確かめられるまで使わない'),
 ('D', '重大（新規）', '7章 19', 'コストの重さが年によって約3倍違う', '13pt固定を値段で割って円にしているので、日経の値上がりでコストの重さが下がり続けた',
  '1回あたりのコスト：2017年 44.0円 → 2026年 14.7円。控除前の損益は前半・後半ともほぼ0（例：逆張り売り 前半 +1.5／後半 +1.3円、控除後は −38／−23円）。「相場の性質が変わった」の多くはこれで説明できる', '年ごとのコストと控除前後の損益（シート「コストの重さ」）', '毎回同じ重さ（13pt÷今の値段＝13円）に統一して評価した。元の手順では成績が上がる（全部・5本・2本 +56,362円）が、本当の前向きでは −5,795円で結論は同じ。売り側は 売りのみ・3本 +5,230円、条件なし・売りのみ・5本 +4,665円 と0以上が多く、買い側はすべてマイナス（シート「前向き_コスト統一」）'),
 ('E', '中', '7章 7', 'コストの感度', '寄り直後のスプレッドの広がり・損切りのすべりは未考慮',
  '元の手順の売買で、20pt −13%、25pt −23%、30pt −33%。2024年は 6,245 → 482円', '同じ売買のコストを変えて計算（シート「売買の現実性」）', '選ぶ段階から 20pt でも残るものに絞る'),
 ('F', '中', '7章 20', '2026年と少ない日への偏り', '成績の大半が2026年と一部の日に集中',
  '2026年が合計の60%。売買した398日のうち上位10日で利益の50%（9日が2026年、すべて2本持ちの日）。2本目だけで15,069円', '日ごとの損益を並べる（シート「偏り」）', '成績は年ごと・上位の日を除いた数字でも見る。同じ向き2本はリスク2倍として扱う'),
 ('G', '中（新規）', '—', '設定の選び方も当てはめ', '集まり6×本数2×方針4＝48通りを比べてから選んでいる',
  '48通りの合計：最小 +1,636／中央 +12,248／最大 +47,521円。採用の設定（+45,069円）は最良に近い。本数3なら +25,978円', 'yunion の全設定を並べる（シート「設定48通り」）', '方針・本数・集まりは成績を見る前に決める'),
 ('H', '小', '7章 3', '5つの評価の形は独立でない', 'どの形も2024〜26年を確かめる年に含む',
  '形どうしの相関 0.28〜0.72。全条件の62%が「3つ以上プラス」を満たす（5つともプラスは25%）', '全条件の形ごとの成績の相関（シート「評価の形の重なり」）', '「3つ以上プラス」に頼らず、確かめる年が重ならない評価を主にする'),
 ('I', '小', '7章 16', '祝日取引日', '現物の寄りが無い日も含めている', '元の手順の売買で祝日取引日は21件・−1,800円（1回 −86円、他は +84円）。件数が少なく偶然の可能性あり', 'シート「偏り」', '除く案を検討（寄り天・寄り底の前提が違う日）'),
]
ws, r = sheet('指摘一覧', '指摘一覧（重大な順）', '歪みの大きさは確かめた値。7章＝引き継ぎ v3 の「リスク・抜け漏れの候補」の番号')
df = pd.DataFrame(I, columns=['記号', '重さ', '7章', '指摘', '何が問題か', '歪みの大きさ（確かめた値）', '確かめ方', '直し方'])
r = table(ws, r, df, widths=[6, 11, 9, 26, 45, 60, 38, 38], wrap=True)
for i in range(len(df)):
    ws.cell(4 + i + 1, 2).fill = BAD if df.重さ[i].startswith(('最重要', '重大')) else PatternFill()

# ---------------------------------------------------------------- 3. 前向き（13pt／コスト統一）
def fwd_sheet(name, E, title, note):
    ws, r = sheet(name, title, note)
    cols = ['集まり', 'N', '方針', '元_2024', '元_2025', '元_2026', '元_合計', '元_最大DD', '本当_2024', '本当_2025', '本当_2026', '本当_合計', '本当_最大DD', '差（本当−元）']
    rows = []
    for (pn, Nn, pol), g in E.groupby(['集まり', 'N', '方針'], sort=False):
        o = g[g.手順 == '元の手順'].iloc[0]; t = g[g.手順 == '本当の前向き'].iloc[0]
        rows.append([pn, int(Nn), {'A1': '先着1本', 'C1': '同じ向き2本', 'D1': '両建て＋2本目'}[pol], o['2024'], o['2025'], o['2026'], None, o.最大DD, t['2024'], t['2025'], t['2026'], None, t.最大DD, None])
    df = pd.DataFrame(rows, columns=cols); r0 = r
    r = table(ws, r, df, widths=[18, 5, 14] + [11] * 11)
    for i in range(len(df)):
        rr = r0 + 1 + i
        ws.cell(rr, 7, f'=SUM(D{rr}:F{rr})').number_format = '#,##0;-#,##0'
        ws.cell(rr, 12, f'=SUM(I{rr}:K{rr})').number_format = '#,##0;-#,##0'
        ws.cell(rr, 14, f'=L{rr}-G{rr}').number_format = '#,##0;-#,##0'
        for c in (7, 12, 14): ws.cell(rr, c).font = Font(name=FONT, size=10, bold=(c == 12)); ws.cell(rr, c).border = BOX
        v = df.loc[i, ['本当_2024', '本当_2025', '本当_2026']].sum()
        ws.cell(rr, 12).fill = GOOD if v > 0 else BAD
    return ws
fwd_sheet('前向き_13pt', E13, '元の手順と本当の前向き（2024〜26、13pt）', ['円。合計・差は式。本当の前向きの合計がプラスなら緑、マイナスなら赤',
          '「条件なし・…」は、条件（指標）を付けない候補（向き・売買・入る形だけ）から案3で選んだもの'])
if FLAT:
    fwd_sheet('前向き_コスト統一', EF, '元の手順と本当の前向き（2024〜26、コストを毎回13円に統一）',
              ['どの年もコストを 13pt÷今の値段（68,800）＝13円 にそろえて、候補選びからやり直した結果。元の手順も同じコストで選び直している'])

ws, r = sheet('前向きのまとめ', '本当の前向き（2024〜26）の合計がプラスだった設定の数', ['設定＝集まり×本数（3・5）×方針（先着1本・同じ向き2本・両建て＋2本目）。売りのみ・買いのみは2本目の方針が同じ結果になる'])
rows = []
for lab, E in [('13pt', E13)] + ([('コスト統一', EF)] if FLAT else []):
    t = E[E.手順 == '本当の前向き']
    for pn, g in t.groupby('集まり', sort=False):
        rows.append([lab, pn, len(g), int((g.合計 > 0).sum()), g.合計.min(), g.合計.median(), g.合計.max()])
table(ws, r, pd.DataFrame(rows, columns=['コスト', '集まり', '設定の数', 'プラスの数', '最小', '中央', '最大']), widths=[12, 20, 10, 10, 11, 11, 11])

# ---------------------------------------------------------------- 4. 偶然の目安
ws, r = sheet('偶然の目安', '公平な偶然の目安：でたらめな条件を元とまったく同じ手順に通す（13pt、種1つ）',
              ['本物の区分を、同じ該当率で「日ごとに続きやすい」でたらめな条件（セッションの並びで AR(1)・係数0.9）に置き換え、ふるい→評価・残す→重なり→案3→運用まで同じ手順'])
df = pd.DataFrame([['ふるい通過（逆張り売り）', 215, 233], ['ふるい通過（逆張り買い）', 298, 265], ['ふるい通過（順張り売り）', 180, 204], ['ふるい通過（順張り買い）', 243, 271],
                   ['残る候補（単点・周辺の別）', 23041, 20256], ['前向き 全部・5本・同じ向き2本', 45069, 24470], ['　2024年', 6245, -3793], ['　2025年', 11924, 6544], ['　2026年', 26900, 21719],
                   ['前向き 売りのみ・5本・同じ向き2本', 23984, 15711], ['前向き 買いのみ・5本・同じ向き2本', 11708, 10448]], columns=['項目', '本物の条件（元の手順）', 'でたらめな条件（同じ手順）'])
table(ws, r, df, widths=[36, 22, 26])

# ---------------------------------------------------------------- 5. 翌年への持続
C = pd.read_pickle(O + 'YC.pkl'); FT = pd.read_pickle(O + 'YCT.pkl'); C['分類'] = C.向き + C.売買; rows = []
for t in (2024, 2025, 2026):
    a_ = FT[FT.年 < t].groupby('cid').損益.agg(['size', 'mean']); b_ = FT[FT.年 == t].groupby('cid').損益.agg(['size', 'mean'])
    j = a_.join(b_, lsuffix='_前', rsuffix='_t', how='inner'); j = j[(j.size_前 >= 20) & (j.size_t >= 5)].join(C.set_index('cid')[['分類', '選ぶ期間平均_%d' % t]])
    for k, g in j.groupby('分類'):
        top = g.sort_values('mean_前', ascending=False).head(max(1, len(g) // 10))
        rows.append([t, k, len(g), spearmanr(g.mean_前, g.mean_t).statistic, spearmanr(g['選ぶ期間平均_%d' % t], g.mean_t).statistic, g.mean_t.mean(), top.mean_t.mean(), (g.mean_t > 0).mean()])
df = pd.DataFrame(rows, columns=['確かめる年', '分類', '候補数', '相関：前向き記録→その年', '相関：選ぶ期間の平均→その年', 'その年の1回平均（候補全体）', 'その年の1回平均（記録の上位10%）', 'その年プラスの割合'])
ws, r = sheet('翌年への持続', '候補の成績は翌年に続くか（元の手順の候補 23,041件）', ['相関は順位相関。記録20件以上・その年5件以上の候補。0に近いほど「当たらない」'])
table(ws, r, df, widths=[11, 12, 9, 20, 22, 20, 22, 16], fmt={'相関：前向き記録→その年': '0.00', '相関：選ぶ期間の平均→その年': '0.00', 'その年プラスの割合': '0%', 'その年の1回平均（候補全体）': '0.0', 'その年の1回平均（記録の上位10%）': '0.0'})

# ---------------------------------------------------------------- 6. コストの重さ
YM = pd.read_pickle(O + 'YM.pkl'); P = pd.read_pickle(O + 'P.pkl'); PM = P.m.values
e = P.open.values[np.minimum(np.searchsorted(PM, YM.te.values.astype('int64')), len(PM) - 1)]; cost = 13 / e * 68800; MN = np.load(O + 'YMN.npy')
d = pd.DataFrame(dict(年=YM.yr, 分類=YM.向き + YM.売買, cost=cost, net=MN, gross=MN + cost))
g = d.groupby('年').agg(値段=('cost', lambda z: 13 / z.mean() * 68800), コスト=('cost', 'mean')).reset_index()
nt = d.groupby(['年', '分類']).net.mean().unstack(); gr = d.groupby(['年', '分類']).gross.mean().unstack()
df = g.copy(); df['値段'] = df.値段.round(-2)
for k in nt.columns: df['控除後 ' + k] = nt[k].values
for k in gr.columns: df['控除前 ' + k] = gr[k].values
df['年'] = df.年.astype(str)
ws, r = sheet('コストの重さ', 'コスト13pt固定の重さ（円換算）と、控除前後の1回平均（506手じまいの平均、元の対象 130,658トレード）',
              ['控除前＝控除後＋その年のコスト。控除前はどの年もほぼ0で、前半と後半の差の多くはコストの重さの差', '値段は 13÷平均コスト×68,800 で逆算した平均の値段（目安）'])
table(ws, r, df, widths=[7, 9, 9] + [12] * 8, fmt={c: '0.0' for c in df.columns if c not in ('年', '値段')} | {'値段': '#,##0'})

# ---------------------------------------------------------------- 7. 売買の現実性
H = pd.read_pickle(N + 'real_H.pkl'); cols = ['損益', '損益_20pt', '損益_25pt', '損益_30pt', '損益_遅れ1分', '損益_遅れ2分', '損益_5分足']
names = ['13pt（元）', '20pt', '25pt', '30pt', '入るのが1分遅れ', '2分遅れ', '利確・損切りを5分足で判定']
df = H.groupby('集まり')[cols].sum().reindex(['全部', '売りのみ', '買いのみ']).reset_index(); df.columns = ['集まり（5本・同じ向き2本）'] + names
y = H[H.集まり == '全部'].groupby('年')[cols].sum().reset_index(); y.columns = ['全部の年別'] + names; y['全部の年別'] = y['全部の年別'].astype(str)
ws, r = sheet('売買の現実性', '元の手順の売買（2024〜26）で、コスト・入る遅れ・足の細かさを変えた合計（円）',
              ['5分足で判定：1回平均の差は −0.9円（約半数で値は変わるが偏りは小さい）。入る遅れは ±10%程度で向きは一定でない'])
r = table(ws, r, df, widths=[26] + [15] * 7); table(ws, r, y)

# ---------------------------------------------------------------- 8. 偏り
H2 = H[H.集まり == '全部'].copy(); YMn = pd.read_pickle(N + 'YM.pkl'); YF = pd.read_pickle(N + 'YF.pkl')
H2['日'] = YMn.t.dt.date.values[H2.row.values].astype(str); H2['寄りの動き%'] = YMn.x.values[H2.row.values] * 100
dd = H2.groupby('日').agg(損益=('損益', 'sum'), 本数=('損益', 'size'), 寄りの動き=('寄りの動き%', 'first')).sort_values('損益', ascending=False).reset_index()
s = [['合計', H2.損益.sum()], ['売買した日数', len(dd)], ['上位10日の合計', dd.損益.head(10).sum()], ['2026年の合計', H2[H2.年 == 2026].損益.sum()], ['2本目の合計', H2[H2.種類 == '2本目'].損益.sum()], ['2本目の件数', (H2.種類 == '2本目').sum()]]
for c in ('祝日取引中', 'SQ当日'):
    f = YF[c].values[H2.row.values] == 1; s += [[c + '：件数', int(f.sum())], [c + '：合計', H2.損益[f].sum()], [c + '：1回平均', H2.損益[f].mean()], [c + '以外：1回平均', H2.損益[~f].mean()]]
ws, r = sheet('偏り', '元の手順（全部・5本・同じ向き2本、2024〜26）の偏り', ['上位10日は日ごとの損益の大きい順'])
r = table(ws, r, pd.DataFrame(s, columns=['項目', '値']), widths=[24, 14, 8, 12])
table(ws, r, dd.head(15).rename(columns={'寄りの動き': '寄りの動き（%）'}), fmt={'寄りの動き（%）': '0.00'})

# ---------------------------------------------------------------- 9. 設定48通り
V = pd.read_pickle(O + 'YV.pkl')[['候補の集まり', 'N', '方針', '件数', '合計', '最大DD', '2024', '2025', '2026']].sort_values('合計', ascending=False)
V['方針'] = V.方針.map({'A1': '先着1本', 'B': '両建て', 'C1': '同じ向き2本', 'D1': '両建て＋2本目'})
ws, r = sheet('設定48通り', '元の手順の運用設定48通り（集まり6×本数2×方針4）の前向き合計', ['採用した「全部（4区分）・5本・同じ向き2本」は 48通りの中で2番目。中央は約12,000円'])
table(ws, r, V, widths=[24, 5, 14, 7, 11, 11, 11, 11, 11])

# ---------------------------------------------------------------- 10. 評価の形の重なり
T = pd.read_pickle(O + 'YE.pkl'); Fm = ['前半→後半_平均', '22-23→24-26_平均', 'WF後半_平均', 'WF全期間_平均', 'WF直近3年_平均']
cm = T[T.選び方 == '単点'][Fm].corr().round(2); cm.index = [x.replace('_平均', '') for x in cm.index]; cm.columns = cm.index; cm = cm.reset_index().rename(columns={'index': '評価の形'})
ws, r = sheet('評価の形の重なり', '5つの評価の形の成績の相関（評価した全条件、単点）', [f'全条件 {len(T):,} 行のうち 3つ以上プラス {(T.プラスの数 >= 3).mean():.0%}、5つともプラス {(T.プラスの数 == 5).mean():.0%}'])
table(ws, r, cm, widths=[16] + [14] * 5, fmt={c: '0.00' for c in cm.columns[1:]})

# ---------------------------------------------------------------- 11. 問題が小さかったもの
OK = [('先読み', '指標（yfeat）・入る判定（eng/eng2）・手じまい（eng/engt）をコードで確認。確定した足だけを使っている。日足出来高（OSE 1D）は 16:30/17:00 始まりの時刻で、使えるのは翌日の夜間の始まり以降なので問題なし。SQ値は SQ日 11:00 以降に使う扱い'),
      ('足の細かさ（7章 8）', '同じ売買を CFD 5分足で判定し直しても1回平均の差 −0.9円'),
      ('入る遅れ', '1分遅れ +47,682円、2分遅れ +40,934円（元 +45,069円）。±10%程度のぶれ'),
      ('利確の「触れたら約定」', 'バーが bid でスプレッドが一定（13pt以内）なら、13pt控除と打ち消し合い正しい計算（売り・買いとも）。13ptを超える時間帯だけ楽観的'),
      ('作り直した部分（7章 17）', 'Y5 の数字は完全に再現。元の窓埋めコードとの細部の差は未確認だが、結論への影響は小さい'),
      ('逆張りの入る形の選び方', 'nest.py の選び方で元の32通りと完全に一致'),
      ('その他', '1分足だけの指標の置き換え・強さの境目（2017〜21）・2026年の年換算（280/365）は問題なし')]
ws, r = sheet('問題が小さかったもの', '確かめて大きな問題が無かったもの')
table(ws, r, pd.DataFrame(OK, columns=['項目', '確かめた内容']), widths=[26, 120], wrap=True)

# ---------------------------------------------------------------- 12. 窓埋め
W = [('10_…', 'code/eng5.py・eng5f.py（5:55修正版）、an/s7cap.py', '5:55決済・上限管理'),
     ('11_…', 'code/eng6.py（先物基準の窓のエンジン）、an/s8fut.py・s8fixed.py', '先物基準の窓（63本の多くが先物基準）'),
     ('12_…・13_…', 'an/s9cal.py, s10scr.py, s10eval.py, s10sum.py、code/feat7.py', '指標・ふるい・評価'),
     ('14_〜21_…', 's11〜s18 の各段階（重なりでまとめる s12group など）', '重なり・案3・方向別'),
     ('22_…', 'an/s19dirscr.py, s19eval.py, s19sum.py', '買い売り別のふるい・評価（S16）'),
     ('23_〜25_…', 's21group.py, s22union.py, s24minus.py, s25narrow.py, s25pf.py, s26list.py、S26all.pkl', '重なり・案3・前向き・63本'),
     ('26_〜29_…', 'Pine 関連（s31〜s41）', '照合（今回は不要）')]
ws, r = sheet('窓埋めの確認に必要なファイル', '窓埋めを同じ方法（本当の前向き）で確かめるのに必要なファイル', ['GitHub（nk225-data）には 01・02・05・08・09 番の zip しか無く、S7 以降のコードが無い。番号は Project の doc から推定'])
table(ws, r, pd.DataFrame(W, columns=['zip（番号）', '中のスクリプト', '用途']), widths=[16, 70, 40], wrap=True)

wb.save(F); print(F)
