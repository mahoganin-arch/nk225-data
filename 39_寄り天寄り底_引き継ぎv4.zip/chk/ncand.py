# 今の採用候補（元の手順・13pt、上位5本、YNOW）を、窓埋めの「売買する候補63本」と同じ粒度で並べる → out/Y7_寄り天寄り底_今の候補一覧.xlsx
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/an')
from evalu import QS, QN
O = '/home/claude/yt/out/'
YM = pd.read_pickle(O + 'YM.pkl'); YR = np.load(O + 'YR.npy', mmap_mode='r'); YF = pd.read_pickle(O + 'YF.pkl')
BINS = pd.read_pickle(O + 'YBINS.pkl'); S0 = pd.read_pickle(O + 'YS.pkl'); EXd = pd.read_pickle(O + 'EXITS.pkl')['D']; nE = len(EXd)
NOW = pd.read_pickle(O + 'YNOW.pkl')[5].reset_index(drop=True)
C = pd.read_pickle(O + 'YC.pkl'); FT = pd.read_pickle(O + 'YCT.pkl')
P = pd.read_pickle(O + 'P.pkl'); PM = P.m.values; ENT = P.open.values[np.minimum(np.searchsorted(PM, YM.te.values.astype('int64')), len(PM) - 1)]
m2 = pd.read_pickle(O + 'E2_D_meta.pkl'); cutmap = {}
for ob, g in m2.drop_duplicates(['観察', 'sid']).groupby('観察'):
    a = np.abs(g.x.values)[g.t.dt.year.values <= 2021]; cutmap[ob] = [np.quantile(a, q) if q > 0 else 0 for q in QS]
QL = np.zeros(len(YM), np.int8); ax = np.abs(YM.x.values)
for ob, cuts in cutmap.items():
    w = YM.観察.values == ob
    for qi, c in enumerate(cuts): QL[w & (ax >= c)] = qi
LATE = set(S0[S0.後半のみ].指標); YRS = YM.yr.values
GI = YM.groupby(['向き', '売買', '観察', '入る']).indices

def cmask(side, bs, ind, kub, use):
    if ind == 'なし': return np.ones(len(YM), bool)
    keys, packed, nn = BINS[(side, bs, ind in LATE)]; i = keys.index((ind, kub)); m = np.unpackbits(packed[i])[:nn].astype(bool); return m if use == '入る' else ~m

def edges(side, bs, ind, kub):
    """区分の境目（2017〜21年のその向き・売買のデータ。後半のみの指標は2023年）"""
    if ind == 'なし': return ''
    base = (YM.向き.values == side) & (YM.売買.values == bs) & ((YRS == 2023) if ind in LATE else (YRS <= 2021))
    v = YF[ind].values.astype(float); vt = v[base & ~np.isnan(v)]
    f = lambda x: f'{x:.4g}'
    if kub.startswith('='): return f'値が {kub[1:]}'
    if kub.startswith('3分割'):
        q = np.quantile(vt, [1 / 3, 2 / 3]); return {'低': f'{f(q[0])} 未満', '中': f'{f(q[0])} 以上 {f(q[1])} 未満', '高': f'{f(q[1])} 以上'}[kub[-1]]
    if kub.startswith('5分割'):
        q = np.quantile(vt, [.2, .4, .6, .8]); k = int(kub[-1]); lo = q[k - 2] if k > 1 else None; hi = q[k - 1] if k < 5 else None
        return (f'{f(lo)} 以上' if lo is not None else '') + (' ' if lo is not None and hi is not None else '') + (f'{f(hi)} 未満' if hi is not None else '')
    lo, hi = np.quantile(vt, [.1, .9]); return f'{f(lo)} 以下' if kub == '下位10%' else f'{f(hi)} 以上'

def stats(v, extra=None):
    v = np.asarray(v, float)
    if len(v) == 0: return dict(件数=0)
    eq = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, eq])[1:] - eq).max(); gp = v[v > 0].sum(); gl = -v[v < 0].sum()
    return dict(件数=len(v), 勝率=(v > 0).mean(), PF=gp / gl if gl > 0 else np.inf, 平均=v.mean(), 合計=v.sum(), 最大DD=dd, RF=v.sum() / dd if dd > 0 else np.inf, 最悪=v.min(), 最良=v.max())

rows = []; yearly = []
for pr, r in enumerate(NOW.itertuples(), 1):
    side, bs = r.向き, r.売買
    idx = GI[(side, bs, r.観察, r.入る)]; m = cmask(side, bs, r.指標, r.区分, r.使い方)[idx]
    # 今のルール（2017〜25年で選んだ強さ×手じまい）を全期間に当てる
    q, e = divmod(int(r.WF全期間_k[-1]), nE); w = idx[m & (QL[idx] >= q)]
    v = np.asarray(YR[w, e], np.float32); ok = ~np.isnan(v); w = w[ok]; v = v[ok]; yr = YRS[w]
    v20 = v - 7 / ENT[w] * 68800
    # 前向き（各年のルール）
    f = FT[FT.cid == r.cid].sort_values('te'); fv = f.損益.values
    fv20 = fv - 7 / ENT[f.row.values] * 68800
    sF = stats(fv); sN = stats(v)
    e_ = EXd.iloc[e]
    why = []
    if r.前の順位 < 99: why.append(f'前の付け方 {r.前の順位 + 1}位（選ぶ期間の1回平均）')
    if r.新の順位 < 99: why.append(f'新しい付け方 {r.新の順位 + 1}位（前向きRF）')
    cond = '条件なし' if r.指標 == 'なし' else f'{r.指標}「{r.区分}」に{"入る" if r.使い方 == "入る" else "当たる日は入らない（避ける）"}'
    row = dict(優先順位=pr, 扱い='売買する' if r.扱い == '' else '記録だけ', 記録だけの理由=r.扱い, 分類=r.分類, 条件=cond, 区分の境目=edges(side, bs, r.指標, r.区分),
               該当率=r.該当率, 観察=r.観察, 入る=r.入る, 選び方=r.選び方, 強さ=QN[q], 手じまいの型=e_.型, 利確=str(e_.利確), 損切り=str(e_.損切り), 時間=str(e_.時間),
               選ばれた理由='・'.join(why), 選ぶ期間の1回平均_2017_25=r.選ぶ期間平均_2026, 選ぶ期間の件数=r.選ぶ期間件数_2026,
               **{'前向き_' + k: v_ for k, v_ in sF.items()}, 前向き_平均_20pt=fv20.mean() if len(fv20) else np.nan,
               **{f'前向き{y}': f[f.年 == y].損益.sum() for y in range(2022, 2027)}, **{f'前向き{y}_件数': int((f.年 == y).sum()) for y in range(2022, 2027)},
               **{'今のルール_' + k: v_ for k, v_ in sN.items()}, 今のルール_平均_20pt=v20.mean(),
               **{f'今{y}': v[yr == y].sum() for y in range(2017, 2027)}, **{f'今{y}_件数': int((yr == y).sum()) for y in range(2017, 2027)},
               今のルール_前半2017_21_平均=v[yr <= 2021].mean() if (yr <= 2021).any() else np.nan, 今のルール_後半2022_26_平均=v[yr >= 2022].mean() if (yr >= 2022).any() else np.nan,
               **{k + '_平均': getattr(r, k.replace('-', '_') + '_平均', np.nan) if False else NOW.loc[pr - 1, k + '_平均'] for k in ['前半→後半', '22-23→24-26', 'WF後半', 'WF全期間', 'WF直近3年']},
               プラスの数=r.プラスの数, 中央=r.中央, 年件数_中央=r.年件数_中央, 条件なし_中央=r.条件なし_中央, 条件なしとの差=r.条件なしとの差,
               ふるい_前半t=r.前半t, ふるい_後半t=r.後半t, 前半も同じ向き=r.前半も同じ向き, グループの大きさ=r.グループの大きさ, グループの安定=r.安定, cid=r.cid)
    rows.append(row)
    for y in range(2017, 2027):
        vy = v[yr == y]; fy = f[f.年 == y].損益.values
        d = dict(優先順位=pr, 分類=r.分類, 条件=cond, 観察=r.観察, 入る=r.入る, 年=str(y))
        d.update({'今のルール_' + k: x for k, x in stats(vy).items() if k in ('件数', '勝率', 'PF', '平均', '合計', '最悪')})
        d.update({'前向き_' + k: x for k, x in stats(fy).items() if k in ('件数', '勝率', 'PF', '平均', '合計', '最悪')})
        yearly.append(d)
T = pd.DataFrame(rows); Y = pd.DataFrame(yearly)
T.to_pickle(O + 'Y7_now.pkl'); Y.to_pickle(O + 'Y7_year.pkl')
print(T[['優先順位', '扱い', '分類', '条件', '観察', '入る', '前向き_件数', '前向き_PF', '前向き_合計', '今のルール_PF']].round(2).to_string())
