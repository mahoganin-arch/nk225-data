# 本当の前向き検証の準備：逆張りの入る形を「48候補」に絞らず、E2_D の逆張りすべて＋順張りすべて（元と同じ）を対象にした YM を作る
#   出力：outn/YM.pkl, outn/YR.npy（行の並びは src・row の順）
import numpy as np, pandas as pd
O = '/home/claude/yt/out/'; N = '/home/claude/yt/outn/'
m2 = pd.read_pickle(O + 'E2_D_meta.pkl'); m2['src'] = 'E2'; m2['row'] = np.arange(len(m2))
m1 = pd.read_pickle(O + 'E_D_meta.pkl'); m1['src'] = 'E'; m1['row'] = np.arange(len(m1)); m1['tpk'] = np.nan; m1['ext'] = np.nan
s1 = (m1.向き.values == '順張り')
YM = pd.concat([m2, m1[s1]], ignore_index=True)
YM['売買'] = np.where(YM.d > 0, '買い', '売り'); YM['sx'] = np.sign(YM.x).astype(int); YM['yr'] = YM.t.dt.year
R2 = np.load(O + 'E2_D_R.npy', mmap_mode='r'); R1 = np.load(O + 'E_D_R.npy', mmap_mode='r')
YR = np.vstack([np.asarray(R2, np.float16), np.asarray(R1[np.flatnonzero(s1)], np.float16)])
YM.to_pickle(N + 'YM.pkl'); np.save(N + 'YR.npy', YR)
print(len(YM), YR.shape); print(YM.groupby(['向き', '売買']).size().to_string())
print('入る形', YM.groupby('向き')[['観察', '入る']].apply(lambda z: len(z.drop_duplicates())).to_dict())
