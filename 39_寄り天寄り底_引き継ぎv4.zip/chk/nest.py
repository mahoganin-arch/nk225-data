# 本当の前向き検証：候補選びの全段階（逆張りの入る形の絞り込み → ふるい → 評価・残す → 重なりでまとめる → 案3 → 運用）を
#   「C 年より前のデータだけ」で行い、C 年を売買する。C=2027 にすると元のやり方（2026年までのデータで候補を選ぶ）と同じになる。
#   python3 nest.py valid   … 元の手順の再現（逆張りの入る形は元の47通り、C=2027）→ 全部 N=5 C1 が 45,068.9 になるか
#   python3 nest.py 2024 2025 2026 … 各年を本当の前向きで
import sys, numpy as np, pandas as pd, scipy.sparse as sp, pickle
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.spatial.distance import squareform
sys.path.insert(0, '/home/claude/yt/an')
from evalu import YEARS, QS, QN, neighbors
O = '/home/claude/yt/out/'; N = '/home/claude/yt/outn/'
import os
COST = os.environ.get('NEST_COST', '13pt'); SUF = '' if COST == '13pt' else '_flat'
YM = pd.read_pickle(N + 'YM.pkl'); YR = np.load(N + ('YR.npy' if COST == '13pt' else 'YR_flat.npy'), mmap_mode='r'); YF = pd.read_pickle(N + 'YF.pkl')
EXd = pd.read_pickle(O + 'EXITS.pkl')['D']; nE = len(EXd); NQ = len(QS); NK = NQ * nE
NB = neighbors(EXd)
NBm = sp.csr_matrix((np.ones(sum(len(z) for z in NB)), (np.repeat(np.arange(NK), [len(z) for z in NB]), np.concatenate(NB))), shape=(NK, NK))
m2 = pd.read_pickle(O + 'E2_D_meta.pkl'); cutmap = {}
for ob, g in m2.drop_duplicates(['観察', 'sid']).groupby('観察'):
    a = np.abs(g.x.values)[g.t.dt.year.values <= 2021]; cutmap[ob] = [np.quantile(a, q) if q > 0 else 0 for q in QS]
yi = {y: k for k, y in enumerate(YEARS)}
QL = np.zeros(len(YM), np.int8); ax = np.abs(YM.x.values)
for ob, cuts in cutmap.items():
    w = YM.観察.values == ob
    for qi, c in enumerate(cuts): QL[w & (ax >= c)] = qi
YRS = YM.yr.values; SID = YM.sid.values; TE = YM.te.values.astype('int64')
MNf = N + 'YMN%s.npy' % SUF
try: MN = np.load(MNf)
except FileNotFoundError:
    MN = np.zeros(len(YM))
    for a in range(0, len(YM), 20000): MN[a:a + 20000] = np.nanmean(np.asarray(YR[a:a + 20000], np.float32), 1)
    np.save(MNf, MN)
SHP = (YM.観察 + '|' + YM.入る).values
LATE = ('夜間最後1時間の出来高比', '出来高最多価格まで', '出来高最多価格をまたいだ', '出来高の多い価格帯の端まで')

def forms(C):
    """C 年より前に確かめられる部分だけの5つの評価の形。空の形は除く。WFR は各年のルール（成績の基準には使わない）"""
    F = {'前半→後半': [(range(2017, 2022), range(2022, C))],
         '22-23→24-26': [(range(2022, 2024), range(2024, C))],
         'WF後半': [(range(2022, y), [y]) for y in range(2023, C)],
         'WF全期間': [(range(2017, y), [y]) for y in range(2022, C)],
         'WF直近3年': [(range(y - 3, y), [y]) for y in range(2022, C)]}
    F = {k: [(a, list(b)) for a, b in v if len(list(b)) > 0 and all(y <= 2026 for y in b)] for k, v in F.items()}
    F = {k: v for k, v in F.items() if v}
    F['WFR'] = [(range(2017, y), [y]) for y in range(2022, 2027)]
    return F

def scs(idx, masks):
    K = masks.shape[0]; S = np.zeros((K, NK, len(YEARS)), np.float32); Cn = np.zeros_like(S); NG = np.zeros_like(S)
    R = np.asarray(YR[idx], np.float32); ok = ~np.isnan(R); R0 = np.where(ok, R, 0); neg = (R < -1000).astype(np.float32); okf = ok.astype(np.float32)
    ql = QL[idx]; yr = YRS[idx]
    for y in np.unique(yr):
        ry = yr == y; k = yi[y]; r0 = R0[ry]; o_ = okf[ry]; n_ = neg[ry]
        for q in range(NQ):
            Mq = (masks[:, ry] & (ql[ry] >= q)[None, :]).astype(np.float32)
            if not Mq.any(): continue
            S[:, q * nE:(q + 1) * nE, k] = Mq @ r0; Cn[:, q * nE:(q + 1) * nE, k] = Mq @ o_; NG[:, q * nE:(q + 1) * nE, k] = Mq @ n_
    return S, Cn, NG

def select(S, Cn, NG, F):
    K = S.shape[0]; out = {}
    for how in ('単点', '周辺'):
        res = {}
        for fn, splits in F.items():
            ts = np.zeros(K); tc = np.zeros(K); ty = np.zeros(K); ch = []
            for tr, te in splits:
                a = [yi[y] for y in tr]; b = [yi[y] for y in te]
                sm = S[:, :, a].sum(2, dtype=np.float64); cn = Cn[:, :, a].sum(2); ng = NG[:, :, a].sum(2)
                with np.errstate(all='ignore'): mean = np.where(cn > 0, sm / np.maximum(cn, 1), np.nan)
                ok = (cn >= 15) & (ng == 0)
                if how == '単点': score = np.where(ok, mean, -np.inf)
                else:
                    fin = np.isfinite(mean); num = (NBm @ np.where(fin, mean, 0).T).T; den = (NBm @ fin.T.astype(float)).T
                    with np.errstate(all='ignore'): nbm = np.where(den > 0, num / den, np.nan)
                    score = np.where(ok, nbm, -np.inf)
                score = np.nan_to_num(score, nan=-np.inf); has = np.isfinite(score.max(1)); k = np.argmax(score, 1)
                ch.append(np.where(has, k, -1))
                sb = S[np.arange(K), k][:, b].sum(1); cb = Cn[np.arange(K), k][:, b].sum(1)
                ts += np.where(has, sb, 0); tc += np.where(has, cb, 0); ty += np.where(has, len(b), 0)
            part = 2026 in [y for _, te in splits for y in te]
            yrs_eff = np.where(part, ty - (1 - 280 / 365), ty)
            with np.errstate(all='ignore'): res[fn] = (np.where(tc > 0, ts / np.maximum(tc, 1), np.nan), tc / np.maximum(yrs_eff, 1e-9), np.array(ch).T)
        out[how] = res
    return out

def judge(sel, F):
    """各 how の (K,) の 残す・中央・プラスの数・年件数中央・WFR のルール"""
    out = {}
    fs = [f for f in F if f != 'WFR']
    for how, res in sel.items():
        vals = np.array([res[f][0] for f in fs]).T; cnt = np.array([res[f][1] for f in fs]).T
        with np.errstate(all='ignore'):
            plus = np.nansum(vals > 0, 1); med = np.nanmedian(vals, 1); ycm = np.nanmedian(cnt, 1)
        keep = (plus >= 3) & (med >= 20) & (ycm >= 10)
        out[how] = dict(keep=keep, med=med, plus=plus, ycm=ycm, rules=res['WFR'][2])
    return out

def make_bins(Fr, sel):
    out = {}
    for c in Fr.columns:
        v = Fr[c].values.astype(float); fin = ~np.isnan(v); vt = v[sel & fin]; u = np.unique(vt)
        if len(vt) < 100: continue
        if len(u) <= 6:
            for x in u: out[(c, '=%g' % x)] = v == x
            continue
        q3 = np.quantile(vt, [1 / 3, 2 / 3]); b3 = np.searchsorted(q3, v, side='right')
        for i, lab in enumerate(['3分割:低', '3分割:中', '3分割:高']): out[(c, lab)] = fin & (b3 == i)
        q5 = np.quantile(vt, [.2, .4, .6, .8]); b5 = np.searchsorted(q5, v, side='right')
        for i in range(5): out[(c, '5分割:%d' % (i + 1))] = fin & (b5 == i)
        lo, hi = np.quantile(vt, [.1, .9]); out[(c, '下位10%')] = fin & (v <= lo); out[(c, '上位10%')] = fin & (v >= hi)
    return out

def uplift(Bm, base, period):
    T = []; D = []
    for g in np.unique(SHP[base]):
        e = base & period & (SHP == g)
        if e.sum() < 60: continue
        m = MN[e]; Be = Bm[:, e].astype(np.float64); nn = Be.sum(1); s_ = Be @ m; q = Be @ (m * m)
        mu = np.where(nn > 0, s_ / np.maximum(nn, 1), np.nan); var = np.where(nn > 1, (q - nn * mu ** 2) / np.maximum(nn - 1, 1), np.nan)
        with np.errstate(all='ignore'): t = (mu - m.mean()) / np.sqrt(var / np.maximum(nn, 1))
        d = mu - m.mean(); t[nn < 20] = np.nan; d[nn < 20] = np.nan; T.append(t); D.append(d)
    if not T: return np.full(Bm.shape[0], np.nan), np.full(Bm.shape[0], np.nan)
    T = np.array(T); D = np.array(D); good = (~np.isnan(T)).sum(0) >= 6
    with np.errstate(all='ignore'): return np.where(good, np.nanmedian(T, 0), np.nan), np.where(good, np.nanmedian(D, 0), np.nan)

def pipeline(C, rev_shapes=None, shuffle=None, verbose=True):
    """C 年より前のデータで候補を選ぶ。戻り値：候補表 Cd、前向きトレード FT（各年のルールで 2022〜2026）"""
    F = forms(C)
    # 1. 逆張りの入る形（条件なし・向きだけ、買い売り両方）
    if rev_shapes is None:
        rev_shapes = set()
        for (ob, en), idx in YM[(YM.向き == '逆張り') & (YM.src == 'E2')].groupby(['観察', '入る']).indices.items():
            idx = np.flatnonzero((YM.向き == '逆張り') & (YM.src == 'E2'))[idx]
            S, Cn, NG = scs(idx, np.ones((1, len(idx)), bool)); jd = judge(select(S, Cn, NG, F), F)
            if jd['単点']['keep'][0] or jd['周辺']['keep'][0]: rev_shapes.add((ob, en))
    inrev = np.array([(o, e) in rev_shapes for o, e in zip(YM.観察.values, YM.入る.values)])
    use_row = ((YM.向き.values == '逆張り') & (YM.src.values == 'E2') & inrev) | (YM.向き.values == '順張り')
    if verbose: print('C', C, '逆張りの入る形', len(rev_shapes), flush=True)
    CANDS = []; MASKS = {}
    for side in ('逆張り', '順張り'):
        for bs in ('売り', '買い'):
            base = use_row & (YM.向き.values == side) & (YM.売買.values == bs)
            Fa = YF.drop(columns=list(LATE)); Fl = YF[list(LATE)]
            conds = [('なし', '', '入る', np.ones(len(YM), bool))]
            for late in (False, True):
                if late and C <= 2024: continue
                Fr = Fl if late else Fa
                bins = make_bins(Fr, base & ((YRS == 2023) if late else (YRS <= 2021)))
                keys = list(bins); Bm = np.array([bins[k] for k in keys])
                if shuffle is not None: Bm = shuffle(Bm)
                pB = ((YRS >= 2024) & (YRS < C)) if late else ((YRS >= 2022) & (YRS < C))
                tB, dB = uplift(Bm, base, pB); cov = Bm[:, base & pB].mean(1)
                ok = (np.abs(tB) >= (1.5 if late else 1.0)) & (cov >= .03)
                for i in np.flatnonzero(ok):
                    use = '入る' if dB[i] > 0 else '避ける'
                    conds.append((keys[i][0], keys[i][1], use, Bm[i] if use == '入る' else ~Bm[i]))
                del Bm
            Mall = np.array([c[3] for c in conds])
            for ci, c in enumerate(conds): MASKS[(side, bs, c[0], c[1], c[2])] = np.packbits(c[3])
            for (ob, en), ii in YM[base].groupby(['観察', '入る']).indices.items():
                idx = np.flatnonzero(base)[ii]
                S, Cn, NG = scs(idx, Mall[:, idx]); jd = judge(select(S, Cn, NG, F), F)
                for how, j in jd.items():
                    for k in np.flatnonzero(j['keep']):
                        c = conds[k]; CANDS.append(dict(向き=side, 売買=bs, 指標=c[0], 区分=c[1], 使い方=c[2], 観察=ob, 入る=en, 選び方=how,
                                                       中央=j['med'][k], プラスの数=j['plus'][k], WFR=list(map(int, j['rules'][k]))))
            if verbose: print(' ', side, bs, '通過', len(conds) - 1, '残す累計', len(CANDS), flush=True)
    Cd = pd.DataFrame(CANDS)
    if len(Cd) == 0: return Cd, pd.DataFrame(), rev_shapes
    U = ['向き', '売買', '指標', '区分', '使い方', '観察', '入る']
    def mask(r): return np.unpackbits(MASKS[(r.向き, r.売買, r.指標, r.区分, r.使い方)])[:len(YM)].astype(bool)
    # 2. 重なりでまとめる（C 年より前の 2022年以降の日で）
    K = Cd.drop_duplicates(U)[U].reset_index(drop=True); K['id'] = np.arange(len(K))
    GI = YM.groupby(['向き', '売買', '観察', '入る']).indices; per = (YRS >= 2022) & (YRS < C) & use_row
    SETS = {}
    for r in K.itertuples():
        idx = GI[(r.向き, r.売買, r.観察, r.入る)]; idx = idx[per[idx]]
        if r.指標 == 'なし': SETS[r.id] = set(SID[idx]); continue
        m = mask(r)[idx]
        SETS[r.id] = set(SID[idx][m]) if r.使い方 == '入る' else set(SID[idx][~m])
    K['grp'] = -1 - K.id
    for (side, bs, use), sub in K[K.指標 != 'なし'].groupby(['向き', '売買', '使い方']):
        ids = sub.id.values
        if len(ids) == 1: K.loc[sub.index, 'grp'] = 10 ** 7 + ids[0]; continue
        days = np.array(sorted(set().union(*[SETS[i] for i in ids]))); pos = {d: j for j, d in enumerate(days)}
        X = np.zeros((len(ids), len(days)), np.float32)
        for a, i in enumerate(ids): X[a, [pos[d] for d in SETS[i]]] = 1
        inter = X @ X.T; nrm = np.sqrt(np.outer(X.sum(1), X.sum(1))); Sm = np.where(nrm > 0, inter / np.maximum(nrm, 1e-9), 0); np.fill_diagonal(Sm, 1)
        Z = linkage(squareform(1 - Sm, checks=False), 'average')
        K.loc[sub.index, 'grp'] = fcluster(Z, 1 - .5, 'distance') + {('逆張り', '売り'): 0, ('逆張り', '買い'): 1, ('順張り', '売り'): 2, ('順張り', '買い'): 3}[(side, bs)] * 100000 + (use == '避ける') * 50000
    Cd = Cd.merge(K, on=U).reset_index(drop=True); Cd['cid'] = np.arange(len(Cd)); Cd['分類'] = Cd.向き + Cd.売買
    # 3. 候補ごとの 選ぶ期間の平均（各年 t のルール）と前向きトレード（各年のルール）
    FT = []; ins = {t: np.full(len(Cd), np.nan) for t in range(2022, 2028)}; insn = {t: np.zeros(len(Cd)) for t in range(2022, 2028)}; s1721 = np.full(len(Cd), np.nan)
    for (side, bs, ob, en), g in Cd.groupby(['向き', '売買', '観察', '入る']):
        idx = GI[(side, bs, ob, en)]; idx = idx[use_row[idx]]
        cs = g[['指標', '区分', '使い方']].drop_duplicates().reset_index(drop=True); ck = {tuple(r): i for i, r in enumerate(cs.itertuples(index=False))}
        M = np.array([np.unpackbits(MASKS[(side, bs) + tuple(r)])[:len(YM)].astype(bool)[idx] for r in cs.itertuples(index=False)])
        S, Cn, NG = scs(idx, M); yr = YRS[idx]; ql = QL[idx]
        for r in g.itertuples():
            i = ck[(r.指標, r.区分, r.使い方)]
            for t, k in zip(range(2022, 2027), r.WFR):
                if k < 0: continue
                a = [yi[y] for y in YEARS if y < t]; n_ = Cn[i, k, a].sum(); insn[t][r.cid] = n_
                if n_ > 0: ins[t][r.cid] = S[i, k, a].sum() / n_
                if t == 2022: s1721[r.cid] = S[i, k, a].sum()
                q, e = divmod(k, nE); w = idx[M[i] & (yr == t) & (ql >= q)]
                x = np.asarray(YR[w, e], np.float32); ok = ~np.isnan(x)
                for row, v in zip(w[ok], x[ok]): FT.append((r.cid, t, int(SID[row]), int(TE[row]), float(v), int(row), int(e)))
    for t in range(2022, 2027): Cd['選ぶ期間平均_%d' % t] = ins[t]; Cd['選ぶ期間件数_%d' % t] = insn[t]
    Cd['選ぶ期間2017_21合計'] = s1721
    FTd = pd.DataFrame(FT, columns=['cid', '年', 'sid', 'te', '損益', 'row', 'e']).sort_values(['cid', 'te'], kind='stable')
    return Cd, FTd, rev_shapes

# ---------------------------------------------------------------- 案3と運用（yunion と同じ）
def record(FT, t):
    F = FT[FT.年 < t]
    if not len(F): return pd.DataFrame(columns=['件数', '合計', 'DD', 'RF', 'PF']), pd.Series(dtype=object)
    v = F.損益.values; cid = F.cid.values; out = {}
    for c, ii in F.groupby('cid').indices.items():
        x = v[ii]; eq = np.cumsum(x); dd = (np.maximum.accumulate(np.r_[0, eq])[1:] - eq).max(); gp = x[x > 0].sum(); gl = -x[x < 0].sum()
        out[c] = dict(件数=len(x), 合計=x.sum(), DD=dd, RF=x.sum() / dd if dd > 0 else (np.inf if x.sum() > 0 else 0), PF=gp / gl if gl > 0 else np.inf)
    return pd.DataFrame.from_dict(out, orient='index'), F.groupby('cid').sid.apply(set)

def choose(Cd, FT, t, Nn, groups, rule_year=None):
    ry = rule_year or t; R, days = record(FT, t)
    X = Cd[Cd['分類'].isin(groups)].join(R, on='cid'); out = []
    for kb, g in X.groupby('分類'):
        a = g[(g['選ぶ期間件数_%d' % ry] >= 15) & g['選ぶ期間平均_%d' % ry].notna() & ~(g.合計 <= 0)].sort_values('選ぶ期間平均_%d' % ry, ascending=False).drop_duplicates('grp')
        b = g[(g.件数 >= 20) & (g.合計 > 0) & (g.選ぶ期間2017_21合計 > 0)].sort_values('RF', ascending=False).drop_duplicates('grp')
        ra = {c: i for i, c in enumerate(a.cid.values[:Nn])}; rb = {c: i for i, c in enumerate(b.cid.values[:Nn])}
        ids = list(dict.fromkeys(list(ra) + list(rb)))
        if not ids: continue
        sel = g.set_index('cid').loc[ids].copy(); sel['前の順位'] = [ra.get(c, 99) for c in ids]; sel['新の順位'] = [rb.get(c, 99) for c in ids]
        sel['両方'] = (sel.前の順位 < 99) & (sel.新の順位 < 99); sel['良い方'] = sel[['前の順位', '新の順位']].min(axis=1)
        sel = sel.sort_values('RF', ascending=False, na_position='last'); keep = []; why = {}
        for c in sel.index:
            dc = days.get(c, set()); hit = None
            for k in keep:
                dk = days.get(k, set())
                if dc and dk and len(dc & dk) / min(len(dc), len(dk)) >= .75: hit = k; break
            if hit is None: keep.append(c)
            else: why[c] = '重なり75%以上'
        sel['扱い'] = [why.get(c, '') for c in sel.index]
        sel.loc[(sel.扱い == '') & (sel.PF < 1.2), '扱い'] = 'PF1.2未満'
        out.append(sel.reset_index())
    if not out: return pd.DataFrame(columns=['cid', '扱い', '両方', '良い方', '前の順位'])
    S = pd.concat(out); S['確かめる年'] = t
    return S.sort_values(['両方', '良い方', '前の順位'], ascending=[False, True, True])

EXT = {}
import engt
def exit_time(row, e):
    if row not in EXT:
        r = YM.iloc[row]; EXT[row] = engt.sim_t((r.d, r.te, r.mv, r.tcap, r.tam if r.tam == r.tam else None, 'D'))[1]
    return EXT[row][e]

def simulate(FT, t, sel, pol, cost_add=0.0, PRICE=None):
    sel = sel[sel.扱い == ''].reset_index(drop=True); pr = {c: i for i, c in enumerate(sel.cid)}
    tr = FT[(FT.年 == t) & FT.cid.isin(pr)].copy(); tr['pr'] = tr.cid.map(pr); tr['d'] = YM.d.values[tr.row.values]
    tr = tr.sort_values(['sid', 'te', 'pr']); out = []
    for s, g in tr.groupby('sid', sort=False):
        held = []; closed = False
        for r in g.itertuples():
            still = []
            for h in held:
                if h[1] <= r.te: closed = True; out.append(h)
                else: still.append(h)
            held = still
            if closed: continue
            same = [h for h in held if h[2] == r.d]; opp = [h for h in held if h[2] != r.d]
            if pol == 'A1' and held: continue
            if pol == 'B' and same: continue
            if pol == 'C1' and (opp or len(held) >= 2): continue
            if pol == 'D1' and len(held) >= 2: continue
            if same and same[0][3] == r.cid: continue
            if pol in ('C1', 'D1') and len(same) >= 1 and len(held) >= 2: continue
            held.append((r.te, exit_time(r.row, r.e), r.d, r.cid, r.損益, s, '2本目' if same else ('両建て' if opp else '1本目'), r.row, r.e))
        out += held
    return pd.DataFrame(out, columns=['入る', '手じまう', 'd', 'cid', '損益', 'sid', '種類', 'row', 'e'])

def summ(H):
    if not len(H): return dict(件数=0, 合計=0.0, 最大DD=0.0)
    H = H.sort_values('手じまう'); v = H.損益.values; eq = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, eq])[1:] - eq).max()
    return dict(件数=len(v), 合計=v.sum(), 最大DD=dd, 一回平均=v.mean(), 勝率=(v > 0).mean() * 100)

POOLS = {'全部': ['逆張り売り', '逆張り買い', '順張り売り', '順張り買い'], '売りのみ': ['逆張り売り', '順張り売り'], '買いのみ': ['逆張り買い', '順張り買い']}

if __name__ == '__main__':
    arg = sys.argv[1:]
    if arg[0] == 'valid':
        REV = set(zip(*[pd.read_pickle(O + 'YM.pkl').query("向き=='逆張り'")[c] for c in ('観察', '入る')])) if COST == '13pt' else None
        Cd, FT, rs = pipeline(2027, rev_shapes=REV)
        pickle.dump((Cd, FT, rs), open(N + f'nest_2027v{SUF}.pkl', 'wb'))
        print('候補', len(Cd), '前向きトレード', len(FT))
        for pn in ('全部', '売りのみ', '買いのみ'):
            Hs = []
            for t in (2024, 2025, 2026):
                H = simulate(FT, t, choose(Cd, FT, t, 5, POOLS[pn]), 'C1'); H['年'] = t; Hs.append(H)
            H = pd.concat(Hs); print(pn, summ(H), {t: round(H[H.年 == t].損益.sum(), 1) for t in (2024, 2025, 2026)}, flush=True)
    else:
        for C in map(int, arg):
            Cd, FT, rs = pipeline(C)
            pickle.dump((Cd, FT, rs), open(N + f'nest_{C}{SUF}.pkl', 'wb'))
            print('C', C, '候補', len(Cd), flush=True)
