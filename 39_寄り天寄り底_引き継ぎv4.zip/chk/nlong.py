# 条件なし（向き×売買×入る形）の全候補で、2019〜2026年の本当の前向き
#   各年 y のルール＝2017〜y−1 年で選んだ強さ×手じまい（単点・周辺、15件以上・最悪 −1,000円以上）。y 年を売買
#   条件を付けないので、候補の集まりは最初から決まっている（＝候補選びに先のデータを使わない）
#   2027 のルール（2017〜2026/10/8 で選ぶ）＝これから使うルールも出す
#   NEST_COST=flat でコストを毎回13円に
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/chk'); import nest
SUF = nest.SUF; YM = nest.YM; YR = nest.YR; nE = nest.nE
F = {'WFR': [(range(2017, y), [y]) for y in range(2019, 2027)] + [(range(2017, 2027), [2026])]}   # 最後は 2027 用のルール（成績は使わない）
GI = YM.groupby(['向き', '売買', '観察', '入る']).indices
C = []; FT = []; cid = 0
for (side, bs, ob, en), idx in GI.items():
    S, Cn, NG = nest.scs(idx, np.ones((1, len(idx)), bool)); sel = nest.select(S, Cn, NG, F)
    yr = nest.YRS[idx]; ql = nest.QL[idx]
    for how, res in sel.items():
        ks = res['WFR'][2][0]
        row = dict(cid=cid, 向き=side, 売買=bs, 分類=side + bs, 観察=ob, 入る=en, 選び方=how, 入る形の元='E2' if YM.src.values[idx[0]] == 'E2' else 'E')
        for y, k in zip(list(range(2019, 2027)) + [2027], ks):
            row[f'k{y}'] = int(k)
            if y == 2027 or k < 0: continue
            q, e = divmod(int(k), nE); w = idx[(yr == y) & (ql >= q)]
            x = np.asarray(YR[w, e], np.float32); ok = ~np.isnan(x)
            for r_, v in zip(w[ok], x[ok]): FT.append((cid, y, int(nest.SID[r_]), int(nest.TE[r_]), float(v), int(r_), e))
        C.append(row); cid += 1
C = pd.DataFrame(C); FT = pd.DataFrame(FT, columns=['cid', '年', 'sid', 'te', '損益', 'row', 'e']).sort_values(['cid', 'te'], kind='stable')
pickle.dump((C, FT), open(nest.N + f'nlong{SUF}.pkl', 'wb'))
print('候補', len(C), '前向きトレード', len(FT))
print(FT.groupby(['年']).損益.agg(['size', 'mean']).round(1).T.to_string())
