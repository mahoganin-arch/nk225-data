# 寄り天（9時台の逆張り売り）3本の照合用 Python（分析のエンジンとは別に書き直した独立版）
#   使い方：python3 yref.py <CFD 1分足> <CFD 5分足> <先物 5分足> <開始日> <終了日の翌日> [出力CSV]
#     ファイルは BarExport（ld.py で戻せる形）。CFD 5分足は RSI（5分・15分）の計算に使うので、長い期間（数か月以上）を入れる
#   ルール（2017〜2026/10/8 のデータで選んだもの。コストは毎回13円、1枚＝68,800円換算）
#     ① 8:45→9:00 の先物が +0.3095% 以上：9:00 以降に始まる5分足で RSI14 が70以上になった後、70を割った足の終わりに売り（9:00から90分以内）
#        利確：入った後に始まる15分足の RSI14 が30以下になった足の終わり（次の足の始値）／損切りなし／引け（先物の最後の5分足の時刻の CFD 始値）
#     ② 8:45→9:05 の先物が +0.3812% 以上：9:10 の CFD 始値で売り。利確なし／損切り 0.8%（入った値段から）／入ってから240分
#     ③ 8:45→9:05 の先物が +0.4849% 以上：9:05 から60分以内に、CFD の安値が「9:05 の CFD 始値 −（先物の動き%×9:05 の CFD 始値）×50%」以下になった足の次の足の始値で売り
#        利確：15分足 RSI14 が30以下／損切り 0.5%／引け
#   口座：同じ向き（売り）は2本まで。そのセッションで1本でも手じまったら、その後は入らない。同じ時刻なら ①②③ の順
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/code'); import ld
UNIT = 68800.0; COST = 13.0
TH = {'①': 0.003095, '②': 0.003812, '③': 0.004849}
def rsi(close):
    c = np.asarray(close, float); dl = np.diff(c, prepend=c[0]); up = np.where(dl > 0, dl, 0); dn = np.where(dl < 0, -dl, 0)
    au = pd.Series(up).ewm(alpha=1 / 14, adjust=False).mean().values; ad = pd.Series(dn).ewm(alpha=1 / 14, adjust=False).mean().values
    return 100 - 100 / (1 + au / np.where(ad == 0, 1e-9, ad))
def first_ge(M, t, tol=5):
    i = np.searchsorted(M, t); return i if (i < len(M) and M[i] - t < tol) else None
def run(c1, c5, f5, start, end):
    PM = c1.m.values; PO = c1.open.values; PH = c1.high.values; PL = c1.low.values
    m5 = c5.m.values; r5 = rsi(c5.close.values); e5 = m5 + 5
    g = (c5.m // 15) * 15; b15 = c5.groupby(g).agg(close=('close', 'last')); m15 = b15.index.values; r15 = rsi(b15.close.values); e15 = m15 + 15
    FM = f5.m.values; FO = f5.open.values
    gap = np.diff(FM, prepend=FM[0] - 999) >= 30; st = np.flatnonzero(gap)
    ends = np.r_[st[1:] - 1, len(FM) - 1]
    T0 = int(pd.Timestamp(start, tz='Asia/Tokyo').timestamp() // 60); T1 = int(pd.Timestamp(end, tz='Asia/Tokyo').timestamp() // 60)
    out = []
    for s, e_ in zip(st, ends):
        m0 = FM[s]; t = pd.Timestamp(m0 * 60, unit='s', tz='UTC').tz_convert('Asia/Tokyo')
        if t.hour * 60 + t.minute != 525 or not (T0 <= m0 < T1): continue
        tcap = FM[e_]
        ia, i9, i95 = first_ge(FM, m0), first_ge(FM, m0 + 15), first_ge(FM, m0 + 20)
        if ia is None: continue
        x9 = FO[i9] / FO[ia] - 1 if i9 is not None else np.nan; x95 = FO[i95] / FO[ia] - 1 if i95 is not None else np.nan
        k = first_ge(PM, m0 + 20); c0 = PO[k] if k is not None else np.nan
        sig = []
        if x9 >= TH['①']:
            k0 = np.searchsorted(m5, m0 + 15); k1 = np.searchsorted(m5, m0 + 15 + 90); was = False
            for k_ in range(k0, k1):
                if r5[k_] >= 70: was = True
                elif was: sig.append(('①', int(e5[k_]), None, 'RSI15', np.inf)); break
        if x95 >= TH['②']: sig.append(('②', int(m0 + 25), 240, None, 0.8))
        if x95 >= TH['③'] and np.isfinite(c0):
            lv = c0 - 0.5 * x95 * c0; j0 = np.searchsorted(PM, m0 + 20); j1 = np.searchsorted(PM, m0 + 20 + 60)
            w = np.flatnonzero(PL[j0:j1] <= lv)
            if len(w) and j0 + w[0] + 1 < len(PM): sig.append(('③', int(PM[j0 + w[0] + 1]), None, 'RSI15', 0.5))
        trades = []
        for nm, te, tm, tp, sl in sig:
            j0 = first_ge(PM, te)
            if j0 is None or te >= tcap: continue
            jc = np.searchsorted(PM, tcap); e = PO[j0]; mm = PM[j0:jc]; n = len(mm)
            if n == 0: continue
            op = PO[j0:jc + 1]
            adv = np.maximum.accumulate(PH[j0:jc] - e)
            si = np.searchsorted(adv, sl / 100 * e) if np.isfinite(sl) else n; slt = mm[si] if si < n else np.inf
            if tm is None: tl = n
            else: tl = min(np.searchsorted(mm, mm[0] + tm), n)
            tlt = mm[tl] if tl < n else tcap
            tpt = np.inf
            if tp:
                k0 = np.searchsorted(m15, te); k1 = np.searchsorted(m15, tcap)
                w = np.flatnonzero(r15[k0:k1] <= 30)
                if len(w): tpt = e15[k0 + w[0]]
            cand = [(slt, 0), (tpt, 1), (tlt, 2)]; tx, kind = min(cand, key=lambda z: (z[0], z[1]))
            if kind == 0: xp = max(op[si], e * (1 + sl / 100)); why = '損切り'
            elif kind == 1:
                kx = min(np.searchsorted(mm, tpt), n); xp = op[kx]; why = '利確（15分RSI30）'; tx = mm[kx] if kx < n else tcap
            else: xp = op[min(tl, n)]; why = '時間（240分）' if tm else '引け'
            trades.append(dict(日=t.date(), ルール=nm, 入る時刻=te_ts(PM[j0]), 入る値段=e, 手じまう時刻=te_ts(tx), 手じまう値段=xp, 理由=why, 損益=(e - xp) / e * UNIT - COST,
                               先物の動き_900_pct=x9 * 100, 先物の動き_905_pct=x95 * 100, _te=int(PM[j0]), _tx=int(tx)))
        # 口座：2本まで、手じまった後は入らない
        trades.sort(key=lambda d: (d['_te'], d['ルール'])); held = []; closed = False
        for d in trades:
            still = []
            for h in held:
                if h['_tx'] <= d['_te']: closed = True
                else: still.append(h)
            held = still
            d['口座'] = '入る' if (not closed and len(held) < 2) else ('入らない（手じまい後）' if closed else '入らない（2本保有中）')
            if d['口座'] == '入る': held.append(d)
            out.append(d)
    return pd.DataFrame(out)
def te_ts(m): return pd.Timestamp(int(m) * 60, unit='s', tz='UTC').tz_convert('Asia/Tokyo').strftime('%Y-%m-%d %H:%M')
if __name__ == '__main__':
    a = sys.argv[1:]
    c1 = ld.bars(a[0]); c5 = ld.bars(a[1]); f5 = ld.bars(a[2])
    T = run(c1, c5, f5, a[3], a[4])
    pd.set_option('display.width', 250)
    print(T.drop(columns=['_te', '_tx']).round(1).to_string(index=False))
    if len(a) > 5: T.drop(columns=['_te', '_tx']).to_csv(a[5], index=False, encoding='utf-8-sig')
