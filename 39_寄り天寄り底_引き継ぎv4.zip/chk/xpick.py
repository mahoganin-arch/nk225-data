# 9時台（8:45→9:00・9:05）× 元からある入り方 24 ＝ 48形から、互いに重ならない数本を選ぶ
#   各形のルール：全部の格子・1回平均で選ぶ・単点（各年はその年より前のデータ）
#   2段目：各年 t の初めに、2019〜t−1 の前向き記録（20件以上・合計プラス）を「1回平均」または「合計÷最大DD」の順に並べ、
#          入る日の重なり（共通÷少ない方）が 75% 未満の形だけを上から N 本。t 年を同じ向き2本・入り直しなしで動かす（2021〜2026）
#   同じ手順を 2027 年に当てて、これから記録する候補を出す
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/chk')
import xeval2 as x2, xeng
from xeval import M, R, EXD, NE, QL, YR, TE, SID, BND, prefix_stats
X = x2.X
OLD = ['0', '+5', 'c25', 'c50', 'pkK25', 'pkK50', 'pkP10', 'pkP20', 'HA1', 'HA5', '前足1', '前足5', 'RSI1', 'RSI5']; OLD = OLD + [c + 'n' for c in OLD[4:]]
QN = ['全部', '上位50%', '上位33%', '上位20%', '上位15%', '上位10%', '上位5%']
allow = x2.ALLOW['全部の格子']; G = M.groupby(['観察', '入る']).indices
SH = []; FT = []
for (ob, en), idx in G.items():
    if ob not in ('8:45→9:00', '8:45→9:05') or en not in OLD: continue
    idx = idx[np.argsort(TE[idx], kind='stable')]; st, P = prefix_stats(idx); t0 = TE[idx[0]]; c = len(SH)
    row = dict(cid=c, 観察=ob, 入る=en)
    for y in range(2019, 2028):
        if P[y] == 0: row[f'k{y}'] = -1; continue
        k = x2.choose2(st[y], (BND[y] - t0) / (365.25 * 1440), allow)[('平均', '単点')]; row[f'k{y}'] = k
        if y == 2027 or k < 0: continue
        q, e = divmod(k, NE); w = idx[(YR[idx] == y) & (QL[idx] >= q)]
        x = np.asarray(R[w, e], np.float32); ok = ~np.isnan(x)
        for r_, v in zip(w[ok], x[ok]): FT.append((c, y, int(SID[r_]), int(TE[r_]), float(v), int(r_), int(e)))
    SH.append(row)
SH = pd.DataFrame(SH); FT = pd.DataFrame(FT, columns=['cid', '年', 'sid', 'te', '損益', 'row', 'e']).sort_values(['cid', 'te'], kind='stable')
def st_(v):
    v = np.asarray(v, float)
    if len(v) == 0: return dict(件数=0, 合計=0.0, 最大DD=0.0)
    eq = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, eq])[1:] - eq).max(); gl = -v[v < 0].sum()
    return dict(件数=len(v), 勝率=(v > 0).mean(), PF=v[v > 0].sum() / gl if gl > 0 else np.inf, 平均=v.mean(), 合計=v.sum(), 最大DD=dd, RF=v.sum() / dd if dd > 0 else np.inf, 最悪=v.min())
EXT = {}
def ext_time(row, e):
    if row not in EXT:
        r = M.iloc[row]; fill = None if (r.fill is None or (isinstance(r.fill, float) and np.isnan(r.fill))) else float(r.fill)
        EXT[row] = xeng.sim((int(r.te), fill, r.mv, r.tcap, r.tam, r.peak0, r.B, r.pcl, r.ncl), want_time=True)[1]
    return EXT[row][e]
def simulate(t, cids, maxpos=2):
    pr = {c: i for i, c in enumerate(cids)}; tr = FT[(FT.年 == t) & FT.cid.isin(pr)].copy(); tr['pr'] = tr.cid.map(pr)
    tr = tr.sort_values(['sid', 'te', 'pr']); out = []
    for s, g in tr.groupby('sid', sort=False):
        held = []; closed = False
        for r in g.itertuples():
            still = []
            for h in held:
                if h[1] <= r.te: closed = True; out.append(h)
                else: still.append(h)
            held = still
            if closed or len(held) >= maxpos: continue
            held.append((r.te, ext_time(r.row, r.e), r.cid, r.損益, s))
        out += held
    return pd.DataFrame(out, columns=['入る', '手じまう', 'cid', '損益', 'sid'])
def pick(t, met, Nn, ovl=0.75):
    past = FT[FT.年 < t]; S = []
    for c, g in past.groupby('cid'):
        s = st_(g.損益.values)
        if s['件数'] >= 20 and s['合計'] > 0: S.append((c, s['平均'], min(s['RF'], 50), set(g.sid)))
    S.sort(key=lambda z: -(z[1] if met == '平均' else z[2])); keep = []
    for c, m_, rf, days in S:
        if any(len(days & d2) / min(len(days), len(d2)) >= ovl for _, d2 in keep): continue
        keep.append((c, days))
        if len(keep) >= Nn: break
    return [c for c, _ in keep]
PORT = []; HS = {}
for met in ('平均', 'RF'):
    for Nn in (1, 2, 3, 5):
        Hs = []; names = {}
        for t in range(2021, 2027):
            cids = pick(t, met, Nn); H = simulate(t, cids); H['年'] = t; Hs.append(H); names[t] = ' / '.join(f"{SH.loc[c, '観察'][-4:]} {SH.loc[c, '入る']}" for c in cids)
        H = pd.concat(Hs); HS[(met, Nn)] = H
        PORT.append(dict(並べる指標={'平均': '1回平均', 'RF': '合計÷最大DD'}[met], 本数=Nn, **st_(H.sort_values('手じまう').損益.values), **{str(t): H[H.年 == t].損益.sum() for t in range(2021, 2027)}, **{f'選んだ形_{t}': names[t] for t in range(2021, 2027)}))
# 比べる相手：48形すべての平均（1形あたり）、今の中心の形（9:05・0）だけ
allf = FT[FT.年 >= 2021]; per = allf.groupby(['cid', '年']).損益.sum().unstack().reindex(columns=range(2021, 2027)).fillna(0)
PORT.append(dict(並べる指標='（48形の平均、1形あたり）', 本数=1, 合計=per.sum(1).mean(), **{str(t): per[t].mean() for t in range(2021, 2027)}))
b = SH[(SH.観察 == '8:45→9:05') & (SH.入る == '0')].cid.iloc[0]; Hb = simulate(2021, [b]); Hb = pd.concat([simulate(t, [b]).assign(年=t) for t in range(2021, 2027)])
PORT.append(dict(並べる指標='（今の中心の形：9:05・入る0）', 本数=1, **st_(Hb.sort_values('手じまう').損益.values), **{str(t): Hb[Hb.年 == t].損益.sum() for t in range(2021, 2027)}))
P = pd.DataFrame(PORT)
# 48形の一覧（2019〜2026 の前向き、今のルール）
L = []
for r in SH.itertuples():
    f = FT[FT.cid == r.cid]; v = f.損益.values; y = f.年.values
    k = r.k2027; q, e = divmod(int(k), NE) if k >= 0 else (0, 0); ex = EXD.iloc[e]
    d = dict(cid=r.cid, 観察=r.観察, 入る=r.入る, **st_(v), プラスの年=sum(v[y == yy].sum() > 0 for yy in range(2019, 2027) if (y == yy).sum() >= 5), 五件以上の年=sum((y == yy).sum() >= 5 for yy in range(2019, 2027)),
             今の強さ=QN[q] if k >= 0 else '', 手じまい群=ex.群 if k >= 0 else '', 利確=f'{ex.利確型}:{ex.利確}' if k >= 0 else '', 損切り=f'{ex.損切り型}:{ex.損切り}' if k >= 0 else '', 時間=ex.時間 if k >= 0 else '')
    for yy in range(2019, 2027): d[str(yy)] = v[y == yy].sum(); d[f'{yy}_件数'] = int((y == yy).sum())
    L.append(d)
L = pd.DataFrame(L)
NOW = {(met, Nn): pick(2027, met, Nn) for met in ('平均', 'RF') for Nn in (1, 2, 3, 5)}
pickle.dump(dict(SH=SH, FT=FT, P=P, L=L, NOW=NOW, HS=HS), open(X + 'xpick.pkl', 'wb'))
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 60)
print(P[['並べる指標', '本数', '件数', 'PF', '平均', '合計', '最大DD', 'RF', '2021', '2022', '2023', '2024', '2025', '2026']].round(2).to_string(index=False))
print(P[['並べる指標', '本数'] + [f'選んだ形_{t}' for t in (2024, 2025, 2026)]].head(8).to_string(index=False))
for k, cids in NOW.items(): print('今', k, L.set_index('cid').loc[cids][['観察', '入る', '件数', 'PF', '合計', 'RF', 'プラスの年', '今の強さ', '利確', '損切り', '時間']].round(2).to_string())
