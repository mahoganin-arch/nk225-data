# 売買の現実性：元の手順の「全部・上位5本・同じ向き2本」（2024〜26）の実際のトレードで
#   ① コスト 13→20/25/30pt、② 入るのが1分・2分遅れる、③ 利確・損切りを5分足で判定した場合（2020/11より前と同じ条件）
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/chk'); sys.path.insert(0, '/home/claude/yt/an')
import nest, eng
Cd, FT, rs = pickle.load(open(nest.N + 'nest_2027v.pkl', 'rb'))
Hs = []
for pn in ('全部', '売りのみ', '買いのみ'):
    for t in (2024, 2025, 2026):
        H = nest.simulate(FT, t, nest.choose(Cd, FT, t, 5, nest.POOLS[pn]), 'C1'); H['年'] = t; H['集まり'] = pn; Hs.append(H)
H = pd.concat(Hs, ignore_index=True)
YM = nest.YM
r = YM.iloc[H.row.values]
ent = eng.PO[np.minimum(np.searchsorted(eng.PM, r.te.values.astype('int64')), len(eng.PM) - 1)]
H['入値'] = ent; H['入る形'] = (r.観察 + '|' + r.入る).values; H['分類'] = (r.向き + r.売買).values
for pt in (20, 25, 30): H['損益_%dpt' % pt] = H.損益 - (pt - 13) / ent * 68800
def resim(row, e, dt=0, path=None):
    q = YM.iloc[row]
    out = eng.sim((q.d, int(q.te) + dt, q.mv, q.tcap, q.tam if q.tam == q.tam else None, 'D'))
    return out[e]
for dt in (1, 2):
    H['損益_遅れ%d分' % dt] = [resim(a, b, dt) for a, b in zip(H.row, H.e)]
# 5分足で判定（CFD 5分足だけの値動きに差し替える）
c5 = pd.read_pickle(nest.O + 'c5.pkl'); keep = (eng.PM.copy(), eng.PO.copy(), eng.PH.copy(), eng.PL.copy())
eng.PM = c5.m.values; eng.PO = c5.open.values; eng.PH = c5.high.values; eng.PL = c5.low.values
H['損益_5分足'] = [resim(a, b) for a, b in zip(H.row, H.e)]
eng.PM, eng.PO, eng.PH, eng.PL = keep
H.to_pickle(nest.N + 'real_H.pkl')
cols = ['損益', '損益_20pt', '損益_25pt', '損益_30pt', '損益_遅れ1分', '損益_遅れ2分', '損益_5分足']
print(H.groupby('集まり')[cols].sum().round(0).to_string())
print(H[H.集まり == '全部'].groupby('年')[cols].sum().round(0).to_string())
print('入る形の内訳（全部）'); print(H[H.集まり == '全部'].groupby('入る形').損益.agg(['size', 'sum']).sort_values('size', ascending=False).head(15).round(0).to_string())
print('5分足で判定したときの差（1回平均）', (H.損益_5分足 - H.損益).mean().round(1), '／ 差がある割合', ((H.損益_5分足 - H.損益).abs() > 1).mean().round(2))
