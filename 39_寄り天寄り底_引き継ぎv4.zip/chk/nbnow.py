# 記録する(B)：条件なしの候補から、今（2019〜2026/10/8 の前向き記録）で選ぶ。ルールは 2017〜2026/10/8 で選んだ強さ×手じまい（k2027）
#   B1：1年だけマイナス可（各年5件以上、プラスの年 ≥ 年数−1）  B2：過去の合計プラス（20件以上）。どちらも分類ごとに前向きRF順で上位5本（同じ入る形は1本）
#   分類：逆張り売り・順張り売り（売りのみ）。参考に逆張り買い・順張り買いも
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/an'); from evalu import QN
O = '/home/claude/yt/out/'; N = '/home/claude/yt/outn/'
EXd = pd.read_pickle(O + 'EXITS.pkl')['D']; nE = len(EXd)
YM = pd.read_pickle(N + 'YM.pkl'); P = pd.read_pickle(O + 'P.pkl'); PM = P.m.values
ENT = P.open.values[np.minimum(np.searchsorted(PM, YM.te.values.astype('int64')), len(PM) - 1)]
out = {}
for SUF, lab in (('_flat', 'コスト統一'), ('', '13pt')):
    C, FT = pickle.load(open(N + f'nlong{SUF}.pkl', 'rb'))
    rows = []
    for r in C.itertuples():
        f = FT[FT.cid == r.cid]; v = f.損益.values
        if len(v) == 0: continue
        eq = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, eq])[1:] - eq).max(); gl = -v[v < 0].sum()
        ny = f.groupby('年').損益.agg(['size', 'sum'])
        yrs = range(2019, 2027); n5 = sum(ny['size'].get(y, 0) >= 5 for y in yrs); pl = sum((ny['size'].get(y, 0) >= 5) and (ny['sum'].get(y, 0) > 0) for y in yrs)
        k = r.k2027
        if k < 0: continue
        q, e = divmod(int(k), nE); ex = EXd.iloc[e]
        d = dict(cid=r.cid, 分類=r.分類, 観察=r.観察, 入る=r.入る, 選び方=r.選び方, 今の強さ=QN[q], 手じまいの型=ex.型, 利確=str(ex.利確), 損切り=str(ex.損切り), 時間=str(ex.時間),
                 前向き_件数=len(v), 前向き_勝率=(v > 0).mean(), 前向き_PF=v[v > 0].sum() / gl if gl > 0 else np.inf, 前向き_平均=v.mean(),
                 前向き_平均_20pt=(v - 7 / ENT[f.row.values] * 68800).mean(), 前向き_合計=v.sum(), 前向き_最大DD=dd, 前向き_RF=v.sum() / dd if dd > 0 else np.inf, 前向き_最悪=v.min(),
                 プラスの年=pl, 五件以上の年=n5)
        for y in yrs: d[f'{y}'] = ny['sum'].get(y, 0.0); d[f'{y}_件数'] = int(ny['size'].get(y, 0))
        rows.append(d)
    A = pd.DataFrame(rows)
    for bn, m in (('B1：1年だけマイナス可', (A.五件以上の年 == 8) & (A.プラスの年 >= 7)), ('B2：過去の合計プラス', (A.前向き_合計 > 0) & (A.前向き_件数 >= 20))):
        s = A[m].sort_values('前向き_RF', ascending=False).drop_duplicates(['分類', '観察', '入る']).groupby('分類').head(5).copy()
        s.insert(0, '記録の組', bn); s.insert(1, 'コスト', lab)
        out[(lab, bn)] = s
    out[(lab, '全候補')] = A
pickle.dump(out, open(N + 'nbnow.pkl', 'wb'))
pd.set_option('display.width', 250)
for k, s in out.items():
    if k[1] == '全候補': continue
    print('==', k); print(s[['分類', '観察', '入る', '選び方', '今の強さ', '手じまいの型', '利確', '損切り', '時間', '前向き_件数', '前向き_PF', '前向き_合計', '前向き_最大DD', 'プラスの年']].round(2).to_string(index=False))
