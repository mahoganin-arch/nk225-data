# (b) 入った後の値動きの性質（候補3本、今のルールの強さで、2017〜2026 の全トレード。選ぶためではなく理解するため）
#   ① 入ってから t 分後の損益（売り、手じまわずに持った場合、13円控除）：平均・中央・プラスの割合
#   ② 最大の含み益（MFE）と、それを付けた時刻／最大の含み損（MAE）と、それを付けた時刻（240分まで・引けまで）
#   ③ 含み損が 0.5・0.8・1.0% に達したトレードは、その後どうなったか（240分時点・引けの損益）
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/chk')
from xeng import PM, PO, PH, PL
X = '/home/claude/yt/outx/'
M = pd.read_pickle(X + 'XM.pkl'); d = pickle.load(open(X + 'xpick.pkl', 'rb')); SH = d['SH']
import xeval as xv
QL = xv.QL; NE = xv.NE
CAND = {8: '① 9:00・RSI5・上位5%', 24: '② 9:05・+5・上位10%', 35: '③ 9:05・c50・上位5%'}
TS = [5, 10, 15, 30, 45, 60, 90, 120, 150, 180, 240, 300, 360]
rows = []
for c, nm in CAND.items():
    ob, en = SH.loc[c, '観察'], SH.loc[c, '入る']; q = divmod(SH.loc[c, 'k2027'], NE)[0]
    idx = np.flatnonzero((M.観察.values == ob) & (M.入る.values == en) & (QL >= q))
    for i in idx:
        r = M.iloc[i]; te = int(r.te); j0 = np.searchsorted(PM, te); jc = np.searchsorted(PM, r.tcap)
        if j0 >= len(PM) or PM[j0] - te >= 5 or jc <= j0: continue
        lim = not (r.fill is None or (isinstance(r.fill, float) and np.isnan(r.fill))); e = float(r.fill) if lim else PO[j0]
        mm = PM[j0:jc]; hi = PH[j0:jc]; lo = PL[j0:jc]; t0 = mm[0]
        cv = lambda p: (e - p) / e * 68800 - 13
        d_ = dict(候補=nm, 年=r.t.year, 日=r.t.date())
        for t in TS:
            k = np.searchsorted(mm, t0 + t); d_[f'{t}分'] = cv(PO[j0 + k]) if k < len(mm) else np.nan
        d_['引け'] = cv(PO[jc])
        for lab, T in (('240分まで', 240), ('引けまで', None)):
            n = len(mm) if T is None else np.searchsorted(mm, t0 + T)
            if n == 0: continue
            fav = (e - lo[:n]) / e * 100; adv = (hi[:n] - e) / e * 100
            kf = int(np.argmax(fav)); ka = int(np.argmax(adv))
            d_[f'最大含み益%_{lab}'] = fav[kf]; d_[f'含み益の時刻_{lab}'] = (mm[kf] - t0); d_[f'最大含み損%_{lab}'] = adv[ka]; d_[f'含み損の時刻_{lab}'] = (mm[ka] - t0)
            d_[f'含み益前の最大含み損%_{lab}'] = adv[:kf + 1].max()
        adv_all = (np.maximum.accumulate(hi) - e) / e * 100
        for th in (0.5, 0.8, 1.0):
            k = np.searchsorted(adv_all, th)
            d_[f'含み損{th}%到達'] = k < len(mm)
        rows.append(d_)
T = pd.DataFrame(rows); T.to_pickle(X + 'xpath.pkl')
pd.set_option('display.width', 250)
for nm, g in T.groupby('候補'):
    print('==', nm, len(g), '件')
    cols = [f'{t}分' for t in TS] + ['引け']
    print(pd.DataFrame({'平均': g[cols].mean(), '中央': g[cols].median(), 'プラスの割合': (g[cols] > 0).mean()}).T.round(2).to_string())
    for lab in ('240分まで', '引けまで'):
        print(lab, '最大含み益% 四分位', g[f'最大含み益%_{lab}'].quantile([.25, .5, .75]).round(2).tolist(), '時刻の中央', g[f'含み益の時刻_{lab}'].median(),
              '最大含み損% 四分位', g[f'最大含み損%_{lab}'].quantile([.25, .5, .75]).round(2).tolist(), '含み益前の含み損 中央', g[f'含み益前の最大含み損%_{lab}'].median().round(2))
    for th in (0.5, 0.8, 1.0):
        h = g[g[f'含み損{th}%到達']]
        print(f'  含み損{th}%に達した', len(h), f'({len(h) / len(g):.0%})', ' 240分の損益 平均', round(h['240分'].mean(), 0), ' 引けの損益 平均', round(h['引け'].mean(), 0), ' 引けでプラス', f"{(h['引け'] > 0).mean():.0%}")
