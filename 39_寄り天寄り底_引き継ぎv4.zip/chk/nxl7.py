# 今の候補一覧の Excel → out/Y7_寄り天寄り底_今の候補一覧.xlsx
import numpy as np, pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
O = '/home/claude/yt/out/'; F = O + 'Y7_寄り天寄り底_今の候補一覧.xlsx'
T = pd.read_pickle(O + 'Y7_now.pkl'); Y = pd.read_pickle(O + 'Y7_year.pkl'); V = pd.read_pickle(O + 'YV.pkl')
FONT = 'Arial'; HEAD = PatternFill('solid', fgColor='DDE4EE'); NEG = Font(name=FONT, size=10, color='C00000'); thin = Side(style='thin', color='BBBBBB'); BOX = Border(top=thin, bottom=thin, left=thin, right=thin)
WARN = PatternFill('solid', fgColor='FFF2CC')
wb = Workbook(); wb.remove(wb.active)
FMT = {'勝率': '0%', 'PF': '0.00', 'RF': '0.0', '該当率': '0%', 't': '0.00'}
def fmt_for(col):
    for k, f in FMT.items():
        if col.endswith(k) or col.endswith(k + '_')or ('_' + k) in col: return f
    return '#,##0;-#,##0'
def sheet(name, title, notes=()):
    ws = wb.create_sheet(name); ws['A1'] = title; ws['A1'].font = Font(name=FONT, bold=True, size=13); r = 2
    for n in notes: c = ws.cell(r, 1, n); c.font = Font(name=FONT, size=10, color='555555'); r += 1
    return ws, r + 1
def table(ws, r, df, widths=None, wrap_cols=(), freeze_col=1):
    for j, c in enumerate(df.columns, 1):
        x = ws.cell(r, j, str(c)); x.font = Font(name=FONT, bold=True, size=10); x.fill = HEAD; x.border = BOX; x.alignment = Alignment(wrap_text=True, vertical='center')
    ws.row_dimensions[r].height = 42
    for i, row in enumerate(df.itertuples(index=False), r + 1):
        for j, v in enumerate(row, 1):
            col = df.columns[j - 1]
            if isinstance(v, np.generic): v = v.item()
            if isinstance(v, float) and np.isnan(v): v = None
            if isinstance(v, float) and np.isinf(v): v = '∞'
            x = ws.cell(i, j, v); x.border = BOX; x.font = Font(name=FONT, size=10)
            x.alignment = Alignment(wrap_text=col in wrap_cols, vertical='top')
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                x.number_format = fmt_for(col)
                if v < 0 and fmt_for(col) == '#,##0;-#,##0': x.font = NEG
    if widths:
        for j, w in enumerate(widths, 1): ws.column_dimensions[get_column_letter(j)].width = w
    ws.freeze_panes = ws.cell(r + 1, freeze_col + 1)
    return r + len(df) + 2

# ---------------------------------------------------------------- 説明・基準
ws, r = sheet('説明と基準', '寄り天・寄り底：今の候補一覧（元の手順・13pt、上位5本、2026-10-17）',
              ['※ 手法チェックの結果、この候補の前向き成績は「候補選びに2026年までのデータを使った」ことで良く見えている（本当の前向きでは −7,595円）。売買ではなく記録の材料として見てください'])
B = [('1. 対象のトレード', '日中の寄り（8:45〜）だけ。判定は先物、売買は CFD（FOREXCOM:JP225）。13pt控除後、1枚＝68,800円換算。逆張りは条件なしの段階で残った48候補の入る形（32通り）、順張りは42通り', '130,658トレード'),
     ('2. 指標の区分', '278指標を 3分割・5分割・上位/下位10%・値ごとに区分。境目は2017〜21年のその向き・売買のデータの分位（出来高の後半のみの指標は2023年）', '—'),
     ('3. ふるい', '1トレードの「506手じまい平均」の、同じ向き・売買・入る形の条件なしとの差。入る形ごとの t の中央値が 後半（2022〜）で絶対値1以上（後半のみの指標は2024年以降で1.5以上）、後半の該当率3%以上。差がプラスなら「入る」、マイナスなら「避ける」', '通過 215／298／180／243'),
     ('4. 評価', '強さ5段×手じまい506通りから選ぶ。単点（最良1点）と周辺（強さ・手じまい各軸±1の平均が最良）。選ぶ期間で15件以上・最悪の1回 −1,000円以上。5つの評価の形（前半→後半、22-23→24-26、WF後半、WF全期間、WF直近3年）', '68,660行'),
     ('5. 残す', '5つの形のうち3つ以上プラス、中央 +20円以上、年10件以上', '23,041候補'),
     ('6. 重なりでまとめる', '2022年以降に入る日の集合の Ochiai、平均連結、区切り0.5', '990グループ'),
     ('7. 案3（分類ごと）', '前の付け方：今のルール（2017〜25で選んだ強さ×手じまい）での選ぶ期間の1回平均の順（15件以上、前向き記録マイナスは除外）。新しい付け方：前向きRF（合計÷最大DD）の順（前向き20件以上・前向きプラス・2017〜21プラス）。それぞれ上位5本、同じグループは最上位だけ', '40本'),
     ('8. 絞り込み', '入る日が75%以上重なる候補は1本（前向きRFの良い方）。前向きPF1.2未満は記録だけ', '売買35本・記録だけ5本'),
     ('優先順位', '①両方の付け方に入る（今回は無し）②良い方の順位 ③前の付け方の順位', '—'),
     ('運用（前向き検証）', '同じ向き2本、同じセッションで手じまった後は入らない。前向き 2024〜26：45,069円・最大DD 5,452円', '—')]
r = table(ws, r, pd.DataFrame(B, columns=['段階', '基準', '数']), widths=[20, 120, 22], wrap_cols=('基準',))
G = [('前向き', '各年 t のルールを、t より前のデータで選んだ強さ×手じまいにして、2022〜2026/10/8 を売買した成績（窓埋めと同じ）。ただし候補自体は2026年までのデータで選んでいる'),
     ('今のルール', '2017〜25年で選んだ強さ×手じまい（今使うルール）を、2017〜2026年の全期間に当てた成績。2025年までは選ぶのに使ったデータ'),
     ('条件', '向きのある指標は「寄りの動き（8:45→観察の終わり）と同じ向き＝プラス」。「避ける」は、その区分に当たる日は入らない'),
     ('観察・入る', '観察＝8:45から何時までの先物の動きを見るか。入る：0＝観察の終わり、+5＝5分後、c25/c50＝動きの25%/50%だけ入る向きに動いたら次の足、pkK25/50＝天井から動きの25%/50%戻したら、pkP10/20＝天井から0.1%/0.2%戻したら、HA1/HA5＝1分/5分の平均足が逆向きに、前足5＝5分足の終値が前の足の安値（高値）を割ったら、RSI1＝1分RSIが70（30）を割ったら、末尾 n＝観察の後に天井を更新してからの反転だけ、pbK25/50＝押した後に天井を更新、HAb1/HAb5＝平均足が逆向きの後に戻ったら'),
     ('強さ', '観察の動きの大きさ。全部／上位50・33・20・10%（2017〜21年の分布）'),
     ('手じまい', '%：利確・損切りは入った値段からの%、倍：観察の動きの幅の倍、指標：RSI・平均足・前足で手じまい。時間：分、AM＝前場引け11:30、C＝日中の引け。inf＝なし'),
     ('平均_20pt', 'コストを20ptにしたときの1回平均（寄り直後のスプレッドの広がりの目安）')]
ws.cell(r, 1, '用語').font = Font(name=FONT, bold=True); r += 1
table(ws, r, pd.DataFrame(G, columns=['用語', '意味']), wrap_cols=('意味',))

# ---------------------------------------------------------------- 売買する／記録だけ
main = ['優先順位', '分類', '条件', '区分の境目', '該当率', '観察', '入る', '選び方', '強さ', '手じまいの型', '利確', '損切り', '時間', '選ばれた理由',
        '前向き_件数', '前向き_勝率', '前向き_PF', '前向き_平均', '前向き_平均_20pt', '前向き_合計', '前向き_最大DD', '前向き_RF', '前向き_最悪',
        '前向き2022', '前向き2023', '前向き2024', '前向き2025', '前向き2026',
        '今のルール_件数', '今のルール_勝率', '今のルール_PF', '今のルール_平均', '今のルール_合計', '今のルール_最大DD', '今のルール_最悪', '今のルール_前半2017_21_平均', '今のルール_後半2022_26_平均',
        '選ぶ期間の1回平均_2017_25', '選ぶ期間の件数', '前半→後半_平均', '22-23→24-26_平均', 'WF後半_平均', 'WF全期間_平均', 'WF直近3年_平均', 'プラスの数', '中央', '年件数_中央', '条件なし_中央', '条件なしとの差',
        'ふるい_前半t', 'ふるい_後半t', 'グループの大きさ', 'グループの安定']
W = [6, 11, 34, 22, 7, 10, 7, 6, 9, 7, 7, 7, 7, 30] + [9] * (len(main) - 14)
ws, r = sheet('売買する35本', '売買する候補（全体の優先順位順）', ['前向き＝各年のルールで 2022〜2026/10/8。今のルール＝2017〜25年で選んだルールを全期間に当てた成績。円'])
table(ws, r, T[T.扱い == '売買する'][main], widths=W, wrap_cols=('条件', '選ばれた理由', '区分の境目'), freeze_col=3)
ws, r = sheet('記録だけ5本', '記録だけの候補（理由付き）', ['重なり75%以上＝ほかの候補と入る日の75%以上が同じ（前向きRFの良い方を残した）。PF1.2未満＝前向きPFが1.2未満'])
table(ws, r, T[T.扱い == '記録だけ'][['記録だけの理由'] + main], widths=[20] + W, wrap_cols=('条件', '選ばれた理由', '区分の境目', '記録だけの理由'), freeze_col=4)

# ---------------------------------------------------------------- 年ごとの合計（横並び）
cols = ['優先順位', '扱い', '分類', '条件', '観察', '入る'] + [f'今{y}' for y in range(2017, 2027)] + [f'前向き{y}' for y in range(2022, 2027)]
X = T[cols].copy(); X.columns = [c.replace('今', '今のルール ') if c.startswith('今') else c.replace('前向き', '前向き ') for c in cols]
ws, r = sheet('年ごとの合計', '年ごとの損益の合計（円）', ['今のルール 2017〜2025 は選ぶのに使ったデータ。2026 は 10/8 まで。赤字はマイナス'])
r0 = r; r = table(ws, r, X, widths=[6, 9, 11, 34, 10, 7] + [11] * 15, wrap_cols=('条件',), freeze_col=6)
n = len(X); last = r0 + n
ws.cell(last + 1, 4, '合計（40本、記録だけを含む）').font = Font(name=FONT, bold=True)
for j in range(7, 7 + 15):
    L = get_column_letter(j); c = ws.cell(last + 1, j, f'=SUM({L}{r0 + 1}:{L}{last})'); c.number_format = '#,##0;-#,##0'; c.font = Font(name=FONT, bold=True); c.border = BOX

# ---------------------------------------------------------------- 年ごとの詳しい成績（縦）
YY = Y.merge(T[['優先順位', '扱い']], on='優先順位')
cols = ['優先順位', '扱い', '分類', '条件', '観察', '入る', '年', '今のルール_件数', '今のルール_勝率', '今のルール_PF', '今のルール_平均', '今のルール_合計', '今のルール_最悪',
        '前向き_件数', '前向き_勝率', '前向き_PF', '前向き_平均', '前向き_合計', '前向き_最悪']
ws, r = sheet('年ごとの成績', '候補×年の件数・勝率・PF・平均・合計・最悪', ['前向きは2022年から'])
table(ws, r, YY[cols], widths=[6, 9, 11, 34, 10, 7, 6] + [9] * 12, wrap_cols=('条件',), freeze_col=7)

# ---------------------------------------------------------------- 運用の前向き
v = V[(V.候補の集まり == '全部（4区分）') & (V.N == 5)][['方針', '件数', '合計', '最大DD', '合計割る最大DD', '一回平均', '最悪の1日', '二本目', '2024', '2025', '2026']].copy()
v['方針'] = v.方針.map({'A1': '先着1本', 'B': '両建て', 'C1': '同じ向き2本', 'D1': '両建て＋2本目'})
ws, r = sheet('運用の前向き', '4分類の候補（上位5本）をまとめて1口座で動かした成績（2024〜26）',
              ['各年の候補選び（案3）はその年より前のデータ。ただし候補の集まりは2026年までのデータで作っている', '参考：候補選びの全段階を前のデータだけで行う本当の前向きでは、同じ向き2本で −7,595円（2024 −16,189／2025 −353／2026 +8,948）'])
r = table(ws, r, v, widths=[14, 7, 11, 11, 12, 10, 11, 8, 11, 11, 11])
for rr in (3,):
    ws.cell(rr, 1).fill = WARN
wb.save(F); print(F)
