# (a) 新しい手じまいを足すと良くなるか（本当の前向き 2019〜2026、9時台48形）
#   A：今の格子（2,151通り）  B：A＋新しい36通り  C：新しい36通りだけ
#   各形のルールは1回平均で選ぶ（単点、15件以上・最悪 −1,000円以上）。2段目は xpick と同じ（合計÷最大DD 順、重なり75%未満、2本・3本、同じ向き2本）
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/chk')
import xeng, xnew
from xeng import PM, PO, PH, IND, INF
X = '/home/claude/yt/outx/'
M = pd.read_pickle(X + 'XM.pkl'); R0 = np.load(X + 'XR.npy', mmap_mode='r'); E0 = pd.read_pickle(X + 'XEXITS.pkl')
rows = np.load(X + 'XN_rows.npy'); RN = np.load(X + 'XN_R.npy'); EN = pd.read_pickle(X + 'XN_EXITS.pkl')
import xeval as xv
QL = xv.QL; YRS = M.t.dt.year.values; TE = M.te.values.astype('int64'); SID = M.sid.values; NQ = 7
QN = ['全部', '上位50%', '上位33%', '上位20%', '上位15%', '上位10%', '上位5%']
pos = {r: i for i, r in enumerate(rows)}
BND = {y: int(pd.Timestamp(f'{y}-01-01', tz='Asia/Tokyo').timestamp() // 60) for y in range(2019, 2028)}
EXALL = pd.concat([E0, EN], ignore_index=True); NA = len(E0); NB_ = len(EN)
SETS = {'A：今の格子': np.r_[np.ones(NA, bool), np.zeros(NB_, bool)], 'B：今の格子＋新しい手じまい': np.ones(NA + NB_, bool), 'C：新しい手じまいだけ': np.r_[np.zeros(NA, bool), np.ones(NB_, bool)]}
def walk(idx, allow):
    Rv = np.hstack([np.asarray(R0[idx], np.float32), RN[[pos[i] for i in idx]].astype(np.float32)])
    ok = ~np.isnan(Rv); ql = QL[idx]; te = TE[idx]; NE_ = Rv.shape[1]; rules = {}
    for y in range(2019, 2028):
        p = np.searchsorted(te, BND[y])
        if p == 0: rules[y] = -1; continue
        best = (-np.inf, -1)
        for q in range(NQ):
            mk = ok[:p] & (ql[:p] >= q)[:, None]; V = np.where(mk, Rv[:p], 0); C = mk.sum(0); S = V.sum(0); W = np.where(mk, Rv[:p], np.inf).min(0)
            with np.errstate(all='ignore'): mean = np.where(C > 0, S / np.maximum(C, 1), np.nan)
            sc = np.where((C >= 15) & (W >= -1000) & allow, np.nan_to_num(mean, nan=-np.inf), -np.inf)
            k = int(np.argmax(sc))
            if sc[k] > best[0]: best = (sc[k], q * NE_ + k)
        rules[y] = best[1]
    ft = []
    for y in range(2019, 2027):
        k = rules[y]
        if k < 0: continue
        q, e = divmod(k, NE_); w = np.flatnonzero((YRS[idx] == y) & (ql >= q))
        for j in w:
            v = Rv[j, e]
            if not np.isnan(v): ft.append((y, int(SID[idx[j]]), int(te[j]), float(v), int(idx[j]), int(e)))
    return rules, ft
G = M.iloc[rows].groupby(['観察', '入る']).indices
RES = {}
for sname, allow in SETS.items():
    FT = []; SH = []
    for c, ((ob, en), ii) in enumerate(G.items()):
        idx = rows[ii]; idx = idx[np.argsort(TE[idx], kind='stable')]
        rules, ft = walk(idx, allow); SH.append(dict(cid=c, 観察=ob, 入る=en, **{f'k{y}': rules[y] for y in rules}))
        FT += [(c,) + t for t in ft]
    RES[sname] = (pd.DataFrame(SH), pd.DataFrame(FT, columns=['cid', '年', 'sid', 'te', '損益', 'row', 'e']).sort_values(['cid', 'te'], kind='stable'))
    print(sname, len(FT), flush=True)
def st_(v):
    v = np.asarray(v, float)
    if len(v) == 0: return dict(件数=0, 合計=0.0, 最大DD=0.0)
    eq = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, eq])[1:] - eq).max(); gl = -v[v < 0].sum()
    return dict(件数=len(v), 勝率=(v > 0).mean(), PF=v[v > 0].sum() / gl if gl > 0 else np.inf, 平均=v.mean(), 合計=v.sum(), 最大DD=dd, RF=v.sum() / dd if dd > 0 else np.inf, 最悪=v.min())
# 手じまいの時刻
EXT = {}
def ext_time(row, e):
    key = (row, e)
    if key in EXT: return EXT[key]
    r = M.iloc[row]; fill = None if (r.fill is None or (isinstance(r.fill, float) and np.isnan(r.fill))) else float(r.fill)
    if e < NA:
        t = xeng.sim((int(r.te), fill, r.mv, r.tcap, r.tam, r.peak0, r.B, r.pcl, r.ncl), want_time=True)[1][e]
    else:
        ex = EN.iloc[e - NA]; kind, tf = ex.利確型.split('_'); tf = int(tf); s = float(ex.損切り); tm = ex.時間
        te = int(r.te); j0 = np.searchsorted(PM, te); jc = np.searchsorted(PM, r.tcap); e_ = fill if fill is not None else PO[j0]
        mm = PM[j0:jc]; n = len(mm); adv = np.maximum.accumulate(PH[j0:jc] - e_)
        ts, _ = xnew.sig(kind, tf, te, r.tcap, e_); si = np.searchsorted(adv, s / 100 * e_) if np.isfinite(s) else n; slt = mm[si] if si < n else INF
        tl = n if tm == 'C' else min(np.searchsorted(mm, mm[0] + int(tm)), n); tlt = mm[tl] if tl < n else r.tcap
        t = min(slt, ts, tlt)
    EXT[key] = t; return t
def simulate(FT, t, cids, maxpos=2):
    pr = {c: i for i, c in enumerate(cids)}; tr = FT[(FT.年 == t) & FT.cid.isin(pr)].copy(); tr['pr'] = tr.cid.map(pr)
    tr = tr.sort_values(['sid', 'te', 'pr']); out = []
    for s, g in tr.groupby('sid', sort=False):
        held = []; closed = False
        for r in g.itertuples():
            still = []
            for h in held:
                if h[1] <= r.te: closed = True; out.append(h)
                else: still.append(h)
            held = still
            if closed or len(held) >= maxpos: continue
            held.append((r.te, ext_time(r.row, r.e), r.cid, r.損益, s))
        out += held
    return pd.DataFrame(out, columns=['入る', '手じまう', 'cid', '損益', 'sid'])
def pick(FT, t, Nn, ovl=.75):
    past = FT[FT.年 < t]; S = []
    for c, g in past.groupby('cid'):
        s = st_(g.損益.values)
        if s['件数'] >= 20 and s['合計'] > 0: S.append((c, min(s['RF'], 50), set(g.sid)))
    S.sort(key=lambda z: -z[1]); keep = []
    for c, rf, days in S:
        if any(len(days & d2) / min(len(days), len(d2)) >= ovl for _, d2 in keep): continue
        keep.append((c, days))
        if len(keep) >= Nn: break
    return [c for c, _ in keep]
SUM = []; PORT = []; SHAPES = []
for sname, (SH, FT) in RES.items():
    per = []
    for c, g in FT.groupby('cid'):
        s = st_(g.損益.values); per.append(dict(設定=sname, cid=c, 観察=SH.loc[c, '観察'], 入る=SH.loc[c, '入る'], **s, **{str(y): g[g.年 == y].損益.sum() for y in range(2019, 2027)}))
    per = pd.DataFrame(per); SHAPES.append(per)
    SUM.append(dict(設定=sname, 形の数=len(per), 合計プラスの割合=(per.合計 > 0).mean(), 合計_中央=per.合計.median(), 合計_平均=per.合計.mean(), PF_中央=per.PF.clip(upper=5).median(), RF_中央=per.RF.clip(upper=20).median()))
    for Nn in (1, 2, 3):
        Hs = []; names = {}
        for t in range(2021, 2027):
            cids = pick(FT, t, Nn); H = simulate(FT, t, cids); H['年'] = t; Hs.append(H); names[t] = ' / '.join(f"{SH.loc[c, '観察'][-4:]} {SH.loc[c, '入る']}" for c in cids)
        H = pd.concat(Hs); PORT.append(dict(設定=sname, 本数=Nn, **st_(H.sort_values('手じまう').損益.values), **{str(t): H[H.年 == t].損益.sum() for t in range(2021, 2027)}, **{f'選んだ形_{t}': names[t] for t in range(2021, 2027)}))
S = pd.DataFrame(SUM); P = pd.DataFrame(PORT); SHP = pd.concat(SHAPES)
# 新しい手じまいが選ばれた割合（B の各形・各年のルール）
SHb = RES['B：今の格子＋新しい手じまい'][0]; NE_ = NA + NB_
kk = [SHb[f'k{y}'] for y in range(2019, 2028)]; kk = np.concatenate([k.values for k in kk]); kk = kk[kk >= 0]
newshare = (kk % NE_ >= NA).mean()
SHb['今の手じまい'] = [EXALL.iloc[k % NE_][['利確型', '利確', '損切り型', '損切り', '時間']].astype(str).str.cat(sep=' ') if k >= 0 else '' for k in SHb.k2027]
pickle.dump(dict(S=S, P=P, SHP=SHP, RES=RES, newshare=newshare, SHb=SHb), open(X + 'xa.pkl', 'wb'))
pd.set_option('display.width', 250); print(S.round(2).to_string(index=False)); print('新しい手じまいが選ばれた割合（B、各形×各年）', round(newshare, 3))
print(P[['設定', '本数', '件数', 'PF', '合計', '最大DD', 'RF', '2021', '2022', '2023', '2024', '2025', '2026']].round(2).to_string(index=False))
a = SHP[SHP.設定 == 'A：今の格子'].set_index('cid').合計; b = SHP[SHP.設定 == 'B：今の格子＋新しい手じまい'].set_index('cid').合計
print('B が A より良い形', int((b > a + 1).sum()), '同じ', int(((b - a).abs() <= 1).sum()), '悪い', int((b < a - 1).sum()))
