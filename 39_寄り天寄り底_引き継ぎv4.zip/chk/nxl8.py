# 1年前に選んでいた候補の答え合わせ → out/Y8_寄り天寄り底_1年前の候補の答え合わせ.xlsx
import pickle, numpy as np, pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
N = '/home/claude/yt/outn/'; F = '/home/claude/yt/out/Y8_寄り天寄り底_1年前の候補の答え合わせ.xlsx'
S, Pl, Pt, Cm = pickle.load(open(N + 'nyear.pkl', 'rb'))
FONT = 'Arial'; HEAD = PatternFill('solid', fgColor='DDE4EE'); thin = Side(style='thin', color='BBBBBB'); BOX = Border(top=thin, bottom=thin, left=thin, right=thin)
GOOD = PatternFill('solid', fgColor='E3F1E3'); BAD = PatternFill('solid', fgColor='FBE3E1')
wb = Workbook(); wb.remove(wb.active)
def fmt(c):
    if '勝率' in c or '割合' in c: return '0%'
    if c.endswith('PF') or c.endswith('RF'): return '0.00'
    if '一回平均' in c or c.endswith('平均'): return '0.0'
    return '#,##0;-#,##0'
def sheet(name, title, notes=()):
    ws = wb.create_sheet(name); ws['A1'] = title; ws['A1'].font = Font(name=FONT, bold=True, size=13); r = 2
    for n in notes: ws.cell(r, 1, n).font = Font(name=FONT, size=10, color='555555'); r += 1
    return ws, r + 1
def table(ws, r, df, widths=None, wrap=(), freeze=1):
    for j, c in enumerate(df.columns, 1):
        x = ws.cell(r, j, c); x.font = Font(name=FONT, bold=True, size=10); x.fill = HEAD; x.border = BOX; x.alignment = Alignment(wrap_text=True, vertical='center')
    ws.row_dimensions[r].height = 40
    for i, row in enumerate(df.itertuples(index=False), r + 1):
        for j, v in enumerate(row, 1):
            c = df.columns[j - 1]
            if isinstance(v, np.generic): v = v.item()
            if isinstance(v, float) and np.isnan(v): v = None
            if isinstance(v, float) and np.isinf(v): v = '∞'
            if isinstance(v, bool): v = '○' if v else ''
            x = ws.cell(i, j, v); x.border = BOX; x.font = Font(name=FONT, size=10, color='C00000' if isinstance(v, (int, float)) and v < 0 else '000000')
            x.alignment = Alignment(wrap_text=c in wrap, vertical='top')
            if isinstance(v, (int, float)): x.number_format = fmt(c)
    if widths:
        for j, w in enumerate(widths, 1): ws.column_dimensions[get_column_letter(j)].width = w
    ws.freeze_panes = ws.cell(r + 1, freeze + 1); return r + len(df) + 2
ws, r = sheet('説明', '寄り天・寄り底：1年前に選んでいた候補の答え合わせ（13pt、2026-10-17）')
L = [('やったこと', '2024・2025・2026年の初めに立ったつもりで、その前の年までのデータだけで候補選びの全段階（入る形の絞り込み→ふるい→評価・残す→重なり→案3）をやり直し、選んだ候補がその年どうだったかを1本ずつ確かめた（＝本当の前向き）'),
     ('選び方', '全部・上位5本：4分類それぞれ案3の上位5本（重なり75%・PF1.2の絞り込みも同じ）。条件なし・売りのみ・上位5本：条件を付けない候補から、売り（逆張り売り・順張り売り）の上位5本。重なりのグループが同じものは1本になるので、実際は1〜2本'),
     ('その年の成績', 'その年のルール（その年より前のデータで選んだ強さ×手じまい）で、候補を1本だけ単独で売買した成績。口座の成績は同じ向き2本で動かした合計'),
     ('候補の集まり全体', 'その年の判断で残っていたすべての候補（2024年 12,890、2025年 5,033、2026年 7,634）のうち、その年に5件以上売買したもの。選んだ候補がこれより良ければ、案3の選び方が効いている'),
     ('今の候補との重なり', '今の35本（売買する）・40本（記録だけを含む）と同じ候補か（向き・売買・条件・観察・入るが同じ）'),
     ('読み方の要点', '①選んだ候補の1回平均は、12組（3年×4分類）のうち集まり全体より良いのは2025年の逆張り売りだけで、多くは同じか悪い ②成績を決めているのは「その年にどの分類が勝ったか」（例：2024年の逆張り買いは集まり全体で −103円） ③条件なし・売りのみは 2024年 −1,979円・2025年 +1,307円・2026年 +4,387円 ④1年前に選んだ候補と今の35本の重なりは 0／1／5本')]
for k, v in L:
    ws.cell(r, 1, k).font = Font(name=FONT, bold=True, size=10); c = ws.cell(r, 2, v); c.font = Font(name=FONT, size=10); c.alignment = Alignment(wrap_text=True, vertical='top'); r += 1
ws.column_dimensions['A'].width = 20; ws.column_dimensions['B'].width = 120
P = Pt.rename(columns=lambda c: c.replace('口座_', '口座の')); P['確かめる年'] = P.確かめる年.astype(str)
ws, r = sheet('口座の成績', 'その年の口座の成績（同じ向き2本）'); table(ws, r, P, widths=[11, 26, 7, 10, 11, 11, 11, 9])
C = Cm.copy(); C['確かめる年'] = C.確かめる年.astype(str); C['選んだ方が良い'] = C.選んだ候補_一回平均 > C.集まり全体_一回平均
ws, r = sheet('選んだ候補と集まり全体', '選んだ候補（売買する、単独）と、その年の候補の集まり全体の比較', ['1回平均＝その年の合計÷件数。選んだ方が良いなら○'])
r0 = r; table(ws, r, C, widths=[11, 26, 11, 9, 11, 9, 13, 13, 13, 11])
for i, ok in enumerate(C.選んだ方が良い): ws.cell(r0 + 1 + i, 11).fill = GOOD if ok else BAD
Q = Pl.copy(); Q['確かめる年'] = Q.確かめる年.astype(str)
ws, r = sheet('候補の集まり全体', 'その年の判断で残っていた候補すべての、その年の成績（その年5件以上）', ['順張り売りは条件なしの候補が残っていない年がある（空欄）'])
table(ws, r, Q, widths=[11, 11, 10, 11, 11, 11, 16, 16])
D = S.copy(); D['確かめる年'] = D.確かめる年.astype(str)
D = D.rename(columns=lambda c: c.replace('選んだ時_', '選んだ時：').replace('その年_', 'その年：'))
ws, r = sheet('選んだ候補1本ずつ', '各年の初めに選んだ候補の一覧と、その年の成績', ['選んだ時：その年より前のデータでの成績。その年：選んだ後、その年に単独で売買した成績'])
table(ws, r, D, widths=[9, 22, 11, 16, 34, 10, 8, 7, 6, 6] + [10] * 14 + [8, 8], wrap=('条件', '扱い'), freeze=3)
wb.save(F); print(F)
