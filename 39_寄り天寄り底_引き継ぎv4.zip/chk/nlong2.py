# 条件なしの全候補（632）の長い本当の前向き（2019〜2026）で
#   ① 続けて良い候補は翌年も良いか（t＝2021〜2026、選ぶのは t より前の前向き記録だけ）
#   ② 口座で動かす（各年の初めに選び、同じ向き2本）
#   NEST_COST=flat でコスト統一
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/chk'); import nest
SUF = nest.SUF
C, FT = pickle.load(open(nest.N + f'nlong{SUF}.pkl', 'rb'))
g = FT.groupby(['cid', '年']).損益
Y = pd.DataFrame(dict(n=g.size(), s=g.sum())).reset_index()
PIV_n = Y.pivot(index='cid', columns='年', values='n').reindex(C.cid).fillna(0)
PIV_s = Y.pivot(index='cid', columns='年', values='s').reindex(C.cid).fillna(0)
YRS = list(range(2019, 2027))
def past_stats(t):
    """t より前の前向き記録（2019〜t−1）"""
    ys = [y for y in YRS if y < t]; n = PIV_n[ys]; s = PIV_s[ys]
    out = pd.DataFrame(index=C.cid)
    out = out.copy(); out['年数'] = len(ys); out['プラスの年'] = ((s > 0) & (n >= 5)).sum(1); out['5件以上の年'] = (n >= 5).sum(1)
    out['合計'] = s.sum(1); out['件数'] = n.sum(1); out['平均'] = out.合計 / out.件数.replace(0, np.nan)
    v = FT[FT.年 < t]; dd = {}; pf = {}
    for c, ii in v.groupby('cid').indices.items():
        x = v.損益.values[ii]; eq = np.cumsum(x); dd[c] = (np.maximum.accumulate(np.r_[0, eq])[1:] - eq).max(); gl = -x[x < 0].sum(); pf[c] = x[x > 0].sum() / gl if gl > 0 else np.inf
    out['最大DD'] = pd.Series(dd); out['PF'] = pd.Series(pf); out['RF'] = out.合計 / out.最大DD.replace(0, np.nan)
    return out
RULES = {'毎年プラス（各年5件以上）': lambda p: (p.プラスの年 == p.年数),
         '1年だけマイナス可': lambda p: (p['5件以上の年'] == p.年数) & (p.プラスの年 >= p.年数 - 1),
         '過去の合計プラス': lambda p: (p.合計 > 0) & (p.件数 >= 20),
         '過去の1回平均 上位10%（分類内）': None}
rows = []; SELS = {}
for t in range(2021, 2027):
    p = past_stats(t).join(C.set_index('cid')[['分類', '向き', '売買', '観察', '入る', '選び方']])
    cur = pd.DataFrame(dict(n_t=PIV_n[t], s_t=PIV_s[t])); p = p.join(cur)
    q = p[p.n_t >= 5]
    for kb, gg in q.groupby('分類'):
        base = dict(確かめる年=t, 分類=kb, 全体_本数=len(gg), 全体_1回平均=gg.s_t.sum() / gg.n_t.sum(), 全体_プラスの割合=(gg.s_t > 0).mean())
        for nm, f in RULES.items():
            m = f(gg) if f is not None else (gg.平均 >= gg.平均.quantile(.9)) & (gg.件数 >= 20)
            h = gg[m]
            rows.append(dict(base, 基準=nm, 選んだ本数=len(h), 選んだ_1回平均=h.s_t.sum() / h.n_t.sum() if len(h) else np.nan, 選んだ_プラスの割合=(h.s_t > 0).mean() if len(h) else np.nan))
    SELS[t] = p
R = pd.DataFrame(rows); R['全体との差'] = R.選んだ_1回平均 - R.全体_1回平均
# ② 口座：各年の初めに、基準を満たす候補を過去のRF順に分類ごと上位5本（同じ入る形の単点・周辺は良い方だけ）、同じ向き2本
POOLS = {'売りのみ': ['逆張り売り', '順張り売り'], '逆張り売り': ['逆張り売り'], '全部': ['逆張り売り', '逆張り買い', '順張り売り', '順張り買い'], '買いのみ': ['逆張り買い', '順張り買い']}
port = []; HS = {}
for nm in ['毎年プラス（各年5件以上）', '1年だけマイナス可', '過去の合計プラス', '（基準なし・過去のRF順）', '（基準なし・過去の1回平均順）']:
    for pn, grp in POOLS.items():
        tot = {}; Hs = []
        for t in range(2021, 2027):
            p = SELS[t]; p = p[p.分類.isin(grp)]
            m = RULES[nm](p) if nm in RULES and RULES[nm] is not None else (p.件数 >= 20)
            s = p[m].sort_values('平均' if '1回平均順' in nm else 'RF', ascending=False)
            s = s.reset_index().drop_duplicates(['分類', '観察', '入る']).groupby('分類').head(5)
            s['扱い'] = ''
            H = nest.simulate(FT, t, s[['cid', '扱い']], 'C1'); H['年'] = t; Hs.append(H); tot[t] = H.損益.sum(); tot[f'本数{t}'] = len(s)
        H = pd.concat(Hs); sm = nest.summ(H); HS[(nm, pn)] = H
        port.append(dict(基準=nm, 集まり=pn, **sm, **{str(k): v for k, v in tot.items()}))
Pt = pd.DataFrame(port)
pickle.dump((R, Pt, HS), open(nest.N + f'nlong2{SUF}.pkl', 'wb'))
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 300)
print('全体の1回平均（分類×年）'); print(R.drop_duplicates(['確かめる年', '分類']).pivot(index='分類', columns='確かめる年', values='全体_1回平均').round(1).to_string())
print('\n基準ごと：全体より良かった組 / 組、差の平均（本数で重み）')
for nm, g2 in R.dropna(subset=['選んだ_1回平均']).groupby('基準'):
    print(' ', nm, int((g2.全体との差 > 0).sum()), '/', len(g2), round(np.average(g2.全体との差, weights=g2.選んだ本数), 1))
print('\n売り（逆張り売り）だけ：'); print(R[R.分類 == '逆張り売り'][['確かめる年', '基準', '選んだ本数', '選んだ_1回平均', '全体_1回平均', '全体との差']].round(1).to_string(index=False))
print('\n口座（2021〜26、同じ向き2本）'); print(Pt[['基準', '集まり', '件数', '合計', '最大DD', '2021', '2022', '2023', '2024', '2025', '2026']].round(0).to_string(index=False))
