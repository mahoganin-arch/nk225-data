# 拡張エンジンの照合：既存の形・既存の手じまい（%の利確×損切り×時間）で、元のエンジン（コスト統一）と一致するか
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/chk'); import xeng
from xeng import TPS, SLS, TIMES, EXD
N = '/home/claude/yt/outn/'
YM = pd.read_pickle(N + 'YM.pkl'); YR = np.load(N + 'YR_flat.npy', mmap_mode='r'); EXo = pd.read_pickle('/home/claude/yt/out/EXITS.pkl')['D']
sel = YM[(YM.向き == '逆張り') & (YM.売買 == '売り') & (YM.src == 'E2')].sample(300, random_state=1)
# 元の % の手じまい → 新しい番号
TPo = [0.1, 0.2, 0.3, 0.5, 0.8, 1.2, np.inf]; SLo = [0.1, 0.2, 0.3, 0.5, 0.8, np.inf]; To = [15, 30, 60, 120, 240, 'AM', 'C']
mp = []
for i, r in EXo.iterrows():
    if r.型 != '%': continue
    tp = r.利確; sl = r.損切り; tm = r.時間
    a = 0 if not np.isfinite(tp) else [k for k, t in enumerate(TPS) if t == ('%', tp)][0]
    b = 0 if not np.isfinite(sl) else [k for k, s in enumerate(SLS) if s == ('%', sl)][0]
    c = TIMES.index(tm if tm in ('AM', 'C') else int(tm))
    j = EXD[(EXD.群 == '値段') & (EXD.ia == a) & (EXD.ib == b) & (EXD.ic == c)].index[0]; mp.append((i, j))
mp = np.array(mp); diffs = []
for r in sel.itertuples():
    if r.te >= r.tcap: continue
    out = xeng.sim((int(r.te), None, r.mv, r.tcap, r.tam if r.tam == r.tam else r.m0 + 165, -np.inf, np.nan, np.nan, np.nan))
    old = np.asarray(YR[r.Index, mp[:, 0]], np.float32); new = out[mp[:, 1]]
    ok = ~np.isnan(old) & ~np.isnan(new); diffs.append(np.abs(old[ok] - new[ok]))
d = np.concatenate(diffs); print('照合した値', len(d), '最大の差', d.max().round(2), '差1円超の割合', (d > 1).mean().round(4), '差の中央', np.median(d).round(3))
