# 「毎年続けて良い成績の候補」は翌年も良いか（本当の前向きで確かめる）
#   各年 t の候補の集まり（t より前のデータで作った nest_t）で、t より前の前向き記録（2022〜t−1、各年のルール）が
#   「毎年プラス」だった候補を選び、t 年の成績を集まり全体と比べる。基準の強さを変えて見る
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/chk'); import nest
SUF = nest.SUF
RULES = {'毎年プラス（各年3件以上）': (3, 0.0, 1.0), '毎年プラス（各年5件以上）': (5, 0.0, 1.0), '毎年PF1.2以上（各年5件以上）': (5, 0.0, 1.2), '毎年1回平均+30円以上（各年5件以上）': (5, 30.0, 1.0)}
rows = []; picks = {}
for t in (2024, 2025, 2026):
    Cd, FT, _ = pickle.load(open(nest.N + f'nest_{t}{SUF}.pkl', 'rb'))
    past = FT[FT.年 < t]; yrs = list(range(2022, t))
    g = past.groupby(['cid', '年']).損益
    A = pd.DataFrame(dict(n=g.size(), s=g.sum(), m=g.mean(), gp=past.assign(p=past.損益.clip(lower=0)).groupby(['cid', '年']).p.sum(),
                          gl=-past.assign(q=past.損益.clip(upper=0)).groupby(['cid', '年']).q.sum())).reset_index()
    A['pf'] = np.where(A.gl > 0, A.gp / A.gl.replace(0, np.nan), np.inf)
    cur = FT[FT.年 == t].groupby('cid').損益.agg(['size', 'sum', 'mean']).rename(columns={'size': 'n_t', 'sum': 's_t', 'mean': 'm_t'})
    X = Cd[['cid', '分類', '指標']].set_index('cid').join(cur)
    X = X[X.n_t >= 5]
    for kb, gg in X.groupby('分類'):
        rows.append(dict(確かめる年=t, 基準='（集まり全体）', 分類=kb, 本数=len(gg), その年プラスの割合=(gg.s_t > 0).mean(), その年1回平均=gg.s_t.sum() / gg.n_t.sum()))
    for nm, (nmin, mmin, pfmin) in RULES.items():
        ok = A[(A.n >= nmin) & (A.s > 0) & (A.m >= mmin) & (A.pf >= pfmin)].groupby('cid').年.nunique()
        good = set(ok[ok == len(yrs)].index)
        picks[(t, nm)] = good
        for kb, gg in X[X.index.isin(good)].groupby('分類'):
            rows.append(dict(確かめる年=t, 基準=nm, 分類=kb, 本数=len(gg), その年プラスの割合=(gg.s_t > 0).mean(), その年1回平均=gg.s_t.sum() / gg.n_t.sum()))
R = pd.DataFrame(rows)
# 分類ごとに全体との差
base = R[R.基準 == '（集まり全体）'].set_index(['確かめる年', '分類'])[['その年1回平均', 'その年プラスの割合']]
R = R.join(base, on=['確かめる年', '分類'], rsuffix='_全体'); R['全体との差'] = R.その年1回平均 - R.その年1回平均_全体
pickle.dump((R, picks), open(nest.N + f'ncons{SUF}.pkl', 'wb'))
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 200)
print(R[R.基準 != '（集まり全体）'][['確かめる年', '基準', '分類', '本数', 'その年プラスの割合', 'その年プラスの割合_全体', 'その年1回平均', 'その年1回平均_全体', '全体との差']].round(2).to_string(index=False))
s = R[R.基準 != '（集まり全体）']
print('\n基準ごと：全体より良かった組の数 / 組の数、1回平均の差（本数で重み）')
for nm, g in s.groupby('基準'):
    print(nm, int((g.全体との差 > 0).sum()), '/', len(g), round(np.average(g.全体との差, weights=g.本数), 1))
