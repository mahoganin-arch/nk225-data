# 第6段②：髭の先端は抜かれにくいか。髭の先端と「髭なしの足で、終値から同じ距離（ATR換算）にある価格」とで、その後N本（15分足）以内に抜かれる割合を比べる
import pandas as pd, numpy as np, pickle, sys, warnings; warnings.filterwarnings('ignore')
from numba import njit
from s1 import atr_
from s14 import m15, link
OUT='/mnt/user-data/outputs/'; NS=np.array([1,2,4,8,12,20,40,80,160]); LAB=['15分','30分','1時間','2時間','3時間','5時間','10時間','20時間','40時間']
@njit(cache=True)
def reach(l,c,a,qh,ql,NS):
    n=len(l); U=np.full((n,len(NS)),np.nan); D=np.full((n,len(NS)),np.nan); m=len(qh); KM=NS[-1]
    for i in range(n):
        if l[i]<0 or l[i]+KM>=m or not a[i]>0: continue
        hi=-1e18; lo=1e18; p=0
        for k in range(1,KM+1):
            hi=max(hi,qh[l[i]+k]); lo=min(lo,ql[l[i]+k])
            if k==NS[p]: U[i,p]=(hi-c[i])/a[i]; D[i,p]=(c[i]-lo)/a[i]; p+=1
    return U,D
def pick(mask,H):
    out=[]; free=0
    for i in np.where(mask)[0]:
        if i<free: continue
        free=i+H+1; out.append(i)
    return np.array(out,np.int64)
def load(tf,q):
    P=pickle.load(open(f'P{tf}.pkl','rb')); b=P['b']; n=P['n']; o,h,lw,c=(b[k].values for k in ('open','high','low','close')); a=atr_(b.high,b.low,b.close).values
    f,l=link(b,q,tf); U,D=reach(l,c,a,q.high.values,q.low.values,NS); valid=np.zeros(n,bool); valid[P['warm']:n-70]=True; valid&=~np.isnan(U[:,-1])
    body=np.abs(c-o); up=h-np.maximum(o,c); dn=np.minimum(o,c)-lw; rq=pd.qcut(pd.Series((h-lw)/a).fillna(0),5,labels=False,duplicates='drop').values
    return dict(b=b,n=n,a=a,c=c,body=body,valid=valid,yr=b.t.dt.year.values,per=P['per'],rq=rq,
                上髭=dict(w=up,M=U,d=(h-c)/a),下髭=dict(w=dn,M=D,d=(c-lw)/a))
def expect(B,S,idx,p,strata):
    # 対照：同じ側の髭がATRの0.25倍未満の足。層（年、または年×値幅の5分位）ごとに「到達幅 > d」の割合を求める
    ctl=B['valid']&(S['w']<0.25*B['a']); key=B['yr']*10+(B['rq'] if strata=='年×値幅' else 0); out=np.full(len(idx),np.nan)
    for k in np.unique(key[idx]):
        pool=np.sort(S['M'][ctl&(key==k),p]); j=np.where(key[idx]==k)[0]
        if len(pool)<30: continue
        out[j]=1-np.searchsorted(pool,S['d'][idx[j]],side='right')/len(pool)
    return out
BANDS=(('ATR0.5倍未満',0,0.5),('ATR0.5〜0.7倍',0.5,0.7),('ATR0.7〜1.0倍',0.7,1.0),('ATR1.0倍以上',1.0,99),('ATR0.7倍以上',0.7,99))
if __name__=='__main__':
    q=m15(); rows=[]; keep={}
    for tf in (60,30):
        B=load(tf,q); keep[tf]=B
        for d in ('上髭','下髭'):
            S=B[d]
            for lab,s0,s1 in BANDS:
                m=(B['body']>0)&(S['w']>=2*B['body'])&(S['w']>=s0*B['a'])&(S['w']<s1*B['a'])&B['valid']
                for p,N in enumerate(NS):
                    idx=pick(m,int(np.ceil(N*15/tf))); obs=(S['M'][idx,p]>S['d'][idx]).astype(float); r=dict(足=tf,向き=d,大きさ=lab,経過=LAB[p],回数=len(idx),髭の長さ_中央値ATR=round(np.median(S['d'][idx]),2),抜かれた割合=round(obs.mean()*100,1))
                    for st in ('年','年×値幅'):
                        ex=expect(B,S,idx,p,st); ok=~np.isnan(ex); r[f'対照（{st}）']=round(ex[ok].mean()*100,1); zz=[]
                        for pp in (0,1):
                            s=ok&(B['per'][idx]==pp); zz.append((obs[s]-ex[s]).sum()/np.sqrt((ex[s]*(1-ex[s])).sum()))
                            if st=='年×値幅': r[['17-22','23-26'][pp]+' 差']=round((obs[s]-ex[s]).mean()*100,1); r[['17-22','23-26'][pp]+' z']=round(zz[-1],2)
                        r[f'z（{st}）']=round(sum(zz)/np.sqrt(2),2)
                    rows.append(r)
    T=pd.DataFrame(rows); T.to_csv(OUT+'stage6_2_髭の先端は抜かれにくいか.csv',index=False,encoding='utf-8-sig'); T.to_pickle('T15.pkl'); print(len(T))
