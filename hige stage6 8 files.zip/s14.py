# 第6段①：15分足で見た髭のでき方の分類（主系統＝1時間足・上髭・実体の2倍・ATR0.7倍以上・40本）。評価は s9 と同じ超過。偽データ＝区分ラベルの入れ替え
import pandas as pd, numpy as np, pickle, sys, warnings; warnings.filterwarnings('ignore')
from s1 import atr_
from s10 import exc, pick, st, two
OUT='/mnt/user-data/outputs/'; CUT=pd.Timestamp('2026-10-09',tz='Asia/Tokyo')
def m15():
    import os
    if not os.path.exists('m15.pkl'):
        from ld import bars; bars('m15.csv').to_pickle('m15.pkl')
    d=pd.read_pickle('m15.pkl'); return d[d.t<CUT].reset_index(drop=True)
def link(b,q,tf):
    # 各上位足に属する15分足の範囲 [f,l]（なければ -1）
    bm=b.m.values.astype(np.int64); qm=q.m.values.astype(np.int64); n=len(b)
    k=np.searchsorted(bm,qm,side='right')-1; ok=(k>=0)&(qm-bm[np.clip(k,0,n-1)]<tf)
    f=np.full(n,-1,np.int64); l=np.full(n,-1,np.int64); j=np.where(ok)[0]; kk=k[ok]
    l[kk]=j; f[kk[::-1]]=j[::-1]; return f,l
def feats(b,q,f,l,a,side):
    # side=+1 上髭（高値側）、-1 下髭（価格を反転して同じ計算）
    n=len(b); s=side
    H=(b.high.values if s>0 else -b.low.values); O=s*b.open.values; C=s*b.close.values
    qh=(q.high.values if s>0 else -q.low.values); ql=(-q.low.values if s<0 else q.low.values); qc=s*q.close.values; qo=s*q.open.values; qv=q.volume.values
    wk=H-np.maximum(O,C); R=dict(nb=np.zeros(n,int),pos=np.full(n,np.nan),ret=np.full(n,np.nan),vol=np.full(n,np.nan),tch=np.zeros(n,int),k=np.full(n,-1))
    for i in np.where((f>=0)&(wk>0)&(a>0))[0]:
        sl=slice(f[i],l[i]+1); hh=qh[sl]; nb=len(hh); k=int(np.argmax(hh)); R['nb'][i]=nb; R['k'][i]=k
        R['pos'][i]=(k+0.5)/nb                                  # 高値を付けた15分足の位置（0〜1）
        R['ret'][i]=(hh[k]-qc[sl][k])/wk[i]                     # 高値を付けた15分足の中で、髭の何割を戻したか
        v=qv[sl]; R['vol'][i]=v[k]/v.sum()*nb if v.sum()>0 else np.nan   # 高値の15分足の出来高÷1本あたり平均
        R['tch'][i]=int((hh>=hh[k]-0.25*a[i]).sum())            # 高値から0.25ATR以内に届いた15分足の本数
    return R
def classes(R):
    c={}
    c['高値の時期']=np.where(R['pos']<0.5,'前半','後半')
    c['戻し方']=np.where(R['ret']>=2/3,'高値の15分足の中で2/3以上戻した',np.where(R['ret']<1/3,'高値の15分足では1/3未満（後の足で戻した）','中間'))
    c['出来高の集中']=np.where(R['vol']>=1.4,'高値の足に集中（平均の1.4倍以上）',np.where(R['vol']<1.0,'平均未満','平均の1.0〜1.4倍'))
    c['高値を試した回数']=np.where(R['tch']>=2,'2本以上','1本だけ')
    return c
def zdiff(e,per,sel):
    t=[]
    for p in (0,1):
        x=e[sel&(per==p)]; y=e[~sel&(per==p)]
        if len(x)<5 or len(y)<5: return np.nan
        t.append((x.mean()-y.mean())/np.sqrt(x.var(ddof=1)/len(x)+y.var(ddof=1)/len(y)))
    return sum(t)/np.sqrt(2)
if __name__=='__main__':
    P=pickle.load(open('P60.pkl','rb')); b=P['b']; q=m15(); n=len(b); per=P['per']; a=atr_(b.high,b.low,b.close).values; cost=(10/b.close*100).values
    f,l=link(b,q,60); raw,x,e,valid=exc(b,pd.Series(a),P['warm'],60,40); valid=valid&(f>=0)
    o,h,lw,c=(b[k].values for k in ('open','high','low','close')); body=np.abs(c-o); up=h-np.maximum(o,c); dn=np.minimum(o,c)-lw
    rows=[]; rng=np.random.default_rng(1); summ=[]
    for nm,side,w,s0,s1 in (('主系統：上髭ATR0.7倍以上',1,up,0.7,99),('比較：上髭ATR0.5倍未満',1,up,0,0.5),('比較：下髭ATR0.7倍以上',-1,dn,0.7,99)):
        R=feats(b,q,f,l,a,side); CL=classes(R)
        idx=pick((body>0)&(w>=2*body)&(w>=s0*a)&(w<s1*a),valid,e,40); pi=per[idx]; ei=e[idx]
        d=dict(対象=nm,分類='（全体）',区分='-'); d.update(two(idx,per,raw,x,e,cost)); rows.append(d); cells=[]
        for cn,cv in CL.items():
            for g in pd.unique(cv[idx]):
                sel=cv[idx]==g; d=dict(対象=nm,分類=cn,区分=g); d.update(two(idx[sel],per,raw,x,e,cost)); d['他の区分との差z']=round(zdiff(ei,pi,sel),2); rows.append(d); cells.append(sel)
        act=np.array([zdiff(ei,pi,s) for s in cells]); NR=2000; mx=np.zeros(NR); c2=np.zeros(NR)
        for r in range(NR):
            pm=np.arange(len(idx))
            for p in (0,1): j=np.where(pi==p)[0]; pm[j]=rng.permutation(j)
            z=np.array([zdiff(ei,pi,s[pm]) for s in cells]); mx[r]=np.nanmax(np.abs(z)); c2[r]=(np.abs(z)>=2).sum()
        summ.append(dict(対象=nm,回数=len(idx),区分数=len(cells),最大差z_本番=round(np.nanmax(np.abs(act)),2),最大差z_偽の平均=round(mx.mean(),2),最大差z_偽の上位5pct=round(np.percentile(mx,95),2),差z2以上_本番=int((np.abs(act)>=2).sum()),差z2以上_偽の平均=round(c2.mean(),2)))
    T=pd.DataFrame(rows); T.to_csv(OUT+'stage6_1_髭のでき方の分類.csv',index=False,encoding='utf-8-sig'); S=pd.DataFrame(summ); S.to_csv(OUT+'stage6_1_髭のでき方の分類_偽データ比較.csv',index=False,encoding='utf-8-sig')
    T.to_pickle('T14.pkl'); S.to_pickle('S14.pkl'); print(len(T))
