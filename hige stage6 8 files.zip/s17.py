# 第8段の土台＋第1回：髭 × 行き過ぎ1条件（同じ足・上位足〔形成中／確定済み〕）。成績は髭足確定後を15分足で追う。超過（%）とATR単位、偽データ＝成績をずらす
import pandas as pd, numpy as np, pickle, sys, itertools, warnings; warnings.filterwarnings('ignore')
from numba import njit
from s1 import atr_
from s14 import m15, link
import s11
OUT='/mnt/user-data/outputs/'; NS=(1,2,4,8,12,20,40,80,160); LAB=dict(zip(NS,['15分','30分','1時間','2時間','3時間','5時間','10時間','20時間','40時間']))
TFN={15:'15分足',30:'30分足',60:'1時間足',240:'4時間足',1440:'日足'}
BENCH='先1か月のみ'
def roll(x,W):
    # 上昇分として引く平均の取り方
    if BENCH=='前後1か月': return pd.Series(x).rolling(W,center=True,min_periods=W//2).mean().values
    if BENCH=='前後6か月': return pd.Series(x).rolling(6*W,center=True,min_periods=3*W).mean().values
    if BENCH=='先1か月のみ': return pd.Series(x[::-1]).rolling(W//2,min_periods=W//4).mean().values[::-1]
    if BENCH=='先6か月のみ': return pd.Series(x[::-1]).rolling(3*W,min_periods=W).mean().values[::-1]
def base(tf,q):
    if tf==15: b=q.copy(); n=len(b); l=np.arange(n); warm=5200
    else: P=pickle.load(open(f'P{tf}.pkl','rb')); b=P['b']; n=P['n']; f,l=link(b,q,tf); warm=P['warm']
    o,h,lw,c=(b[k].values for k in ('open','high','low','close')); a=atr_(b.high,b.low,b.close).values; m=len(q); qo,qc=q.open.values,q.close.values
    valid=np.zeros(n,bool); valid[warm:]=True; valid&=(l>=0)&(l+NS[-1]+1<m)&(a>0); lc=np.clip(l,0,m-1)
    per=(b.t.dt.year.values>=2023).astype(np.int64); cell=b.t.dt.hour.values*5+pd.qcut(pd.Series((h-lw)/a).fillna(0),5,labels=False,duplicates='drop').values; W=920*4; E={};EA={};X={}
    for N in NS:
        rq=np.full(m,np.nan); rq[:m-N]=qc[N:]-qo[1:m-N+1]; pc=rq/qc*100
        xq=pc-roll(pc,W); aq=rq-roll(rq,W)
        x=np.where(valid,xq[lc],np.nan); xa=np.where(valid,aq[lc]/a,np.nan)
        E[N]=x-pd.Series(x).groupby(cell).transform('mean').values; EA[N]=xa-pd.Series(xa).groupby(cell).transform('mean').values; X[N]=x
    return dict(tf=tf,b=b,n=n,l=lc,a=a,o=o,h=h,lw=lw,c=c,E=E,EA=EA,X=X,per=per,valid=valid,cost=10/c*100,warm=warm)
def wicks(B):
    o,h,lw,c,a=B['o'],B['h'],B['lw'],B['c'],B['a']; body=np.abs(c-o); W={}
    for d,s in (('上髭',1),('下髭',-1)):
        H=h if s>0 else -lw; C=s*c; O=s*o; w=H-np.maximum(O,C)
        for (sk,s0),(ck,cm) in itertools.product((('下限なし',0),('ATR0.3倍以上',0.3),('ATR0.5倍以上',0.5),('ATR0.7倍以上',0.7)),(('色不問',C==C),('陽線',c>o),('陰線',c<o))):
            W[d,sk,ck]=(body>0)&(w>=2*body)&(w>=s0*a)&cm&B['valid']
    return W
def gid(q,U):
    if U==15: return np.arange(len(q))
    if U in (30,60): P=pickle.load(open(f'P{U}.pkl','rb')); bm=P['b'].m.values.astype(np.int64); g=np.searchsorted(bm,q.m.values.astype(np.int64),side='right')-1
    else: g=s11.groups(q,'4時間足' if U==240 else '日足')
    return np.unique(g,return_inverse=True)[1]
def tfvals(q,g,s):
    # 15分足の各時点での上位足の指標（形成中＝その時点までの値で作った上位足、確定済み＝直前に終わった上位足）。s=-1 は価格を反転（下髭用）
    pc=s*q.close.values; ph=(q.high.values if s>0 else -q.low.values); pl=(q.low.values if s>0 else -q.high.values); G=g.max()+1; m=len(q)
    end=np.r_[g[1:]!=g[:-1],True]; Cg=pc[end]; Hg=pd.Series(ph).groupby(g).max().values; Lg=pd.Series(pl).groupby(g).min().values
    A=atr_(pd.Series(Hg),pd.Series(Lg),pd.Series(Cg)).values; dC=np.diff(Cg,prepend=np.nan)
    AU=pd.Series(np.clip(dC,0,None)).ewm(alpha=1/14,adjust=False,min_periods=14).mean().values; AD=pd.Series(np.clip(-dC,0,None)).ewm(alpha=1/14,adjust=False,min_periods=14).mean().values
    cs=pd.Series(Cg); pv=lambda x:np.where(g>0,np.r_[np.nan,x][g],np.nan)       # 1本前の確定足の値
    def back(k): y=np.full(G,np.nan); y[k:]=Cg[:-k]; return y[g]                # k本前の確定足の終値
    ch=pc-pv(Cg); au=(pv(AU)*13+np.clip(ch,0,None))/14; ad=(pv(AD)*13+np.clip(-ch,0,None))/14; F={'rsi':100*au/(au+ad)}; atr=pv(A)
    for N in (20,75):
        s1=pv(cs.rolling(N-1).sum().values)+pc; s2=pv((cs*cs).rolling(N-1).sum().values)+pc*pc; ma=s1/N
        F[f'dev{N}']=(pc-ma)/atr
        if N==20: F['bbz']=(pc-ma)/np.sqrt(np.maximum(s2/N-ma*ma,1e-12))
    F['run5']=(pc-back(5))/atr; F['run20']=(pc-back(20))/atr
    e=np.where(end,np.arange(m),-1); e=np.maximum.accumulate(e); Cf={k:np.where(e>=0,v[np.clip(e,0,None)],np.nan) for k,v in F.items()}
    return F,Cf
CONDS=(('RSI70以上','rsi',70,1),('RSI80以上','rsi',80,1),('RSI50未満','rsi',50,-1),('終値がBB+2σ超','bbz',2,1),('SMA20から+2ATR以上','dev20',2,1),('SMA75から+3ATR以上','dev75',3,1),('直前5本で+1.5ATR以上','run5',1.5,1),('直前20本で+3ATR以上','run20',3,1))
def conds(q,tf,B,side):
    # 返り値：{(条件名,見る足,取り方):髭足ごとの真偽}。下髭は上下を反転して同じ条件（RSI30以下、BB-2σ割れ…）
    s=1 if side=='上髭' else -1; out={}
    for U in (15,30,60,240,1440):
        if U<tf: continue
        F,Cf=tfvals(q,gid(q,U),s)
        for mode,V in (('同じ足',F),) if U==tf else (('形成中',F),('確定済み',Cf)):
            for nm,k,th,sg in CONDS:
                v=V[k][B['l']]; out[nm,TFN[U],mode]=(v>=th) if sg>0 else (v<th)
    return out
@njit(cache=True)
def pick(ix,H,e):
    out=np.empty(len(ix),np.int64); k=0; free=0
    for i in ix:
        if i<free or np.isnan(e[i]): continue
        free=i+H+1; out[k]=i; k+=1
    return out[:k]
@njit(cache=True)
def tz2(idx,e,per):
    q=np.zeros((2,3))
    for i in idx:
        v=e[i]
        if np.isnan(v): continue
        p=per[i]; q[p,0]+=1; q[p,1]+=v; q[p,2]+=v*v
    t=np.zeros(2)
    for p in range(2):
        n=q[p,0]
        if n<2: t[p]=np.nan; continue
        mu=q[p,1]/n; var=(q[p,2]-n*mu*mu)/(n-1); t[p]=mu/np.sqrt(max(var,1e-18)/n)
    return t[0],t[1],(t[0]+t[1])/np.sqrt(2)
def flip(nm,side):
    if side=='上髭': return nm
    for a_,b_ in (('RSI70以上','RSI30以下'),('RSI80以上','RSI20以下'),('RSI50未満','RSI50超'),('BB+2σ超','BB-2σ割れ'),('から+','から-'),('で+','で-'),('以上','以上下')): nm=nm.replace(a_,b_)
    return nm.replace('以下下','以下')
def run(name,condfn,NR=100,seed=7):
    q=m15(); rows=[]; SG=[]; Bs=[]
    for tf in (60,30,15):
        B=base(tf,q); Bs.append(B); W=wicks(B); CD={d:condfn(q,tf,B,d) for d in ('上髭','下髭')}; z0={}
        for (d,sk,ck),wm in W.items():
            for N in NS: z0[d,sk,ck,N]=tz2(pick(np.where(wm)[0],int(np.ceil(N*15/tf)),B['E'][N]),B['E'][N],B['per'])[2]
            for (cn,un,mode),cm in CD[d].items():
                ix=np.where(wm&np.nan_to_num(cm).astype(bool))[0]
                if len(ix)<90: continue
                for N in NS:
                    idx=pick(ix,int(np.ceil(N*15/tf)),B['E'][N]); p=B['per'][idx]
                    if (p==0).sum()<60 or (p==1).sum()<30: continue
                    t0,t1,z=tz2(idx,B['E'][N],B['per']); za=tz2(idx,B['EA'][N],B['per'])[2]; sg=1 if z>0 else -1; SG.append((len(Bs)-1,N,idx,mode))
                    r=dict(髭の足=TFN[tf],髭=d+ck.replace('色不問',''),大きさ=sk,条件=flip(cn,d),条件を見る足=un,取り方=mode,経過=LAB[N],売買='買い' if z>0 else '売り')
                    for k,nm in ((0,'17-22'),(1,'23-26')):
                        v=sg*B['X'][N][idx[p==k]]-B['cost'][idx[p==k]]; r[nm+' 回数']=int((p==k).sum()); r[nm+' t']=round((t0,t1)[k],2); r[nm+' 超過PF']=round(v[v>0].sum()/max(-v[v<=0].sum(),1e-9),2)
                    r['z']=round(z,2); r['z（ATR単位）']=round(za,2); r['髭だけのz']=round(z0[d,sk,ck,N],2); rows.append(r)
    T=pd.DataFrame(rows); T.to_pickle(f'T_{name}.pkl'); T.reindex(T.z.abs().sort_values(ascending=False).index).to_csv(OUT+f'{name}_一覧.csv',index=False,encoding='utf-8-sig'); print('本番',len(T),flush=True)
    rng=np.random.default_rng(seed); A=np.zeros((NR,len(SG)))
    for r in range(NR):
        u=rng.uniform(0.1,0.9); ES={}
        for bi,B in enumerate(Bs):
            w0=B['warm']; sft=int(u*(B['n']-w0))
            for N in NS: e=B['E'][N].copy(); e[w0:]=np.roll(e[w0:],sft); ES[bi,N]=e
        for k,(bi,N,idx,mode) in enumerate(SG): A[r,k]=abs(tz2(idx,ES[bi,N],Bs[bi]['per'])[2])
    np.save(f'null_{name}.npy',A.astype(np.float32)); out=[]
    for grp,sel in [('全体',np.ones(len(T),bool))]+[(g,(T['取り方']==g).values) for g in T['取り方'].unique()]:
        az=T.z.abs().values[sel]; a=A[:,sel]; mx=np.nanmax(a,1); d=dict(系統=grp,通り=int(sel.sum()),最大z_本番=az.max(),最大z_偽平均=mx.mean(),最大z_偽上位5pct=np.percentile(mx,95))
        for k in (2.5,3,3.5): c=(a>=k).sum(1); d[f'z{k}以上_本番']=int((az>=k).sum()); d[f'z{k}以上_偽平均']=c.mean(); d[f'z{k}以上_偽上位5pct']=np.percentile(c,95)
        out.append(d)
    S=pd.DataFrame(out).round(2); S.to_csv(OUT+f'{name}_偽データ比較.csv',index=False,encoding='utf-8-sig'); S.to_pickle(f'S_{name}.pkl'); print(S.T.to_string())
if __name__=='__main__': run('stage8_1_髭×行き過ぎ',conds)
