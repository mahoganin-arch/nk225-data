# 第7段①：連続して高値（安値）を更新した後に出た髭。1時間足・30分足・15分足の髭を、その後15分足単位で追う。
# 評価：s9 と同じ超過（%）と、ATR単位にそろえた超過の両方。偽データ＝成績系列を時間方向にずらす
import pandas as pd, numpy as np, pickle, sys, itertools, warnings; warnings.filterwarnings('ignore')
from s1 import atr_
from s14 import m15, link
OUT='/mnt/user-data/outputs/'; NS=(1,2,4,8,12,20,40,80,160); LAB=dict(zip(NS,['15分','30分','1時間','2時間','3時間','5時間','10時間','20時間','40時間']))
def sh(x,k):
    y=np.zeros(len(x),x.dtype) if x.dtype==bool else np.full(len(x),np.nan); y[k:]=x[:-k]; return y
def build(tf,q):
    if tf==15: b=q.copy(); n=len(b); f=l=np.arange(n); warm=5200
    else: P=pickle.load(open(f'P{tf}.pkl','rb')); b=P['b']; n=P['n']; f,l=link(b,q,tf); warm=P['warm']
    o,h,lw,c=(b[k].values for k in ('open','high','low','close')); a=atr_(b.high,b.low,b.close).values; m=len(q); qo,qc=q.open.values,q.close.values
    valid=np.zeros(n,bool); valid[warm:]=True; valid&=(l>=0)&(l+NS[-1]+1<m)&(a>0); lc=np.clip(l,0,m-1)
    yr=b.t.dt.year.values; per=(yr>=2023).astype(int); hr=b.t.dt.hour.values
    cell=hr*5+pd.qcut(pd.Series((h-lw)/a).fillna(0),5,labels=False,duplicates='drop').values; W=920*4
    E={};EA={};X={}
    for N in NS:
        rq=np.full(m,np.nan); rq[:m-N]=qc[N:]-qo[1:m-N+1]           # 15分足jの次の始値→N本目の終値（円）
        pc=rq/qc*100; xq=pc-pd.Series(pc).rolling(W,center=True,min_periods=W//2).mean().values
        aq=rq-pd.Series(rq).rolling(W,center=True,min_periods=W//2).mean().values
        x=np.where(valid,xq[lc],np.nan); xa=np.where(valid,aq[lc]/a,np.nan)
        E[N]=x-pd.Series(x).groupby(cell).transform('mean').values; EA[N]=xa-pd.Series(xa).groupby(cell).transform('mean').values; X[N]=x
    body=np.abs(c-o); S={}
    for d,s in (('上髭',1),('下髭',-1)):
        H=h if s>0 else -lw; C=s*c; O=s*o; w=H-np.maximum(O,C)
        nh=H>pd.Series(H).shift(1).rolling(20).max().values           # 20本高値（安値）の更新
        up1=H>sh(H,1)                                                # 前の足より高値切り上げ
        ctx={'不問':np.ones(n,bool)}
        for k in (2,3,4):
            mm=np.ones(n,bool)
            for j in range(1,k+1): mm&=sh(up1,j)
            ctx[f'直前{k}本が連続で高値切り上げ']=mm
        cnt=sum(sh(nh,j).astype(int) for j in range(1,6))
        ctx['直前5本のうち2本以上が20本高値更新']=cnt>=2; ctx['直前5本のうち3本以上が20本高値更新']=cnt>=3
        ctx['直前2本が連続で20本高値更新']=sh(nh,1)&sh(nh,2); ctx['直前3本が連続で20本高値更新']=sh(nh,1)&sh(nh,2)&sh(nh,3)
        for (sk,s0),(ck,cm),(xk,xm),(tk,tm) in itertools.product((('下限なし',0),('ATR0.3倍以上',0.3),('ATR0.5倍以上',0.5),('ATR0.7倍以上',0.7)),(('色不問',C==C),('髭と同じ向きの色',C<O),('髭と逆向きの色',C>O)),ctx.items(),(('髭足は不問',np.ones(n,bool)),('髭足も20本高値更新',nh))):
            S[d,sk,ck,xk,tk]=(body>0)&(w>=2*body)&(w>=s0*a)&cm&xm&tm&valid
    return dict(tf=tf,n=n,S=S,E=E,EA=EA,X=X,per=per,valid=valid,cost=10/c*100,warm=warm)
def pick(mask,H,e):
    out=[]; free=0
    for i in np.where(mask)[0]:
        if i<free or np.isnan(e[i]): continue
        free=i+H+1; out.append(i)
    return np.array(out,np.int64)
def tz2(v,p):
    t=[]
    for k in (0,1):
        x=v[p==k]; t.append(x.mean()/(x.std(ddof=1)/np.sqrt(len(x))) if len(x)>1 and x.std()>0 else np.nan)
    return t[0],t[1],(t[0]+t[1])/np.sqrt(2)
if __name__=='__main__':
    q=m15(); Bs=[build(tf,q) for tf in (60,30,15)]; rows=[]; SG=[]
    for B in Bs:
        for key,m in B['S'].items():
            for N in NS:
                idx=pick(m,int(np.ceil(N*15/B['tf'])),B['E'][N]); p=B['per'][idx]
                if (p==0).sum()<60 or (p==1).sum()<30: continue
                SG.append((B,N,idx,p)); t0,t1,z=tz2(B['E'][N][idx],p); a0,a1,za=tz2(B['EA'][N][idx],p); sg=1 if z>0 else -1; r=dict(足=B['tf'],向き=key[0],大きさ=key[1],色=key[2],直前の動き=key[3],髭足=key[4],経過=LAB[N],N=N)
                for k,nm in ((0,'17-22'),(1,'23-26')):
                    v=sg*B['X'][N][idx[p==k]]-B['cost'][idx[p==k]]; r[nm+' 回数']=int((p==k).sum()); r[nm+' 超過平均%']=round(B['E'][N][idx[p==k]].mean(),4); r[nm+' t']=round((t0,t1)[k],2); r[nm+' 超過PF']=round(v[v>0].sum()/max(-v[v<=0].sum(),1e-9),2)
                r['z']=round(z,2); r['z（ATR単位）']=round(za,2); r['向く売買']='買い' if z>0 else '売り'; rows.append(r)
    T=pd.DataFrame(rows); T['absz']=T.z.abs(); T=T.sort_values('absz',ascending=False).drop(columns='absz'); T.to_csv(OUT+'stage7_1_連続高値更新後の髭_一覧.csv',index=False,encoding='utf-8-sig'); T.to_pickle('T16.pkl'); print('本番',len(T),flush=True)
    rng=np.random.default_rng(7); NR=int(sys.argv[1]) if len(sys.argv)>1 else 100; res=[]
    for r in range(NR):
        u=rng.uniform(0.1,0.9); Z=[]; ES={}
        for B in Bs:
            w0=B['warm']; sft=int(u*(B['n']-w0))
            for N in NS: e=B['E'][N].copy(); e[w0:]=np.roll(e[w0:],sft); ES[B['tf'],N]=e
        for B,N,idx,p in SG:
            e=ES[B['tf'],N][idx]; ok=~np.isnan(e); Z.append(tz2(e[ok],p[ok])[2])
        res.append(np.array(Z))
    pickle.dump(res,open('null16.pkl','wb')); A=np.abs(np.array(res)); az=T.z.abs().values
    S=pd.DataFrame([dict(指標='最大|z|',本番=az.max(),偽の平均=np.nanmax(A,1).mean(),偽の上位5pct=np.percentile(np.nanmax(A,1),95))]+[dict(指標=f'|z|≧{k}の件数',本番=(az>=k).sum(),偽の平均=(A>=k).sum(1).mean(),偽の上位5pct=np.percentile((A>=k).sum(1),95)) for k in (2,2.5,3,3.5)]).round(2)
    S.to_csv(OUT+'stage7_1_連続高値更新後の髭_偽データ比較.csv',index=False,encoding='utf-8-sig'); print(S.to_string())
