# 第6段②の確認：対照の取り方を変えても結論が同じか。(1) 値幅÷ATRが近い足300本（同じ年・同じセッション）を対照にする (2) 対照の母集団を変える (3) 髭の反対方向の同じ距離
import pandas as pd, numpy as np, pickle, warnings; warnings.filterwarnings('ignore')
from s15 import *
def nn(B,ctl,Mc,idx,d,p,K=300):
    hr=B['b'].t.dt.hour.values; ses=((hr>=8)&(hr<16)).astype(int); key=B['yr']*10+ses; rr=B['rr']; out=np.full(len(idx),np.nan)
    for k in np.unique(key[idx]):
        c=np.where(ctl&(key==k))[0]; c=c[np.argsort(rr[c])]; r=rr[c]; m=Mc[c,p]
        if len(c)<K: continue
        for j in np.where(key[idx]==k)[0]:
            s=np.searchsorted(r,rr[idx[j]]); lo=min(max(s-K//2,0),len(c)-K); out[j]=(m[lo:lo+K]>d[j]).mean()
    return out
def zz(obs,ex,per):
    r=[]; ok=~np.isnan(ex)
    for pp in (0,1):
        s=ok&(per==pp); r.append((obs[s]-ex[s]).sum()/np.sqrt((ex[s]*(1-ex[s])).sum()))
    return round(ex[ok].mean()*100,1),round(r[0],2),round(r[1],2),round(sum(r)/np.sqrt(2),2)
if __name__=='__main__':
    q=m15(); rows=[]
    for tf in (60,30):
        B=load(tf,q); b=B['b']; B['rr']=np.nan_to_num(((b.high-b.low).values)/B['a'])
        for d,od in (('上髭','下髭'),('下髭','上髭')):
            S=B[d]; So=B[od]
            for lab,s0,s1 in BANDS:
                m=(B['body']>0)&(S['w']>=2*B['body'])&(S['w']>=s0*B['a'])&(S['w']<s1*B['a'])&B['valid']
                for p,N in enumerate(NS):
                    idx=pick(m,int(np.ceil(N*15/tf))); dd=S['d'][idx]; per=B['per'][idx]; obs=(S['M'][idx,p]>dd).astype(float); r=dict(足=tf,向き=d,大きさ=lab,経過=LAB[p],回数=len(idx),先端を抜いた割合=round(obs.mean()*100,1))
                    for nm,ctl in (('髭なし',B['valid']&(S['w']<0.25*B['a'])),('定義外の全足',B['valid']&~m)):
                        e_,z0,z1,z=zz(obs,nn(B,ctl,S['M'],idx,dd,p),per); r[f'対照（{nm}）']=e_; r[f'z（{nm}）']=z
                        if nm=='髭なし': r['17-22 z']=z0; r['23-26 z']=z1
                    # 反対方向：髭足の終値から、髭と同じ長さだけ反対側にある価格に届いた割合。対照は反対側に髭のない足
                    ob2=(So['M'][idx,p]>dd).astype(float); e_,z0,z1,z=zz(ob2,nn(B,B['valid']&(So['w']<0.25*B['a']),So['M'],idx,dd,p),per)
                    r['反対方向に同じ距離を進んだ割合']=round(ob2.mean()*100,1); r['反対方向の対照']=e_; r['反対方向のz']=z; rows.append(r)
    T=pd.DataFrame(rows); T.to_csv(OUT+'stage6_2b_髭の先端_対照を変えた確認.csv',index=False,encoding='utf-8-sig'); T.to_pickle('T15b.pkl')
