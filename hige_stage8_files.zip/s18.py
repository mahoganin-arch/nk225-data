# 第8段 第2回：髭 × 上位足のトレンド状態（1条件）。同じ足・上位足〔形成中／確定済み〕。物差しは s17 と同じ（先1か月のみ）
import pandas as pd, numpy as np, pickle, sys, time, warnings; warnings.filterwarnings('ignore')
from numba import njit
import s17
from s17 import base, wicks, gid, pick, tz2, NS, LAB, TFN, OUT
from s14 import m15
rma=lambda x,n: pd.Series(x).ewm(alpha=1/n,adjust=False).mean().values
def streak(b):
    b=np.asarray(b,bool); i=np.arange(len(b)); last=np.maximum.accumulate(np.where(~b,i,-1)); return ((i-last)*b).astype(float)
@njit(cache=True)
def stloop(ub,lb,cv):
    n=len(cv); dr=np.ones(n)
    for i in range(1,n):
        if not np.isnan(ub[i-1]):
            if not (ub[i]<ub[i-1] or cv[i-1]>ub[i-1]): ub[i]=ub[i-1]
            if not (lb[i]>lb[i-1] or cv[i-1]<lb[i-1]): lb[i]=lb[i-1]
        dr[i]=1 if cv[i]>ub[i-1] else (-1 if cv[i]<lb[i-1] else dr[i-1])
    return ub,lb,dr
def tfv2(q,g,s):
    # 返り値：F,Cf＝{(分類,条件名,向き):15分足ごとの真偽}。F＝形成中の上位足、Cf＝確定済みの上位足。s=-1 は価格を反転して同じ計算をし、名前だけ実際の向きに直す
    tk=dict(U='上',D='下',yo='陽',inn='陰',kou='好転',gya='逆転',pdi='+DI',mdi='-DI',age='切り上げ',sage='切り下げ',jun='上から短期・中期・長期の順',rev='上から長期・中期・短期の順',up='上昇',dn='下降') if s>0 else \
       dict(U='下',D='上',yo='陰',inn='陽',kou='逆転',gya='好転',pdi='-DI',mdi='+DI',age='切り下げ',sage='切り上げ',jun='上から長期・中期・短期の順',rev='上から短期・中期・長期の順',up='下降',dn='上昇')
    pc=s*q.close.values; po=s*q.open.values; ph=(q.high.values if s>0 else -q.low.values); pl=(q.low.values if s>0 else -q.high.values); G=int(g.max())+1; m=len(q)
    first=np.r_[True,g[1:]!=g[:-1]]; end=np.r_[g[1:]!=g[:-1],True]
    H=pd.Series(ph).groupby(g).cummax().values; L=pd.Series(pl).groupby(g).cummin().values
    Og=po[first]; O=Og[g]; Cg=pc[end]; Hg=H[end]; Lg=L[end]; cs=pd.Series(Cg); hs=pd.Series(Hg); ls=pd.Series(Lg)
    def lag(x,k): y=np.full(G+k,np.nan); y[k:]=x; return y[g]
    F={}
    def add(cat,name,dirn,v): F[cat,name.format(**tk),{'u':tk['up'],'d':tk['dn'],'n':'どちらでもない'}[dirn]]=np.nan_to_num(v).astype(bool)
    # 移動平均
    S={};Sc={}
    for N in (5,10,20,25,50,75,100,200):
        Sc[N]=cs.rolling(N).mean().values; S[N]=(lag(cs.rolling(N-1).sum().values,1)+pc)/N
        add('MAの位置',f'終値がSMA{N}より{{U}}','u',pc>S[N]); add('MAの位置',f'終値がSMA{N}より{{D}}','d',pc<S[N])
    for N in (20,50,75,200):
        p=lag(Sc[N],5); add('MAの傾き',f'SMA{N}が{{U}}向き','u',S[N]>p); add('MAの傾き',f'SMA{N}が{{D}}向き','d',S[N]<p)
    for x,y,z in ((5,20,75),(20,75,200),(25,75,200)):
        a=(S[x]>S[y])&(S[y]>S[z]); b=(S[x]<S[y])&(S[y]<S[z]); ok=~np.isnan(S[z])
        add('MAの並び',f'SMA{x}・{y}・{z}が{{jun}}','u',a); add('MAの並び',f'SMA{x}・{y}・{z}が{{rev}}','d',b); add('MAの並び',f'SMA{x}・{y}・{z}の並びがどちらでもない','n',ok&~a&~b)
    for x,y in ((5,20),(20,75),(50,200)):
        add('MAのクロス',f'SMA{x}がSMA{y}より{{U}}','u',S[x]>S[y]); add('MAのクロス',f'SMA{x}がSMA{y}より{{D}}','d',S[x]<S[y])
    # 一目
    hi=lambda N:np.maximum(lag(hs.rolling(N-1).max().values,1),H); lo=lambda N:np.minimum(lag(ls.rolling(N-1).min().values,1),L)
    mid=lambda N:(hs.rolling(N).max().values+ls.rolling(N).min().values)/2
    ten=(hi(9)+lo(9))/2; kij=(hi(26)+lo(26))/2; sbn=(hi(52)+lo(52))/2; san=(ten+kij)/2
    kijc=mid(26); sac=(mid(9)+kijc)/2; sbc=mid(52)
    a_,b_=lag(sac,25),lag(sbc,25); ct=np.maximum(a_,b_); cb=np.minimum(a_,b_)
    add('一目','終値が雲の{U}','u',pc>ct); add('一目','終値が雲の{D}','d',pc<cb); add('一目','終値が雲の中','n',(pc<=ct)&(pc>=cb))
    add('一目','転換線が基準線より{U}','u',ten>kij); add('一目','転換線が基準線より{D}','d',ten<kij)
    p=lag(kijc,5); add('一目','基準線が{U}向き','u',kij>p); add('一目','基準線が{D}向き','d',kij<p)
    add('一目','遅行線が26本前の足より{U}','u',pc>lag(Hg,25)); add('一目','遅行線が26本前の足より{D}','d',pc<lag(Lg,25))
    a2,b2=lag(sac,50),lag(sbc,50); add('一目','遅行線が26本前の雲より{U}','u',pc>np.maximum(a2,b2)); add('一目','遅行線が26本前の雲より{D}','d',pc<np.minimum(a2,b2))
    add('一目','先行する雲が{yo}転（先行スパン1が2より{U}）','u',san>sbn); add('一目','先行する雲が{inn}転（先行スパン1が2より{D}）','d',san<sbn)
    add('一目','三役{kou}','u',(pc>ct)&(ten>kij)&(pc>lag(Hg,26))); add('一目','三役{gya}','d',(pc<cb)&(ten<kij)&(pc<lag(Lg,26)))
    # ADX・DI
    pC=cs.shift().values; trc=np.fmax(np.fmax(Hg-Lg,np.abs(Hg-pC)),np.abs(Lg-pC)); upc=np.diff(Hg,prepend=np.nan); dnc=-np.diff(Lg,prepend=np.nan)
    ATc=rma(trc,14); SPc=rma(np.where((upc>dnc)&(upc>0),upc,0.0),14); SMc=rma(np.where((dnc>upc)&(dnc>0),dnc,0.0),14)
    pdic=100*SPc/ATc; mdic=100*SMc/ATc; ADc=rma(100*np.abs(pdic-mdic)/(pdic+mdic),14)
    c1=lag(Cg,1); tr=np.fmax(np.fmax(H-L,np.abs(H-c1)),np.abs(L-c1)); up=H-lag(Hg,1); dn=lag(Lg,1)-L
    at=(lag(ATc,1)*13+tr)/14; sp=(lag(SPc,1)*13+np.where((up>dn)&(up>0),up,0.0))/14; sm=(lag(SMc,1)*13+np.where((dn>up)&(dn>0),dn,0.0))/14
    pdi=100*sp/at; mdi=100*sm/at; adx=(lag(ADc,1)*13+100*np.abs(pdi-mdi)/(pdi+mdi))/14
    add('ADX・DI','ADX25以上で{pdi}が優位','u',(adx>=25)&(pdi>mdi)); add('ADX・DI','ADX25以上で{mdi}が優位','d',(adx>=25)&(pdi<mdi)); add('ADX・DI','ADX20未満','n',adx<20)
    p=lag(ADc,5); add('ADX・DI','ADXが上昇中','n',adx>p); add('ADX・DI','ADXが低下中','n',adx<p)
    # MACD
    E12=cs.ewm(span=12,adjust=False).mean().values; E26=cs.ewm(span=26,adjust=False).mean().values; Mc=E12-E26; SGc=pd.Series(Mc).ewm(span=9,adjust=False).mean().values; HSc=Mc-SGc
    e12=lag(E12,1); e12=e12+2/13*(pc-e12); e26=lag(E26,1); e26=e26+2/27*(pc-e26); mc=e12-e26; sg=lag(SGc,1); sg=sg+0.2*(mc-sg); hsn=mc-sg; hp=lag(HSc,1)
    add('MACD','MACDがシグナルより{U}','u',mc>sg); add('MACD','MACDがシグナルより{D}','d',mc<sg); add('MACD','MACDが0より{U}','u',mc>0); add('MACD','MACDが0より{D}','d',mc<0)
    add('MACD','MACDがシグナルより{U}で、差が拡大','u',(hsn>0)&(hsn>hp)); add('MACD','MACDがシグナルより{U}で、差が縮小','u',(hsn>0)&(hsn<hp))
    add('MACD','MACDがシグナルより{D}で、差が拡大','d',(hsn<0)&(hsn<hp)); add('MACD','MACDがシグナルより{D}で、差が縮小','d',(hsn<0)&(hsn>hp))
    # スーパートレンド(10,3)
    A10=rma(trc,10); hl2=(Hg+Lg)/2; UB,LB,DR=stloop(hl2+3*A10,hl2-3*A10,Cg.copy()); CN=np.arange(G)-np.maximum.accumulate(np.where(np.r_[True,DR[1:]!=DR[:-1]],np.arange(G),0))
    d1=lag(DR,1); dr=np.where(pc>lag(UB,1),1.0,np.where(pc<lag(LB,1),-1.0,d1)); cn=np.where(dr!=d1,0.0,lag(CN.astype(float),1)+1); ok=~np.isnan(lag(UB,1))
    add('スーパートレンド','スーパートレンドが{U}向き','u',ok&(dr>0)); add('スーパートレンド','スーパートレンドが{D}向き','d',ok&(dr<0))
    add('スーパートレンド','スーパートレンドが{U}向きに転換して5本以内','u',ok&(dr>0)&(cn<5)); add('スーパートレンド','スーパートレンドが{U}向きで20本超','u',ok&(dr>0)&(cn>20))
    add('スーパートレンド','スーパートレンドが{D}向きに転換して5本以内','d',ok&(dr<0)&(cn<5)); add('スーパートレンド','スーパートレンドが{D}向きで20本超','d',ok&(dr<0)&(cn>20))
    # 平均足
    hcc=(Og+Hg+Lg+Cg)/4; hoc=pd.Series(hcc).ewm(alpha=0.5,adjust=False).mean().shift().values; yc=(hcc>hoc).astype(float); ic=(hcc<hoc).astype(float)
    hc=(O+H+L+pc)/4; ho=hoc[g]; y=hc>ho; i_=hc<ho
    add('平均足','平均足が{yo}線','u',y); add('平均足','平均足が{inn}線','d',i_)
    add('平均足','平均足が{yo}線3本以上連続','u',y&(lag(yc,1)==1)&(lag(yc,2)==1)); add('平均足','平均足が{inn}線3本以上連続','d',i_&(lag(ic,1)==1)&(lag(ic,2)==1))
    # 波の形（20本高値・安値を、その20本前の時点の値と比べる）
    hh=hi(20); ll=lo(20); h0=lag(hs.rolling(20).max().values,20); l0=lag(ls.rolling(20).min().values,20); a=(hh>h0)&(ll>l0); b=(hh<h0)&(ll<l0)
    add('波の形','20本高値・安値がともに{age}','u',a); add('波の形','20本高値・安値がともに{sage}','d',b); add('波の形','20本高値・安値の切り上げ・切り下げが混在','n',~np.isnan(h0)&~a&~b)
    # トレンドの長さ
    for N,K in ((20,20),(75,50)):
        add('トレンドの長さ',f'終値がSMA{N}より{{U}}に{K}本以上連続','u',(pc>S[N])&(lag(streak(Cg>Sc[N]),1)>=K-1)); add('トレンドの長さ',f'終値がSMA{N}より{{D}}に{K}本以上連続','d',(pc<S[N])&(lag(streak(Cg<Sc[N]),1)>=K-1))
    e=np.where(end,np.arange(m),-1); e=np.maximum.accumulate(e); Cf={k:np.where(e>=0,v[np.clip(e,0,None)],False) for k,v in F.items()}
    return F,Cf
_C={}
def conds(q,tf,B,side):
    s=1 if side=='上髭' else -1; out={}
    for U in (15,30,60,240,1440):
        if U<tf: continue
        if (U,s) not in _C: _C[U,s]=tfv2(q,gid(q,U),s)
        F,Cf=_C[U,s]
        for mode,V in (('同じ足',F),) if U==tf else (('形成中',F),('確定済み',Cf)):
            for k,v in V.items(): out[k+(TFN[U],mode)]=v[B['l']]
    return out
@njit(cache=True)
def nullz(idx,e,per,w0,sfts,out):
    L=len(e)-w0
    for r in range(len(sfts)):
        q=np.zeros((2,3))
        for i in idx:
            v=e[w0+((i-w0-sfts[r])%L)]
            if np.isnan(v): continue
            p=per[i]; q[p,0]+=1; q[p,1]+=v; q[p,2]+=v*v
        z=0.0
        for p in range(2):
            n=q[p,0]
            if n<2: z=np.nan; break
            mu=q[p,1]/n; var=(q[p,2]-n*mu*mu)/(n-1); z+=mu/np.sqrt(max(var,1e-18)/n)
        out[r]=abs(z/np.sqrt(2))
def run(name,condfn,NR=100,seed=7,tfs=(60,30,15)):
    q=m15(); rows=[]; NZ=[]; rng=np.random.default_rng(seed); us=rng.uniform(0.1,0.9,NR); buf=np.zeros(NR); t0=time.time()
    for tf in tfs:
        B=base(tf,q); W=wicks(B); w0=B['warm']; sfts=(us*(B['n']-w0)).astype(np.int64); per=B['per']; hold={N:int(np.ceil(N*15/tf)) for N in NS}
        for d in ('上髭','下髭'):
            CD=condfn(q,tf,B,d); z0={}; zc={}
            for (dd,sk,ck),wm in W.items():
                if dd!=d: continue
                for N in NS: z0[sk,ck,N]=tz2(pick(np.where(wm)[0],hold[N],B['E'][N]),B['E'][N],per)[2]
            for key,cm in CD.items():
                ixc=np.where(cm&B['valid'])[0]
                for N in NS: zc[key,N]=tz2(pick(ixc,hold[N],B['E'][N]),B['E'][N],per)[2]      # 条件だけ（髭なしの全足）
                for (dd,sk,ck),wm in W.items():
                    if dd!=d: continue
                    ix=np.where(wm&cm)[0]
                    if len(ix)<90: continue
                    for N in NS:
                        e=B['E'][N]; idx=pick(ix,hold[N],e); p=per[idx]; n1=int(p.sum()); n0=len(p)-n1
                        if n0<60 or n1<30: continue
                        t_0,t_1,z=tz2(idx,e,per); za=tz2(idx,B['EA'][N],per)[2]; sg=1 if z>0 else -1; pf=[]
                        for k in (0,1): v=sg*B['X'][N][idx[p==k]]-B['cost'][idx[p==k]]; pf.append(round(v[v>0].sum()/max(-v[v<=0].sum(),1e-9),2))
                        nullz(idx,e,per,w0,sfts,buf); NZ.append(buf.astype(np.float32))
                        cat,cn,dirn,un,mode=key
                        rows.append((TFN[tf],d+ck.replace('色不問',''),sk,cat,cn,dirn,un,mode,LAB[N],'買い' if z>0 else '売り',n0,round(t_0,2),pf[0],n1,round(t_1,2),pf[1],round(z,2),round(za,2),round(z0[sk,ck,N],2),round(zc[key,N],2)))
            print(tf,d,len(rows),int(time.time()-t0),'秒',flush=True)
    T=pd.DataFrame(rows,columns=['髭の足','髭','大きさ','分類','条件','トレンドの向き','条件を見る足','取り方','経過','売買','17-22 回数','17-22 t','17-22 超過PF','23-26 回数','23-26 t','23-26 超過PF','z','z（ATR単位）','髭だけのz','条件だけのz'])
    A=np.array(NZ).T; T.to_pickle(f'T_{name}.pkl'); np.save(f'null_{name}.npy',A); summary(name,T,A)
def summary(name,T,A):
    out=[]; az_all=T.z.abs().values
    grp=[('全体',np.ones(len(T),bool))]+[('取り方：'+g,(T['取り方']==g).values) for g in T['取り方'].unique()]+[('向き：'+a+'×'+g,((T['髭'].str[:2]==a)&(T['トレンドの向き']==g)).values) for a in ('上髭','下髭') for g in ('上昇','下降','どちらでもない')]
    grp+=[(c+'・'+g,((T['分類']==c)&(T['取り方']==g)).values) for c in T['分類'].unique() for g in T['取り方'].unique()]
    for nm,sel in grp:
        if sel.sum()==0: continue
        az=az_all[sel]; a=A[:,sel]; mx=np.nanmax(a,1); d=dict(系統=nm,通り=int(sel.sum()),最大z_本番=az.max(),最大z_偽平均=mx.mean(),最大z_偽上位5pct=np.percentile(mx,95))
        for k in (2.5,3,3.5): c=(a>=k).sum(1); d[f'z{k}以上_本番']=int((az>=k).sum()); d[f'z{k}以上_偽平均']=c.mean(); d[f'z{k}以上_偽上位5pct']=np.percentile(c,95); d[f'z{k}以上_本番を超えた偽の割合']=(c>=d[f'z{k}以上_本番']).mean()
        out.append(d)
    S=pd.DataFrame(out).round(2); S.to_csv(OUT+f'{name}_偽データ比較.csv',index=False,encoding='utf-8-sig'); S.to_pickle(f'S_{name}.pkl')
    X=T[T.z.abs()>=2.5]; X.reindex(X.z.abs().sort_values(ascending=False).index).to_csv(OUT+f'{name}_一覧.csv',index=False,encoding='utf-8-sig'); print('本番',len(T),'一覧',len(X))
if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='test': run('test8_2',conds,NR=5,tfs=(60,))
    else: run('stage8_2_髭×トレンド',conds)
