# 第8段 第3回：髭 × 行き過ぎ（RSIの刻み、ストキャス、基準線・VWAP乖離、ダイバージェンス、第1回の条件の刻み）。枠組みは s18 と同じ
import pandas as pd, numpy as np, sys, warnings; warnings.filterwarnings('ignore')
from numba import njit
import s17, s18, s11
from s17 import gid, TFN, OUT
from s14 import m15
from s1 import atr_
@njit(cache=True)
def prevmax(Hg,V,N):
    # 各足について、直前N本（当該足を除く）の最高値と、その足での指標の値
    n=len(Hg); M=np.full(n,np.nan); VV=np.full(n,np.nan)
    for j in range(N,n):
        b=j-N
        for k in range(j-N+1,j):
            if Hg[k]>=Hg[b]: b=k
        M[j]=Hg[b]; VV[j]=V[b]
    return M,VV
_V={}
def vwaps(q):
    if 'v' not in _V:
        gd=s11.groups(q,'日足'); ic=q.t.groupby(gd).transform('max').dt.isocalendar(); gw=(ic.year.values.astype(np.int64)*100+ic.week.values.astype(np.int64))
        tp=((q.high+q.low+q.close)/3*q.volume).values; v=q.volume.values.astype(float); out={}
        for nm,g in (('当日',gd),('今週',gw)):
            a=pd.Series(tp).groupby(g).cumsum().values; b=pd.Series(v).groupby(g).cumsum().values; out[nm]=np.where(b>0,a/np.where(b>0,b,1),np.nan)
        _V['v']=out
    return _V['v']
def tfv3(q,g,s):
    up=s>0; OB='買われすぎ' if up else '売られすぎ'; OS='売られすぎ' if up else '買われすぎ'
    pc=s*q.close.values; ph=(q.high.values if up else -q.low.values); pl=(q.low.values if up else -q.high.values); G=int(g.max())+1; m=len(q)
    end=np.r_[g[1:]!=g[:-1],True]; H=pd.Series(ph).groupby(g).cummax().values; L=pd.Series(pl).groupby(g).cummin().values
    Cg=pc[end]; Hg=H[end]; Lg=L[end]; cs=pd.Series(Cg); hs=pd.Series(Hg); ls=pd.Series(Lg)
    def lag(x,k): y=np.full(G+k,np.nan); y[k:]=x; return y[g]
    F={}
    def add(cat,name,dirn,v,done=''): F[cat,name,dirn,done]=np.nan_to_num(v).astype(bool)
    atr=lag(atr_(hs,ls,cs).values,1); F1,_=s17.tfvals(q,g,s)
    # RSI
    dC=np.diff(Cg,prepend=np.nan); ch=pc-lag(Cg,1); R={}; Rc={}
    for n in (9,14,21):
        AU=pd.Series(np.clip(dC,0,None)).ewm(alpha=1/n,adjust=False,min_periods=n).mean().values; AD=pd.Series(np.clip(-dC,0,None)).ewm(alpha=1/n,adjust=False,min_periods=n).mean().values
        au=(lag(AU,1)*(n-1)+np.clip(ch,0,None))/n; ad=(lag(AD,1)*(n-1)+np.clip(-ch,0,None))/n; R[n]=100*au/(au+ad); Rc[n]=100*AU/(AU+AD)
        for th in (60,65,70,75,80): add('RSIの水準',f'RSI{n}が{th}以上' if up else f'RSI{n}が{100-th}以下',OB,R[n]>=th,'済' if n==14 and th in (70,80) else '')
    r=R[14]
    for a,b in ((60,65),(65,70),(70,75),(75,80),(80,101)):
        nm=(f'RSI14が{a}〜{b}' if b<=80 else 'RSI14が80以上（帯）') if up else (f'RSI14が{100-b}〜{100-a}' if b<=80 else 'RSI14が20以下（帯）'); add('RSIの帯',nm,OB,(r>=a)&(r<b))
    add('RSIの水準','RSI14が50未満' if up else 'RSI14が50超',OS,r<50,'済'); add('RSIの水準','RSI14が30以下' if up else 'RSI14が70以上',OS,r<=30)
    # ストキャス（14,3,3）
    hi=lambda N:np.maximum(lag(hs.rolling(N-1).max().values,1),H); lo=lambda N:np.minimum(lag(ls.rolling(N-1).min().values,1),L)
    hh,ll=hs.rolling(14).max().values,ls.rolling(14).min().values; rkc=100*(Cg-ll)/np.where(hh>ll,hh-ll,np.nan); Kc=pd.Series(rkc).rolling(3).mean().values
    h_,l_=hi(14),lo(14); rk=100*(pc-l_)/np.where(h_>l_,h_-l_,np.nan); K=(lag(rkc,1)+lag(rkc,2)+rk)/3; D=(lag(Kc,1)+lag(Kc,2)+K)/3
    f=(lambda x:x) if up else (lambda x:100-x)
    add('ストキャス',f'%Kが80以上' if up else '%Kが20以下',OB,K>=80); add('ストキャス','%Kが90以上' if up else '%Kが10以下',OB,K>=90)
    add('ストキャス','%Kが80以上で%Dより上' if up else '%Kが20以下で%Dより下',OB,(K>=80)&(K>D)); add('ストキャス','%Kが80以上で%Dより下' if up else '%Kが20以下で%Dより上',OB,(K>=80)&(K<D))
    add('ストキャス','%Kが20以下' if up else '%Kが80以上',OS,K<=20)
    # 基準線・VWAP乖離
    kij=(hi(26)+lo(26))/2; sg='+' if up else '-'
    for th in (1.5,3): add('基準線からの乖離',f'基準線から{sg}{th}ATR以上',OB,(pc-kij)/atr>=th)
    for nm,vw in vwaps(q).items():
        for th in (1,2,3): add('VWAPからの乖離',f'{nm}VWAPから{sg}{th}ATR以上',OB,(pc-s*vw)/atr>=th)
    # ダイバージェンス
    E12=cs.ewm(span=12,adjust=False).mean().values; E26=cs.ewm(span=26,adjust=False).mean().values; Mc=E12-E26; e12=lag(E12,1); e12=e12+2/13*(pc-e12); e26=lag(E26,1); e26=e26+2/27*(pc-e26); mc=e12-e26
    hl='高値' if up else '安値'; ud='下' if up else '上'
    for N in (20,50):
        for nm,vc,vp in (('RSI14',Rc[14],R[14]),('MACD',Mc,mc)):
            M,VV=prevmax(Hg,vc,N); add('ダイバージェンス',f'{hl}が直前{N}本の{hl}を更新、{nm}は前回より{ud}',OB,(H>M[g])&(vp<VV[g]))
    # 第1回の条件の刻み
    for th in (1,2,2.5,3): add('BB',f'終値がBB{sg}{th}σ超',OB,F1['bbz']>th,'済' if th==2 else '')
    for th in (1,2,3): add('MAからの乖離',f'SMA20から{sg}{th}ATR以上',OB,F1['dev20']>=th,'済' if th==2 else '')
    for th in (2,3,5): add('MAからの乖離',f'SMA75から{sg}{th}ATR以上',OB,F1['dev75']>=th,'済' if th==3 else '')
    for th in (1,1.5,2.5): add('直前の値幅',f'直前5本で{sg}{th}ATR以上',OB,F1['run5']>=th,'済' if th==1.5 else '')
    for th in (2,3,5): add('直前の値幅',f'直前20本で{sg}{th}ATR以上',OB,F1['run20']>=th,'済' if th==3 else '')
    e=np.where(end,np.arange(m),-1); e=np.maximum.accumulate(e); Cf={k:np.where(e>=0,v[np.clip(e,0,None)],False) for k,v in F.items()}
    return F,Cf
_C={}
def conds(q,tf,B,side):
    s=1 if side=='上髭' else -1; out={}
    for U in (15,30,60,240,1440):
        if U<tf: continue
        if (U,s) not in _C: _C[U,s]=tfv3(q,gid(q,U),s)
        F,Cf=_C[U,s]
        for mode,V in (('同じ足',F),) if U==tf else (('形成中',F),('確定済み',Cf)):
            for (cat,nm,dirn,done),v in V.items(): out[cat,nm,dirn+('|済' if done else '|'),TFN[U],mode]=v[B['l']]
    return out
def summary(name):
    T=pd.read_pickle(f'T_{name}.pkl'); A=np.load(f'null_{name}.npy'); T['第1回で実施済み']=np.where(T['トレンドの向き'].str.endswith('済'),'済',''); T['行き過ぎの向き']=T['トレンドの向き'].str.split('|').str[0]; T=T.drop(columns='トレンドの向き'); T.to_pickle(f'T_{name}.pkl')
    out=[]; az_all=T.z.abs().values; new=(T['第1回で実施済み']=='').values; hi=T['取り方']!='同じ足'
    grp=[('全体',np.ones(len(T),bool)),('全体（第1回の条件を除く）',new)]+[('取り方：'+g,(T['取り方']==g).values) for g in T['取り方'].unique()]+[('取り方：'+g+'（第1回の条件を除く）',(T['取り方']==g).values&new) for g in T['取り方'].unique()]
    grp+=[('向き：'+a+'×'+g,((T['髭'].str[:2]==a)&(T['行き過ぎの向き']==g)).values) for a in ('上髭','下髭') for g in ('買われすぎ','売られすぎ')]
    grp+=[(c+'・'+g,((T['分類']==c)&(T['取り方']==g)).values&new) for c in T['分類'].unique() for g in T['取り方'].unique()]
    grp+=[('上位足を見る足：'+u,((T['条件を見る足']==u)&hi).values) for u in T['条件を見る足'].unique()]
    for nm,sel in grp:
        if sel.sum()==0: continue
        az=az_all[sel]; a=A[:,sel]; mx=np.nanmax(a,1); d=dict(系統=nm,通り=int(sel.sum()),最大z_本番=az.max(),最大z_偽平均=mx.mean(),最大z_偽上位5pct=np.percentile(mx,95))
        for k in (2.5,3,3.5): c=(a>=k).sum(1); d[f'z{k}以上_本番']=int((az>=k).sum()); d[f'z{k}以上_偽平均']=c.mean(); d[f'z{k}以上_偽上位5pct']=np.percentile(c,95); d[f'z{k}以上_本番を超えた偽の割合']=(c>=d[f'z{k}以上_本番']).mean()
        out.append(d)
    S=pd.DataFrame(out).round(2); S.to_csv(OUT+f'{name}_偽データ比較.csv',index=False,encoding='utf-8-sig'); S.to_pickle(f'S_{name}.pkl')
    X=T[T.z.abs()>=2.5]; X.reindex(X.z.abs().sort_values(ascending=False).index).to_csv(OUT+f'{name}_一覧.csv',index=False,encoding='utf-8-sig'); print('本番',len(T),'一覧',len(X))
if __name__=='__main__':
    name='stage8_3_髭×行き過ぎ2'
    if len(sys.argv)>1 and sys.argv[1]=='sum': summary(name)
    else: s18.run(name,conds); summary(name)
