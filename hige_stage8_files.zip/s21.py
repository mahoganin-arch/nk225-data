# 第8段 検証2：状態だけ（髭なし）。条件を満たす全足の成績を、成績をずらした偽データと比べる。条件は第2回（トレンド84）と第3回（行き過ぎ55）
import pandas as pd, numpy as np, sys, time, warnings; warnings.filterwarnings('ignore')
import s17, s18, s19
from s17 import base, pick, tz2, NS, LAB, TFN, OUT
from s18 import nullz
from s14 import m15
def run(name='state8',NR=100,seed=7):
    q=m15(); rows=[]; NZ=[]; rng=np.random.default_rng(seed); us=rng.uniform(0.1,0.9,NR); buf=np.zeros(NR); t0=time.time()
    for tf in (60,30,15):
        B=base(tf,q); w0=B['warm']; sfts=(us*(B['n']-w0)).astype(np.int64); per=B['per']; hold={N:int(np.ceil(N*15/tf)) for N in NS}
        for src,fn in (('トレンド',s18.conds),('行き過ぎ',s19.conds)):
            for d,dn in (('上髭','上側'),('下髭','下側')):
                for key,cm in fn(q,tf,B,d).items():
                    ix=np.where(cm&B['valid'])[0]
                    if len(ix)<90: continue
                    for N in NS:
                        e=B['E'][N]; idx=pick(ix,hold[N],e); p=per[idx]; n1=int(p.sum()); n0=len(p)-n1
                        if n0<60 or n1<30: continue
                        t_0,t_1,z=tz2(idx,e,per); za=tz2(idx,B['EA'][N],per)[2]; sg=1 if z>0 else -1; pf=[]
                        for k in (0,1): v=sg*B['X'][N][idx[p==k]]-B['cost'][idx[p==k]]; pf.append(round(v[v>0].sum()/max(-v[v<=0].sum(),1e-9),2))
                        nullz(idx,e,per,w0,sfts,buf); NZ.append(buf.astype(np.float32)); cat,cn,dirn,un,mode=key
                        rows.append((TFN[tf],src,dn,cat,cn,dirn.split('|')[0],un,mode,LAB[N],'買い' if z>0 else '売り',n0,round(t_0,2),pf[0],n1,round(t_1,2),pf[1],round(z,2),round(za,2)))
        print(tf,len(rows),int(time.time()-t0),'秒',flush=True)
    T=pd.DataFrame(rows,columns=['入る足','種類','条件の側','分類','条件','向き','条件を見る足','取り方','経過','売買','17-22 回数','17-22 t','17-22 超過PF','23-26 回数','23-26 t','23-26 超過PF','z','z（ATR単位）'])
    A=np.array(NZ).T; T.to_pickle(f'T_{name}.pkl'); np.save(f'null_{name}.npy',A); out=[]; az=T.z.abs().values
    grp=[('全体',np.ones(len(T),bool))]+[('種類：'+g,(T['種類']==g).values) for g in ('トレンド','行き過ぎ')]+[('入る足：'+g,(T['入る足']==g).values) for g in T['入る足'].unique()]
    grp+=[(s+'・'+g,((T['種類']==s)&(T['向き']==g)).values) for s in ('トレンド','行き過ぎ') for g in T[T['種類']==s]['向き'].unique()]
    grp+=[('見る足：'+g,(T['条件を見る足']==g).values) for g in T['条件を見る足'].unique()]+[('分類：'+g,(T['分類']==g).values) for g in T['分類'].unique()]
    grp+=[('買われすぎ×見る足：'+g,((T['向き']=='買われすぎ')&(T['条件を見る足']==g)).values) for g in T['条件を見る足'].unique()]+[('売られすぎ×見る足：'+g,((T['向き']=='売られすぎ')&(T['条件を見る足']==g)).values) for g in T['条件を見る足'].unique()]
    grp+=[(d+'×'+g,((T['向き']==d)&(T['分類']==g)).values) for d in ('買われすぎ','売られすぎ') for g in T[T['種類']=='行き過ぎ']['分類'].unique()]
    for nm,sel in grp:
        if sel.sum()<100: continue
        a=A[:,sel]; mx=np.nanmax(a,1); d=dict(系統=nm,通り=int(sel.sum()),最大z_本番=az[sel].max(),最大z_偽平均=mx.mean(),最大z_偽上位5pct=np.percentile(mx,95))
        for k in (3,3.5): c=(a>=k).sum(1); d[f'z{k}以上_本番']=int((az[sel]>=k).sum()); d[f'z{k}以上_偽平均']=c.mean(); d[f'z{k}以上_偽上位5pct']=np.percentile(c,95); d[f'z{k}_偽が本番以上の割合']=(c>=d[f'z{k}以上_本番']).mean()
        out.append(d)
    S=pd.DataFrame(out).round(2); S.to_pickle(f'S_{name}.pkl'); S.to_csv(OUT+'stage8_検証2_状態だけ_偽データ比較.csv',index=False,encoding='utf-8-sig')
    X=T[az>=2.5]; X.reindex(X.z.abs().sort_values(ascending=False).index).to_csv(OUT+'stage8_検証2_状態だけ_一覧.csv',index=False,encoding='utf-8-sig'); print('本番',len(T))
if __name__=='__main__': run()
