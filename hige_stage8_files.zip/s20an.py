import pandas as pd,numpy as np,sys
pd.set_option('display.width',300,'display.max_rows',500,'display.max_colwidth',44,'display.unicode.east_asian_width',True)
n=sys.argv[1]; T=pd.read_pickle(f'T_{n}.pkl'); A=np.load(f'null_{n}.npy'); T['向き']=T['向き'].str.split('|').str[0]; az=T['上乗せz'].abs().values; out=[]
hi=(T['取り方']!='同じ足').values
grp=[('全体',np.ones(len(T),bool))]+[('取り方：'+g,(T['取り方']==g).values) for g in T['取り方'].unique()]
grp+=[(a+'×'+g,((T['髭'].str[:2]==a)&(T['向き']==g)).values) for a in ('上髭','下髭') for g in T['向き'].unique()]
grp+=[('髭の足：'+u,(T['髭の足']==u).values) for u in T['髭の足'].unique()]
grp+=[('上位足を見る足：'+u,((T['条件を見る足']==u).values&hi)) for u in T['条件を見る足'].unique()]
grp+=[('分類：'+c,(T['分類']==c).values) for c in T['分類'].unique()]
grp+=[('上髭×'+c+'・'+g,((T['分類']==c)&(T['取り方']==g)&(T['髭'].str[:2]=='上髭')).values) for c in T['分類'].unique() for g in ('形成中','確定済み')]
for nm,sel in grp:
    if sel.sum()<200: continue
    a=A[:,sel]; mx=np.nanmax(a,1); d=dict(系統=nm,通り=int(sel.sum()),最大_本番=np.nanmax(az[sel]),最大_偽平均=mx.mean(),最大_偽上位5pct=np.percentile(mx,95))
    for k in (3,3.5): c=(a>=k).sum(1); d[f'z{k}以上_本番']=int((az[sel]>=k).sum()); d[f'z{k}以上_偽平均']=c.mean(); d[f'z{k}以上_偽上位5pct']=np.percentile(c,95); d[f'z{k}_偽が本番以上の割合']=(c>=d[f'z{k}以上_本番']).mean()
    out.append(d)
S=pd.DataFrame(out).round(2); S.to_pickle(f'S_{n}.pkl'); S.to_csv('/mnt/user-data/outputs/'+sys.argv[2]+'_偽データ比較.csv',index=False,encoding='utf-8-sig')
X=T[az>=2.5]; X.reindex(X['上乗せz'].abs().sort_values(ascending=False).index).to_csv('/mnt/user-data/outputs/'+sys.argv[2]+'_一覧.csv',index=False,encoding='utf-8-sig')
S.columns=[c.replace('以上_','_').replace('偽上位5pct','95').replace('偽平均','偽').replace('_偽が本番以上の割合','p') for c in S.columns]; print(S.to_string())
X=T[az>=3]; print(len(X),'プラスの割合',(X['上乗せz']>0).mean()); print(X.groupby(['髭の足','取り方']).size().to_string())
print(T.reindex(T['上乗せz'].abs().sort_values(ascending=False).index).head(25).drop(columns=['分類','向き']).to_string())
y=T[(T.髭の足=='30分足')&(T.髭=='上髭')&(T.大きさ=='ATR0.5倍以上')&(T.条件を見る足=='4時間足')&(T.取り方=='形成中')&(T.条件.isin(['RSI14が70以上','終値が雲の上']))]; print(y.drop(columns=['分類','向き']).to_string())
