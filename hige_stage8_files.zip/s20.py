# 第8段 検証：髭の上乗せ。「条件を満たす足のうち、髭の足」と「条件を満たす全足の平均」との差を測る。偽データ＝髭の位置だけを時間方向にずらす（条件と成績はそのまま）
import pandas as pd, numpy as np, sys, time, warnings; warnings.filterwarnings('ignore')
from numba import njit
import s17, s18, s19
from s17 import base, wicks, NS, LAB, TFN, OUT
from s14 import m15
@njit(cache=True)
def addz(wi,cm,valid,e,per,hold,mu,sfts,w0,out,cnt):
    n=len(e); L=n-w0; K=len(wi)
    for r in range(len(sfts)):
        sft=sfts[r]; k0=0
        while k0<K and wi[k0]+sft<n: k0+=1
        q=np.zeros((2,3)); free=0
        for kk in range(K):
            k=(k0+kk)%K; i=w0+((wi[k]-w0+sft)%L)
            if i<free or not cm[i] or not valid[i]: continue
            v=e[i]
            if np.isnan(v): continue
            free=i+hold+1; p=per[i]; v-=mu[p]; q[p,0]+=1; q[p,1]+=v; q[p,2]+=v*v
        z=0.0
        for p in range(2):
            m=q[p,0]
            if m<2: z=np.nan; break
            a=q[p,1]/m; var=(q[p,2]-m*a*a)/(m-1); z+=a/np.sqrt(max(var,1e-18)/m)
        out[r]=z/np.sqrt(2)
        if r==0: cnt[0]=q[0,0]; cnt[1]=q[1,0]
def run(name,condfn,NR=100,seed=11):
    q=m15(); rows=[]; NZ=[]; rng=np.random.default_rng(seed); us=rng.uniform(0.1,0.9,NR); buf=np.zeros(NR+1); cnt=np.zeros(2); t0=time.time()
    for tf in (60,30,15):
        B=base(tf,q); W=wicks(B); w0=B['warm']; sfts=np.r_[0,(us*(B['n']-w0)).astype(np.int64)]; per=B['per']; valid=B['valid']; hold={N:int(np.ceil(N*15/tf)) for N in NS}
        for d in ('上髭','下髭'):
            CD=condfn(q,tf,B,d); WI={k:np.where(v)[0] for k,v in W.items() if k[0]==d}
            for key,cm in CD.items():
                cm=np.ascontiguousarray(cm&valid); MU={}
                for N in NS:
                    e=B['E'][N]; MU[N]=np.array([np.nanmean(e[cm&(per==p)]) if (cm&(per==p)).sum()>50 else np.nan for p in (0,1)])
                for (dd,sk,ck),wi in WI.items():
                    if cm[wi].sum()<90: continue
                    for N in NS:
                        if np.isnan(MU[N]).any(): continue
                        addz(wi,cm,valid,B['E'][N],per,hold[N],MU[N],sfts,w0,buf,cnt)
                        if cnt[0]<60 or cnt[1]<30: continue
                        NZ.append(np.abs(buf[1:]).astype(np.float32)); rows.append((TFN[tf],d+ck.replace('色不問',''),sk)+tuple(key)+(LAB[N],int(cnt[0]),int(cnt[1]),round(buf[0],2)))
            print(tf,d,len(rows),int(time.time()-t0),'秒',flush=True)
    T=pd.DataFrame(rows,columns=['髭の足','髭','大きさ','分類','条件','向き','条件を見る足','取り方','経過','17-22 回数','23-26 回数','上乗せz'])
    T.to_pickle(f'T_{name}.pkl'); np.save(f'null_{name}.npy',np.array(NZ).T)
if __name__=='__main__':
    if sys.argv[1]=='3': run('add8_3',s19.conds)
    if sys.argv[1]=='2': run('add8_2',s18.conds,NR=50)
