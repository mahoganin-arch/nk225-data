import pandas as pd, numpy as np, glob, nest2
pd.set_option('display.width', 250)
Y = pd.concat([pd.read_pickle(f) for f in ['p2_fut_W_r0_r1_r2_r3_r4.pkl', 'p2_cfd_W_r0_r1_r2_r3_r4.pkl']])
Y['ext'] = Y.ex.str.split(' ').str[0]
Y.to_pickle('p2_all.pkl')
S = Y.groupby(['inst', 'fam', 'cond', 'dir', 'tim', 'ex', 'ext']).agg(nf=('nf', 'sum'), np_=('np_', 'sum'), gross=('gross', 'sum'), n=('n', 'sum')).reset_index()
S['avg'] = S.gross / S.n
S.to_pickle('p2_s.pkl')
# 決済の種類ごと：本物とでたらめの平均
E = S.groupby(['inst', 'ext', 'fam']).agg(med=('nf', 'median'), best=('nf', 'max'), pos=('nf', lambda s: (s > 0).mean()), avg=('avg', 'mean')).reset_index()
E['fam2'] = np.where(E.fam == 'W', 'W', 'rand')
print(E.groupby(['inst', 'ext', 'fam2'])[['med', 'best', 'pos', 'avg']].mean().round(2).to_string())
# 本物の上位
key = ['inst', 'cond', 'dir', 'tim', 'ex']
W = S[S.fam == 'W'].set_index(key); R = S[S.fam != 'W'].groupby(key).nf.agg(['mean', 'max'])
W = W.join(R)
for inst in ['fut', 'cfd']:
    w = W.loc[inst]
    print(inst, '両コストでプラス', ((w.nf > 0) & (w.np_ > 0)).sum(), '/', len(w), ' でたらめ5種の最大を上回る', (w.nf > w['max']).sum())
    print(w.sort_values('nf', ascending=False).head(10)[['nf', 'np_', 'n', 'avg', 'mean', 'max']].round(1).to_string())
W.to_pickle('p2_W.pkl')
F, D = nest2.nested(Y, ['cond', 'dir', 'tim', 'ex'])
print(F.round(0).to_string())
print(D[D.fam == 'W'].to_string())
F.to_pickle('p2_nest.pkl'); D.to_pickle('p2_nest_d.pkl')
