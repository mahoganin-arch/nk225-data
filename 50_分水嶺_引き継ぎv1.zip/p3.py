import eng4, eng3, numpy as np, pandas as pd, itertools, sys
RT={'fut':10,'cfd':7}
inst=sys.argv[1];fams=['W']+[f'r{s}' for s in range(10)]
B=eng4.prep(inst);rt=RT[inst]
rows=[]
for fam in fams:
    LNs={k:eng3.bar_lines(B,k,fam,inst)[0] for k in ['wk','day','ses']}
    for key in ['wk','day','ses']:
        LN=LNs[key]
        cfgs=[('E1',dr,tm,b,op) for dr,tm,b,op in itertools.product(['L','S','LS'],['T0','T15','T60'],[0,0.1,0.2,0.3],['W','next'])]
        cfgs+=[('E2',dr,tm,b,'-') for dr,tm,b in itertools.product(['L','S','LS'],['T15','T60'],[0,0.1,0.2,0.3])]
        cfgs+=[('E3',dr,tm,b,op) for dr,tm,b,op in itertools.product(['L','S','LS'],['T15','T60'],[0,0.1,0.2,0.3],['next','half'])]
        for kind,dr,tm,b,op in cfgs:
            for wkf in (['none'] if key=='wk' else ['none','side','room']):
                T=eng4.run(B,LN,key,kind,dr,tm,b,op,WK=LNs['wk'],wkf=wkf)
                if T is None or len(T)==0: continue
                T['nf']=T.pt-rt;T['np']=T.pt-rt*T.ep/60000
                g=T.groupby('yr').agg(nf=('nf','sum'),np_=('np','sum'),gross=('pt','sum'),n=('pt','size'),tp=('rs',lambda s:(s==3).sum()))
                for y,r in g.iterrows():
                    rows.append((inst,fam,key,kind,dr,tm,b,op,wkf,y,r.nf,r.np_,r.gross,r.n,r.tp))
    print(inst,fam,flush=True)
    pd.DataFrame(rows,columns=['inst','fam','key','kind','dir','tim','b','opt','wkf','yr','nf','np_','gross','n','ntp']).to_pickle(f'p3_{inst}.pkl')
