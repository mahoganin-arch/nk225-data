import eng, numpy as np, pandas as pd
RT={'fut':10,'cfd':7}
rows=[];yrs=[]
def hi_arrays(d,hkey,PH,LH):
    m=pd.Series(np.arange(len(PH)),index=PH.index)
    idx=d[hkey].map(m).values
    W=LH.W.values.astype(float).copy();W[:2]=np.nan
    return W[idx],LH.D.values[idx],LH.bull.values[idx]
for inst in ['fut','cfd']:
    d=eng.load(inst)
    for key,hkey in [('day','wk'),('ses','wk'),('ses','day')]:
        P=eng.periods(d,key);L=eng.lines(P,'W');PH=eng.periods(d,hkey)
        pstart=np.r_[True,d[key].values[1:]!=d[key].values[:-1]]
        px=np.where(pstart,d.o.values,d.c.values)
        tfe={tf:eng.tf_end(d,key,tf) for tf in (5,15,60)}
        hls={'W':eng.lines(PH,'W'),**{f'rand{s}':eng.lines(PH,'rand',seed=100+s) for s in range(5)}}
        for hl,LH in hls.items():
            Wh,Dh,Bh=hi_arrays(d,hkey,PH,LH)
            ok=~np.isnan(Wh)
            F={'none':(np.ones(len(d),bool),np.ones(len(d),bool)),
               'F1':(ok&(px>Wh),ok&(px<Wh)),
               'F2':(ok&(px>Wh)&(px<Wh+Dh),ok&(px<Wh)&(px>Wh-Dh)),
               'F3':(ok&(Bh==1),ok&(Bh==0))}
            if hl!='W': F={k:v for k,v in F.items() if k in('F1','F2')}
            for fn,(al,ash) in F.items():
                for rule,mode,tf in [('A',0,5),('B15',1,15),('B60',1,60)]:
                    T=eng.costs(eng.run(d,key,P,L,mode,tf,al=al,ash=ash,tfe=tfe[tf]),RT[inst])
                    rows.append(dict(inst=inst,key=key,hkey=hkey,hl=hl,filt=fn,rule=rule,n=len(T),gross=T.pt.sum(),net_fix=T.net_fix.sum(),net_pct=T.net_pct.sum(),avg_g=T.pt.mean()))
                    if hl=='W':
                        for y,g in T.groupby('yr'): yrs.append(dict(inst=inst,key=key,hkey=hkey,filt=fn,rule=rule,yr=y,net=g.net_fix.sum(),net_pct=g.net_pct.sum(),n=len(g)))
        print(inst,key,hkey,flush=True)
pd.DataFrame(rows).to_pickle('mtf.pkl');pd.DataFrame(yrs).to_pickle('mtf_y.pkl')
