import eng4, eng3, numpy as np, pandas as pd, warnings; warnings.filterwarnings('ignore')
rows=[]
for inst in ['fut','cfd']:
    B=eng4.prep(inst);d=B['d'];n=len(d)
    o,h,l,c=d.o.values,d.h.values,d.l.values,d.c.values
    chk=B['tfe'][60];ci=np.nonzero(chk)[0]
    prevchk=np.full(n,np.nan);prevchk[ci[1:]]=c[ci[:-1]]
    ss=B['ses_start'];sidx=np.maximum.accumulate(np.where(ss,np.arange(n),0));sopen=o[sidx]
    se=np.nonzero(B['ses_end'])[0];prevsc=np.full(n,np.nan);k=np.searchsorted(se,sidx)-1;okk=k>=0;prevsc[okk]=c[se[k[okk]]]
    de=np.nonzero(B['pend']['day'])[0]
    hr=d.t.dt.hour.values;wd=d.t.dt.dayofweek.values;yr=d.t.dt.year.values;hm=hr*60+d.t.dt.minute.values
    dayses=((hm>=480)&(hm<975)) if inst=='fut' else ((hr>=7)&(hr<17))
    # 日の値幅の20日平均（前日まで）、日の始値からの動き
    P,_=B['day'];rng=(P.h-P.l);avg20=rng.rolling(20).mean().shift(1);prevr=rng.shift(1)
    dix=d.day.map(pd.Series(np.arange(len(P)),index=P.index)).values
    dop=P.o.values[dix]
    # 20日平均の値段（前日まで）
    ma20=P.c.rolling(20).mean().shift(1).values[dix]
    for fam in ['W']+[f'r{s}' for s in range(10)]:
        LN={k:eng3.bar_lines(B,k,fam,inst)[0] for k in ['wk','day']};Ld=LN['day'];Lw=LN['wk']
        for dr,wkf in [('L','side'),('S','none')]:
            sig,_,tpP,slP=eng4.signals(B,Ld,'E2',dr,'T60',0.0,'-',WK=Lw,wkf=wkf)
            T=eng4.run(B,Ld,'day','E2',dr,'T60',0.0,'-',WK=Lw,wkf=wkf)
            i=T.ei.values;p=c[i];sd=T.dir.values;D=Ld['D'][i]
            endi=de[np.searchsorted(de,i)]
            df=pd.DataFrame({'inst':inst,'fam':fam,'dir':dr,'yr':yr[i],'pt':T.pt.values,
                '時間帯':np.where(dayses[i],'日中','夜間'),'時刻':hr[i],'曜日':wd[i],
                '日の終わりまでの時間':(endi-i)/12,
                '利確までの余地':np.abs(tpP[i]-p)/D,'利確の線が無い':np.isnan(tpP[i]),
                '損切りまでの幅':np.abs(p-slP[i])/D,
                '勢い':(p-prevchk[i])*sd/D,
                '日の始値からの動き':(p-dop[i])*sd/D,
                '寄りの窓':(sopen[i]-prevsc[i])*sd/D,
                'Dの大きさ（値段比）':D/p*100,
                'Dと20日平均の比':D/avg20.values[dix[i]],
                '前日の値幅と20日平均の比':prevr.values[dix[i]]/avg20.values[dix[i]],
                '日の分水嶺からの距離':(p-Ld['W'][i])*sd/D,
                '週の分水嶺からの距離':(p-Lw['W'][i])*sd/Lw['D'][i],
                '20日平均からの距離':(p-ma20[i])*sd/p*100,
                '前日の向き':np.where(Ld['s'][i]*sd>0,'同じ向き','逆向き'),
                '週の線の向き':np.where(Lw['s'][i]*sd>0,'同じ向き','逆向き')})
            rows.append(df)
    print(inst,flush=True)
A=pd.concat(rows,ignore_index=True);A.to_pickle('feat3.pkl');print(len(A))
