import pandas as pd,numpy as np
f=pd.read_pickle('fut5.pkl');c=pd.read_pickle('cfd5.pkl')
m=f[['t','close']].merge(c[['t','close']],on='t',suffixes=('_f','_c'))
m['b']=m.close_f-m.close_c
m['d']=(m.t-pd.Timedelta(hours=6)).dt.date
db=m.groupby('d').b.median()
j=db.diff()
# SQ dates
rows=[]
for y in range(2017,2027):
  for mo in (3,6,9,12):
    d=pd.Timestamp(y,mo,1)
    fr=d+pd.Timedelta(days=(4-d.weekday())%7+7)
    rows.append(fr.date())
out=[]
for sq in rows:
  w=j[(j.index>=sq-pd.Timedelta(days=6))&(j.index<=sq)]
  if len(w)==0: continue
  k=w.abs().idxmax();out.append((sq,k,round(w[k])))
o=pd.DataFrame(out,columns=['SQ','jump_day','jump'])
print(o.to_string());print('abs mean',o.jump.abs().mean(),'normal day |diff| median',j.abs().median())
