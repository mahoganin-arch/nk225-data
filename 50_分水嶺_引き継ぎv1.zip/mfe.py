"""入った後、セッションの終わりまでの最大の含み益（MFE）と含み損（MAE）を集計する"""
import eng2, numpy as np, pandas as pd
from numba import njit

@njit(cache=True)
def excur(h, l, ei, send_idx, ep, dr):
    m = len(ei); fav = np.empty(m); adv = np.empty(m)
    for k in range(m):
        hi = -1e18; lo = 1e18
        for j in range(ei[k] + 1, send_idx[k] + 1):
            if h[j] > hi: hi = h[j]
            if l[j] < lo: lo = l[j]
        if send_idx[k] <= ei[k]:
            fav[k] = 0.0; adv[k] = 0.0
        elif dr[k] == 1:
            fav[k] = hi - ep[k]; adv[k] = ep[k] - lo
        else:
            fav[k] = ep[k] - lo; adv[k] = hi - ep[k]
    return fav, adv

rows = []
for inst in ['fut', 'cfd']:
    B = eng2.base(inst); d = B['d']
    LA = eng2.line_arrays(B, 'W'); CC = (eng2.conds(LA, d.c.values), eng2.conds(LA, d.o.values))
    Rs = LA['ses'][2]
    se = np.nonzero(B['ses_end'])[0]
    for cond in ['S0', 'A1', 'A2', 'A3']:
        for tim in ['T0', 'T60']:
            T = eng2.run(B, LA, cond, 'LS', tim, 0, CC=CC)
            sidx = se[np.searchsorted(se, T.ei.values)]
            fav, adv = excur(d.h.values, d.l.values, T.ei.values, sidx, T.ep.values, T.dir.values)
            T['fav'] = fav; T['adv'] = adv; T['R'] = Rs[T.ei.values]
            for dr, g in T.groupby('dir'):
                q = lambda s, p: float(np.nanquantile(s, p))
                rows.append(dict(inst=inst, cond=cond, tim=tim, dir='買い' if dr == 1 else '売り', n=len(g),
                                 fav50=q(g.fav, .5), fav75=q(g.fav, .75), fav90=q(g.fav, .9),
                                 adv50=q(g.adv, .5), adv75=q(g.adv, .75), adv90=q(g.adv, .9),
                                 end_avg=g.pt.mean(), R50=q(g.R, .5),
                                 favR50=q(g.fav / g.R, .5), advR50=q(g.adv / g.R, .5),
                                 p100=(g.fav >= 100).mean(), p500=(g.fav >= 500).mean()))
M = pd.DataFrame(rows); M.to_pickle('mfe.pkl')
pd.set_option('display.width', 250); print(M.round(2).to_string())
