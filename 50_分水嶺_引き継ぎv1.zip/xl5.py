import pandas as pd,numpy as np,warnings;warnings.filterwarnings('ignore')
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter as L
F='Arial';NUM='#,##0;[Red]-#,##0';P1='0.0;[Red]-0.0';PC='0%'
IN={'fut':'ミニ','cfd':'CFD'};DR={'L':'買い','S':'売り'};WF={'none':'なし','side':'週Wと同じ側'}
wb=Workbook()
def sheet(title,cols,rows,fmts,widths,note=None):
    ws=wb.create_sheet(title)
    for j,c in enumerate(cols,1):
        x=ws.cell(1,j,c);x.font=Font(name=F,bold=True,color='FFFFFF');x.fill=PatternFill('solid',fgColor='305496');x.alignment=Alignment(wrap_text=True,vertical='center')
    for i,r in enumerate(rows,2):
        for j,v in enumerate(r,1):
            if isinstance(v,np.floating): v=None if np.isnan(v) else float(v)
            if isinstance(v,np.integer): v=int(v)
            c=ws.cell(i,j,v);c.font=Font(name=F)
            if j-1 in fmts: c.number_format=fmts[j-1]
    for j,w in enumerate(widths,1): ws.column_dimensions[L(j)].width=w
    ws.freeze_panes='A2'
    if note: ws.cell(len(rows)+3,1,note).font=Font(name=F,italic=True)
txt=[('日の線の抜け：売りの改善と窓開けの検証（2026-10-21）',True),
('対象：日の γ・α・Ω を60分足の確定で抜けたら入る形（前回の候補）。2017〜2022年で傾向を見つけ、2023〜2026年で確かめた。でたらめな線10種と比べた。',False),('',False),('■ 結論',True),
('1. 売りは、特徴で絞っても、決済の方法を変えても、コストを越えられなかった。前半で一番良かった決済を後半に使うと、ミニ −2,118〜−3,748、CFD −2,848〜−7,858。',False),
('2. 売りの入れ子の前向き（決済約420通りから毎年選ぶ）：ミニ −6,796、CFD −10,539。でたらめな線の売りも全部マイナスで、本物はその中でも下の方。',False),
('3. 売りでも本物はでたらめより1回あたり約 +7 pt 良いが、相場全体が上がっている分（約 −2〜−4 pt）とコスト（7〜10 pt）に負ける。',False),
('4. 窓開け：窓の大きさで動きが分かれる（小さな窓は83〜86%が同じセッションで埋まり、大きな窓は35〜57%しか埋まらない）。しかし窓が日の線をまたいだかどうかでは、でたらめな線と差が無い。',False),
('5. ミニの日中の大きな下窓（D×0.5超）は、その後むしろ上げる（寄りから日中の終わりまで平均 +20 pt）。ここでも売りは不利。',False),
('6. 買いの決済は「日の終わりまで持つ」が一番良い。利確の位置（次の線、D の何倍、無し）では差が小さく、1〜2時間で切ると悪くなる。',False),
('7. 注意：買いでも、2017〜2022年だけを見ると、決済の方法を平均した損益はマイナス。利益の多くは2023年以降。',False),
('',False),('■ 次の候補',True),
('・売りは、この線の抜けとは別の仕掛け（寄り天・窓など、売り側に効く形）から探す方が見込みがある。',False),
('・この線の売買は買いだけにし、売りの合図は「買わない」合図として使う。',False)]
ws=wb.active;ws.title='まとめ'
for i,(t,b) in enumerate(txt,1):
    c=ws.cell(i,1,t);c.font=Font(name=F,bold=b,size=12 if b else 10);c.alignment=Alignment(wrap_text=True,vertical='top')
ws.column_dimensions['A'].width=115
O=pd.read_pickle('feat2an.pkl')
FN={'line':'抜けた線','above_W':'線の位置','ses':'時間帯','gapx':'窓で抜けたか','prevbull':'前日の向き','wkside':'週の分水嶺','gapb':'寄りの窓','Db':'日の値幅 D','pvb':'勢い（直前60分の動き÷D）','wd':'曜日'}
O=O[O.val!='na']
rows=[[IN[r.inst],DR[r.dir],FN[r.feat],str(r.val),r['前半17-22_n'],r['前半17-22_W'],r['前半17-22_R'],r['前半17-22_ex'],r['後半23-26_n'],r['後半23-26_W'],r['後半23-26_R'],r['後半23-26_ex']] for _,r in O.sort_values(['inst','dir','feat'],ascending=[False,False,True]).iterrows()]
sheet('特徴別',['商品','向き','特徴','値','前半 回数','前半 本物 1回の粗利','前半 でたらめ','前半 差','後半 回数','後半 本物','後半 でたらめ','後半 差'],rows,{5:P1,6:P1,7:P1,9:P1,10:P1,11:P1},[6,5,20,14,8,10,9,8,8,9,9,8],'1回の粗利は pt（コスト前）。決済は元の形（次の線で利確、抜けた線の0.25D先で損切り、日の終わり）。週の条件なし。')
S=pd.read_pickle('ex5_split.pkl')
rows=[]
for (inst,dr,wkf),g in S.groupby(['inst','dir','wkf']):
    w=g[g.fam=='W'].iloc[0];r=g[g.fam!='W']
    rows.append([IN[inst],DR[dr],WF[wkf],w.best,w['first'],w.second,w.sec_avg,r.second.median(),r.second.max(),np.mean(r.second<w.second),w.base_first,w.base_second])
sheet('決済 前半で選ぶ',['商品','向き','週の条件','前半で一番良かった決済（利確|終わり|損切り|建値移動）','前半','後半','後半 1回の粗利','でたらめ 後半 中央','でたらめ 後半 最大','本物が上回る割合','元の決済 前半','元の決済 後半'],rows,{4:NUM,5:NUM,6:P1,7:NUM,8:NUM,9:PC,10:NUM,11:NUM},[6,5,11,36,9,9,9,10,10,9,10,10],'決済は 利確7通り×終わり5通り×損切り3通り×建値移動2通り＝210通り。損益はコスト固定、pt。')
Y=pd.concat([pd.read_pickle('ex5_fut.pkl'),pd.read_pickle('ex5_cfd.pkl')]);Y['per']=np.where(Y.yr<=2022,'前半','後半')
w=Y[(Y.fam=='W')&(Y.wkf=='side')];rows=[]
FX={'tp':'利確','end':'決済の時','sl':'損切り（抜けた線から D×）','be':'建値移動（含み益 D×）'}
for dr in ['L','S']:
    for f in ['tp','end','sl','be']:
        x=w[w.dir==dr];cnt=x.drop_duplicates(['tp','end','sl','be']).groupby(f).size()
        p=x.groupby([f,'inst','per']).nf.sum().unstack(['inst','per'])
        for v in p.index:
            rows.append([DR[dr],FX[f],str(v)]+[p.loc[v].get((i,pp),np.nan)/cnt[v] for i in ['fut','cfd'] for pp in ['前半','後半']])
sheet('決済 種類別の平均',['向き','項目','値','ミニ 前半','ミニ 後半','CFD 前半','CFD 後半'],rows,{3:NUM,4:NUM,5:NUM,6:NUM},[5,22,12,10,10,10,10],'週Wと同じ側のとき。その値を持つ決済の組み合わせの平均の損益（コスト固定、pt）。')
G=pd.read_pickle('gap.pkl');G=G[~np.isnan(G.D)&(G.D>0)&(G.inst=='fut')]
G['gb']=pd.cut(G.gap/G.D,[-99,-0.5,-0.2,-0.05,0.05,0.2,0.5,99],labels=['下窓 大','下窓 中','下窓 小','ほぼ無し','上窓 小','上窓 中','上窓 大'])
G['cross']=np.where(G.crossU|G.crossD,'線をまたいだ','またがない');G['f2']=np.where(G.fam=='W','本物','でたらめ')
p=G.groupby(['ses','gb','cross','f2'],observed=True).agg(n=('gap','size'),fill=('fill','mean'),r60=('r60','mean'),rend=('rend','mean')).reset_index()
p['n']=np.where(p.f2=='でたらめ',p.n/10,p.n)
rows=[[r.ses,str(r.gb),r.cross,r.f2,r.n,r.fill,r.r60,r.rend] for r in p.itertuples()]
sheet('窓開け（ミニ）',['セッション','窓（前の終値との差÷D）','日の線','線','回数','同じセッションで埋まった割合','寄りから1時間（pt）','寄りからセッションの終わり（pt）'],rows,{4:'0',5:PC,6:P1,7:P1},[9,14,12,8,7,12,12,14],'でたらめの回数は10種の平均。値動きは寄りの値段からの上下（上げがプラス）。')
wb.save('売りと窓の検証_2026-10-21.xlsx')
