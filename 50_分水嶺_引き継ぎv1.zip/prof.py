import pandas as pd,numpy as np;pd.set_option('display.width',250);pd.set_option('display.max_rows',600)
A=pd.read_pickle('feat3.pkl');COST={'fut':5,'cfd':7};A['net']=A.pt-A.inst.map(COST)
A['per']=np.where(A.yr<=2022,'前半','後半')
NUMF=['日の終わりまでの時間','利確までの余地','損切りまでの幅','勢い','日の始値からの動き','Dの大きさ（値段比）','Dと20日平均の比','前日の値幅と20日平均の比','日の分水嶺からの距離','週の分水嶺からの距離','20日平均からの距離']
CATF=['時間帯','曜日','利確の線が無い','前日の向き','週の線の向き']
rows=[]
for (inst,dr),g in A.groupby(['inst','dir']):
    w0=g[(g.fam=='W')&(g.per=='前半')]
    for f in NUMF:
        q=w0[f].quantile([.2,.4,.6,.8]).values  # 境目は本物の前半で決める
        b=np.digitize(g[f].values,q);b=np.where(g[f].isna(),-1,b)
        gg=g.assign(bin=b)
        for v in range(5):
            x=gg[gg.bin==v];lab=f'{["下位20%","20-40%","40-60%","60-80%","上位20%"][v]}'
            r=dict(inst=inst,dir=dr,feat=f,val=lab,lo=q[v-1] if v>0 else np.nan,hi=q[v] if v<4 else np.nan)
            for per in ['前半','後半']:
                xw=x[(x.fam=='W')&(x.per==per)];xr=x[(x.fam!='W')&(x.per==per)]
                r[per+'_n']=len(xw);r[per+'_W']=xw.net.mean();r[per+'_R']=xr.net.mean()
            rows.append(r)
    for f in CATF:
        for v,x in g.groupby(f):
            r=dict(inst=inst,dir=dr,feat=f,val=str(v),lo=np.nan,hi=np.nan)
            for per in ['前半','後半']:
                xw=x[(x.fam=='W')&(x.per==per)];xr=x[(x.fam!='W')&(x.per==per)]
                r[per+'_n']=len(xw);r[per+'_W']=xw.net.mean();r[per+'_R']=xr.net.mean()
            rows.append(r)
P=pd.DataFrame(rows);P.to_pickle('prof.pkl')
for (inst,dr),g in P.groupby(['inst','dir']):
    print('=====',inst,dr);print(g.drop(columns=['inst','dir']).round(2).to_string(index=False))
