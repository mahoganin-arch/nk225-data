import eng2, numpy as np, pandas as pd, itertools, sys
RT={'fut':10,'cfd':7}
seeds=range(5,30)
rows=[]
for inst in ['fut','cfd']:
    B=eng2.base(inst);d=B['d']
    for s in seeds:
        fam=f'r{s}';LA=eng2.line_arrays(B,fam);CC=(eng2.conds(LA,d.c.values),eng2.conds(LA,d.o.values))
        for cond,dirn,tim,xm in itertools.product(eng2.COND,['L','S','LS'],['T0','T15','T30','T60'],[0,1]):
            T=eng2.run(B,LA,cond,dirn,tim,xm,CC=CC);rt=RT[inst]
            T['nf']=T.pt-rt;T['np']=T.pt-rt*T.ep/60000;T['n2']=T.pt-2*rt
            g=T.groupby('yr').agg(nf=('nf','sum'),np_=('np','sum'),n2=('n2','sum'),gross=('pt','sum'),n=('pt','size'))
            for y,r in g.iterrows():
                rows.append(dict(inst=inst,fam=fam,cond=cond,dir=dirn,tim=tim,xm=xm,yr=y,nf=r.nf,np_=r.np_,n2=r.n2,gross=r.gross,n=r.n))
        print(inst,fam,flush=True)
pd.DataFrame(rows).to_pickle('p1_y_more.pkl')
