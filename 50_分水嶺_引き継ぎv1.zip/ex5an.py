import pandas as pd,numpy as np,nest2;pd.set_option('display.width',250)
Y=pd.concat([pd.read_pickle('ex5_fut.pkl'),pd.read_pickle('ex5_cfd.pkl')])
Y['cfg']=Y.tp+'|'+Y.end+'|損'+Y.sl.astype(str)+'|建値'+Y.be.astype(str)
out=[]
for (inst,dr,wkf,fam),y in Y.groupby(['inst','dir','wkf','fam']):
    a=y[y.yr<=2022].groupby('cfg')[['nf','np_']].sum();b=y[y.yr>=2023].groupby('cfg')[['nf','np_','gross','n']].sum()
    sc=np.minimum(a.nf,a.np_);best=sc.idxmax()
    out.append(dict(inst=inst,dir=dr,wkf=wkf,fam=fam,best=best,first=sc[best],second=b.nf.get(best,0),sec_avg=b.gross.get(best,0)/max(b.n.get(best,1),1),
                    base_first=a.nf.get('次の線|日の終わり|損0.25|建値0.0'),base_second=b.nf.get('次の線|日の終わり|損0.25|建値0.0')))
O=pd.DataFrame(out)
for (inst,dr,wkf),g in O.groupby(['inst','dir','wkf']):
    w=g[g.fam=='W'].iloc[0];r=g[g.fam!='W']
    print(f'{inst} {dr} {wkf:5s} 前半で選んだ決済: {w.best:28s} 前半 {w.first:8.0f} 後半 {w.second:8.0f}（1回 {w.sec_avg:5.1f}） | でたらめ10種の後半: 中央 {r.second.median():7.0f} 最大 {r.second.max():7.0f} 本物が上回る {np.mean(r.second<w.second):.1f} | 元の決済 前半 {w.base_first:7.0f} 後半 {w.base_second:7.0f}')
O.to_pickle('ex5_split.pkl')
# 決済の種類ごとの平均（本物、前半・後半）
Y['per']=np.where(Y.yr<=2022,'前半','後半')
for dr in ['S','L']:
  w=Y[(Y.fam=='W')&(Y.dir==dr)&(Y.wkf=='side')]
  for f in ['tp','end','sl','be']:
    print(dr,f,w.groupby([f,'inst','per']).nf.sum().unstack(['inst','per']).div(w.groupby([f]).cfg.nunique(),axis=0).round(0).to_string())
F,D=nest2.nested(Y.assign(cfg2=Y.cfg),['dir','wkf','tp','end','sl','be'])
print(F.round(0).to_string())
F2,D2=nest2.nested(Y[Y.dir=='S'],['wkf','tp','end','sl','be'])
print('売りだけ');print(F2.round(0).to_string());print(D2[D2.fam=='W'].to_string())
F.to_pickle('ex5_nest.pkl');F2.to_pickle('ex5_nestS.pkl');D2.to_pickle('ex5_nestS_d.pkl')
