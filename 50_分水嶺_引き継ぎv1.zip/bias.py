import eng4, eng3, numpy as np, pandas as pd, warnings; warnings.filterwarnings('ignore')
RT={'fut':10,'cfd':7}
out=[];yrs=[];rnd=[]
for inst in ['fut','cfd']:
    B=eng4.prep(inst);d=B['d'];rt=RT[inst];c=d.c.values
    LN={k:eng3.bar_lines(B,k,'W',inst)[0] for k in ['wk','day']}
    # 地合い：日足の終値と20日平均（入る前日までで判定）
    dc=d.groupby('day').c.last();ma=dc.rolling(20).mean()
    reg=(dc>ma).shift(1);regmap=d.day.map(reg).values
    wkchg=d.groupby('wk').c.last().diff();wkmap=d.wk.map(wkchg.shift(1)>0).values  # 前週が上げたか
    for dr,wkf in [('L','side'),('S','side'),('LS','side'),('L','none'),('S','none')]:
        T=eng4.run(B,LN['day'],'day','E2',dr,'T60',0.0,'-',WK=LN['wk'],wkf=wkf)
        T['nf']=T.pt-rt;T['hold']=T.xi-T.ei
        # 同じ持ち時間の、全部の足の平均の値動き（その年の上昇分）
        yr=d.t.dt.year.values
        drift={}
        for y in np.unique(yr):
            m=np.nonzero(yr==y)[0];drift[y]=(c[m[-1]]-c[m[0]])/len(m)
        T['drift']=T.dir*T.hold*np.array([drift[y] for y in yr[T.ei]])
        T['ex']=T.pt-T.drift
        T['bull_reg']=regmap[T.ei]
        out.append(dict(inst=inst,dir=dr,wkf=wkf,n=len(T),nf=T.nf.sum(),avg=T.pt.mean(),drift=T.drift.mean(),excess=T.ex.mean(),
                        bull_n=(T.bull_reg==True).sum(),bull_avg=T[T.bull_reg==True].pt.mean(),bear_n=(T.bull_reg==False).sum(),bear_avg=T[T.bull_reg==False].pt.mean()))
        for y,g in T.groupby('yr'): yrs.append(dict(inst=inst,dir=dr,wkf=wkf,yr=y,n=len(g),nf=g.nf.sum(),avg=g.pt.mean()))
O=pd.DataFrame(out);Yr=pd.DataFrame(yrs)
pd.set_option('display.width',250);print(O.round(1).to_string())
print(Yr.pivot_table(index=['inst','dir','wkf'],columns='yr',values='nf').round(0).to_string())
O.to_pickle('bias.pkl');Yr.to_pickle('bias_y.pkl')
