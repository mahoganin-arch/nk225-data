import eng4, eng3, numpy as np, pandas as pd, warnings; warnings.filterwarnings('ignore')
rows=[]
for inst in ['fut','cfd']:
    B=eng4.prep(inst);d=B['d'];n=len(d)
    o,h,l,c=d.o.values,d.h.values,d.l.values,d.c.values
    ss=np.nonzero(B['ses_start'])[0];se=np.nonzero(B['ses_end'])[0]
    t=d.t
    # セッションの寄り：前のセッションの終値との差。CFD は日をまたぐ寄り（月曜・7時）
    for k in range(1,len(ss)):
        i=ss[k];pc=c[se[k-1]];e=se[k]
        gap=o[i]-pc
        hh=h[i:e+1];ll=l[i:e+1];cc=c[i:e+1]
        n60=min(12,e-i+1)
        fill=(ll.min()<=pc) if gap>0 else (hh.max()>=pc)
        # 窓埋めまでの本数
        rows.append(dict(inst=inst,i=i,t=t.iloc[i],yr=t.iloc[i].year,ses='日中' if t.iloc[i].hour in (7,8,9) else '夜間',
                         mon=t.iloc[i].dayofweek==0 and t.iloc[i].hour<12,gap=gap,pc=pc,op=o[i],
                         r60=(cc[n60-1]-o[i]),rend=(cc[-1]-o[i]),fill=fill,
                         up=hh.max()-o[i],dn=o[i]-ll.min()))
G=pd.DataFrame(rows)
# 線の情報
out=[]
for inst in ['fut','cfd']:
    B=eng4.prep(inst);g=G[G.inst==inst].copy()
    for fam in ['W']+[f'r{s}' for s in range(10)]:
        Ld=eng3.bar_lines(B,'day',fam,inst)[0]
        i=g.i.values;M=np.c_[Ld['alp'][i],Ld['W'][i],Ld['gam'][i],Ld['ome'][i]];D=Ld['D'][i]
        pc=g.pc.values;op=g.op.values
        crossU=((M>pc[:,None])&(M<=op[:,None])).any(1);crossD=((M<pc[:,None])&(M>=op[:,None])).any(1)
        # 寄りから一番近い線までの距離（向き付き：窓の向きの先にある線）
        up=np.where(M>op[:,None],M,np.inf).min(1)-op;dn=op-np.where(M<op[:,None],M,-np.inf).max(1)
        gg=g.assign(fam=fam,D=D,crossU=crossU,crossD=crossD,aboveW=op>Ld['W'][i],near_up=up/D,near_dn=dn/D)
        out.append(gg)
G2=pd.concat(out,ignore_index=True);G2.to_pickle('gap.pkl')
G2=G2[~np.isnan(G2.D)&(G2.D>0)]
G2['gD']=G2.gap/G2.D
G2['gb']=pd.cut(G2.gD,[-99,-0.5,-0.2,-0.05,0.05,0.2,0.5,99],labels=['下窓 大','下窓 中','下窓 小','ほぼ無し','上窓 小','上窓 中','上窓 大'])
G2['cross']=np.where(G2.crossU,'上に線をまたいだ',np.where(G2.crossD,'下に線をまたいだ','またがない'))
G2['per']=np.where(G2.yr<=2022,'前半','後半')
pd.set_option('display.width',250)
for inst in ['fut','cfd']:
  for ses in ['日中','夜間']:
    w=G2[(G2.inst==inst)&(G2.ses==ses)&(G2.fam=='W')]
    if len(w)<50: continue
    print('=====',inst,ses,'寄りの窓（本物の線）')
    print(w.groupby(['gb'],observed=True).agg(n=('gap','size'),gap=('gap','mean'),fill=('fill','mean'),r60=('r60','mean'),rend=('rend','mean')).round(2).to_string())
    print(w.groupby(['gb','cross'],observed=True).agg(n=('gap','size'),fill=('fill','mean'),r60=('r60','mean'),rend=('rend','mean')).round(2).to_string())
    q=G2[(G2.inst==inst)&(G2.ses==ses)&(G2.fam!='W')]
    print('  でたらめ：',q.groupby(['gb','cross'],observed=True).agg(n=('gap','size'),fill=('fill','mean'),r60=('r60','mean'),rend=('rend','mean')).round(2).to_string())
