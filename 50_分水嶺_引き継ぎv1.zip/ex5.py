import eng4, eng3, numpy as np, pandas as pd, itertools, sys, warnings; warnings.filterwarnings('ignore')
from numba import njit
RT={'fut':10,'cfd':7}
@njit(cache=True)
def sim5(o,h,l,c,sig,tpd,sld,Dv,endf,maxh,be):
    n=len(o);ei=np.empty(n,np.int64);xi=np.empty(n,np.int64);dr=np.empty(n,np.int64);ep=np.empty(n);xp=np.empty(n);rs=np.empty(n,np.int64)
    k=0;pos=0;e_i=0;e_p=0.;tp=np.nan;sl=np.nan;D=0.
    for i in range(n):
        if pos!=0 and i>e_i:
            hitS=False;hitT=False;px=0.
            if pos==1:
                if not np.isnan(sl) and l[i]<=sl: hitS=True;px=min(o[i],sl)
                elif not np.isnan(tp) and h[i]>=tp: hitT=True;px=max(o[i],tp)
            else:
                if not np.isnan(sl) and h[i]>=sl: hitS=True;px=max(o[i],sl)
                elif not np.isnan(tp) and l[i]<=tp: hitT=True;px=min(o[i],tp)
            if hitS or hitT:
                ei[k]=e_i;xi[k]=i;dr[k]=pos;ep[k]=e_p;xp[k]=px;rs[k]=3 if hitT else 4;k+=1;pos=0
            elif be>0:
                if pos==1 and c[i]-e_p>=be*D and sl<e_p: sl=e_p
                if pos==-1 and e_p-c[i]>=be*D and sl>e_p: sl=e_p
        if pos!=0 and (endf[i] or (maxh>0 and i-e_i>=maxh)):
            ei[k]=e_i;xi[k]=i;dr[k]=pos;ep[k]=e_p;xp[k]=c[i];rs[k]=1;k+=1;pos=0;continue
        if pos==0 and sig[i]!=0 and not endf[i]:
            pos=sig[i];e_i=i;e_p=c[i];D=Dv[i]
            tp=e_p+pos*tpd[i] if not np.isnan(tpd[i]) else np.nan
            sl=e_p-pos*sld[i] if not np.isnan(sld[i]) else np.nan
    return ei[:k],xi[:k],dr[:k],ep[:k],xp[:k],rs[:k]
if __name__=='__main__':
    inst=sys.argv[1];rt=RT[inst]
    B=eng4.prep(inst);d=B['d'];o,h,l,c=d.o.values,d.h.values,d.l.values,d.c.values;yr=d.t.dt.year.values
    ends={'日の終わり':(B['pend']['day'],0),'セッション終わり':(B['ses_end'],0),'1時間':(B['pend']['day'],12),'2時間':(B['pend']['day'],24),'4時間':(B['pend']['day'],48)}
    rows=[]
    for fam in ['W']+[f'r{s}' for s in range(10)]:
        LN={k:eng3.bar_lines(B,k,fam,inst)[0] for k in ['wk','day']};Dd=LN['day']['D']
        for dr,wkf in itertools.product(['L','S'],['none','side']):
            sig,_,tpP,slP=eng4.signals(B,LN['day'],'E2',dr,'T60',0.0,'-',WK=LN['wk'],wkf=wkf)
            sd=sig.astype(float)
            X=slP+sd*0.25*Dd  # 抜けた線
            tpN=np.abs(tpP-c)  # 次の線までの距離
            for tpn,ek,sk,be in itertools.product(['次の線','0.25D','0.5D','0.75D','1D','1.5D','無し'],list(ends),[0.1,0.25,0.5],[0,0.5]):
                tpd=tpN if tpn=='次の線' else (np.full(len(c),np.nan) if tpn=='無し' else float(tpn[:-1])*Dd)
                sld=np.abs(c-(X-sd*sk*Dd))
                ef,mh=ends[ek]
                r=sim5(o,h,l,c,sig,tpd,sld,Dd,ef,mh,be)
                T=pd.DataFrame(dict(zip(['ei','xi','dir','ep','xp','rs'],r)));T['pt']=T.dir*(T.xp-T.ep)
                T['yr']=yr[T.xi.values];T['nf']=T.pt-rt;T['np']=T.pt-rt*T.ep/60000
                g=T.groupby('yr').agg(nf=('nf','sum'),np_=('np','sum'),gross=('pt','sum'),n=('pt','size'))
                for y,v in g.iterrows(): rows.append((inst,fam,dr,wkf,tpn,ek,sk,be,y,v.nf,v.np_,v.gross,v.n))
        print(inst,fam,flush=True)
        pd.DataFrame(rows,columns=['inst','fam','dir','wkf','tp','end','sl','be','yr','nf','np_','gross','n']).to_pickle(f'ex5_{inst}.pkl')
