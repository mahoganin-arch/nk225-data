import pandas as pd,numpy as np,nest2
pd.set_option('display.width',250)
Y=pd.concat([pd.read_pickle('p3_fut.pkl'),pd.read_pickle('p3_cfd.pkl')])
key=['inst','key','kind','dir','tim','b','opt','wkf']
S=Y.groupby(['fam']+key).agg(nf=('nf','sum'),np_=('np_','sum'),gross=('gross','sum'),n=('n','sum'),ntp=('ntp','sum')).reset_index()
S['avg']=S.gross/S.n
W=S[S.fam=='W'].set_index(key);R=S[S.fam!='W']
lst=R.groupby(key).nf.apply(list)
W['rank']=[np.mean(np.array(lst[i])<W.nf[i]) if i in lst.index else np.nan for i in W.index]
W['r_med']=R.groupby(key).nf.median();W['r_avg']=R.groupby(key).avg.mean()
W.to_pickle('p3_W.pkl');S.to_pickle('p3_s.pkl')
for inst in ['fut','cfd']:
    w=W.loc[inst]
    print(inst,'設定数',len(w),'両コスト+',((w.nf>0)&(w.np_>0)).sum(),'でたらめ10種全部を上回る',(w['rank']==1).sum(),' 平均順位',round(w['rank'].mean(),2))
    print(w.groupby(level=['key','kind'])['rank'].mean().round(2).unstack())
    print(w.groupby(level='b')['rank'].mean().round(2).to_dict(),w.groupby(level='wkf')['rank'].mean().round(2).to_dict())
    print(w.sort_values('nf',ascending=False).head(12)[['nf','np_','n','avg','r_med','r_avg','rank']].round(1).to_string())
# 本物の平均順位がでたらめの範囲かどうか：でたらめの1種を「本物」とみなした場合の平均順位の分布
fams=sorted(R.fam.unique())
for inst in ['fut','cfd']:
    s=S[S.inst==inst];piv=s.pivot_table(index=key[1:],columns='fam',values='nf')
    ranks={}
    for f in piv.columns:
        others=piv.drop(columns=[f])
        ranks[f]=(others.lt(piv[f],axis=0)).mean(1).mean()
    print(inst,'平均順位 本物',round(ranks['W'],3),' でたらめ各種',sorted(round(v,3) for k,v in ranks.items() if k!='W'))
F,D=nest2.nested(Y,['key','kind','dir','tim','b','opt','wkf'])
F.to_pickle('p3_nest.pkl');D.to_pickle('p3_nest_d.pkl')
print(F.round(0).to_string());print(D[D.fam=='W'].to_string())
