import eng4, eng3, numpy as np, pandas as pd, warnings; warnings.filterwarnings('ignore')
rows=[]
for inst,costs in [('fut',[0,3,5,7,10]),('cfd',[3,5,6,7,10])]:
    B=eng4.prep(inst);d=B['d']
    for fam in ['W']+[f'r{s}' for s in range(10)]:
        LN={k:eng3.bar_lines(B,k,fam,inst)[0] for k in ['wk','day']}
        for dr,wkf in [('L','side'),('S','side'),('S','none')]:
            T=eng4.run(B,LN['day'],'day','E2',dr,'T60',0.0,'-',WK=LN['wk'],wkf=wkf)
            T['per']=np.where(T.yr<=2022,'前半','後半')
            for cst in costs:
                for per,g in [('全期間',T)]+list(T.groupby('per')):
                    rows.append(dict(inst=inst,fam=fam,dir=dr,wkf=wkf,cost=cst,per=per,n=len(g),net=(g.pt-cst).sum(),avg=g.pt.mean()))
R=pd.DataFrame(rows);R.to_pickle('cost.pkl')
w=R[R.fam=='W'];q=R[R.fam!='W'].groupby(['inst','dir','wkf','cost','per']).net.agg(['median','max'])
x=w.set_index(['inst','dir','wkf','cost','per'])[['n','avg','net']].join(q)
pd.set_option('display.width',250);print(x.unstack('per').round(0).to_string())
