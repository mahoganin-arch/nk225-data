import pandas as pd,numpy as np;pd.set_option('display.width',250)
A=pd.read_pickle('feat3.pkl');COST={'fut':5,'cfd':7};A['net']=A.pt-A.inst.map(COST)
NUMF=['日の終わりまでの時間','利確までの余地','損切りまでの幅','勢い','日の始値からの動き','寄りの窓','Dの大きさ（値段比）','Dと20日平均の比','前日の値幅と20日平均の比','日の分水嶺からの距離','週の分水嶺からの距離','20日平均からの距離']
CATF=['時間帯','時刻','曜日','利確の線が無い','前日の向き','週の線の向き']
def masks(df,ref):
    M={}
    for f in NUMF:
        q=ref[f].quantile([.2,.4,.6,.8]).values
        b=np.digitize(df[f].values,q)
        b=np.where(np.isnan(df[f].values),-1,b)
        for v in range(5): M[(f,f'{["下位20%","20-40%","40-60%","60-80%","上位20%"][v]}（{q[v-1] if v>0 else -np.inf:.2f}〜{q[v] if v<4 else np.inf:.2f}）')]=b==v
    for f in CATF:
        for v in df[f].dropna().unique(): M[(f,str(v))]=(df[f]==v).values
    return M
def learn(a,K=3,minfrac=0.05):
    keep=np.ones(len(a),bool);M=masks(a,a);chosen=[]
    for _ in range(K):
        best=None
        for key,m in M.items():
            mm=m&keep
            if mm.sum()<max(30,minfrac*len(a)): continue
            s=a.net.values[mm].sum()
            if s<0 and (best is None or s<best[1]): best=(key,s)
        if best is None: break
        chosen.append(best[0]);keep&=~M[best[0]]
    return chosen
def apply(df,ref,chosen):
    M=masks(df,ref);keep=np.ones(len(df),bool)
    for k in chosen: keep&=~M[k]
    return keep
out=[];ch=[]
for (inst,dr,fam),g in A.groupby(['inst','dir','fam']):
    a=g[g.yr<=2022].reset_index(drop=True);b=g[g.yr>=2023].reset_index(drop=True)
    for K in (1,2,3):
        c=learn(a,K)
        ka=apply(a,a,c);kb=apply(b,a,c)
        out.append(dict(inst=inst,dir=dr,fam=fam,K=K,n_a=len(a),net_a=a.net.sum(),net_a2=a.net[ka].sum(),n_b=len(b),n_b2=kb.sum(),net_b=b.net.sum(),net_b2=b.net[kb].sum(),
                        avg_b=b.net.mean(),avg_b2=b.net[kb].mean()))
        if fam=='W': ch.append(dict(inst=inst,dir=dr,K=K,chosen=' ／ '.join(f'{f}:{v}' for f,v in c)))
O=pd.DataFrame(out);O['d_b']=O.net_b2-O.net_b;O['d_avg']=O.avg_b2-O.avg_b
O.to_pickle('excl.pkl');pd.DataFrame(ch).to_pickle('excl_ch.pkl')
for (inst,dr,K),g in O.groupby(['inst','dir','K']):
    w=g[g.fam=='W'].iloc[0];r=g[g.fam!='W']
    print(f'{inst} {dr} 除く数{K}: 前半 {w.net_a:7.0f}→{w.net_a2:7.0f} | 後半 {w.net_b:7.0f}→{w.net_b2:7.0f}（{w.n_b}→{w.n_b2}回、1回 {w.avg_b:5.1f}→{w.avg_b2:5.1f}） | でたらめの後半の1回の改善 中央 {r.d_avg.median():5.1f} 範囲 {r.d_avg.min():5.1f}〜{r.d_avg.max():5.1f}')
print(pd.DataFrame(ch).to_string())
