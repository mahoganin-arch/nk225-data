import pandas as pd,numpy as np;pd.set_option('display.width',250)
A=pd.read_pickle('feat3.pkl');COST={'fut':5,'cfd':7};A['net']=A.pt-A.inst.map(COST)
A['per']=np.where(A.yr<=2022,'前半','後半')
R={
 'L':{'なし':lambda a:np.ones(len(a),bool),
      'R1 前日が静かな日を除く（前日の値幅≥20日平均×0.6）':lambda a:a['前日の値幅と20日平均の比']>=0.6,
      'R2 日中だけ':lambda a:a['時間帯']=='日中',
      'R3 Dが小さい日を除く（D≥20日平均の値幅×0.3）':lambda a:a['Dと20日平均の比']>=0.3,
      'R1＋R2':lambda a:(a['前日の値幅と20日平均の比']>=0.6)&(a['時間帯']=='日中'),
      'R1＋R3':lambda a:(a['前日の値幅と20日平均の比']>=0.6)&(a['Dと20日平均の比']>=0.3)},
 'S':{'なし':lambda a:np.ones(len(a),bool),
      'S1 売られすぎを除く（20日平均より2%以上下）':lambda a:a['20日平均からの距離']<2,
      'S2 値幅の大きい日を除く（D≥値段の1.2%）':lambda a:a['Dの大きさ（値段比）']<1.2,
      'S3 日の終わりまで5時間未満を除く':lambda a:a['日の終わりまでの時間']>=5,
      'S1＋S2':lambda a:(a['20日平均からの距離']<2)&(a['Dの大きさ（値段比）']<1.2),
      'S1＋S2＋S3':lambda a:(a['20日平均からの距離']<2)&(a['Dの大きさ（値段比）']<1.2)&(a['日の終わりまでの時間']>=5),
      'S1＋S2＋日中だけ':lambda a:(a['20日平均からの距離']<2)&(a['Dの大きさ（値段比）']<1.2)&(a['時間帯']=='日中')}}
out=[]
for (inst,dr),g in A.groupby(['inst','dir']):
    for nm,f in R[dr].items():
        m=np.asarray(f(g));x=g[m]
        for per in ['前半','後半']:
            w=x[(x.fam=='W')&(x.per==per)];q=x[(x.fam!='W')&(x.per==per)]
            rq=q.groupby('fam').net.sum()
            out.append(dict(inst=inst,dir=dr,rule=nm,per=per,n=len(w),net=w.net.sum(),avg=w.net.mean(),win=(w.net>0).mean(),r_med=rq.median(),r_max=rq.max(),r_avg=q.net.mean(),rank=(rq<w.net.sum()).mean()))
O=pd.DataFrame(out);O.to_pickle('rules.pkl')
p=O.pivot_table(index=['inst','dir','rule'],columns='per',values=['n','net','avg','r_avg','rank'],sort=False)
print(p.round(2).to_string())
# 年ごと
yrs=[]
for (inst,dr),g in A[A.fam=='W'].groupby(['inst','dir']):
    for nm,f in R[dr].items():
        x=g[np.asarray(f(g))];s=x.groupby('yr').net.sum()
        yrs.append(dict(inst=inst,dir=dr,rule=nm,**{str(k):v for k,v in s.items()}))
Yr=pd.DataFrame(yrs);Yr.to_pickle('rules_y.pkl');print(Yr.round(0).to_string())
