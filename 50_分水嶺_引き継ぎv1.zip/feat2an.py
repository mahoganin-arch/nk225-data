import pandas as pd,numpy as np;pd.set_option('display.width',250);pd.set_option('display.max_rows',500)
A=pd.read_pickle('feat2.pkl')
A['per']=np.where(A.yr<=2022,'前半17-22','後半23-26')
A['hrb']=A.hr
A['gapb']=pd.cut(A.gap*np.where(A.dir=='L',1,-1),[-99,-0.5,-0.1,0.1,0.5,99],labels=['逆向き大','逆向き小','ほぼ無し','同じ向き小','同じ向き大'])
A['Db']=pd.qcut(A.Dpct,4,labels=['D小','D中小','D中大','D大'])
A['pvb']=pd.cut(A.pv_dist,[-1,0.25,0.5,1,99],labels=['勢い小','勢い中','勢い大','勢い特大'])
A['wd']=A.wd.map({0:'月',1:'火',2:'水',3:'木',4:'金',5:'土'})
feats=['line','above_W','ses','gapx','prevbull','wkside','gapb','Db','pvb','wd']
out=[]
for inst in ['fut','cfd']:
  for dr in ['L','S']:
    a=A[(A.inst==inst)&(A.dir==dr)]
    for f in feats:
      for v,g in a.groupby(f,observed=True):
        r={}
        for per,gg in g.groupby('per'):
          w=gg[gg.fam=='W'];q=gg[gg.fam!='W']
          r[per+'_n']=len(w);r[per+'_W']=w.pt.mean();r[per+'_R']=q.pt.mean()
        out.append(dict(inst=inst,dir=dr,feat=f,val=v,**r))
O=pd.DataFrame(out)
for c in ['前半17-22','後半23-26']: O[c+'_ex']=O[c+'_W']-O[c+'_R']
O.to_pickle('feat2an.pkl')
cols=['feat','val','前半17-22_n','前半17-22_W','前半17-22_R','後半23-26_n','後半23-26_W','後半23-26_R']
for inst in ['fut','cfd']:
  for dr in ['S','L']:
    print('=====',inst,dr);print(O[(O.inst==inst)&(O.dir==dr)][cols].round(1).to_string(index=False))
