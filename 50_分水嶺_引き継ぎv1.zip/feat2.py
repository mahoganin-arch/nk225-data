import eng4, eng3, numpy as np, pandas as pd, warnings; warnings.filterwarnings('ignore')
from mfe import excur
RT={'fut':10,'cfd':7}
rows=[]
for inst in ['fut','cfd']:
    B=eng4.prep(inst);d=B['d'];n=len(d)
    o,h,l,c=d.o.values,d.h.values,d.l.values,d.c.values
    chk=B['tfe'][60];ci=np.nonzero(chk)[0]
    prevchk=np.full(n,np.nan);prevchk[ci[1:]]=c[ci[:-1]]
    ss=B['ses_start'];sidx=np.maximum.accumulate(np.where(ss,np.arange(n),0));sopen=o[sidx]
    # 前のセッションの終値
    se=np.nonzero(B['ses_end'])[0];prevsc=np.full(n,np.nan)
    k=np.searchsorted(se,sidx)-1;okk=k>=0;prevsc[okk]=c[se[k[okk]]]
    firstbucket=np.r_[True,np.cumsum(chk)[:-1]]  # placeholder
    nchk_since=np.zeros(n,int);cnt=0
    for i in range(n):
        if ss[i]: cnt=0
        nchk_since[i]=cnt
        if chk[i]: cnt+=1
    de=np.nonzero(B['pend']['day'])[0]
    hr=d.t.dt.hour.values;wd=d.t.dt.dayofweek.values;yr=d.t.dt.year.values
    hm=hr*60+d.t.dt.minute.values
    dayses=((hm>=480)&(hm<975)) if inst=='fut' else ((hr>=7)&(hr<17))
    for fam in ['W']+[f'r{s}' for s in range(10)]:
        LN={k:eng3.bar_lines(B,k,fam,inst)[0] for k in ['wk','day']}
        Ld=LN['day']
        for dr in ['L','S']:
            T=eng4.run(B,Ld,'day','E2',dr,'T60',0.0,'-')
            if len(T)==0: continue
            i=T.ei.values;p=c[i];pv=prevchk[i]
            M=np.c_[Ld['alp'][i],Ld['gam'][i],Ld['ome'][i]];nm=np.array(['α','γ','Ω'])
            if dr=='L':
                cr=(M>pv[:,None])&(M<=p[:,None]);X=np.where(cr,M,-np.inf);j=X.argmax(1)
            else:
                cr=(M<pv[:,None])&(M>=p[:,None]);X=np.where(cr,M,np.inf);j=X.argmin(1)
            Xv=M[np.arange(len(i)),j];W=Ld['W'][i];D=Ld['D'][i]
            sd=1 if dr=='L' else -1
            gapx=(nchk_since[i]==0)&((sopen[i]-Xv)*sd>0)
            gap=(sopen[i]-prevsc[i])/D
            endi=de[np.searchsorted(de,i)]
            fav,adv=excur(h,l,i,endi,T.ep.values,T.dir.values)
            df=pd.DataFrame({'inst':inst,'fam':fam,'dir':dr,'yr':yr[i],'pt':T.pt.values,'fav':fav,'adv':adv,'rs':T.rs.values,
                'line':nm[j],'above_W':np.where(Xv>W,'分水嶺より上の線','分水嶺より下の線'),
                'ses':np.where(dayses[i],'日中','夜間'),'hr':hr[i],'wd':wd[i],'gapx':np.where(gapx,'窓で抜けた','足の中で抜けた'),
                'gap':gap,'prevbull':np.where(Ld['s'][i]>0,'前日陽線','前日陰線'),
                'wkside':np.where(np.isnan(LN['wk']['W'][i]),'na',np.where(p>LN['wk']['W'][i],'週Wの上','週Wの下')),
                'Dpct':D/p*100,'dist_open':(p-sopen[i])/D*sd,'pv_dist':(p-pv)/D*sd})
            rows.append(df)
    print(inst,flush=True)
A=pd.concat(rows,ignore_index=True);A.to_pickle('feat2.pkl');print(len(A))
