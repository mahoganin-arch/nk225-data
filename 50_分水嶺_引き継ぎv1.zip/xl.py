import pandas as pd,numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment,Border,Side
from openpyxl.utils import get_column_letter as L
R=pd.read_pickle('grid.pkl');Y=pd.read_pickle('grid_y.pkl');M=pd.read_pickle('mtf.pkl');N=pd.read_pickle('nest.pkl');ND=pd.read_pickle('nest_d.pkl');RL=pd.read_pickle('rolls.pkl')
IN={'fut':'ミニ','cfd':'CFD'};KY={'wk':'週','day':'日','ses':'セッション'}
RU={'A':'A 始まりで決めて終わりまで','B5':'B ドテン 5分','B15':'B ドテン 15分','B60':'B ドテン 60分','C5':'C ドテン＋利確 5分','C15':'C ドテン＋利確 15分','C60':'C ドテン＋利確 60分'}
wb=Workbook();F='Arial'
hf=Font(name=F,bold=True,color='FFFFFF');hfill=PatternFill('solid',fgColor='305496');thin=Side(style='thin',color='BFBFBF')
def header(ws,r,cols):
    for j,c in enumerate(cols,1):
        x=ws.cell(r,j,c);x.font=hf;x.fill=hfill;x.alignment=Alignment(wrap_text=True,vertical='center')
def fmt(ws,widths):
    for j,w in enumerate(widths,1): ws.column_dimensions[L(j)].width=w
    for row in ws.iter_rows():
        for x in row:
            if x.font.name!=F: x.font=Font(name=F,bold=x.font.bold,color=x.font.color,size=x.font.size)
    ws.freeze_panes='A2' if ws.title!='まとめ' else None
NUM='#,##0;[Red]-#,##0'
# まとめ
ws=wb.active;ws.title='まとめ'
lines=[('分水嶺ライン（Ω・γ・分水嶺・α）の検証まとめ　2026-10-20',True),
('データ：ミニ（OSE:NK225M1!、限月の飛びを調整）5分足 2017/1〜2026/10/8、CFD（FOREXCOM:JP225）5分足 2017/3〜2026/10/8。2026/10/9 以降は使っていない。',False),
('コスト：ミニ 往復10円、CFD 往復7円（pt）。「割合」は 60,000円のときに同じ額になる割合で、値段に比例させた版。損益は1枚・1単位あたりの pt（ミニは×100円）。',False),
('',False),('■ 結論',True),
('1. 「分水嶺より上なら買い・下なら売り」は、週・日・セッションのどれでも、コスト後に安定した利益が出なかった（42通り中、両方のコストでプラスは CFD 週ルールAの1通りだけ）。',False),
('2. プラスが出た形も、分水嶺の代わりにでたらめな線（前の終値±値幅×乱数）を使った場合と同じ程度。分水嶺に特別な効き目は見られない。',False),
('3. 同じルールでも、ミニと CFD で結果が逆になることがある（週ルールA：ミニ −34,020、CFD +15,750）。週明けの始値の時刻（8:45 と 7:00）の違いだけで約2万円 pt 変わる。偶然の影響が大きい印。',False),
('4. CFD 週ルールAのプラスは、日経の上昇の分。毎週月曜に買うだけ（+47,706）より少ない。',False),
('5. 日・セッションの売買に週（日）の分水嶺を条件として足すと、取引が減って損が小さくなるが、1回あたりの損益はでたらめな線を条件にした場合と変わらない。',False),
('6. 入れ子の前向き（候補選びを過去の年だけで行う）：ミニ −3,686、CFD +11,784。CFD もでたらめな線5種の結果（−25,673〜+17,982）の範囲内。',False),
('7. 1回あたりの粗利（コスト前）は、ほとんどが −10〜+8 pt で、コスト（7〜10 pt）を超えない。日・セッションでは回数が多い分、コストで大きく負ける。',False),
('',False),('■ 次の候補',True),
('・線を「売買の向き」ではなく、利確・損切りの目安として、別の仕掛け（窓埋め・寄り天など）に組み合わせて効くかを見る。',False),
('・線への反応（タッチ後に反発するか、抜けて伸びるか）を直接数え、でたらめな線と比べる。',False),
]
for i,(t,b) in enumerate(lines,1):
    c=ws.cell(i,1,t);c.font=Font(name=F,bold=b,size=12 if b else 10);c.alignment=Alignment(wrap_text=True,vertical='top')
ws.column_dimensions['A'].width=110
# ルール別
ws=wb.create_sheet('ルール別')
R['ln']=R.line.where(~R.line.str.startswith('rand'),'rand')
cols=['商品','期間','ルール','分水嶺 固定','分水嶺 割合','前の終値','前の中点','でたらめ平均','でたらめ最大','分水嶺−でたらめ平均','回数','勝率','プラスの年数','1回の粗利 pt','上位10日の合計','分水嶺 コスト2倍']
header(ws,1,cols);r=2
for inst in ['fut','cfd']:
  for key in ['wk','day','ses']:
    for rule in RU:
      s=R[(R.inst==inst)&(R.key==key)&(R.rule==rule)];w=s[s.line=='W'].iloc[0];rd=s[s.ln=='rand']
      v=[IN[inst],KY[key],RU[rule],w.net_fix,w.net_pct,s[s.line=='C'].net_fix.iloc[0],s[s.line=='mid'].net_fix.iloc[0],rd.net_fix.mean(),rd.net_fix.max(),f'=D{r}-H{r}',w.n,w.win,w.yrs_pos,w.gross/w.n,w.top10,w.net_fix2]
      for j,x in enumerate(v,1):
        c=ws.cell(r,j,x)
        if j in(4,5,6,7,8,9,10,15,16): c.number_format=NUM
        if j==12: c.number_format='0%'
        if j==14: c.number_format='0.0;[Red]-0.0'
      r+=1
fmt(ws,[7,10,22,12,12,11,11,12,12,13,8,7,8,9,11,12])
ws.cell(r+1,1,'損益は pt（ミニは×100円）。固定＝往復コスト一定、割合＝値段に比例。でたらめ＝前の終値＋値幅×乱数（−1〜1）の線、種5つ。').font=Font(name=F,italic=True)
# 年別
ws=wb.create_sheet('年別（分水嶺）')
y=Y[Y.line=='W'].copy();y['cfg']=y.inst.map(IN)+' '+y.key.map(KY)+' '+y.rule
pv=y.pivot_table(index='cfg',columns='yr',values='net',aggfunc='sum',fill_value=0)
order=[IN[i]+' '+KY[k]+' '+ru for i in['fut','cfd'] for k in['wk','day','ses'] for ru in RU]
pv=pv.reindex(order);yrs=list(pv.columns)
header(ws,1,['設定']+[str(c) for c in yrs]+['合計'])
for i,(idx,row) in enumerate(pv.iterrows(),2):
    ws.cell(i,1,idx)
    for j,v in enumerate(row.values,2): ws.cell(i,j,float(v)).number_format=NUM
    ws.cell(i,len(yrs)+2,f'=SUM(B{i}:{L(len(yrs)+1)}{i})').number_format=NUM
fmt(ws,[16]+[9]*len(yrs)+[10])
ws.cell(len(pv)+3,1,'コスト固定、pt。2026年は10/8まで。').font=Font(name=F,italic=True)
# 上位足
ws=wb.create_sheet('上位足の条件')
M['ln']=M.hl.where(M.hl=='W','rand')
FL={'none':'条件なし','F1':'F1 上位の分水嶺と同じ側','F2':'F1＋上位のγ/αの手前','F3':'F3 上位が陽線なら買いだけ'}
header(ws,1,['商品','売買の期間','条件の期間','ルール','条件','回数','1回の粗利 pt','損益 固定','損益 割合','でたらめ条件 1回の粗利','でたらめ条件 損益 固定'])
r=2
for (inst,key,hk,rule,f),g in M.groupby(['inst','key','hkey','rule','filt'],sort=False):
    w=g[g.ln=='W'].iloc[0];rd=g[g.ln=='rand']
    v=[IN[inst],KY[key],KY[hk],rule,FL[f],w.n,w.avg_g,w.net_fix,w.net_pct,rd.avg_g.mean() if len(rd) else None,rd.net_fix.mean() if len(rd) else None]
    for j,x in enumerate(v,1):
        c=ws.cell(r,j,x)
        if j in(8,9,11): c.number_format=NUM
        if j in(7,10): c.number_format='0.0;[Red]-0.0'
    r+=1
fmt(ws,[7,9,9,7,24,8,10,11,11,12,12])
# 入れ子
ws=wb.create_sheet('入れ子の前向き')
FM={'W':'分水嶺','C':'前の終値','mid':'前の中点'}
header(ws,1,['商品','線','前向き 固定','前向き 割合','（参考）全期間で一番良い設定'])
for i,row in enumerate(N.itertuples(),2):
    for j,x in enumerate([IN[row.inst],FM.get(row.fam,'でたらめ'+row.fam[-1]),row.fwd_fix,row.fwd_pct,row.insample_best],1):
        c=ws.cell(i,j,x)
        if j>2: c.number_format=NUM
r=len(N)+4
ws.cell(r-1,1,'分水嶺の年ごとの選択（その年より前の成績で、両方のコストの小さい方が一番良い設定。マイナスなら見送り）').font=Font(name=F,bold=True)
header(ws,r,['商品','年','選んだ設定','損益 固定','損益 割合'])
for i,row in enumerate(ND[ND.fam=='W'].itertuples(),r+1):
    for j,x in enumerate([IN[row.inst],str(row.yr),row.pick,row.net,row.net_pct],1):
        c=ws.cell(i,j,x)
        if j>3: c.number_format=NUM
fmt(ws,[8,12,13,13,16])
# 切り替え
ws=wb.create_sheet('限月切り替えの飛び')
header(ws,1,['切り替えの時刻（日本時間）','飛び（新−旧、円）'])
for i,row in enumerate(RL.itertuples(),2):
    ws.cell(i,1,row.t.strftime('%Y-%m-%d %H:%M'));ws.cell(i,2,row.jump).number_format=NUM
n=len(RL)+1
ws.cell(n+2,1,'3・9月の平均');ws.cell(n+2,2,f'=AVERAGEIFS(B2:B{n},A2:A{n},"*-03-*")/2+AVERAGEIFS(B2:B{n},A2:A{n},"*-09-*")/2').number_format=NUM
ws.cell(n+3,1,'6・12月の平均');ws.cell(n+3,2,f'=AVERAGEIFS(B2:B{n},A2:A{n},"*-06-*")/2+AVERAGEIFS(B2:B{n},A2:A{n},"*-12-*")/2').number_format=NUM
ws.cell(n+4,1,'先物と CFD の差の変化から推定。この分を切り替え前の値段に足して、つなぎ足を調整した。').font=Font(name=F,italic=True)
fmt(ws,[24,16])
# 式
ws=wb.create_sheet('計算式')
t=[('前の期間の H・L・C（期間の始値と終値で陽線・陰線）',True),('陽線：Ω＝2C−L、分水嶺＝2C−H、γ＝分水嶺＋(C−L)、α＝分水嶺−(C−L)',False),('陰線：Ω＝2C−H、分水嶺＝2C−L、γ＝分水嶺−(H−C)、α＝分水嶺＋(H−C)',False),
('期間：週＝月曜の日中〜土曜朝、日＝日中＋その夜の夜間（CFD は7:00区切り）、セッション＝ミニは日中/夜間、CFD は 7:00〜17:00 / 17:00〜翌7:00',False),
('ルールA：期間の最初の始値が分水嶺の上なら買い・下なら売り、期間の最後の終値で決済',False),('ルールB：A の後、5/15/60分足の終値が分水嶺を越えたらドテン（その終値で約定）。期間の最後に決済',False),
('ルールC：B に加え、買いは分水嶺＋D、売りは分水嶺−D で利確（D＝γ と分水嶺の幅）。利確後は次のドテンの合図まで休む',False)]
for i,(x,b) in enumerate(t,1): ws.cell(i,1,x).font=Font(name=F,bold=b)
ws.column_dimensions['A'].width=110
wb.save('/home/claude/bs/分水嶺ライン検証_2026-10-20.xlsx')
