import pandas as pd,numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter as L
F='Arial';NUM='#,##0;[Red]-#,##0'
IN={'fut':'ミニ','cfd':'CFD'};DR={'L':'買いだけ','S':'売りだけ','LS':'両方','逆L':'逆張り(買い条件で売り)','逆S':'逆張り(売り条件で買い)','逆LS':'逆張り(両方)'}
TM={'T0':'セッション開始','T15':'15分確定','T30':'30分確定','T60':'60分確定'};XM={0:'セッション終わり',1:'条件が崩れたら'}
CD={'S0':'S0 日Wの上','Wk':'Wk 週Wの上','A1':'A1 価格>日W>週W','A2':'A2 A1+価格>セッションW','A3':'A3 A1+セッションW>日W'}
wb=Workbook()
def sheet(title,cols,rows,fmts,widths,note=None,first=False):
    ws=wb.active if first else wb.create_sheet(title);ws.title=title
    for j,c in enumerate(cols,1):
        x=ws.cell(1,j,c);x.font=Font(name=F,bold=True,color='FFFFFF');x.fill=PatternFill('solid',fgColor='305496');x.alignment=Alignment(wrap_text=True,vertical='center')
    for i,r in enumerate(rows,2):
        for j,v in enumerate(r,1):
            if isinstance(v,(np.floating,)): v=float(v)
            if isinstance(v,(np.integer,)): v=int(v)
            c=ws.cell(i,j,v);c.font=Font(name=F)
            if j-1 in fmts: c.number_format=fmts[j-1]
    for j,w in enumerate(widths,1): ws.column_dimensions[L(j)].width=w
    ws.freeze_panes='A2'
    if note: ws.cell(len(rows)+3,1,note).font=Font(name=F,italic=True)
    return ws
# まとめ
txt=[('週・日・セッションの分水嶺の並びでの売買　検証まとめ（2026-10-20）',True),
('データ：ミニ（限月調整済み）・CFD（FOREXCOM:JP225）の5分足、2017〜2026/10/8。コスト：ミニ往復10円・CFD往復7円（固定と、値段に比例の割合の2通り）。損益は1枚の pt。',False),
('比べる相手：分水嶺の代わりに、前の期間の終値±値幅の範囲でランダムに引いた線（週・日・セッションそれぞれ）。同じ手順を全部通す。並びの条件は30種、決済の幅は5種。',False),('',False),('■ 結論',True),
('1. 「価格＞日W＞週W で買い（逆で売り）」など、並びの条件で順張りする形（120通り）は、ほとんどがでたらめな線の真ん中より下。A1〜A3 の平均順位は30種中 下から13〜29%。',False),
('2. 入れ子の前向き（毎年、その年より前の成績で設定を選ぶ）：ミニ +20,392、CFD +11,419。でたらめ30種の中央（+20,525・+11,465）とほぼ同じで、効き目は見られない。',False),
('3. プラスの大きい設定は、どれも「買いだけ・条件が崩れるまで持つ」形で、日経の上昇（特に2025〜2026年）を取っているだけ。でたらめな線でも同じ程度に出る。',False),
('4. 逆張り（日Wの下で、日W<週Wのとき買い、Wに戻ったら決済＝ゼロラインへの戻り）は、全期間ではでたらめのほぼすべてを上回った。ただし利益の多くが2026年で、入れ子の前向きでは CFD −6,363（でたらめ30種の下から3%）。安定した効き目とは言えない。',False),
('5. 決済の幅（固定50〜500円、前セッション値幅×0.25〜1.5、日・週の次の線まで、計約2,600通り）：入れ子の前向きでミニ −3,018、CFD −2,225。でたらめ5種（−12,228〜+15,382）の範囲内。',False),
('6. 入った後の最大の含み益と含み損は、どの条件でもほぼ同じ大きさ（中央値 70〜140円）。+100円に届く割合は約55%、+500円は約8%。配信の「第1決済レンジ（約100円）」「最大決済レンジ（約500円）」に、届きやすさの偏りは無い。',False),
('',False),('■ 考えられる理由',True),
('・分水嶺は前の期間の高値・安値・終値の折り返しで、値動きの「その後」を決める情報を持っていない（でたらめな線と同じ振る舞い）。',False),
('・成績の差の多くは、上昇相場での買いの持ち時間の長さで決まる。',False),
]
ws=wb.active;ws.title='まとめ'
for i,(t,b) in enumerate(txt,1):
    c=ws.cell(i,1,t);c.font=Font(name=F,bold=b,size=12 if b else 10);c.alignment=Alignment(wrap_text=True,vertical='top')
ws.column_dimensions['A'].width=115
# 並び 全設定
W=pd.read_pickle('p1_W.pkl').reset_index()
rows=[[IN[r.inst],CD[r.cond],DR[r.dir],TM[r.tim],XM[r.xm],r.nf,r.np_,r.n,r.avg,r.r_med,r.rank_pct] for r in W.sort_values(['inst','cond','dir','tim','xm'],ascending=[False,True,True,True,True]).itertuples()]
sheet('並び 全設定',['商品','条件','向き','入る','決済','損益 固定','損益 割合','回数','1回の粗利 pt','でたらめ30種の中央','でたらめより上の割合'],rows,{5:NUM,6:NUM,9:NUM,8:'0.0;[Red]-0.0',10:'0%'},[6,22,9,12,14,10,10,7,9,11,10],'でたらめより上の割合：30種のうち、本物の損益（固定）が上回った割合。50%前後なら、でたらめと区別できない。')
# 逆張り
Y=pd.read_pickle('p1_all_rev.pkl');S=Y.groupby(['inst','fam','cond','dir','tim','xm']).agg(nf=('nf','sum'),np_=('np_','sum'),gross=('gross','sum'),n=('n','sum')).reset_index()
key=['inst','cond','dir','tim','xm'];Wr=S[(S.fam=='W')&S.dir.str.startswith('逆')].set_index(key);Rr=S[(S.fam!='W')&S.dir.str.startswith('逆')]
lst=Rr.groupby(key).nf.apply(list);Wr['rank']=[np.mean(np.array(lst[i])<Wr.nf[i]) for i in Wr.index];Wr=Wr.reset_index()
rows=[[IN[r.inst],CD[r.cond],DR[r.dir],TM[r.tim],XM[r.xm],r.nf,r.np_,r.n,r.gross/r.n,r.rank] for r in Wr.sort_values('nf',ascending=False).itertuples()]
sheet('逆張り',['商品','条件','向き','入る','決済','損益 固定','損益 割合','回数','1回の粗利 pt','でたらめより上の割合'],rows,{5:NUM,6:NUM,8:'0.0;[Red]-0.0',9:'0%'},[6,22,20,12,14,10,10,7,9,10],'並びの条件の向きを反対にした場合。損益の大きい順。')
# 年別
w=Y[Y.fam=='W'];sel=[('A1','L','T0',1),('A2','L','T0',1),('A3','L','T60',1),('Wk','L','T0',1),('A1','逆S','T60',1),('S0','逆S','T60',1),('A1','LS','T60',0),('A2','LS','T30',0)]
yrs=sorted(w.yr.unique());rows=[]
for inst in ['fut','cfd']:
    for c,dd,t,x in sel:
        s=w[(w.inst==inst)&(w.cond==c)&(w.dir==dd)&(w.tim==t)&(w.xm==x)].groupby('yr').nf.sum()
        rows.append([IN[inst],CD[c],DR[dd],TM[t],XM[x]]+[float(s.get(y,0)) for y in yrs]+[None])
ws=sheet('年別 主な設定',['商品','条件','向き','入る','決済']+[str(y) for y in yrs]+['合計'],rows,{i:NUM for i in range(5,6+len(yrs))},[6,22,20,12,14]+[8]*len(yrs)+[9],'コスト固定。2026年は10/8まで。')
for i in range(2,len(rows)+2): ws.cell(i,6+len(yrs),f'=SUM({L(6)}{i}:{L(5+len(yrs))}{i})').number_format=NUM
# 入れ子
rows=[]
for nm,fn in [('並び（順張り120通り）','p1_nest.pkl'),('並び（順張り＋逆張り240通り）','p1r_nest.pkl'),('決済の幅つき（約2,580通り）','p2_nest.pkl')]:
    Fn=pd.read_pickle(fn)
    for inst in ['fut','cfd']:
        f=Fn[Fn.inst==inst];wv=f[f.fam=='W'].iloc[0];r=f[f.fam!='W']
        rows.append([nm,IN[inst],wv.fwd_nf,wv.fwd_np,len(r),r.fwd_nf.median(),r.fwd_nf.min(),r.fwd_nf.max(),(r.fwd_nf<wv.fwd_nf).mean()])
sheet('入れ子の前向き',['手順','商品','本物 固定','本物 割合','でたらめの数','でたらめ 中央','でたらめ 最小','でたらめ 最大','本物が上回る割合'],rows,{2:NUM,3:NUM,5:NUM,6:NUM,7:NUM,8:'0%'},[26,6,10,10,8,10,10,10,10],'2019〜2026年。毎年、その年より前の成績（両方のコストの小さい方）で一番良い設定を選び、その年に使う。マイナスなら見送り。')
D=pd.concat([pd.read_pickle('p1r_nest_d.pkl').assign(手順='並び 順＋逆'),pd.read_pickle('p2_nest_d.pkl').assign(手順='決済の幅つき')])
D=D[D.fam=='W'];rows=[[r.手順,IN[r.inst],str(r.yr),r.pick,r.nf,r.np_] for r in D.itertuples()]
sheet('前向き 年ごとの選択',['手順','商品','年','選んだ設定（条件|向き|入る|決済）','損益 固定','損益 割合'],rows,{4:NUM,5:NUM},[12,6,6,40,10,10])
# 決済の種類
S2=pd.read_pickle('p2_s.pkl');E=S2.groupby(['inst','ext','fam']).agg(med=('nf','median'),best=('nf','max'),pos=('nf',lambda s:(s>0).mean()),avg=('avg','mean')).reset_index()
E['f2']=np.where(E.fam=='W','本物','でたらめ平均');E=E.groupby(['inst','ext','f2'])[['med','best','pos','avg']].mean().reset_index()
rows=[[IN[r.inst],r.ext,r.f2,r.med,r.best,r.pos,r.avg] for r in E.sort_values(['inst','ext','f2'],ascending=[False,True,False]).itertuples()]
sheet('決済の幅 種類別',['商品','決済の基準','線','損益の中央','一番良い設定','プラスの割合','1回の粗利 pt'],rows,{3:NUM,4:NUM,5:'0%',6:'0.0;[Red]-0.0'},[6,12,12,11,11,10,10],'固定＝利確・損切りの円、値幅＝前セッションの値幅×倍率、線まで＝日（週）の次の線を利確に。どれもセッションの終わりで決済。')
W2=pd.read_pickle('p2_W.pkl').reset_index()
rows=[[IN[r.inst],CD[r.cond],DR[r.dir],TM[r.tim],r.ex,r.nf,r.np_,r.n,r.avg,r.rmean,r.rmax] for r in W2.rename(columns={'mean':'rmean','max':'rmax'}).sort_values('nf',ascending=False).groupby('inst').head(25).sort_values(['inst','nf'],ascending=[False,False]).itertuples()]
sheet('決済の幅 上位',['商品','条件','向き','入る','決済','損益 固定','損益 割合','回数','1回の粗利 pt','でたらめ5種 平均','でたらめ5種 最大'],rows,{5:NUM,6:NUM,8:'0.0;[Red]-0.0',9:NUM,10:NUM},[6,22,9,12,22,10,10,7,9,10,10],'全期間で一番良い設定は、選んだ後の年で続かない（入れ子の前向きのシート参照）。')
M=pd.read_pickle('mfe.pkl')
rows=[[IN[r.inst],CD[r.cond],TM[r.tim],r.dir,r.n,r.fav50,r.fav75,r.fav90,r.adv50,r.adv75,r.adv90,r.p100,r.p500,r.end_avg] for r in M.itertuples()]
sheet('含み益と含み損',['商品','条件','入る','向き','回数','含み益 中央','含み益 75%','含み益 90%','含み損 中央','含み損 75%','含み損 90%','+100円に届く','+500円に届く','終わりの平均 pt'],rows,{5:NUM,6:NUM,7:NUM,8:NUM,9:NUM,10:NUM,11:'0%',12:'0%',13:'0.0;[Red]-0.0'},[6,22,12,6,7,9,9,9,9,9,9,9,9,9],'入った後、セッションの終わりまでの最大の含み益・含み損（pt）。')
txt2=['条件（買い。売りは上下を逆）','S0：価格＞日の分水嶺','Wk：価格＞週の分水嶺','A1：価格＞日の分水嶺＞週の分水嶺','A2：A1 かつ 価格＞セッションの分水嶺','A3：A1 かつ セッションの分水嶺＞日の分水嶺 かつ 価格＞セッションの分水嶺',
'入る：セッション開始＝始値で条件を見て入る。15/30/60分確定＝その足の終値で条件が「成り立っていない→成り立った」に変わったら入る。',
'決済：セッション終わり／条件が崩れたら（同じ足の確定で判定。開始で入った場合は15分足）。持ち越しあり。',
'期間：週＝月曜日中〜土曜朝、日＝日中＋夜間（CFD は7:00区切り）、セッション＝ミニは日中・夜間、CFD は7:00〜17:00・17:00〜翌7:00。',
'利確と損切りが同じ足で両方届いたときは、損切りとして数える。窓で飛んだときは始値で約定。']
ws=wb.create_sheet('条件の説明')
for i,t in enumerate(txt2,1): ws.cell(i,1,t).font=Font(name=F,bold=(i==1))
ws.column_dimensions['A'].width=110
wb.save('分水嶺の並び検証_2026-10-20.xlsx')
