"""全期間の候補群（本物）と、でたらめな線の群の数。候補の表を作る（でたらめな線の同じ設定の成績を添える）。"""
import pandas as pd,numpy as np,g_scr,g_sig as G
DF=pd.read_csv('defs.csv',index_col=0);FT=pd.read_csv('feats.csv')
EXN=[f"{G.TPS[a]}|{G.SLS[s]}|{G.TIMES[t]}" for a,s,t in G.EXITS]
cnt=[];tabs={}
for inst in ['fut','cfd']:
    fams=['W','r0','r1','r2','r20','r21','r22']
    for fam in fams:
        A=pd.read_parquet(f'agg_{inst}_{fam}.parquet');S,grp,h=g_scr.screen(A,list(range(2017,2027)))
        cnt.append(dict(inst=inst,fam=fam,**{g:int(m.sum()) for g,m in grp.items()}))
        if fam=='W':
            K=A[['def','exit','feat','val']].join(S)
            K=K[K['群']!='']
            K['tot']=A.loc[K.index,[f'net{y}' for y in range(2017,2027)]].sum(1);K['totn']=A.loc[K.index,[f'nrm{y}' for y in range(2017,2027)]].sum(1)
            Wk=K
        else:
            A['avg']=A[[f'net{y}' for y in range(2017,2027)]].sum(1)/A[[f'n{y}' for y in range(2017,2027)]].sum(1)
            r=A.set_index(['def','exit','feat','val']).avg.rename(fam)
            Wk=Wk.join(r,on=['def','exit','feat','val'])
        print(inst,fam,flush=True)
    Wk['でたらめ同じ設定の1回平均']=Wk[[f for f in fams[1:]]].mean(1)
    Wk=Wk.merge(DF,left_on='def',right_index=True).merge(FT,on=['feat','val'])
    Wk['決済']=Wk.exit.map(lambda e:EXN[e])
    tabs[inst]=Wk.drop(columns=fams[1:])
pd.DataFrame(cnt).to_pickle('grpcount.pkl');pd.to_pickle(tabs,'cands_full.pkl')
print(pd.DataFrame(cnt).to_string())
