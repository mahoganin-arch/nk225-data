"""G3：合図ごとの条件を付け、入り方 × 決済 × 条件 × 年 の成績を集計する。
コスト：主＝実コスト（ミニ往復5pt・CFD往復7pt）、副＝今の値段にそろえる（pt×68,800÷入った値段 − 同じコスト）。
出力：agg_{inst}_{fam}.parquet（年ごとの n・純損益・そろえた純損益・勝ち・利益の和・損失の和。合計 n≥20 だけ）
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs'); sys.path.insert(0, '/home/claude/bs/g')
import eng2, eng3
import g_sig as G

COST = {'fut': 5.0, 'cfd': 7.0}
REF = 68800.0
YEARS = list(range(2017, 2027))

def bins(x, edges):
    b = np.digitize(x, edges)
    return np.where(np.isnan(x), -1, b)

def features(inst, fam, X, S, DF, B):
    n = len(S['i']); i = S['i']; di = S['d']; e = S['e']
    dr = DF['dir'].values[di]; per = DF['per'].values[di]
    # 自分の期間の D と、前の期間の向き、週・日の分水嶺（同じ fam の線）
    Dself = np.full(n, np.nan); same = np.zeros(n, int); wkside = np.full(n, -1); dyside = np.full(n, -1)
    Wb = {}
    for j, key in enumerate(G.PERS):
        P, ok = B[key]; Lp = eng3.per_lines(P, ok, fam, inst, j); pid = X['pid_' + key]
        Wb[key] = (Lp.W.values[pid], Lp.D.values[pid], Lp.s.values[pid])
    for key in G.PERS:
        m = per == key
        Dself[m] = Wb[key][1][i[m]]
        same[m] = (Wb[key][2][i[m]] * dr[m] > 0).astype(int)
    ww = Wb['wk'][0][i]; wd = Wb['day'][0][i]
    wkside = np.where(np.isnan(ww), -1, ((e - ww) * dr > 0).astype(int))
    dyside = np.where(np.isnan(wd), -1, ((e - wd) * dr > 0).astype(int))
    # 勢い：直前の判定足（指値は直前の5分足）の終値からの動き÷D
    tf = DF['tf'].values[di]; pc = np.full(n, np.nan)
    for t in (5, 15, 30, 60):
        m = tf == t
        if not m.any(): continue
        if t == 5:
            pc[m] = X['c'][i[m] - 1]
        else:
            ch = np.nonzero(X[f'tf{t}'])[0]
            k = np.searchsorted(ch, i[m]) - 1
            pc[m] = X['c'][ch[np.maximum(k, 0)]]
    F = {}
    F['全体'] = (np.zeros(n, int), ['全体'])
    F['曜日'] = (X['wd'][i], ['月', '火', '水', '木', '金', '土'])
    F['時間'] = (X['hr'][i], [f'{h}時' for h in range(24)])
    F['曜日×時間'] = (X['wd'][i] * 24 + X['hr'][i], [f'{w} {h}時' for w in '月火水木金土' for h in range(24)])
    F['時間帯'] = (X['dayses'][i].astype(int), ['夜間', '日中'])
    F['前の期間の向き'] = (same, ['逆向き', '同じ向き'])
    F['週の分水嶺の側'] = (wkside, ['反対側', '同じ側'])
    F['日の分水嶺の側'] = (dyside, ['反対側', '同じ側'])
    for k, lab in [('sqw_major', 'SQ週（メジャー）'), ('sqw_minor', 'SQ週（ミニ）'), ('sq_day', 'SQ日'), ('hol_trade', '祝日の取引日'),
                   ('hol_before', '祝日の前日'), ('hol_after', '祝日の翌日'), ('month_end', '月末2日'), ('month_start', '月初2日')]:
        F[lab] = (X['mk_' + k][i].astype(int), ['以外', '該当'])
    F['寄りの窓（D比）'] = (bins(X['ses_gap'][i] * dr / Dself, [-0.5, -0.1, 0.1, 0.5]), ['逆向き 0.5超', '逆向き 0.1〜0.5', 'ほぼ無し', '同じ向き 0.1〜0.5', '同じ向き 0.5超'])
    F['前日の値幅÷20日平均'] = (bins(X['prevr'][i] / X['avg20'][i], [0.6, 0.8, 1.0, 1.3]), ['0.6未満', '0.6〜0.8', '0.8〜1.0', '1.0〜1.3', '1.3以上'])
    F['D÷20日平均の値幅'] = (bins(Dself / X['avg20'][i], [0.25, 0.4, 0.6, 1.0]), ['0.25未満', '0.25〜0.4', '0.4〜0.6', '0.6〜1.0', '1.0以上'])
    F['20日平均からの乖離（向き付き%）'] = (bins((e - X['ma20'][i]) * dr / e * 100, [-2, -0.5, 0.5, 2]), ['−2%未満', '−2〜−0.5%', '±0.5%', '0.5〜2%', '2%以上'])
    F['日足RSI14'] = (bins(X['rsi_d'][i], [30, 50, 70]), ['30未満', '30〜50', '50〜70', '70以上'])
    F['勢い（D比）'] = (bins((e - pc) * dr / Dself, [0.25, 0.5, 1.0]), ['0.25未満', '0.25〜0.5', '0.5〜1', '1以上'])
    return F

def agg(inst, fam):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); S = dict(np.load(f'/home/claude/bs/g/sig_{inst}_{fam}.npz'))
    DF = pd.read_csv('/home/claude/bs/g/defs.csv', index_col=0); B = eng2.base(inst)
    F = features(inst, fam, X, S, DF, B)
    yr = X['yr'][S['i']]; yi = yr - 2017
    R = S['R'].astype(np.float64); cost = COST[inst]
    net = R - cost; nrm = R * (REF / S['e'])[:, None] - cost
    if inst == 'cfd':  # 金利調整額：年3%（買い・売りとも支払いとして近似）を、7時をまたいだ回数だけ
        fin = S['nt'].astype(np.float64) * 0.03 / 365
        net = net - fin * S['e'][:, None]; nrm = nrm - fin * REF
    blocks = []; meta_d = []; meta_c = []; meta_f = []; meta_v = []
    fnames = list(F.keys())
    order = np.argsort(S['d'], kind='stable'); dsorted = S['d'][order]
    bounds = np.r_[0, np.nonzero(np.diff(dsorted))[0] + 1, len(dsorted)]
    for a, b in zip(bounds[:-1], bounds[1:]):
        idx = order[a:b]; di = int(S['d'][idx[0]])
        ny = net[idx]; nr = nrm[idx]; yy = yi[idx]
        valid = ~np.isnan(ny)
        for fi, fname in enumerate(fnames):
            code, labs = F[fname]
            cd = code[idx]; k = len(labs)
            ok = cd >= 0
            key = np.where(ok, cd * 10 + yy, -1)
            for col in range(48):
                v = ok & valid[:, col]
                if v.sum() < 20: continue
                kk = key[v]; x = ny[v, col]; z = nr[v, col]
                cnt = np.bincount(kk, minlength=k * 10).reshape(k, 10)
                keep = np.nonzero(cnt.sum(1) >= 20)[0]
                if len(keep) == 0: continue
                arr = [cnt, np.bincount(kk, x, k * 10).reshape(k, 10), np.bincount(kk, z, k * 10).reshape(k, 10),
                       np.bincount(kk, np.where(x > 0, x, 0), k * 10).reshape(k, 10), np.bincount(kk, np.where(x < 0, -x, 0), k * 10).reshape(k, 10),
                       np.bincount(kk, (x > 0).astype(float), k * 10).reshape(k, 10)]
                blocks.append(np.concatenate([q[keep] for q in arr], 1).astype(np.float32))
                meta_d.append(np.full(len(keep), di, np.int16)); meta_c.append(np.full(len(keep), col, np.int8))
                meta_f.append(np.full(len(keep), fi, np.int8)); meta_v.append(keep.astype(np.int16))
    M = np.concatenate(blocks)
    cols = [f'{s}{y}' for s in ['n', 'net', 'nrm', 'pos', 'neg', 'win'] for y in YEARS]
    A = pd.DataFrame(M, columns=cols)
    A.insert(0, 'val', np.concatenate(meta_v)); A.insert(0, 'feat', np.concatenate(meta_f))
    A.insert(0, 'exit', np.concatenate(meta_c)); A.insert(0, 'def', np.concatenate(meta_d))
    A.to_parquet(f'/home/claude/bs/g/agg_{inst}_{fam}.parquet')
    pd.DataFrame([(fi, fn, vi, lb) for fi, fn in enumerate(fnames) for vi, lb in enumerate(F[fn][1])], columns=['feat', 'feat_name', 'val', 'val_name']).to_csv('/home/claude/bs/g/feats.csv', index=False)
    print(inst, fam, len(A), flush=True)

if __name__ == '__main__':
    for fam in sys.argv[2].split(','):
        agg(sys.argv[1], fam)
