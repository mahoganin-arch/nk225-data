"""G1：ミニ・CFDの5分足に、区切り・判定足・印・特徴を付けて保存する。
出力：/home/claude/bs/g/data_{inst}.npz
"""
import sys, numpy as np, pandas as pd, holidays
sys.path.insert(0, '/home/claude/bs')
import eng, eng2

def sq_dates(years):
    out = {}
    for y in years:
        for m in range(1, 13):
            d = pd.Timestamp(y, m, 1)
            fr = d + pd.Timedelta(days=(4 - d.weekday()) % 7 + 7)
            out[fr.date()] = m in (3, 6, 9, 12)
    return out

def build(inst):
    B = eng2.base(inst); d = B['d']; n = len(d)
    t = d.t; yr = t.dt.year.values
    X = dict(o=d.o.values, h=d.h.values, l=d.l.values, c=d.c.values,
             tm=t.astype('int64').values, yr=yr)
    # 区切り
    for key in ['wk', 'day', 'ses']:
        P, ok = B[key]
        X['pid_' + key] = d[key].map(pd.Series(np.arange(len(P)), index=P.index)).values.astype(np.int64)
        pk = d[key].values
        X['end_' + key] = np.r_[pk[:-1] != pk[1:], True]
        X['ok_' + key] = ok
    X['ses_start'] = B['ses_start']
    for tf in (15, 30, 60):
        X[f'tf{tf}'] = B['tfe'][tf]
    X['tf5'] = np.ones(n, bool)
    # 時刻・曜日・時間帯
    hr = t.dt.hour.values; mi = t.dt.minute.values; hm = hr * 60 + mi
    X['hr'] = hr; X['wd'] = t.dt.dayofweek.values
    X['dayses'] = ((hm >= 480) & (hm < 975)) if inst == 'fut' else ((hr >= 7) & (hr < 17))
    # 印（取引日＝日の区切りの日付）
    dday = pd.to_datetime(d.day.values).date
    udays = sorted(set(dday))
    jp = holidays.JP(years=range(2016, 2028))
    sq = sq_dates(range(2016, 2028))
    tdays = pd.Series(udays)
    mon = pd.Series([x.month for x in udays]); nxt_mon = mon.shift(-1); prv_mon = mon.shift(1)
    mark = {}
    for i, x in enumerate(udays):
        wk_start = x - pd.Timedelta(days=x.weekday())
        sqw = [s for s in sq if wk_start <= s < wk_start + pd.Timedelta(days=7)]
        mark[x] = dict(
            sqw_major=bool(sqw and sq[sqw[0]]), sqw_minor=bool(sqw and not sq[sqw[0]]), sq_day=x in sq,
            hol_trade=x in jp, hol_before=(x + pd.Timedelta(days=1)) in jp, hol_after=(x - pd.Timedelta(days=1)) in jp or (x.weekday() == 0 and (x - pd.Timedelta(days=3)) in jp),
            month_end=(i + 2 < len(udays) and mon[i + 2] != mon[i]) or (i + 1 < len(udays) and mon[i + 1] != mon[i]),
            month_start=(i >= 2 and mon[i - 2] != mon[i]) or (i >= 1 and mon[i - 1] != mon[i]))
    for k in ['sqw_major', 'sqw_minor', 'sq_day', 'hol_trade', 'hol_before', 'hol_after', 'month_end', 'month_start']:
        X['mk_' + k] = np.array([mark[x][k] for x in dday])
    # 日足の特徴（前日までで確定した値）
    P, _ = B['day']
    rng = (P.h - P.l)
    avg20 = rng.rolling(20).mean().shift(1)
    prevr = rng.shift(1)
    ma20 = P.c.rolling(20).mean().shift(1)
    dc = P.c.diff()
    up = dc.clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean(); dn = (-dc.clip(upper=0)).ewm(alpha=1 / 14, adjust=False).mean()
    rsi = (100 - 100 / (1 + up / dn)).shift(1)
    pidd = X['pid_day']
    X['avg20'] = avg20.values[pidd]; X['prevr'] = prevr.values[pidd]; X['ma20'] = ma20.values[pidd]; X['rsi_d'] = rsi.values[pidd]
    # セッションの寄りの窓（前のセッションの終値との差）
    ss = B['ses_start']; sidx = np.maximum.accumulate(np.where(ss, np.arange(n), 0))
    se = np.nonzero(X['end_ses'])[0]; k = np.searchsorted(se, sidx) - 1
    prevsc = np.where(k >= 0, X['c'][se[np.maximum(k, 0)]], np.nan)
    X['ses_gap'] = X['o'][sidx] - prevsc
    np.savez_compressed(f'/home/claude/bs/g/data_{inst}.npz', **X)
    print(inst, n, {k: int(v.sum()) for k, v in X.items() if k.startswith('mk_')})

if __name__ == '__main__':
    for inst in sys.argv[1:] or ['fut', 'cfd']:
        build(inst)
