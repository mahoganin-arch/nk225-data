import pandas as pd,numpy as np,sys
DF=pd.read_csv('defs.csv',index_col=0)
YS=range(2019,2027)
def load(inst):
    rows=[]
    for fam in ['W','r0','r1','r2']:
        A=pd.read_parquet(f'agg_{inst}_{fam}.parquet',filters=[('feat','=',0)])
        A=A[['def','exit']+[f'{a}{y}' for a in ['n','net','nrm'] for y in range(2017,2027)]].copy();A['fam']=fam;rows.append(A)
    N=pd.read_pickle(f'famnull_{inst}_3.pkl').drop(columns=['inst']);rows.append(N)
    return pd.concat(rows,ignore_index=True).merge(DF,left_on='def',right_index=True)
def famtab(A,keys):
    g=A.groupby(keys+['fam'])
    n=g[[f'n{y}' for y in YS]].sum().sum(1);nt=g[[f'net{y}' for y in YS]].sum().sum(1);nr=g[[f'nrm{y}' for y in YS]].sum().sum(1)
    yp=(g[[f'nrm{y}' for y in YS]].sum()>0).sum(1)
    T=pd.DataFrame({'n':n,'avg':nt/n,'avgn':nr/n,'plusyrs':yp}).reset_index()
    W=T[T.fam=='W'].set_index(keys);R=T[T.fam!='W']
    st=R.groupby(keys).agg(r_mean=('avgn','mean'),r_sd=('avgn','std'),r_max=('avgn','max'),nr=('avgn','size'))
    W=W.join(st);W['rank']=[ (R.set_index(keys).loc[k].avgn< W.loc[k,'avgn']).mean() for k in W.index]
    W['z']=(W.avgn-W.r_mean)/W.r_sd
    return W
if __name__=='__main__':
    inst=sys.argv[1];A=load(inst);pd.set_option('display.width',250);pd.set_option('display.max_rows',200)
    W=famtab(A,['per','kind','dir']);print(W.round(2).to_string())
    W2=famtab(A,['per','line','kind','dir']);print(W2.sort_values('z',ascending=False).round(2).head(25).to_string())
    W.to_pickle(f'famrank_{inst}.pkl');W2.to_pickle(f'famrank2_{inst}.pkl')
