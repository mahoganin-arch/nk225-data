import pandas as pd,numpy as np,warnings;warnings.filterwarnings('ignore')
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter as L
F='Arial';NUM='#,##0;[Red]-#,##0';P1='0.0;[Red]-0.0';P2='0.00;[Red]-0.00';PC='0%';PC1='0.0%'
IN={'fut':'ミニ','cfd':'CFD'};DR={1:'買い',-1:'売り'}
wb=Workbook()
HF=Font(name=F,bold=True,color='FFFFFF');HP=PatternFill('solid',fgColor='305496')
def sheet(title,cols,rows,fmts,widths,note=None):
    ws=wb.create_sheet(title)
    for j,c in enumerate(cols,1):
        x=ws.cell(1,j,c);x.font=HF;x.fill=HP;x.alignment=Alignment(wrap_text=True,vertical='center')
    for i,r in enumerate(rows,2):
        for j,v in enumerate(r,1):
            if isinstance(v,(np.floating,float)): v=None if (v is None or np.isnan(v) or np.isinf(v)) else float(v)
            elif isinstance(v,np.integer): v=int(v)
            elif isinstance(v,(np.bool_,)): v=bool(v)
            c=ws.cell(i,j,v)
            if j-1 in fmts: c.number_format=fmts[j-1]
    for j,w in enumerate(widths,1): ws.column_dimensions[L(j)].width=w
    ws.freeze_panes='A2'
    if note: ws.cell(len(rows)+3,1,note).font=Font(name=F,italic=True)
    return ws
def text(title,lines,width=120):
    ws=wb.create_sheet(title) if title!='まとめ' else wb.active
    ws.title=title
    for i,(t,b) in enumerate(lines,1):
        c=ws.cell(i,1,t);c.font=Font(name=F,bold=b,size=12 if b else 10);c.alignment=Alignment(wrap_text=True,vertical='top')
    ws.column_dimensions['A'].width=width
# ---------- まとめ
G5=pd.read_pickle('g5.pkl');S=G5['S'].set_index('対象');OV=G5['OV'].set_index('組み合わせ')
C=pd.read_pickle('cand.pkl')
cs=C[C.yr>=2017].groupby(['inst','fam','delay']).nrm.sum()
lines=[('分水嶺ライン（Ω・γ・分水嶺・α）網羅的な検証　まとめ（2026-10-22）',True),
('データ：ミニ（OSE:NK225M1!、限月の飛びを調整）・CFD（FOREXCOM:JP225）の5分足、2017〜2026/10/8（10/9以降は前向きの確認用に残す）。ミニの線でミニを、CFDの線でCFDを売買（別々に評価）。',False),
('コスト：主＝実コスト（ミニ往復5pt、CFD往復7pt）。副＝今の値段にそろえた損益（pt×68,800÷入った値段−同じコスト）。CFD は7時をまたぐごとに金利調整額（年3%）を引く。',False),
('探索：入り方432通り（週・日・セッション × Ω・γ・分水嶺・α × 抜け6・反発9・指値タッチ3 × 買い・売り）× 決済48通り（利確4×損切り3×時間4）× 条件約230（曜日・時間・曜日×時間・時間帯・前の期間の向き・週と日の分水嶺の側・SQ週・SQ日・祝日・月末月初・寄りの窓・前日の値幅・D・20日乖離・日足RSI・勢い）＝ミニ約133万・CFD約131万の組み合わせ。',False),
('比べる相手：分水嶺の位置だけをランダムにし、γ・α・Ωの並びと間隔は本物と同じにした線。候補群と本当の前向きは同じ手順を全部通して6種、形としての強さは15種。',False),
('',False),('■ 結論',True),
('1. 全期間で基準を通る候補の数は、本物とでたらめで同じくらい（両方で優位：ミニ 本物42,847／でたらめ37,326〜51,011、CFD 本物29,443／でたらめ23,734〜36,252）。これだけ広く探すと、偶然でも同じ数が通る。候補一覧は「この中に本物の効き目があるか」の材料で、そのまま使う一覧ではない。',False),
('2. 本当の前向き（2019〜2026、毎年その年より前のデータだけで候補群を作り直し、上位5本を売買）：',False),
('　・ミニ：本物はでたらめと区別できない（両方で優位 −4,996、でたらめ6種の中央 +1,878。上回る割合33%）。',False),
('　・CFD：本物がでたらめより良い（両方で優位 +32,130／でたらめ中央 −10,663、上回る割合83%。前半で優位 +33,871／中央 −21,155、100%）。ただし最大DD 2.3万〜3.7万、PF 1.1〜1.2、上位10日で利益の約2倍（上位の日を除くとマイナス）で、口座としては弱い。',False),
('　・選ばれたのは主に「週の線の上抜け買い・指値買いを週の終わりまで持つ」形（金利調整額を引いた後）。',False),
('3. 前年までの成績と翌年の成績の順位相関は、どの群も −0.03〜+0.07。候補の中で上位を選んでも翌年は良くならない（窓埋め・寄り天と同じ）。',False),
('4. 形としての強さ（選ばず、形の全設定を平均）：ミニ・CFDとも、18の形はすべて偶然の範囲（z −1.3〜+2.1）。72の形×線では、「日の α の上抜け買い」がミニ（z=2.6）・CFD（z=3.4）とも一番上。72通りの中の一番なので割り引く必要があるが、2つの商品で同じ形が一番になっている。',False),
('5. 条件（印・曜日・時間・地合い）：2商品×2半期で一貫して効く条件はあるが、ほとんどはでたらめな線でも同じ向きに効く（相場のくせ）。例：売りは月曜が悪く木曜が良い、勢いが大きい抜けは良い、Dが小さい日の買いは悪い。線に特有の条件はほぼ見つからない。',False),
(f'6. 前の候補（日の γ・α・Ω の上抜け買い、1日1回、週の分水嶺の上）：今の値段にそろえて ミニ +{cs[("fut","W",False)]:,.0f}（10年すべてプラス）、CFD +{cs[("cfd","W",False)]:,.0f}。でたらめ3種 ミニ +20,620〜+31,867、CFD −2,836〜+14,811。入りを5分遅らせても、1分足で判定し直しても変わらない。ただし、この形は探索の途中で結果を見て選んだので、前向きの確認が必要。',False),
(f'7. 窓埋め・寄り天②と合わせる（2019〜2026、そろえた損益）：窓埋め＋寄り天② {OV.loc["窓埋め＋寄り天②","合計"]:,.0f}（合計÷最大DD {OV.loc["窓埋め＋寄り天②","RF"]:.1f}）→ 前の候補を足すと {OV.loc["窓埋め＋寄り天②＋分水嶺（前の候補 CFD）","合計"]:,.0f}（{OV.loc["窓埋め＋寄り天②＋分水嶺（前の候補 CFD）","RF"]:.1f}）。相関は窓埋めと0.25、寄り天と−0.15で、重なりは小さい。',False),
('',False),('■ 進め方の案',True),
('・前の候補（日の線の上抜け買い）は、ストラテジー v1・v2 で記録を続け、2026/10/9 以降の前向きで判断する（窓埋め・寄り天と同じ扱い）。',False),
('・CFD の「週の線の上抜け・指値買い（週の終わりまで）」は、本当の前向きで唯一でたらめを上回った形。ルールを固定して記録だけ始める候補。金利調整額とDDの大きさに注意。',False),
('・「日の α の上抜け買い」は、2商品で一番になった形。記録の候補に加える。',False),
('・売りは、この線では見込みが無い（形としても、前向きでも）。',False)]
text('まとめ',lines)
text('説明',[('この Excel について',True),
('候補群の基準（事前に決めた値、pt・実コスト後）：両方で優位＝前半（2017〜2021）・後半（2022〜2026）とも 件数20以上・1回平均+5pt以上・PF1.2以上・5年中4年以上で年3回以上。後半で優位・前半で優位＝その半期だけ満たす。少数・高勝率＝各半期10件以上・勝率65%以上・平均+5pt以上。安定（幅が広い）＝両方の半期でプラスで、決済を1つだけ変えた周りの設定の70%以上も両方の半期でプラス。',False),
('本当の前向き：確かめる年 t ごとに、t より前の年だけを2つの半期に分けて同じ基準で候補群を作り、点数（両方・安定・少数＝2つの半期の平均の小さい方、後半・前半＝その半期の平均）の上位5本（同じ入り方は1本まで）を t 年に売買。同じ足・同じ向きは1本、1日2本まで。',False),
('入り方：抜け＝判定足（15/30/60分）の終わり値が線を越えた（近さ b：線から D×b 以上先）。反発＝判定足の中で線から D×b 以内まで来て、終わり値は線の手前で止まった（線と反対の向きに入る）。指値タッチ＝5分足で、線から D×b 手前の指値に届いた（線で反発する向き）。どれも、その期間で最初の合図だけ。',False),
('決済：利確（次の線、入った値段から0.5D、1D、無し）× 損切り（基準の線から0.25D先、0.5D先、無し）× 時間（60分、240分、セッションの終わり、期間の終わり）。利確と損切りが同じ足なら損切り。窓で飛んだら始値で約定。',False),
('D＝分水嶺とγの幅（前の期間の終値から反対の端まで）。週の期間＝月曜日中〜土曜朝、日＝日中＋夜間（CFDは7時区切り）、セッション＝日中・夜間。',False),
('CFD の金利調整額：FOREX.com の日本225は、買い＝基準金利＋3.0%、売り＝基準金利−3.0%（日本時間7時に保有で発生）。ここでは買い・売りとも年3%の支払いとして近似。',False),
('寄り天②は、引き継ぎメモのルール②（8:45→9:05の先物+0.3812%以上で9:10にCFD売り、損切り0.8%、240分）を作り直したもの（2019〜2026で159件、メモの148件・+10,677円とは少し違う）。窓埋めは、窓埋めの本当の前向き（条件なし、long_flat.pkl の『全部』）のトレード。',False)])
# ---------- 候補群の数
GC=pd.read_pickle('grpcount.pkl')
gr=['両方で優位','後半で優位','前半で優位','少数・高勝率','安定（幅が広い）']
rows=[[IN[r['inst']],'本物' if r['fam']=='W' else 'でたらめ '+r['fam']]+[r[g] for g in gr] for _,r in GC.iterrows()]
sheet('候補群の数',['商品','線']+gr,rows,{i:NUM for i in range(2,7)},[6,12,11,11,11,11,13],'全期間（2017〜2026）で基準を通った組み合わせの数。本物とでたらめで同じくらい。')
# ---------- 候補一覧
T=pd.read_pickle('cands_full.pkl')
COLS=['群','商品','期間','線','入り方','判定足','近さ(D×)','向き','決済','条件の粒度','条件','前半件数','前半平均','前半勝率','前半PF','前半プラス年','後半件数','後半平均','後半勝率','後半PF','後半プラス年','前半そろえた平均','後半そろえた平均','周りの設定のプラス割合','全期間の合計','でたらめ同じ設定の1回平均']
FM={11:'0',12:P1,13:PC,14:P2,15:'0',16:'0',17:P1,18:PC,19:P2,20:'0',21:P1,22:P1,23:PC,24:NUM,25:P1}
PER={'wk':'週','day':'日','ses':'セッション'}
for g,cap in [('両方で優位',20000),('後半で優位',10000),('前半で優位',10000),('少数・高勝率',10000),('安定（幅が広い）',10000)]:
    rows=[]
    for inst in ['fut','cfd']:
        x=T[inst];x=x[x['群'].str.contains(g,regex=False)].copy()
        sc=np.minimum(x['前半平均'],x['後半平均']) if g in ('両方で優位','少数・高勝率','安定（幅が広い）') else (x['後半平均'] if g=='後半で優位' else x['前半平均'])
        x=x.assign(sc=sc).sort_values('sc',ascending=False).head(cap//2)
        for r in x.itertuples():
            rows.append([r.群,IN[inst],PER[r.per],r.line,r.kind,f'{r.tf}分',r.b,DR[r.dir],r.決済,r.feat_name,r.val_name,r.前半件数,r.前半平均,r.前半勝率,r.前半PF,r.前半プラス年,r.後半件数,r.後半平均,r.後半勝率,r.後半PF,r.後半プラス年,r.前半そろえた平均,r.後半そろえた平均,r.周りの設定のプラス割合,r.tot,r.でたらめ同じ設定の1回平均])
    sheet(g,COLS,rows,FM,[14,6,8,6,6,6,7,5,26,16,14,7,8,7,6,7,7,8,7,6,7,9,9,9,10,10],f'各商品で点数の上位{cap//2:,}本まで（全数は「候補群の数」）。平均は1回あたりの pt（実コスト後）。でたらめ同じ設定＝でたらめな線6種で、同じ入り方・決済・条件の1回平均の平均。')
# ---------- 印の全体傾向
M=pd.read_pickle('marks_eff.pkl')
p=M.pivot_table(index=['inst','dir','feat_name','val_name'],columns=['half','fam2'],values=['n','avg','eff']).reset_index()
rows=[]
for _,r in p.iterrows():
    if r[('feat_name','','')] in ('曜日×時間',): continue
    rows.append([IN[r[('inst','','')]],DR[r[('dir','','')]],r[('feat_name','','')],r[('val_name','','')],
                 r[('n','前半','本物')],r[('avg','前半','本物')],r[('eff','前半','本物')],r[('eff','前半','でたらめ')],
                 r[('n','後半','本物')],r[('avg','後半','本物')],r[('eff','後半','本物')],r[('eff','後半','でたらめ')]])
sheet('印と条件の全体傾向',['商品','向き','条件の粒度','条件','前半 件数','前半 1回平均','前半 差（全体比）','前半 でたらめの差','後半 件数','後半 1回平均','後半 差（全体比）','後半 でたらめの差'],rows,{4:NUM,5:P1,6:P1,7:P1,8:NUM,9:P1,10:P1,11:P1},[6,5,22,16,9,9,9,9,9,9,9,9],'決済は代表の1つ（利確＝次の線、損切り＝線の0.25D先、期間の終わり）。全部の入り方をまとめた1回平均（pt・実コスト後）。差＝その条件の1回平均−全体の1回平均。でたらめの差も同じ向きなら、線ではなく相場のくせ。')
rows=[]
for _,r in p.iterrows():
    if r[('feat_name','','')]!='曜日×時間': continue
    rows.append([IN[r[('inst','','')]],DR[r[('dir','','')]],r[('val_name','','')],r[('n','前半','本物')],r[('avg','前半','本物')],r[('eff','前半','でたらめ')],r[('n','後半','本物')],r[('avg','後半','本物')],r[('eff','後半','でたらめ')]])
sheet('曜日×時間（決済固定）',['商品','向き','曜日×時間','前半 件数','前半 1回平均','前半 でたらめの差','後半 件数','後半 1回平均','後半 でたらめの差'],rows,{3:NUM,4:P1,5:P1,6:NUM,7:P1,8:P1},[6,5,10,9,9,10,9,9,10])
# ---------- 形としての強さ
rows=[]
for inst in ['fut','cfd']:
    for lv,fn in [('形','famrank_'),('形×線','famrank2_')]:
        W=pd.read_pickle(f'{fn}{inst}.pkl').reset_index()
        for _,r in W.iterrows():
            rows.append([IN[inst],lv,PER[r.per],r.get('line','（全部）') if 'line' in W.columns else '（全部）',r.kind,DR[r.dir],r.n,r.avg,r.avgn,r.plusyrs,r.r_mean,r.r_sd,r.r_max,r['rank'],r.z])
sheet('形としての強さ',['商品','まとめ方','期間','線','入り方','向き','トレード数（全設定）','1回平均 pt','そろえた1回平均','そろえてプラスの年（8年中）','でたらめ15種の平均','でたらめのばらつき','でたらめの最大','でたらめより上の割合','z'],rows,{6:NUM,7:P1,8:P1,10:P1,11:P1,12:P1,13:PC,14:P2},[6,7,8,7,6,5,10,8,9,9,9,9,9,9,6],'2019〜2026年。その形の全部の設定（判定足・近さ・決済48通り）を平均した成績。選ばないので当てはめが入らない。z＝（本物−でたらめの平均）÷でたらめのばらつき。72通りの中では z=2.5 前後が偶然でも1つは出る。')
# ---------- 本当の前向き
R=pd.read_pickle('nest_all.pkl')
s=R.groupby(['inst','grp','fam']).agg(top5=('top5','sum'),top5n=('top5n','sum'),n=('top5_n','sum'),q=('avgn_t','mean'),rho=('rho','mean')).reset_index()
rows=[]
for (inst,g),x in s.groupby(['inst','grp']):
    w=x[x.fam=='W'].iloc[0];r=x[x.fam!='W']
    rows.append([IN[inst],g,w.n,w.top5,w.top5n,r.top5n.median(),r.top5n.min(),r.top5n.max(),(r.top5n<w.top5n).mean(),w.q,r.q.median(),w.rho,r.rho.median()])
sheet('本当の前向き',['商品','群','本物 トレード数','本物 上位5本 実コスト','本物 上位5本 そろえた','でたらめ6種 中央','でたらめ 最小','でたらめ 最大','本物が上回る割合','本物 群の質（そろえた1回平均）','でたらめ 群の質 中央','本物 翌年への持続（順位相関）','でたらめ 持続 中央'],rows,{2:NUM,3:NUM,4:NUM,5:NUM,6:NUM,7:NUM,8:PC,9:P1,10:P1,11:P2,12:P2},[6,14,8,10,10,10,10,10,9,10,10,10,10],'2019〜2026年の合計。群の質＝その年の、群の候補全部の1回平均（各年の平均）。持続＝選ぶ期間の点数と、その年の1回平均の順位相関（各年の平均）。')
rows=[]
for (inst,g,fam),x in R.groupby(['inst','grp','fam']):
    rows.append([IN[inst],g,'本物' if fam=='W' else fam]+[x.set_index('t').top5n.get(t,np.nan) for t in range(2019,2027)]+[x.top5n.sum()])
sheet('前向き 年ごと',['商品','群','線']+[str(t) for t in range(2019,2027)]+['合計'],rows,{i:NUM for i in range(3,12)},[6,14,8]+[9]*9,'上位5本の口座、そろえた損益。')
N=pd.concat([pd.read_pickle('nest_tr_fut.pkl'),pd.read_pickle('nest_tr_cfd.pkl')]);N=N[N.fam=='W']
DF=pd.read_csv('defs.csv',index_col=0);import g_sig as G
EXN=[f"{G.TPS[a]}|{G.SLS[s]}|{G.TIMES[t]}" for a,s,t in G.EXITS]
g=N.groupby(['inst','grp','t','def','exit','feat','val']).agg(n=('nrm','size'),nrm=('nrm','sum')).reset_index().merge(DF,left_on='def',right_index=True)
rows=[[IN[r.inst],r.grp,str(r.t),PER[r.per],r.line,r.kind,f'{r.tf}分',r.b,DR[r.dir],EXN[r.exit],r.feat,r.val,r.n,r.nrm] for r in g.itertuples()]
sheet('前向きで選ばれた設定',['商品','群','年','期間','線','入り方','判定足','近さ','向き','決済','条件の粒度','条件','その年の件数','その年の損益（そろえた）'],rows,{12:'0',13:NUM},[6,14,6,8,6,6,6,6,5,26,16,14,8,10])
# ---------- 口座・コスト
SS=G5['S'];rows=[[r.対象,r.n,r.合計,r.最大DD,r.PF,r.RF,r.上位10日,r.上位10日の割合] for r in SS.itertuples()]
sheet('口座の成績',['対象','売買した日数','合計（そろえた）','最大DD','PF','合計÷最大DD','上位10日の合計','上位10日の割合'],rows,{1:NUM,2:NUM,3:NUM,4:P2,5:P2,6:NUM,7:PC},[34,9,11,10,7,9,11,9],'2019〜2026年、日ごとの合計で計算。上位10日の割合が100%を超えるものは、上位の日を除くとマイナス。')
SE=G5['SE'];p=SE.pivot_table(index='対象',columns='コスト',values='合計').reset_index()
rows=[[r['対象']]+[r[k] for k in p.columns[1:]] for _,r in p.iterrows()]
sheet('コストの感度',['対象']+[f'コスト{k}' for k in p.columns[1:]],rows,{i:NUM for i in range(1,len(p.columns))},[34]+[10]*(len(p.columns)-1),'そろえた損益で、往復コストを変えた合計（2019〜2026）。CFD の金利調整額は前向きの数字に入っている（コストの列とは別）。')
# ---------- 前の候補
rows=[]
for (inst,fam,dl),x in C.groupby(['inst','fam','delay']):
    yy=x.groupby('yr').nrm.sum()
    rows.append([IN[inst],'本物' if fam=='W' else 'でたらめ '+fam,'次の足の始値' if dl else '判定足の終わり値',len(x),x.net.sum(),x.nrm.sum(),x.net.mean()]+[yy.get(y,0) for y in range(2017,2027)])
O1=pd.read_pickle('cand_1m.pkl')
for inst,x in O1.groupby('inst'):
    rows.append([IN[inst],'本物（1分足で判定）',f'{x.t.min():%Y/%m}以降',len(x),None,None,x.pt1.mean()-{'fut':5,'cfd':7}[inst]]+[None]*10)
    rows.append([IN[inst],'本物（5分足、同じ期間）',f'{x.t.min():%Y/%m}以降',len(x),None,None,x.pt5.mean()-{'fut':5,'cfd':7}[inst]]+[None]*10)
sheet('前の候補の確認',['商品','線','入る値段','件数','合計 実コスト','合計 そろえた','1回平均 実コスト']+[str(y) for y in range(2017,2027)],rows,{3:NUM,4:NUM,5:NUM,6:P1,**{i:NUM for i in range(7,17)}},[6,18,16,7,10,10,9]+[8]*10,'日の γ・α・Ω の上抜け買い（60分確定、1日1回、週の分水嶺の上だけ）、利確＝次の線、損切り＝抜けた線の0.25D下、日の終わり。年の列はそろえた損益。')
# ---------- 重なり
P=pd.read_pickle('ovl.pkl');cols=P.columns.tolist();rows=[]
for a in cols:
    for b in cols:
        if a<b:
            m=P[a].notna()&P[b].notna()
            rows.append([a,b,int(P[a].notna().sum()),int(P[b].notna().sum()),int(m.sum()),P.loc[m,[a,b]].corr().iloc[0,1] if m.sum()>5 else None])
ws=sheet('窓埋め・寄り天との重なり',['A','B','Aの日数','Bの日数','重なる日','重なる日の相関'],rows,{2:NUM,3:NUM,4:NUM,5:P2},[30,30,8,8,8,10])
r0=len(rows)+4
OVt=G5['OV']
ws.cell(r0,1,'組み合わせの成績（2019〜2026、そろえた損益、日ごとの合計）').font=Font(name=F,bold=True)
hd=['組み合わせ','日数','合計','最大DD','PF','合計÷最大DD','上位10日','上位10日の割合']
for j,h in enumerate(hd,1):
    c=ws.cell(r0+1,j,h);c.font=HF;c.fill=HP
for i,r in enumerate(OVt.itertuples(),r0+2):
    for j,v in enumerate([r.組み合わせ,r.n,r.合計,r.最大DD,r.PF,r.RF,r.上位10日,r.上位10日の割合],1):
        c=ws.cell(i,j,float(v) if isinstance(v,(np.floating,)) else v)
        c.number_format=[None,NUM,NUM,NUM,P2,P2,NUM,PC][j-1] or 'General'
YR=G5['YR'];r1=r0+3+len(OVt)
ws.cell(r1,1,'年ごと').font=Font(name=F,bold=True)
for j,h in enumerate(['年']+YR.columns.tolist(),1):
    c=ws.cell(r1+1,j,h);c.font=HF;c.fill=HP
for i,(y,r) in enumerate(YR.iterrows(),r1+2):
    ws.cell(i,1,str(y))
    for j,v in enumerate(r.values,2): ws.cell(i,j,float(v)).number_format=NUM
wb.save('分水嶺_網羅的検証_2026-10-22.xlsx')
print('saved')
