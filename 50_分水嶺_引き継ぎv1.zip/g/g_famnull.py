"""形としての強さの偶然の目安を増やす：でたらめな線 r3〜r14 で、条件なし（全体）の年ごとの合計だけを作る。"""
import sys, os, numpy as np, pandas as pd
sys.path.insert(0,'/home/claude/bs/g')
import g_sig, g_agg
inst=sys.argv[1]; seeds=range(int(sys.argv[2]),int(sys.argv[3]))
X=dict(np.load(f'/home/claude/bs/g/data_{inst}.npz'));DF=pd.read_csv('/home/claude/bs/g/defs.csv',index_col=0)
rows=[]
for s in seeds:
    fam=f'r{s}';g_sig.run(inst,[fam]);f=f'/home/claude/bs/g/sig_{inst}_{fam}.npz';S=np.load(f)
    yi=X['yr'][S['i']]-2017;net=S['R']-g_agg.COST[inst];nrm=S['R']*(g_agg.REF/S['e'])[:,None]-g_agg.COST[inst]
    if inst=='cfd':
        fin=S['nt'].astype(float)*0.03/365;net=net-fin*S['e'][:,None];nrm=nrm-fin*g_agg.REF
    key=S['d'].astype(np.int64)*10+yi;K=432*10
    for col in range(48):
        v=~np.isnan(net[:,col])
        cnt=np.bincount(key[v],minlength=K).reshape(432,10);sn=np.bincount(key[v],net[v,col],K).reshape(432,10);sr=np.bincount(key[v],nrm[v,col],K).reshape(432,10)
        for di in range(432): rows.append((inst,fam,di,col,*cnt[di],*sn[di],*sr[di]))
    os.remove(f);print(inst,fam,flush=True)
cols=['inst','fam','def','exit']+[f'{a}{y}' for a in ['n','net','nrm'] for y in range(2017,2027)]
pd.DataFrame(rows,columns=cols).to_pickle(f'/home/claude/bs/g/famnull_{inst}_{seeds.start}.pkl')
