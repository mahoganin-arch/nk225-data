"""G3/G4：候補群（両方で優位・後半で優位・前半で優位・少数高勝率・安定）を作る。
screen(A, years) は、与えた年だけで2つの半期に分けて判定する（本当の前向きでも同じ関数を使う）。
"""
import numpy as np, pandas as pd, itertools
import g_sig as G

YEARS = list(range(2017, 2027))
# 事前に決めた基準（pt、実コスト後）
TH = dict(n_half=20, mean=5.0, pf=1.2, act=0.8, few_n=10, few_win=0.65, stab=0.7)

def half_stats(A, ys, tag):
    n = A[[f'n{y}' for y in ys]].sum(1)
    net = A[[f'net{y}' for y in ys]].sum(1); nrm = A[[f'nrm{y}' for y in ys]].sum(1)
    pos = A[[f'pos{y}' for y in ys]].sum(1); neg = A[[f'neg{y}' for y in ys]].sum(1)
    win = A[[f'win{y}' for y in ys]].sum(1)
    act = (A[[f'n{y}' for y in ys]].values >= 3).sum(1)
    plus = ((A[[f'net{y}' for y in ys]].values > 0) & (A[[f'n{y}' for y in ys]].values >= 3)).sum(1)
    out = pd.DataFrame({f'{tag}件数': n, f'{tag}合計': net, f'{tag}平均': net / n.clip(lower=1), f'{tag}PF': pos / neg.replace(0, np.nan),
                        f'{tag}勝率': win / n.clip(lower=1), f'{tag}そろえた平均': nrm / n.clip(lower=1),
                        f'{tag}稼働年': act, f'{tag}プラス年': plus}, index=A.index)
    return out

def screen(A, ys):
    ys = [y for y in ys if y in YEARS]
    k = len(ys); h1 = ys[:(k + 1) // 2]; h2 = ys[(k + 1) // 2:]
    S1 = half_stats(A, h1, '前半'); S2 = half_stats(A, h2, '後半')
    S = pd.concat([S1, S2], axis=1)
    t = TH
    def good(tag, hs):
        return (S[f'{tag}件数'] >= t['n_half']) & (S[f'{tag}平均'] >= t['mean']) & (S[f'{tag}PF'] >= t['pf']) & (S[f'{tag}稼働年'] >= np.ceil(t['act'] * len(hs)))
    g1 = good('前半', h1); g2 = good('後半', h2)
    grp = {}
    grp['両方で優位'] = g1 & g2
    grp['後半で優位'] = g2 & ~g1
    grp['前半で優位'] = g1 & ~g2
    grp['少数・高勝率'] = (S['前半件数'] >= t['few_n']) & (S['後半件数'] >= t['few_n']) & (S['前半勝率'] >= t['few_win']) & (S['後半勝率'] >= t['few_win']) & (S['前半平均'] >= t['mean']) & (S['後半平均'] >= t['mean'])
    # 安定：同じ入り方・条件で、決済を1つだけ変えた周りの設定の 70% 以上が両方の半期でプラス
    pos2 = (S['前半平均'] > 0) & (S['後半平均'] > 0) & (S['前半件数'] >= t['n_half']) & (S['後半件数'] >= t['n_half'])
    ex = np.array(G.EXITS)
    key = A['def'].astype(np.int64) * 1000000 + A['feat'].astype(np.int64) * 10000 + A['val'].astype(np.int64)
    P = pd.Series(pos2.values, index=pd.MultiIndex.from_arrays([key.values, A['exit'].values]))
    P = P[~P.index.duplicated()]
    frac = np.zeros(len(A)); cnt = np.zeros(len(A))
    for dim, size in [(0, 4), (1, 3), (2, 4)]:
        for delta in range(1, size):
            nb = ex.copy(); nb[:, dim] = (nb[:, dim] + delta) % size
            nb_col = np.array([G.EXITS.index(tuple(r)) for r in nb])
            q = pd.MultiIndex.from_arrays([key.values, nb_col[A['exit'].values]])
            v = P.reindex(q).values
            frac += np.nan_to_num(v.astype(float)); cnt += 1
    S['周りの設定のプラス割合'] = frac / cnt
    grp['安定（幅が広い）'] = pos2 & (S['周りの設定のプラス割合'] >= t['stab'])
    S['群'] = ''
    for g, m in grp.items():
        cur = S.loc[m, '群']
        S.loc[m, '群'] = np.where(cur == '', g, cur + '／' + g)
    return S, grp, (h1, h2)
