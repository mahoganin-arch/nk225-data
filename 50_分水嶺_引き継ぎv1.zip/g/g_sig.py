"""G2：全格子の売買を作る。
入り方 432通り（期間3 × 線4 × [抜け6・反発9・指値タッチ3] × 向き2）、決済48通り（利確4 × 損切り3 × 時間4）。
1つの入り方につき、その期間で最初の合図だけを使う。各合図について48通りの決済の損益（pt、コスト前）を計算する。
出力：/home/claude/bs/g/sig_{inst}_{fam}.npz（合図ごとの情報と損益）、defs.csv（入り方の一覧）
"""
import sys, numpy as np, pandas as pd, itertools
from numba import njit
sys.path.insert(0, '/home/claude/bs')
import eng2, eng3

PERS = ['wk', 'day', 'ses']
LNAMES = ['Ω', 'γ', '分水嶺', 'α']
KINDS = [('抜け', tf, b) for tf in (15, 30, 60) for b in (0.0, 0.1)] + \
        [('反発', tf, b) for tf in (15, 30, 60) for b in (0.0, 0.1, 0.2)] + \
        [('指値', 5, b) for b in (0.0, 0.1, 0.2)]
TPS = ['次の線', '0.5D', '1D', '無し']
SLS = ['線の0.25D先', '線の0.5D先', '無し']
TIMES = ['60分', '240分', 'セッション終わり', '期間の終わり']
EXITS = list(itertools.product(range(4), range(3), range(4)))

def defs():
    rows = []
    for p, li, (k, tf, b), dr in itertools.product(range(3), range(4), KINDS, (1, -1)):
        rows.append(dict(per=PERS[p], line=LNAMES[li], kind=k, tf=tf, b=b, dir=dr))
    return pd.DataFrame(rows)

@njit(cache=True)
def gen(o, h, l, c, pid, okp, chk, th, tl, Lv, Dv, kind, b, dr, pend):
    n = len(o)
    out_i = np.empty(n, np.int64); out_e = np.empty(n); k = 0
    pc = np.nan; lastp = -1
    for i in range(n):
        L = Lv[i]; D = Dv[i]; p = pid[i]
        if kind == 2:  # 指値タッチ（5分足）
            if i > 0 and p != lastp and okp[p] and not np.isnan(L) and D > 0 and not pend[i]:
                lim = L + b * D if dr == 1 else L - b * D
                pcl = c[i - 1]
                if dr == 1 and pcl > lim and l[i] <= lim:
                    out_i[k] = i; out_e[k] = min(o[i], lim); k += 1; lastp = p
                elif dr == -1 and pcl < lim and h[i] >= lim:
                    out_i[k] = i; out_e[k] = max(o[i], lim); k += 1; lastp = p
            continue
        if not chk[i]:
            continue
        if p != lastp and okp[p] and not np.isnan(L) and D > 0 and not np.isnan(pc) and not pend[i]:
            hit = False
            if kind == 0:  # 抜け：直前の判定足の終値が線の手前、今の終値が線の先（b×D 以上）
                if dr == 1:
                    hit = pc < L and c[i] >= L + b * D
                else:
                    hit = pc > L and c[i] <= L - b * D
            else:  # 反発：判定足の中で線から b×D 以内まで来て、終値は線の手前で止まる
                if dr == 1:
                    hit = pc > L + b * D and tl[i] <= L + b * D and c[i] > L
                else:
                    hit = pc < L - b * D and th[i] >= L - b * D and c[i] < L
            if hit:
                out_i[k] = i; out_e[k] = c[i]; k += 1; lastp = p
        pc = c[i]
    return out_i[:k], out_e[:k]

@njit(cache=True)
def evalx(o, h, l, c, si, se, dr, Lr, D, tpn, endP, endS):
    m = len(si); R = np.full((m, 48), np.nan, np.float32); XI = np.zeros((m, 48), np.int32)
    for q in range(m):
        i = si[q]; e = se[q]; d = dr; jP = endP[i]; jS = min(endS[i], jP)
        tp = np.empty(3); tp[0] = tpn[q]; tp[1] = e + d * 0.5 * D[q]; tp[2] = e + d * 1.0 * D[q]
        sl = np.empty(2); sl[0] = Lr[q] - d * 0.25 * D[q]; sl[1] = Lr[q] - d * 0.5 * D[q]
        tpi = np.full(3, -1, np.int64); tpx = np.zeros(3); sli = np.full(2, -1, np.int64); slx = np.zeros(2)
        for j in range(i + 1, jP + 1):
            for a in range(3):
                if tpi[a] < 0 and not np.isnan(tp[a]):
                    if (d == 1 and h[j] >= tp[a]) or (d == -1 and l[j] <= tp[a]):
                        tpi[a] = j; tpx[a] = max(o[j], tp[a]) if d == 1 else min(o[j], tp[a])
            for a in range(2):
                if sli[a] < 0:
                    if (d == 1 and l[j] <= sl[a]) or (d == -1 and h[j] >= sl[a]):
                        sli[a] = j; slx[a] = min(o[j], sl[a]) if d == 1 else max(o[j], sl[a])
        tend = np.empty(4, np.int64)
        tend[0] = min(i + 12, jP); tend[1] = min(i + 48, jP); tend[2] = jS; tend[3] = jP
        col = 0
        for a in range(4):
            for s in range(3):
                for t in range(4):
                    te = tend[t]; x = c[te]; xi = te
                    if s < 2 and sli[s] >= 0 and sli[s] <= xi:
                        xi = sli[s]; x = slx[s]
                    if a < 3 and tpi[a] >= 0 and tpi[a] < xi:  # 同じ足なら損切りを先に
                        xi = tpi[a]; x = tpx[a]
                    R[q, col] = d * (x - e); XI[q, col] = xi
                    col += 1
    return R, XI

def tf_hl(X, tf):
    n = len(X['o'])
    if tf == 5:
        return X['h'], X['l']
    chk = X[f'tf{tf}']
    grp = np.cumsum(np.r_[True, chk[:-1]])
    th = pd.Series(X['h']).groupby(grp).cummax().values
    tl = pd.Series(X['l']).groupby(grp).cummin().values
    return th, tl

def run(inst, fams):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz'))
    B = eng2.base(inst)
    DF = defs(); DF.to_csv('/home/claude/bs/g/defs.csv', index_label='def')
    o, h, l, c = X['o'], X['h'], X['l'], X['c']
    THL = {tf: tf_hl(X, tf) for tf in (5, 15, 30, 60)}
    endidx = {}
    for key in PERS + ['ses']:
        e = np.nonzero(X['end_' + key])[0]
        endidx[key] = e[np.searchsorted(e, np.arange(len(o)))]
    for fam in fams:
        LN = {}
        for j, key in enumerate(PERS):
            P, ok = B[key]
            Lp = eng3.per_lines(P, ok, fam, inst, j)
            pid = X['pid_' + key]
            okp = np.asarray(ok, bool).copy()
            sm = (P.n < 0.2 * P.n.median()).values; okp &= ~sm; okp[1:] &= ~sm[:-1]
            LN[key] = dict(M=np.c_[Lp.ome.values, Lp.gam.values, Lp.W.values, Lp.alp.values][pid], D=Lp.D.values[pid], okp=okp)
        S_def = []; S_i = []; S_e = []; S_R = []; S_tp = []; S_nt = []
        for di, r in DF.iterrows():
            key = r.per; li = LNAMES.index(r.line); kind = {'抜け': 0, '反発': 1, '指値': 2}[r.kind]
            L4 = LN[key]['M']; Lv = L4[:, li]; Dv = LN[key]['D']
            th, tl = THL[r.tf]; chk = X[f'tf{r.tf}']
            si, se = gen(o, h, l, c, X['pid_' + key], LN[key]['okp'], chk, th, tl, Lv, Dv, kind, float(r.b), int(r.dir), X['end_' + key])
            if len(si) == 0:
                continue
            D = Dv[si]; Lr = Lv[si]; dr = int(r.dir)
            M = L4[si]
            beyond = (M - se[:, None]) * dr > 0.1 * D[:, None]
            cand = np.where(beyond, np.abs(M - se[:, None]), np.inf).min(1)
            tpn = np.where(np.isfinite(cand), se + dr * cand, np.nan)
            R, XI = evalx(o, h, l, c, si, se, dr, Lr, D, tpn, endidx[key], endidx['ses'])
            # 日をまたいだ回数（CFD の金利調整額は日本時間7時に保有していると発生。日の区切りと同じ）
            nts = (X['pid_day'][XI] - X['pid_day'][si][:, None]).astype(np.int8)
            S_def.append(np.full(len(si), di, np.int32)); S_i.append(si); S_e.append(se); S_R.append(R); S_tp.append(tpn); S_nt.append(nts)
        np.savez(f'/home/claude/bs/g/sig_{inst}_{fam}.npz', d=np.concatenate(S_def), i=np.concatenate(S_i), e=np.concatenate(S_e),
                 R=np.concatenate(S_R), tpn=np.concatenate(S_tp), nt=np.concatenate(S_nt))
        print(inst, fam, sum(len(x) for x in S_i), flush=True)

if __name__ == '__main__':
    run(sys.argv[1], sys.argv[2].split(','))
