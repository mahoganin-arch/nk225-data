"""形としての強さ（条件なし・選ばない）：入り方を形でまとめ、全部の設定（判定足・近さ・決済）を平均した年ごとの成績。
本物とでたらめ3種を並べる。選ばないので当てはめが入らない（窓埋めの『条件なしの順張り D>N が中心』と同じ見方）。
"""
import numpy as np, pandas as pd
YEARS = list(range(2017, 2027))

def run():
    DF = pd.read_csv('/home/claude/bs/g/defs.csv', index_col=0)
    out = []
    for inst in ['fut', 'cfd']:
        for fam in ['W', 'r0', 'r1', 'r2']:
            A = pd.read_parquet(f'/home/claude/bs/g/agg_{inst}_{fam}.parquet', filters=[('feat', '=', 0)])
            A = A.merge(DF, left_on='def', right_index=True)
            for lvl, keys in [('形', ['per', 'kind', 'dir']), ('形×線', ['per', 'line', 'kind', 'dir'])]:
                g = A.groupby(keys)
                for k, x in g:
                    row = dict(inst=inst, fam=fam, lvl=lvl, **dict(zip(keys, k)), nconf=len(x))
                    for y in YEARS:
                        row[f'n{y}'] = x[f'n{y}'].sum(); row[f'net{y}'] = x[f'net{y}'].sum(); row[f'nrm{y}'] = x[f'nrm{y}'].sum()
                    out.append(row)
    O = pd.DataFrame(out)
    O.to_pickle('/home/claude/bs/g/fam.pkl')
    return O

if __name__ == '__main__':
    O = run()
    pd.set_option('display.width', 250)
    f = O[O.lvl == '形'].copy()
    ys = range(2019, 2027)
    f['avg19_26'] = f[[f'net{y}' for y in ys]].sum(1) / f[[f'n{y}' for y in ys]].sum(1)
    f['avgn19_26'] = f[[f'nrm{y}' for y in ys]].sum(1) / f[[f'n{y}' for y in ys]].sum(1)
    f['plusyrs'] = sum((f[f'net{y}'] > 0).astype(int) for y in ys)
    f['plusyrs_n'] = sum((f[f'nrm{y}'] > 0).astype(int) for y in ys)
    p = f.pivot_table(index=['inst', 'per', 'kind', 'dir'], columns='fam', values=['avg19_26', 'avgn19_26', 'plusyrs_n'])
    print(p.round(1).to_string())
