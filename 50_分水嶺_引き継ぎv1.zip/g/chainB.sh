cd /home/claude/bs/g
python3 -W ignore g_sig.py fut r20,r21,r22 && python3 -W ignore g_agg.py fut r20,r21,r22 && python3 -W ignore g_nest.py fut r20,r21,r22 _x && python3 -W ignore g_famnull.py cfd 3 15 && echo CHAIN_B_DONE
