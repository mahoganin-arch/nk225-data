"""G4：本当の前向き。各年 t（2019〜2026）について、t より前の年だけで候補群を作り、t 年の成績を見る。
本物の線とでたらめな線（r0〜r2）に同じ手順を通す。
- 群の質：t 年の、候補全部の1回平均（トレード数で重み）、プラスだった候補の割合
- 翌年への持続：選ぶ期間の成績（半期の小さい方の平均）と t 年の1回平均の順位相関
- 上位5本の口座：群ごとに点数の上位5本（同じ入り方は1本まで）を t 年に売買。同じ足・同じ向きは1本、1日2本まで
出力：nest_{inst}.pkl（年ごとの結果）、nest_tr_{inst}.pkl（上位5本の口座のトレード）
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs'); sys.path.insert(0, '/home/claude/bs/g')
import eng2
import g_agg, g_scr

SCORE = {'両方で優位': ('min', None), '安定（幅が広い）': ('min', None), '少数・高勝率': ('min', None), '後半で優位': ('h', '後半平均'), '前半で優位': ('h', '前半平均')}

def run(inst, fams, tag=''):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); DF = pd.read_csv('/home/claude/bs/g/defs.csv', index_col=0); B = eng2.base(inst)
    cost = g_agg.COST[inst]
    res = []; trs = []
    for fam in fams:
        A = pd.read_parquet(f'/home/claude/bs/g/agg_{inst}_{fam}.parquet')
        S_ = dict(np.load(f'/home/claude/bs/g/sig_{inst}_{fam}.npz'))
        F = g_agg.features(inst, fam, X, S_, DF, B); fn = list(F.keys())
        codes = np.stack([F[k][0] for k in fn], 1)
        yr = X['yr'][S_['i']]; dayid = X['pid_day'][S_['i']]
        for t in range(2019, 2027):
            S, grp, (h1, h2) = g_scr.screen(A, list(range(2017, t)))
            nt = A[f'n{t}']; nett = A[f'net{t}']; nrmt = A[f'nrm{t}']
            for g, m in grp.items():
                m = m.values
                if m.sum() == 0:
                    res.append(dict(inst=inst, fam=fam, t=t, grp=g, ncand=0)); continue
                sel = m & (nt.values > 0)
                avg_t = nett.values[sel].sum() / max(nt.values[sel].sum(), 1)
                avgn_t = nrmt.values[sel].sum() / max(nt.values[sel].sum(), 1)
                pos_t = (nett.values[sel] > 0).mean() if sel.any() else np.nan
                kind, col = SCORE[g]
                sc = np.minimum(S['前半平均'].values, S['後半平均'].values) if kind == 'min' else S[col].values
                sel5 = m & (nt.values >= 5)
                rho = pd.Series(sc[sel5]).rank().corr(pd.Series(nett.values[sel5] / nt.values[sel5]).rank()) if sel5.sum() > 10 else np.nan
                # 上位5本（同じ入り方は1本まで）
                idx = np.nonzero(m)[0]; idx = idx[np.argsort(-sc[idx], kind='stable')]
                pick = []; used = set()
                for q in idx:
                    d = int(A['def'].values[q])
                    if d in used: continue
                    used.add(d); pick.append(q)
                    if len(pick) == 5: break
                T = []
                for rank, q in enumerate(pick):
                    d = int(A['def'].values[q]); ex = int(A['exit'].values[q]); f = int(A['feat'].values[q]); v = int(A['val'].values[q])
                    mm = (S_['d'] == d) & (codes[:, f] == v) & (yr == t)
                    if not mm.any(): continue
                    T.append(pd.DataFrame({'rank': rank, 'def': d, 'exit': ex, 'feat': fn[f], 'val': F[fn[f]][1][v], 'i': S_['i'][mm], 'dir': DF['dir'].values[d],
                                           'e': S_['e'][mm], 'pt': S_['R'][mm, ex], 'day': dayid[mm]}))
                if T:
                    T = pd.concat(T).sort_values(['i', 'rank']).drop_duplicates(['i', 'dir'])
                    T = T[T.groupby('day').cumcount() < 2]
                    T['net'] = T.pt - cost; T['nrm'] = T.pt * g_agg.REF / T.e - cost
                    T = T.assign(inst=inst, fam=fam, t=t, grp=g); trs.append(T)
                    acc = T.net.sum(); accn = T.nrm.sum(); acc_n = len(T)
                else:
                    acc = accn = 0.0; acc_n = 0
                res.append(dict(inst=inst, fam=fam, t=t, grp=g, ncand=int(m.sum()), avg_t=avg_t, avgn_t=avgn_t, pos_t=pos_t, rho=rho,
                                top5=acc, top5n=accn, top5_n=acc_n))
            print(inst, fam, t, flush=True)
        pd.DataFrame(res).to_pickle(f'/home/claude/bs/g/nest_{inst}{tag}.pkl')
        if trs: pd.concat(trs).to_pickle(f'/home/claude/bs/g/nest_tr_{inst}{tag}.pkl')

if __name__ == '__main__':
    run(sys.argv[1], sys.argv[2].split(','), sys.argv[3] if len(sys.argv) > 3 else '')
