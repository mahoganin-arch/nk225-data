"""前の候補（日の γ・α・Ω の上抜け買い、60分確定、利確＝次の線、損切り＝線の0.25D先、日の終わり、週の分水嶺の上だけ）を、
全格子の中から取り出して確かめる。
- 3本の線のどれかで、その日の最初の合図だけ（1日1回）
- 入りの遅れ（次の5分足の始値で入る）
- でたらめな線（r0〜r2）での同じ設定
出力：cand_{inst}.pkl（トレード）
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs'); sys.path.insert(0, '/home/claude/bs/g')
import eng2, eng3, g_sig as G, g_agg

EX = G.EXITS.index((0, 0, 3))

def trades(inst, fam, delay=False):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); DF = pd.read_csv('/home/claude/bs/g/defs.csv', index_col=0)
    S = dict(np.load(f'/home/claude/bs/g/sig_{inst}_{fam}.npz'))
    sel = DF[(DF.per == 'day') & (DF.kind == '抜け') & (DF.tf == 60) & (DF.b == 0) & (DF.dir == 1) & DF.line.isin(['Ω', 'γ', 'α'])].index
    m = np.isin(S['d'], sel)
    B = eng2.base(inst); P, ok = B['wk']; Lw = eng3.per_lines(P, ok, fam, inst, 0); Ww = Lw.W.values[X['pid_wk']]
    i = S['i'][m]; e = S['e'][m]; pt = S['R'][m, EX]; d = S['d'][m]; tpn = S['tpn'][m]
    T = pd.DataFrame({'i': i, 'e': e, 'pt': pt, 'def': d, 'tpn': tpn})
    T = T[(T.e > Ww[T.i.values])]
    T['day'] = X['pid_day'][T.i.values]
    T = T.sort_values('i').drop_duplicates('day')
    if delay:
        o, h, l, c = X['o'], X['h'], X['l'], X['c']
        P2, ok2 = B['day']; Ld = eng3.per_lines(P2, ok2, fam, inst, 1); pid = X['pid_day']
        M = np.c_[Ld.ome.values, Ld.gam.values, Ld.W.values, Ld.alp.values][pid]; Dd = Ld.D.values[pid]
        li = DF.loc[T['def'].values, 'line'].map({'Ω': 0, 'γ': 1, '分水嶺': 2, 'α': 3}).values
        si = T.i.values + 1; se = o[si]; D = Dd[T.i.values]; Lr = M[T.i.values, li]
        e_ = np.nonzero(X['end_day'])[0]; endP = e_[np.searchsorted(e_, np.arange(len(o)))]
        e2 = np.nonzero(X['end_ses'])[0]; endS = e2[np.searchsorted(e2, np.arange(len(o)))]
        ok3 = si <= endP[T.i.values]
        R, XI = G.evalx(o, h, l, c, si[ok3], se[ok3], 1, Lr[ok3], D[ok3], T.tpn.values[ok3], endP, endS)
        T = T[ok3].copy(); T['e'] = se[ok3]; T['pt'] = R[:, EX]
    cost = g_agg.COST[inst]
    T['net'] = T.pt - cost; T['nrm'] = T.pt * g_agg.REF / T.e - cost
    T['t'] = pd.to_datetime(X['tm'][T.i.values], unit='s', utc=True).tz_convert('Asia/Tokyo')
    T['yr'] = T.t.dt.year; T['fam'] = fam; T['inst'] = inst; T['delay'] = delay
    return T

if __name__ == '__main__':
    out = []
    for inst in ['fut', 'cfd']:
        for fam in ['W', 'r0', 'r1', 'r2']:
            out.append(trades(inst, fam))
        out.append(trades(inst, 'W', delay=True))
    T = pd.concat(out); T.to_pickle('/home/claude/bs/g/cand.pkl')
    pd.set_option('display.width', 250)
    print(T.groupby(['inst', 'fam', 'delay']).agg(n=('pt', 'size'), net=('net', 'sum'), nrm=('nrm', 'sum'), avg=('net', 'mean')).round(1).to_string())
    print(T[(T.fam == 'W') & ~T.delay].pivot_table(index='inst', columns='yr', values='nrm', aggfunc='sum').round(0).to_string())
