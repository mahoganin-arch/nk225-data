cd /home/claude/bs/g
python3 -W ignore g_sig.py cfd W,r0,r1,r2,r20,r21,r22 && python3 -W ignore g_agg.py cfd W,r0,r1,r2,r20,r21,r22 && python3 -W ignore g_nest.py cfd W,r0,r1,r2,r20,r21,r22 && echo CHAIN_A_DONE
