import pandas as pd,numpy as np,g_ovl,sys
pd.set_option('display.width',250)
DF=pd.read_csv('defs.csv',index_col=0)
def stats(s):
    s=s.sort_index();c=s.cumsum();dd=(c.cummax()-c).max()
    pos=s[s>0].sum();neg=-s[s<0].sum()
    d=s.groupby(level=0).sum() if False else s
    top=s.sort_values(ascending=False).head(10).sum()
    return dict(n=len(s),合計=s.sum(),最大DD=dd,PF=pos/neg if neg>0 else np.nan,RF=s.sum()/dd if dd>0 else np.nan,上位10日=top,上位10日の割合=top/s.sum() if s.sum()>0 else np.nan)
rows=[];sens=[]
# 1) 前の候補
C=pd.read_pickle('cand.pkl');C=C[(C.fam=='W')&(~C.delay)&(C.yr>=2019)]
for inst in ['fut','cfd']:
    c=C[C.inst==inst]
    s=pd.Series(c.nrm.values,index=pd.to_datetime(c.t.dt.date));rows.append(dict(対象=f'前の候補（日の線の上抜け買い）{inst}',**stats(s.groupby(level=0).sum())))
    for k in [0,3,5,7,10,13,20,30]:
        sens.append(dict(対象=f'前の候補 {inst}',コスト=k,合計=(c.pt*68800/c.e-k).sum(),一回平均=(c.pt*68800/c.e-k).mean()))
# 2) 本当の前向き 上位5本（本物）
N=pd.concat([pd.read_pickle('nest_tr_fut.pkl'),pd.read_pickle('nest_tr_cfd.pkl')]);N=N[N.fam=='W']
X={i:np.load(f'data_{i}.npz')['tm'] for i in ['fut','cfd']}
N['date']=[pd.Timestamp(X[i][j],unit='s',tz='UTC').tz_convert('Asia/Tokyo').date() for i,j in zip(N.inst,N.i)]
for (inst,g),x in N.groupby(['inst','grp']):
    s=pd.Series(x.nrm.values,index=pd.to_datetime(x.date)).groupby(level=0).sum()
    rows.append(dict(対象=f'前向き上位5本 {g} {inst}',**stats(s)))
    for k in [0,3,5,7,10,13,20,30]:
        sens.append(dict(対象=f'前向き上位5本 {g} {inst}',コスト=k,合計=(x.pt*68800/x.e-k).sum(),一回平均=(x.pt*68800/x.e-k).mean()))
S=pd.DataFrame(rows);SE=pd.DataFrame(sens)
print(S.round(2).to_string())
# 3) 重なり：窓埋め・寄り天②
c=C[C.inst=='cfd'];our=pd.DataFrame({'date':c.t.dt.date,'pnl':c.nrm.values,'src':'分水嶺（前の候補 CFD）'})
x=N[(N.inst=='cfd')&(N.grp=='両方で優位')];our2=pd.DataFrame({'date':x.date,'pnl':x.nrm.values,'src':'分水嶺（前向き 両方で優位 CFD）'})
P=g_ovl.combine(pd.concat([our,our2]))
P.to_pickle('ovl.pkl')
cols=P.columns.tolist();print(cols)
D=P.fillna(0)
print('相関（両方に売買がある日だけ）')
for a in cols:
    for b in cols:
        if a<b:
            m=P[a].notna()&P[b].notna();print(a,b,'重なる日',m.sum(),'相関',round(P.loc[m,[a,b]].corr().iloc[0,1],2) if m.sum()>5 else None)
ov=[]
for combo in [['窓埋め'],['寄り天②'],['窓埋め','寄り天②'],['分水嶺（前の候補 CFD）'],['窓埋め','寄り天②','分水嶺（前の候補 CFD）'],['分水嶺（前向き 両方で優位 CFD）'],['窓埋め','寄り天②','分水嶺（前向き 両方で優位 CFD）']]:
    s=D[combo].sum(1);s=s[s!=0];ov.append(dict(組み合わせ='＋'.join(combo),**stats(s)))
OV=pd.DataFrame(ov);print(OV.round(2).to_string())
yr=D.groupby(pd.to_datetime(D.index).year).sum();print(yr.round(0).to_string())
pd.to_pickle(dict(S=S,SE=SE,OV=OV,YR=yr),'g5.pkl')
