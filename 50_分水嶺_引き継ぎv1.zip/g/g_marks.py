"""印（SQ・祝日・月末月初）・曜日×時間・地合いの全体傾向。決済は代表の1つ（利確＝次の線、損切り＝線の0.25D先、期間の終わり）に固定。
入り方は、期間×線×入り方の種類×向き でまとめる（判定足・近さは平均）。本物とでたらめ3種の平均を並べる。
"""
import numpy as np, pandas as pd
import g_sig as G

FIX = G.EXITS.index((0, 0, 3))
YEARS = list(range(2017, 2027))

def run():
    DF = pd.read_csv('/home/claude/bs/g/defs.csv', index_col=0)
    FT = pd.read_csv('/home/claude/bs/g/feats.csv')
    out = []
    for inst in ['fut', 'cfd']:
        for fam in ['W', 'r0', 'r1', 'r2']:
            A = pd.read_parquet(f'/home/claude/bs/g/agg_{inst}_{fam}.parquet', filters=[('exit', '=', FIX)])
            A = A[A.exit == FIX]
            A = A.merge(DF[['per', 'line', 'kind', 'dir']], left_on='def', right_index=True)
            for h, ys in [('前半', YEARS[:5]), ('後半', YEARS[5:])]:
                n = A[[f'n{y}' for y in ys]].sum(1); net = A[[f'net{y}' for y in ys]].sum(1); win = A[[f'win{y}' for y in ys]].sum(1)
                B = A[['per', 'line', 'kind', 'dir', 'feat', 'val']].assign(n=n, net=net, win=win)
                g = B.groupby(['per', 'line', 'kind', 'dir', 'feat', 'val'], as_index=False)[['n', 'net', 'win']].sum()
                g['inst'] = inst; g['fam'] = fam; g['half'] = h
                out.append(g)
    O = pd.concat(out)
    O = O.merge(FT, on=['feat', 'val'])
    O.to_pickle('/home/claude/bs/g/marks.pkl')
    print(len(O))

if __name__ == '__main__':
    run()
