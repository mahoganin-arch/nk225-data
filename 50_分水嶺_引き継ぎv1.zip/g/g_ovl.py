"""G5：窓埋め・寄り天との重なり。
- 窓埋め：前の本当の前向き（条件なし、2019〜2026、long_flat.pkl の『全部』）のトレード（損益は今の値段にそろえた円、13円コスト）
- 寄り天：ルール②（8:45→9:05 の先物が +0.3812% 以上なら 9:10 の CFD 始値で売り、損切り0.8%、240分で手じまい）を作り直す
- 分水嶺：本当の前向きの上位5本の口座のトレード（nest_tr_*.pkl）
日ごとの損益で、重なる日・相関・足したときの合計と最大DDを見る。損益はどれも今の値段にそろえた形（分水嶺は nrm）。
"""
import numpy as np, pandas as pd

def window_trades():
    x = pd.read_pickle('/root/prev/42_窓埋め_引き継ぎv4/nest_out/long_flat.pkl')
    H = x['H']['全部'].copy()
    H['t'] = pd.to_datetime(H['入る時刻'] * 60, unit='s', utc=True).dt.tz_convert('Asia/Tokyo')
    H = H.drop_duplicates(['入る時刻', '向き'])
    return pd.DataFrame({'date': H.t.dt.date, 'pnl': H['損益'].values, 'src': '窓埋め'})

def yoriten2():
    f = pd.read_pickle('/home/claude/bs/fut5.pkl'); c = pd.read_pickle('/home/claude/bs/cfd5.pkl')
    f['d'] = f.t.dt.date; f['hm'] = f.t.dt.strftime('%H:%M'); c['d'] = c.t.dt.date; c['hm'] = c.t.dt.strftime('%H:%M')
    fo = f[f.hm == '08:45'].set_index('d').open; fc = f[f.hm == '09:00'].set_index('d').close
    chg = (fc / fo - 1) * 100
    days = chg[chg >= 0.3812].index
    cg = {d: g for d, g in c[c.d.isin(days)].groupby('d')}
    rows = []
    for d in days:
        g = cg.get(d)
        if g is None: continue
        g = g.set_index('hm')
        if '09:10' not in g.index: continue
        e = g.loc['09:10', 'open']; sl = e * 1.008
        seg = g.loc['09:10':'13:05']
        x = seg.close.iloc[-1]
        hit = seg[seg.high >= sl]
        if len(hit): x = max(sl, hit.open.iloc[0])
        pt = e - x
        rows.append(dict(date=d, pnl=pt * 68800 / e - 13, src='寄り天②'))
    return pd.DataFrame(rows)

def dd(s):
    c = s.cumsum(); return float((c.cummax() - c).max())

def combine(our):
    W = window_trades(); Y = yoriten2()
    D = pd.concat([our, W, Y])
    D = D[pd.to_datetime(D.date).dt.year >= 2019]
    P = D.pivot_table(index='date', columns='src', values='pnl', aggfunc='sum').sort_index()
    return P
