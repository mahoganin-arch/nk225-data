"""1分足での確認：前の候補のトレードを、1分足で利確・損切りを判定し直して、5分足の結果と比べる。"""
import sys, numpy as np, pandas as pd
sys.path.insert(0,'/root/ldnew');sys.path.insert(0,'/home/claude/bs');sys.path.insert(0,'/home/claude/bs/g')
import ld, eng2, eng3
FILES={'cfd':'/root/nk225-data/cfd-BarExport3_FOREXCOM_JP225_2026-10-12.csv','fut':'/root/nk225-data/BarExport3_OSE_NK225M1!_2026-10-12.csv'}
T=pd.read_pickle('cand.pkl');T=T[(T.fam=='W')&(~T.delay)]
DF=pd.read_csv('defs.csv',index_col=0)
out=[]
for inst in ['cfd','fut']:
    import os
    f=FILES[inst]
    if not os.path.exists(f):
        import glob,unicodedata
        f=[x for x in glob.glob('/root/nk225-data/*.csv') if unicodedata.normalize('NFC',os.path.basename(x))==os.path.basename(FILES[inst])][0]
    m1=ld.bars(f);m1=m1.sort_values('t').reset_index(drop=True)
    if inst=='fut':
        # 限月調整：5分足と同じ飛びを足す
        R=pd.read_pickle('/home/claude/bs/rolls.pkl');adj=np.zeros(len(m1))
        for t,j in zip(R.t,R.jump): adj[m1.t.values<np.datetime64(t.tz_convert('UTC').tz_localize(None))]+=j
        for c in ['open','high','low','close']: m1[c]=m1[c]+adj
    X=dict(np.load(f'data_{inst}.npz'));B=eng2.base(inst);P,ok=B['day'];Ld=eng3.per_lines(P,ok,'W',inst,1);pid=X['pid_day']
    tt=T[(T.inst==inst)&(T.t>=m1.t.iloc[0]+pd.Timedelta('1D'))].rename(columns={'def':'dd'})
    ends=np.nonzero(X['end_day'])[0]
    mt=m1.t.values
    for r in tt.itertuples():
        i=r.i;line=DF.loc[int(r.dd),'line']
        col={'Ω':'ome','γ':'gam','分水嶺':'W','α':'alp'}[line];L=Ld[col].values[pid[i]];D=Ld.D.values[pid[i]]
        sl=L-0.25*D;tp=r.tpn
        t_in=pd.Timestamp(X['tm'][i]+300,unit='s',tz='UTC')  # 5分足の終わり
        j_end=ends[np.searchsorted(ends,i)];t_end=pd.Timestamp(X['tm'][j_end]+300,unit='s',tz='UTC')
        a=np.searchsorted(mt,np.datetime64(t_in.tz_localize(None)));b=np.searchsorted(mt,np.datetime64(t_end.tz_localize(None)))
        seg=m1.iloc[a:b]
        if len(seg)==0: continue
        x=seg.close.iloc[-1]
        for q in seg.itertuples():
            if q.low<=sl: x=min(q.open,sl);break
            if not np.isnan(tp) and q.high>=tp: x=max(q.open,tp);break
        out.append(dict(inst=inst,t=r.t,pt5=r.pt,pt1=x-r.e))
O=pd.DataFrame(out);O.to_pickle('cand_1m.pkl')
print(O.groupby('inst').agg(n=('pt5','size'),pt5=('pt5','mean'),pt1=('pt1','mean'),diff=('pt1',lambda s:0)).round(2))
O['d']=O.pt1-O.pt5;print(O.groupby('inst').d.describe().round(2))
