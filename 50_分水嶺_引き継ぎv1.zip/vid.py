import pandas as pd,numpy as np
f=pd.read_pickle('fut5.pkl')  # 調整なし（当時の限月の値段）
f=f.set_index('t')
obs={'2026-04-17':[59090,59590,58570],'2026-04-20':[58955,59055,59435],'2026-04-22':[59570],'2026-04-23':[59195,59275,59695,58650],
     '2026-04-24':[59950,60030,60450],'2026-04-30':[59230,59310,59730],'2026-05-04':[59680,60160],'2026-05-06':[62070,61990,61570],'2026-05-08':[62930,63410]}
def lines(o,h,l,c):
    b=c>=o;W=2*c-h if b else 2*c-l;d=c-l if b else h-c
    return dict(Ω=2*c-l if b else 2*c-h,γ=W+d if b else W-d,W=W,α=W-d if b else W+d)
for day,v in obs.items():
    D=pd.Timestamp(day,tz='Asia/Tokyo')
    cand={}
    # 候補の元になる期間
    per={'当日日中':(D+pd.Timedelta('8h45m'),D+pd.Timedelta('15h50m')),
         '前日夜間':(D-pd.Timedelta('7h'),D+pd.Timedelta('6h05m')),
         '前の日(日中+夜)':(D-pd.Timedelta('1d')+pd.Timedelta('8h45m'),D+pd.Timedelta('6h05m'))}
    for hh in (1,4):
        e=D+pd.Timedelta('21h')
        per[f'21時前の{hh}時間']=(e-pd.Timedelta(hours=hh),e)
    for nm,(a,b) in per.items():
        x=f[(f.index>=a)&(f.index<b)]
        if len(x)==0: continue
        cand[nm]=lines(x.open.iloc[0],x.high.max(),x.low.min(),x.close.iloc[-1])
    px=f[(f.index>=D+pd.Timedelta('21h10m'))&(f.index<D+pd.Timedelta('21h20m'))].close
    print(day,'メモ',v,' 21:15頃',px.iloc[0] if len(px) else None)
    for nm,L in cand.items(): print('   ',nm,{k:int(x) for k,x in L.items()})
