import pandas as pd,numpy as np,openpyxl
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter as L
O=pd.read_pickle('touch_sum.pkl')
A=pd.read_pickle('touch.pkl');A=A[A.res.isin([1,-1])].copy();A['pt']=np.where(A.res==1,A.x,-A.x)
ev=A.groupby(['inst','key','xf','line']).agg(x=('x','mean'),avg=('pt','mean')).reset_index()
O=O.merge(ev,on=['inst','key','xf','line'])
IN={'fut':'ミニ','cfd':'CFD'};KY={'wk':'週','day':'日','ses':'セッション'};RT={'fut':10,'cfd':7}
fn='分水嶺ライン検証_2026-10-20.xlsx';wb=openpyxl.load_workbook(fn)
if '線への反応' in wb.sheetnames: del wb['線への反応']
ws=wb.create_sheet('線への反応',1);F='Arial'
cols=['商品','期間','幅（前の値幅×）','線','触れた回数','反発の割合','でたらめ（距離そろえ）','差','z','差がプラスの年','年数','上から来て反発','下から来て反発','幅の平均 pt','逆張り 1回の粗利 pt','コスト pt','逆張り 1回の純利 pt']
for j,c in enumerate(cols,1):
    x=ws.cell(1,j,c);x.font=Font(name=F,bold=True,color='FFFFFF');x.fill=PatternFill('solid',fgColor='305496');x.alignment=Alignment(wrap_text=True)
order={'wk':0,'day':1,'ses':2};lo={'分水嶺':0,'γ':1,'Ω':2,'α':3}
O=O.sort_values(['inst','key','xf','line'],key=lambda s:s.map(order) if s.name=='key' else (s.map(lo) if s.name=='line' else s),ascending=[False,True,True,True])
for r,row in enumerate(O.itertuples(),2):
    v=[IN[row.inst],KY[row.key],row.xf,row.line,row.n,row.bounce,row.rand_match,f'=F{r}-G{r}',row.z,row.yrs_plus,row.yrs,row.sup_bounce,row.res_bounce,row.x,row.avg,RT[row.inst],f'=O{r}-P{r}']
    for j,x in enumerate(v,1):
        c=ws.cell(r,j,x);c.font=Font(name=F)
        if j in(6,7,8,12,13): c.number_format='0.0%;[Red]-0.0%'
        if j in(9,14,15,17): c.number_format='0.0;[Red]-0.0'
n=len(O)+3
notes=['反発＝線に初めて触れた後、来た側へ「幅」戻るのが、反対側へ「幅」抜けるより先。突破はその逆。期間の終わりまでにどちらも無いものは除く。',
 'でたらめ＝前の終値±値幅×2 の範囲の線40本（値段の刻みにそろえる）。期間の始値からの距離が同じくらいのものと比べた。',
 '逆張り＝触れたところで反対向きに入り、利確・損切りとも「幅」。コストは往復（ミニ10、CFD7）。']
for i,t in enumerate(notes): ws.cell(n+i,1,t).font=Font(name=F,italic=True)
for j,w in enumerate([7,10,9,7,8,9,10,8,6,8,6,9,9,9,10,7,10],1): ws.column_dimensions[L(j)].width=w
ws.freeze_panes='A2'
wb.save(fn)
