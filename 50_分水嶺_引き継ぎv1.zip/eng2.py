"""週・日・セッションの分水嶺の並びで入る戦略の計算（全部ここで共通に使う）"""
import numpy as np, pandas as pd
from numba import njit
import eng

COND = ['S0', 'Wk', 'A1', 'A2', 'A3']   # S0:日の分水嶺の上  Wk:週の分水嶺の上  A1:価格>日W>週W  A2:A1かつ価格>セッションW  A3:A1かつセッションW>日Wかつ価格>セッションW

def base(inst):
    """足ごとに、週・日・セッションの分水嶺と幅を付けた表を作る。"""
    d = eng.load(inst)
    out = {'d': d}
    for key in ['wk', 'day', 'ses']:
        P = eng.periods(d, key)
        ok = np.ones(len(P), bool); ok[:2] = False; ok[-1] = False
        sm = (P.n < 0.2 * P.n.median()).values; ok &= ~sm; ok[1:] &= ~sm[:-1]
        out[key] = (P, ok)
    pk = d.ses.values
    out['ses_start'] = np.r_[True, pk[1:] != pk[:-1]]
    out['ses_end'] = np.r_[pk[:-1] != pk[1:], True]
    out['tfe'] = {tf: eng.tf_end(d, 'ses', tf) for tf in (15, 30, 60)}
    return out

def line_arrays(B, fam):
    """fam='W'（本物）または 'r0'〜'r4'（でたらめ）。足ごとの W・D・R（前の値幅）を返す。"""
    d = B['d']; res = {}
    for j, key in enumerate(['wk', 'day', 'ses']):
        P, ok = B[key]
        if fam == 'W':
            L = eng.lines(P, 'W')
        else:
            L = eng.lines(P, 'rand', seed=1000 * int(fam[1:]) + j)
        W = L.W.values.astype(float).copy(); W[~ok] = np.nan
        R = (P.h - P.l).shift(1).values
        idx = d[key].map(pd.Series(np.arange(len(P)), index=P.index)).values
        res[key] = (W[idx], L.D.values[idx], R[idx])
    return res

def conds(LA, px):
    Ww = LA['wk'][0]; Wd = LA['day'][0]; Ws = LA['ses'][0]
    with np.errstate(invalid='ignore'):
        okk = ~np.isnan(Ww) & ~np.isnan(Wd) & ~np.isnan(Ws)
        L = {'S0': px > Wd, 'Wk': px > Ww,
             'A1': (px > Wd) & (Wd > Ww),
             'A2': (px > Wd) & (Wd > Ww) & (px > Ws),
             'A3': (px > Wd) & (Wd > Ww) & (Ws > Wd) & (px > Ws)}
        S = {'S0': px < Wd, 'Wk': px < Ww,
             'A1': (px < Wd) & (Wd < Ww),
             'A2': (px < Wd) & (Wd < Ww) & (px < Ws),
             'A3': (px < Wd) & (Wd < Ww) & (Ws < Wd) & (px < Ws)}
    return {k: v & okk for k, v in L.items()}, {k: v & okk for k, v in S.items()}

@njit(cache=True)
def sim2(o, h, l, c, sstart, send, chkE, atOpen, cLc, cSc, cLo, cSo, chkX, xmode, dmode, trans, tpL, tpS, slL, slS, maxn):
    """
    chkE: 入る判定をする足（確定足）。atOpen=True ならセッション開始の足の始値で判定して入る。
    xmode 0: セッションの終わりで決済 / 1: 条件が崩れたら（chkX の足の終値で）決済、ドテンあり
    dmode 1: 買いだけ -1: 売りだけ 0: 両方
    tpd/sld: 入った足で決まる利確・損切りの幅（nan なら無し）
    """
    n = len(o)
    ei = np.empty(maxn, np.int64); xi = np.empty(maxn, np.int64); dr = np.empty(maxn, np.int64)
    ep = np.empty(maxn); xp = np.empty(maxn); rs = np.empty(maxn, np.int64)
    k = 0; pos = 0; e_i = 0; e_p = 0.0; tp = np.nan; sl = np.nan
    prevL = False; prevS = False
    for i in range(n):
        # ① セッション開始の始値で入る（T0）
        if atOpen and sstart[i]:
            if pos != 0 and xmode == 1:
                # 条件が崩れていたら始値で決済
                if (pos == 1 and not cLo[i]) or (pos == -1 and not cSo[i]):
                    ei[k] = e_i; xi[k] = i; dr[k] = pos; ep[k] = e_p; xp[k] = o[i]; rs[k] = 2; k += 1; pos = 0
            if pos == 0:
                if cLo[i] and dmode >= 0:
                    pos = 1
                elif cSo[i] and dmode <= 0:
                    pos = -1
                if pos != 0:
                    e_i = i; e_p = o[i]
                    tdist = tpL[i] if pos == 1 else tpS[i]
                    sdist = slL[i] if pos == 1 else slS[i]
                    tp = e_p + pos * tdist if not np.isnan(tdist) else np.nan
                    sl = e_p - pos * sdist if not np.isnan(sdist) else np.nan
        # ② 利確・損切り（入った足の次から。始値で入った足はその足から）
        if pos != 0 and (i > e_i or (atOpen and sstart[i] and i == e_i)):
            hitS = False; hitT = False; px = 0.0
            if pos == 1:
                if not np.isnan(sl) and l[i] <= sl:
                    hitS = True; px = min(o[i], sl) if i > e_i else sl
                elif not np.isnan(tp) and h[i] >= tp:
                    hitT = True; px = max(o[i], tp) if i > e_i else tp
            else:
                if not np.isnan(sl) and h[i] >= sl:
                    hitS = True; px = max(o[i], sl) if i > e_i else sl
                elif not np.isnan(tp) and l[i] <= tp:
                    hitT = True; px = min(o[i], tp) if i > e_i else tp
            if hitS or hitT:
                ei[k] = e_i; xi[k] = i; dr[k] = pos; ep[k] = e_p; xp[k] = px; rs[k] = 3 if hitT else 4; k += 1; pos = 0
        # ③ 条件が崩れたら決済
        if pos != 0 and xmode == 1 and chkX[i] and i > e_i:
            if (pos == 1 and not cLc[i]) or (pos == -1 and not cSc[i]):
                ei[k] = e_i; xi[k] = i; dr[k] = pos; ep[k] = e_p; xp[k] = c[i]; rs[k] = 2; k += 1; pos = 0
        # ④ セッションの終わりで決済
        if pos != 0 and xmode == 0 and send[i]:
            ei[k] = e_i; xi[k] = i; dr[k] = pos; ep[k] = e_p; xp[k] = c[i]; rs[k] = 1; k += 1; pos = 0
            continue
        # ⑤ 確定足で入る（T15/30/60）
        if (not atOpen) and chkE[i]:
            Lc = cLc[i]; Sc = cSc[i]
            okL = Lc and (not trans or not prevL)
            okS = Sc and (not trans or not prevS)
            prevL = Lc; prevS = Sc
            if pos == 0 and not (xmode == 0 and send[i]):
                if okL and dmode >= 0:
                    pos = 1
                elif okS and dmode <= 0:
                    pos = -1
                if pos != 0:
                    e_i = i; e_p = c[i]
                    tdist = tpL[i] if pos == 1 else tpS[i]
                    sdist = slL[i] if pos == 1 else slS[i]
                    tp = e_p + pos * tdist if not np.isnan(tdist) else np.nan
                    sl = e_p - pos * sdist if not np.isnan(sdist) else np.nan
        if k >= maxn - 2:
            break
    if pos != 0:
        ei[k] = e_i; xi[k] = n - 1; dr[k] = pos; ep[k] = e_p; xp[k] = c[n - 1]; rs[k] = 5; k += 1
    return ei[:k], xi[:k], dr[:k], ep[:k], xp[:k], rs[:k]

TIM = {'T0': 0, 'T15': 15, 'T30': 30, 'T60': 60}

def run(B, LA, cond, dirn, tim, xm, tpd=None, sld=None, CC=None, tpS=None, slS=None):
    """tpd/sld：買いの利確・損切りの幅（売りも同じなら tpS/slS は省略）"""
    d = B['d']; n = len(d)
    if CC is None:
        CC = (conds(LA, d.c.values), conds(LA, d.o.values))
    (cLc, cSc), (cLo, cSo) = CC
    atOpen = tim == 'T0'
    chkE = np.zeros(n, np.bool_) if atOpen else B['tfe'][TIM[tim]]
    chkX = B['tfe'][15] if atOpen else B['tfe'][TIM[tim]]
    nan = np.full(n, np.nan)
    def pick(a, b=None):
        if a is not None: return a.astype(float)
        if b is not None: return b.astype(float)
        return nan
    r = sim2(d.o.values, d.h.values, d.l.values, d.c.values, B['ses_start'], B['ses_end'], chkE, atOpen,
             cLc[cond], cSc[cond], cLo[cond], cSo[cond], chkX, xm, {'L': 1, 'S': -1, 'LS': 0}[dirn], True,
             pick(tpd), pick(tpS, tpd), pick(sld), pick(slS, sld), n)
    T = pd.DataFrame(dict(zip(['ei', 'xi', 'dir', 'ep', 'xp', 'rs'], r)))
    T['pt'] = T.dir * (T.xp - T.ep)
    T['yr'] = d.t.dt.year.values[T.xi.values]
    T['day'] = d.day.values[T.ei.values]
    return T
