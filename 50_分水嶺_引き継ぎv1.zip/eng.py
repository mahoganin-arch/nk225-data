import numpy as np, pandas as pd
from numba import njit

CUT = pd.Timestamp('2026-10-09 06:00', tz='Asia/Tokyo')

def load(inst):
    if inst == 'fut':
        f = pd.read_pickle('/home/claude/bs/fut5a.pkl')
        d = pd.DataFrame({'t': f.t, 'o': f.open_a, 'h': f.high_a, 'l': f.low_a, 'c': f.close_a})
    else:
        f = pd.read_pickle('/home/claude/bs/cfd5.pkl')
        d = pd.DataFrame({'t': f.t, 'o': f.open, 'h': f.high, 'l': f.low, 'c': f.close})
    d = d[d.t < CUT].reset_index(drop=True)
    # 日の区切り：先物は 6:00 の引け足までを前の日に、CFD は 7:00（冬の引け）までを前の日に入れる
    sh = pd.Timedelta(hours=6, minutes=5) if inst == 'fut' else pd.Timedelta(hours=7)
    s = (d.t - sh).dt.tz_localize(None)
    d['day'] = s.dt.normalize()
    d['wk'] = s.dt.to_period('W-SUN').dt.start_time
    hr = d.t.dt.hour
    hm = hr * 60 + d.t.dt.minute
    dayses = ((hm >= 8 * 60) & (hm < 16 * 60 + 15)) if inst == 'fut' else ((hr >= 7) & (hr < 17))
    d['ses'] = d.day + pd.to_timedelta(np.where(dayses, 0, 12), unit='h')
    mins = hr * 60 + d.t.dt.minute
    if inst == 'fut':  # 足は立会の始まり（8:45 / 17:00）から数える
        anchor = np.where(dayses, 8 * 60 + 45, np.where(hm >= 16 * 60 + 30, np.where(hm < 17 * 60, 16 * 60 + 30, 17 * 60), 17 * 60))
    else:
        anchor = np.zeros(len(d), dtype=int)
    d['rel'] = (mins - anchor) % 1440
    return d

def periods(d, key):
    g = d.groupby(key, sort=True)
    P = g.agg(o=('o', 'first'), h=('h', 'max'), l=('l', 'min'), c=('c', 'last'), t0=('t', 'first'), t1=('t', 'last'), n=('o', 'size'))
    return P

def lines(P, kind='W', seed=None):
    """前の期間の O/H/L/C から、今の期間の分水嶺 W と幅 D、向き（陽線=1）を作る。"""
    O, H, L, C = P.o.shift(1), P.h.shift(1), P.l.shift(1), P.c.shift(1)
    bull = (C >= O)
    W = np.where(bull, 2 * C - H, 2 * C - L)
    D = np.where(bull, C - L, H - C)
    if kind == 'C':
        W = C.values
    elif kind == 'mid':
        W = ((H + L) / 2).values
    elif kind == 'rand':
        rng = np.random.default_rng(seed)
        W = (C + rng.uniform(-1, 1, len(P)) * (H - L)).values
    out = pd.DataFrame({'W': W, 'D': D, 'bull': bull.astype(int)}, index=P.index)
    out['gam'] = np.where(bull, out.W + out.D, out.W - out.D)
    out['alp'] = np.where(bull, out.W - out.D, out.W + out.D)
    out['ome'] = np.where(bull, 2 * C - L, 2 * C - H)
    return out

@njit(cache=True)
def sim(o, h, l, c, pid, Wp, Dp, tfend, mode, al, ash):
    # mode 0=A（始まりで向きを決めて終わりまで） 1=B（分水嶺でドテン） 2=C（B＋分水嶺±D で利確）
    n = len(o)
    ent_i = np.empty(n, np.int64); ex_i = np.empty(n, np.int64)
    dirs = np.empty(n, np.int64); ep = np.empty(n); xp = np.empty(n)
    k = 0; pos = 0; e_i = 0; e_p = 0.0; last = 0
    for i in range(n):
        p = pid[i]
        W = Wp[p]; D = Dp[p]
        if i == 0 or pid[i - 1] != p:
            pos = 0; last = 0
            if not np.isnan(W):
                s = 1 if o[i] > W else (-1 if o[i] < W else 0)
                last = s
                if s == 1 and al[i]:
                    pos = 1; e_i = i; e_p = o[i]
                elif s == -1 and ash[i]:
                    pos = -1; e_i = i; e_p = o[i]
        if np.isnan(W):
            continue
        # 利確（C）
        if mode == 2 and pos != 0 and D > 0:
            if pos == 1 and h[i] >= W + D:
                x = W + D
                if i != e_i and o[i] > x: x = o[i]
                ent_i[k] = e_i; ex_i[k] = i; dirs[k] = 1; ep[k] = e_p; xp[k] = x; k += 1; pos = 0
            elif pos == -1 and l[i] <= W - D:
                x = W - D
                if i != e_i and o[i] < x: x = o[i]
                ent_i[k] = e_i; ex_i[k] = i; dirs[k] = -1; ep[k] = e_p; xp[k] = x; k += 1; pos = 0
        endp = (i == n - 1) or (pid[i + 1] != p)
        if mode >= 1 and tfend[i] and not endp:
            s = 1 if c[i] > W else (-1 if c[i] < W else last)
            if s != last:
                last = s
                if pos != 0:
                    ent_i[k] = e_i; ex_i[k] = i; dirs[k] = pos; ep[k] = e_p; xp[k] = c[i]; k += 1; pos = 0
                if s == 1 and al[i]:
                    pos = 1; e_i = i; e_p = c[i]
                elif s == -1 and ash[i]:
                    pos = -1; e_i = i; e_p = c[i]
        if endp and pos != 0:
            ent_i[k] = e_i; ex_i[k] = i; dirs[k] = pos; ep[k] = e_p; xp[k] = c[i]; k += 1; pos = 0
    return ent_i[:k], ex_i[:k], dirs[:k], ep[:k], xp[:k]

def tf_end(d, key, tf):
    if tf == 5:
        return np.ones(len(d), dtype=np.bool_)
    b = (d.rel // tf).values
    pk = d[key].values
    e = np.ones(len(d), dtype=np.bool_)
    e[:-1] = (b[:-1] != b[1:]) | (pk[:-1] != pk[1:])
    return e

def run(d, key, P, L, mode, tf, al=None, ash=None, tfe=None):
    pid = d[key].map(pd.Series(np.arange(len(P)), index=P.index)).values.astype(np.int64)
    if tfe is None: tfe = tf_end(d, key, tf)
    n = len(d)
    if al is None: al = np.ones(n, np.bool_)
    if ash is None: ash = np.ones(n, np.bool_)
    Wp = L.W.values.astype(float).copy(); Dp = L.D.values.astype(float)
    Wp[:2] = np.nan; Wp[-1] = np.nan  # 最初の2期間（不完全）と最後の期間（途中）は使わない
    small = (P.n < 0.2 * P.n.median()).values  # 祝日などで本数がごく少ない期間
    Wp[small] = np.nan; Wp[1:][small[:-1]] = np.nan
    ei, xi, dr, ep, xp = sim(d.o.values, d.h.values, d.l.values, d.c.values, pid, Wp, Dp, tfe, mode, al, ash)
    T = pd.DataFrame({'ei': ei, 'xi': xi, 'dir': dr, 'ep': ep, 'xp': xp})
    T['pt'] = T.dir * (T.xp - T.ep)
    T['et'] = d.t.values[ei]; T['xt'] = d.t.values[xi]
    T['yr'] = pd.to_datetime(T.xt).dt.year if T.xt.dtype != object else 0
    return T

def costs(T, rt):
    """rt=往復の pt。固定と割合（60,000円のときに rt になる割合）の両方の損益を付ける。"""
    T = T.copy()
    T['net_fix'] = T.pt - rt
    T['net_pct'] = T.pt - rt * T.ep / 60000
    return T
