import pandas as pd,numpy as np
Y=pd.read_pickle('grid_y.pkl')
Y['cfg']=Y.key+'_'+Y.rule
res=[];detail=[]
for inst in ['fut','cfd']:
  for fam in ['W','C','mid']+[f'rand{s}' for s in range(5)]:
    y=Y[(Y.inst==inst)&(Y.line==fam)]
    nf=y.pivot_table(index='yr',columns='cfg',values='net',fill_value=0)
    npct=y.pivot_table(index='yr',columns='cfg',values='net_pct',fill_value=0)
    tot_f=tot_p=0
    for yr in range(2019,2027):
      past_f=nf.loc[nf.index<yr].sum();past_p=npct.loc[npct.index<yr].sum()
      sc=np.minimum(past_f,past_p);best=sc.idxmax()
      if sc[best]<=0: f=p=0;best='（見送り）'
      else: f=nf.loc[yr,best];p=npct.loc[yr,best]
      tot_f+=f;tot_p+=p
      detail.append(dict(inst=inst,fam=fam,yr=yr,pick=best,net=f,net_pct=p))
    res.append(dict(inst=inst,fam=fam,fwd_fix=tot_f,fwd_pct=tot_p,insample_best=np.minimum(nf.sum(),npct.sum()).max()))
R=pd.DataFrame(res);D=pd.DataFrame(detail)
print(R.round(0).to_string());print(D[D.fam=='W'].round(0).to_string())
R.to_pickle('nest.pkl');D.to_pickle('nest_d.pkl')
