"""Ω・γ・分水嶺・α の4本を、本物とでたらめ（同じ並び方で位置だけランダム）で作る"""
import numpy as np, pandas as pd
import eng

TICK = {'fut': 5.0, 'cfd': 1.0}

def per_lines(P, ok, fam, inst, j=0):
    """期間ごとの α・W・γ・Ω と D（Wとγの幅）、R（前の値幅）、向き s（陽線=+1）。"""
    O, H, L, C = P.o.shift(1).values, P.h.shift(1).values, P.l.shift(1).values, P.c.shift(1).values
    bull = C >= O
    s = np.where(bull, 1.0, -1.0)
    D = np.where(bull, C - L, H - C)
    R = H - L
    if fam == 'W':
        W = np.where(bull, 2 * C - H, 2 * C - L)
    else:
        rng = np.random.default_rng(5000 * int(fam[1:]) + j)
        t = TICK[inst]
        W = C + np.round(rng.uniform(-1, 1, len(P)) * R / t) * t
    out = pd.DataFrame({'W': W, 'D': D, 'R': R, 's': s,
                        'gam': W + s * D, 'alp': W - s * D, 'ome': W + s * R}, index=P.index)
    out.loc[~ok, ['W', 'gam', 'alp', 'ome']] = np.nan
    return out

def bar_lines(B, key, fam, inst):
    P, ok = B[key]
    j = {'wk': 0, 'day': 1, 'ses': 2}[key]
    Lp = per_lines(P, ok, fam, inst, j)
    idx = B['d'][key].map(pd.Series(np.arange(len(P)), index=P.index)).values
    return {c: Lp[c].values[idx] for c in Lp.columns}, Lp
