import eng, eng2, numpy as np, pandas as pd, itertools, sys
RT={'fut':10,'cfd':7}
inst=sys.argv[1]; fams=sys.argv[2].split(',')
B=eng2.base(inst);d=B['d'];n=len(d)
rows=[]
def line_mat(B,fam,key,j):
    P,ok=B[key]
    L=eng.lines(P,'W') if fam=='W' else eng.lines(P,'rand',seed=1000*int(fam[1:])+j)
    if fam!='W':  # でたらめな線でも Ω・γ・α は同じ形（W±D、Ω は W から2D）にそろえる
        b=L.bull.values==1
        L['gam']=np.where(b,L.W+L.D,L.W-L.D);L['alp']=np.where(b,L.W-L.D,L.W+L.D);L['ome']=np.where(b,L.W+2*L.D,L.W-2*L.D)
    M=L[['ome','gam','W','alp']].values.astype(float);M[~ok]=np.nan
    idx=d[key].map(pd.Series(np.arange(len(P)),index=P.index)).values
    return M[idx]
def nearest(M,px,up):
    dd=(M-px[:,None]) if up else (px[:,None]-M)
    dd=np.where(dd>=20,dd,np.inf);r=dd.min(1);r[np.isinf(r)]=np.nan;return r
for fam in fams:
    LA=eng2.line_arrays(B,fam);CC=(eng2.conds(LA,d.c.values),eng2.conds(LA,d.o.values))
    Rs=LA['ses'][2]
    Md=line_mat(B,fam,'day',1);Mw=line_mat(B,fam,'wk',0)
    pxo=np.where(B['ses_start'],d.o.values,d.c.values)
    EX=[]
    for a in (50,100,200,300,500):
        for b in (50,100,200,300,500): EX.append((f'固定 利{a} 損{b}',np.full(n,float(a)),None,np.full(n,float(b)),None))
    for a in (0.25,0.5,1,1.5):
        for b in (0.25,0.5,1): EX.append((f'値幅 利{a} 損{b}',a*Rs,None,b*Rs,None))
    LN={}
    for tim in ('T0','T15'):
        px=pxo if tim=='T0' else d.c.values
        LN[tim]={'日の線':(nearest(Md,px,True),nearest(Md,px,False)),'週の線':(nearest(Mw,px,True),nearest(Mw,px,False))}
    for cond,dirn,tim in itertools.product(eng2.COND,['L','S','LS'],['T0','T15','T30','T60']):
        ex=list(EX)
        ln=LN['T0' if tim=='T0' else 'T15']
        for nm,(tu,td) in ln.items():
            for snm,sv in (('損100',np.full(n,100.)),('損200',np.full(n,200.)),('損値幅0.5',0.5*Rs)):
                ex.append((f'{nm}まで {snm}',tu,td,sv,None))
        for ename,tL,tS,sL,sS in ex:
            T=eng2.run(B,LA,cond,dirn,tim,0,tpd=tL,tpS=tS,sld=sL,slS=sS,CC=CC);rt=RT[inst]
            T['nf']=T.pt-rt;T['np']=T.pt-rt*T.ep/60000
            g=T.groupby('yr').agg(nf=('nf','sum'),np_=('np','sum'),gross=('pt','sum'),n=('pt','size'))
            for y,r in g.iterrows():
                rows.append(dict(inst=inst,fam=fam,cond=cond,dir=dirn,tim=tim,ex=ename,yr=y,nf=r.nf,np_=r.np_,gross=r.gross,n=r.n))
    print(inst,fam,flush=True)
    pd.DataFrame(rows).to_pickle(f'p2_{inst}_{"_".join(fams)}.pkl')
