"""入れ子の前向き：毎年、その年より前の成績だけで設定を1つ選び（両方のコストの小さい方で比べる）、その年に使う。
本物の線と、でたらめな線（各種）に同じ手順を通して比べる。"""
import pandas as pd, numpy as np, sys

def nested(Y, keys, start=2019, end=2026, minpast=0):
    """Y: fam ごとの年別成績。keys: 設定を決める列。戻り値：fam ごとの前向きの合計と年ごとの選択"""
    out = []; det = []
    for (inst, fam), y in Y.groupby(['inst', 'fam']):
        cfg = y[keys].astype(str).agg('|'.join, axis=1)
        y = y.assign(cfg=cfg)
        nf = y.pivot_table(index='yr', columns='cfg', values='nf', aggfunc='sum', fill_value=0)
        npc = y.pivot_table(index='yr', columns='cfg', values='np_', aggfunc='sum', fill_value=0)
        tf = tp = 0
        for yr in range(start, end + 1):
            pf = nf.loc[nf.index < yr].sum(); pp = npc.loc[npc.index < yr].sum()
            sc = np.minimum(pf, pp); best = sc.idxmax()
            if sc[best] <= minpast:
                f = p = 0.0; best = '（見送り）'
            else:
                f = nf.loc[yr, best] if yr in nf.index else 0.0
                p = npc.loc[yr, best] if yr in npc.index else 0.0
            tf += f; tp += p
            det.append(dict(inst=inst, fam=fam, yr=yr, pick=best, nf=f, np_=p))
        out.append(dict(inst=inst, fam=fam, fwd_nf=tf, fwd_np=tp))
    return pd.DataFrame(out), pd.DataFrame(det)
