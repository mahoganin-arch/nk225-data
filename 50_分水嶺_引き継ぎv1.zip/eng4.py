"""γ・α・Ω を使った入り方（近さの幅つき）"""
import numpy as np, pandas as pd
from numba import njit
import eng2, eng3

@njit(cache=True)
def sim3(o, h, l, c, sig, atopen, tpP, slP, pend):
    n = len(o)
    ei = np.empty(n, np.int64); xi = np.empty(n, np.int64); dr = np.empty(n, np.int64)
    ep = np.empty(n); xp = np.empty(n); rs = np.empty(n, np.int64)
    k = 0; pos = 0; e_i = 0; e_p = 0.0; tp = np.nan; sl = np.nan; op = False
    for i in range(n):
        if pos == 0 and sig[i] != 0 and atopen[i]:
            pos = sig[i]; e_i = i; e_p = o[i]; tp = tpP[i]; sl = slP[i]; op = True
        if pos != 0 and (i > e_i or op):
            hitS = False; hitT = False; px = 0.0
            if pos == 1:
                if not np.isnan(sl) and l[i] <= sl:
                    hitS = True; px = min(o[i], sl) if i > e_i else sl
                elif not np.isnan(tp) and h[i] >= tp:
                    hitT = True; px = max(o[i], tp) if i > e_i else tp
            else:
                if not np.isnan(sl) and h[i] >= sl:
                    hitS = True; px = max(o[i], sl) if i > e_i else sl
                elif not np.isnan(tp) and l[i] <= tp:
                    hitT = True; px = min(o[i], tp) if i > e_i else tp
            if hitS or hitT:
                ei[k] = e_i; xi[k] = i; dr[k] = pos; ep[k] = e_p; xp[k] = px; rs[k] = 3 if hitT else 4; k += 1; pos = 0
        op = False
        if pos != 0 and pend[i]:
            ei[k] = e_i; xi[k] = i; dr[k] = pos; ep[k] = e_p; xp[k] = c[i]; rs[k] = 1; k += 1; pos = 0
            continue
        if pos == 0 and sig[i] != 0 and not atopen[i] and not pend[i]:
            pos = sig[i]; e_i = i; e_p = c[i]; tp = tpP[i]; sl = slP[i]
    return ei[:k], xi[:k], dr[:k], ep[:k], xp[:k], rs[:k]

def prep(inst):
    B = eng2.base(inst); d = B['d']; n = len(d)
    ends = {}
    for key in ['wk', 'day', 'ses']:
        pk = d[key].values; ends[key] = np.r_[pk[:-1] != pk[1:], True]
    B['pend'] = ends
    # 足ごとの TF の高値・安値（確定足の判定用）
    tfhl = {}
    for tf in (15, 60):
        b = (d.rel // tf).astype(np.int64).values
        grp = np.cumsum(np.r_[True, (b[1:] != b[:-1]) | (d.ses.values[1:] != d.ses.values[:-1])])
        hh = pd.Series(d.h.values).groupby(grp).cummax().values
        ll = pd.Series(d.l.values).groupby(grp).cummin().values
        tfhl[tf] = (hh, ll)
    B['tfhl'] = tfhl
    return B

def next_lines(M, p, margin):
    """M: (n,4) の線。p より margin 以上離れた、上で一番近い線と下で一番近い線"""
    up = np.where(M > p[:, None] + margin[:, None], M, np.inf).min(1)
    dn = np.where(M < p[:, None] - margin[:, None], M, -np.inf).max(1)
    up[np.isinf(up)] = np.nan; dn[np.isinf(dn)] = np.nan
    return up, dn

def signals(B, LN, kind, dirn, tim, b, opt, WK=None, wkf='none', wb=0.2):
    """kind: E1 ゾーン / E2 抜け / E3 近くで反発。戻り値：sig, atopen, tpP, slP"""
    d = B['d']; n = len(d)
    o, h, l, c = d.o.values, d.h.values, d.l.values, d.c.values
    W, D, a, g, om = LN['W'], LN['D'], LN['alp'], LN['gam'], LN['ome']
    M = np.c_[a, W, g, om]
    M3 = np.c_[a, g, om]  # 分水嶺以外
    sig = np.zeros(n, np.int64); tpP = np.full(n, np.nan); slP = np.full(n, np.nan)
    atopen = np.zeros(n, np.bool_)
    valid = ~np.isnan(W) & (D > 0)
    if tim == 'T0':
        idx = np.nonzero(B['ses_start'] & valid)[0]; p = o[idx]; prevp = None
    else:
        tf = int(tim[1:]); chk = B['tfe'][tf]
        allc = np.nonzero(chk)[0]
        prev_all = np.r_[np.nan, c[allc[:-1]]]
        m = valid[allc]; idx = allc[m]; p = c[idx]; prevp = prev_all[m]
        th, tl = B['tfhl'][tf][0][idx], B['tfhl'][tf][1][idx]
    Dx = D[idx]; Wx = W[idx]
    L = np.zeros(len(idx), np.int64); TP = np.full(len(idx), np.nan); SL = np.full(len(idx), np.nan)
    up, dn = next_lines(M[idx], p, 0.1 * Dx)
    if kind == 'E1':
        if tim == 'T0':
            lo = p > Wx; so = p < Wx
        else:
            lo = (p > Wx) & (prevp <= Wx); so = (p < Wx) & (prevp >= Wx)
        tpl = up - b * Dx; tps = dn + b * Dx
        if opt == 'W':
            sll = Wx - 0.25 * Dx; sls = Wx + 0.25 * Dx
        else:  # 分水嶺の反対側の線（α など）の少し手前
            _, dW = next_lines(M[idx], Wx, 0.1 * Dx); uW, _ = next_lines(M[idx], Wx, 0.1 * Dx)
            sll = dW + b * Dx; sls = uW - b * Dx
        lo &= tpl > p + 0.1 * Dx; so &= tps < p - 0.1 * Dx
        L[lo] = 1; TP[lo] = tpl[lo]; SL[lo] = sll[lo]
        L[so] = -1; TP[so] = tps[so]; SL[so] = sls[so]
    elif kind == 'E2':
        if tim == 'T0':
            return None
        Mx = M3[idx]
        crU = (Mx > prevp[:, None]) & (Mx <= p[:, None]); crD = (Mx < prevp[:, None]) & (Mx >= p[:, None])
        XU = np.where(crU, Mx, -np.inf).max(1); XD = np.where(crD, Mx, np.inf).min(1)
        lo = np.isfinite(XU); so = np.isfinite(XD) & ~lo
        L[lo] = 1; TP[lo] = up[lo] - b * Dx[lo]; SL[lo] = XU[lo] - 0.25 * Dx[lo]
        L[so] = -1; TP[so] = dn[so] + b * Dx[so]; SL[so] = XD[so] + 0.25 * Dx[so]
    elif kind == 'E3':
        if tim == 'T0':
            return None
        Mx = M[idx]
        # 上の線の近く（b×D 以内）まで来て、終値は線の手前 → 売り
        nearU = (th[:, None] >= Mx - b * Dx[:, None]) & (p[:, None] < Mx) & (prevp[:, None] < Mx - b * Dx[:, None])
        nearD = (tl[:, None] <= Mx + b * Dx[:, None]) & (p[:, None] > Mx) & (prevp[:, None] > Mx + b * Dx[:, None])
        XU = np.where(nearU, Mx, np.inf).min(1); XD = np.where(nearD, Mx, -np.inf).max(1)
        so = np.isfinite(XU); lo = np.isfinite(XD) & ~so
        if opt == 'next':
            tps = dn + b * Dx; tpl = up - b * Dx
        else:
            tps = p - 0.5 * Dx; tpl = p + 0.5 * Dx
        L[so] = -1; TP[so] = tps[so]; SL[so] = XU[so] + 0.25 * Dx[so]
        L[lo] = 1; TP[lo] = tpl[lo]; SL[lo] = XD[lo] - 0.25 * Dx[lo]
    if dirn == 'L': L[L == -1] = 0
    if dirn == 'S': L[L == 1] = 0
    # 週の線を条件にする（日・セッションの線のとき）
    if WK is not None and wkf != 'none':
        Ww = WK['W'][idx]; Dw = WK['D'][idx]
        Mw = np.c_[WK['alp'], WK['W'], WK['gam'], WK['ome']][idx]
        ok = ~np.isnan(Ww)
        side_l = ok & (p > Ww); side_s = ok & (p < Ww)
        if wkf == 'room':
            uw, dw = next_lines(Mw, p, np.zeros(len(p)))
            side_l &= ~(uw - p < wb * Dw); side_s &= ~(p - dw < wb * Dw)
        L[(L == 1) & ~side_l] = 0; L[(L == -1) & ~side_s] = 0
    sig[idx] = L; tpP[idx] = TP; slP[idx] = SL
    if tim == 'T0':
        atopen[idx] = True
    return sig, atopen, tpP, slP

def run(B, LN, key, kind, dirn, tim, b, opt, WK=None, wkf='none'):
    s = signals(B, LN, kind, dirn, tim, b, opt, WK, wkf)
    if s is None: return None
    sig, atopen, tpP, slP = s; d = B['d']
    r = sim3(d.o.values, d.h.values, d.l.values, d.c.values, sig, atopen, tpP, slP, B['pend'][key])
    T = pd.DataFrame(dict(zip(['ei', 'xi', 'dir', 'ep', 'xp', 'rs'], r)))
    T['pt'] = T.dir * (T.xp - T.ep)
    T['yr'] = d.t.dt.year.values[T.xi.values]
    return T
