import eng, numpy as np, pandas as pd
from numba import njit
@njit(cache=True)
def scan(o,h,l,c,s0,s1,lev,xs):
    P,K=lev.shape
    res=np.zeros((P,K),np.int64); side=np.zeros((P,K),np.int64); tix=np.full((P,K),-1,np.int64)
    for p in range(P):
        x=xs[p]
        if not (x>0): continue
        for k in range(K):
            L=lev[p,k]
            if np.isnan(L): continue
            ref=o[s0[p]]; t=-1; sd=0
            for i in range(s0[p],s1[p]+1):
                if l[i]<=L<=h[i]:
                    if ref<L: sd=1
                    elif ref>L: sd=-1
                    else: sd=0
                    if sd!=0:
                        t=i;break
                ref=c[i]
            if t<0: continue
            tix[p,k]=t; side[p,k]=sd
            far=L+sd*x; back=L-sd*x
            if (sd==1 and h[t]>=far) or (sd==-1 and l[t]<=far):
                res[p,k]=-1;continue
            r=0
            for j in range(t+1,s1[p]+1):
                hf=(h[j]>=far) if sd==1 else (l[j]<=far)
                hb=(l[j]<=back) if sd==1 else (h[j]>=back)
                if hf and hb: r=9;break
                if hf: r=-1;break
                if hb: r=1;break
            res[p,k]=r
    return res,side,tix
NR=40
rows=[]
for inst in ['fut','cfd']:
    d=eng.load(inst)
    for key in ['wk','day','ses']:
        P=eng.periods(d,key);Lw=eng.lines(P,'W')
        pid=d[key].values
        st=np.r_[0,np.nonzero(pid[1:]!=pid[:-1])[0]+1];en=np.r_[st[1:]-1,len(d)-1]
        R=(P.h-P.l).shift(1).values
        ok=np.ones(len(P),bool);ok[:2]=False;ok[-1]=False
        sm=(P.n<0.2*P.n.median()).values;ok&=~sm;ok[1:]&=~sm[:-1]
        real=np.c_[Lw.ome,Lw.gam,Lw.W,Lw.alp].astype(float);real[~ok]=np.nan
        rng=np.random.default_rng(7)
        C=P.c.shift(1).values
        tick=5.0 if inst=='fut' else 1.0
        rnd=C[:,None]+np.round(rng.uniform(-2,2,(len(P),NR))*R[:,None]/tick)*tick;  # 値段の刻みにそろえる
        rnd[~ok]=np.nan
        lev=np.c_[real,rnd]
        names=['Ω','γ','分水嶺','α']+['rand']*NR
        O0=P.o.values
        for xf in (0.1,0.25):
            xs=np.where(ok,R*xf,np.nan)
            res,sd,tx=scan(d.o.values,d.h.values,d.l.values,d.c.values,st,en,lev,xs)
            yr=pd.to_datetime(P.t0).dt.year.values
            for k in range(lev.shape[1]):
                m=tx[:,k]>=0
                dist=np.abs(lev[:,k]-O0)/R
                rows.append(pd.DataFrame({'inst':inst,'key':key,'xf':xf,'line':names[k],'lk':k,'res':res[m,k],'side':sd[m,k],'dist':dist[m],'yr':yr[m],'x':xs[m]}))
        print(inst,key,flush=True)
A=pd.concat(rows,ignore_index=True);A.to_pickle('touch.pkl');print(len(A))
