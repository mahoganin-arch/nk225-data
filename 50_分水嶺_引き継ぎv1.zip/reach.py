import eng2, eng3, numpy as np, pandas as pd
NS=20; BS=[0,0.1,0.2,0.3]
rows=[]
for inst in ['fut','cfd']:
    B=eng2.base(inst);d=B['d']
    for key in ['wk','day','ses']:
        P,ok=B[key]
        g=d.groupby(key);hi=g.h.max().values;lo=g.l.min().values;op=g.o.first().values
        for fam in ['W']+[f'r{s}' for s in range(NS)]:
            _,Lp=eng3.per_lines(P,ok,fam,inst,{'wk':0,'day':1,'ses':2}[key]) if False else (None,eng3.per_lines(P,ok,fam,inst,{'wk':0,'day':1,'ses':2}[key]))
            for ln in ['ome','gam','W','alp']:
                Lv=Lp[ln].values;D=Lp.D.values;R=Lp.R.values
                v=~np.isnan(Lv)&(D>0)
                up=Lv>op
                dist=np.abs(Lv-op)
                for b in BS:
                    tol=b*D
                    valid=v&(dist>tol)
                    reach=np.where(up,hi>=Lv-tol,lo<=Lv+tol)
                    beyond=np.where(up,hi>=Lv+0.25*D,lo<=Lv-0.25*D)  # 0.25D 以上抜けた
                    rows.append(pd.DataFrame({'inst':inst,'key':key,'fam':fam,'line':ln,'b':b,'reach':reach[valid],'beyond':beyond[valid],'dist':(dist/R)[valid]}))
        print(inst,key,flush=True)
A=pd.concat(rows,ignore_index=True);A.to_pickle('reach.pkl')
A['db']=pd.cut(A.dist,[0,.1,.2,.3,.5,.75,1,1.5,2,3,99])
out=[]
for (inst,key,ln,b),g in A.groupby(['inst','key','line','b']):
    r=g[g.fam=='W'];q=g[g.fam!='W']
    rb=q.groupby('db',observed=False).reach.mean();w=r.db.value_counts(normalize=True)
    exp=float((w*rb.reindex(w.index)).sum())
    # でたらめ各種の値（同じ重み）で、ばらつきを見る
    sims=[]
    for f,qq in q.groupby('fam'):
        rr=qq.groupby('db',observed=False).reach.mean();sims.append(float((w*rr.reindex(w.index)).sum()))
    out.append(dict(inst=inst,key=key,line=ln,b=b,n=len(r),reach=r.reach.mean(),rand=exp,diff=r.reach.mean()-exp,rank=np.mean(np.array(sims)<r.reach.mean()),
                    beyond_given_reach=r[r.reach].beyond.mean(),rand_beyond=q[q.reach].beyond.mean(),dist_med=r.dist.median()))
O=pd.DataFrame(out);O.to_pickle('reach_sum.pkl')
pd.set_option('display.width',250);print(O.round(3).to_string())
