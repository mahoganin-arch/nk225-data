import eng4, eng3, numpy as np, pandas as pd
RT={'fut':10,'cfd':7}
def hl_lines(B,key):
    P,ok=B[key];d=B['d']
    H,L,C=P.h.shift(1).values,P.l.shift(1).values,P.c.shift(1).values;R=H-L
    bull=C>=P.o.shift(1).values
    df=pd.DataFrame({'W':C,'D':R/2,'R':R,'s':np.where(bull,1.,-1.),'gam':H,'alp':L,'ome':np.where(bull,H+R/2,L-R/2)},index=P.index)
    df.loc[~ok,['W','gam','alp','ome']]=np.nan
    idx=d[key].map(pd.Series(np.arange(len(P)),index=P.index)).values
    return {c:df[c].values[idx] for c in df.columns}
out=[]
for inst in ['fut','cfd']:
    B=eng4.prep(inst);d=B['d'];rt=RT[inst]
    LNw={k:eng3.bar_lines(B,k,'W',inst)[0] for k in ['wk','day']}
    HL=hl_lines(B,'day')
    for nm,LN in [('分水嶺の4本',LNw['day']),('前日の高値・安値（比較）',HL)]:
        for dr,wkf in [('L','side'),('L','none'),('LS','none')]:
            T=eng4.run(B,LN,'day','E2',dr,'T60',0.0,'-',WK=LNw['wk'],wkf=wkf)
            T['nf']=T.pt-rt;T['n2']=T.pt-2*rt;T['ret']=T.pt/T.ep
            T['day']=d.day.values[T.ei]
            top=T.groupby('day').nf.sum().sort_values(ascending=False)
            yr=T.groupby('yr').ret.sum()*100
            out.append(dict(inst=inst,lines=nm,dir=dr,wkf=wkf,n=len(T),nf=T.nf.sum(),n2=T.n2.sum(),avg=T.pt.mean(),win=(T.nf>0).mean(),
                            top10=top.head(10).sum(),pct_tot=T.ret.sum()*100,**{f'%{y}':round(v,1) for y,v in yr.items()}))
O=pd.DataFrame(out);O.to_pickle('e2chk.pkl')
pd.set_option('display.width',300);print(O.round(1).to_string())
