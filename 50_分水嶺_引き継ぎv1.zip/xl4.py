import pandas as pd,numpy as np,nest2,warnings;warnings.filterwarnings('ignore')
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter as L
F='Arial';NUM='#,##0;[Red]-#,##0';P1='0.0;[Red]-0.0';PC='0%';PC1='0.0%;[Red]-0.0%'
IN={'fut':'ミニ','cfd':'CFD'};KY={'wk':'週','day':'日','ses':'セッション'};LN={'W':'分水嶺','gam':'γ','ome':'Ω','alp':'α'}
KD={'E1':'E1 ゾーン（分水嶺を越えたら次の線へ）','E2':'E2 抜け（γ・α・Ω を越えたら次の線へ）','E3':'E3 近くで反発（線の近くで逆張り）'}
DR={'L':'買いだけ','S':'売りだけ','LS':'両方'};TM={'T0':'セッション開始','T15':'15分確定','T60':'60分確定'}
OP={'W':'損切り＝分水嶺の少し先','next':'損切り＝反対側の線の手前','-':'損切り＝抜けた線の少し先','half':'利確＝D×0.5','next ':''}
OP3={'next':'利確＝次の線の手前','half':'利確＝D×0.5'}
WF={'none':'なし','side':'週Wと同じ側','room':'週Wと同じ側＋週の線の手前'}
wb=Workbook()
def sheet(title,cols,rows,fmts,widths,note=None):
    ws=wb.create_sheet(title)
    for j,c in enumerate(cols,1):
        x=ws.cell(1,j,c);x.font=Font(name=F,bold=True,color='FFFFFF');x.fill=PatternFill('solid',fgColor='305496');x.alignment=Alignment(wrap_text=True,vertical='center')
    for i,r in enumerate(rows,2):
        for j,v in enumerate(r,1):
            if isinstance(v,np.floating): v=None if np.isnan(v) else float(v)
            if isinstance(v,np.integer): v=int(v)
            c=ws.cell(i,j,v);c.font=Font(name=F)
            if j-1 in fmts: c.number_format=fmts[j-1]
    for j,w in enumerate(widths,1): ws.column_dimensions[L(j)].width=w
    ws.freeze_panes='A2'
    if note: ws.cell(len(rows)+3,1,note).font=Font(name=F,italic=True)
    return ws
txt=[('γ・α・Ω の使い方（近さの幅つき）検証まとめ（2026-10-20）',True),
('データ：ミニ（限月調整済み）・CFD 5分足 2017〜2026/10/8。コスト：ミニ往復10円・CFD往復7円。近さの幅 b：分水嶺〜γ の幅 D に対する 0・10・20・30%。',False),
('比べる相手：分水嶺の位置だけをランダムにし、γ・α・Ω の並び方と間隔は本物と同じにした線（10種。近づく割合は20種）。',False),('',False),('■ 近くまで来る割合',True),
('・期間中に届く（または幅 b 以内まで近づく）割合：分水嶺 約65〜75%、γ 約41〜56%、Ω 約29〜47%、α 約14〜30%。γ・Ω・α に「ちょうど」届くのは半分以下。',False),
('・分水嶺だけ、でたらめな線より少し多く戻ってくる（+1〜+6%）。γ・Ω・α は同じか少ない。',False),('',False),('■ 入り方（各1,008通り）',True),
('・E1 ゾーン（分水嶺を越えたら次の線の手前で利確）と E3 近くで反発（逆張り）は、でたらめな線と同じか下。入れ子の前向きもでたらめの中央並み。',False),
('・E2 抜け（γ・α・Ω を確定足で越えたら、次の線で利確）だけ、日の線（ミニ・CFD）と CFD のセッションの線で、でたらめを上回る設定が多い（平均で、でたらめの79〜93%より上）。週の線やミニのセッションの線では差が無い。',False),
('・E2 全体（週・日・セッション）に絞った入れ子の前向きは、ミニ +12,999（でたらめ10種すべてより上）、CFD +30（でたらめの下から2番目）で、商品によって結果が割れた。',False),
('・日の線の抜けだけに絞った入れ子の前向き：ミニ +14,405、CFD +12,595（でたらめ10種の中央 約+3,100、上回る割合 90%）。毎年選ばれたのは「60分確定で上に抜けたら買い、次の線ちょうどで利確、週の分水嶺より上のときだけ」。',False),
('・ただし注意：(1) E2 に絞ったのは結果を見た後なので、それ自体が当てはめの可能性がある。(2) 利益の約半分〜6割が上位10日。(3) 2026年の上げ相場の分が大きい。(4) コスト2倍でもプラス（ミニ +6,696、CFD +13,109）。',False),
('・前日の高値・安値を抜けたら買う単純な形より、分水嶺の4本の方が良い（同じ条件で ミニ +3,041 → +16,836、CFD +2,373 → +20,620）。',False),
('・値段に対する割合で見ると、ミニの候補はコスト前で毎年プラス（年+2.9〜+16.1%）。',False),
('・週の線を条件にする（週Wと同じ側だけ）と、日の抜けの1回あたりの利益が上がる。',False),
('',False),('■ 次の一歩',True),
('・候補「日の γ・α・Ω の上抜け買い（60分確定、週Wの上だけ）」を、2026/10/9 以降の新しいデータで確かめる。成績を見ずに、このルールのまま前向きで記録する。',False)]
ws=wb.active;ws.title='まとめ'
for i,(t,b) in enumerate(txt,1):
    c=ws.cell(i,1,t);c.font=Font(name=F,bold=b,size=12 if b else 10);c.alignment=Alignment(wrap_text=True,vertical='top')
ws.column_dimensions['A'].width=115
R=pd.read_pickle('reach_sum.pkl')
rows=[[IN[r.inst],KY[r.key],LN[r.line],r.b,r.n,r.reach,r.rand,r.diff,r.rank] for r in R.sort_values(['inst','key','line','b'],ascending=[False,True,True,True]).itertuples()]
sheet('近づく割合',['商品','期間','線','近さの幅 b','数','届いた割合','でたらめ（距離そろえ）','差','でたらめ20種より上の割合'],rows,{3:PC,5:PC1,6:PC1,7:PC1,8:PC},[6,9,7,8,7,9,11,8,11],'期間の始値から見て線の手前にいる状態から、期間中に線から b×D 以内まで来た割合。始めから b×D 以内にいたものは除く。')
W=pd.read_pickle('p3_W.pkl').reset_index()
g=W.groupby(['inst','key','kind'])['rank'].agg(['mean',lambda s:(s>=0.9).mean()]).reset_index()
g.columns=['inst','key','kind','m','top']
rows=[[IN[r.inst],KY[r.key],KD[r.kind],r.m,r.top] for r in g.sort_values(['inst','kind','key'],ascending=[False,True,True]).itertuples()]
sheet('入り方別の順位',['商品','線の期間','入り方','でたらめより上の割合（平均）','上から1〜2番目の設定の割合'],rows,{3:PC,4:PC},[6,9,36,14,14],'50%なら、でたらめと区別できない。各セルは向き・入る時・近さの幅・決済・週の条件の全設定の平均。')
rows=[[IN[r.inst],KY[r.key],KD[r.kind][:2],DR[r.dir],TM[r.tim],r.b,(OP3.get(r.opt,'') if r.kind=='E3' else OP.get(r.opt,'')),WF[r.wkf],r.nf,r.np_,r.n,r.avg,r.r_med,r.r_avg,r['rank']] for _,r in W.sort_values('nf',ascending=False).iterrows()]
sheet('全設定',['商品','線の期間','入り方','向き','入る','近さの幅 b','損切り・利確','週の条件','損益 固定','損益 割合','回数','1回の粗利 pt','でたらめ 中央','でたらめ 1回の粗利','でたらめより上の割合'],rows,{8:NUM,9:NUM,12:NUM,11:P1,13:P1,14:PC},[6,8,6,8,12,8,22,20,10,10,7,9,10,10,10],'損益の大きい順。全期間の成績で選ぶと当てはめになるので、入れ子の前向きのシートと合わせて見る。')
Y=pd.concat([pd.read_pickle('p3_fut.pkl'),pd.read_pickle('p3_cfd.pkl')])
rows=[]
for nm,sub in [('全部（1,008通り）',Y),('E1 ゾーンだけ',Y[Y.kind=='E1']),('E2 抜けだけ',Y[Y.kind=='E2']),('E2 抜け・日の線だけ',Y[(Y.kind=='E2')&(Y.key=='day')]),('E3 反発だけ',Y[Y.kind=='E3'])]:
    Fn,_=nest2.nested(sub,['key','kind','dir','tim','b','opt','wkf'])
    for inst in ['fut','cfd']:
        f=Fn[Fn.inst==inst];w=f[f.fam=='W'].iloc[0];r=f[f.fam!='W']
        rows.append([nm,IN[inst],w.fwd_nf,w.fwd_np,r.fwd_nf.median(),r.fwd_nf.min(),r.fwd_nf.max(),(r.fwd_nf<w.fwd_nf).mean()])
sheet('入れ子の前向き',['候補の範囲','商品','本物 固定','本物 割合','でたらめ10種 中央','最小','最大','本物が上回る割合'],rows,{2:NUM,3:NUM,4:NUM,5:NUM,6:NUM,7:PC},[22,6,10,10,11,9,9,10],'2019〜2026年。毎年、その年より前の成績で設定を選ぶ。「E2 抜けだけ」などの範囲の絞り込みは結果を見た後なので、その分は割り引いて見る。')
D=pd.read_pickle('p3_nest_d.pkl');D=D[D.fam=='W']
_,D2=nest2.nested(Y[(Y.kind=='E2')&(Y.key=='day')],['key','kind','dir','tim','b','opt','wkf']);D2=D2[D2.fam=='W']
rows=[[nm,IN[r.inst],str(r.yr),r.pick,r.nf,r.np_] for nm,DD in [('全部',D),('E2 抜け・日',D2)] for r in DD.itertuples()]
sheet('前向き 年ごとの選択',['範囲','商品','年','選んだ設定（期間|入り方|向き|入る|b|損切り|週の条件）','損益 固定','損益 割合'],rows,{4:NUM,5:NUM},[10,6,6,44,10,10])
E=pd.read_pickle('e2chk.pkl');yc=[c for c in E.columns if c.startswith('%')]
rows=[[IN[r['inst']],r['lines'],DR[r['dir']],WF[r['wkf']],r['n'],r['nf'],r['n2'],r['avg'],r['win'],r['top10'],r['top10']/r['nf'] if r['nf']>0 else None]+[r[c]/100 for c in yc] for _,r in E.iterrows()]
sheet('候補の確認',['商品','線','向き','週の条件','回数','損益 固定','コスト2倍','1回の粗利 pt','勝率','上位10日の合計','上位10日の割合']+[c[1:]+' 粗利%' for c in yc],rows,{5:NUM,6:NUM,7:P1,8:PC,9:NUM,10:PC,**{11+i:PC1 for i in range(len(yc))}},[6,18,8,12,7,10,10,9,7,10,9]+[8]*len(yc),'候補：日の線、E2 抜け、60分確定、近さの幅0（次の線ちょうどで利確）、損切りは抜けた線の0.25D先、日の終わりで決済。粗利%は値段に対する割合の年合計（コスト前）。')
txt2=['入り方（買いの場合。売りは上下を逆）','E1 ゾーン：分水嶺を確定足で上に越えたら買い（セッション開始なら始値が分水嶺の上）。利確＝上の次の線の b×D 手前。損切り＝分水嶺の 0.25D 下、または分水嶺の下の線（α など）の b×D 上。',
'E2 抜け：γ・α・Ω のどれかを確定足で上に越えたら買い。利確＝上の次の線の b×D 手前（無ければ期間の終わりまで）。損切り＝越えた線の 0.25D 下。',
'E3 近くで反発：足の安値が下の線から b×D 以内まで来て、終値は線より上で止まったら買い（直前の確定足は b×D より上）。利確＝上の次の線の手前、または D×0.5。損切り＝線の 0.25D 下。',
'週の条件（日・セッションの線のとき）：「週Wと同じ側」＝買いは週の分水嶺より上のときだけ。「＋週の線の手前」＝さらに上の週の線まで 0.2×週の D 以上の余地があるときだけ。',
'決済：利確・損切り、またはその線の期間（セッション・日・週）の終わり。利確と損切りが同じ足なら損切りとして数える。','D＝分水嶺と γ の幅（前の期間の、終値から反対の端までの幅）。']
ws=wb.create_sheet('条件の説明')
for i,t in enumerate(txt2,1): ws.cell(i,1,t).font=Font(name=F,bold=(i==1));ws.cell(i,1).alignment=Alignment(wrap_text=True)
ws.column_dimensions['A'].width=115
wb.save('γαΩの使い方検証_2026-10-20.xlsx')
