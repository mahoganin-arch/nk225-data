import eng, numpy as np, pandas as pd, sys
RT={'fut':10,'cfd':7}
rows=[];yrs=[]
for inst in ['fut','cfd']:
    d=eng.load(inst)
    for key in ['wk','day','ses']:
        P=eng.periods(d,key)
        tfe={tf:eng.tf_end(d,key,tf) for tf in (5,15,60)}
        Ls={'W':eng.lines(P,'W'),'C':eng.lines(P,'C'),'mid':eng.lines(P,'mid')}
        for sd in range(5): Ls[f'rand{sd}']=eng.lines(P,'rand',seed=sd)
        for ln,L in Ls.items():
            for rule,mode,tf in [('A',0,5),('B5',1,5),('B15',1,15),('B60',1,60),('C5',2,5),('C15',2,15),('C60',2,60)]:
                T=eng.costs(eng.run(d,key,P,L,mode,tf,tfe=tfe[tf]),RT[inst])
                g=T.groupby('yr').net_fix.sum()
                top=T.groupby(pd.to_datetime(T.et).dt.date).net_fix.sum().sort_values(ascending=False)
                rows.append(dict(inst=inst,key=key,line=ln,rule=rule,n=len(T),gross=T.pt.sum(),net_fix=T.net_fix.sum(),net_pct=T.net_pct.sum(),
                     net_fix2=(T.pt-2*RT[inst]).sum(),win=(T.net_fix>0).mean(),avg=T.net_fix.mean(),
                     yrs_pos=(g>0).sum(),top10=top.head(10).sum()))
                for y,v in g.items(): yrs.append(dict(inst=inst,key=key,line=ln,rule=rule,yr=y,net=v,net_pct=T[T.yr==y].net_pct.sum(),n=(T.yr==y).sum()))
        print(inst,key,'done',flush=True)
R=pd.DataFrame(rows);Y=pd.DataFrame(yrs)
R.to_pickle('grid.pkl');Y.to_pickle('grid_y.pkl')
