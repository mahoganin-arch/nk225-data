import pandas as pd,numpy as np
A=pd.read_pickle('touch.pkl');A=A[A.res.isin([1,-1])].copy()
A['b']=(A.res==1).astype(int)
bins=[0,0.05,0.1,0.2,0.3,0.5,0.75,1,1.5,2,9]
A['db']=pd.cut(A.dist,bins,include_lowest=True)
out=[]
for (inst,key,xf),g in A.groupby(['inst','key','xf']):
    rd=g[g.line=='rand'];rb=rd.groupby('db',observed=False).b.mean()
    rsd=rd.b.std()
    for ln in ['Ω','γ','分水嶺','α']:
        r=g[g.line==ln]
        if len(r)<20: continue
        w=r.db.value_counts(normalize=True)
        exp=float((w*rb.reindex(w.index)).sum())
        p=r.b.mean();n=len(r);se=np.sqrt(p*(1-p)/n)
        # 年ごと（実の線−でたらめ）
        yy=[]
        for y,ry in r.groupby('yr'):
            if len(ry)<10: continue
            wy=ry.db.value_counts(normalize=True);yy.append(ry.b.mean()-float((wy*rb.reindex(wy.index)).sum()))
        out.append(dict(inst=inst,key=key,xf=xf,line=ln,n=n,bounce=p,rand_match=exp,diff=p-exp,z=(p-exp)/se,yrs_plus=sum(v>0 for v in yy),yrs=len(yy),
                        res_bounce=r[r.side==1].b.mean(),sup_bounce=r[r.side==-1].b.mean()))
O=pd.DataFrame(out);O.to_pickle('touch_sum.pkl')
pd.set_option('display.width',250);print(O.round(3).to_string())
