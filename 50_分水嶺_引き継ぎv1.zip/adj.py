import pandas as pd,numpy as np
f=pd.read_pickle('fut5.pkl');c=pd.read_pickle('cfd5.pkl')
m=f[['t','close']].merge(c[['t','close']],on='t',suffixes=('_f','_c'));m['b']=m.close_f-m.close_c
sqs=[]
for y in range(2017,2027):
  for mo in (3,6,9,12):
    d=pd.Timestamp(y,mo,1,tz='Asia/Tokyo');sqs.append(d+pd.Timedelta(days=(4-d.weekday())%7+7))
rolls=[]
for sq in sqs:
  w=m[(m.t>=sq-pd.Timedelta(days=4))&(m.t<sq+pd.Timedelta(hours=1))].reset_index(drop=True)
  if len(w)<50: continue
  bb=w.b.rolling(12,center=True,min_periods=3).median()
  # best split point
  best=None
  for i in range(24,len(w)-24):
    s=abs(w.b.iloc[i-24:i].median()-w.b.iloc[i:i+24].median())
    if best is None or s>best[0]: best=(s,i)
  i=best[1];jmp=w.b.iloc[i:i+36].median()-w.b.iloc[i-36:i].median()
  rolls.append((w.t.iloc[i],round(jmp)))
r=pd.DataFrame(rolls,columns=['t','jump']);print(r.to_string())
r.to_pickle('rolls.pkl')
# back-adjust: price before roll += jump (so old prices expressed in newer contract)
f=f.copy();adj=np.zeros(len(f))
for t,jv in zip(r.t,r.jump): adj[f.t.values<np.datetime64(t.tz_convert('UTC').tz_localize(None))]+=jv
for col in ['open','high','low','close']: f[col+'_a']=f[col]+adj
f.to_pickle('fut5a.pkl')
