# 買い向きが多い偏り（保有20本以上）の原因確認：本番と偽データで「zが正の割合」を比べる。上昇分を引く期間Wも変える
import pandas as pd, numpy as np, pickle, sys, time, warnings; warnings.filterwarnings('ignore')
import s9
from s9 import ev1,tz
def zs(B,SG,E,shift=None):
    out=[]
    for H in s9.HS:
        e=E[H]
        if shift is not None:
            e=e.copy(); w0=B['warm']; w1=B['n']-70; e[w0:w1]=np.roll(e[w0:w1],int(shift*(w1-w0)))
        for key,kn,idx in SG:
            q=ev1(idx,H,e,B['per'])
            if q[0,0]>=60 and q[1,0]>=30:
                n,mu,t=tz(q); out.append((H,key[0]=='上髭',kn=='場所不問',(t[0]+t[1])/np.sqrt(2),mu[0]*n[0]+mu[1]*n[1],n.sum()))
    return np.array(out)
if __name__=='__main__':
    res={}
    for tf in (60,30):
        B=s9.build(tf); SG=s9.sigs(B); res[tf,'real']=zs(B,SG,B['E'])
        rng=np.random.default_rng(1); res[tf,'null']=[zs(B,SG,B['E'],rng.uniform(0.1,0.9)) for r in range(40)]
        # 全足（重複なしで順に入る）の平均e：物差し自体の偏り
        res[tf,'all']={H:(np.nanmean(B['E'][H][B['valid']]),np.nanmedian(B['E'][H][B['valid']]),np.nanmean(B['X'][H][B['valid']]),np.nanmedian(B['X'][H][B['valid']])) for H in s9.HS}
        print(tf,'完了',flush=True)
    pickle.dump(res,open('bias10.pkl','wb'))
