# 掘り下げ：1時間足の大きな上髭の買い（年別・大きさ・保有本数・候補A/Bとの重なり・取引時間変更前後）と、買い向きの偏りの原因確認
import pandas as pd, numpy as np, pickle, sys, warnings; warnings.filterwarnings('ignore')
from s1 import atr_
import s9
from s5 import signals
OUT='/mnt/user-data/outputs/'
def base(tf):
    P=pickle.load(open(f'P{tf}.pkl','rb')); b=P['b']; o,h,l,c=b.open,b.high,b.low,b.close; a=atr_(h,l,c)
    return P,b,o,h,l,c,a
def exc(b,a,warm,tf,H,W=920):
    # s9 と同じ：超過x＝損益率−前後W本(1時間足換算)の平均、e＝xから時間帯×値幅5分位の平均を引いたもの
    o,h,l,c=b.open,b.high,b.low,b.close; n=len(b); ov,cv=o.values,c.values; Wb=W*60//tf
    rng=h-l; cell=b.t.dt.hour.values*5+pd.qcut((rng/a).fillna(0),5,labels=False,duplicates='drop').values
    valid=np.zeros(n,bool); valid[warm:n-70]=True
    raw=np.full(n,np.nan); raw[:n-H]=(cv[H:]-ov[1:n-H+1])/cv[:n-H]*100
    x=raw-pd.Series(raw).rolling(Wb,center=True,min_periods=Wb//2).mean().values
    g=pd.Series(np.where(valid,x,np.nan)).groupby(cell).transform('mean').values
    return raw,x,x-g,valid
def pick(mask,valid,e,H):
    out=[]; free=0
    for i in np.where(mask&valid)[0]:
        if i<free or np.isnan(e[i]): continue
        free=i+H+1; out.append(i)
    return np.array(out,int)
def st(idx,raw,x,e,cost):
    n=len(idx)
    if n<2: return dict(n=n)
    ee=e[idx]; t=ee.mean()/(ee.std(ddof=1)/np.sqrt(n)) if ee.std()>0 else np.nan
    pf=lambda v:(v[v>0].sum()/max(-v[v<=0].sum(),1e-9))
    return dict(n=n,超過平均=round(ee.mean(),4),t=round(t,2),超過PF=round(pf(x[idx]-cost[idx]),2),実PF=round(pf(raw[idx]-cost[idx]),2),実損益合計=round((raw[idx]-cost[idx]).sum(),2),勝率=round(((raw[idx]-cost[idx])>0).mean()*100,1))
def two(idx,per,raw,x,e,cost):
    a=st(idx[per[idx]==0],raw,x,e,cost); b_=st(idx[per[idx]==1],raw,x,e,cost)
    z=(a.get('t',np.nan)+b_.get('t',np.nan))/np.sqrt(2)
    r={'17-22 '+k:v for k,v in a.items()}; r.update({'23-26 '+k:v for k,v in b_.items()}); r['z']=round(z,2); return r
if __name__=='__main__':
    P,b,o,h,l,c,a=base(60); warm=P['warm']; n=len(b); per=P['per']; yr=b.t.dt.year.values; cost=(10/c*100).values
    body=(c-o).abs(); up=h-np.maximum(o,c); lo=np.minimum(o,c)-l; rng=h-l
    R={'実体の2倍':(body>0)&(up>=2*body),'実体の3倍':(body>0)&(up>=3*body),'実体の5倍':(body>0)&(up>=5*body),'値幅の50%':(rng>0)&(up>=0.5*rng),'値幅の67%':(rng>0)&(up>=0.67*rng)}
    f=lambda s:np.asarray(pd.Series(s).fillna(False),bool)
    HSX=(10,15,20,25,30,35,40,45,50,60,70,80); EX={H:exc(b,a,warm,60,H) for H in HSX}
    # 1) 大きさ×保有本数の刻み
    rows=[]
    for rk,r in R.items():
        for s in (0,0.3,0.5,0.6,0.7,0.8,0.9,1.0,1.1,1.25,1.5,1.75,2.0):
            m=f(r&(up>=s*a))
            for H in HSX:
                raw,x,e,valid=EX[H]; idx=pick(m,valid,e,H); d=dict(比率=rk,大きさ_ATR倍以上=s,保有本数=H); d.update(two(idx,per,raw,x,e,cost)); rows.append(d)
    G=pd.DataFrame(rows); G.to_csv(OUT+'stage3_2a_上髭買い_大きさ×保有本数.csv',index=False,encoding='utf-8-sig'); G.to_pickle('G10.pkl')
    # 大きさの帯（以上・未満）で分けた場合（保有40本）
    rows=[]; raw,x,e,valid=EX[40]
    for rk in ('実体の2倍','実体の3倍','値幅の67%'):
        for lo_,hi_ in ((0,0.3),(0.3,0.5),(0.5,0.7),(0.7,1.0),(1.0,1.5),(1.5,99)):
            idx=pick(f(R[rk]&(up>=lo_*a)&(up<hi_*a)),valid,e,40); d=dict(比率=rk,大きさの帯=f'ATR{lo_}〜{hi_}倍'); d.update(two(idx,per,raw,x,e,cost)); rows.append(d)
    pd.DataFrame(rows).to_csv(OUT+'stage3_2b_上髭買い_大きさの帯別.csv',index=False,encoding='utf-8-sig'); pd.DataFrame(rows).to_pickle('G10b.pkl')
    # 2) 年別（主定義3種、保有40本）
    mk=pd.Series(c.values).groupby(yr).agg(lambda s:(s.iloc[-1]/s.iloc[0]-1)*100)
    rows=[]; main={'実体の3倍・ATR以上':f(R['実体の3倍']&(up>=a)),'実体の2倍・ATR以上':f(R['実体の2倍']&(up>=a)),'値幅の67%・ATR以上':f(R['値幅の67%']&(up>=a)),'実体の2倍・ATR0.7倍以上':f(R['実体の2倍']&(up>=0.7*a))}
    for nm,m in main.items():
        idx=pick(m,valid,e,40)
        for y in range(2017,2027):
            d=dict(定義=nm,年=y,その年の騰落率=round(mk[y],1)); d.update(st(idx[yr[idx]==y],raw,x,e,cost)); rows.append(d)
    Y=pd.DataFrame(rows); Y.to_csv(OUT+'stage3_2c_上髭買い_年別.csv',index=False,encoding='utf-8-sig'); Y.to_pickle('Y10.pkl')
    # 3) 取引時間変更（2024/11）の前後
    chg=(b.t>=pd.Timestamp('2024-11-05',tz='Asia/Tokyo')).values; rows=[]
    for nm,m in main.items():
        idx=pick(m,valid,e,40)
        for lab,sel in (('2017〜22',per[idx]==0),('2023〜2024/11',(per[idx]==1)&~chg[idx]),('2024/11〜',chg[idx])):
            d=dict(定義=nm,期間=lab); d.update(st(idx[sel],raw,x,e,cost)); rows.append(d)
    C=pd.DataFrame(rows); C.to_pickle('C10.pkl')
    # 4) 候補A・Bとの重なり
    SG=signals(b,60); rows=[]; T={}
    for k in ('A','B'): T[k]=pick(SG[k][0],valid,e,40)
    for nm,m in main.items():
        idx=pick(m,valid,e,40); cov=np.zeros(n,bool)
        d=dict(定義=nm,回数=len(idx))
        for k in ('A','B'):
            cv_=np.zeros(n,bool)
            for i in T[k]: cv_[i:i+41]=True
            same=np.isin(idx,T[k]); ovl=cv_[idx]
            d[f'{k}の回数']=len(T[k]); d[f'{k}と同じ足']=int(same.sum()); d[f'{k}の保有中に発生']=int(ovl.sum())
            for lab,sel in ((f'{k}と重なる',ovl),(f'{k}と重ならない',~ovl)):
                s=st(idx[sel],raw,x,e,cost); d[lab+' n']=s.get('n'); d[lab+' t']=s.get('t'); d[lab+' 超過PF']=s.get('超過PF')
        cvA=np.zeros(n,bool)
        for k in ('A','B'):
            for i in T[k]: cvA[i:i+41]=True
        s=st(idx[~cvA[idx]],raw,x,e,cost); d['A・Bどちらとも重ならない n']=s.get('n'); d['同 t']=s.get('t'); d['同 超過PF']=s.get('超過PF'); rows.append(d)
    O=pd.DataFrame(rows); O.to_pickle('O10.pkl')
    # 逆向き：A・Bのうち「ATR以上の上髭」とそれ以外
    rows=[]
    for k in ('A','B'):
        big=f(up>=a)[T[k]]
        for lab,sel in (('上髭がATR以上',big),('上髭がATR0.5〜1.0',~big&f(up>=0.5*a)[T[k]]),('上髭がATR0.5未満',~f(up>=0.5*a)[T[k]])):
            d=dict(候補=k,区分=lab); d.update(two(T[k][sel],per,raw,x,e,cost)); rows.append(d)
    AB=pd.DataFrame(rows); AB.to_pickle('AB10.pkl')
    pd.concat([C.assign(表='取引時間変更前後'),O.assign(表='候補A・Bとの重なり'),AB.assign(表='候補A・Bの上髭の大きさ別')]).to_csv(OUT+'stage3_2d_上髭買い_時間変更・重なり.csv',index=False,encoding='utf-8-sig')
    print('完了')
