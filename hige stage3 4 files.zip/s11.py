# 第3段：髭の後の動き（a 次の足の肯定・否定、b 髭が続けて出た場合、c 4時間足・日足の髭を下位足で仕掛ける）。評価は s9 と同じ超過、偽データ＝成績系列をずらす
import pandas as pd, numpy as np, pickle, sys, time, warnings; warnings.filterwarnings('ignore')
from s1 import atr_
import s9
from s9 import ev1,ev2,tz
HS=s9.HS; OUT='/mnt/user-data/outputs/'
RT=('実体の2倍','実体の3倍','値幅の50%'); SZ=(('下限なし',0),('ATR0.5倍',0.5),('ATR0.7倍',0.7),('ATR1.0倍',1.0))
def wick(o,h,l,c,a):
    body=np.abs(c-o); up=h-np.maximum(o,c); lo=np.minimum(o,c)-l; rng=h-l; W={}
    for d,w in (('上髭',up),('下髭',lo)):
        R={'実体の2倍':(body>0)&(w>=2*body),'実体の3倍':(body>0)&(w>=3*body),'値幅の50%':(rng>0)&(w>=0.5*rng)}
        for rk in RT:
            for sk,s in SZ: W[d,rk,sk]=np.nan_to_num(R[rk]&(w>=s*a)&(a>0)).astype(bool)
    return W
def sh(x,k,fill=False):
    y=np.full(len(x),fill,dtype=x.dtype); 
    if k>0: y[k:]=x[:-k]
    return y
def groups(b,kind):
    t=b.t
    if kind=='4時間足': g=(t.dt.floor('4h')).astype('int64').values
    else:
        u=t+pd.Timedelta(hours=7.5); d=u.dt.normalize(); g=d.astype('int64').values.copy()
        day=((t.dt.hour>=9)&(t.dt.hour<15)).values; ug=np.unique(g); has={x:False for x in ug}
        for x in np.unique(g[day]): has[x]=True
        nxt=None; mp={}
        for x in ug[::-1]:
            if has[x]: nxt=x
            mp[x]=nxt if nxt is not None else x
        g=np.array([mp[x] for x in g])
    return g
def build(tf):
    P=pickle.load(open(f'P{tf}.pkl','rb')); b=P['b']; n=P['n']; B=s9.build(tf)
    o,h,l,c=(b[k].values for k in ('open','high','low','close')); a=atr_(b.high,b.low,b.close).values
    W=wick(o,h,l,c,a); S=[]   # (分類,向き,比率,大きさ,条件,マスク)
    T=np.ones(n,bool)
    def follow(d,m):
        # m：髭足のマスク（位置i）。返すのはシグナル足（i+1など）のマスク
        hi,lw=(h,l) if d=='上髭' else (-l,-h); cc=c if d=='上髭' else -c; oo=o if d=='上髭' else -o
        p=sh(m,1); ph=sh(hi,1,np.nan); pl=sh(lw,1,np.nan); r={}
        r['次足の終値が髭先を超えた（否定）']=p&(cc>ph)
        r['次足が髭先を超えたが終値は戻された']=p&(hi>ph)&(cc<=ph)
        r['次足が髭先を超えない']=p&(hi<=ph)
        r['次足の終値が髭足の反対端を抜けた（肯定）']=p&(cc<pl)
        r['次足が髭と同じ向きの色（上髭なら陰線）']=p&(cc<oo)
        r['次足が髭と逆向きの色（上髭なら陽線）']=p&(cc>oo)
        r['次足がはらみ（髭足の値幅内）']=p&(hi<=ph)&(lw>=pl)
        done=np.zeros(n,bool); f3=np.zeros(n,bool)
        for k in (1,2,3):
            x=sh(m,k)&(cc>sh(hi,k,np.nan))&~sh(done,0) if k==1 else sh(m,k)&(cc>sh(hi,k,np.nan))
            # 「最初の足」だけ：それ以前のkで超えていないこと
            prev=np.zeros(n,bool)
            for j in range(1,k): prev|=(sh(cc,k-j,np.nan)>sh(hi,k,np.nan))&sh(m,k)
            f3|=x&~prev
        r['3本以内に終値が髭先を超えた（最初の足）']=f3
        no=sh(m,3)
        for j in (0,1,2): no&=~(sh(cc,j,np.nan)>sh(hi,3,np.nan))
        r['3本たっても終値が髭先を超えない']=no
        return r
    for (d,rk,sk),m in W.items():
        for nm,x in follow(d,m).items(): S.append(('a 次の足',d,rk,sk,nm,x))
    for d in ('上髭','下髭'):
        for nm,x in follow(d,T).items(): S.append(('a 次の足',d+'の代わりに全足（対照）','-','-',nm,x))
    for (d,rk,sk),m in W.items():
        od='下髭' if d=='上髭' else '上髭'; mo=W[od,rk,sk]; tip=h if d=='上髭' else l
        for N in (3,5,10,20):
            same=np.zeros(n,bool); near=np.zeros(n,bool); opp=np.zeros(n,bool)
            for k in range(1,N+1):
                s=sh(m,k); same|=s; near|=s&(np.abs(tip-sh(tip,k,np.nan))<=0.25*a); opp|=sh(mo,k)
            S.append(('b 髭の連続',d,rk,sk,f'直前{N}本以内に同じ向きの髭',m&same)); S.append(('b 髭の連続',d,rk,sk,f'直前{N}本以内に同じ向きの髭・髭先が0.25ATR以内',m&near))
            S.append(('b 髭の連続',d,rk,sk,f'直前{N}本以内に反対向きの髭',m&opp)); S.append(('b 髭の連続',d,rk,sk,f'直前{N}本以内に同じ向きの髭なし（単発）',m&~same))
    lw_={k:v for k,v in W.items()}
    for kind in ('4時間足','日足'):
        g=groups(b,kind); df=pd.DataFrame(dict(g=g,o=o,h=h,l=l,c=c,i=np.arange(n))); G=df.groupby('g',sort=True).agg(o=('o','first'),h=('h','max'),l=('l','min'),c=('c','last'),i0=('i','first'),i1=('i','last'))
        ga=atr_(G.h,G.l,G.c).values; GW=wick(G.o.values,G.h.values,G.l.values,G.c.values,ga); i0=G.i0.values; i1=G.i1.values; ng=len(G)
        for (d,rk,sk),gm in GW.items():
            now=np.zeros(n,bool); lt=np.zeros(n,bool); brk=np.zeros(n,bool); opp=np.zeros(n,bool); ltw=W[d,'実体の2倍','ATR0.5倍']
            for j in np.where(gm)[0]:
                now[i1[j]]=True
                if j+1>=ng: continue
                s,e=i0[j+1],i1[j+1]+1
                k=np.where(ltw[s:e])[0]
                if len(k): lt[s+k[0]]=True
                up_=c[s:e]>G.h.values[j]; dn_=c[s:e]<G.l.values[j]
                tipb,endb=(up_,dn_) if d=='上髭' else (dn_,up_)
                k=np.where(tipb)[0]
                if len(k): brk[s+k[0]]=True
                k=np.where(endb)[0]
                if len(k): opp[s+k[0]]=True
            S.append(('c 上位足の髭',d,kind+'・'+rk,sk,'上位足の確定直後',now)); S.append(('c 上位足の髭',d,kind+'・'+rk,sk,'次の上位足1本の間に、下位足で同じ向きの髭（最初の足）',lt))
            S.append(('c 上位足の髭',d,kind+'・'+rk,sk,'次の上位足1本の間に、終値が髭先を超えた（最初の足）',brk)); S.append(('c 上位足の髭',d,kind+'・'+rk,sk,'次の上位足1本の間に、終値が反対端を抜けた（最初の足）',opp))
    SG=[]
    for cat,d,rk,sk,nm,m in S:
        idx=np.where(m&B['valid'])[0]; lo_=(40,20) if cat[0]=='c' else (60,30)
        if (B['per'][idx]==0).sum()>=lo_[0] and (B['per'][idx]==1).sum()>=lo_[1]: SG.append((cat,d,rk,sk,nm,idx,lo_))
    return B,SG
if __name__=='__main__':
    X={tf:build(tf) for tf in (60,30)}; print({tf:len(X[tf][1]) for tf in X},flush=True)
    if sys.argv[1]=='real':
        rows=[]
        for tf in (60,30):
            B,SG=X[tf]
            for cat,d,rk,sk,nm,idx,lo_ in SG:
                for H in HS:
                    q=ev2(idx,H,B['E'][H],B['X'][H],B['RAW'][H],B['cost'],B['per'])
                    if q[0,0]<lo_[0] or q[1,0]<lo_[1]: continue
                    n,mu,t=tz(q); z=t.sum()/np.sqrt(2); k=3 if z>0 else 5; kr=7 if z>0 else 9
                    rows.append(dict(分類=cat,足=tf,向き=d,比率=rk,大きさ=sk,条件=nm,保有本数=H,売買='買い' if z>0 else '売り',z=round(z,2),**{f'{p} 回数':int(n[i]) for i,p in enumerate(('17-22','23-26'))},**{f'{p} t':round(t[i],2) for i,p in enumerate(('17-22','23-26'))},
                        **{f'{p} 超過PF':round(q[i,k]/max(q[i,k+1],1e-9),2) for i,p in enumerate(('17-22','23-26'))},**{f'{p} 実PF':round(q[i,kr]/max(q[i,kr+1],1e-9),2) for i,p in enumerate(('17-22','23-26'))},**{f'{p} 超過平均%':round(mu[i],4) for i,p in enumerate(('17-22','23-26'))}))
        T=pd.DataFrame(rows); T.to_pickle('real11.pkl'); T.reindex(T.z.abs().sort_values(ascending=False).index).to_csv(OUT+'stage3_3_髭の後の動き_一覧.csv',index=False,encoding='utf-8-sig'); print('本番',len(T))
    else:
        rng=np.random.default_rng(int(sys.argv[2])); res=[]; t0=time.time()
        for r in range(int(sys.argv[3])):
            Z={'a':[],'b':[],'c':[]}; u=rng.uniform(0.1,0.9)
            for tf in (60,30):
                B,SG=X[tf]; w0=B['warm']; w1=B['n']-70; s_=int(u*(w1-w0))
                for H in HS:
                    e=B['E'][H].copy(); e[w0:w1]=np.roll(e[w0:w1],s_)
                    for cat,d,rk,sk,nm,idx,lo_ in SG:
                        q=ev1(idx,H,e,B['per'])
                        if q[0,0]>=lo_[0] and q[1,0]>=lo_[1]:
                            n,mu,t=tz(q); Z[cat[0]].append(t.sum()/np.sqrt(2))
            res.append({k:np.array(v,np.float32) for k,v in Z.items()})
            if r==0: print('1回',round(time.time()-t0),'秒',flush=True)
        pickle.dump(res,open(f'null11_{sys.argv[2]}.pkl','wb')); print('完了',round(time.time()-t0))
