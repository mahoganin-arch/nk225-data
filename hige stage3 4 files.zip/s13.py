# 第4段②③：決済と入り方の総当たり＋リスクの数字。売りは価格を反転して同じシミュレーターを使う
# 超過＝損益率 − 保有本数×（前後約1か月の1本あたり平均騰落率）。同じ足数だけ持った場合の上昇分を引く
import pandas as pd, numpy as np, pickle, sys, warnings; warnings.filterwarnings('ignore')
from numba import njit
from s1 import rma,rsi_,atr_,ichi
import s9, s11
OUT='/mnt/user-data/outputs/'; INF=1e18
@njit(cache=True)
def sim(sig,o,h,l,c,atr,em,elv,enb,stA,stR,tgA,tgR,tgRR,tgDyn,useDyn,trm,trk,trArr,beK,pA,pR,cutN,exA,endA,tmax):
    n=len(c); m=len(sig); R=np.full(m,np.nan); HL=np.zeros(m); J=np.zeros(m,np.int64); free=0
    for s in range(m):
        i=sig[s]
        if i<free or i+enb+2>=n-2: continue
        a=atr[i]; j=-1; e=0.0
        if em==0: j=i+1; e=o[j]
        elif em==1:
            for q in range(i+1,i+1+enb):
                if h[q]>=elv[i]: j=q; e=max(elv[i],o[q]); break
        elif em==2:
            for q in range(i+1,i+1+enb):
                if l[q]<=elv[i]: j=q; e=min(elv[i],o[q]); break
        else: j=i+1+enb; e=o[j]
        if j<0: continue
        st=max(stA[i],e-stR[i]) if stR[i]<1e17 else stA[i]
        if st>=e: st=e-0.25*a
        tg=INF
        if tgA[i]>e+5: tg=tgA[i]
        if tgR[i]<1e17: tg=min(tg,e+tgR[i])
        if tgRR>0 and st>-1e17: tg=min(tg,e+tgRR*(e-st))
        pl=INF
        if pA[i]>e+5: pl=pA[i]
        if pR[i]<1e17: pl=min(pl,e+pR[i])
        hh=e; x=np.nan; banked=False; pv=0.0; t=j
        while True:
            if useDyn: tg=tgDyn[t-1] if tgDyn[t-1]>e else INF
            if t>j and o[t]<=st: x=o[t]
            elif l[t]<=st and not (t==j and em==1 and st>=o[t]): x=st
            if np.isnan(x) and not (t==j and em==2):
                if not banked and h[t]>=pl: banked=True; pv=max(pl,o[t]) if t>j else pl
                if t>j and o[t]>=tg: x=o[t]
                elif h[t]>=tg: x=tg
            if np.isnan(x) and (exA[t] or endA[t] or t-j+1>=tmax or t>=n-2): x=c[t]
            if np.isnan(x) and cutN>0 and t-j+1==cutN and c[t]<=e: x=c[t]
            if not np.isnan(x): break
            if h[t]>hh: hh=h[t]
            if trm==1: st=max(st,hh-trk*a)
            elif trm==2: st=max(st,c[t]-trk*a)
            elif trm==3: st=max(st,trArr[t])
            if beK>0 and hh>=e+beK*a: st=max(st,e)
            t+=1
        pnl=(x-e) if not banked else 0.5*(pv-e)+0.5*(x-e)
        R[s]=(pnl-10)/abs(c[i])*100; HL[s]=t-j+1; J[s]=j; free=t+1
    return R,HL,J
def prep(tf,mirror):
    P=pickle.load(open(f'P{tf}.pkl','rb')); b=P['b']; n=P['n']; o,h,l,c=b.open,b.high,b.low,b.close; v=b.volume
    r1=(c.pct_change()*100); Wb=920*60//tf; drift=r1.rolling(Wb,center=True,min_periods=Wb//2).mean().values*(-1 if mirror else 1)
    gd=s11.groups(b,'日足'); gw=(pd.to_datetime(gd)-pd.to_timedelta(pd.to_datetime(gd).weekday,unit='D')).asi8
    tp=((h+l+c)/3*v).groupby(gd).cumsum(); vw=(tp/v.groupby(gd).cumsum().replace(0,np.nan)).ffill()
    if mirror: o,h,l,c,vw=-o,-l,-h,-c,-vw
    a=atr_(h,l,c); A=dict(o=o.values,h=h.values,l=l.values,c=c.values,atr=a.values,drift=drift,n=n,per=P['per'],yr=b.t.dt.year.values,warm=P['warm'])
    body=(c-o).abs(); up=h-np.maximum(o,c); lo=np.minimum(o,c)-l; A['up']=up.values; A['lo']=lo.values; A['body']=body.values; A['rng']=(h-l).values
    for k in (5,10,20): A[f'low{k}']=l.rolling(k).min().values
    for k in (20,50): A[f'high{k}']=h.rolling(k).max().values
    s20=c.rolling(20).mean(); sd=c.rolling(20).std(ddof=0); A['bbU']=(s20+2*sd).values; A['vwap']=vw.values
    for nm,g in (('日次',gd),('週次',gw)):
        G=pd.DataFrame(dict(g=g,h=h.values,l=l.values,c=c.values)).groupby('g').agg(h=('h','max'),l=('l','min'),c=('c','last')).shift(1); Pv=(G.h+G.l+G.c)/3
        A[nm+'P']=pd.Series(g).map(Pv).values; A[nm+'R1']=pd.Series(g).map(2*Pv-G.l).values
        if nm=='日次': A['前日高値']=pd.Series(g).map(G.h).values
    ten,kij,ct,cb=ichi(h,l,c); r=rsi_(c); hc=(o+h+l+c)/4; ho=hc.ewm(alpha=0.5,adjust=False).mean().shift()
    mm=c.ewm(span=12,adjust=False).mean()-c.ewm(span=26,adjust=False).mean(); sg=mm.ewm(span=9,adjust=False).mean()
    X={'平均足が陰転':hc<ho,'RSIが50割れ':(r<50)&(r.shift()>=50),'遅行線が26本前の終値割れ':c<c.shift(25),'終値がSMA20割れ':c<s20,'終値が基準線割れ':c<kij,'終値が転換線割れ':c<ten,
       'MACDがシグナル割れ':(mm<sg)&(mm.shift()>=sg.shift()),'終値が雲の下限割れ':c<pd.Series(cb,index=c.index),'陰線2連続':(c<o)&(c.shift()<o.shift()),'前の足の安値を終値で割る':c<l.shift(),
       '反対向きの大きな髭':(body>0)&(lo>=2*body)&(lo>=0.7*a),'同じ向きの大きな髭が再発':(body>0)&(up>=2*body)&(up>=0.7*a)}
    A['X']={k:np.asarray(pd.Series(x).fillna(False),bool) for k,x in X.items()}
    gap=(b.m.shift(-1)-b.m>tf*1.5).values; hr=b.t.dt.hour.values; day=(hr>=8)&(hr<16)
    A['E']={'セッション引け':gap,'日中引け':gap&day,'夜間引け':gap&~day,'週末引け':(b.m.shift(-1)-b.m>60*30).values}
    return A
def exits(base):
    L=[]
    def add(nm,cat,T=None,**k):
        for t in ((T,) if T else base):
            d=dict(nm=nm+(f' +{t}本' if not T else ''),cat=cat,tmax=t if not T else T,st=None,tg=None,rr=0,dyn=None,trm=0,trk=0,tra=None,be=0,part=None,cut=0,ex=None,en=None); d.update(k); L.append(d)
    for t in (1,2,3,5,10,15,20,30,40,50,60,80): add(f'{t}本後','時間',T=t)
    for k in ('セッション引け','日中引け','夜間引け','週末引け'): add(k,'時間',T=400,en=k)
    ST=[('シグナル足の反対端',('abs','l',0)),('反対端から0.25ATR外',('abs','l',-0.25)),('シグナル足の実体の端',('abs','bodylo',0))]+[(f'ATR{k}倍',('atr',k)) for k in (1,1.5,2,3,4)]+[(f'{k}%',('pct',k)) for k in (0.5,1,2)]+[(f'直近{k}本安値',('abs',f'low{k}',0)) for k in (5,10,20)]
    TG=[('髭の先端',('abs','h')),('髭の中間',('abs','wmid'))]+[(f'髭の長さの{k}倍',('wick',k)) for k in (1,2,3)]+[(f'シグナル足の値幅の{k}倍',('rng',k)) for k in (1,2)]+[(f'ATR{k}倍',('atr',k)) for k in (1,2,3,5)]+[(k,('abs',k)) for k in ('週次P','週次R1','日次P','日次R1','前日高値','vwap','high20','high50')]
    for nm,s in ST: add('損切り:'+nm,'損切り',st=s)
    for nm,g in TG: add('利確:'+nm,'利確',tg=g)
    add('利確:BB+2σ到達','利確',dyn='bbU')
    for sn,s in (('ATR1.5倍',('atr',1.5)),('ATR2倍',('atr',2)),('反対端',('abs','l',0))):
        for k in (1,2,3): add(f'損切り{sn}・利確はその{k}倍','損切り+利確',st=s,rr=k)
    for sn,s in (('ATR2倍',('atr',2)),('ATR3倍',('atr',3)),('反対端',('abs','l',0))):
        for gn,g in (('髭の先端',('abs','h')),('髭の長さの2倍',('wick',2)),('ATR3倍',('atr',3))): add(f'損切り{sn}・利確{gn}','損切り+利確',st=s,tg=g)
    for k in (2,3,4): add(f'トレール:高値からATR{k}倍','追随',st=('atr',k),trm=1,trk=k)
    for k in (2,3): add(f'トレール:終値からATR{k}倍','追随',st=('atr',k),trm=2,trk=k)
    for k in (5,10,20): add(f'トレール:直近{k}本安値','追随',st=('abs',f'low{k}',0),trm=3,tra=f'low{k}')
    for k in (1,2): add(f'建値移動(+{k}ATRで)・損切りなし','追随',be=k); add(f'建値移動(+{k}ATRで)・損切りATR2倍','追随',st=('atr',2),be=k)
    for nm,g in (('ATR1倍',('atr',1)),('ATR2倍',('atr',2)),('髭の先端',('abs','h'))): add(f'半分を{nm}で利確・残りは時間','分割',part=g)
    for k in (3,5,10): add(f'見切り:{k}本目の終値で含み益なしなら撤退','見切り',cut=k)
    for k in ('反対向きの大きな髭','同じ向きの大きな髭が再発'): add('反対シグナル:'+k if k[0]=='反' else '再シグナル:'+k,'シグナル',ex=k)
    for k in ('平均足が陰転','RSIが50割れ','遅行線が26本前の終値割れ','終値がSMA20割れ','終値が基準線割れ','終値が転換線割れ','MACDがシグナル割れ','終値が雲の下限割れ','陰線2連続','前の足の安値を終値で割る'): add('指標:'+k,'指標',ex=k)
    return L
ENT=[('成行（次の足の始値）',0,None,1),('髭の先端+5円の逆指値（3本以内）',1,'h5',3),('髭の中間の逆指値（3本以内）',1,'wmid',3),('終値−0.25ATRの指値（5本以内）',2,'c25',5),('終値−0.5ATRの指値（5本以内）',2,'c50',5),('シグナル足の反対端の指値（5本以内）',2,'l',5),('2本遅らせて成行',3,None,2),('4本遅らせて成行',3,None,4)]
def lv(A,key,off=0):
    n=A['n']
    if key=='l': return A['l']+off*A['atr']
    if key=='h': return A['h']
    if key=='h5': return A['h']+5
    if key=='bodylo': return np.minimum(A['o'],A['c'])
    if key=='wmid': return A['h']-A['up']/2
    if key=='c25': return A['c']-0.25*A['atr']
    if key=='c50': return A['c']-0.5*A['atr']
    return A[key]
def run(A,sig,x,ent):
    n=A['n']; ninf=np.full(n,-INF); pinf=np.full(n,INF); zb=np.zeros(n,bool)
    stA,stR=ninf,pinf
    if x['st']:
        s=x['st']
        if s[0]=='abs': stA=np.nan_to_num(lv(A,s[1],s[2])-5,nan=-INF)
        elif s[0]=='atr': stR=s[1]*A['atr']
        else: stR=s[1]/100*np.abs(A['c'])
    def tgt(g):
        tA,tR=pinf,pinf
        if g:
            if g[0]=='abs': tA=np.nan_to_num(lv(A,g[1]),nan=INF)
            elif g[0]=='atr': tR=g[1]*A['atr']
            elif g[0]=='wick': tR=g[1]*A['up']
            else: tR=g[1]*A['rng']
        return tA,tR
    tgA,tgR=tgt(x['tg']); pA,pR=tgt(x['part'])
    enm,em,ek,enb=ent; elv=lv(A,ek) if ek else pinf
    return sim(sig,A['o'],A['h'],A['l'],A['c'],A['atr'],em,elv,enb,stA,stR,tgA,tgR,float(x['rr']),A[x['dyn']] if x['dyn'] else pinf,bool(x['dyn']),x['trm'],float(x['trk']),A[x['tra']] if x['tra'] else ninf,float(x['be']),pA,pR,x['cut'],
               A['X'][x['ex']] if x['ex'] else zb,A['E'][x['en']] if x['en'] else zb,x['tmax'])
def stats(A,sig,R,HL,J):
    ok=~np.isnan(R); out={}; ts=[]
    ex=R-HL*np.nan_to_num(A['drift'][J])
    for p,lab in ((0,'17-22'),(1,'23-26')):
        m=ok&(A['per'][sig]==p); r=R[m]; e=ex[m]; k=len(r)
        if k<15: out[lab+' 回数']=k; ts.append(np.nan); continue
        pf=lambda v:round(v[v>0].sum()/max(-v[v<=0].sum(),1e-9),2); t=e.mean()/(e.std(ddof=1)/np.sqrt(k)); ts.append(t); cs=np.cumsum(r)
        out.update({lab+' 回数':k,lab+' 実PF':pf(r),lab+' 超過PF':pf(e),lab+' 超過t':round(t,2),lab+' 実損益合計%':round(r.sum(),1),lab+' 超過合計%':round(e.sum(),1),lab+' 勝率':round((r>0).mean()*100,1),lab+' 平均保有本数':round(HL[m].mean(),1),
                    lab+' 最大損失%':round(r.min(),2),lab+' 最大ドローダウン%':round((np.maximum.accumulate(np.r_[0,cs])-np.r_[0,cs]).max(),1)})
    out['z']=round((ts[0]+ts[1])/np.sqrt(2),2); return out
def family(name,tf,mirror,sig,base,baseT):
    A=prep(tf,mirror); EX=exits(base); rows=[]
    for ent in ENT:
        for x in EX:
            R,HL,J=run(A,sig,x,ent); d=dict(対象=name,入り方=ent[0],分類=x['cat'],決済=x['nm']); d.update(stats(A,sig,R,HL,J)); rows.append(d)
    T=pd.DataFrame(rows); return T
if __name__=='__main__':
    P=pickle.load(open('P60.pkl','rb')); b=P['b']; n=P['n']; o,h,l,c=(b[k].values for k in ('open','high','low','close')); a=atr_(b.high,b.low,b.close).values
    body=np.abs(c-o); up=h-np.maximum(o,c); valid=np.zeros(n,bool); valid[P['warm']:n-90]=True
    F=[]
    F.append(('1時間足・上髭（実体の2倍・ATR0.7倍以上）の買い',60,False,np.where((body>0)&(up>=2*body)&(up>=0.7*a)&valid)[0],(20,40,60),40))
    F.append(('1時間足・上髭（実体の3倍・ATR1.0倍以上）の買い',60,False,np.where((body>0)&(up>=3*body)&(up>=1.0*a)&valid)[0],(20,40,60),40))
    B=s9.build(30); SG=s9.sigs(B); key=('下髭','値幅の50%','ATR0.5倍','陰線','終値不問','反対髭ほぼなし')
    hit=[x for x in SG if x[0]==key and x[1]=='髭先が500円の節目を突いて戻る']; print('売り候補',len(hit),[len(x[2]) for x in hit])
    if hit: F.append(('30分足・下髭陰線（値幅の50%・ATR0.5倍以上・反対髭ほぼなし）が500円節目を突いて戻った後の売り',30,True,hit[0][2].astype(np.int64),(3,10,20),1))
    allT=[]
    for nm,tf,mir,sig,base,bt in F:
        T=family(nm,tf,mir,sig.astype(np.int64),base,bt); allT.append(T); print(nm,len(T),flush=True)
    T=pd.concat(allT); T.to_pickle('ex13.pkl'); T.to_csv(OUT+'stage4_2_決済と入り方_一覧.csv',index=False,encoding='utf-8-sig')
