# 第4段①：髭の後の経路（1本ごとの終値位置・上方向の最大幅・下方向の最大幅、髭先・反対端への到達率）。単位はシグナル足のATR。対照＝同じ年の全足
import pandas as pd, numpy as np, pickle, warnings; warnings.filterwarnings('ignore')
from numba import njit
from s1 import atr_
OUT='/mnt/user-data/outputs/'; KS=np.array([1,2,3,5,10,15,20,30,40,50,60]); KM=60
@njit(cache=True)
def path(idx,o,h,l,c,a,KM):
    m=len(idx); R=np.full((m,KM),np.nan); U=np.full((m,KM),np.nan); D=np.full((m,KM),np.nan); TH=np.zeros((m,KM)); TL=np.zeros((m,KM))
    for j in range(m):
        i=idx[j]; e=o[i+1]; hi=-1e18; lo=1e18
        for k in range(1,KM+1):
            hi=max(hi,h[i+k]); lo=min(lo,l[i+k])
            R[j,k-1]=(c[i+k]-e)/a[i]; U[j,k-1]=(hi-e)/a[i]; D[j,k-1]=(e-lo)/a[i]; TH[j,k-1]=hi>h[i]; TL[j,k-1]=lo<l[i]
    return R,U,D,TH,TL
def pick(mask,H):
    out=[]; free=0
    for i in np.where(mask)[0]:
        if i<free: continue
        free=i+H+1; out.append(i)
    return np.array(out,np.int64)
def load(tf):
    P=pickle.load(open(f'P{tf}.pkl','rb')); b=P['b']; n=P['n']; o,h,l,c=(b[k].values for k in ('open','high','low','close')); a=atr_(b.high,b.low,b.close).values
    valid=np.zeros(n,bool); valid[P['warm']:n-70]=True; return b,n,o,h,l,c,a,valid,b.t.dt.year.values
if __name__=='__main__':
    rows=[]; keep={}
    for tf in (60,30):
        b,n,o,h,l,c,a,valid,yr=load(tf); body=np.abs(c-o); up=h-np.maximum(o,c); lo=np.minimum(o,c)-l
        allidx=np.where(valid)[0][::3]; RA,UA,DA,THA,TLA=path(allidx,o,h,l,c,a,KM); ya=yr[allidx]
        for d,w in (('上髭',up),('下髭',lo)):
            for lab,s0,s1 in (('ATR0.5倍未満',0,0.5),('ATR0.5〜0.7倍',0.5,0.7),('ATR0.7〜1.0倍',0.7,1.0),('ATR1.0倍以上',1.0,99),('ATR0.7倍以上',0.7,99)):
                m=(body>0)&(w>=2*body)&(w>=s0*a)&(w<s1*a)&valid; idx=pick(m,40); R,U,D,TH,TL=path(idx,o,h,l,c,a,KM); ys=yr[idx]
                wt=np.array([(ys==y).sum()/max((ya==y).sum(),1) for y in ya]); wt=wt/wt.sum()   # 対照は年の構成をそろえる
                keep[tf,d,lab]=(idx,R,U,D)
                for k in KS:
                    r=R[:,k-1]; br=(RA[:,k-1]*wt).sum(); sd=r.std(ddof=1)/np.sqrt(len(r))
                    rows.append(dict(足=tf,向き=d,大きさ=lab,回数=len(idx),経過本数=k,終値位置_平均=round(r.mean(),3),終値位置_対照=round(br,3),差のt=round((r.mean()-br)/sd,2),終値位置_中央値=round(np.median(r),3),プラスの割合=round((r>0).mean()*100,1),
                        上方向の最大幅_中央値=round(np.median(U[:,k-1]),2),上方向_対照=round(np.median(UA[:,k-1]),2),下方向の最大幅_中央値=round(np.median(D[:,k-1]),2),下方向_対照=round(np.median(DA[:,k-1]),2),
                        下方向_上位25pct=round(np.percentile(D[:,k-1],75),2),下方向_上位10pct=round(np.percentile(D[:,k-1],90),2),髭足の高値を超えた割合=round(TH[:,k-1].mean()*100,1),高値超え_対照=round((THA[:,k-1]*wt).sum()*100,1),髭足の安値を割った割合=round(TL[:,k-1].mean()*100,1),安値割れ_対照=round((TLA[:,k-1]*wt).sum()*100,1)))
    T=pd.DataFrame(rows); T.to_csv(OUT+'stage4_1_髭の後の経路.csv',index=False,encoding='utf-8-sig'); T.to_pickle('path12.pkl'); pickle.dump(keep,open('keep12.pkl','wb')); print(len(T))
