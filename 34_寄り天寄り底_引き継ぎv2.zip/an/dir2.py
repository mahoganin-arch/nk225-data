# 寄り天（上の動きに売り）と寄り底（下の動きに買い）を分けた成績：日中の残った候補
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/home/claude/yt/an')
from detail2 import trades, stats, YEARS, O, neighbors
X=pd.read_pickle(O+'cand2.pkl'); X=X[X.区分=='D']
EV=pd.read_pickle(O+'EV2_D.pkl')
rows=[]; yrows=[]
for _,r in X.iterrows():
    st=pd.read_pickle(O+'E2_D_store.pkl')[(r.観察,r.向き,r.入る)]; S,C,M=st
    EXd=pd.read_pickle(O+'EXITS.pkl')['D']; NB=neighbors(EXd) if r.選び方=='周辺' else None
    yi={y:k for k,y in enumerate(YEARS)}
    def pick(tr):
        a=[yi[y] for y in tr]; sm=S[:,a].sum(1); cn=C[:,a].sum(1); mn=M[:,a].min(1)
        mean=np.where(cn>0,sm/np.maximum(cn,1),np.nan); ok=(cn>=15)&(mn>=-1000)
        sc=mean if NB is None else np.array([np.nanmean(mean[nb]) for nb in NB])
        return int(np.argmax(np.nan_to_num(np.where(ok,sc,-np.inf),nan=-np.inf)))
    dF=trades('D','E2',r.観察,r.向き,r.入る,{y:pick(range(2017,y)) for y in range(2022,2027)})
    now=pick(range(2017,2026)); dN=trades('D','E2',r.観察,r.向き,r.入る,{y:now for y in range(2017,2027)})
    for lab,sel in [('売り（寄り天）',-1),('買い（寄り底）',1)]:
        a=dF[dF.d==sel]; b=dN[dN.d==sel]
        row=dict(id=r.id,観察=r.観察,入る=r.入る,選び方=r.選び方,売買=lab)
        row.update({'前向き_'+k:v for k,v in stats(a).items()})
        b1=b[pd.to_datetime(b.t).dt.year<=2021]; b2=b[pd.to_datetime(b.t).dt.year>=2022]
        row.update({'今_前半_'+k:v for k,v in stats(b1).items() if k in('件数','PF','平均')})
        row.update({'今_後半_'+k:v for k,v in stats(b2).items() if k in('件数','PF','平均')})
        rows.append(row)
        for y in range(2017,2027):
            dy=b[pd.to_datetime(b.t).dt.year==y]; yrows.append(dict(id=r.id,観察=r.観察,入る=r.入る,選び方=r.選び方,売買=lab,年=y,件数=len(dy),合計=dy.v.sum()))
T=pd.DataFrame(rows); Y=pd.DataFrame(yrows); pd.to_pickle((T,Y),O+'dir2.pkl')
pd.set_option('display.width',300); pd.set_option('display.max_rows',300)
c=['id','観察','入る','選び方','売買','前向き_件数','前向き_勝率','前向き_PF','前向き_平均','前向き_合計','今_前半_件数','今_前半_平均','今_後半_件数','今_後半_平均']
top=[34,23,10,14,18,19,26,24,28,7,8]
print(T[T.id.isin(top)][c].round(1).to_string())
s=T.groupby('売買')[['前向き_合計','前向き_件数']].sum(); print(s)
print('前向きプラスの候補数', T.groupby('売買').apply(lambda d:(d.前向き_合計>0).sum()).to_dict(), '/', T.id.nunique())
yy=Y[Y.id.isin([34,23,18])].pivot_table(index='年',columns=['id','売買'],values='合計').round(0); print(yy.to_string())
