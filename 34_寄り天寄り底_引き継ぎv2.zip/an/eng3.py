# 高値引け・安値引けの後の売買（総当たり）
#   観察：引けの位置（x＝引けの位置−0.5、高値引けほど＋）と、最後30分の動き（先物）
#   入る：引けの直後(引)・引け+15分・夜間の寄りの15分前(寄-15)・寄り・寄り+5・寄り+15、
#        確かめてから c25/c50（引けの後、CFD が mv の25%/50% 入る向きに動いたら次の足、60分以内）
#   手じまい：eng.py の夜間の格子（時間は入ってから、最後は夜間の 5:55）
#   出力：out/E2_H_meta.pkl, out/E2_H_R.npy
import numpy as np, pandas as pd, sys
from multiprocessing import Pool
sys.path.insert(0, '/home/claude/yt/an')
import eng
from eng import sim, O, CM, CO, px

def events():
    E = pd.read_pickle(O + 'close_ev.pkl'); rows = []
    for r in E.itertuples():
        c0 = px(CM, CO, np.array([r.close_t]))[0]
        if not np.isfinite(c0): continue
        for obs, x, mv in [('引けの位置', r.clv - 0.5, 0.5 * r.rng * c0), ('最後30分', r.last30, abs(r.last30) * c0)]:
            if not np.isfinite(x) or x == 0 or mv <= 0: continue
            sx = int(np.sign(x))
            for dn, d in [('順張り', sx), ('逆張り', -sx)]:
                ents = [('引', r.close_t), ('引+15', r.close_t + 15), ('寄-15', r.open_n - 15), ('寄', r.open_n), ('寄+5', r.open_n + 5), ('寄+15', r.open_n + 15)]
                for c in ['c25', 'c50']:
                    te = eng.confirm(d, r.close_t, c0, float(c[1:]) / 100 * mv, 60, d)
                    if te is not None: ents.append((c, te))
                for en, te in ents:
                    rows.append(dict(sid=r.i, m0=r.close_t, t=r.t, 観察=obs, 向き=dn, 入る=en, d=d, x=x, mv=mv, te=te, tcap=r.cap_n, tam=np.nan, tpk=np.nan, ext=np.nan))
    return pd.DataFrame(rows)

if __name__ == '__main__':
    ev = events(); print(len(ev), flush=True)
    args = [(r.d, r.te, r.mv, r.tcap, None, 'N') for r in ev.itertuples()]
    with Pool(2) as p: R = np.vstack(p.map(sim, args, chunksize=1000))
    ev.to_pickle(O + 'E2_H_meta.pkl'); np.save(O + 'E2_H_R.npy', R.astype(np.float16))
    print(R.shape, np.isnan(R).mean(), ev.groupby('入る').size().to_dict())
