# 天井の形ごとの成績：天井が「観察中（9:00まで）」「9:00〜9:05」「9:05〜9:10」…のどこで付いたか
#   逆張り、決済は固定（損切り0.8%・利確なし・引けまで／前場引けまで）。強さは上位10%（前半の分布）。
import numpy as np, pandas as pd, sys
O='/home/claude/yt/out/'
EX=pd.read_pickle(O+'EXITS.pkl')['D']
def col(tp,sl,tm): return EX[(EX.型=='%')&(EX.利確==tp)&(EX.損切り==sl)&(EX.時間==tm)].index[0]
CUTS=[('引けまで',col(np.inf,0.8,'C')),('前場引けまで',col(np.inf,0.8,'AM')),('120分',col(np.inf,0.8,120))]
BINS=[-2,0,5,10,15,30,91]; BN=['観察中(9:00まで)','0-5分','5-10分','10-15分','15-30分','30-90分']
rows=[]; yrows=[]
for fam,base in [('D','8:45→9:00'),('K','9:45→10:00')]:
    meta=pd.read_pickle(O+f'E2_{fam}_meta.pkl'); R=np.load(O+f'E2_{fam}_R.npy',mmap_mode='r')
    for ob in sorted(meta.観察.unique()):
        u=meta[meta.観察==ob].drop_duplicates('sid'); a=np.abs(u.x.values)[u.t.dt.year.values<=2021]
        cut=np.quantile(a,0.9); cut33=np.quantile(a,0.67)
        for ent in ['pkK25','pkP10','前足5','RSI5','HA5']:
            g=meta[(meta.観察==ob)&(meta.向き=='逆張り')&(meta.入る==ent)]
            for gn,cc in [('上位10%',cut),('上位33%',cut33)]:
                gg=g[np.abs(g.x)>=cc].copy()
                gg['bin']=pd.cut(gg.tpk.fillna(-1).where(gg.tpk>=0,-1),BINS,right=False,labels=BN)
                for cn,ci in CUTS:
                    v=np.asarray(R[gg.index.values,ci],dtype=np.float32); gg['v']=v
                    for (b,hf),d in gg.groupby(['bin',np.where(gg.t.dt.year<=2021,'前半','後半')],observed=True):
                        d=d.dropna(subset=['v'])
                        if len(d)<5: continue
                        rows.append(dict(区分=fam,観察=ob,入る=ent,強さ=gn,決済=cn,天井=b,期間=hf,n=len(d),平均=d.v.mean(),t=d.v.mean()/d.v.std()*np.sqrt(len(d)),勝率=(d.v>0).mean()*100))
                    if gn=='上位10%' and cn=='引けまで':
                        for y,d in gg.dropna(subset=['v']).groupby(gg.t.dt.year):
                            yrows.append(dict(区分=fam,観察=ob,入る=ent,年=y,n=len(d),平均=d.v.mean()))
T=pd.DataFrame(rows); Y=pd.DataFrame(yrows); pd.to_pickle((T,Y),O+'shape.pkl')
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
sel=T[(T.決済=='引けまで')&(T.強さ=='上位10%')&(T.入る.isin(['pkK25','RSI5']))&(T.観察.isin(['8:45→9:00','8:45→9:05','9:45→10:00','9:45→10:05']))]
print(sel.pivot_table(index=['区分','観察','入る','天井'],columns='期間',values=['n','平均','t'],observed=True).round(1).to_string())
yy=Y[(Y.入る.isin(['pkK25','RSI5']))&(Y.観察.isin(['8:45→9:00','8:45→9:05','9:45→10:00']))]
print(yy.pivot_table(index='年',columns=['観察','入る'],values='平均').round(0).to_string())
