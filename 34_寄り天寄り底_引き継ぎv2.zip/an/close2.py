# 高値引けと安値引けを分けて：引け後〜夜間の動き（CFD、bp、上＝＋）
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/home/claude/yt/an')
from ev import CM,CO,px,O
E=pd.read_pickle(O+'close_ev.pkl'); yr=E.t.dt.year.values; H1=yr<=2021
ct=E.close_t.values; on=E.open_n.values
P={'引け':px(CM,CO,ct),'引け+30分':px(CM,CO,ct+30),'寄りの15分前':px(CM,CO,on-15),'夜間の寄り':px(CM,CO,on),'寄り+60分':px(CM,CO,on+60),'夜間の引け':px(CM,CO,E.cap_n.values)}
rows=[]
for gn,gm in [('高値引け(上10%)',E.clv>=0.9),('安値引け(下10%)',E.clv<=0.1),('すべての日',E.clv>=0)]:
    for a,b in [('引け','引け+30分'),('引け','寄りの15分前'),('寄りの15分前','夜間の寄り'),('引け','夜間の寄り'),('夜間の寄り','寄り+60分'),('夜間の寄り','夜間の引け'),('引け','夜間の引け')]:
        z=(P[b]/P[a]-1)*1e4; r=dict(区分=gn,区間=f'{a}→{b}')
        for hn,hm in [('前半',H1),('後半',~H1)]:
            k=gm.values&hm&np.isfinite(z); zz=z[k]; r[hn+'_n']=k.sum(); r[hn+'_bp']=zz.mean(); r[hn+'_t']=zz.mean()/zz.std()*np.sqrt(len(zz))
        rows.append(r)
T=pd.DataFrame(rows); T.to_pickle(O+'close2.pkl'); pd.set_option('display.width',200); print(T.round(1).to_string())
