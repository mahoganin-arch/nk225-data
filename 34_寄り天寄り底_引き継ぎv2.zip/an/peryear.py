# 残った候補：前向き（WF全期間：各年はその年より前で選んだルール）の年ごと、今のルールの年ごと
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/home/claude/yt/an')
from evalu import *
T=pd.read_pickle(O+'EV0.pkl'); T=T[(T.プラスの数>=3)&(T.中央>=20)&(T.年件数_中央>=10)]
rows=[]
for _,r in T.iterrows():
    fam=r.区分; meta=pd.read_pickle(O+f'E_{fam}_meta.pkl'); R=np.load(O+f'E_{fam}_R.npy')
    EXd=pd.read_pickle(O+'EXITS.pkl')['D' if fam=='D' else 'N']; nE=len(EXd); NB=neighbors(EXd) if r.選び方=='周辺' else None
    yrs=meta.t.dt.year.values; ax=np.abs(meta.x.values)
    sel=(meta.観察==r.観察)&(meta.向き==r.向き)&(meta.入る==r.入る); idx=np.where(sel)[0]
    o=(meta.観察==r.観察).values
    cuts=[np.quantile(ax[o&(yrs<=2021)],q) if q>0 else 0 for q in QS]
    S=[];C=[];M=[];TR=[]
    for cut in cuts:
        mk=np.zeros(len(meta),bool); mk[idx]=ax[idx]>=cut
        s_,c_,m_=yearly(R,yrs,mk); S.append(s_);C.append(c_);M.append(m_)
    S=np.vstack(S);C=np.vstack(C);M=np.vstack(M)
    yi={y:k for k,y in enumerate(YEARS)}
    def pick(tr):
        a=[yi[y] for y in tr]; sm=S[:,a].sum(1); cn=C[:,a].sum(1); mn=M[:,a].min(1)
        mean=np.where(cn>0,sm/np.maximum(cn,1),np.nan); ok=(cn>=15)&(mn>=-1000)
        sc=mean if NB is None else np.array([np.nanmean(mean[nb]) for nb in NB])
        sc=np.nan_to_num(np.where(ok,sc,-np.inf),nan=-np.inf); return int(np.argmax(sc))
    row=dict(区分=fam,観察=r.観察,向き=r.向き,入る=r.入る,選び方=r.選び方)
    tot=0;cnt=0
    for y in range(2022,2027):
        k=pick(range(2017,y)); b=yi[y]; row[f'前向き{y}']=S[k,b]/C[k,b] if C[k,b] else np.nan; row[f'件{y}']=C[k,b]; tot+=S[k,b]; cnt+=C[k,b]
    row['前向き合計']=tot; row['前向き件数']=cnt
    k=pick(range(2017,2026))
    for y in range(2017,2027): b=yi[y]; row[f'今{y}']=S[k,b]/C[k,b] if C[k,b] else np.nan
    a=[yi[y] for y in range(2017,2022)]; row['今_前半平均']=S[k,a].sum()/C[k,a].sum()
    a=[yi[y] for y in range(2022,2027)]; row['今_後半平均']=S[k,a].sum()/C[k,a].sum()
    rows.append(row)
X=pd.DataFrame(rows); X.to_pickle(O+'EV0_year.pkl')
pd.set_option('display.width',300)
print(X[['区分','観察','向き','入る','選び方']+[f'前向き{y}' for y in range(2022,2027)]+['前向き合計','前向き件数','今_前半平均','今_後半平均']].round(0).to_string())
