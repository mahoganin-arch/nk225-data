# 寄り天・寄り底 売買エンジン（総当たり）
#   使い方: python3 eng.py D|N|C
#   D: 日中 8:45→9:00 の先物の動き / N: 夜間 寄り→+L分 の先物の動き / C: 夜間の寄り前の CFD の動き
#   出力: out/E_{fam}_meta.pkl（1行＝1つの売買のもと）, out/E_{fam}_R.npy（円、13pt控除後）, out/EXITS.pkl
import numpy as np, pandas as pd, sys
from multiprocessing import Pool
sys.path.insert(0, '/home/claude/yt/an')
from ev import FM, FO, CM, CO, px, O

SPREAD = 13.0; UNIT = 68800.0
P = pd.read_pickle(O + 'P.pkl'); PM = P.m.values; PO = P.open.values; PH = P.high.values; PL = P.low.values
IND = pd.read_pickle(O + 'IND.pkl')
INF = np.inf

# ---- 手じまいの格子 ----
TPp = [0.1, 0.2, 0.3, 0.5, 0.8, 1.2, INF]; SLp = [0.1, 0.2, 0.3, 0.5, 0.8, INF]
TPk = [0.5, 1, 1.5, 2, INF]; SLk = [0.5, 1, 1.5, INF]
TIMES = {'D': [15, 30, 60, 120, 240, 'AM', 'C'], 'N': [15, 30, 60, 120, 240, 480, 'C']}
INDS = [('RSI', 1, 70), ('RSI', 1, 60), ('RSI', 5, 70), ('RSI', 5, 60), ('RSI', 15, 70), ('RSI', 15, 60),
        ('HA', 1, 0), ('HA', 5, 0), ('HA', 15, 0), ('HA', 60, 0), ('前足', 5, 0), ('前足', 15, 0)]
ISL = [INF, 0.3, 0.5]; ITM = [120, 'C']

def exit_list(sess):
    T = TIMES[sess]; L = []
    for a, tp in enumerate(TPp):
        for b, sl in enumerate(SLp):
            for c, tm in enumerate(T): L.append(dict(型='%', 利確=tp, 損切り=sl, 時間=tm, ia=a, ib=b, ic=c))
    for a, tp in enumerate(TPk):
        for b, sl in enumerate(SLk):
            for c, tm in enumerate(T): L.append(dict(型='倍', 利確=tp, 損切り=sl, 時間=tm, ia=a, ib=b, ic=c))
    for a, (nm, tf, lv) in enumerate(INDS):
        for b, sl in enumerate(ISL):
            for c, tm in enumerate(ITM): L.append(dict(型='指標', 利確=f'{nm}{tf}分' + (f'{lv}' if nm == 'RSI' else ''), 損切り=sl, 時間=tm, ia=a, ib=b, ic=c))
    return pd.DataFrame(L)

def ind_exit(tf, kind, lv, d, te, tcap):
    """指標の手じまい時刻と値段（無ければ inf）。te 以降に始まる足のみ。"""
    I = IND[tf]; m = I['m']
    if tf == 1 and te < m[0] + 1440: return INF, np.nan
    k0 = np.searchsorted(m, te); k1 = np.searchsorted(m, tcap)
    if k1 <= k0: return INF, np.nan
    if kind == 'RSI':
        r = I['rsi'][k0:k1]; hit = (r >= lv) if d > 0 else (r <= 100 - lv)
        w = np.flatnonzero(hit)
        if len(w) == 0: return INF, np.nan
        t = I['end'][k0 + w[0]]; return t, None          # 次の足の始値
    if kind == 'HA':
        h = I['ha'][k0:k1]; w = np.flatnonzero(h == -d)
        if len(w) == 0: return INF, np.nan
        return I['end'][k0 + w[0]], None
    # 前足：前の足の安値（買い）・高値（売り）を割ったら、その値段で
    if k0 < 1: return INF, np.nan
    lo = I['low']; hi = I['high']; op = I['open']
    for k in range(max(k0 + 1, 1), k1):
        if d > 0 and lo[k] < lo[k - 1]: return m[k], min(op[k], lo[k - 1])
        if d < 0 and hi[k] > hi[k - 1]: return m[k], max(op[k], hi[k - 1])
    return INF, np.nan

def sim(args):
    d, te, mv, tcap, tam, sess = args
    T = TIMES[sess]; nE = len(EX[sess])
    out = np.full(nE, np.nan, np.float32)
    j0 = np.searchsorted(PM, te)
    if j0 >= len(PM) or PM[j0] - te >= 5 or te >= tcap: return out
    e = PO[j0]; jc = np.searchsorted(PM, tcap)
    if jc <= j0: return out
    hi = PH[j0:jc]; lo = PL[j0:jc]; op = PO[j0:jc + 1] if jc < len(PO) else np.r_[PO[j0:jc], PO[-1]]
    mm = PM[j0:jc]
    if d > 0: fav = np.maximum.accumulate(hi - e); adv = np.maximum.accumulate(e - lo)
    else: fav = np.maximum.accumulate(e - lo); adv = np.maximum.accumulate(hi - e)
    n = len(mm)
    # 時間の打ち切り（足の番号）
    def tix(tm):
        if tm == 'C': return n
        if tm == 'AM':
            if tam is None or tam <= te: return -1
            return min(np.searchsorted(mm, tam), n)
        return min(np.searchsorted(mm, te + tm), n)
    tI = np.array([tix(tm) for tm in T])
    def pnl(xp): return ((xp - e) * d - SPREAD) / e * UNIT
    def grid(tps, sls):
        tpi = np.array([np.searchsorted(fav, v, 'left') if np.isfinite(v) else n for v in tps])
        sli = np.array([np.searchsorted(adv, v, 'left') if np.isfinite(v) else n for v in sls])
        res = np.full((len(tps), len(sls), len(T)), np.nan)
        for a in range(len(tps)):
            for b in range(len(sls)):
                for c in range(len(T)):
                    ti = tI[c]
                    if ti < 0: continue
                    ki = min(tpi[a], sli[b])
                    if ki < ti and ki < n:
                        if sli[b] <= tpi[a]:   # 同じ足は損切りを先
                            lvl = e - d * sls[b]; o = op[ki]
                            xp = min(o, lvl) if d > 0 else max(o, lvl)
                        else:
                            lvl = e + d * tps[a]; o = op[ki]
                            xp = max(o, lvl) if d > 0 else min(o, lvl)
                    else:
                        xp = op[min(ti, n)]
                    res[a, b, c] = pnl(xp)
        return res.ravel()
    r1 = grid([v / 100 * e for v in TPp], [v / 100 * e for v in SLp])
    r2 = grid([v * mv for v in TPk], [v * mv for v in SLk])
    # 指標
    r3 = []
    for (nm, tf, lv) in INDS:
        ti_t, ti_p = ind_exit(tf, nm, lv, d, te, tcap)
        for sl in ISL:
            sli = np.searchsorted(adv, sl / 100 * e, 'left') if np.isfinite(sl) else n
            for tm in ITM:
                tlim = tI[T.index(tm)] if tm in T else n
                tl_time = mm[tlim] if tlim < n else tcap
                if tf == 1 and ti_t == INF and te < IND[1]['m'][0] + 1440: r3.append(np.nan); continue
                slt = mm[sli] if sli < n else INF
                cand = [(slt, 0), (ti_t, 1), (tl_time, 2)]
                tmin, kind = min(cand, key=lambda z: (z[0], z[1]))
                if kind == 0:
                    lvl = e - d * sl / 100 * e; o = op[sli]; xp = min(o, lvl) if d > 0 else max(o, lvl)
                elif kind == 1:
                    if ti_p is not None and not (isinstance(ti_p, float) and np.isnan(ti_p)): xp = ti_p
                    else: xp = op[min(np.searchsorted(mm, ti_t), n)]
                else:
                    xp = op[min(tlim, n)]
                r3.append(pnl(xp))
    out[:] = np.r_[r1, r2, np.array(r3)]
    return out

EX = {'D': exit_list('D'), 'N': exit_list('N')}

def confirm(d, t0, c0, thr, dead, sgn):
    """t0 以降 dead 分以内に、c0 から sgn 向きに thr 動いた足の次の足の時刻"""
    j0 = np.searchsorted(PM, t0); j1 = np.searchsorted(PM, t0 + dead)
    if j1 <= j0: return None
    h = PH[j0:j1]; l = PL[j0:j1]
    hit = (h >= c0 + thr) if sgn > 0 else (l <= c0 - thr)
    w = np.flatnonzero(hit)
    if len(w) == 0: return None
    k = j0 + w[0] + 1
    return PM[k] if k < len(PM) else None

def events(fam):
    s = pd.read_pickle(O + 'sess.pkl'); s = s[s.t >= pd.Timestamp('2017-03-16', tz='Asia/Tokyo')].reset_index(drop=True)
    last = FM[np.searchsorted(FM, s.end.values - 1) - 1]
    rows = []
    for i, r in s.iterrows():
        m0 = r.m
        if fam == 'D':
            if r.kind != 'D': continue
            obs = [('8:45→9:00', m0, m0 + 15, 'F')]; tcap = last[i]; tam = m0 + 165; ents = ['0', '+5', '+15', '+30', 'c25', 'c50']
        else:
            if r.kind != 'N': continue
            tcap = last[i] - 5; tam = None
            if fam == 'N':
                obs = [(f'寄り→+{L}', m0, m0 + L, 'F') for L in [5, 10, 15, 30, 60]]; ents = ['0', '+5', 'c25', 'c50']
            else:
                pl = last[i - 1] if i > 0 and s.kind[i - 1] == 'D' else np.nan
                obs = [(f'寄り前{P}分', m0 - P, m0, 'C') for P in [15, 30, 60]] + [('日中引けから', pl, m0, 'C')]
                ents = ['0', '+5', 'c25', 'c50']
        for name, a, b, src in obs:
            if not np.isfinite(a): continue
            if src == 'F': pa, pb = px(FM, FO, a), px(FM, FO, b)
            else: pa, pb = px(CM, CO, a), px(CM, CO, b)
            if not (np.isfinite(pa) and np.isfinite(pb)) or pa == pb: continue
            x = pb / pa - 1; sx = np.sign(x)
            c0 = px(CM, CO, b)
            if not np.isfinite(c0): continue
            mv = abs(x) * c0
            for dn, d in [('順張り', sx), ('逆張り', -sx)]:
                for en in ents:
                    if en[0] == 'c':
                        te = confirm(d, b, c0, float(en[1:]) / 100 * mv, 60, d)
                        if te is None: continue
                    else: te = b + int(en)
                    rows.append(dict(sid=i, m0=m0, t=r.t, 観察=name, 向き=dn, 入る=en, d=int(d), x=x, mv=mv, te=te, tcap=tcap, tam=tam))
    return pd.DataFrame(rows)

if __name__ == '__main__':
    fam = sys.argv[1]; sess = 'D' if fam == 'D' else 'N'
    ev = events(fam); print(fam, len(ev), flush=True)
    args = [(r.d, r.te, r.mv, r.tcap, r.tam if r.tam == r.tam else None, sess) for r in ev.itertuples()]
    with Pool(2) as p: R = np.vstack(p.map(sim, args, chunksize=500))
    ev.to_pickle(O + f'E_{fam}_meta.pkl'); np.save(O + f'E_{fam}_R.npy', R.astype(np.float32))
    pd.to_pickle(EX, O + 'EXITS.pkl')
    print(fam, R.shape, np.isnan(R).mean())
