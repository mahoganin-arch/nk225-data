import pandas as pd, numpy as np
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
O='/home/claude/yt/out/'; F='/home/claude/yt/out/Y1_寄り天寄り底_法則と条件なし.xlsx'
FORMS=['前半→後半','22-23→24-26','WF後半','WF全期間','WF直近3年']
L1=pd.read_pickle(O+'law1.pkl'); L2=pd.read_pickle(O+'law2.pkl')
EV=pd.read_pickle(O+'EV0.pkl'); EV['残す']=np.where((EV.プラスの数>=3)&(EV.中央>=20)&(EV.年件数_中央>=10),'残す','')
EV=EV.sort_values(['残す','中央'],ascending=[False,False])
Y=pd.read_pickle(O+'EV0_year.pkl')
ex=pd.DataFrame({'項目':[
 '目的','データ','コスト・単位','日中(D)','夜間(N)','寄り前CFD(C)','入る','強さ','手じまい','選び方','評価の形','残す基準','窓埋めとの重なり','注意'],
 '内容':[
 '「寄り天・寄り底」の法則があるかを確かめ、条件なしの総当たりで候補を探す（2026-10-15）',
 '判定は先物、売買は CFD。CFD は 2020/11/10 以降 1分足、それ以前 5分足。2026/10/9 以降は使わない',
 '13pt 控除（13÷価格×68,800円）。1枚＝68,800円換算。1bp≒6.9円',
 '先物 8:45→9:00 の動き',
 '先物 夜間の寄り（2024/11/5 より前は 16:30、以後 17:00）→ +5/10/15/30/60分の動き',
 '先物の夜間の寄りまでの CFD の動き（寄り前 15/30/60分、または先物の日中引けから）',
 '観察の終わりに入る(0)、+5/+15/+30分、確かめてから(c25/c50：動きの25%/50%だけ入る向きに動いたら次の足、60分以内)',
 '観察の動きの大きさ。前半(2017〜21)の分布で 全部/上位50%/33%/20%/10%',
 '利確・損切り（% と 動きの幅の倍率）×時間（15分〜引け、日中は前場引けも）、指標（RSI 1/5/15分 70・60、平均足 1/5/15/60分、前の足の高安割れ 5/15分）×損切り×時間。夜間の引けは 5:55',
 '単点（選ぶ期間の平均が最良）、周辺（強さ・手じまいの各軸±1 の平均が最良）。選ぶ期間で 15件以上・最悪の1回 −1,000円以上',
 '前半→後半、22-23→24-26、WF後半（2022〜前年→翌年）、WF全期間（2017〜前年→翌年、2022〜26年）、WF直近3年',
 '5つの形のうち3つ以上プラス、中央 +20円以上、年10件以上（窓埋めと同じ）',
 '窓埋め（現行・CFD基準）の順張り 0.9% を近似で作り、同じセッション・同じ向きに入っているかを数えた',
 '1分足の指標（RSI1分など）は 2020/11 以降のみ。前半で選ぶときは約1年分だけで選んでいる']})
with pd.ExcelWriter(F) as w:
    ex.to_excel(w,sheet_name='説明',index=False)
    L1.to_excel(w,sheet_name='法則_寄りの動きとその後',index=False)
    L2['時間帯比較'].to_excel(w,sheet_name='法則_時間帯の比較',index=False)
    L2['寄り前CFD'].to_excel(w,sheet_name='法則_寄り前CFD',index=False)
    L2['きれいさ'].to_excel(w,sheet_name='法則_きれいさ',index=False)
    L2['相関'].to_excel(w,sheet_name='法則_相関',index=False)
    c=['区分','観察','向き','入る','選び方','残す']+[f+'_平均' for f in FORMS]+[f+'_年件数' for f in FORMS]+['プラスの数','中央','年件数_中央','前半で選んだ強さ','前半で選んだ手じまい','今の強さ','今の手じまい']
    EV[c].round(1).to_excel(w,sheet_name='条件なし_全件',index=False)
    Y.round(1).to_excel(w,sheet_name='残った候補_年ごと',index=False)
wb=load_workbook(F)
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c in row: c.font=Font(name='Arial',size=10,bold=(c.row==1))
    for c in ws[1]: c.fill=PatternFill('solid',fgColor='DDE4EE'); c.alignment=Alignment(wrap_text=True,vertical='top')
    ws.freeze_panes='A2'
    for col in ws.columns:
        ws.column_dimensions[col[0].column_letter].width=min(max(len(str(col[0].value or ''))*1.6,9),40)
wb['説明'].column_dimensions['B'].width=110
for r in wb['説明'].iter_rows(min_row=2):
    r[1].alignment=Alignment(wrap_text=True,vertical='top')
wb.save(F); print(F)
