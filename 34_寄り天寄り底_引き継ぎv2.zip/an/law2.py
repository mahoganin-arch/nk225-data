# 法則の確認2：①ほかの時間帯との比較 ②寄り前のCFDの動き ③上がり方のきれいさ(1分足)
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/home/claude/yt/an'); from ev import *
s=pd.read_pickle(O+'sess.pkl'); s=s[s.t>=pd.Timestamp('2017-03-16',tz='Asia/Tokyo')].reset_index(drop=True)
yr=s.t.dt.year.values; H1=yr<=2021; m0=s.m.values
last=FM[np.searchsorted(FM,s.end.values-1)-1]   # 最後の足（引けの足）
cap=np.where(s.kind=='N',last-5,last)            # 夜間は5:55、日中は引けの足
def z_stats(x,y,q=0.9):
    z=y*np.sign(x); ok=~np.isnan(z)&~np.isnan(x)
    cut=np.quantile(np.abs(x[ok&H1]),q); r=[]
    for k in [ok&H1, ok&~H1]:
        kk=k&(np.abs(x)>=cut); zz=z[kk]*1e4
        r+= [kk.sum(), zz.mean(), zz.mean()/zz.std()*np.sqrt(len(zz))]
    return r
cols=['前半n','前半bp','前半t','後半n','後半bp','後半t']
def fwd(b,h): return px(CM,CO,np.minimum(b+h,cap))/px(CM,CO,b)-1
def fwdc(b): return px(CM,CO,cap)/px(CM,CO,b)-1
out={}
# ① 15分の動き → その後（30分・60分・引けまで）、時間帯ごと
rows=[]
for kind,offs in [('D',range(15,390,15)),('N',range(15,690,15))]:
    k=(s.kind==kind).values
    for off in offs:
        a=m0+off-15; b=m0+off
        if kind=='D': okb=b<=last-60
        else: okb=b<=cap-60
        x=px(FM,FO,b)/px(FM,FO,a)-1; x[~(k&okb)]=np.nan
        if np.isnan(x).mean()>0.6: continue
        for hn,y in [('30分',fwd(b,30)),('60分',fwd(b,60)),('引けまで',fwdc(b))]:
            rows.append([kind,off,hn]+z_stats(x,y))
T1=pd.DataFrame(rows,columns=['区分','寄りから分','その後']+cols); out['時間帯比較']=T1
# ② 寄り前のCFDの動き（先物の寄りまで）→ 寄りから後
rows=[]
for kind in ['D','N']:
    k=(s.kind==kind).values
    for P in [15,30,60,'始め']:
        if P=='始め':
            if kind=='D':  # CFDのその日の始まり(7:00/8:00)から
                a=np.array([CM[np.searchsorted(CM,t-120)] for t in m0])
            else:          # 先物の日中の引けから
                pl=np.r_[np.nan,last[:-1]]; a=pl
        else: a=m0-P
        x=px(CM,CO,a)/px(CM,CO,m0)-1; x=-x/(1+x)  # (O/a-1)
        x=px(CM,CO,m0)/px(CM,CO,a)-1; x[~k]=np.nan
        for hn,y in [('5分',fwd(m0,5)),('15分',fwd(m0,15)),('30分',fwd(m0,30)),('60分',fwd(m0,60)),('引けまで',fwdc(m0))]:
            for q in [0.67,0.9]:
                rows.append([kind,str(P),hn,f'上位{round((1-q)*100)}%']+z_stats(x,y,q))
T2=pd.DataFrame(rows,columns=['区分','寄り前の区間(分)','寄りから','強さ']+cols); out['寄り前CFD']=T2
# 寄り前CFDの動きと、寄りの窓・寄り後の動きとの相関
r=[]
for kind,L in [('D',15),('N',15),('N',30)]:
    k=(s.kind==kind).values
    pre=px(CM,CO,m0)/px(CM,CO,m0-30)-1
    gap=px(FM,FO,m0)/np.r_[np.nan,px(FM,FO,last[:-1])]-1 if True else None
    post=px(FM,FO,m0+L)/px(FM,FO,m0)-1
    d=pd.DataFrame({'寄り前30分CFD':pre,'窓(先物)':gap,f'寄り後{L}分(先物)':post})[k]
    c=d.corr(); r.append([kind,L,c.iloc[0,1],c.iloc[0,2],c.iloc[1,2]])
out['相関']=pd.DataFrame(r,columns=['区分','寄り後L','寄り前×窓','寄り前×寄り後','窓×寄り後'])
# ③ 上がり方のきれいさ：CFD1分足（2020/11以降）、8:45→9:00 と 夜間 寄り→+15分
c1=pd.read_pickle(O+'c1.pkl'); M1=c1.m.values; C1=c1.close.values; O1=c1.open.values
rows=[]
for kind,L,h0 in [('D',15,15),('N',15,15),('N',30,30)]:
    k=(s.kind==kind).values&(s.t>=pd.Timestamp('2020-11-10',tz='Asia/Tokyo')).values
    er=np.full(len(s),np.nan); upf=np.full(len(s),np.nan)
    for i in np.where(k)[0]:
        j0=np.searchsorted(M1,m0[i]); j1=np.searchsorted(M1,m0[i]+L)
        if j1-j0<L*0.8: continue
        p=np.r_[O1[j0],C1[j0:j1]]; d=np.diff(p); net=p[-1]-p[0]
        er[i]=abs(net)/np.abs(d).sum() if np.abs(d).sum()>0 else np.nan
        upf[i]=(np.sign(d)==np.sign(net)).mean()
    x=px(FM,FO,m0+L)/px(FM,FO,m0)-1; x[~k]=np.nan
    b=m0+L
    for hn,y in [('15分',fwd(b,15)),('30分',fwd(b,30)),('60分',fwd(b,60)),('120分',fwd(b,120)),('引けまで',fwdc(b))]:
        z=y*np.sign(x)*1e4; ok=~np.isnan(z)&~np.isnan(er)
        big=np.abs(x)>=np.nanquantile(np.abs(x[ok]),0.67)
        for nm,sel in [('強い×きれい(ER上位半分)',big&(er>=np.nanmedian(er[ok&big]))),('強い×ぎざぎざ(ER下位半分)',big&(er<np.nanmedian(er[ok&big])))]:
            kk=ok&sel; zz=z[kk]
            rows.append([kind,L,hn,nm,kk.sum(),zz.mean(),zz.mean()/zz.std()*np.sqrt(len(zz)),(zz>0).mean()*100])
out['きれいさ']=pd.DataFrame(rows,columns=['区分','観察分','その後','グループ','n','平均bp','t','続く%'])
pd.to_pickle(out,O+'law2.pkl')
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
for k,v in out.items(): print('=====',k); print(v.round(1).to_string())
