import pandas as pd, numpy as np
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
O='/home/claude/yt/out/'; F=O+'Y2_寄り天寄り底_天井の形と反転.xlsx'
FORMS=['前半→後半','22-23→24-26','WF後半','WF全期間','WF直近3年']
EV=pd.concat([pd.read_pickle(O+'EV2_D.pkl'),pd.read_pickle(O+'EV2_NC.pkl'),pd.read_pickle(O+'EV2_K.pkl')])
EV['残す']=np.where((EV.プラスの数>=3)&(EV.中央>=20)&(EV.年件数_中央>=10),'残す','')
cnt=EV.groupby('区分').apply(lambda d:pd.Series(dict(通り=len(d),残す=(d.残す=='残す').sum()))).reset_index()
cnt['残す割合%']=(cnt.残す/cnt.通り*100).round(1)
cnt['区分']=cnt.区分.map({'D':'日中 8:45→9:00〜9:30','N':'夜間 寄り→+L分','C':'夜間 寄り前CFD','K':'比べる相手：日中 9:45→10:00〜10:30（同じルール）'})
T,Y=pd.read_pickle(O+'shape.pkl')
ex=pd.DataFrame({'項目':['目的','天井の時刻','天井と底の比較','観察の延長','天井からの反転(pk)','反転の目印','順張り(pb・HAb)','末尾 n','比べる相手(K)','手じまい・評価','天井の形ごとの成績','候補の詳細','注意'],
'内容':['9:05・9:10 まで上がり続けてから下がる形を含め、寄りの後の天井（底）の付き方と、反転を確かめて入る売買の再現性を調べる（2026-10-15）',
'寄りの動きと同じ向きの最高値（下げなら最安値）が、観察の終わりから150分の間のいつ付くか。CFD 5分足（全期間）と1分足（2020/11以降）',
'寄りの直後は値動きが大きいので、天井も底も早く付きやすい。反対向きの極値（底）の時刻と並べ、天井だけが早いかを見る',
'日中の観察を 8:45→9:00 に加え、9:05・9:10・9:15・9:30 まで延ばした',
'pkK25/50：天井（観察の始まりからの最高値）から動きの25%/50% 戻した足の終値で判定、pkP10/20：0.1%/0.2% 戻した。次の足の始値で入る。判定は観察の終わりから90分以内',
'平均足が逆向き（HA1/HA5）、終値が前の足の安値割れ（前足1/前足5）、RSI14が70以上の後に70割れ（RSI1/RSI5、下げは30）',
'pbK25/50：天井から押した後に終値で天井を更新、HAb1/HAb5：平均足が一度逆向きになった後に戻った',
'観察の終わりの後に天井を更新してから（＝9:05・9:10…まで上がり続けてから）の反転だけ',
'同じルールを 9:45→10:00（〜10:30）の動きに当てはめた。偶然でどれくらい残るかの目安',
'手じまい 506通り・13pt控除・5つの評価の形・単点／周辺・残す基準は Y1 と同じ。強さの境目は観察ごとにセッション単位の前半の分布',
'逆張り・強さ上位10%・決済固定（損切り0.8%・利確なし・引けまで等）で、天井が付いた時刻ごとに平均を出した（天井＝入るまでの最高値）',
'残った候補の前向き（各年はその年より前で選んだルール）と、今のルール（2017〜25年で選択）の全期間の成績。グループは2022年以降のトレードの重なり（Ochiai 0.5以上）',
'1分足の指標（HA1・前足1・RSI1）は2020/11以降のみ。2020/10以前は5分足なので天井の時刻は5分刻み']})
with pd.ExcelWriter(F) as w:
    ex.to_excel(w,sheet_name='説明',index=False)
    cnt.to_excel(w,sheet_name='偶然との比較',index=False)
    pd.read_pickle(O+'peak.pkl').round(1).to_excel(w,sheet_name='天井の時刻',index=False)
    pd.read_pickle(O+'peak2.pkl').round(1).to_excel(w,sheet_name='天井と底の比較',index=False)
    p3=pd.read_pickle(O+'peak3.pkl'); p3.round(1).to_excel(w,sheet_name='天井と底_年ごと',index=False)
    T.round(1).to_excel(w,sheet_name='天井の形ごとの成績',index=False)
    Y.round(1).to_excel(w,sheet_name='天井の形_年ごと',index=False)
    X=pd.read_pickle(O+'cand2.pkl'); X.round(1).to_excel(w,sheet_name='残った候補の詳細',index=False)
    c=['区分','観察','向き','入る','選び方','残す']+[f+'_平均' for f in FORMS]+[f+'_年件数' for f in FORMS]+['プラスの数','中央','年件数_中央','前向き合計','前向き件数']+[f'前向き{y}' for y in range(2022,2027)]+['前半で選んだの強さ','前半で選んだの手じまい','今の強さ','今の手じまい']
    EV.sort_values(['区分','残す','中央'],ascending=[True,False,False])[c].round(1).to_excel(w,sheet_name='総当たり_全件',index=False)
wb=load_workbook(F)
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c_ in row: c_.font=Font(name='Arial',size=10,bold=(c_.row==1))
    for c_ in ws[1]: c_.fill=PatternFill('solid',fgColor='DDE4EE'); c_.alignment=Alignment(wrap_text=True,vertical='top')
    ws.freeze_panes='A2'
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width=min(max(len(str(col[0].value or ''))*1.6,9),40)
wb['説明'].column_dimensions['B'].width=110
for r in wb['説明'].iter_rows(min_row=2): r[1].alignment=Alignment(wrap_text=True,vertical='top')
wb.save(F); print(F); print(cnt.to_string())
