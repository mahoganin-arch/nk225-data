# 天井の早さは「寄りの動きのせい」か「寄りの直後は値動きが大きいだけ」か：
#   同じ向きの極値（天井）と、反対向きの極値（底）の時刻を並べて比べる。1分足（2020/11以降）でも。
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/home/claude/yt/an')
from ev import FM,FO,CM,CO,px,O
s=pd.read_pickle(O+'sess.pkl'); s=s[s.t>=pd.Timestamp('2017-03-16',tz='Asia/Tokyo')].reset_index(drop=True)
last=FM[np.searchsorted(FM,s.end.values-1)-1]; yr=s.t.dt.year.values; m0=s.m.values
def calc(src_bars, a, b, Hm, obs, tf):
    M=src_bars.m.values; H=src_bars.high.values; L=src_bars.low.values
    pa=px(FM,FO,a) if obs=='F' else px(CM,CO,a); pb=px(FM,FO,b) if obs=='F' else px(CM,CO,b); x=pb/pa-1
    t1=np.full(len(a),np.nan); t2=np.full(len(a),np.nan)
    for i in range(len(a)):
        if not np.isfinite(x[i]) or x[i]==0: continue
        j0=np.searchsorted(M,b[i]); j1=np.searchsorted(M,b[i]+Hm[i])
        if j1-j0<Hm[i]/tf*0.8 or M[j0]-b[i]>=tf: continue
        up=H[j0:j1]; dn=L[j0:j1]
        if x[i]>0: t1[i]=M[j0+np.argmax(up)]-b[i]; t2[i]=M[j0+np.argmin(dn)]-b[i]
        else: t1[i]=M[j0+np.argmin(dn)]-b[i]; t2[i]=M[j0+np.argmax(up)]-b[i]
    return x,t1,t2
rows=[]
c5=pd.read_pickle(O+'c5.pkl'); c1=pd.read_pickle(O+'c1.pkl')
def summarize(name,x,t1,t2,mask,first):
    ax=np.abs(x); ok=mask&np.isfinite(t1)
    for hf,hm in [('前半',yr<=2021),('後半',yr>2021)]:
        cut=np.nanquantile(ax[ok&(yr<=2021)],[0.67,0.9]) if (ok&(yr<=2021)).sum()>50 else np.nanquantile(ax[ok],[0.67,0.9])
        for gn,gm in [('上位10%',ax>=cut[1]),('上位33%',ax>=cut[0]),('下位67%',ax<cut[0])]:
            k=ok&hm&gm
            if k.sum()<20: continue
            rows.append(dict(観察=name,期間=hf,強さ=gn,n=k.sum(),
              **{f'天井{first}分以内%':(t1[k]<first).mean()*100, f'底{first}分以内%':(t2[k]<first).mean()*100,
                 '天井15分以内%':(t1[k]<15).mean()*100,'底15分以内%':(t2[k]<15).mean()*100,
                 '天井の時刻(中央)':np.median(t1[k]),'底の時刻(中央)':np.median(t2[k])}))
isD=(s.kind=='D').values; isN=(s.kind=='N').values
HD=np.minimum(150,last-(m0+15))
x,t1,t2=calc(c5,m0,m0+15,HD,'F',5); summarize('日中 8:45→9:00 (5分足)',x,t1,t2,isD,5)
for off in [75,105,285]:
    Hm=np.minimum(150,last-(m0+off)); x,t1,t2=calc(c5,m0+off-15,m0+off,Hm,'C',5)
    hh=(pd.Timestamp('2000-01-01 08:45')+pd.Timedelta(minutes=off)).strftime('%H:%M')
    summarize(f'比較 日中{hh} (5分足)',x,t1,t2,isD&(Hm>=60),5)
x,t1,t2=calc(c5,m0,m0+15,np.full(len(m0),150),'F',5); summarize('夜間 寄り→+15分 (5分足)',x,t1,t2,isN,5)
x,t1,t2=calc(c5,m0-30,m0,np.full(len(m0),150),'C',5); summarize('夜間 寄り前CFD30分 (5分足)',x,t1,t2,isN,5)
# 1分足（2020/11以降）：日中 9:00 の直後を1分単位で
x,t1,t2=calc(c1,m0,m0+15,HD,'F',1); after=(s.t>=pd.Timestamp('2020-11-10',tz='Asia/Tokyo')).values
summarize('日中 8:45→9:00 (1分足)',x,t1,t2,isD&after,5)
for off in [75,285]:
    Hm=np.minimum(150,last-(m0+off)); x,t1,t2=calc(c1,m0+off-15,m0+off,Hm,'C',1)
    hh=(pd.Timestamp('2000-01-01 08:45')+pd.Timedelta(minutes=off)).strftime('%H:%M')
    summarize(f'比較 日中{hh} (1分足)',x,t1,t2,isD&after&(Hm>=60),5)
T=pd.DataFrame(rows); T.to_pickle(O+'peak2.pkl')
pd.set_option('display.width',250); print(T.round(1).to_string())
# 1分足：天井の時刻の分布（日中 上位33%、2020/11以降）
x,t1,t2=calc(c1,m0,m0+15,HD,'F',1); ax=np.abs(x); k=isD&after&np.isfinite(t1)&(ax>=np.nanquantile(ax[isD&(yr<=2021)],0.67))
bins=[0,1,2,3,5,10,15,20,30,60,151]
print('天井(1分足) 上位33%', (pd.Series(pd.cut(t1[k],bins,right=False)).value_counts(normalize=True).sort_index()).round(3).mul(100).to_dict())
print('底  (1分足) 上位33%', (pd.Series(pd.cut(t2[k],bins,right=False)).value_counts(normalize=True).sort_index()).round(3).mul(100).to_dict())
