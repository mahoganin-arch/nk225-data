# 窓埋め（現行・CFD基準）の順張り 0.9% と、残った候補の重なり（近似）
#   窓：基準＝前のセッションの引けの時刻の CFD。CFD が基準から ±0.9% に先に届いた向きで入る。
#   先物の寄りの後に基準まで戻ったら、その窓では入らない。
import numpy as np, pandas as pd, sys
sys.path.insert(0, '/home/claude/yt/an')
from ev import FM, CM, CO, O
P = pd.read_pickle(O + 'P.pkl'); PM = P.m.values; PH = P.high.values; PL = P.low.values
s = pd.read_pickle(O + 'sess.pkl'); s = s[s.t >= pd.Timestamp('2017-03-16', tz='Asia/Tokyo')].reset_index(drop=True)
last = FM[np.searchsorted(FM, s.end.values - 1) - 1]

def window(w=0.009):
    rows = []
    for i in range(1, len(s)):
        bt = last[i - 1]; j0 = np.searchsorted(PM, bt)
        if j0 >= len(PM) or PM[j0] - bt >= 5: rows.append((np.nan, np.nan)); continue
        base = P.open.values[j0]; m0 = s.m[i]; cap = last[i] - 5
        j1 = np.searchsorted(PM, cap); hi = PH[j0:j1]; lo = PL[j0:j1]; mm = PM[j0:j1]
        up = np.flatnonzero(hi >= base * (1 + w)); dn = np.flatnonzero(lo <= base * (1 - w))
        ku = up[0] if len(up) else 10**9; kd = dn[0] if len(dn) else 10**9
        k = min(ku, kd)
        if k >= len(mm): rows.append((np.nan, np.nan)); continue
        d = 1 if ku < kd else -1
        # 寄りの後に基準へ戻ったか（届く前）
        after = np.flatnonzero((mm >= m0) & (mm < mm[k]) & (lo <= base) & (hi >= base))
        if len(after): rows.append((np.nan, np.nan)); continue
        rows.append((d, mm[k]))
    return pd.DataFrame([(np.nan, np.nan)] + rows, columns=['wd', 'wt'])

if __name__ == '__main__':
    W = window(); W['sid'] = range(len(s)); W['kind'] = s.kind.values
    W.to_pickle(O + 'W09.pkl')
    print(W.groupby('kind').wd.apply(lambda x: x.notna().mean()))
    T = pd.read_pickle(O + 'EV0.pkl')
    T = T[(T.プラスの数 >= 3) & (T.中央 >= 20) & (T.年件数_中央 >= 10)]
    QS = {'全部': 0, '上位50%': .5, '上位33%': .67, '上位20%': .8, '上位10%': .9}
    rows = []
    for _, r in T.iterrows():
        meta = pd.read_pickle(O + f'E_{r.区分}_meta.pkl')
        g = meta[(meta.観察 == r.観察) & (meta.向き == r.向き) & (meta.入る == r.入る)]
        allx = np.abs(meta[meta.観察 == r.観察].x); yr = meta[meta.観察 == r.観察].t.dt.year
        q = QS[r.今の強さ]; cut = np.quantile(allx[yr <= 2021], q) if q else 0
        g = g[np.abs(g.x) >= cut].merge(W, on='sid', how='left')
        g = g[g.t.dt.year >= 2022]
        same = (g.wd == g.d); opp = (g.wd == -g.d)
        rows.append(dict(区分=r.区分, 観察=r.観察, 向き=r.向き, 入る=r.入る, 選び方=r.選び方, 後半件数=len(g),
                         窓あり_同じ向き=same.mean() * 100, 窓あり_逆向き=opp.mean() * 100,
                         窓が先に入る割合=((g.wt < g.te) & same).mean() * 100))
    print(pd.DataFrame(rows).round(1).to_string())
