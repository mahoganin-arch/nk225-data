# 年ごと：「天井が先（30分以内）」と「底が先（30分以内）」の差。強い動き（上位33%）、5分足
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/home/claude/yt/an'); from peak2 import calc, s, last, yr, m0, isD, isN
c5=pd.read_pickle('/home/claude/yt/out/c5.pkl')
rows=[]
def go(name,a,b,Hm,obs,mask):
    x,t1,t2=calc(c5,a,b,Hm,obs,5); ax=np.abs(x); ok=mask&np.isfinite(t1)
    cut=np.nanquantile(ax[ok&(yr<=2021)],0.67); k0=ok&(ax>=cut)
    for y in range(2017,2027):
        k=k0&(yr==y)
        rows.append(dict(観察=name,年=y,n=k.sum(),天井30分以内=(t1[k]<30).mean()*100,底30分以内=(t2[k]<30).mean()*100))
HD=np.minimum(150,last-(m0+15))
go('日中9:00',m0,m0+15,HD,'F',isD)
Hm=np.minimum(150,last-(m0+75)); go('比較 日中10:00',m0+60,m0+75,Hm,'C',isD&(Hm>=60))
go('夜間 寄り+15分',m0,m0+15,np.full(len(m0),150),'F',isN)
go('夜間 寄り前CFD30分',m0-30,m0,np.full(len(m0),150),'C',isN)
T=pd.DataFrame(rows); T['差']=T.天井30分以内-T.底30分以内
P=T.pivot(index='年',columns='観察',values='差').round(1); print(P.to_string()); T.to_pickle('/home/claude/yt/out/peak3.pkl')
