# 寄り天・寄り底 売買エンジン2：観察の延長・天井（底）からの反転・反転の目印で入る
#   python3 eng2.py D|N|C
#   出力: out/E2_{fam}_meta.pkl, out/E2_{fam}_R.npy（float16、円、13pt控除後）。手じまいは eng.py と同じ 506通り
#   入る（逆張り）：
#     pkK25/pkK50 : 天井（観察の始まりからの最高値）から、観察の動きの25%/50% 戻した足の終値で判定 → 次の足の始値
#     pkP10/pkP20 : 天井から 0.1%/0.2% 戻した
#     HA1/HA5     : 平均足（1分/5分）が逆向きに変わった
#     前足1/前足5  : 終値が前の足の安値（上の動き）／高値（下の動き）を割った
#     RSI1/RSI5   : RSI14 が 70 以上（下の動きは30以下）になった後、70を割った（30を超えた）
#     末尾 n       : 観察の終わりの後に天井を更新してから（＝9:05・9:10…まで上がり続けてから）の反転だけ
#   入る（順張り）：
#     pbK25/pbK50 : 天井から25%/50% 押した後、終値で天井を更新
#     HAb1/HAb5   : 平均足が逆向きになった後、観察の向きに戻った
#   判定の期限：観察の終わりから 90分
import numpy as np, pandas as pd, sys
from multiprocessing import Pool
sys.path.insert(0, '/home/claude/yt/an')
import eng
from eng import P, PM, PO, PH, PL, IND, sim, O, FM, FO, CM, CO, px
PC = P.close.values; PTF = P.tf.values
DEAD = 90

def trigger(code, sg, a, b, c0, mv):
    """戻り値：(入る時刻, 天井の時刻−b, 天井の伸び（観察の動きの倍）)。無ければ None"""
    j0 = np.searchsorted(PM, b); j1 = np.searchsorted(PM, b + DEAD)
    ja = np.searchsorted(PM, a)
    if j1 <= j0 or ja >= j0: return None
    # 観察中の天井
    pre = (PH[ja:j0].max() if sg > 0 else -PL[ja:j0].min())
    hi = PH[j0:j1] if sg > 0 else -PL[j0:j1]           # 向きをそろえた高値
    lo = PL[j0:j1] if sg > 0 else -PH[j0:j1]
    cl = PC[j0:j1] * sg
    mm = PM[j0:j1]; tf = PTF[j0:j1]
    run = np.maximum(np.maximum.accumulate(hi), pre)     # 天井（観察の始まりから）
    runpost = np.maximum.accumulate(hi)                  # 観察の終わり後の天井
    newx = runpost > pre                                 # 観察の終わり後に天井を更新したか
    base = code.rstrip('n'); need_new = code.endswith('n')
    hit = None
    if base.startswith('pkK') or base.startswith('pkP'):
        v = float(base[3:])
        thr = v / 100 * mv if base[2] == 'K' else v / 10000 * c0   # pkK25=動きの25%、pkP10=0.1%
        hit = cl <= run - thr
    elif base.startswith('pbK'):
        r = float(base[3:]) / 100 * mv
        dip = np.maximum.accumulate((run - lo) >= r)       # 押しが入ったか（以後ずっと True）
        prev_run = np.r_[pre, run[:-1]]
        hit = dip & (np.r_[False, dip[:-1]]) & (cl > prev_run)
    elif base[:3] in ('HA1', 'HA5', '前足1', '前足5', 'RSI', 'HAb'):
        tfi = int(base[-1]); I = IND[tfi]; m = I['m']
        if tfi == 1 and b < m[0] + 1440: return None
        k0 = np.searchsorted(m, b); k1 = np.searchsorted(m, b + DEAD)
        if k1 <= k0 + 1: return None
        ends = I['end'][k0:k1]
        if base.startswith('HAb'):
            ha = I['ha'][k0:k1] * sg
            opp = np.maximum.accumulate(ha < 0)
            sig = opp & np.r_[False, opp[:-1]] & (ha > 0)
        elif base.startswith('HA'):
            sig = (I['ha'][k0:k1] * sg) < 0
        elif base.startswith('前足'):
            cc = I['close'][k0:k1] * sg
            lo_ = (I['low'][k0 - 1:k1 - 1] if sg > 0 else -I['high'][k0 - 1:k1 - 1])
            sig = cc < lo_
        else:  # RSI
            rs = I['rsi'][k0:k1]
            if sg < 0: rs = 100 - rs
            was = np.maximum.accumulate(rs >= 70)
            sig = was & np.r_[False, was[:-1]] & (rs < 70)
        w = np.flatnonzero(sig)
        if need_new:
            # 判定の時刻までに観察の終わり後の天井更新があったもの
            w = [k for k in w if newx[min(np.searchsorted(mm, ends[k]) - 1, len(mm) - 1)]] if len(w) else []
        if len(w) == 0: return None
        te = ends[w[0]]
        kk = max(np.searchsorted(mm, te) - 1, 0)
        tpk = mm[int(np.argmax(hi[:kk + 1]))] - b if newx[kk] else -1
        return te, tpk, (run[kk] - sg * c0) / mv
    w = np.flatnonzero(hit & (newx if need_new else True))
    if len(w) == 0: return None
    k = w[0]; te = mm[k] + tf[k]
    tpk = mm[int(np.argmax(hi[:k + 1]))] - b if newx[k] else -1
    return te, tpk, (run[k] - sg * c0) / mv

REV = ['pkK25', 'pkK50', 'pkP10', 'pkP20', 'HA1', 'HA5', '前足1', '前足5', 'RSI1', 'RSI5']
REV = REV + [c + 'n' for c in REV]
FOL = ['pbK25', 'pbK50', 'HAb1', 'HAb5']

def events(fam):
    s = pd.read_pickle(O + 'sess.pkl'); s = s[s.t >= pd.Timestamp('2017-03-16', tz='Asia/Tokyo')].reset_index(drop=True)
    last = FM[np.searchsorted(FM, s.end.values - 1) - 1]
    rows = []
    for i, r in s.iterrows():
        m0 = r.m
        if fam == 'D':
            if r.kind != 'D': continue
            obs = [(f'8:45→{h}', m0, m0 + L, 'F') for h, L in [('9:00', 15), ('9:05', 20), ('9:10', 25), ('9:15', 30), ('9:30', 45)]]
            tcap = last[i]; tam = m0 + 165
        elif fam == 'K':   # 比べる相手：同じルールを 9:45→10:00（先物）に当てはめる。前場引けは 11:30 のまま
            if r.kind != 'D': continue
            obs = [(f'9:45→{h}', m0 + 60, m0 + 60 + L, 'F') for h, L in [('10:00', 15), ('10:05', 20), ('10:10', 25), ('10:15', 30), ('10:30', 45)]]
            tcap = last[i]; tam = m0 + 165
        else:
            if r.kind != 'N': continue
            tcap = last[i] - 5; tam = None
            if fam == 'N': obs = [(f'寄り→+{L}', m0, m0 + L, 'F') for L in [5, 10, 15, 30, 60]]
            else:
                pl = last[i - 1] if i > 0 and s.kind[i - 1] == 'D' else np.nan
                obs = [(f'寄り前{P_}分', m0 - P_, m0, 'C') for P_ in [15, 30, 60]] + [('日中引けから', pl, m0, 'C')]
        for name, a, b, src in obs:
            if not np.isfinite(a): continue
            pa, pb = (px(FM, FO, a), px(FM, FO, b)) if src == 'F' else (px(CM, CO, a), px(CM, CO, b))
            if not (np.isfinite(pa) and np.isfinite(pb)) or pa == pb: continue
            x = pb / pa - 1; sx = int(np.sign(x)); c0 = px(CM, CO, b)
            if not np.isfinite(c0): continue
            mv = abs(x) * c0
            ents = [('逆張り', -sx, c) for c in REV] + [('順張り', sx, c) for c in FOL]
            if fam in ('D', 'K') and name not in ('8:45→9:00', '9:45→10:00'):   # 延長した観察では、もとの入る形も
                for dn, d in [('順張り', sx), ('逆張り', -sx)]:
                    ents += [(dn, d, '0'), (dn, d, '+5')]
                    for c in ['c25', 'c50']:
                        te = eng.confirm(d, b, c0, float(c[1:]) / 100 * mv, 60, d)
                        if te is not None: rows.append(dict(sid=i, m0=m0, t=r.t, 観察=name, 向き=dn, 入る=c, d=d, x=x, mv=mv, te=te, tcap=tcap, tam=tam, tpk=np.nan, ext=np.nan))
            for dn, d, c in ents:
                if c in ('0', '+5'):
                    rows.append(dict(sid=i, m0=m0, t=r.t, 観察=name, 向き=dn, 入る=c, d=d, x=x, mv=mv, te=b + int(c), tcap=tcap, tam=tam, tpk=np.nan, ext=np.nan)); continue
                tr = trigger(c, sx, a, b, c0, mv)
                if tr is None: continue
                rows.append(dict(sid=i, m0=m0, t=r.t, 観察=name, 向き=dn, 入る=c, d=d, x=x, mv=mv, te=tr[0], tcap=tcap, tam=tam, tpk=tr[1], ext=tr[2]))
    return pd.DataFrame(rows)

if __name__ == '__main__':
    fam = sys.argv[1]; sess = 'D' if fam in ('D', 'K') else 'N'
    with Pool(2) as p:
        ev = events(fam); print(fam, len(ev), flush=True)
        args = [(r.d, r.te, r.mv, r.tcap, r.tam if r.tam == r.tam else None, sess) for r in ev.itertuples()]
        R = np.vstack(p.map(sim, args, chunksize=1000))
    ev.to_pickle(O + f'E2_{fam}_meta.pkl'); np.save(O + f'E2_{fam}_R.npy', R.astype(np.float16))
    print(fam, R.shape, np.isnan(R).mean(), ev.groupby('入る').size().to_dict())
