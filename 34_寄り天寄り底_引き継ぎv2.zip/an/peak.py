# 天井・底の時刻：寄りの動き（観察）の後、同じ向きの最高値（最安値）がいつ付くか
#   全期間でそろえるため CFD 5分足で計算。観察の向き s：上がった日は高値、下がった日は安値を見る。
#   比べる相手：同じ長さの動きを、ほかの時刻でも同じように計算（CFDの動きで観察）。
import numpy as np, pandas as pd, sys
sys.path.insert(0, '/home/claude/yt/an')
from ev import FM, FO, CM, CO, px, O
c5 = pd.read_pickle(O + 'c5.pkl'); M = c5.m.values; H = c5.high.values; L = c5.low.values; Op = c5.open.values
s = pd.read_pickle(O + 'sess.pkl'); s = s[s.t >= pd.Timestamp('2017-03-16', tz='Asia/Tokyo')].reset_index(drop=True)
last = FM[np.searchsorted(FM, s.end.values - 1) - 1]
yr = s.t.dt.year.values
BINS = [0, 5, 10, 15, 30, 60, 151]; BN = ['9:00台前半(0-5分)', '5-10分', '10-15分', '15-30分', '30-60分', '60-150分']

def one(a, b, Hm, src):
    """a→b の動き、b から Hm 分の間の天井の時刻ほか"""
    pa = px(FM, FO, a) if src == 'F' else px(CM, CO, a); pb = px(FM, FO, b) if src == 'F' else px(CM, CO, b)
    x = pb / pa - 1
    cb = px(CM, CO, b)
    R = dict(x=x, tau=np.full(len(a), np.nan), ext=np.full(len(a), np.nan), endr=np.full(len(a), np.nan),
             fall=np.full(len(a), np.nan), endH=np.full(len(a), np.nan))
    for i in range(len(a)):
        if not (np.isfinite(x[i]) and np.isfinite(cb[i])) or x[i] == 0: continue
        j0 = np.searchsorted(M, b[i]); j1 = np.searchsorted(M, b[i] + Hm[i])
        if j1 - j0 < 3 or M[j0] - b[i] >= 5: continue
        sg = np.sign(x[i])
        e = H[j0:j1] if sg > 0 else -L[j0:j1]
        k = int(np.argmax(e)); peak = e[k] * sg      # 値段
        pend = Op[j1] if j1 < len(Op) and M[j1] - (b[i] + Hm[i]) < 5 else np.nan
        mv = abs(x[i]) * cb[i]
        R['tau'][i] = M[j0 + k] - b[i]
        R['ext'][i] = sg * (peak - cb[i]) / mv            # 観察の動きの何倍だけ先へ伸びたか
        R['fall'][i] = sg * (pend - peak) / cb[i] * 1e4   # 天井から終わりまで（bp、マイナス＝戻った）
        R['endH'][i] = sg * (pend - cb[i]) / cb[i] * 1e4  # b から終わりまで（bp）
        R['endr'][i] = sg * (pend - cb[i]) / mv           # 観察の動きの何倍（−1＝寄りの値段まで戻った）
    return pd.DataFrame(R)

def groups(x, half_mask):
    ax = np.abs(x); ok = np.isfinite(ax)
    q = lambda p: np.nanquantile(ax[ok & half_mask], p)
    g = np.full(len(x), '', object)
    g[ok & (ax >= q(0.9))] = '上位10%'
    g[ok & (ax >= q(0.67)) & (ax < q(0.9))] = '上位33-10%'
    g[ok & (ax >= q(0.33)) & (ax < q(0.67))] = '中位'
    g[ok & (ax < q(0.33))] = '下位33%'
    return g

def table(df, g, name):
    rows = []
    df = df.assign(g=g, half=np.where(yr <= 2021, '前半', '後半'))
    df['bin'] = pd.cut(df.tau, BINS, right=False, labels=BN)
    for (gg, hf), d in df[df.g != ''].groupby(['g', 'half']):
        d = d.dropna(subset=['tau'])
        r = dict(観察=name, 強さ=gg, 期間=hf, n=len(d))
        for b_ in BN: r[b_] = (d.bin == b_).mean() * 100
        r['先へ伸びた倍(中央)'] = d.ext.median()
        r['天井から戻り(bp平均)'] = d.fall.mean()
        r['寄り後→終わり(bp平均)'] = d.endH.mean()
        r['t'] = d.endH.mean() / d.endH.std() * np.sqrt(len(d))
        r['観察の起点まで戻った%'] = (d.endr <= -1).mean() * 100
        rows.append(r)
    return rows

if __name__ == '__main__':
    m0 = s.m.values; isD = (s.kind == 'D').values; isN = (s.kind == 'N').values
    out = []; keep = {}
    HD = np.minimum(150, last - (m0 + 15))
    # 日中：先物 8:45→9:00、9:00 から150分（前場引け 11:30 まで）
    d = one(m0, m0 + 15, HD, 'F'); g = groups(np.where(isD, d.x, np.nan), yr <= 2021)
    out += table(d, np.where(isD, g, ''), '日中 先物8:45→9:00'); keep['D'] = d.assign(g=np.where(isD, g, ''))
    # 同じ時刻を CFD で
    d = one(m0, m0 + 15, HD, 'C'); g = groups(np.where(isD, d.x, np.nan), yr <= 2021)
    out += table(d, np.where(isD, g, ''), '日中 CFD8:45→9:00')
    # 比べる相手（日中のほかの時刻、CFD）
    for off in [45, 75, 105, 255, 285, 315]:
        Hm = np.minimum(150, last - (m0 + off))
        d = one(m0 + off - 15, m0 + off, Hm, 'C'); okk = isD & (Hm >= 60)
        g = groups(np.where(okk, d.x, np.nan), yr <= 2021)
        hh = (pd.Timestamp('2000-01-01 08:45') + pd.Timedelta(minutes=off)).strftime('%H:%M')
        out += table(d, np.where(okk, g, ''), f'比較 日中{hh}まで15分')
    # 夜間：寄り→+15分、その後150分
    for LL in [15, 30]:
        d = one(m0, m0 + LL, np.full(len(m0), 150), 'F'); g = groups(np.where(isN, d.x, np.nan), yr <= 2021)
        out += table(d, np.where(isN, g, ''), f'夜間 先物寄り→+{LL}分'); keep[f"N{LL}"] = d.assign(g=np.where(isN, g, ''))
    for off in [120, 240, 360, 480]:
        Hm = np.minimum(150, last - 5 - (m0 + off))
        d = one(m0 + off - 15, m0 + off, Hm, 'C'); okk = isN & (Hm >= 60)
        g = groups(np.where(okk, d.x, np.nan), yr <= 2021)
        out += table(d, np.where(okk, g, ''), f'比較 夜間 寄り+{off}分まで15分')
    # 寄り前 CFD 30分 → 寄りから150分
    d = one(m0 - 30, m0, np.full(len(m0), 150), 'C'); g = groups(np.where(isN, d.x, np.nan), yr <= 2021)
    out += table(d, np.where(isN, g, ''), '夜間 寄り前CFD30分'); keep['C30'] = d.assign(g=np.where(isN, g, ''))
    T = pd.DataFrame(out); T.to_pickle(O + 'peak.pkl'); pd.to_pickle(keep, O + 'peak_keep.pkl')
    pd.set_option('display.width', 300); pd.set_option('display.max_rows', 400)
    print(T.round(1).to_string())
