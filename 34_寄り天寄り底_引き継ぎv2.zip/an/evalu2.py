# エンジン2（観察の延長・天井からの反転・反転の目印）を5つの評価の形で評価
#   evalu.py と同じ選び方。強さの境目は、観察ごとにセッション単位（重複なし）の前半の分布で決める。
import numpy as np, pandas as pd, sys
sys.path.insert(0, '/home/claude/yt/an')
from evalu import YEARS, QS, QN, FORMS, neighbors, O

def yearly_rows(R, rows, yrs_rows):
    nE = R.shape[1]; S = np.zeros((nE, len(YEARS))); C = np.zeros((nE, len(YEARS))); M = np.full((nE, len(YEARS)), np.inf)
    sub_all = np.asarray(R[rows], dtype=np.float32)
    for k, y in enumerate(YEARS):
        sub = sub_all[yrs_rows == y]
        if len(sub) == 0: continue
        ok = ~np.isnan(sub)
        S[:, k] = np.where(ok, sub, 0).sum(0); C[:, k] = ok.sum(0); M[:, k] = np.where(ok, sub, np.inf).min(0)
    return S, C, M

def evaluate(fam, tag='E2'):
    meta = pd.read_pickle(O + f'{tag}_{fam}_meta.pkl'); R = np.load(O + f'{tag}_{fam}_R.npy', mmap_mode='r')
    EXd = pd.read_pickle(O + 'EXITS.pkl')['D' if fam in ('D', 'K') else 'N']; nE = len(EXd); NB = neighbors(EXd)
    yrs = meta.t.dt.year.values; ax = np.abs(meta.x.values)
    cutmap = {}
    for ob, g in meta.drop_duplicates(['観察', 'sid']).groupby('観察'):
        a = np.abs(g.x.values)[g.t.dt.year.values <= 2021]
        cutmap[ob] = [np.quantile(a, q) if q > 0 else 0 for q in QS]
    yi = {y: k for k, y in enumerate(YEARS)}
    out = []; store = {}
    for keys, g in meta.groupby(['観察', '向き', '入る'], sort=False):
        idx = g.index.values; S = []; C = []; M = []
        for cut in cutmap[keys[0]]:
            rows = idx[ax[idx] >= cut]
            s_, c_, m_ = yearly_rows(R, rows, yrs[rows]); S.append(s_); C.append(c_); M.append(m_)
        S = np.vstack(S); C = np.vstack(C); M = np.vstack(M)
        store[keys] = (S.astype(np.float32), C.astype(np.int32), M.astype(np.float32))
        for how in ['単点', '周辺']:
            res = {}
            for fn, splits in FORMS.items():
                ts = 0; tc = 0; tyears = 0; ch = []
                for tr, te in splits:
                    a = [yi[y] for y in tr]; b = [yi[y] for y in te]
                    sm = S[:, a].sum(1); cn = C[:, a].sum(1); mn = M[:, a].min(1)
                    mean = np.where(cn > 0, sm / np.maximum(cn, 1), np.nan)
                    ok = (cn >= 15) & (mn >= -1000)
                    if how == '単点': score = np.where(ok, mean, -np.inf)
                    else:
                        nbm = np.array([np.nanmean(mean[nb]) if len(nb) else np.nan for nb in NB])
                        score = np.where(ok, nbm, -np.inf)
                    score = np.nan_to_num(score, nan=-np.inf)
                    if not np.isfinite(score.max()): continue
                    k = int(np.argmax(score)); ch.append(k)
                    ts += S[k, b].sum(); tc += C[k, b].sum(); tyears += len(b)
                yrs_eff = tyears - (1 - 280 / 365) if 2026 in [y for _, te in splits for y in te] else tyears
                res[fn] = (ts / tc if tc else np.nan, tc / max(yrs_eff, 1e-9), ch)
            vals = np.array([res[f][0] for f in FORMS])
            row = dict(区分=fam, 観察=keys[0], 向き=keys[1], 入る=keys[2], 選び方=how)
            for f in FORMS: row[f + '_平均'] = res[f][0]; row[f + '_年件数'] = res[f][1]
            row['プラスの数'] = int(np.nansum(vals > 0)); row['中央'] = np.nanmedian(vals)
            row['年件数_中央'] = np.nanmedian([res[f][1] for f in FORMS])
            # WF全期間の各年（前向き）
            tot = 0; cnt = 0
            for (tr, te), k in zip(FORMS['WF全期間'], res['WF全期間'][2]):
                b = yi[te[0]]; row[f'前向き{te[0]}'] = S[k, b] / C[k, b] if C[k, b] else np.nan; tot += S[k, b]; cnt += C[k, b]
            row['前向き合計'] = tot; row['前向き件数'] = cnt
            for lab, f, j in [('今', 'WF全期間', -1), ('前半で選んだ', '前半→後半', 0)]:
                if res[f][2]:
                    k = res[f][2][j]; qi, ei = divmod(k, nE); e = EXd.iloc[ei]
                    row[lab + 'の強さ'] = QN[qi]; row[lab + 'の手じまい'] = f"{e.型}:利確{e.利確}/損切り{e.損切り}/時間{e.時間}"
                    row[lab + '_k'] = k
            out.append(row)
    pd.to_pickle(store, O + f'{tag}_{fam}_store.pkl')
    return pd.DataFrame(out)

if __name__ == '__main__':
    T = pd.concat([evaluate(f) for f in sys.argv[1:]])
    T.to_pickle(O + 'EV2_' + ''.join(sys.argv[1:]) + '.pkl')
    T['残す'] = (T.プラスの数 >= 3) & (T.中央 >= 20) & (T.年件数_中央 >= 10)
    pd.set_option('display.width', 300); pd.set_option('display.max_rows', 500)
    c = ['区分', '観察', '向き', '入る', '選び方', 'プラスの数', '中央', '年件数_中央', '前向き合計', '前向き件数', '今の強さ', '今の手じまい']
    print(T[T.残す].sort_values('中央', ascending=False)[c].round(1).to_string())
    print('残す', T.残す.sum(), '/', len(T))
