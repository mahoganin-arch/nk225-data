# 法則の確認1：寄りの動き(先物)と、その後のCFDの動き（続く＋／戻る−）
import numpy as np, pandas as pd, sys
sys.path.insert(0,'/home/claude/yt/an'); from ev import *
s=pd.read_pickle(O+'sess.pkl'); s=s[s.t>=pd.Timestamp('2017-03-16',tz='Asia/Tokyo')].reset_index(drop=True)
yr=s.t.dt.year.values; half=np.where(yr<=2021,'前半','後半')
def stat(x,y,cut):
    z=y*np.sign(x); ok=~np.isnan(z)
    r={}
    for h in ['前半','後半','全体']:
        k=ok&((half==h) if h!='全体' else True)
        a=np.abs(x)>=cut; kk=k&a
        zz=z[kk]; r[h+'_n']=kk.sum(); r[h+'_平均bp']=zz.mean()*1e4; r[h+'_t']=zz.mean()/zz.std()*np.sqrt(len(zz)) if len(zz)>2 else np.nan
        r[h+'_続く%']=(zz>0).mean()*100
    return r
rows=[]
def run(kind,a,b,label,HS):
    k=(s.kind==kind).values
    x=(px(FM,FO,b)/px(FM,FO,a)-1); x[~k]=np.nan
    cut_src=np.abs(x[(half=='前半')&~np.isnan(x)])
    for q in [0,0.67,0.9]:
        cut=np.quantile(cut_src,q) if q>0 else 0
        for hn,e in HS:
            y=px(CM,CO,np.minimum(e,s.end.values-5))/px(CM,CO,b)-1
            r=dict(区分=kind,観察=label,強さ=f'上位{int(round((1-q)*100))}%' if q else '全部',境目pct=round(cut*100,3),その後=hn); r.update(stat(x,y,cut)); rows.append(r)
m0=s.m.values
last=FM[np.searchsorted(FM,s.end.values-1)-1]
end=np.where(s.kind=='N',last-5,last)+5  # 夜間は5:55、日中は引けの足
# 日中：8:45→9:00、9:00から
HS=[(f'{h}分',m0+15+h) for h in [5,10,15,30,60,120]]+[('11:30まで',m0+165),('引けまで',end-5)]
run('D',m0,m0+15,'8:45→9:00',HS)
run('D',m0,m0+5,'8:45→8:50',[(f'{h}分',m0+5+h) for h in [5,10,15,30,60,120]])
run('D',m0,m0+10,'8:45→8:55',[(f'{h}分',m0+10+h) for h in [5,10,15,30,60,120]])
for L in [5,10,15,30,60]:
    run('N',m0,m0+L,f'寄り→+{L}分',[(f'{h}分',m0+L+h) for h in [5,10,15,30,60,120,240]]+[('引けまで',end-5)])
R=pd.DataFrame(rows); R.to_pickle(O+'law1.pkl')
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
c=['区分','観察','強さ','その後','前半_n','前半_平均bp','前半_t','後半_n','後半_平均bp','後半_t','全体_平均bp','全体_t','全体_続く%']
print(R[c].round(1).to_string())
