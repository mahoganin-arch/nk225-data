import sys, pandas as pd
sys.path.insert(0,'/home/claude/yt/code')
import ld
D='/home/claude/yt/data/'; O='/home/claude/yt/out/'
def save():
    for n in ['c1','c5','f1','f5']:
        d=ld.bars(D+n+'.csv',until='2026-10-09'); d.to_pickle(O+n+'.pkl')
        print(n,len(d),d.t.iloc[0],d.t.iloc[-1], (d.m.diff().value_counts().head(3).to_dict()))
if __name__=='__main__': save()
