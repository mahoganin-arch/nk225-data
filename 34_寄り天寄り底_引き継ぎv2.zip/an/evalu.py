# 条件なし（強さの区分つき）を5つの評価の形で評価する
#   戦略＝(区分, 観察, 向き, 入る)。選ぶもの＝強さ(5段) × 手じまい(506)。
#   単点：選ぶ期間の平均が最良の1点。周辺：強さ・手じまいの各軸±1の平均が最良の点。
#   制約：選ぶ期間で 15件以上・最悪の1回 −1,000円以上。
import numpy as np, pandas as pd, sys
O = '/home/claude/yt/out/'
YEARS = np.arange(2017, 2027)
QS = [0, 0.5, 0.67, 0.8, 0.9]; QN = ['全部', '上位50%', '上位33%', '上位20%', '上位10%']
FORMS = {'前半→後半': [(range(2017, 2022), range(2022, 2027))],
         '22-23→24-26': [(range(2022, 2024), range(2024, 2027))],
         'WF後半': [(range(2022, y), [y]) for y in range(2023, 2027)],
         'WF全期間': [(range(2017, y), [y]) for y in range(2022, 2027)],
         'WF直近3年': [(range(y - 3, y), [y]) for y in range(2022, 2027)]}

def neighbors(EXd):
    n = len(EXd); key = {}
    for i, r in EXd.iterrows(): key[(r.型, r.ia, r.ib, r.ic)] = i
    NB = []
    for qi in range(len(QS)):
        for i, r in EXd.iterrows():
            L = []
            for dq in (-1, 0, 1):
                q2 = qi + dq
                if not 0 <= q2 < len(QS): continue
                for da in (-1, 0, 1):
                    for db in (-1, 0, 1):
                        for dc in (-1, 0, 1):
                            j = key.get((r.型, r.ia + da, r.ib + db, r.ic + dc))
                            if j is not None: L.append(q2 * n + j)
            NB.append(np.array(L))
    return NB

def yearly(R, yrs, mask):
    """R[件, 手じまい] → 年ごとの 合計・件数・最小 [手じまい, 年]"""
    nE = R.shape[1]; S = np.zeros((nE, len(YEARS))); C = np.zeros((nE, len(YEARS))); M = np.full((nE, len(YEARS)), np.inf)
    for k, y in enumerate(YEARS):
        sub = R[mask & (yrs == y)]
        if len(sub) == 0: continue
        ok = ~np.isnan(sub)
        S[:, k] = np.where(ok, sub, 0).sum(0); C[:, k] = ok.sum(0); M[:, k] = np.where(ok, sub, np.inf).min(0)
    return S, C, M

def evaluate(fam):
    meta = pd.read_pickle(O + f'E_{fam}_meta.pkl'); R = np.load(O + f'E_{fam}_R.npy')
    EXd = pd.read_pickle(O + 'EXITS.pkl')['D' if fam == 'D' else 'N']; nE = len(EXd)
    NB = neighbors(EXd)
    yrs = meta.t.dt.year.values; ax = np.abs(meta.x.values)
    out = []; picks = []
    for keys, g in meta.groupby(['観察', '向き', '入る'], sort=False):
        idx = g.index.values
        src = ax[idx][yrs[idx] <= 2021]
        cuts = [np.quantile(np.abs(meta.x[(meta.観察 == keys[0])].values[yrs[(meta.観察 == keys[0]).values] <= 2021]), q) if q > 0 else 0 for q in QS]
        S = []; C = []; M = []
        for qi, cut in enumerate(cuts):
            mk = np.zeros(len(meta), bool); mk[idx] = ax[idx] >= cut
            s, c, m = yearly(R, yrs, mk); S.append(s); C.append(c); M.append(m)
        S = np.vstack(S); C = np.vstack(C); M = np.vstack(M)   # [強さ×手じまい, 年]
        yi = {y: k for k, y in enumerate(YEARS)}
        for how in ['単点', '周辺']:
            res = {}
            for fn, splits in FORMS.items():
                ts = 0; tc = 0; tyears = 0; ch = []
                for tr, te in splits:
                    a = [yi[y] for y in tr]; b = [yi[y] for y in te]
                    sm = S[:, a].sum(1); cn = C[:, a].sum(1); mn = M[:, a].min(1)
                    mean = np.where(cn > 0, sm / np.maximum(cn, 1), np.nan)
                    ok = (cn >= 15) & (mn >= -1000)
                    if how == '単点': score = np.where(ok, mean, -np.inf)
                    else:
                        nbm = np.array([np.nanmean(mean[nb]) if len(nb) else np.nan for nb in NB])
                        score = np.where(ok, nbm, -np.inf)
                    score = np.nan_to_num(score, nan=-np.inf)
                    if not np.isfinite(score.max()): continue
                    k = int(np.argmax(score)); ch.append(k)
                    ts += S[k, b].sum(); tc += C[k, b].sum(); tyears += len(b)
                yrs_eff = tyears - (1 - 280 / 365) if 2026 in [y for _, te in splits for y in te] else tyears  # 2026年は10/8まで
                res[fn] = (ts / tc if tc else np.nan, tc / max(yrs_eff, 1e-9), ch)
            vals = np.array([res[f][0] for f in FORMS])
            row = dict(区分=fam, 観察=keys[0], 向き=keys[1], 入る=keys[2], 選び方=how)
            for f in FORMS: row[f + '_平均'] = res[f][0]; row[f + '_年件数'] = res[f][1]
            row['プラスの数'] = int(np.nansum(vals > 0)); row['中央'] = np.nanmedian(vals)
            row['年件数_中央'] = np.nanmedian([res[f][1] for f in FORMS])
            # 今のルール（2017〜2025年で選ぶ＝WF全期間の最後）
            k = res['WF全期間'][2][-1] if res['WF全期間'][2] else None
            if k is not None:
                qi, ei = divmod(k, nE); e = EXd.iloc[ei]
                row.update(今の強さ=QN[qi], 今の手じまい=f"{e.型}:利確{e.利確}/損切り{e.損切り}/時間{e.時間}")
            # 前半→後半で選んだルール
            k = res['前半→後半'][2][0] if res['前半→後半'][2] else None
            if k is not None:
                qi, ei = divmod(k, nE); e = EXd.iloc[ei]
                row.update(前半で選んだ強さ=QN[qi], 前半で選んだ手じまい=f"{e.型}:利確{e.利確}/損切り{e.損切り}/時間{e.時間}")
            out.append(row)
        print(fam, keys, flush=True)
    return pd.DataFrame(out)

if __name__ == '__main__':
    T = pd.concat([evaluate(f) for f in sys.argv[1:]]); T.to_pickle(O + 'EV0.pkl')
    pd.set_option('display.width', 250); pd.set_option('display.max_rows', 300)
    c = ['区分', '観察', '向き', '入る', '選び方'] + [f + '_平均' for f in FORMS] + ['プラスの数', '中央', '年件数_中央']
    print(T[c].round(1).to_string())
