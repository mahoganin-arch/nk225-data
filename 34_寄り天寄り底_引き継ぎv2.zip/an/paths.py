# CFDの値動き（2020/11/10以降は1分足、それ以前は5分足）と、手じまい用の指標（1・5・15・60分）
import numpy as np, pandas as pd
O='/home/claude/yt/out/'
def build():
    c1=pd.read_pickle(O+'c1.pkl'); c5=pd.read_pickle(O+'c5.pkl')
    t0=c1.m.iloc[0]+60*24   # 2020/11/10 から1分足
    c1=c1[c1.m>=t0]; a=c5[c5.m<t0].assign(tf=5); b=c1.assign(tf=1)
    P=pd.concat([a,b])[['m','open','high','low','close','tf']].reset_index(drop=True)
    P.to_pickle(O+'P.pkl')
    # 上位足：5分足から15・60分（日本時間の時刻で区切る）
    out={}
    def ind(d,tf,src):
        c=d.close.values
        dl=np.diff(c,prepend=c[0]); up=np.where(dl>0,dl,0); dn=np.where(dl<0,-dl,0)
        au=pd.Series(up).ewm(alpha=1/14,adjust=False).mean().values; ad=pd.Series(dn).ewm(alpha=1/14,adjust=False).mean().values
        rsi=100-100/(1+au/np.where(ad==0,1e-9,ad))
        hc=(d.open.values+d.high.values+d.low.values+c)/4; ho=np.empty_like(hc); ho[0]=(d.open.values[0]+c[0])/2
        for i in range(1,len(hc)): ho[i]=(ho[i-1]+hc[i-1])/2
        out[tf]=dict(m=d.m.values, end=d.m.values+tf, rsi=rsi, ha=np.sign(hc-ho), low=d.low.values, high=d.high.values, open=d.open.values, close=c, src=src)
    ind(c1.reset_index(drop=True),1,'c1')
    ind(c5.reset_index(drop=True),5,'c5')
    for tf in [15,60]:
        g=(c5.m//tf)*tf   # 分単位のUTC区切り（15・60分は日本時間と同じ区切り）
        d=c5.groupby(g).agg(open=('open','first'),high=('high','max'),low=('low','min'),close=('close','last')).reset_index().rename(columns={'m':'m'})
        d.columns=['m','open','high','low','close']; ind(d,tf,'c5')
    pd.to_pickle(out,O+'IND.pkl'); print(len(P), {k:len(v['m']) for k,v in out.items()})
if __name__=='__main__': build()
