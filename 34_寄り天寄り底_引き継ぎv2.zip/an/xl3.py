import pandas as pd, numpy as np
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
O='/home/claude/yt/out/'; F=O+'Y3_寄り天寄り底_売買別と高値安値引け.xlsx'
FORMS=['前半→後半','22-23→24-26','WF後半','WF全期間','WF直近3年']
T,Y=pd.read_pickle(O+'dir2.pkl')
s=T.groupby('売買').agg(候補=('id','nunique'),前向き合計=('前向き_合計','sum'),前向き件数=('前向き_件数','sum'),前向きプラスの候補=('前向き_合計',lambda v:(v>0).sum())).reset_index()
EV=pd.read_pickle(O+'EV2_H.pkl'); EV['残す']=np.where((EV.プラスの数>=3)&(EV.中央>=20)&(EV.年件数_中央>=10),'残す','')
ex=pd.DataFrame({'項目':['目的','売買別','高値引け・安値引け','引けの位置','最後30分','その後の区間','総当たり','注意'],
'内容':['①日中の寄り天（上の動きに売り）と寄り底（下の動きに買い）を分けて確かめる ②日中に高値引け・安値引けした後の CFD と夜間の寄り前後に優位性があるか（2026-10-15）',
'日中の残った候補48（Y2）を、売り・買いに分けて前向き（各年はその年より前で選んだルール）と今のルール（2017〜25年で選択）の成績を出した',
'先物の日中の高安の中で、引けがどこにあるか（引けの位置＝(終値−安値)/(高値−安値)）。高値引け＝0.9以上、安値引け＝0.1以下',
'向きは高値引けを＋。その後の CFD の動き×向きの平均（bp）：＋は続く、−は戻る',
'先物の引けの30分前から引けまでの動き。強さは前半の分布で上位33%・10%',
'引け→引け+15/30分、引け→夜間の寄りの15分前、寄りの15分前→寄り、寄り→+15〜240分、寄り→夜間の引け（5:55）',
'入る：引けの直後・引け+15分・寄りの15分前・寄り・寄り+5・寄り+15・確かめてから(c25/c50)。順張り・逆張り。手じまい506通り、13pt控除、5つの評価の形、残す基準は同じ',
'2025/4/7（日中の寄りが止まった日）など、先物の 8:45 の足が無い日は対象外（数日）']})
with pd.ExcelWriter(F) as w:
    ex.to_excel(w,sheet_name='説明',index=False)
    s.round(0).to_excel(w,sheet_name='売買別_まとめ',index=False)
    T.round(1).to_excel(w,sheet_name='売買別_候補ごと',index=False)
    Y.round(0).pivot_table(index=['id','観察','入る','選び方','売買'],columns='年',values='合計').reset_index().to_excel(w,sheet_name='売買別_年ごと',index=False)
    pd.read_pickle(O+'close1.pkl').round(1).to_excel(w,sheet_name='引け後_続くか戻るか',index=False)
    pd.read_pickle(O+'close2.pkl').round(1).to_excel(w,sheet_name='高値引けと安値引け',index=False)
    pd.read_pickle(O+'close1_year.pkl').round(1).to_excel(w,sheet_name='引け後_年ごと',index=False)
    c=['観察','向き','入る','選び方','残す']+[f+'_平均' for f in FORMS]+['プラスの数','中央','年件数_中央','前向き合計','前向き件数','今の強さ','今の手じまい']
    EV.sort_values('中央',ascending=False)[c].round(1).to_excel(w,sheet_name='引け後_総当たり',index=False)
wb=load_workbook(F)
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c_ in row: c_.font=Font(name='Arial',size=10,bold=(c_.row==1))
    for c_ in ws[1]: c_.fill=PatternFill('solid',fgColor='DDE4EE'); c_.alignment=Alignment(wrap_text=True,vertical='top')
    ws.freeze_panes='A2'
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width=min(max(len(str(col[0].value or ''))*1.6,9),40)
wb['説明'].column_dimensions['B'].width=110
for r in wb['説明'].iter_rows(min_row=2): r[1].alignment=Alignment(wrap_text=True,vertical='top')
wb.save(F); print(F); print(s)
