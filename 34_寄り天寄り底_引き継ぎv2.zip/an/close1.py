# 高値引け・安値引けの後：日中の引けの位置（先物の日中の高安の中の位置）と、最後30分の動き
#   → 引け後の CFD（先物が止まっている間）、夜間の寄りまで、寄りの後
#   向き：高値引け＝＋（上）。その後の動き × 向き の平均（bp）：＋は続く、−は戻る
import numpy as np, pandas as pd, sys
sys.path.insert(0, '/home/claude/yt/an')
from ev import FM, FO, CM, CO, px, O
f5 = pd.read_pickle(O + 'f5.pkl'); FH = f5.high.values; FL = f5.low.values; FC = f5.close.values
s = pd.read_pickle(O + 'sess.pkl'); s = s[s.t >= pd.Timestamp('2017-03-16', tz='Asia/Tokyo')].reset_index(drop=True)
last = FM[np.searchsorted(FM, s.end.values - 1) - 1]

def day_events():
    rows = []
    for i in range(len(s) - 1):
        if s.kind[i] != 'D' or s.kind[i + 1] != 'N': continue
        j0 = np.searchsorted(FM, s.m[i]); j1 = np.searchsorted(FM, last[i]) + 1
        hi = FH[j0:j1].max(); lo = FL[j0:j1].min(); cl = FC[j1 - 1]
        if hi <= lo: continue
        clv = (cl - lo) / (hi - lo)
        c30 = px(FM, FO, last[i] - 30)
        rows.append(dict(i=i, t=s.t[i], close_t=last[i] + 5, open_n=s.m[i + 1], cap_n=last[i + 1] - 5,
                         clv=clv, rng=(hi - lo) / cl, last30=cl / c30 - 1, fclose=cl, dayret=cl / FO[j0] - 1))
    return pd.DataFrame(rows)

if __name__ == '__main__':
    E = day_events(); E.to_pickle(O + 'close_ev.pkl')
    yr = E.t.dt.year.values; H1 = yr <= 2021
    c0 = px(CM, CO, E.close_t.values)                     # 引けの直後の CFD
    on = E.open_n.values; ct = E.close_t.values
    pts = {'引け+15分': ct + 15, '引け+30分': ct + 30, '寄りの15分前': on - 15, '夜間の寄り': on,
           '寄り+15分': on + 15, '寄り+30分': on + 30, '寄り+60分': on + 60, '寄り+120分': on + 120, '寄り+240分': on + 240,
           '夜間の引け(5:55)': E.cap_n.values}
    P = {k: px(CM, CO, v) for k, v in pts.items()}
    rows = []
    for obs, sig, grp in [('引けの位置', np.sign(E.clv - 0.5), None), ('最後30分の動き', np.sign(E.last30), None)]:
        if obs == '引けの位置':
            gdef = [('高値引け・安値引け(上下10%)', (E.clv >= 0.9) | (E.clv <= 0.1)), ('上下20%', (E.clv >= 0.8) | (E.clv <= 0.2)),
                    ('中ほど(40-60%)', (E.clv > 0.4) & (E.clv < 0.6))]
        else:
            a = np.abs(E.last30); q = [np.quantile(a[H1], p) for p in (0.67, 0.9)]
            gdef = [('上位10%', a >= q[1]), ('上位33%', a >= q[0]), ('下位67%', a < q[0])]
        for gn, gm in gdef:
            for a_name, b_name in [('引け', '引け+15分'), ('引け', '引け+30分'), ('引け', '寄りの15分前'), ('引け', '夜間の寄り'),
                                   ('寄りの15分前', '夜間の寄り'), ('夜間の寄り', '寄り+15分'), ('夜間の寄り', '寄り+30分'),
                                   ('夜間の寄り', '寄り+60分'), ('夜間の寄り', '寄り+120分'), ('夜間の寄り', '寄り+240分'),
                                   ('夜間の寄り', '夜間の引け(5:55)'), ('引け', '夜間の引け(5:55)')]:
                pa = c0 if a_name == '引け' else P[a_name]; pb = P[b_name]
                z = (pb / pa - 1) * sig * 1e4
                r = dict(観察=obs, 区分=gn, 区間=f'{a_name}→{b_name}')
                for hn, hm in [('前半', H1), ('後半', ~H1)]:
                    k = gm.values & hm & np.isfinite(z) & (sig != 0)
                    zz = z[k]; r[hn + '_n'] = k.sum(); r[hn + '_bp'] = zz.mean(); r[hn + '_t'] = zz.mean() / zz.std() * np.sqrt(len(zz)); r[hn + '_続く%'] = (zz > 0).mean() * 100
                rows.append(r)
    T = pd.DataFrame(rows); T.to_pickle(O + 'close1.pkl')
    # 年ごと：高値引け・安値引け(上下10%)、引け→夜間の寄り と 寄り→夜間の引け
    yrows = []
    sig = np.sign(E.clv - 0.5).values; gm = ((E.clv >= 0.9) | (E.clv <= 0.1)).values
    for y in range(2017, 2027):
        k = gm & (yr == y)
        for nm, pa, pb in [('引け→夜間の寄り', c0, P['夜間の寄り']), ('寄り→寄り+60分', P['夜間の寄り'], P['寄り+60分']), ('寄り→夜間の引け', P['夜間の寄り'], P['夜間の引け(5:55)'])]:
            z = (pb / pa - 1) * sig * 1e4; kk = k & np.isfinite(z)
            yrows.append(dict(年=y, 区間=nm, n=kk.sum(), bp=z[kk].mean()))
    Y = pd.DataFrame(yrows); Y.to_pickle(O + 'close1_year.pkl')
    pd.set_option('display.width', 250); pd.set_option('display.max_rows', 200)
    print(T.round(1).to_string()); print(Y.pivot(index='年', columns='区間', values='bp').round(1).to_string())
    print('高値引け(≥0.9)の割合', (E.clv >= 0.9).mean().round(3), '安値引け(≤0.1)', (E.clv <= 0.1).mean().round(3))
