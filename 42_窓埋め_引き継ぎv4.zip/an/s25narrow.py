# 売買する候補（両方＋売りのみ、上位5本）を、①入る窓の重なり75%以上をまとめる ②前向きPF1.2以上 で絞ったときの前向き検証
#   各年 t の判断は、その年より前の前向き記録（2022〜t−1年）だけで行う。前向き記録のない候補は残す
#   まとめるときは、前向きの合計÷最大DDの良い方を残す（同じ窓の種類の中で比べる）
import sys
src = open('/home/claude/work/08/an/s24minus.py').read(); exec(src[:src.index('PR = []\nfor dn')])
def fwd_stats(t, end_incl=False):
    past = WF[(WF['年'] <= t) if end_incl else (WF['年'] < t)].sort_values('手じまう時刻'); out = {}
    for k, g in past.groupby(['id', '窓の種類']):
        v = g['損益'].values; c = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, c])[1:] - c).max()
        gp, gl = v[v > 0].sum(), -v[v < 0].sum()
        out[k] = dict(ses=set(g['セッション']), rf=v.sum() / max(dd, 1.0), pf=gp / gl if gl > 0 else np.inf)
    return out
def narrow(L, fs, dedup, pfmin):
    keys = [(r[0], k[0]) for k, rows in L.items() for r in rows]
    if pfmin: keys = [k for k in keys if k not in fs or fs[k]['pf'] >= pfmin]
    if dedup:
        keep = []
        for k in sorted(keys, key=lambda k: -fs[k]['rf'] if k in fs else 0):
            ok = True
            for q in keep:
                if q[1] != k[1] or k not in fs or q not in fs: continue
                A, B = fs[k]['ses'], fs[q]['ses']
                if A and B and len(A & B) / len(A | B) >= dedup: ok = False; break
            if ok: keep.append(k)
        keys = keep
    ks = set(keys)
    return {key: [r for r in rows if (r[0], key[0]) in ks] for key, rows in L.items()}
def simulate_n(N, pol, dirs, dedup, pfmin):
    out = []
    for t in (2024, 2025, 2026):
        L = narrow(union_list(rank_old(t), rank_rf(t), N, dirs), fwd_stats(t), dedup, pfmin)
        allr = [(k, r) for k, rows in L.items() for r in rows]; allr.sort(key=lambda kr: (not kr[1][1], min(kr[1][2], kr[1][3]), kr[1][2]))
        pr = {(r[0], k[0]): p for p, (k, r) in enumerate(allr)}
        test = T0[(T0['t'] == t) & (T0['年'] == t)].copy(); test['順位'] = [pr.get((a, b), np.nan) for a, b in zip(test['id'], test['窓の種類'])]
        test = test[test['順位'].notna()].sort_values(['セッション', '入る時刻', '順位'])
        for s_, tr in test.groupby('セッション', sort=False):
            for h in run_window(tr.to_dict('records'), pol, False, fill.get(s_, np.inf)): h['確かめる年'] = t; out.append(h)
    return pd.DataFrame(out)
DIRS = ('両方', '売りのみ'); PR = []
for nm_, dd_, pf_ in (('そのまま', None, None), ('重なり75%でまとめる', .75, None), ('PF1.2以上', None, 1.2), ('両方', .75, 1.2)):
    L26 = narrow(union_list(rank_old(2026, True), rank_rf(2026, True), 5, DIRS), fwd_stats(2026, True), dd_, pf_); n26 = sum(len(v) for v in L26.values())
    for pol, pn in (('A1', '先着1本'), ('C1', '同じ向き2本'), ('D1', '両建て＋2本目')):
        H = simulate_n(5, pol, DIRS, dd_, pf_).sort_values('手じまう時刻'); r = stats(H['損益'].values, 3)
        r.update(絞り方=nm_, 今の本数=n26, 方針=pn, 最悪の1窓=H.groupby('セッション')['損益'].sum().min())
        for y, g in H.groupby('確かめる年'): r['%d年' % y] = g['損益'].sum()
        PR.append(r)
    if nm_ == '両方': pd.to_pickle(L26, W + '/S25L26.pkl')
PR = pd.DataFrame(PR); PR.to_pickle(W + '/S25port.pkl')
pd.set_option('display.width', 250)
print(PR[['絞り方', '今の本数', '方針', '件数', '勝率', 'PF', '平均', '合計', '最大DD', '合計割る最大DD', '最悪の1窓', '2024年', '2025年', '2026年']].round(2).to_string(index=False))
