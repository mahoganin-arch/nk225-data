import numpy as np, pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter
from lib import W
def dec_t(t):
    if not isinstance(t, tuple): return ''
    sl, tp, tm = t; return '損切り:戻り%d%% / 利確:%s / 時間:%s' % (round(sl * 100), 'なし' if tp == 0 else '幅×%g' % tp, '次の引け' if tm == 0 else '%d分' % tm)
def dec_r(t):
    if not isinstance(t, tuple): return ''
    tp, sl, tm = t; return '利確:窓の%d%% / 損切り:%s / 時間:%s' % (round(tp * 100), 'なし' if sl == 0 else '幅×%g' % sl, '次の引け' if tm == 0 else '%d分' % tm)
ST = pd.read_pickle(W + '/S3stop.pkl')
C = pd.read_pickle(W + '/S4C.pkl'); B = pd.read_pickle(W + '/S4B.pkl'); O = pd.read_pickle(W + '/S5overlap.pkl')
for d in (C, B): d['決済'] = d['決済'].map(dec_r)
CI = C.drop_duplicates(['分け方', '窓'])[['分け方', '窓', '入る指標', '避ける指標']]; C = C.drop(columns=['入る指標', '避ける指標'])
BS = B.groupby(['分け方', '窓']).agg(上位20組=('順位', 'size'), 選ぶ期間の中央t=('選ぶ期間:中央t', 'median'), 確かめる上乗せ_中央=('確かめる:上乗せ中央(全決済平均)', 'median'),
                                  確かめるで上乗せプラスの組の割合=('確かめる:上乗せ中央(全決済平均)', lambda s: (s > 0).mean() * 100),
                                  上位5組の確かめる平均_中央=('確かめる平均', 'median'), 上位5組で確かめる平均プラスの数=('確かめる平均', lambda s: int((s > 0).sum()))).reset_index()
exp = [
 ['①順張りの止める仕組み・②逆張り（C・B）・③同時運用の重なり（2026-10-13）'], [''],
 ['共通', 'コスト13pt控除後。判定・選択はすべてその時点より前のデータ（選ぶ期間）だけで行う'],
 ['① 目印（事前に固定）', 'I1 続いた率：直近60窓のうち、乖離0.5%に届いた後、基準に戻る前に乖離幅の2倍まで進んだ割合 > 0.5 なら入る'],
 ['', 'I2 直近成績：そのルール自体の直近50回の損益合計 > 0 なら入る ／ I3 日足ATRの直近365日での順位 ≥ 0.5 ／ I4 日足ADXの直近365日での順位 ≥ 0.5'],
 ['', '感度（参考、選んではいない）：I1 30・120窓、I2 25・100回、I3・I4 180日'],
 ['① 対象', '固定ルール3つ（両方の窓。2025年までを見て選んだ形なので参考）と、前向き検証の記録（両方の窓・条件なし・周辺の選び方。年ごとに選び直したルール）'],
 ['① 列', '止めた分の合計＝止めたトレードの損益の合計（プラスなら止めて損をした）'],
 ['② 逆張り', '独立したストラテジーとして、乖離幅・決済・指標を逆張り自身の成績で選ぶ。区分の境目は選ぶ期間の全エントリーで決めた1つの値'],
 ['② 分け方', '前半→後半 ／ 2017-21→2022-23 ／ 2017-23→2024-26 ／ 2022-23→2024-26（後半重視）'],
 ['② ふるい分けの尺度', '1エントリーの1,944決済の平均損益（控除後）。条件なし（同じ窓・乖離幅・期間）との差＝上乗せ。乖離幅ごとのtの中央値'],
 ['② C 投票方式', '中央t ≥ 1.5 の区分（入る）と ≤ −1.5（避ける）から系統ごとに代表、各最大5つ。点数＝入る該当数−避ける該当数'],
 ['② B 2指標', '|中央t| ≥ 1.0、該当率5〜60%の区分どうし（違う系統）の組み合わせから、選ぶ期間の中央tの上位20組。上位5組は決済も選んで確かめる'],
 ['② 決済の選び方', '選ぶ期間で、周辺（乖離幅・利確・損切り・時間の各軸±1）の平均が最良の点。最悪の1回 −1,000円以上、15件以上'],
 ['② 決済の表記（逆張り）', '利確:窓の○% ＝ 基準までの距離の○%戻ったら利確（100%超は基準を越えた位置）／損切り:幅×○ ＝ エントリーから乖離幅の○倍逆行で損切り'],
 ['③ 重なり', '確かめる期間でプラスだった逆張りの候補（30件以上）と、順張りの固定ルール2つを同じ期間で同時に運用した場合'],
 ['確認', '① 常に入るの値はステップ2の固定ルールと一致。② 2022-23→2024-26 D>N 条件なしの確かめる成績を独立に再計算して一致'],
]
out = W + '/S3_止める仕組み_逆張り_重なり.xlsx'
with pd.ExcelWriter(out, engine='openpyxl') as xw:
    pd.DataFrame(exp).to_excel(xw, sheet_name='説明', index=False, header=False)
    ST.round(1).to_excel(xw, sheet_name='①止める仕組み', index=False)
    C.round(1).to_excel(xw, sheet_name='②C投票方式', index=False)
    CI.to_excel(xw, sheet_name='②C選んだ指標', index=False)
    BS.round(1).to_excel(xw, sheet_name='②B要約', index=False)
    B.round(1).to_excel(xw, sheet_name='②B上位20組', index=False)
    O.round(1).to_excel(xw, sheet_name='③重なり', index=False)
wb = load_workbook(out); hf = PatternFill('solid', fgColor='DDEBF7')
for ws in wb:
    for row in ws.iter_rows():
        for c in row: c.font = Font(name='Arial', size=10, bold=(c.row == 1))
    if ws.title == '説明':
        ws.column_dimensions['A'].width = 20; ws.column_dimensions['B'].width = 150; continue
    for c in ws[1]: c.fill = hf; c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.row_dimensions[1].height = 60; ws.freeze_panes = 'C2'
    for i in range(1, ws.max_column + 1): ws.column_dimensions[get_column_letter(i)].width = 12
    for i, c in enumerate(ws[1], 1):
        if c.value in ('対象', '目印', '指標1', '指標2', '逆張り候補', '順張り', '決済'): ws.column_dimensions[get_column_letter(i)].width = 36
        if c.value in ('入る指標', '避ける指標'): ws.column_dimensions[get_column_letter(i)].width = 90
wb.save(out); print(out)
