# Pine v0.8（条件あり）と照合する Python の答え：61本（2026年のルール・条件あり）を同じ向き2本・入り直しなしで動かした一覧（2026/9/1〜10/8）と、入った時の指標の値
import sys, numpy as np, pandas as pd
sys.argv = [sys.argv[0]]
exec(open('/home/claude/work/08/an/s13sim.py').read().split("if __name__ == '__main__':")[0])
from s10scr import load
W = '/home/claude/work'
S = pd.read_pickle(W + '/S37rules.pkl'); C = pd.read_pickle(W + '/S21cands.pkl').set_index('id')
T = pd.read_pickle(W + '/S20trades.pkl'); T = T[(T['評価'] == 'WF全期間') & (T['選び方'] == '周辺') & (T['t'] == 2026) & (T['年'] == 2026)]
DS = {('現行', '順張り'): W + '/T', ('先物基準', '順張り'): W + '/F6W/T6', ('現行', '逆張り'): W + '/R', ('先物基準', '逆張り'): W + '/F6W/R6'}
Fs = {k: load(d)[3] for k, d in DS.items()}
from s9cal import flags
FLs = {k: flags(pd.read_pickle(d + '/evt.pkl')).iloc[pd.read_pickle(d + '/en.pkl').ev.values].reset_index(drop=True) for k, d in DS.items()}
rows = []
for k, r in S.iterrows():
    tt = T[(T['id'] == r['id']) & (T['窓の種類'] == r['窓の種類'])].copy()
    if not len(tt): continue
    key = (r['定義'], r['向き']); ind = r['指標(内部名)']
    F = Fs[key]
    tt['v'] = F[ind].values[tt['row'].values] if ind in F.columns else FLs[key][ind].values[tt['row'].values].astype(float)
    tt['#'] = k + 1; tt['名前'] = r['名前']; tt['順位'] = k
    rows.append(tt)
TT = pd.concat(rows, ignore_index=True)
tz = lambda v: pd.to_datetime(np.asarray(v, float) * 60, unit='s', utc=True).tz_convert('Asia/Tokyo')
TT = TT[tz(TT['入る時刻']) >= pd.Timestamp('2026-09-01', tz='Asia/Tokyo')]
out = []
for s_, tr in TT.sort_values(['セッション', '入る時刻', '順位']).groupby('セッション', sort=False):
    out += run_window(tr.to_dict('records'), 'C1', False, np.inf)
H = pd.DataFrame(out).sort_values('入る時刻')
H['入る（日本時間）'] = tz(H['入る時刻']).strftime('%Y-%m-%d %H:%M'); H['手じまう（日本時間）'] = tz(H['手じまう時刻']).strftime('%Y-%m-%d %H:%M')
H['売買'] = np.where(H['向き'] > 0, '買い', '売り')
cols = ['入る（日本時間）', '窓の種類', '#', '名前', '売買', '入る値段', 'v', '手じまう（日本時間）', '手じまう値段', '損益']
H[cols].round(4).to_csv(W + '/08/results/照合用_条件あり_61本_2026-09-01_10-08.csv', index=False, encoding='utf-8-sig')
print(len(H), round(H['損益'].sum())); print(H[cols].round(3).to_string(index=False))
