# ①順張りの止める仕組み（すべて各窓の基準時刻より前のデータだけで判定）
#   目印（事前に固定）：
#     I1 続いた率   : 直近60窓（乖離0.5%に届いた窓）のうち、基準へ戻る前に乖離幅の2倍まで進んだ割合。0.5超なら入る（偏りのない値動きなら0.5）
#     I2 直近成績   : そのルール自体の直近50回の損益合計（控除後）がプラスなら入る
#     I3 日足ATR    : 日足ATR（価格比）の直近365日の中での順位が0.5以上なら入る
#     I4 日足ADX    : 日足ADXの直近365日の中での順位が0.5以上なら入る
#   感度（参考）：I1 30/120窓、I2 25/100回、I3/I4 180日
import sys, numpy as np, pandas as pd
from lib import *
sys.path.insert(0, '/home/claude/work/01/code'); import ld, indlib
SP = 13.0
Y, en, F, F2 = setup('順張り'); ev = pd.read_pickle(W + '/T/evt.pkl'); NE = len(ev); Bp = ev.B.values[en.ev.values]
ok = ~en.long.values; both = np.isin(en.kind.values, ['D>N', 'N>D'])
def series(x, ex):
    """全イベントの、ルール (乖離幅x, 決済番号ex) の控除後損益（入らなかった窓は NaN）"""
    r = np.nonzero(ok & both & np.isclose(en.x.values, x))[0]; s = np.full(NE, np.nan)
    s[en.ev.values[r]] = np.asarray(Y[r, ex], float) / 100 * P - SP * P / Bp[r]; return s
def roll_prev(s, n, fn):
    """各イベントについて、それより前の（NaNでない）直近n個に fn を適用"""
    out = np.full(NE, np.nan); idx = np.nonzero(~np.isnan(s))[0]; v = s[idx]
    pos = np.searchsorted(idx, np.arange(NE))                     # イベントeより前の個数
    cs = np.r_[0, np.cumsum(v)]
    for e in range(NE):
        k = pos[e]
        if k >= n: out[e] = fn(cs, k - n, k)
    return out
# I1：続いた率（0.5%、損切り=基準、利確=乖離幅×1、引けまで）
_r = np.nonzero(ok & np.isclose(en.x.values, .5))[0]; cont = np.full(NE, np.nan)
cont[en.ev.values[_r]] = (np.asarray(Y[_r, CBI[(1.0, 1.0, 0)]], float) > 0).astype(float)   # コスト控除前の向きだけで判定
def I1(n): r = roll_prev(cont, n, lambda cs, a, b: (cs[b] - cs[a]) / n); return r > .5, r
def I2(s, n): r = roll_prev(s, n, lambda cs, a, b: cs[b] - cs[a]); return r > 0, r
# I3/I4：日足ATR・ADXの順位
c5 = ld.bars(W + '/data/c5.csv', until='2026-10-09'); x = c5.rename(columns={'open': 'o', 'high': 'h', 'low': 'l', 'close': 'c'})[['m', 'o', 'h', 'l', 'c']]
dk = (x.m.astype('int64') + 120) // 1440; b = x.groupby(dk).agg(o=('o', 'first'), h=('h', 'max'), l=('l', 'min'), c=('c', 'last'))
ind = indlib.ind(b, [20, 25, 75]); av = (b.index.values + 1) * 1440 - 120
pend = ev.pend.values.astype('int64')
def dayrank(vals, days):
    ok_ = ~np.isnan(vals); a = av[ok_]; v = vals[ok_]; r = np.full(NE, np.nan)
    for e, pe in enumerate(pend):
        hi = np.searchsorted(a, pe, side='right'); lo = np.searchsorted(a, pe - days * 1440, side='left')
        if hi - lo >= 60: r[e] = (v[lo:hi] <= v[hi - 1]).mean()
    return r
RK = {('ATR', d): dayrank(ind['atr'].values, d) for d in (180, 365)} | {('ADX', d): dayrank(ind['adx'].values, d) for d in (180, 365)}
def gates(s):
    g = {'常に入る': np.ones(NE, bool)}
    for n in (60, 30, 120): g['I1 続いた率(%d窓)' % n] = I1(n)[0]
    for n in (50, 25, 100): g['I2 直近成績(%d回)' % n] = I2(s, n)[0]
    for k in ('ATR', 'ADX'):
        for d in (365, 180): g['I%d 日足%s順位(%d日)' % (3 if k == 'ATR' else 4, k, d)] = RK[(k, d)] >= .5
    return g
MAIN = ['常に入る', 'I1 続いた率(60窓)', 'I2 直近成績(50回)', 'I3 日足ATR順位(365日)', 'I4 日足ADX順位(365日)']
def maxdd(v):
    c = np.cumsum(v); return float((np.maximum.accumulate(np.r_[0, c])[1:] - c).max()) if len(v) else np.nan
yr_ev = ev.t0.dt.year.values
def evaluate(base, s, g):
    rows = []
    for gname, on in g.items():
        t = ~np.isnan(s) & (on == True); v = s[t]; y = yr_ev[t]; tall = ~np.isnan(s)
        r = {'対象': base, '目印': gname, '主な目印': gname in MAIN, '入った割合%': t.sum() / max(1, tall.sum()) * 100, '件数': int(t.sum()), '平均': v.mean() if len(v) else np.nan, '合計': v.sum(),
             '前半合計': v[y <= 2021].sum(), '後半合計': v[y >= 2022].sum(), '最大DD': maxdd(v), '後半最大DD': maxdd(v[y >= 2022]),
             '止めた分の合計': s[tall & ~(on == True)].sum()}
        for yy in range(2017, 2027): r[str(yy)] = v[y == yy].sum()
        rows.append(r)
    return rows
rows = []
RULES = [('後半型：0.9%・戻り90%・利確×1.5・引け', .9, (0.9, 1.5, 0)), ('中間：0.9%・戻り90%・利確×0.6・引け', .9, (0.9, .6, 0)), ('前半型：0.8%・戻り125%・利確×0.75・120分', .8, (1.25, .75, 120))]
for name, x_, exk in RULES:
    s = series(x_, CBI[exk]); rows += evaluate('固定 ' + name, s, gates(s))
# 前向き検証（両方の窓・条件なし・周辺）：年ごとに選ばれたルールを使う。I2 はその年のルールを過去に当てはめた成績
REC = pd.read_pickle(W + '/S2rec.pkl'); PK = pd.read_pickle(W + '/S2pick.pkl')
for scn in ('WF全期間', 'WF後半', 'WF直近3年'):
    pk = PK[(PK['評価'] == scn) & (PK['窓'] == '両方の窓') & (PK['戦略'] == '条件なし') & (PK['選び方'] == '周辺')]
    s_all = np.full(NE, np.nan); gate_all = None
    for _, p in pk.iterrows():
        s = series(p['乖離幅'], CBI[(round(p['決済'][0], 3), round(p['決済'][1], 3), int(p['決済'][2]))]); g = gates(s); m = yr_ev == p['確かめる年']
        s_all[m] = s[m]
        if gate_all is None: gate_all = {k: np.zeros(NE, bool) for k in g}
        for k in g: gate_all[k][m] = g[k][m]
    rows += evaluate('前向き検証 ' + scn + '（両方の窓・条件なし・周辺）', s_all, gate_all)
O = pd.DataFrame(rows); O.to_pickle(W + '/S3stop.pkl')
pd.set_option('display.width', 260); pd.set_option('display.max_rows', 200)
print(O.drop(columns=['主な目印']).round(0).to_string(index=False))
