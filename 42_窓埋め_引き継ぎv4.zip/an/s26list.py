# 売買する候補（63本）と記録だけの候補の一覧・Excel
#   売買する：両方＋売りのみ、上位5本（案3）、前向きでマイナスを外す、入る窓の重なり75%以上はまとめる（合計÷最大DDの良い方を残す）、前向きPF1.2以上
#   記録だけ：買いのみ／PF1.2未満／重なりでまとめた側／前向きでマイナス（S18で外した12本）
import pandas as pd, numpy as np
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
W = '/home/claude/work'; OUT = W + '/08/results/S19_売買する候補63本.xlsx'
U = pd.read_pickle(W + '/S24list.pkl'); L26 = pd.read_pickle(W + '/S25L26.pkl'); J = np.load(W + '/S25J.npy'); UU = pd.read_pickle(W + '/S25U.pkl')
U['key'] = list(zip(U['id'], U['窓の種類']))
allr = [(k, r) for k, rows in L26.items() for r in rows]; allr.sort(key=lambda kr: (not kr[1][1], min(kr[1][2], kr[1][3]), kr[1][2]))
gp = {(r[0], k[0]): p + 1 for p, (k, r) in enumerate(allr)}; bp = {(r[0], k[0]): p + 1 for k, rows in L26.items() for p, r in enumerate(rows)}
U['全体の優先順位'] = U['key'].map(gp); U['区分内の優先順位'] = U['key'].map(bp)
lab = dict(zip(UU['key'], UU['窓の種類'] + ' ' + UU['向き'] + ' ' + UU['売買'] + ' ' + UU['候補'] + ' ' + UU['使い方'] + ' [' + UU['定義'] + ']'))
ukeys = list(UU['key'])
def why(r):
    if r['key'] in gp: return '売買する'
    if r['売買'] == '買いのみ': return '記録だけ：買いのみ'
    if r['前向き:PF'] < 1.2: return '記録だけ：PF1.2未満'
    a = ukeys.index(r['key']); m = [lab[ukeys[b]] for b in np.nonzero(J[a] >= .75)[0] if ukeys[b] in gp]
    return '記録だけ：重なり75%%以上（残した方：%s）' % ' / '.join(m)
U['扱い'] = U.apply(why, axis=1)
O = pd.read_pickle(W + '/S24out.pkl').copy(); O['扱い'] = '記録だけ：前向きでマイナス（S18で外した）'
A = pd.concat([U, O], ignore_index=True)
A.to_pickle(W + '/S26all.pkl')
cols = ['扱い', '全体の優先順位', '窓の種類', '向き', '売買', '区分内の優先順位', '候補', '使い方', '条件', '定義', '候補の窓', 'テーマ', '今のルール',
        '前向き:件数', '前向き:勝率', '前向き:PF', '前向き:平均', '前向き:合計', '前向き:最大DD', '前向き:合計割る最大DD', '前向き:最悪の1回', '前向き:最大連敗', 'プラスの年', '年の数',
        '2022年', '2023年', '2024年', '2025年', '2026年', '両方に入る', '前の付け方の順位', '新しい付け方の順位', 'id']
S = A[A['扱い'] == '売買する'].sort_values('全体の優先順位'); R = A[A['扱い'] != '売買する'].sort_values(['扱い', '窓の種類', '向き', '売買'])
P1 = pd.read_pickle(W + '/S25port.pkl'); P2 = pd.read_pickle(W + '/S25pf.pkl'); P = pd.concat([P1, P2[P2['絞り方'] != '両方 PF1.2']], ignore_index=True)
pc = ['絞り方', '今の本数', '方針', '件数', '勝率', 'PF', '平均', '合計', '最大DD', '合計割る最大DD', '2024年', '2025年', '2026年']
desc = [
 ['この表について', '売買する候補63本と、記録だけにする候補の一覧（まろ、2026-10-14）'],
 ['売買する候補の決め方', '①両方＋方向別の候補から、区分（窓の種類×向き×売買）ごとに案3で上位5本 ②前向きの合計がマイナスのものを外す ③買いのみは記録だけ ④入る窓が75%以上重なるものはまとめる（前向きの合計÷最大DDの良い方を残す）⑤前向きPF1.2以上'],
 ['優先順位', '全体の優先順位＝同時にシグナルが出たときの順（①両方の物差しに入る ②2つの順位の良い方 ③前の付け方の順位）。区分内の優先順位は参考'],
 ['前向き', '2022年〜2026/10/8。各年はその年より前のデータで決めたルールで売買した成績。1枚＝68,800円換算、13pt控除後、円'],
 ['前向き検証', '2024〜26年、両方＋売りのみ、上位5本。絞り方ごと。各年の判断はその年より前のデータだけ。63本・同じ向き2本：合計59,091円、最大DD 6,580円、合計÷最大DD 8.98'],
 ['記録だけ', '売買はしないが、シグナルと成績は記録する。2026/10/9以降の成績で売買に入れるかを判断する'],
 ['シート', '売買する（63本）／記録だけ／前向き検証'],
]
with pd.ExcelWriter(OUT, engine='openpyxl') as w:
    pd.DataFrame(desc, columns=['項目', '内容']).to_excel(w, sheet_name='説明', index=False)
    S[cols].round(2).to_excel(w, sheet_name='売買する（63本）', index=False)
    R[cols].round(2).to_excel(w, sheet_name='記録だけ', index=False)
    P[pc].round(2).to_excel(w, sheet_name='前向き検証', index=False)
wb = load_workbook(OUT); red = Font(name='Arial', size=10, color='C00000')
for ws in wb:
    for row in ws.iter_rows():
        for c in row:
            c.font = Font(name='Arial', size=10, bold=c.row == 1)
            if c.row > 1 and isinstance(c.value, (int, float)) and not isinstance(c.value, bool) and c.value < 0: c.font = red
    for c in ws[1]: c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.freeze_panes = 'H2' if ws.title != '説明' and ws.title != '前向き検証' else 'A2'
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = 11
ws = wb['説明']; ws.column_dimensions['A'].width = 18; ws.column_dimensions['B'].width = 150
for c in ws['B']: c.alignment = Alignment(wrap_text=True, vertical='top')
for n in ('売買する（63本）', '記録だけ'):
    ws = wb[n]; ws.column_dimensions['A'].width = 24 if n == '売買する（63本）' else 60; ws.column_dimensions['G'].width = 28; ws.column_dimensions['I'].width = 36; ws.column_dimensions['M'].width = 70
wb.save(OUT)
print(A['扱い'].str.split('（').str[0].value_counts().to_string())
print(S.groupby(['窓の種類', '向き', '売買']).size().to_string())
print(S[['全体の優先順位', '窓の種類', '向き', '売買', '候補', '使い方', '定義', '前向き:件数', '前向き:PF', '前向き:合計']].round(2).head(15).to_string(index=False))
