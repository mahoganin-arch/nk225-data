# 買い・売りに分けたふるい分け（まろ、2026-10-13：2023年以降の上昇相場で買いの放置が良く見えるだけではないか、片方だけなら良い候補はないか）
#   対象：条件なし＋F6・F7 の全区分 × 買いのみ／売りのみ × 現行・先物基準 × 順張り・逆張り × 3窓
#   買い：順張りは上に離れた窓（d=−1）、逆張りは下に離れた窓（d=+1）
#   尺度：1エントリーの1,944決済の平均損益（13pt控除後）。比べる相手＝同じ窓・乖離幅・期間の条件なし（買い売り両方）
#   通過：前半（2017〜21年）と後半（2022〜26年）で上乗せの向きが同じ、後半の中央t の絶対値 ≥ 1、後半の該当率2%以上
#     → 前半でも同じ向きを求めるので、2023年以降の上昇相場だけで良く見えるものは通りにくい
#   1時間足の出来高（2023年〜）の指標は、2023年で境目を決め 2024〜26年でふるう
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/work/01/code'); from common6 import jname
from s10scr import load, make_bins, uplift, LATE
W = '/home/claude/work'
SEGS = {'D>N': ['D>N'], 'N>D': ['N>D'], '両方の窓': ['D>N', 'N>D']}
RUNS = [('現行', '順張り', W + '/T'), ('先物基準', '順張り', W + '/F6W/T6'), ('現行', '逆張り', W + '/R'), ('先物基準', '逆張り', W + '/F6W/R6')]
rows = []
for lab, side, d in RUNS:
    Y, en, MN, F = load(d); ok = ~en.long.values; yr = en.yr.values; XP = np.array(sorted(en.x.unique()))
    buy = (en.d.values < 0) if side == '順張り' else (en.d.values > 0)
    ba = make_bins(F.drop(columns=list(LATE)), ok & (yr <= 2021)); bl = make_bins(F[list(LATE)], ok & (yr == 2023))
    ba[('条件なし', '')] = np.ones(len(en), bool)
    for bins, late in ((ba, False), (bl, True)):
        keys = list(bins); Bm0 = np.array([bins[k] for k in keys])
        for dname, dm in (('買いのみ', buy), ('売りのみ', ~buy)):
            Bm = Bm0 & dm[None, :]
            for w, kinds in SEGS.items():
                if late: tA, dA = uplift(Bm, MN, en, ok, yr == 2023, kinds, XP); tB, dB = uplift(Bm, MN, en, ok, yr >= 2024, kinds, XP)
                else: tA, dA = uplift(Bm, MN, en, ok, yr <= 2021, kinds, XP); tB, dB = uplift(Bm, MN, en, ok, yr >= 2022, kinds, XP)
                cov = Bm[:, ok & np.isin(en.kind.values, kinds) & (yr >= 2022)].mean(1)
                for i, k in enumerate(keys):
                    rows.append(dict(定義=lab, 向き=side, 売買=dname, 窓=w, 指標=k[0], 区分=k[1], 後半のみ=late, 該当率=cov[i], 前半t=tA[i], 前半上乗せ=dA[i], 後半t=tB[i], 後半上乗せ=dB[i]))
        print(lab, side, len(rows), flush=True)
S = pd.DataFrame(rows)
S['通過'] = (np.sign(S['前半上乗せ']) == np.sign(S['後半上乗せ'])) & (S['後半上乗せ'] > 0) & np.where(S['後半のみ'], S['後半t'].abs() >= 1.5, S['後半t'].abs() >= 1.0) & (S['該当率'] >= .02)
S.loc[S['指標'] == '条件なし', '通過'] = True          # 方向だけの条件なしは必ず評価する
S.to_pickle(W + '/S18scr.pkl')
print(S.groupby(['定義', '向き', '売買', '窓'])['通過'].agg(['sum', 'size']).to_string())
