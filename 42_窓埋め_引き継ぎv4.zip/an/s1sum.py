import numpy as np, pandas as pd
from lib import W
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 40)
def summ(sp):
    R = pd.read_pickle(W + '/S1_%g.pkl' % sp); out = []
    for (w, s), g in R.groupby(['窓', '戦略'], sort=False):
        best = g.loc[g['前半選択_前半平均'].idxmax()]; good = g[g['前半選択_前半平均'] >= 20]
        h = g.dropna(subset=['後半内_22-23平均']); b2 = h.loc[h['後半内_22-23平均'].idxmax()] if len(h) else None; good2 = h[h['後半内_22-23平均'] >= 20]
        out.append({'窓': w, '戦略': s, 'A主要': bool(g['A主要'].iloc[0]),
            '①前半最良の幅': best['乖離幅%'], '①決済': best['前半選択_決済'], '①前半': best['前半選択_前半平均'], '①後半': best['前半選択_後半平均'], '①後半件数': best['前半選択_後半件数'], '①後半最悪': best['前半選択_後半最悪'], '①後半DD': best['前半選択_後半最大DD'], '①後半分岐pt': best['前半選択_後半_損益分岐pt'],
            '②前半+20の幅数': len(good), '②その幅の後半中央': good['前半選択_後半平均'].median(), '②後半プラス%': (good['前半選択_後半平均'] > 0).mean() * 100 if len(good) else np.nan,
            '③22-23最良の幅': b2['乖離幅%'] if b2 is not None else np.nan, '③決済': b2['後半内_決済'] if b2 is not None else None, '③22-23': b2['後半内_22-23平均'] if b2 is not None else np.nan, '③24-26': b2['後半内_24-26平均'] if b2 is not None else np.nan, '③24-26件数': b2['後半内_24-26件数'] if b2 is not None else np.nan,
            '④22-23+20の幅数': len(good2), '④その幅の24-26中央': good2['後半内_24-26平均'].median(), '④24-26プラス%': (good2['後半内_24-26平均'] > 0).mean() * 100 if len(good2) else np.nan,
            '全幅:後半全決済平均の最大': g['全決済平均_後半'].max(), '全幅:後半プラス決済%の最大': g['後半プラス決済%'].max()})
    return pd.DataFrame(out)
for sp in (0, 13, 20):
    S = summ(sp); S.to_pickle(W + '/S1sum_%g.pkl' % sp)
    print('\n######## スプレッド', sp)
    print(S.drop(columns=['①決済', '③決済']).round(1).to_string(index=False))
