# 再選定で選ばれた（乖離幅・決済）について、トレード単位の詳細を計算
import sys, time, numpy as np, pandas as pd
from lib import *
side = sys.argv[1]; dd = W + ('/R' if side == '逆張り' else '/T')
Y, en, F, F2 = setup(side); z = dict(np.load(dd + '/resel.npz')); fam = pd.read_pickle(dd + '/resel_fam.pkl')
XP = z['XP']; bx = z['best_x']; be = z['best_e']; NF = len(fam)
sh = bx.shape
out = {k: np.full(sh, np.nan, np.float32) for k in ('wA', 'wB', 'w2A', 'w2B', 'winA', 'winB', 'pfA', 'pfB', 'ypA', 'ynA', 'ypB', 'ynB')}
YM = np.full(sh + (10,), np.nan, np.float32)                             # 年別平均（2017〜2026）
two = fam['指標2'] != ''
t0 = time.time()
for xi, x in enumerate(XP):
    need = np.nonzero((bx == xi).any((1, 2)))[0]
    if not len(need): continue
    idx = np.nonzero((~en.long.values) & np.isclose(en.x.values, x))[0]
    kind = en.kind.values[idx]; half = en.half.values[idx]; yi = en.yr.values[idx] - 2017
    f1 = F.iloc[idx]; f2 = F2.iloc[idx]; segm = {s: np.isin(kind, g) for s, g in SEGS.items()}
    Yx = np.asarray(Y[idx], dtype=np.float32) / 100 * P; c1 = {}; c2 = {}
    for i in need:
        r = fam.iloc[i]
        if r['指標2'] == '':
            if r['指標1'] not in c1: c1[r['指標1']] = dict(bins_for(f1[r['指標1']].values.astype(float), None))
            lab = ('=' + r['区分1'][1:]) if r['区分1'].startswith('値') else r['区分1']; mk = segm[r['窓']] & c1[r['指標1']][lab]
        else:
            mk = segm[r['窓']].copy()
            for k, lab in ((r['指標1'], r['区分1']), (r['指標2'], r['区分2'])):
                if k not in c2: c2[k] = b3lab(k, f2[k].values.astype(float))
                mk &= c2[k][lab]
        rows = np.nonzero(mk)[0]; hh = half[rows]; yy = yi[rows]
        sk = np.argwhere(bx[i] == xi)
        for si, k in sk:
            y = Yx[rows, be[i, si, k]]
            for h, sfx in (('A', 'A'), ('B', 'B')):
                m = hh == h; v = np.sort(y[m])
                if not len(v): continue
                out['w' + sfx][i, si, k] = v[0]; out['w2' + sfx][i, si, k] = v[1] if len(v) > 1 else np.nan
                out['win' + sfx][i, si, k] = (v > 0).mean() * 100; out['pf' + sfx][i, si, k] = v[v > 0].sum() / max(-v[v < 0].sum(), 1e-6)
                yl = yy[m]; cnt = np.bincount(yl, minlength=10); s = np.bincount(yl, weights=y[m], minlength=10)
                rng = slice(0, 5) if h == 'A' else slice(5, 10); ok = cnt[rng] >= 3
                out['yp' + sfx][i, si, k] = ((s[rng] > 0) & ok).sum(); out['yn' + sfx][i, si, k] = ok.sum()
            cnt = np.bincount(yy, minlength=10); s = np.bincount(yy, weights=y, minlength=10)
            YM[i, si, k] = np.where(cnt > 0, s / np.maximum(cnt, 1), np.nan)
    print('x', x, '対象', len(need), round(time.time() - t0), 's', flush=True)
np.savez_compressed(dd + '/detail.npz', YM=YM, **out); print('saved')
