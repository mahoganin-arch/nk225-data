# 方向別の候補を重なりでまとめる（買い売り両方の候補は S12 のグループをそのまま使う）
#   s12group.py と同じ方法：乖離幅0.2〜1.5%の格子の (セッション, 乖離幅) の集合（2022年以降、1時間足の出来高は2023年以降）でOchiai、平均連結、0.5で切る
#   方向別では、向き×売買（買いのみ／売りのみ）×種類（入る／避ける）ごと。「避ける」は外す集合どうしで比べる
#   「入る」と「避ける」で中身が同じもの（2値の指標の =0 を避ける ＝ =1 に入る）は、入る側の集合が同じになるので、別に「同じ中身」として印を付ける
#   方向だけの条件なし（買いのみ・売りのみ）は「基本」としてまとめの対象外
#   代表：①単点・周辺の両方で残った ②5つの形の最悪が高い ③年件数が多い
import sys, numpy as np, pandas as pd
from collections import Counter
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.spatial.distance import squareform
from s10scr import load, make_bins, LATE
W = '/home/claude/work'
DS = {('現行', '順張り'): W + '/T', ('先物基準', '順張り'): W + '/F6W/T6', ('現行', '逆張り'): W + '/R', ('先物基準', '逆張り'): W + '/F6W/R6'}
SEGS = {'D>N': ['D>N'], 'N>D': ['N>D'], '両方の窓': ['D>N', 'N>D']}
XG = np.array([.2, .3, .4, .5, .6, .7, .8, .9, 1.0, 1.2, 1.5])
CA = pd.read_pickle(W + '/S20cands.pkl'); K = CA[CA['売買'] != '両方'].copy()
ROW = {}; ENT = {}; TR = {}
for key_d, d in DS.items():
    Y, en, MN, F = load(d); evt = pd.read_pickle(d + '/evt.pkl'); ok = ~en.long.values; yr = en.yr.values; sess = evt.i.values[en.ev.values]
    ba = make_bins(F.drop(columns=list(LATE)), ok & (yr <= 2021)); bl = make_bins(F[list(LATE)], ok & (yr == 2023)); ba[('条件なし', '')] = np.ones(len(en), bool)
    side = key_d[1]; buy = (en.d.values < 0) if side == '順張り' else (en.d.values > 0)
    keyx = sess * 100 + np.round(en.x.values * 10).astype(int); grid = np.isin(np.round(en.x.values, 3), XG)
    for z in K[(K['定義'] == key_d[0]) & (K['向き'] == side)].itertuples():
        b_ = (bl if z.後半のみ else ba)[(z.指標, z.区分)]; dm = buy if z.売買 == '買いのみ' else ~buy
        per = ok & np.isin(en.kind.values, SEGS[z.窓]) & (yr >= 2022) & dm
        if z.後半のみ: per &= (yr >= 2023) & ~np.isnan(F[z.指標].values)
        ent = ~b_ if z.使い方 == '避ける' else b_
        ENT[z.id] = set(keyx[per & grid & ent]); ROW[z.id] = set(keyx[per & grid & b_]) if z.使い方 == '避ける' else ENT[z.id]
        TR[z.id] = set(sess[per & np.isclose(en.x.values, z.x) & ent])
    print(key_d, flush=True)
def sim(sets, ids):
    n = len(ids); S = np.eye(n); L = [sets[i] for i in ids]
    for a in range(n):
        for b in range(a + 1, n):
            d = np.sqrt(len(L[a]) * len(L[b])); S[a, b] = S[b, a] = len(L[a] & L[b]) / d if d else 0
    return S
def cluster(S, thr):
    if len(S) == 1: return np.array([1])
    return fcluster(linkage(squareform(1 - S, checks=False), 'average'), 1 - thr, 'distance')
K['グループ'] = ''
for (side, dname), sub0 in K.groupby(['向き', '売買']):
    for kind in ('入る', '避ける'):
        sub = sub0[(sub0['指標'] != '条件なし') & (sub0['使い方'] == kind)]
        if not len(sub): continue
        ids = list(sub['id']); S = sim(ROW, ids); g5 = cluster(S, .5); g3 = cluster(S, .3)
        K.loc[sub.index, 'グループ'] = ['%s・%s・%s・%03d' % (side, dname, kind, c) for c in g5]
        K.loc[sub.index, '大グループ(0.3)'] = ['%s・%s・%s・大%03d' % (side, dname, kind, c) for c in g3]
        print(side, dname, kind, len(ids), 'グループ', len(set(g5)), '大グループ', len(set(g3)), flush=True)
K.loc[K['指標'] == '条件なし', 'グループ'] = K.loc[K['指標'] == '条件なし', '向き'] + '・' + K.loc[K['指標'] == '条件なし', '売買'] + '・基本'
# 同じ中身（入る側の集合と窓・定義が同じ）
sig = {}
for z in K.itertuples():
    s = (z.定義, z.向き, z.売買, z.窓, hash(frozenset(ENT[z.id])))
    sig.setdefault(s, []).append(z.id)
K['同じ中身の候補数'] = [len(sig[(z.定義, z.向き, z.売買, z.窓, hash(frozenset(ENT[z.id])))]) for z in K.itertuples()]
K = K.sort_values(['グループ', '選び方数', '最小', '年件数'], ascending=[True, False, False, False]); K['グループ内順位'] = K.groupby('グループ').cumcount() + 1
K['代表'] = np.where(K['指標'] == '条件なし', '基本', np.where(K['グループ内順位'] == 1, '代表', ''))
C0 = CA[CA['売買'] == '両方']
CB_ = pd.concat([C0, K], ignore_index=True); CB_.to_pickle(W + '/S21cands.pkl'); pd.to_pickle(dict(ROW=ROW, ENT=ENT, TR=TR), W + '/S21sets.pkl')
print(CB_.groupby(['向き', '売買'])['グループ'].nunique().to_dict()); print('代表', CB_.groupby(['向き', '売買'])['代表'].apply(lambda v: (v == '代表').sum()).to_dict())
