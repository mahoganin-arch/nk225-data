import numpy as np, pandas as pd
from lib import W
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 40); pd.set_option('display.max_rows', 500)
R = pd.read_pickle(W + '/S2rec.pkl').sort_values(['m'])
def maxdd(v):
    c = np.cumsum(v); return float((np.maximum.accumulate(np.r_[0, c])[1:] - c).max()) if len(v) else np.nan
def st(g):
    v = g['損益'].values; yrs = g['年'].nunique()
    d = {'件数': len(v), '年あたり件数': len(v) / max(1, g['年'].max() - g['年'].min() + 1), '平均': v.mean(), '勝率%': (v > 0).mean() * 100, '最悪': v.min(), '最大DD': maxdd(v), '合計': v.sum(),
         '損益分岐pt': g['控除前'].sum() / g['円per pt'].sum()}
    for y, gg in g.groupby('年'): d[str(y)] = gg['損益'].mean()
    return pd.Series(d)
K = ['評価', '窓', '戦略', '選び方']
S = pd.DataFrame([dict(zip(K, k)) | st(g).to_dict() for k, g in R.groupby(K, sort=False)])
S.to_pickle(W + '/S2sum.pkl')
if __name__ == '__main__':
    c = ['評価', '窓', '戦略', '選び方', '件数', '年あたり件数', '平均', '勝率%', '最悪', '最大DD', '合計', '損益分岐pt'] + [str(y) for y in range(2022, 2027)]
    for scn in S['評価'].unique():
        print('\n#####', scn); print(S[S['評価'] == scn][c].drop(columns='評価').round(1).to_string(index=False))
