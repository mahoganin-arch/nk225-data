# 案3（まろ、2026-10-13）：前の付け方（選ぶ期間の1回平均）と新しい付け方（前向きRF）の上位を合わせて採用候補にする
#   各年 t、窓の種類・向きごとに：
#     前の付け方：代表(0.5)から、t年のルールの選ぶ期間（〜t−1年）の1回平均（15件以上）の上位N本
#     新しい付け方：全候補から、前向き記録（2022〜t−1年、5×年数件以上・合計プラス、選ぶ期間2017〜21年もプラス）のRF上位N本（重なりの同じグループは最上位だけ）
#   合わせた候補の優先順位：①両方に入る候補 ②残りは2つの順位のうち良い方（同じなら前の付け方を優先）
#   確かめる期間：2024〜26年（新しい付け方は前向き記録が2年以上必要なため）。先着1本・同じ向き2本・両建て＋2本目、N=3・5・10
#   最後に、今（2026/10/8まで）のデータで付けた採用候補リストを作る
import sys, numpy as np, pandas as pd
sys.argv = [sys.argv[0]]
exec(open('/home/claude/work/08/an/s13sim.py').read().split("if __name__ == '__main__':")[0])
from s14report_funcs import stats, rule_text, cond_text
SCN, METH = 'WF全期間', '周辺'
PK = pd.read_pickle(W + '/S13picks.pkl'); TT = T0[(T0['評価'] == SCN) & (T0['選び方'] == METH)]
WF = TT[TT['年'] == TT['t']]; SELP = TT[(TT['t'] == 2022) & (TT['年'] <= 2021)]
selsum = SELP.groupby(['id', '窓の種類'])['損益'].sum()
GRP = C['グループ']; SIDE = C['向き']
OLDMODE = '窓の種類ごと'
def rank_old(t):
    """{(窓の種類, 向き): [id...]}（順位順、全件）。OLDMODE＝'窓の種類ごと'：その窓の種類のトレードだけで平均／'両方の窓まとめて'：s13sim と同じく候補の全トレードで平均"""
    Tt = TT[(TT['t'] == t) & TT['id'].isin(UNIV['代表(0.5)'])]; out = {}
    insall = Tt[Tt['年'] < t].groupby('id')['損益'].agg(['mean', 'size']); insall = insall[insall['size'] >= 15]['mean']
    for kind in ('D>N', 'N>D'):
        tk = Tt[(Tt['窓の種類'] == kind) & (Tt['年'] < t)]; ins = tk.groupby('id')['損益'].agg(['mean', 'size']); ins = ins[ins['size'] >= 15]['mean'].sort_values(ascending=False)
        if OLDMODE != '窓の種類ごと': ins = insall[insall.index.isin(tk['id'].unique())].sort_values(ascending=False)
        for side in ('順張り', '逆張り'): out[(kind, side)] = [i for i in ins.index if SIDE[i] == side]
    return out
def rank_rf(t, end_incl=False):
    past = WF[(WF['年'] <= t) if end_incl else (WF['年'] < t)]; ny = (t - 2022 + 1) if end_incl else (t - 2022); minn = 20 if end_incl else 5 * ny
    sc = []
    for (i, kind), v in past.groupby(['id', '窓の種類']):
        v = v.sort_values('手じまう時刻')['損益'].values
        if len(v) < minn or v.sum() <= 0 or selsum.get((i, kind), -1) <= 0: continue
        c = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, c])[1:] - c).max(); sc.append((i, kind, v.sum() / max(dd, 1.0)))
    S = pd.DataFrame(sc, columns=['id', 'kind', 'rf']).sort_values('rf', ascending=False); S['g'] = S['id'].map(GRP); S = S.drop_duplicates(['kind', 'g'])
    out = {}
    for kind in ('D>N', 'N>D'):
        for side in ('順張り', '逆張り'): out[(kind, side)] = [i for i in S[S['kind'] == kind]['id'] if SIDE[i] == side]
    return out
def union_list(old, rf, N):
    """両方の上位N本を合わせ、優先順位を付ける → {(kind, side): [(id, 両方, 前の順位, 新しい順位)]}"""
    out = {}
    for key in old:
        a = old[key][:N]; b = rf.get(key, [])[:N]; ids = list(dict.fromkeys(a + b))
        rows = [(i, i in a and i in b, a.index(i) + 1 if i in a else 99, b.index(i) + 1 if i in b else 99) for i in ids]
        rows.sort(key=lambda r: (not r[1], min(r[2], r[3]), r[2])); out[key] = rows
    return out
def simulate_sel(sel, N, pol):
    out = []
    for t in (2024, 2025, 2026):
        if sel == '前の付け方': L = {k: [(i, False, r + 1, 99) for r, i in enumerate(v[:N])] for k, v in rank_old(t).items()}
        elif sel == '新しい付け方': L = {k: [(i, False, 99, r + 1) for r, i in enumerate(v[:N])] for k, v in rank_rf(t).items()}
        else: L = union_list(rank_old(t), rank_rf(t), N)
        pr = {}
        for (kind, side), rows in L.items():
            for p, r in enumerate(rows): pr[(r[0], kind)] = p
        test = TT[(TT['t'] == t) & (TT['年'] == t)].copy(); test['順位'] = [pr.get((a, b), np.nan) for a, b in zip(test['id'], test['窓の種類'])]
        test = test[test['順位'].notna()].sort_values(['セッション', '入る時刻', '順位'])
        for s_, tr in test.groupby('セッション', sort=False):
            for h in run_window(tr.to_dict('records'), pol, False, fill.get(s_, np.inf)): h['確かめる年'] = t; out.append(h)
    return pd.DataFrame(out)
PR = []
for OLDMODE, sel in [('窓の種類ごと', '前の付け方'), ('窓の種類ごと', '新しい付け方'), ('窓の種類ごと', '合わせる（案3）'), ('両方の窓まとめて', '前の付け方'), ('両方の窓まとめて', '合わせる（案3）')]:
    for N in (3, 5, 10):
        for pol, pn in (('A1', '先着1本'), ('C1', '同じ向き2本'), ('D1', '両建て＋2本目')):
            H = simulate_sel(sel, N, pol).sort_values('手じまう時刻'); r = stats(H['損益'].values, 3)
            r.update(付け方=sel, 前の付け方の平均の取り方=OLDMODE if sel != '新しい付け方' else '', 上位N本=N, 方針=pn, 最悪の1窓=H.groupby('セッション')['損益'].sum().min(), 候補の延べ数=H['id'].nunique())
            for y, g in H.groupby('確かめる年'): s_ = stats(g['損益'].values); r['%d年' % y] = s_['合計']; r['%d年PF' % y] = s_['PF']
            PR.append(r)
PR = pd.DataFrame(PR); PR.to_pickle(W + '/S17port.pkl')
OLDMODE = '窓の種類ごと'
# ---- 今の採用候補リスト（前の付け方＝2026年のルールの2017〜25年の平均、新しい付け方＝2022〜2026/10/8 の前向き記録）
old = rank_old(2026); rf = rank_rf(2026, end_incl=True)
rows = []
for N in (5, 10):
    U = union_list(old, rf, N)
    for (kind, side), lst in U.items():
        for p, (i, both, ro, rn) in enumerate(lst, 1):
            z = C.loc[i]; v = WF[(WF['id'] == i) & (WF['窓の種類'] == kind)].sort_values('手じまう時刻'); s = stats(v['損益'].values, None)
            pk = PK[(PK['id'] == i) & (PK['評価'] == SCN) & (PK['選び方'] == METH) & (PK['t'] == 2026)]
            yr = v.groupby('年')['損益'].sum()
            r = dict(上位N本=N, 窓の種類=kind, 向き=side, 優先順位=p, 候補=z['名前'].replace('=-0', '=0'), 使い方=z['使い方'], 条件=cond_text(z), 定義=z['定義'], 候補の窓=z['窓'], テーマ=z['テーマ'],
                     両方に入る=both, 前の付け方の順位=ro if ro < 99 else np.nan, 新しい付け方の順位=rn if rn < 99 else np.nan,
                     今のルール=rule_text(side, pk['乖離幅'].iloc[0], pk['決済'].iloc[0]) if len(pk) else '', id=i)
            r.update({'前向き:' + k: x for k, x in s.items()}); r['プラスの年'] = int((yr > 0).sum()); r['年の数'] = len(yr)
            for y in range(2022, 2027): r['%d年' % y] = yr.get(y, np.nan)
            rows.append(r)
U = pd.DataFrame(rows); U.to_pickle(W + '/S17list.pkl')
pd.set_option('display.width', 280); pd.set_option('display.max_colwidth', 36)
print(PR[['付け方', '前の付け方の平均の取り方', '上位N本', '方針', '件数', '勝率', 'PF', '平均', '合計', '最大DD', '合計割る最大DD', '最悪の1窓', '2024年', '2025年', '2026年']].round(1).to_string(index=False))
print(U[U['上位N本'] == 5][['窓の種類', '向き', '優先順位', '候補', '使い方', '定義', '両方に入る', '前の付け方の順位', '新しい付け方の順位', '前向き:件数', '前向き:勝率', '前向き:PF', '前向き:平均', '前向き:最大DD', '前向き:合計割る最大DD']].round(2).to_string(index=False))
