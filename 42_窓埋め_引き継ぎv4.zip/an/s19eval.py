# 買い・売り別（ゆるい基準）の評価。s10eval.evaluate と同じ計算を、乖離幅ごとの損益行列を先に読み込んでおく形で速くしたもの
#   使い方: python s19eval.py <定義> <向き>
import sys, numpy as np, pandas as pd
from s9cal import schemes, nbr_mean, maxdd, PERM, SEGS, WORST, MINSEL, SP, CB, P
from s10scr import load, make_bins, LATE
W = '/home/claude/work'
NY = {'S1 前半→後半': 4.77, 'S2 22-23→24-26': 2.77, 'WF後半': 3.77, 'WF全期間': 4.77, 'WF直近3年': 4.77}
lab, side = sys.argv[1], sys.argv[2]
d = {('現行', '順張り'): W + '/T', ('先物基準', '順張り'): W + '/F6W/T6', ('現行', '逆張り'): W + '/R', ('先物基準', '逆張り'): W + '/F6W/R6'}[(lab, side)]
S = pd.read_pickle(W + '/S19scr.pkl'); S = S[(S['定義'] == lab) & (S['向き'] == side)]
Y, en, MN, F = load(d); px = en.ent.values if 'ent' in en else pd.read_pickle(d + '/evt.pkl').B.values[en.ev.values]
ok = ~en.long.values; yr = en.yr.values; buy = (en.d.values < 0) if side == '順張り' else (en.d.values > 0)
ba = make_bins(F.drop(columns=list(LATE)), ok & (yr <= 2021)); bl = make_bins(F[list(LATE)], ok & (yr == 2023)); ba[('条件なし', '')] = np.ones(len(en), bool)
XP = np.array(sorted(en.x.unique()))
CACHE = {}
def fam_all(w):
    """窓ごと・乖離幅ごとに、条件なしの全エントリー（時刻順）の損益行列を一度だけ作る"""
    if w not in CACHE:
        fam = {}
        for j, x in enumerate(XP):
            idx = np.nonzero(ok & np.isclose(en.x.values, x) & np.isin(en.kind.values, SEGS[w]))[0]; idx = idx[np.argsort(en.m.values[idx])]
            N = np.asarray(Y[idx], dtype=np.float32) / 100 * P - (SP * P / px[idx]).astype(np.float32)[:, None]
            fam[j] = dict(idx=idx, yr=yr[idx], N=N)
        CACHE.clear(); CACHE[w] = fam
    return CACHE[w]
def evaluate(mask, w, tmin=0):
    base = fam_all(w); fam = {}
    for j, b in base.items():
        k = mask[b['idx']]; fam[j] = dict(yr=b['yr'][k], N=b['N'][k])
    Js = sorted(fam); out = []
    for scn, splits in schemes():
        res = {'単点': [], '周辺': []}; pk = {'単点': [], '周辺': []}
        for selfn, tstfn, ty in splits:
            Mn = np.full((len(Js), 1944), np.nan, np.float32); Wst = np.full((len(Js), 1944), np.nan, np.float32); cnt = np.zeros(len(Js), int)
            for q, j in enumerate(Js):
                s = selfn(fam[j]['yr']); cnt[q] = s.sum()
                if cnt[q] >= MINSEL: Ns = fam[j]['N'][s]; Mn[q] = Ns.mean(0); Wst[q] = Ns.min(0)
            if not (cnt >= MINSEL).any(): continue
            SM = nbr_mean(Mn[:, PERM].reshape(len(Js), 12, 18, 9)).reshape(len(Js), 1944); SMc = np.full_like(SM, np.nan); SMc[:, PERM] = SM
            okw = Wst >= WORST
            for meth, score in (('単点', Mn), ('周辺', SMc)):
                sc = np.where(np.isnan(Mn), -np.inf, score); sc2 = np.where(okw, sc, -np.inf); use = sc2 if np.isfinite(sc2).any() else sc
                q, e = np.unravel_index(int(np.argmax(use)), use.shape); j = Js[q]; t = tstfn(fam[j]['yr']) & (fam[j]['yr'] >= tmin)
                res[meth] += list(fam[j]['N'][t, e]); pk[meth].append('%g%%%s' % (XP[j], CB[e]))
        nyr = NY[scn] if tmin == 0 else 2.77
        for meth in ('単点', '周辺'):
            v = np.array(res[meth]); out.append(dict(窓=w, 評価=scn, 選び方=meth, 件数=len(v), 年件数=len(v) / nyr, 平均=v.mean() if len(v) else np.nan,
                                                最悪=v.min() if len(v) else np.nan, 最大DD=maxdd(v) if len(v) else np.nan, 選ばれた点=' '.join(pk[meth])))
    return out
rows = []
S = S.sort_values('窓')                                                    # 窓ごとにまとめて処理（行列の読み込みを1回にする）
for n_, z in enumerate(S.itertuples()):
    late = bool(z.後半のみ); m = (bl if late else ba)[(z.指標, z.区分)]
    if z.使い方 == '避ける': m = ~m
    m = m & (buy if z.売買 == '買いのみ' else ~buy)
    if late: m = m & ~np.isnan(F[z.指標].values)
    for r in evaluate(m, z.窓, 2024 if late else 0): r.update(定義=lab, 向き=side, 売買=z.売買, 指標=z.指標, 区分=z.区分, 使い方=z.使い方, 後半のみ=late); rows.append(r)
    if n_ % 200 == 0: print(lab, side, n_, len(S), flush=True); pd.DataFrame(rows).to_pickle(W + '/S19eval_%s_%s.pkl' % (lab, side))
pd.DataFrame(rows).to_pickle(W + '/S19eval_%s_%s.pkl' % (lab, side))
