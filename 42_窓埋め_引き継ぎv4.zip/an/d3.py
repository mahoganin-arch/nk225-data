# 前半の強さ（tの中央値）別に、後半で同じ向きだった割合
import sys, numpy as np, pandas as pd
from lib import W
for side in sys.argv[1:]:
    S = pd.read_pickle(W + ('/R' if side == '逆張り' else '/T') + '/d2.pkl')
    for k in ('全', '固'):
        t = S['前半t中央_' + k]; same = np.sign(S['前半_' + k]) == np.sign(S['後半_' + k])
        b = pd.cut(t, [-99, -3, -2, -1, 0, 1, 2, 3, 99])
        G = S.assign(同じ向き=same, 後半=S['後半_' + k]).groupby(b, observed=True).agg(件数=('同じ向き', 'size'), 後半も同じ向き率=('同じ向き', lambda s: round(s.mean() * 100, 1)), 後半上乗せ平均=('後半', lambda s: round(s.mean(), 1)))
        print('==', side, '測り方', k, '（前半tの中央値で区切る）'); print(G.to_string())
