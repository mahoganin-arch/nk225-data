# 前向きでマイナスの候補の判断材料 Excel
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
W = '/home/claude/work'; OUT = W + '/08/results/S12_マイナス候補の判断材料.xlsx'
J = pd.read_pickle(W + '/S15cand.pkl'); DR = pd.read_pickle(W + '/S15drop.pkl'); P = pd.read_pickle(W + '/S15persist.pkl')
J['候補'] = J['候補'].str.replace('=-0', '=0', regex=False)
desc = [
 ['この表について', '今の候補40行（S11）のうち、前向きでマイナスの候補をどう扱うか判断するための情報'],
 ['① 候補ごと', '前向き（2022〜26年）の1回平均の不確かさ：ブートストラップ（トレードを入れ替えて4,000回）の90%区間と、本当の平均がプラスである確率の目安。選ぶ期間（2017〜25年）の平均との差、プラスの年の数、年ごとのルール（乖離幅・決済）が変わった回数、組み合わせ（同じ向き2本・上位10本）で実際に使われた件数と損益'],
 ['② 外すルールの検証', '「その年より前の前向き記録（2022年〜前年）が、N件以上で平均マイナスなら、その年は売買しない」を各年で決め、2023〜26年の組み合わせの成績で、外さない場合と比べる（N=5・10・20、候補の集まり4通り、上位5・10本、先着1本・同じ向き2本）'],
 ['③ 持続性', '全候補・全年で、ある年（または前年まで）の前向き成績がマイナスだった候補が、翌年（その年）にどうなったか'],
 ['使い方', '「避ける」の候補は、条件なしからその区分を除いて入るもの（例：週足ねじれ前=1 は、ねじれ前のときは入らない）'],
 ['シート', '候補ごと／外すルールの検証／持続性'],
]
with pd.ExcelWriter(OUT, engine='openpyxl') as w:
    pd.DataFrame(desc, columns=['項目', '内容']).to_excel(w, sheet_name='説明', index=False)
    J.round(1).to_excel(w, sheet_name='候補ごと', index=False)
    DR.round(1).to_excel(w, sheet_name='外すルールの検証', index=False)
    P['P1'].round(1).to_excel(w, sheet_name='持続性', index=False, startrow=1); P['P2'].round(1).to_excel(w, sheet_name='持続性', index=False, startrow=6)
wb = load_workbook(OUT); red = Font(name='Arial', size=10, color='C00000')
ws = wb['持続性']; ws['A1'] = 'ある年の前向き成績と翌年（5件以上の候補×年）。相関 %.3f' % P['c']; ws['A6'] = '前年までの前向き記録とその年（10件以上）。相関 %.3f' % P['c2']
for ws in wb:
    for row in ws.iter_rows():
        for c in row:
            c.font = Font(name='Arial', size=10, bold=c.row == 1)
            if c.row > 1 and isinstance(c.value, (int, float)) and c.value < 0: c.font = red
    for c in ws[1]: c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = 12
ws = wb['説明']; ws.column_dimensions['A'].width = 16; ws.column_dimensions['B'].width = 150
for c in ws['B']: c.alignment = Alignment(wrap_text=True, vertical='top')
wb['候補ごと'].column_dimensions['F'].width = 30; wb['外すルールの検証'].column_dimensions['D'].width = 34
wb.save(OUT); print(OUT)
