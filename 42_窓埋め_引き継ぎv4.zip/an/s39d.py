import sys; sys.path.insert(0, '/home/claude/work/01/code'); import ld, pandas as pd, numpy as np
c = ld.bars('data/c1.csv').set_index('t')
def win(t_base_end, t_open, t_end, B, xs):
    a = c.loc[pd.Timestamp(t_base_end, tz='Asia/Tokyo') + pd.Timedelta('1min'):pd.Timestamp(t_end, tz='Asia/Tokyo')]
    to = pd.Timestamp(t_open, tz='Asia/Tokyo'); g = a.loc[to:].open.iloc[0] - B
    post = a.loc[to:]; ci = post.index[(post.low <= B) if g > 0 else (post.high >= B)]
    print(t_open, 'B', B, 'CFD gap', g, 'closed at', ci[0].strftime('%m-%d %H:%M') if len(ci) else None)
    for x in xs:
        U = B * (1 + x / 100); D = B * (1 - x / 100)
        u = a.index[a.high >= U]; d = a.index[a.low <= D]
        print('  x', x, 'up first', u[0].strftime('%m-%d %H:%M') if len(u) else None, 'down first', d[0].strftime('%m-%d %H:%M') if len(d) else None)
win('2026-09-02 05:55', '2026-09-02 08:45', '2026-09-02 15:45', 64865, [0.25])
win('2026-09-01 05:55', '2026-09-01 08:45', '2026-09-01 15:45', 65809, [0.25])
win('2026-09-16 05:55', '2026-09-16 08:45', '2026-09-16 15:45', 63681, [0.7])
win('2026-09-03 15:45', '2026-09-03 17:00', '2026-09-04 05:55', 64214, [0.45])
