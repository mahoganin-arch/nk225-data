# 候補ごとのトレード一覧（前向き検証：WF全期間・WF後半の年ごとに選ばれた乖離幅・決済）
#   各候補 × 確かめる年 t（2022〜2026）× 選び方（単点／周辺）：その年のルールで、全年のトレード（選ぶ期間の成績＝優先順位用）と、t年のトレード
#   出力：セッション、窓の種類、入る時刻（分）、入る値段、向き（+1買い／−1売り）、手じまう時刻、手じまう値段、損益（13pt控除後、円）、年、候補id、t、選び方、評価の形
#   時刻：入る＝足の始まり＋0.5分（足の途中）、ただし始値・終値で入るものはその時刻。水準での手じまい＝その足の終わりの少し前、時間での手じまい＝その足の始値、最後の足＝その足の終わり
#   逆張りC・B（1つの分け方だけで評価）は年ごとのルールがないため対象外
import re, sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/work/01/code'); import ld
from common6 import CB, P
from s10scr import load, make_bins, LATE
from s9cal import flags
W = '/home/claude/work'; SP = 13.0
DS = {('現行', '順張り'): W + '/T', ('先物基準', '順張り'): W + '/F6W/T6', ('現行', '逆張り'): W + '/R', ('先物基準', '逆張り'): W + '/F6W/R6'}
SEGS = {'D>N': ['D>N'], 'N>D': ['N>D'], '両方の窓': ['D>N', 'N>D']}
CBI = {(round(a, 3), round(b, 3), int(c)): i for i, (a, b, c) in enumerate(CB)}
c5 = ld.bars(W + '/data/c5.csv', until='2026-10-09'); c1 = ld.bars(W + '/data/c1.csv', until='2026-10-09')
cx = pd.concat([c5[c5.m + 5 <= c1.m.iloc[0]], c1], ignore_index=True); cm = cx.m.values.astype(float); co = cx.open.values; cc = cx.close.values
blen = np.r_[np.diff(cm), 1.0]; blen = np.where(blen > 5, np.where(cm >= c1.m.iloc[0], 1.0, 5.0), blen)
C = pd.read_pickle(W + '/S12cands.pkl'); C = C[~C['出所'].str.startswith('S6逆張り')]
O10 = pd.concat([pd.read_pickle(W + '/S10eval_%s_%s.pkl' % k) for k in DS]); S9 = pd.read_pickle(W + '/S9cal.pkl')
P8 = pd.read_pickle(W + '/S8pick.pkl'); P8 = P8[P8['窓の下限'] == 0].copy(); P8['定義'] = P8['定義'].replace({'現行(CFD基準)': '現行'}); P2 = pd.read_pickle(W + '/S2pick.pkl')
YEARS = {'WF全期間': [2022, 2023, 2024, 2025, 2026], 'WF後半': [2023, 2024, 2025, 2026]}
def parse(s):
    return [(float(x), (float(a), float(b), int(c))) for x, a, b, c in re.findall(r'([\d.]+)%\(([\d.]+), ([\d.]+), (\d+)\)', s)]
def picks(z, scn, meth):
    """{確かめる年: (乖離幅, 決済)}"""
    yrs = YEARS[scn]
    if z.出所 == '条件なし':
        p = P8[(P8['定義'] == z.定義) & (P8['向き'] == z.向き) & (P8['窓'] == z.窓) & (P8['評価'] == scn) & (P8['選び方'] == meth)]
        return {int(r.確かめる年): (float(r.乖離幅), tuple(r.決済)) for r in p.itertuples()}
    if z.出所 == 'S2 ATR':
        p = P2[(P2['戦略'] == z.指標) & (P2['窓'] == z.窓) & (P2['評価'] == scn) & (P2['選び方'] == meth)]
        return {int(r.確かめる年): (float(r.乖離幅), tuple(r.決済)) for r in p.itertuples()}
    if z.出所 == 'S6印':
        o = S9[(S9['定義'] == z.定義) & (S9['向き'] == z.向き) & (S9['窓'] == z.窓) & (S9['印'] == z.指標) & (S9['使い方'] == z.使い方) & (S9['評価'] == scn) & (S9['選び方'] == meth)]
    else:
        o = O10[(O10['定義'] == z.定義) & (O10['向き'] == z.向き) & (O10['窓'] == z.窓) & (O10['指標'] == z.指標) & (O10['区分'] == z.区分) & (O10['使い方'] == z.使い方) & (O10['評価'] == scn) & (O10['選び方'] == meth)]
    if len(o) != 1: return {}
    pk = parse(o['選ばれた点'].iloc[0]); yy = [y for y in yrs if not (z.後半のみ and y < 2024)]
    if len(pk) != len(yy): return {}
    return dict(zip(yy, pk))
DATA = {}
for key, d in DS.items():
    Y, en, MN, F = load(d); evt = pd.read_pickle(d + '/evt.pkl'); ok = ~en.long.values; yr = en.yr.values
    px = en.ent.values if 'ent' in en else evt.B.values[en.ev.values]
    DATA[key] = dict(Y=Y, EX=np.load(d + '/EX.npy', mmap_mode='r'), en=en, F=F, ok=ok, yr=yr, px=px, gk=np.load(d + '/gk.npy'), ep=np.load(d + '/entp.npy'), sess=evt.i.values[en.ev.values],
                     ba=make_bins(F.drop(columns=list(LATE)), ok & (yr <= 2021)), bl=make_bins(F[list(LATE)], ok & (yr == 2023)), FL=flags(evt).iloc[en.ev.values].reset_index(drop=True),
                     atopen=(en.atopen.values if 'atopen' in en else np.zeros(len(en), bool)), reo=en.reo.values)
DATA[('現行', '順張り')]['RK'] = pd.read_pickle(W + '/T/atrrank.pkl')
def cond_mask(z, D):
    en = D['en']; F = D['F']
    if z.出所 == '条件なし': return np.ones(len(en), bool)
    if z.出所 == 'S6印': m = D['FL'][z.指標].values.astype(bool)
    elif z.出所 == 'S2 ATR':
        if '前半固定' in z.指標:
            v = F['atr_5m' if 'ATR5分' in z.指標 else 'atr_15m'].values.astype(float); t = D['ok'] & (D['yr'] <= 2021) & ~np.isnan(v); m = v >= np.quantile(v[t], .9)
        else: m = D['RK']['rk_atr_%s_%s' % ('5m' if 'ATR5分' in z.指標 else '15m', '90d' if '90日' in z.指標 else '365d')].values >= .9
    else: m = (D['bl'] if z.後半のみ else D['ba'])[(z.指標, z.区分)]
    if z.使い方 == '避ける': m = ~m
    if z.後半のみ: m = m & ~np.isnan(F[z.指標].values)
    return m
REC = []; PKS = []
for z in C.itertuples():
    D = DATA[(z.定義, z.向き)]; en = D['en']; m = cond_mask(z, D); base = D['ok'] & m & np.isin(en.kind.values, SEGS[z.窓])
    for scn in YEARS:
        for meth in ('単点', '周辺'):
            pk = picks(z, scn, meth)
            for t, (x, ex) in pk.items():
                PKS.append(dict(id=z.id, 評価=scn, 選び方=meth, t=t, 乖離幅=x, 決済=ex))
                e = CBI[(round(ex[0], 3), round(ex[1], 3), int(ex[2]))]
                rows = np.nonzero(base & np.isclose(en.x.values, x) & (D['yr'] <= t))[0]
                if len(rows) == 0: continue
                pnl = np.asarray(D['Y'][rows, e], float) / 100 * P - SP * P / D['px'][rows]
                code = np.asarray(D['EX'][rows, e]).astype(int); idx = code // 4; typ = code % 4; g = D['gk'][rows] + idx; g0 = D['gk'][rows]
                d_ = en.d.values[rows]; pos = d_ if z.向き == '逆張り' else -d_
                # 入る時刻：先物基準は足の始値、現行は水準を越えた足の途中（休止明けの足は終値で入るので足の終わり）
                if z.定義 == '先物基準': t_in = cm[g0]
                else: t_in = np.where(D['reo'][rows], cm[g0] + blen[g0], cm[g0] + 0.5 * blen[g0])
                t_out = np.where(typ == 2, cm[g], np.where(typ == 3, cm[g] + blen[g], cm[g] + 0.9 * blen[g]))
                REC.append(pd.DataFrame(dict(id=z.id, 評価=scn, 選び方=meth, t=t, row=rows, セッション=D['sess'][rows], 窓の種類=en.kind.values[rows], 年=D['yr'][rows],
                                             入る時刻=t_in, 入る値段=D['ep'][rows], 向き=pos, 手じまう時刻=t_out, 損益=pnl, 円per値=P / D['px'][rows])))
T = pd.concat(REC, ignore_index=True)
T['手じまう値段'] = T['入る値段'] + T['向き'] * (T['損益'] + SP * T['円per値']) / T['円per値']
T.to_pickle(W + '/S13trades.pkl'); pd.DataFrame(PKS).to_pickle(W + '/S13picks.pkl')
print(T.shape, T.groupby(['評価', '選び方'])['id'].nunique().to_dict())
# 確認：t年のトレードの平均が、評価（S10等）の確かめる期間の値と一致するか（WF全期間・周辺、S7指標の候補から抜き取り）
chk = T[(T['評価'] == 'WF全期間') & (T['選び方'] == '周辺') & (T['年'] == T['t'])].groupby('id')['損益'].agg(['mean', 'size'])
O = O10[(O10['評価'] == 'WF全期間') & (O10['選び方'] == '周辺')]
bad = 0; n = 0
for z in C[C['出所'] == 'S7指標'].sample(40, random_state=0).itertuples():
    o = O[(O['定義'] == z.定義) & (O['向き'] == z.向き) & (O['窓'] == z.窓) & (O['指標'] == z.指標) & (O['区分'] == z.区分) & (O['使い方'] == z.使い方)]
    if len(o) and z.id in chk.index: n += 1; bad += abs(o['平均'].iloc[0] - chk.loc[z.id, 'mean']) > 0.05 or o['件数'].iloc[0] != chk.loc[z.id, 'size']
print('評価との一致の確認', n, '件中 不一致', bad)
