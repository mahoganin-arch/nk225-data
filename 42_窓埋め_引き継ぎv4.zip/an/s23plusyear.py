# 「前向きでプラスの年が3年以上」を条件にした場合の影響
#   ① 今の採用候補（S22、上位5本×12区分）への当てはめ：残る本数・外れる候補
#   ② 前向き検証（2024〜26年）：各年 t の候補を「2022〜t−1年の前向きで、プラスの年が過半数（2年なら2年、3年なら2年以上、4年なら3年以上）」に限ってから案3で選ぶ
#      （2026年に使うときの「5年中3年以上」に近い形を、その年より前のデータだけで再現したもの）
import sys, numpy as np, pandas as pd
sys.argv = [sys.argv[0]]
exec(open('/home/claude/work/08/an/s22union.py').read().split('PR = []')[0])
U = pd.read_pickle(W + '/S22list.pkl')
U['由来'] = np.where(U['両方に入る'], '両方', np.where(U['前の付け方の順位'].notna(), '前の付け方のみ', '新しい付け方のみ'))
U['プラス3年以上'] = U['プラスの年'] >= 3
print('今の採用候補', len(U), ' プラスの年3年以上', U['プラス3年以上'].sum())
print(pd.crosstab([U['売買']], U['プラス3年以上']))
print('外れる候補の前向き'); print(U[~U['プラス3年以上']][['窓の種類', '向き', '売買', '候補', '使い方', '由来', '前向き:件数', '前向き:PF', '前向き:平均', 'プラスの年', '年の数']].round(2).to_string(index=False))
print('前向きマイナス12本のうち外れる', ((U['前向き:合計'] <= 0) & ~U['プラス3年以上']).sum())
# ② 前向き検証
def plus_ok(t):
    past = WF[(WF['年'] < t) & (WF['年'] >= 2022)]; ny = t - 2022; need = ny // 2 + 1 if ny > 1 else 1
    y = past.groupby(['id', '窓の種類', '年'])['損益'].sum().reset_index(); y['plus'] = y['損益'] > 0
    c = y.groupby(['id', '窓の種類'])['plus'].sum(); return set(c[c >= need].index)
def simulate_p(N, pol, dirs, use_plus):
    out = []
    for t in (2024, 2025, 2026):
        old = rank_old(t); rf = rank_rf(t)
        if use_plus:
            okset = plus_ok(t)
            old = {k: [i for i in v if (i, k[0]) in okset] for k, v in old.items()}; rf = {k: [i for i in v if (i, k[0]) in okset] for k, v in rf.items()}
        L = union_list(old, rf, N, dirs)
        allr = [(k, r) for k, rows in L.items() for r in rows]; allr.sort(key=lambda kr: (not kr[1][1], min(kr[1][2], kr[1][3]), kr[1][2]))
        pr = {(r[0], k[0]): p for p, (k, r) in enumerate(allr)}
        test = T0[(T0['t'] == t) & (T0['年'] == t)].copy(); test['順位'] = [pr.get((a, b), np.nan) for a, b in zip(test['id'], test['窓の種類'])]
        test = test[test['順位'].notna()].sort_values(['セッション', '入る時刻', '順位'])
        for s_, tr in test.groupby('セッション', sort=False):
            for h in run_window(tr.to_dict('records'), pol, False, fill.get(s_, np.inf)): h['確かめる年'] = t; out.append(h)
    return pd.DataFrame(out)
PR = []
for dn, dirs in (('両方のみ', ('両方',)), ('両方＋売りのみ', ('両方', '売りのみ')), ('両方＋方向別', ('両方', '買いのみ', '売りのみ')), ('買いのみ', ('買いのみ',)), ('売りのみ', ('売りのみ',))):
    for N in (3, 5):
        for pol, pn in (('A1', '先着1本'), ('C1', '同じ向き2本')):
            for up in (False, True):
                H = simulate_p(N, pol, dirs, up).sort_values('手じまう時刻'); r = stats(H['損益'].values, 3)
                r.update(候補の集まり=dn, 上位N本=N, 方針=pn, プラスの年の条件=up, 最悪の1窓=H.groupby('セッション')['損益'].sum().min())
                for y, g in H.groupby('確かめる年'): r['%d年' % y] = g['損益'].sum()
                PR.append(r)
PR = pd.DataFrame(PR); PR.to_pickle(W + '/S23port.pkl'); U.to_pickle(W + '/S23list.pkl')
pd.set_option('display.width', 250)
print(PR[['候補の集まり', '上位N本', '方針', 'プラスの年の条件', '件数', 'PF', '平均', '合計', '最大DD', '合計割る最大DD', '2024年', '2025年', '2026年']].round(1).to_string(index=False))
