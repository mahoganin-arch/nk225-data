# ふるいを通った区分を、条件なし＋入る/避けるとして5つの評価の形で評価（13pt控除後、単点／周辺）
#   後半のみの指標（1時間足の出来高）は確かめる年を2024年以降に限る
#   使い方: python s10eval.py <定義> <向き>   （例：現行 順張り）
import sys, numpy as np, pandas as pd
from s9cal import schemes, nbr_mean, maxdd, PERM, SEGS, WORST, MINSEL, SP, CB, P
from s10scr import load, make_bins, LATE
W = '/home/claude/work'
NY = {'S1 前半→後半': 4.77, 'S2 22-23→24-26': 2.77, 'WF後半': 3.77, 'WF全期間': 4.77, 'WF直近3年': 4.77}
def evaluate(Y, en, mask, w, tmin=0):
    XP = np.array(sorted(en.x.unique())); fam = {}; out = []
    for j, x in enumerate(XP):
        idx = np.nonzero((~en.long.values) & mask & np.isclose(en.x.values, x) & np.isin(en.kind.values, SEGS[w]))[0]; idx = idx[np.argsort(en.m.values[idx])]
        G = np.asarray(Y[idx], dtype=np.float32) / 100 * P; ppt = (P / en.px.values[idx]).astype(np.float32)
        fam[j] = dict(yr=en.yr.values[idx], N=G - SP * ppt[:, None])
    Js = sorted(fam)
    for scn, splits in schemes():
        res = {'単点': [], '周辺': []}; pk = {'単点': [], '周辺': []}; ny = 0
        for selfn, tstfn, ty in splits:
            Mn = np.full((len(Js), 1944), np.nan, np.float32); Wst = np.full((len(Js), 1944), np.nan, np.float32); cnt = np.zeros(len(Js), int)
            for q, j in enumerate(Js):
                s = selfn(fam[j]['yr']); cnt[q] = s.sum()
                if cnt[q] >= MINSEL: Ns = fam[j]['N'][s]; Mn[q] = Ns.mean(0); Wst[q] = Ns.min(0)
            if not (cnt >= MINSEL).any(): continue
            SM = nbr_mean(Mn[:, PERM].reshape(len(Js), 12, 18, 9)).reshape(len(Js), 1944); SMc = np.full_like(SM, np.nan); SMc[:, PERM] = SM
            okw = Wst >= WORST
            for meth, score in (('単点', Mn), ('周辺', SMc)):
                sc = np.where(np.isnan(Mn), -np.inf, score); sc2 = np.where(okw, sc, -np.inf); use = sc2 if np.isfinite(sc2).any() else sc
                q, e = np.unravel_index(int(np.argmax(use)), use.shape); j = Js[q]; t = tstfn(fam[j]['yr']) & (fam[j]['yr'] >= tmin)
                res[meth] += list(fam[j]['N'][t, e]); pk[meth].append('%g%%%s' % (XP[j], CB[e]))
        nyr = NY[scn] if tmin == 0 else 2.77
        for meth in ('単点', '周辺'):
            v = np.array(res[meth]); out.append(dict(窓=w, 評価=scn, 選び方=meth, 件数=len(v), 年件数=len(v) / nyr, 平均=v.mean() if len(v) else np.nan,
                                                最悪=v.min() if len(v) else np.nan, 最大DD=maxdd(v) if len(v) else np.nan, 選ばれた点=' '.join(pk[meth])))
    return out
if __name__ == '__main__':
    lab, side = sys.argv[1], sys.argv[2]
    d = {('現行', '順張り'): W + '/T', ('先物基準', '順張り'): W + '/F6W/T6', ('現行', '逆張り'): W + '/R', ('先物基準', '逆張り'): W + '/F6W/R6'}[(lab, side)]
    S = pd.read_pickle(W + '/S10scr.pkl'); S = S[(S['定義'] == lab) & (S['向き'] == side) & S['通過']]
    ONLY = sys.argv[3].split(',') if len(sys.argv) > 3 else None          # 指定した指標だけ評価し直し、既存の結果に差し替える
    if ONLY: S = S[S['指標'].isin(ONLY)]
    Y, en, MN, F = load(d); en['px'] = en.ent.values if 'ent' in en else pd.read_pickle(d + '/evt.pkl').B.values[en.ev.values]
    ok = ~en.long.values; yr = en.yr.values
    ba = make_bins(F.drop(columns=list(LATE)), ok & (yr <= 2021)); bl = make_bins(F[list(LATE)], ok & (yr == 2023))
    rows = []
    for w in SEGS:
        for r in evaluate(Y, en, np.ones(len(en), bool), w): r.update(定義=lab, 向き=side, 指標='条件なし', 区分='', 使い方='', 後半のみ=False); rows.append(r)
        for r in evaluate(Y, en, np.ones(len(en), bool), w, 2024): r.update(定義=lab, 向き=side, 指標='条件なし(2024-)', 区分='', 使い方='', 後半のみ=True); rows.append(r)
    for n_, z in enumerate(S.itertuples()):
        late = bool(z.後半のみ); m = (bl if late else ba)[(z.指標, z.区分)]; mask = m if z.使い方 == '入る' else ~m
        if late: mask = mask & ~np.isnan(F[z.指標].values)
        for r in evaluate(Y, en, mask, z.窓, 2024 if late else 0): r.update(定義=lab, 向き=side, 指標=z.指標, 区分=z.区分, 使い方=z.使い方, 後半のみ=late); rows.append(r)
        if n_ % 50 == 0: print(lab, side, n_, len(S), flush=True)
    R = pd.DataFrame(rows); fn = W + '/S10eval_%s_%s.pkl' % (lab, side)
    if ONLY:
        old = pd.read_pickle(fn); old = old[~old['指標'].isin(ONLY)]; R = pd.concat([old, R[~R['指標'].str.startswith('条件なし')]], ignore_index=True)
    R.to_pickle(fn)
