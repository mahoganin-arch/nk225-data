# 候補を「拾う窓の重なり」でまとめる
#   候補：S10（F6＋F7の入る／避ける）、S9（SQ・祝日・月末月初）、S2（ATR上位10%系）、S4（逆張りC・B）、条件なし（基本ルール）
#   各候補の「入る窓」＝代表の乖離幅（評価で選ばれた乖離幅の最頻値）で、条件を満たしたエントリーの窓（セッション番号で現行・先物基準を共通化）
#   条件の似かた：乖離幅0.2〜1.5%の格子で、条件を満たす (セッション, 乖離幅) の集合（2022年以降、1時間足の出来高は2023年以降）を比べる。乖離幅の選び方に左右されないため
#   「避ける」候補は、入る集合がほぼ条件なしと同じになるため、外す集合どうしで比べる
#   似ている度合い：Ochiai（共通 ÷ √(Aの数×Bの数)）。入れ子（狭い区分が広い区分の中にある）も中くらいに似ていると数える。入れ子の度合い（共通 ÷ 小さい方）も記録
#   まとめ方：向き×種類（入る／避ける）ごとに、平均連結の階層クラスタリングで、似かた0.5で切る。0.4／0.6でも切り、グループの安定性を記録
#   条件なし（基本ルール）はまとめの対象外（すべての「入る」候補を含むため）
#   追加の確認：「入る」候補の条件の半分以上が、同じ定義・窓の「避ける」候補の外す区分に入る組（矛盾）を一覧にする
#   代表どうしの「入る窓」（代表の乖離幅）の重なりも出す（同時に運用する段階で使う）
#   代表：グループ内で、①単点・周辺の両方で残った ②5つの評価の形の最悪が高い ③年件数が多い の順。2番目の候補も残す（定義・窓・中身が違うもの優先）
import re, sys, numpy as np, pandas as pd
from collections import Counter
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.spatial.distance import squareform
sys.path.insert(0, '/home/claude/work/01/code'); from common6 import jname
from s10scr import load, make_bins, LATE
from s9cal import flags
W = '/home/claude/work'
DS = {('現行', '順張り'): W + '/T', ('先物基準', '順張り'): W + '/F6W/T6', ('現行', '逆張り'): W + '/R', ('先物基準', '逆張り'): W + '/F6W/R6'}
TFJ = {'5m': '5分', '15m': '15分', '60m': '60分', '4h': '4時間', 'D': '日足', 'W': '週足'}
def nm(x):
    b_, _, tf = x.rpartition('_')
    if tf in TFJ and (not b_.isascii() or b_.isupper()): return TFJ[tf] + b_
    return jname(x)
def theme(name):
    t = name
    for k, v in (('SQ値', '節目'), ('出来高', '出来高'), ('SQ', '時期・SQ'), ('祝日', '時期・SQ'), ('月末', '時期・SQ'), ('月初', '時期・SQ'), ('週目', '時期・SQ'), ('四半期', '時期・SQ'), ('年末', '時期・SQ'), ('決算', '時期・SQ'), ('配当', '時期・SQ'), ('夏時間', '時期・SQ'),
                 ('曜日', '時間'), ('時間帯', '時間'), ('経過分', '時間'), ('寄り後', '時間'),
                 ('ATR', 'ボラ'), ('BB幅', 'ボラ'), ('雲の厚さ', 'ボラ'), ('実現ボラ', 'ボラ'), ('値幅', 'ボラ'),
                 ('キリ', '節目'), ('節目', '節目'), ('ピボット', '節目'), ('前日', '節目'), ('前週', '節目'), ('前月', '節目'), ('20日高安', '節目'), ('60日高安', '節目'), ('SQ値', '節目'),
                 ('RSI', '過熱'), ('ストキャス', '過熱'), ('CCI', '過熱'), ('BBσ', '過熱'), ('60本高安', '過熱'),
                 ('窓', '窓・前セッション'), ('前セッション', '窓・前セッション'), ('前々セッション', '窓・前セッション'), ('引け', '窓・前セッション'), ('上に離れた', '窓・前セッション')):
        if k in t: return v
    return 'トレンド'
def xmode(strs):
    xs = [float(m) for s in strs if isinstance(s, str) for m in re.findall(r'([\d.]+)%\(', s)]
    return Counter(xs).most_common(1)[0][0] if xs else np.nan
cands = []
# ---- S10
G = pd.read_pickle(W + '/S10sum.pkl'); O10 = pd.concat([pd.read_pickle(W + '/S10eval_%s_%s.pkl' % k) for k in DS])
k10 = ['定義', '向き', '窓', '指標', '区分', '使い方', '後半のみ']
for key, g in G[G['残す']].groupby(k10):
    d = dict(zip(k10, key)); o = O10[(O10['定義'] == d['定義']) & (O10['向き'] == d['向き']) & (O10['窓'] == d['窓']) & (O10['指標'] == d['指標']) & (O10['区分'] == d['区分']) & (O10['使い方'] == d['使い方'])]
    cands.append(dict(出所='S7指標', **d, 名前='%s %s' % (nm(d['指標']), d['区分']), 選び方数=len(g), 中央=g['中央'].mean(), 最小=g['最小'].min(), プラス数=g['プラス数'].min(), 年件数=g['年件数'].mean(),
                      最大DD=g['最大DD'].mean(), 改善=g['改善'].mean(), x=xmode(o['選ばれた点'])))
# ---- S9（印）
S9 = pd.read_pickle(W + '/S9cal.pkl'); k9 = ['定義', '向き', '印', '使い方', '窓', '選び方']
g9 = S9.groupby(k9).agg(プラス数=('平均', lambda v: (v > 0).sum()), 中央=('平均', 'median'), 最小=('平均', 'min'), 年件数=('年件数', 'median'), 最大DD=('最大DD', 'median')).reset_index()
b9 = g9[g9['印'] == '条件なし'][['定義', '向き', '窓', '選び方', '中央']].rename(columns={'中央': 'b'}); g9 = g9.merge(b9, on=['定義', '向き', '窓', '選び方']); g9['改善'] = g9['中央'] - g9['b']
g9 = g9[(g9['プラス数'] >= 3) & (g9['中央'] >= 20) & (g9['年件数'] >= 10) & (g9['改善'] >= 20) & (g9['印'] != '条件なし')]
for key, g in g9.groupby(['定義', '向き', '窓', '印', '使い方']):
    d = dict(zip(['定義', '向き', '窓', '指標', '使い方'], key)); o = S9[(S9['定義'] == d['定義']) & (S9['向き'] == d['向き']) & (S9['窓'] == d['窓']) & (S9['印'] == d['指標']) & (S9['使い方'] == d['使い方'])]
    cands.append(dict(出所='S6印', **d, 区分='印あり', 後半のみ=False, 名前=d['指標'], 選び方数=len(g), 中央=g['中央'].mean(), 最小=g['最小'].min(), プラス数=g['プラス数'].min(), 年件数=g['年件数'].mean(),
                      最大DD=g['最大DD'].mean(), 改善=g['改善'].mean(), x=xmode(o['選ばれた点'])))
# ---- 条件なし（基本ルール）
S8 = pd.read_pickle(W + '/S8sum.pkl'); S8 = S8[S8['窓の下限'] == 0].copy(); S8['定義'] = S8['定義'].replace({'現行(CFD基準)': '現行'})
PK8 = pd.read_pickle(W + '/S8pick.pkl'); PK8 = PK8[PK8['窓の下限'] == 0].copy(); PK8['定義'] = PK8['定義'].replace({'現行(CFD基準)': '現行'})
for key, g in S8.groupby(['定義', '向き', '窓']):
    a = g.groupby('選び方')['平均']; p = PK8[(PK8['定義'] == key[0]) & (PK8['向き'] == key[1]) & (PK8['窓'] == key[2])]
    cands.append(dict(出所='条件なし', 定義=key[0], 向き=key[1], 窓=key[2], 指標='条件なし', 区分='', 使い方='基本', 後半のみ=False, 名前='条件なし', 選び方数=int(((a.apply(lambda v: (v > 0).sum()) >= 3) & (a.median() >= 20)).sum()),
                      中央=g['平均'].median(), 最小=g['平均'].min(), プラス数=int(a.apply(lambda v: (v > 0).sum()).min()), 年件数=g['年あたり件数'].median(), 最大DD=g['最大DD'].median(), 改善=0.0,
                      x=Counter(p['乖離幅']).most_common(1)[0][0]))
# ---- S2（ATR系、現行・順張り）
S2 = pd.read_pickle(W + '/S2sum.pkl'); P2 = pd.read_pickle(W + '/S2pick.pkl')
for key, g in S2[S2['戦略'].str.startswith('ATR')].groupby(['戦略', '窓']):
    ok_ = [m for m, gg in g.groupby('選び方') if (gg['平均'] > 0).sum() >= 3 and gg['平均'].median() >= 20 and gg['年あたり件数'].median() >= 10]
    if not ok_: continue
    gg = g[g['選び方'].isin(ok_)]; p = P2[(P2['戦略'] == key[0]) & (P2['窓'] == key[1])]
    cands.append(dict(出所='S2 ATR', 定義='現行', 向き='順張り', 窓=key[1], 指標=key[0], 区分='上位10%', 使い方='入る', 後半のみ=False, 名前=key[0], 選び方数=len(ok_), 中央=gg['平均'].median(), 最小=gg['平均'].min(),
                      プラス数=int(gg.groupby('選び方')['平均'].apply(lambda v: (v > 0).sum()).min()), 年件数=gg['年あたり件数'].median(), 最大DD=gg['最大DD'].median(), 改善=np.nan, x=Counter(p['乖離幅']).most_common(1)[0][0]))
# ---- S4（逆張りC・B）
yrs = {'前半→後半': 4.77, '2017-21→2022-23': 2, '2017-23→2024-26': 2.77, '2022-23→2024-26': 2.77}
for tag, f in (('C', 'S4C.pkl'), ('B', 'S4B.pkl')):
    D = pd.read_pickle(W + '/' + f); D['年件数'] = D['確かめる件数'] / D['分け方'].map(yrs)
    D = D[(D['確かめる平均'] >= 20) & (D['年件数'] >= 10)]
    for z in D.itertuples():
        lab = z.区分 if tag == 'C' else z.指標1 + ' & ' + z.指標2
        if tag == 'C' and lab == '条件なし': continue
        cands.append(dict(出所='S6逆張り' + tag, 定義='現行', 向き='逆張り', 窓=z.窓, 指標='%s|%s|%s' % (tag, z.分け方, lab), 区分='', 使い方='入る', 後半のみ=False, 名前='%s %s（%s）' % (tag, lab, z.分け方), 選び方数=1,
                          中央=z.確かめる平均, 最小=z.確かめる平均, プラス数=1, 年件数=z.年件数, 最大DD=np.nan, 改善=np.nan, x=z.乖離幅))
C = pd.DataFrame(cands); C['id'] = np.arange(len(C)); C['テーマ'] = [('基本' if n == '条件なし' else theme(n)) for n in C['名前']]
print('候補', len(C)); print(C.groupby(['向き', '出所']).size())
# ---- 各候補の「入る窓」「外す窓」（セッション番号の集合）
DATA = {}
for key, d in DS.items():
    Y, en, MN, F = load(d); evt = pd.read_pickle(d + '/evt.pkl'); ok = ~en.long.values; yr = en.yr.values
    if key[1] == '順張り' and key[0] == '現行': RK = pd.read_pickle(W + '/T/atrrank.pkl')
    DATA[key] = dict(en=en, F=F, sess=evt.i.values[en.ev.values], ok=ok, yr=yr, ba=make_bins(F.drop(columns=list(LATE)), ok & (yr <= 2021)), bl=make_bins(F[list(LATE)], ok & (yr == 2023)), FL=flags(evt).iloc[en.ev.values].reset_index(drop=True))
DATA[('現行', '順張り')]['RK'] = RK
M4 = pd.read_pickle(W + '/S4masks.pkl')
def cond_mask(z, D):
    en = D['en']; F = D['F']
    if z.出所 == '条件なし': return np.ones(len(en), bool), None
    if z.出所 == 'S6印': m = D['FL'][z.指標].values.astype(bool)
    elif z.出所 == 'S2 ATR':
        if '前半固定' in z.指標:
            v = F['atr_5m' if 'ATR5分' in z.指標 else 'atr_15m'].values.astype(float); t = D['ok'] & (D['yr'] <= 2021) & ~np.isnan(v)
            m = v >= np.quantile(v[t], .9)
        else:
            col = 'rk_atr_%s_%s' % ('5m' if 'ATR5分' in z.指標 else '15m', '90d' if '90日' in z.指標 else '365d'); m = D['RK'][col].values >= .9
    elif z.出所.startswith('S6逆張り'):
        tag, sp, lab = z.指標.split('|'); m = np.unpackbits(M4[(tag, sp, z.窓, lab)])[:len(en)].astype(bool)
    else: m = (D['bl'] if z.後半のみ else D['ba'])[(z.指標, z.区分)]
    if z.使い方 == '避ける': return ~m, m
    return m, None
SEGS = {'D>N': ['D>N'], 'N>D': ['N>D'], '両方の窓': ['D>N', 'N>D']}
XG = np.array([.2, .3, .4, .5, .6, .7, .8, .9, 1.0, 1.2, 1.5])
# 条件の集合（乖離幅0.2〜1.5%の格子の (セッション, 乖離幅)、2022年以降）と、実際に入る窓（代表の乖離幅、2022年以降）
ROW = {}; TR = {}; ENT = {}   # ENT：入る側の (セッション, 乖離幅) の集合（「避ける」でも入る側）
for z in C.itertuples():
    D = DATA[(z.定義, z.向き)]; en = D['en']; key = D['sess'] * 100 + np.round(en.x.values * 10).astype(int)
    per = D['ok'] & np.isin(en.kind.values, SEGS[z.窓]) & (D['yr'] >= 2022)
    if z.後半のみ: per &= (D['yr'] >= 2023) & ~np.isnan(D['F'][z.指標].values)
    m, rm = cond_mask(z, D); sel = rm if rm is not None else m
    ROW[z.id] = set(key[per & np.isin(np.round(en.x.values, 3), XG) & sel])
    ENT[z.id] = set(key[per & np.isin(np.round(en.x.values, 3), XG) & m])
    TR[z.id] = set(D['sess'][per & np.isclose(en.x.values, z.x) & m])
C['条件の該当数(2022-)'] = [len(ROW[i]) for i in C['id']]; C['入る窓の数(2022-)'] = [len(TR[i]) for i in C['id']]
# 絞り込みの度合い：同じ定義・向き・窓・乖離幅の条件なしで入る窓のうち、その候補で入る割合（0.8以上は「ほぼ条件なしと同じ」）
share = []
for z in C.itertuples():
    D = DATA[(z.定義, z.向き)]; en = D['en']; per = D['ok'] & np.isin(en.kind.values, SEGS[z.窓]) & (D['yr'] >= 2022) & np.isclose(en.x.values, z.x)
    if z.後半のみ: per &= (D['yr'] >= 2023)
    nb = len(set(D['sess'][per])); share.append(len(TR[z.id]) / nb if nb else np.nan)
C['条件なしのうち入る割合'] = share; C['ほぼ条件なし'] = (C['条件なしのうち入る割合'] >= .8) & (C['使い方'] == '入る')
def sim(sets, ids):
    """Ochiai（共通 ÷ √(Aの数×Bの数)）と入れ子（共通 ÷ 小さい方）"""
    n = len(ids); S = np.eye(n); OV = np.eye(n); L = [sets[i] for i in ids]
    for a in range(n):
        for b in range(a + 1, n):
            i_ = len(L[a] & L[b]); d = np.sqrt(len(L[a]) * len(L[b])); mn = min(len(L[a]), len(L[b]))
            S[a, b] = S[b, a] = i_ / d if d else 0; OV[a, b] = OV[b, a] = i_ / mn if mn else 0
    return S, OV
def cluster(S, thr):
    if len(S) == 1: return np.array([1])
    return fcluster(linkage(squareform(1 - S, checks=False), 'average'), 1 - thr, 'distance')
PAIRS = []; C['グループ'] = ''
for side in ('順張り', '逆張り'):
    for kind in ('入る', '避ける'):
        sub = C[(C['向き'] == side) & (C['使い方'] != '基本') & ((C['使い方'] == '避ける') if kind == '避ける' else (C['使い方'] != '避ける'))]
        ids = list(sub['id']); S, OV = sim(ROW, ids)
        g5 = cluster(S, .5); g4 = cluster(S, .4); g6 = cluster(S, .6)
        C.loc[sub.index, 'グループ'] = ['%s・%s・%02d' % (side, kind, c) for c in g5]
        C.loc[sub.index, '大グループ(0.3)'] = ['%s・%s・大%02d' % (side, kind, c) for c in cluster(S, .3)]
        # 安定性：0.6で同じグループのまま／0.4で他のグループと合わさるか
        st = []
        for i in range(len(ids)):
            same5 = g5 == g5[i]; st.append('分かれる(0.6)' if len(set(g6[same5])) > 1 else ('合わさる(0.4)' if (g4 == g4[i]).sum() > same5.sum() else '安定'))
        C.loc[sub.index, 'グループの安定性'] = st
        C.loc[sub.index, 'グループ内の平均の似かた'] = [S[i, g5 == g5[i]].mean() if (g5 == g5[i]).sum() > 1 else np.nan for i in range(len(ids))]
        for a in range(len(ids)):
            for b in range(a + 1, len(ids)):
                if S[a, b] >= .4 or OV[a, b] >= .8: PAIRS.append(dict(向き=side, 種類=kind, A=ids[a], B=ids[b], 似かた=S[a, b], 入れ子=OV[a, b], 同じグループ=g5[a] == g5[b]))
C.loc[C['使い方'] == '基本', 'グループ'] = C.loc[C['使い方'] == '基本', '向き'] + '・基本'
# 矛盾の確認：「入る」候補の条件と「避ける」候補の外す区分が大きく重なる（同じ向き・同じ定義・同じ窓を含む）
CONF = []
for side in ('順張り', '逆張り'):
    A_ = C[(C['向き'] == side) & (C['使い方'] == '入る')]; B_ = C[(C['向き'] == side) & (C['使い方'] == '避ける')]
    for a in A_.itertuples():
        for b in B_.itertuples():
            if a.定義 != b.定義 or not (set(SEGS[a.窓]) & set(SEGS[b.窓])): continue
            i_ = len(ROW[a.id] & ROW[b.id]); r = i_ / len(ROW[a.id]) if ROW[a.id] else 0
            if r >= .5:
                bid = C.loc[(C['使い方'] == '基本') & (C['定義'] == b.定義) & (C['向き'] == side) & (C['窓'] == b.窓), 'id'].iloc[0]; base_n = len(ROW[bid])
                CONF.append(dict(向き=side, 入る候補=a.id, 避ける候補=b.id, 入る条件のうち外す区分に入る割合=r, 避ける候補が外す割合=len(ROW[b.id]) / base_n if base_n else np.nan))
# 代表
C = C.sort_values(['グループ', '選び方数', '最小', '年件数'], ascending=[True, False, False, False])
C['グループ内順位'] = C.groupby('グループ').cumcount() + 1; C['代表'] = ''
for gname, g in C.groupby('グループ'):
    if g['使い方'].iloc[0] == '基本': C.loc[g.index, '代表'] = '基本'; continue
    C.loc[g.index[0], '代表'] = '代表'; first = g.iloc[0]; rest = g.iloc[1:]
    alt = rest[(rest['定義'] != first['定義']) | (rest['窓'] != first['窓']) | (rest['テーマ'] != first['テーマ'])]
    if len(alt): C.loc[alt.index[0], '代表'] = '2番目'
nmap = C.set_index('id')['名前'] + '（' + C.set_index('id')['定義'] + '・' + C.set_index('id')['窓'] + '・' + C.set_index('id')['使い方'] + '）'
P = pd.DataFrame(PAIRS); P['A名'] = P['A'].map(nmap); P['B名'] = P['B'].map(nmap)
CF = pd.DataFrame(CONF)
if len(CF): CF['入る候補名'] = CF['入る候補'].map(nmap); CF['避ける候補名'] = CF['避ける候補'].map(nmap)
gs = C[C['使い方'] != '基本'].groupby('グループ').agg(向き=('向き', 'first'), 件数=('id', 'size'), テーマ=('テーマ', lambda v: ' / '.join('%s%d' % (a, b) for a, b in Counter(v).most_common(3))),
        定義=('定義', lambda v: '/'.join(sorted(set(v)))), 窓=('窓', lambda v: '/'.join(sorted(set(v)))), 中央の最大=('中央', 'max'), 安定=('グループの安定性', lambda v: Counter(v).most_common(1)[0][0]),
        メンバー=('名前', lambda v: ' | '.join(list(v)[:8]) + (' …' if len(v) > 8 else ''))).reset_index()
rep = C[C['代表'] == '代表'][['グループ', 'id', '名前', '定義', '窓', '使い方', '中央', '最小', '年件数', '選び方数', '最大DD']].rename(columns=lambda c: c if c == 'グループ' else '代表:' + c)
gs = gs.merge(rep, on='グループ')
# 代表どうしの「入る窓」の重なり（同時運用の準備）
REP = C[C['代表'].isin(['代表', '基本']) & (C['使い方'] != '避ける')]; RO = []   # 「避ける」の代表は入る窓が条件なしとほぼ同じなので除く
for side in ('順張り', '逆張り'):
    r = REP[REP['向き'] == side]; ids = list(r['id']); S, OV = sim(TR, ids)
    for a in range(len(ids)):
        for b in range(a + 1, len(ids)):
            if S[a, b] >= .3: RO.append(dict(向き=side, A名=nmap[ids[a]], B名=nmap[ids[b]], 入る窓の似かた=S[a, b], 入れ子=OV[a, b]))
RO = pd.DataFrame(RO)
C.to_pickle(W + '/S12cands.pkl'); pd.to_pickle(dict(ROW=ROW, ENT=ENT, TR=TR), W + '/S12sets.pkl'); gs.to_pickle(W + '/S12groups.pkl'); P.to_pickle(W + '/S12pairs.pkl'); CF.to_pickle(W + '/S12conf.pkl'); RO.to_pickle(W + '/S12repov.pkl')
print('候補', len(C), 'グループ', gs.groupby(['向き']).size().to_dict()); print(gs.groupby('向き')['件数'].describe())
print('安定性', C['グループの安定性'].value_counts().to_dict()); print('大グループ', C[C['使い方'] != '基本'].groupby('向き')['大グループ(0.3)'].nunique().to_dict()); print('矛盾の組', len(CF)); print('代表どうしで入る窓が似ている組（≥0.3）', len(RO))
