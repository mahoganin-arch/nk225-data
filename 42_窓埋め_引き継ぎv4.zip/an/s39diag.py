# Pine v0.8 のログと Python の照合：一致・Pineだけ・Pythonだけを出し、食い違いは Python 側の指標の値と条件の判定を並べる
import sys, glob, re, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/work/08/an'); from s10scr import load
from s9cal import flags
W = '/home/claude/work'
S = pd.read_pickle(W + '/S37rules.pkl')
DS = {('現行', '順張り'): W + '/T', ('先物基準', '順張り'): W + '/F6W/T6', ('現行', '逆張り'): W + '/R', ('先物基準', '逆張り'): W + '/F6W/R6'}
CACHE = {}
def get(key):
    if key not in CACHE:
        d = DS[key]; Y, en, MN, F = load(d)
        FL = flags(pd.read_pickle(d + '/evt.pkl')).iloc[en.ev.values].reset_index(drop=True)
        CACHE[key] = (en, F, FL)
    return CACHE[key]
def cond(r, v):
    if np.isnan(v): ok = False
    else:
        kb = r['区分_']; lo, hi = r['下限(以上)'], r['上限(未満)']
        if kb == '印あり': ok = v == 1
        elif kb.startswith('='): ok = v == float(kb[1:])
        elif kb == '上位10%': ok = v >= lo
        elif kb == '下位10%': ok = v <= hi
        else: ok = (np.isnan(lo) or v >= lo) and (np.isnan(hi) or v < hi)
    return (not ok) if r['使い方'] == '避ける' else ok
P = []
for f in sorted(glob.glob(sys.argv[1] + '/pine-logs*' + (sys.argv[2] if len(sys.argv) > 2 else 'v0.9') + '*.csv')):
    L = pd.read_csv(f)
    for t, msg in L.values:
        m = re.match(r'ENTRY id=(\d+) dir=(-?1) E=([\d,\.]+) .* v=(\S+)', msg)
        if m: P.append(dict(t=pd.Timestamp(t), id=int(m[1]), dir=int(m[2]), E=float(m[3].replace(',', '')), v=float(m[4]) if m[4] != 'NaN' else np.nan, src=f.split('条件あり')[-1]))
P = pd.DataFrame(P).drop_duplicates(['t', 'id'])
R = pd.read_csv(W + '/08/results/照合用_条件あり_61本_2026-09-01_10-08.csv'); R['t'] = pd.to_datetime(R['入る（日本時間）']).dt.tz_localize('Asia/Tokyo')
end = pd.Timestamp('2026-10-08 23:59', tz='Asia/Tokyo'); beg = pd.Timestamp('2026-09-01 06:00', tz='Asia/Tokyo')
Pp = P[(P.t >= beg) & (P.t <= end)]
M = Pp.merge(R, left_on='id', right_on='#', how='outer', suffixes=('', '_py'))
M = M[(M.t.isna()) | (M.t_py.isna()) | ((M.t - M.t_py).abs() <= pd.Timedelta('3min'))]
both = M.dropna(subset=['t', 't_py']); 
po = Pp[~Pp.set_index(['t', 'id']).index.isin(both.set_index(['t', 'id']).index)]
yo = R[~R.set_index(['t', '#']).index.isin(both.set_index(['t_py', '#']).index)]
print('一致', len(both), ' Pineだけ', len(po), ' Pythonだけ', len(yo))
print('一致の v の差 最大', (both.v - both.v_py).abs().max().round(4), ' 値段の差 最大', (both.E - both['入る値段']).abs().max())
def pyrow(r, t):
    key = (r['定義'], r['向き']); en, F, FL = get(key); x = float(r['乖離幅(%)'])
    mm = t.tz_convert('UTC').value // 60_000_000_000
    c = en.index[(np.isclose(en.x, x)) & (np.abs(en.m - mm) <= 3)]
    ind = r['指標(内部名)']
    vals = [(F[ind].values[i] if ind in F.columns else float(FL[ind].values[i])) for i in c]
    return c.tolist(), vals
print('\n--- Pineだけ（Python の同じ時刻の行の値）')
for _, p in po.iterrows():
    r = S.iloc[p.id - 1]; c, vals = pyrow(r, p.t)
    print(p.t.strftime('%m-%d %H:%M'), '#%d' % p.id, r['名前'], r['定義'], '| Pine v=%s' % p.v, '| Py v=', [round(v, 4) for v in vals], '条件', [cond(r, v) for v in vals], '| しきい', r['下限(以上)'], r['上限(未満)'], r['使い方'])
print('\n--- Pythonだけ')
for _, p in yo.iterrows():
    r = S.iloc[p['#'] - 1]
    print(p.t.strftime('%m-%d %H:%M'), '#%d' % p['#'], r['名前'], r['定義'], 'Py v=', p.v, '| しきい', r['下限(以上)'], r['上限(未満)'])
print('\n--- 10/9以降（Pythonの答えなし）'); print(P[P.t > end][['t', 'id', 'dir', 'E', 'v']].to_string(index=False))
