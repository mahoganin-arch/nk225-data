# 逆張りC・Bの選び直しと 5-2（SQ・祝日・月末月初）の Excel。残す基準：3/5以上プラス・中央+20円以上・年10件以上（C・Bは1つの分け方で確かめる平均+20円以上・年10件以上）
import pandas as pd, numpy as np
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
W = '/home/claude/work'; OUT = W + '/08/results/S6_逆張りCB選び直し_SQ祝日月末.xlsx'
C = pd.read_pickle(W + '/S4C.pkl'); B = pd.read_pickle(W + '/S4B.pkl')
yrs = {'前半→後半': 4.77, '2017-21→2022-23': 2, '2017-23→2024-26': 2.77, '2022-23→2024-26': 2.77}
for D in (C, B): D['確かめる年件数'] = D['確かめる件数'] / D['分け方'].map(yrs); D['残す'] = (D['確かめる平均'] >= 20) & (D['確かめる年件数'] >= 10); D['決済'] = D['決済'].astype(str)
O0 = pd.read_pickle(W + '/S9cal.pkl'); k = ['定義', '向き', '印', '使い方', '窓', '選び方']
G = O0.groupby(k).agg(プラス数=('平均', lambda v: (v > 0).sum()), 中央=('平均', 'median'), 最小=('平均', 'min'), 年件数=('年件数', 'median'), 最大DD=('最大DD', 'median')).reset_index()
G = G.merge(G[G['印'] == '条件なし'][['定義', '向き', '窓', '選び方', '中央']].rename(columns={'中央': '条件なし中央'}), on=['定義', '向き', '窓', '選び方']); G['改善'] = G['中央'] - G['条件なし中央']
G['残す'] = (G['プラス数'] >= 3) & (G['中央'] >= 20) & (G['年件数'] >= 10)
O = pd.read_pickle(W + '/S9cal.pkl')
keep = G[G['残す'] & (G['印'] != '条件なし') & (G['改善'] >= 20)].sort_values(['向き', '改善'], ascending=[True, False])
desc = [
 ['この表について', '候補を残す基準を緩めた（2026-10-13 合意）うえでの、逆張り C（投票方式）・B（2指標）の選び直しと、5-2 SQ・祝日・月末月初の条件の検証。すべて13pt控除後、円/回'],
 ['残す基準', 'ステップ2型の評価：5つの評価の形のうち3つ以上でプラス、中央値+20円以上、年10件以上。C・B は分け方ごとに選ぶため「確かめる期間の平均+20円以上・年10件以上」'],
 ['逆張り C・B', 'C：60件中4件、B：上位20組×4分け方×3窓（215件）中8件が残る。多くは N>D・乖離幅0.1〜0.3%・損切りなし／大きい損切り。週足の75MA傾き下位・100MA乖離上位（週足の下げ基調での戻り）や「経過分=5分割:4」が繰り返し出る'],
 ['', '注意：最悪の1回が −570〜−2,435円。B は1つの分け方でしか確かめていない（同じ組が他の分け方で選ばれるとは限らない）'],
 ['5-2 印の作り方', '窓の日付（D>Nは引けた日、N>Dは日中セッションの日）に、SQ週(メジャー/ミニ)、SQ当日、SQ前日、祝日前日、祝日翌日(連休明け含む)、祝日取引中、月末3営業日、月初3営業日の印を付け、「入る（印あり）」「避ける（印なし）」を条件なしに加えた'],
 ['5-2 結果', '残す基準を満たし、条件なしより中央値で+20円以上良いもの（候補シート）。順張り：SQ週(ミニ)を避ける（D>N、現行・先物基準とも）、月末3営業日・月初3営業日に入る（両方の窓、年12〜14件）、SQ前日・祝日前日を避ける（D>N）、SQ週(メジャー)を避ける（N>D・先物基準の両方の窓）など'],
 ['', '逆張り：SQ週(ミニ)に入る D>N（周辺 +56円、年11件、5/5プラス）、月初3営業日を避ける D>N（+31円）、先物基準 N>D 月初3営業日を避ける（+30円）'],
 ['シート', '候補（印）：残す基準＋改善+20円以上／印まとめ全件：印×使い方×窓×選び方の5つの形のまとめ／印の評価の形ごと：全件／C・B：全件（残す列で絞り込み）'],
]
with pd.ExcelWriter(OUT, engine='openpyxl') as w:
    pd.DataFrame(desc, columns=['項目', '内容']).to_excel(w, sheet_name='説明', index=False)
    keep.round(1).to_excel(w, sheet_name='候補（印）', index=False)
    G.round(1).to_excel(w, sheet_name='印まとめ全件', index=False)
    O.round(1).to_excel(w, sheet_name='印の評価の形ごと', index=False)
    C.round(1).to_excel(w, sheet_name='逆張りC', index=False)
    B.round(1).to_excel(w, sheet_name='逆張りB', index=False)
wb = load_workbook(OUT)
for ws in wb:
    for row in ws.iter_rows():
        for c in row: c.font = Font(name='Arial', size=10, bold=c.row == 1)
    for c in ws[1]: c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.freeze_panes = 'A2'
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = 13
ws = wb['説明']; ws.column_dimensions['A'].width = 16; ws.column_dimensions['B'].width = 150
for c in ws['B']: c.alignment = Alignment(wrap_text=True, vertical='top')
wb.save(OUT); print(OUT, len(keep))
