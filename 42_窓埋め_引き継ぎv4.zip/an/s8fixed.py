# 5-4 先物基準と現行の比較：同じ固定ルールの年ごとの成績（13pt控除後、円/回）。参考（ルールは現行の分析で選んだ形）
import sys; sys.path.insert(0, '/home/claude/work/01/code'); from common6 import CB, P
import numpy as np, pandas as pd
W = '/home/claude/work'
def load(d):
    Y = np.load(d + '/Y.npy', mmap_mode='r'); en = pd.read_pickle(d + '/en.pkl'); ev = pd.read_pickle(d + '/evt.pkl'); en = en.join(ev[['kind', 'long', 't0']], on='ev'); en['yr'] = en.t0.dt.year
    en['px'] = en.ent.values if 'ent' in en else ev.B.values[en.ev.values]; return Y, en
def maxdd(v):
    c = np.cumsum(v); return float((np.maximum.accumulate(np.r_[0, c])[1:] - c).max())
rows = []
for lab, d in (('先物基準', W + '/F6W/T6'), ('現行', W + '/T')):
    Y, en = load(d)
    for name, x, ex in (('中間 0.9%・戻り90%・利確×0.6・引け', .9, (.9, .6, 0)), ('後半型 0.9%・戻り90%・利確×1.5・引け', .9, (.9, 1.5, 0)), ('1.0%・戻り100%・利確×1.5・引け', 1.0, (1.0, 1.5, 0)), ('1.2%・戻り90%・利確×1.5・引け', 1.2, (.9, 1.5, 0))):
        for w, ks in (('D>N', ['D>N']), ('N>D', ['N>D']), ('両方の窓', ['D>N', 'N>D'])):
            idx = np.nonzero((~en.long.values) & np.isclose(en.x.values, x) & np.isin(en.kind.values, ks))[0]; idx = idx[np.argsort(en.m.values[idx])]
            v = np.asarray(Y[idx, CB.index(ex)], float) / 100 * P - 13 * P / en.px.values[idx]; y = en.yr.values[idx]
            r = {'定義': lab, 'ルール': name, '窓': w, '件数': len(v), '前半': v[y <= 2021].mean(), '後半': v[y >= 2022].mean(), '後半DD': maxdd(v[y >= 2022]), '全期間DD': maxdd(v)}
            for yy in range(2017, 2027): r[str(yy)] = v[y == yy].mean()
            rows.append(r)
O = pd.DataFrame(rows); O.to_pickle(W + '/S8fixed.pkl'); pd.set_option('display.width', 260)
print(O.round(0).to_string(index=False))
