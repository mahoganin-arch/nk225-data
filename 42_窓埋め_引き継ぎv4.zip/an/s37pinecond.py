# Pine v0.8：61本の条件（指標）を入れる。s31pine.py の骨組みに、pine_ind.txt（指標の計算）と、候補ごとの f_val・f_cond を足す
import re, numpy as np, pandas as pd
W = '/home/claude/work'; AN = W + '/08/an'
src = open(AN + '/s31pine.py').read()
S = pd.read_pickle(W + '/S37rules.pkl')
EXPR = {
 'ストキャス_4h': 'h4_st * s', 'ねじれ前_4h': 'h4_nej', 'BBσ位置_4h': 'h4_bb * s', '雲の厚さ_4h': 'h4_th', 'kijun_4h': 'h4_kj * s', '平均足実体比_4h': 'h4_hb', '60本高安の位置_4h': 'h4_p60 * s',
 'harun_15m': 'n15_harun * s', 'di_15m': 'n15_di * s', 'BB幅順位_15m': 'n15_bwr', '遅行スパン_15m': 'n15_chi * s', 'ストキャス_15m': 'n15_st * s', 'adx_15m': 'n15_adx',
 'cloud_15m': 'n15_cloud * s', 'ma25_15m': 'n15_ma25 * s', 'ret20_15m': 'n15_ret20 * s', 'ma75_15m': 'n15_ma75 * s',
 'slope_s_60m': 'n60_slope * s', 'ねじれ前_60m': 'n60_nej', 'macd_60m': 'n60_macd * s', 'rsi_60m': 'n60_rsi * s', 'slope_s_5m': 'n5_slope * s', 'di_5m': 'n5_di * s',
 '雲の厚さ_D': 'hD_th', 'harun_D': 'hD_run * s', 'ret5_D': 'hD_ret5 * s', 'BBσ位置_D': 'hD_bb * s',
 'ma13x26_W': 'hW_mx * s', '平均足実体比_W': 'hW_hb', '遅行スパン_W': 'hW_chi * s', 'ret5_W': 'hW_ret5 * s', 'di_W': 'hW_di * s',
 '前日高安まで': '((s > 0 ? hD_h : hD_l) - entp) / Bx * 100 * s', '前月高安まで': '((s > 0 ? hM_h : hM_l) - entp) / Bx * 100 * s',
 '前週安高まで': '((s > 0 ? hW_l : hW_h) - entp) / Bx * 100 * s', '前週終値まで': '(hW_c - entp) / Bx * 100 * s',
 'キリ500まで': 'math.min(entp % 500, 500 - entp % 500) / Bx * 100',
 'SQ値まで': '(SQV - entp) / Bx * 100 * s', 'メジャーSQ値まで': '(MSQV - entp) / Bx * 100 * s',
 'SQ週(ミニ)': 'f_sqweek(wDateT) ? 1.0 : 0.0', '月の何週目': 'math.floor((dayofmonth(wDateT, "Asia/Tokyo") - 1) / 7) + 1',
 '前の窓の連続(向き)': 'runW * s', '前セッション実体比': '(pB - pO) / math.max(pH - pL, 1e-9) * s', '前セッション値幅': '(pH - pL) / Bx * 100',
 '引け位置': '(s > 0 ? (Bx - pL) / math.max(pH - pL, 1e-9) : 1 - (Bx - pL) / math.max(pH - pL, 1e-9))',
 '停止中値幅÷日ATR': '((hrH - hrL) / Bx * 100) / hD_atr', '前セッション最後1時間の出来高比': 'lateW', '日足出来高比5': 'volR5',
}
def num(v): return repr(float(v))
VAL = []; CON = []
for k, r in S.iterrows():
    ind = r['指標(内部名)']; kb = r['区分_']; e = EXPR[ind]
    VAL.append('        %d => v := %s' % (k, e))
    lo, hi = r['下限(以上)'], r['上限(未満)']
    if kb == '印あり': t = 'v == 1'
    elif kb.startswith('='): t = 'v == %s' % num(float(kb[1:]))
    elif kb == '上位10%': t = 'v >= %s' % num(lo)
    elif kb == '下位10%': t = 'v <= %s' % num(hi)
    else:
        t = ' and '.join(([] if np.isnan(lo) else ['v >= %s' % num(lo)]) + ([] if np.isnan(hi) else ['v < %s' % num(hi)]))
    t = 'not na(v) and ' + t
    if r['使い方'] == '避ける': t = 'not (%s)' % t
    CON.append('        %d => r := %s' % (k, t))
FUNCS = '''
// ---------- 候補ごとの指標の値と条件（Python の区分のしきい値。向きのある指標は「窓と同じ向き＝プラス」）
f_sqweek(int ts) =>
    y = year(ts, "Asia/Tokyo")
    m = month(ts, "Asia/Tokyo")
    fd = dayofweek(timestamp("Asia/Tokyo", y, m, 1, 0, 0), "Asia/Tokyo")
    sf = 1 + (6 - fd + 7) % 7 + 7
    sqT = timestamp("Asia/Tokyo", y, m, sf, 12, 0)
    dw = dayofweek(ts, "Asia/Tokyo")
    mon = ts - ((dw + 5) % 7) * 86400000
    dwS = dayofweek(sqT, "Asia/Tokyo")
    monS = sqT - ((dwS + 5) % 7) * 86400000
    not (m == 3 or m == 6 or m == 9 or m == 12) and str.format_time(mon, "yyyyMMdd", "Asia/Tokyo") == str.format_time(monS, "yyyyMMdd", "Asia/Tokyo")
f_val(int i, bool up, float ep) =>
    s = up ? 1.0 : -1.0
    isF = array.get(cDef, i) == 1
    Bx = isF ? Bf : B
    x = array.get(cX, i)
    entp = isF ? ep : B * (1 + s * x / 100)
    float v = na
    switch i
__VAL__
    v
f_cond(int i, bool up, float ep) =>
    v = f_val(i, up, ep)
    bool r = true
    switch i
__CON__
    r
f_estE(int i, bool up) =>
    (array.get(cDef, i) == 0 ? B : Bf) * (1 + (up ? array.get(cX, i) : -array.get(cX, i)) / 100)
'''.replace('__VAL__', '\n'.join(VAL)).replace('__CON__', '\n'.join(CON))
IND = open(AN + '/pine_ind.txt').read()
# 4時間の60本高安の位置も返す
IND = IND.replace("a4_hb[1], b4_hb[1], eDf[1]", "a4_hb[1], b4_hb[1], a4_p60[1], b4_p60[1], eDf[1]")
IND = IND.replace("a4_hb, b4_hb, x_eD", "a4_hb, b4_hb, a4_p60, b4_p60, x_eD")
IND = IND.replace("h4_hb = u4 ? a4_hb : b4_hb", "h4_hb = u4 ? a4_hb : b4_hb\nh4_p60 = u4 ? a4_p60 : b4_p60")
# 前月：今の日の月が確定した月と違えば、確定した月が前月（A・B 共通）
IND = IND.replace("hM_h = uD ? aM_h : bM_h\nhM_l = uD ? aM_l : bM_l", "hM_h = aM_h\nhM_l = aM_l")
a = src.index("pine = r'''"); b = src.index("'''\nfor k, v in")
p = src[a:b]
p = p.replace('''// ---------- 条件（ステップ4で指標を入れる）。up=true は窓が上に離れた側
f_cond(int i, bool up) =>
    true
''', '')
p = p.replace("f_fmt(float v) =>", IND + FUNCS + "\nf_fmt(float v) =>", 1)
# 呼び出し
p = p.replace("and f_cond(i, up)\n                            array.push(qId, i)", "and true\n                            array.push(qId, i)")
p = p.replace("""                if not (array.get(cSell, i) and d != -1) and f_cond(i, up)
                    x = array.get(cX, i)""", """                if not (array.get(cSell, i) and d != -1) and f_cond(i, up, f_estE(i, up))
                    x = array.get(cX, i)""")
p = p.replace("and f_cond(i, up) and f_can(i, d)\n                        E = reo", "and f_cond(i, up, c_) and f_can(i, d)\n                        E = reo")
p = p.replace("and f_cond(i, up) and f_can(i, d)\n                        f_open(i, d, o_", "and f_cond(i, up, o_) and f_can(i, d)\n                        f_open(i, d, o_")
p = p.replace("and f_cond(i, up)\n                            best := prog", "and f_cond(i, up, f_estE(i, up))\n                            best := prog")
p = p.replace("prog < 1 and not (array.get(cSell, i) and d != -1) and f_cond(i, up)", "prog < 1 and not (array.get(cSell, i) and d != -1) and f_cond(i, up, f_estE(i, up))")
p = p.replace("and f_cond(i, up) and not (isF and fBack)", "and f_cond(i, up, f_estE(i, up)) and not (isF and fBack)")
# 予約の実行：この足の始値で、条件を確かめてから入る
p = p.replace("""            if f_can(i, d)
                E = o_
                f_open(i, d, E,""", """            if f_cond(i, gapSign > 0, o_) and f_can(i, d)
                E = o_
                f_open(i, d, E,""")
# 「まもなく入る」アラートは、今の値段で条件を見たときだけ
p = p.replace("""                            alert("【まもなく入る】""", """                            if f_cond(i, up, c_)
                                alert("【まもなく入る】""")
# エントリーのログに指標の値
p = p.replace('log.info("ENTRY id={0} dir={1} E={2} tp={3} sl={4}", i + 1, d, E, tp, sl)',
              'log.info("ENTRY id={0} dir={1} E={2} tp={3} sl={4} v={5}", i + 1, d, E, tp, sl, f_val(i, array.get(cSide, i) == 0 ? d < 0 : d > 0, E))')
# 基準が決まったときに、前のセッション・連続・出来高・停止中の値幅を確定
p = p.replace("    B := preDN\n    Bf := na(fC) ? fLast : fC\n", "    B := preDN\n    Bf := na(fC) ? fLast : fC\n    pO := sesO\n    pH := sesH\n    pL := sesL\n    pB := B\n    runW := streak\n    lateW := lateR\n    hrH := na\n    hrL := na\n    wDateT := time\n")
p = p.replace("    B := Bnd\n    Bf := fLast\n", "    B := Bnd\n    Bf := fLast\n    pO := sesO\n    pH := sesH\n    pL := sesL\n    pB := B\n    runW := streak\n    lateW := na\n    hrH := na\n    hrL := na\n    wDateT := time\n")
# 停止中の値幅（N>D：基準のあと、先物が寄るまで）を、その足の処理のあとで更新
p = p.replace("// ---------- チャートに描く", "if barstate.isconfirmed and wOn and wKind == 1 and not fOpen\n    hrH := na(hrH) ? h_ : math.max(hrH, h_)\n    hrL := na(hrL) ? l_ : math.min(hrL, l_)\n\n// ---------- チャートに描く", 1)
p = p.replace('indicator("窓埋め61本 v0.7 骨組み（条件なし）"', 'indicator("窓埋め61本 v0.8 条件あり"')
p = p.replace("// まだ指標の条件は入っていない（f_cond はいつも true）。Python の「条件なし」の計算と照合するための版", "// 61本の条件（指標）を入れた版。Python の「条件あり」と照合する")
assert p.count('f_cond(i, up)') == 0, p.count('f_cond(i, up)')
out = src[:a] + p + src[b:]
out = out.replace("窓埋め61本_v0.7_骨組み.pine", "窓埋め61本_v0.8_条件あり.pine")
open(AN + '/s37gen.py', 'w').write(out)
