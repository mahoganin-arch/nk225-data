import numpy as np, pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter
from lib import W
def dec(t):
    if not isinstance(t, tuple): return ''
    sl, tp, tm = t
    return '損切り:戻り%d%% / 利確:%s / 時間:%s' % (round(sl * 100), 'なし' if tp == 0 else '幅×%g' % tp, '次の引け' if tm == 0 else '%d分' % tm)
S = {sp: pd.read_pickle(W + '/S1sum_%g.pkl' % sp) for sp in (0, 13, 20)}
R = pd.read_pickle(W + '/S1_13.pkl'); Yt = pd.read_pickle(W + '/S1y_13.pkl')
# まとめ
M = S[13].copy(); M['①決済'] = M['①決済'].map(dec); M['③決済'] = M['③決済'].map(dec)
M.insert(3, 'スプレッド0の①後半', S[0]['①後半'].values); M.insert(4, 'スプレッド20の①後半', S[20]['①後半'].values)
M['スプレッド0の④'] = S[0]['④その幅の24-26中央'].values; M['スプレッド20の④'] = S[20]['④その幅の24-26中央'].values
M = M.rename(columns={'A主要': 'Aの主要戦略', '①前半最良の幅': '①乖離幅%', '①前半': '①前半平均', '①後半': '①後半平均', '①後半分岐pt': '①後半の損益分岐スプレッド(pt)',
    '②前半+20の幅数': '②前半+20円以上の幅数', '②その幅の後半中央': '②その幅の後半平均(中央)', '②後半プラス%': '②その幅で後半プラス%',
    '③22-23最良の幅': '③乖離幅%', '③22-23': '③22-23平均', '③24-26': '③24-26平均', '④22-23+20の幅数': '④22-23+20円以上の幅数', '④その幅の24-26中央': '④その幅の24-26平均(中央)', '④24-26プラス%': '④その幅で24-26プラス%',
    '全幅:後半全決済平均の最大': '参考:後半の全決済平均(幅の中で最大)', '全幅:後半プラス決済%の最大': '参考:後半プラス決済%(幅の中で最大)'})
# 幅ごと
D = R.copy()
for c in ('前半選択_決済', '後半内_決済'): D[c] = D[c].map(dec)
D = D.drop(columns=[c for c in D.columns if c.endswith('合計') or c.endswith('最悪制約')])
# 年ごと
Yp = Yt.pivot_table(index=['窓', '戦略', '乖離幅%', '決済の選び方'], columns='年', values='平均(控除後)').reset_index()
Yc = Yt[Yt['決済の選び方'] == '前半選択'].pivot_table(index=['窓', '戦略', '乖離幅%'], columns='年', values='件数').reset_index()
Yc.columns = [('件数' + str(c)) if isinstance(c, (int, np.integer)) else c for c in Yc.columns]
Yp.columns = [str(c) for c in Yp.columns]; Yp = Yp.merge(Yc, on=['窓', '戦略', '乖離幅%'], how='left')
exp = [
 ['ステップ1：Aの主要な順張り戦略にコスト（スプレッド）を反映（2026-10-13）'],
 [''],
 ['コスト', '1回あたり = スプレッド(pt) ÷ 基準価格 × 68,800円。標準13pt。往復でスプレッド1回分。前半平均 約39円、後半平均 約24円（2026年は約15円）'],
 ['決済の選び方', 'コスト控除後の成績で選ぶ。選ぶ期間で「最悪の1回 −1,000円以上」の決済のうち平均が最良のもの（なければ制約なし）'],
 ['決済の表記（順張り）', '損切り:戻り○% ＝ 基準方向へ乖離距離の○%戻ったら損切り（100%超は基準を越えた位置）／利確:幅×○ ＝ エントリーから乖離幅の○倍進んだら利確／時間:次の引け ＝ 次の先物セッション引けで決済'],
 ['①', '前半(2017-21)で幅と決済を1つ選び、後半(2022-26/10/8)で確かめる（Aと同じ方式）'],
 ['②', '前半+20円以上だった幅をまたいだ、後半平均の中央値'],
 ['③', '後半重視：2022-23で幅と決済を1つ選び、2024-26/10/8で確かめる'],
 ['④', '後半重視：2022-23で+20円以上だった幅をまたいだ、2024-26平均の中央値（各期間15件以上の幅のみ）'],
 ['損益分岐スプレッド', 'コスト控除前の損益合計 ÷ 1ポイントあたりの円の合計。このpt数までのスプレッドなら損益がプラス'],
 ['ATRの境目', '窓×乖離幅ごとに前半のデータの上位10%点で固定（Aと同じ）'],
 ['確認', 'スプレッド0ptで計算すると前回のA（A_フィルター検証.xlsx）と一致'],
 ['シート', 'まとめ＝窓×戦略ごとの要約（13pt、0pt・20ptの比較つき）／幅ごと＝全件／年ごと＝年別平均（控除後）と件数'],
]
out = W + '/S1_コスト控除.xlsx'
with pd.ExcelWriter(out, engine='openpyxl') as xw:
    pd.DataFrame(exp).to_excel(xw, sheet_name='説明', index=False, header=False)
    M.round(1).assign(**{'①乖離幅%':M['①乖離幅%'],'③乖離幅%':M['③乖離幅%']}).to_excel(xw, sheet_name='まとめ', index=False); D.round(1).assign(**{'乖離幅%':D['乖離幅%'],'ATR境目%':D['ATR境目%'].round(3)}).to_excel(xw, sheet_name='幅ごと', index=False); Yp.round(1).assign(**{'乖離幅%':Yp['乖離幅%']}).to_excel(xw, sheet_name='年ごと', index=False)
wb = load_workbook(out); hf = PatternFill('solid', fgColor='DDEBF7')
for ws in wb:
    for row in ws.iter_rows():
        for c in row: c.font = Font(name='Arial', size=10, bold=(c.row == 1))
    if ws.title != '説明':
        for c in ws[1]: c.fill = hf; c.alignment = Alignment(wrap_text=True, vertical='top')
        ws.freeze_panes = 'D2'
        for i in range(1, ws.max_column + 1): ws.column_dimensions[get_column_letter(i)].width = 11
        ws.row_dimensions[1].height = 60
    else:
        ws.column_dimensions['A'].width = 20; ws.column_dimensions['B'].width = 140
for ws in (wb['まとめ'],):
    ws.column_dimensions['B'].width = 22
    for col in ('①決済', '③決済'):
        j = [c.value for c in ws[1]].index(col) + 1; ws.column_dimensions[get_column_letter(j)].width = 38
wb.save(out); print(out)
