# PF の下限を 1.4・1.6 にしたとき（重なり75%でまとめるのも併用）。s25narrow.py と同じ計算
src = open('/home/claude/work/08/an/s25narrow.py').read(); exec(src[:src.index("DIRS = ('両方', '売りのみ'); PR = []")])
DIRS = ('両方', '売りのみ'); PR = []
for nm_, dd_, pf_ in (('両方 PF1.2', .75, 1.2), ('両方 PF1.4', .75, 1.4), ('両方 PF1.6', .75, 1.6), ('PF1.4のみ', None, 1.4), ('PF1.6のみ', None, 1.6)):
    L26 = narrow(union_list(rank_old(2026, True), rank_rf(2026, True), 5, DIRS), fwd_stats(2026, True), dd_, pf_); n26 = sum(len(v) for v in L26.values())
    for pol, pn in (('A1', '先着1本'), ('C1', '同じ向き2本'), ('D1', '両建て＋2本目')):
        H = simulate_n(5, pol, DIRS, dd_, pf_).sort_values('手じまう時刻'); r = stats(H['損益'].values, 3)
        r.update(絞り方=nm_, 今の本数=n26, 方針=pn, 使った候補数=H['id'].nunique())
        for y, g in H.groupby('確かめる年'): r['%d年' % y] = g['損益'].sum()
        PR.append(r)
PR = pd.DataFrame(PR); PR.to_pickle(W + '/S25pf.pkl')
pd.set_option('display.width', 250)
print(PR[['絞り方', '今の本数', '方針', '使った候補数', '件数', '勝率', 'PF', '合計', '最大DD', '合計割る最大DD', '2024年', '2025年', '2026年']].round(2).to_string(index=False))
