# 前向きでマイナスの候補をどう扱うか判断するための情報
#   ① 候補ごと（S14の40行）：前向き平均の不確かさ（ブートストラップの90%区間、本当の平均がプラスである確率の目安）、選ぶ期間の平均との差、
#      年ごとのプラスの年数、ルール（乖離幅・決済）が年ごとに変わった回数、組み合わせ（同じ向き2本・上位10本）で実際に使われた件数と損益
#   ② ルール自体の前向き検証：「その年より前の前向き記録（2022年〜前年）がマイナスの候補は売買しない」を各年で決め、
#      外した場合と外さない場合の組み合わせの成績を比べる（2023〜26年。2022年は前向き記録がないので比較対象外）
#   ③ 持続性：ある年に前向きでマイナスだった候補は、翌年もマイナスになりやすいか（全候補・全年で）
import sys, numpy as np, pandas as pd
sys.argv = [sys.argv[0]]
exec(open('/home/claude/work/08/an/s13sim.py').read().split("if __name__ == '__main__':")[0])
SCN, METH, UNI = 'WF全期間', '周辺', '代表(0.5)'
L = pd.read_pickle(W + '/S14list.pkl'); PK = pd.read_pickle(W + '/S13picks.pkl')
TT = T0[(T0['評価'] == SCN) & (T0['選び方'] == METH)]
WF = TT[TT['年'] == TT['t']]
rng = np.random.default_rng(0)
def boot(v, n=4000):
    if len(v) < 3: return np.nan, np.nan, np.nan
    m = rng.choice(v, (n, len(v))).mean(1); return np.quantile(m, .05), np.quantile(m, .95), (m > 0).mean() * 100
H10 = pd.read_pickle(W + '/S14port_C1_10.pkl')
idmap = dict(zip(L.index, L['id']))   # S14 に保存した候補id（名前だけだと「入る」と「避ける」を取り違えるため）
rows = []
for k, r in L.iterrows():
    i = idmap[k]; v = WF[(WF['id'] == i) & (WF['窓の種類'] == r['窓の種類'])].sort_values('手じまう時刻')
    lo, hi, pp = boot(v['損益'].values)
    yr = v.groupby('年')['損益'].sum()
    pk = PK[(PK['id'] == i) & (PK['評価'] == SCN) & (PK['選び方'] == METH)].sort_values('t')
    chg = int((pk[['乖離幅']].astype(str).agg(''.join, axis=1) + pk['決済'].astype(str)).ne((pk[['乖離幅']].astype(str).agg(''.join, axis=1) + pk['決済'].astype(str)).shift()).sum() - 1)
    xs = '／'.join('%d:%g%%' % (a, b) for a, b in zip(pk['t'], pk['乖離幅']))
    used = H10[(H10['id'] == i) & (H10['窓の種類'] == r['窓の種類'])]
    rows.append({'id': i, '使い方': C.loc[i, '使い方'], '窓の種類': r['窓の種類'], '向き': r['向き'], '順位': r['順位'], '候補': r['候補'], '定義': r['定義'], '前向き:件数': len(v), '前向き:平均': v['損益'].mean(),
                 '平均の90%区間:下': lo, '平均の90%区間:上': hi, '本当の平均がプラスの確率%(目安)': pp, '選ぶ期間の平均(2017-25)': r['順位の値_2017_25の1回平均'],
                 '前向き−選ぶ期間': v['損益'].mean() - r['順位の値_2017_25の1回平均'], 'プラスの年/年数': '%d/%d' % ((yr > 0).sum(), len(yr)),
                 'ルールが変わった回数(5年)': chg, '年ごとの乖離幅': xs, '組み合わせで使われた件数': len(used), '組み合わせでの損益合計': used['損益'].sum(),
                 '組み合わせでの1回平均': used['損益'].mean() if len(used) else np.nan})
J = pd.DataFrame(rows)
# ② 「前向き記録がマイナスなら外す」の前向き検証（同じ向き2本・先着1本、上位5・10本）
SIMSRC = simulate
def simulate_drop(scn, meth, univ, N, pol, drop, minn=10):
    T = T0[(T0['評価'] == scn) & (T0['選び方'] == meth) & T0['id'].isin(UNIV[univ])]; out = []
    for t, Tt in T.groupby('t'):
        if t < 2023: continue
        ins = Tt[SEL[scn](Tt['年'].values, t)].groupby('id')['損益'].agg(['mean', 'size']); ins = ins[ins['size'] >= 15]['mean']
        if drop:
            past = T[(T['年'] == T['t']) & (T['年'] < t) & (T['年'] >= 2022)].groupby('id')['損益'].agg(['mean', 'size'])
            bad = past[(past['size'] >= minn) & (past['mean'] < 0)].index; ins = ins.drop(bad, errors='ignore')
        test = Tt[Tt['年'] == t].copy(); test['順位'] = -test['id'].map(ins); test = test[test['順位'].notna()]
        keep = []
        for kind in ('D>N', 'N>D'):
            tk = test[test['窓の種類'] == kind]
            for side, g in tk.groupby(tk['id'].map(C['向き'])):
                ids = g.groupby('id')['順位'].first().sort_values().head(N).index; keep.append(g[g['id'].isin(ids)])
        test = pd.concat(keep).sort_values(['セッション', '入る時刻', '順位'])
        for s, tr in test.groupby('セッション', sort=False):
            for h in run_window(tr.to_dict('records'), pol, False, fill.get(s, np.inf)): h['確かめる年'] = t; out.append(h)
    return pd.DataFrame(out)
D = []
for univ in ('代表(0.5)', '代表(0.4)', '代表(0.6)', '全候補'):
    for N in (5, 10):
        for pol in ('A1', 'C1'):
            for drop, minn in ((False, 0), (True, 5), (True, 10), (True, 20)):
                H = simulate_drop(SCN, METH, univ, N, pol, drop, minn); r = summarize(H)
                D.append(dict(候補の集まり=univ, N=N, 方針=pol, 外す=('外さない' if not drop else '前向き%d件以上で平均マイナスなら外す' % minn), **{k: r[k] for k in ('件数', '年あたり合計', '一回平均', '最大DD', '合計割る最大DD', '最悪の1窓', '2023', '2024', '2025', '2026') if k in r}))
DR = pd.DataFrame(D)
# ③ 持続性：候補×年の前向き平均（10件以上）の、翌年との関係
g = WF.groupby(['id', '年'])['損益'].agg(['mean', 'size']).reset_index(); g = g[g['size'] >= 5]
nx = g.merge(g.assign(年=g['年'] - 1), on=['id', '年'], suffixes=('', '_翌年'))
P1 = pd.DataFrame([dict(条件='その年マイナス', 件数=int((nx['mean'] < 0).sum()), 翌年プラスの割合=(nx.loc[nx['mean'] < 0, 'mean_翌年'] > 0).mean() * 100, 翌年の平均の中央=nx.loc[nx['mean'] < 0, 'mean_翌年'].median()),
                   dict(条件='その年プラス', 件数=int((nx['mean'] > 0).sum()), 翌年プラスの割合=(nx.loc[nx['mean'] > 0, 'mean_翌年'] > 0).mean() * 100, 翌年の平均の中央=nx.loc[nx['mean'] > 0, 'mean_翌年'].median())])
c = np.corrcoef(nx['mean'], nx['mean_翌年'])[0, 1]
# 前年までの前向き記録の累計で見た場合
acc = []
for t in range(2023, 2027):
    past = WF[(WF['年'] < t)].groupby('id')['損益'].agg(['mean', 'size']); past = past[past['size'] >= 10]
    now = WF[WF['年'] == t].groupby('id')['損益'].mean()
    m = past.join(now.rename('now'), how='inner'); acc.append(m.assign(t=t))
acc = pd.concat(acc)
P2 = pd.DataFrame([dict(条件='前年までの前向き記録がマイナス', 件数=int((acc['mean'] < 0).sum()), その年プラスの割合=(acc.loc[acc['mean'] < 0, 'now'] > 0).mean() * 100, その年の平均の中央=acc.loc[acc['mean'] < 0, 'now'].median()),
                   dict(条件='前年までの前向き記録がプラス', 件数=int((acc['mean'] > 0).sum()), その年プラスの割合=(acc.loc[acc['mean'] > 0, 'now'] > 0).mean() * 100, その年の平均の中央=acc.loc[acc['mean'] > 0, 'now'].median())])
c2 = np.corrcoef(acc['mean'], acc['now'])[0, 1]
J.to_pickle(W + '/S15cand.pkl'); DR.to_pickle(W + '/S15drop.pkl'); pd.to_pickle(dict(P1=P1, P2=P2, c=c, c2=c2), W + '/S15persist.pkl')
pd.set_option('display.width', 280); pd.set_option('display.max_colwidth', 50)
print(J.drop(columns=['年ごとの乖離幅']).round(1).to_string(index=False))
print(DR.round(1).to_string(index=False)); print(P1.round(1).to_string(index=False), '相関', round(c, 3)); print(P2.round(1).to_string(index=False), '相関', round(c2, 3))
