# 「避ける」候補の使い方の比較：除外（その区分では入らない）／ロット半分（その区分では0.5枚）／条件なし（常に1枚）
#   対象：S10（F6＋F7の指標）と S9（SQ・祝日・月末月初の印）で残した「避ける」候補
#   乖離幅と決済は、選ぶ期間の「1枚あたり平均」（重み付き：Σw×損益 ÷ Σw）で選ぶ。最悪の1回（w×損益）−1,000円以上・15件以上（重みの合計）
#   確かめる期間：年あたりの損益合計、1枚あたり平均、最大DD（w×損益の累計）、合計÷最大DD
import sys, numpy as np, pandas as pd
from s9cal import schemes, nbr_mean, maxdd, PERM, SEGS, WORST, MINSEL, SP, CB, P, flags
from s10scr import load, make_bins, LATE
W = '/home/claude/work'
NY = {'S1 前半→後半': 4.77, 'S2 22-23→24-26': 2.77, 'WF後半': 3.77, 'WF全期間': 4.77, 'WF直近3年': 4.77}
def evaluate(Y, en, wt, w, tmin=0):
    XP = np.array(sorted(en.x.unique())); fam = {}; out = []
    for j, x in enumerate(XP):
        idx = np.nonzero((~en.long.values) & (wt > 0) & np.isclose(en.x.values, x) & np.isin(en.kind.values, SEGS[w]))[0]; idx = idx[np.argsort(en.m.values[idx])]
        G = np.asarray(Y[idx], dtype=np.float32) / 100 * P; ppt = (P / en.px.values[idx]).astype(np.float32)
        fam[j] = dict(yr=en.yr.values[idx], N=G - SP * ppt[:, None], w=wt[idx].astype(np.float32))
    Js = sorted(fam)
    for scn, splits in schemes():
        res = {'単点': [[], []], '周辺': [[], []]}
        for selfn, tstfn, ty in splits:
            Mn = np.full((len(Js), 1944), np.nan, np.float32); Wst = np.full((len(Js), 1944), np.nan, np.float32); cnt = np.zeros(len(Js))
            for q, j in enumerate(Js):
                s = selfn(fam[j]['yr']); ws = fam[j]['w'][s]; cnt[q] = ws.sum()
                if cnt[q] >= MINSEL: WN = fam[j]['N'][s] * ws[:, None]; Mn[q] = WN.sum(0) / ws.sum(); Wst[q] = WN.min(0)
            if not (cnt >= MINSEL).any(): continue
            SM = nbr_mean(Mn[:, PERM].reshape(len(Js), 12, 18, 9)).reshape(len(Js), 1944); SMc = np.full_like(SM, np.nan); SMc[:, PERM] = SM
            okw = Wst >= WORST
            for meth, score in (('単点', Mn), ('周辺', SMc)):
                sc = np.where(np.isnan(Mn), -np.inf, score); sc2 = np.where(okw, sc, -np.inf); use = sc2 if np.isfinite(sc2).any() else sc
                q, e = np.unravel_index(int(np.argmax(use)), use.shape); j = Js[q]; t = tstfn(fam[j]['yr']) & (fam[j]['yr'] >= tmin)
                res[meth][0] += list(fam[j]['N'][t, e] * fam[j]['w'][t]); res[meth][1] += list(fam[j]['w'][t])
        nyr = NY[scn] if tmin == 0 else 2.77
        for meth in ('単点', '周辺'):
            v = np.array(res[meth][0]); ww = np.array(res[meth][1]); dd = maxdd(v) if len(v) else np.nan
            out.append(dict(窓=w, 評価=scn, 選び方=meth, 件数=len(v), 年あたり合計=v.sum() / nyr, 一枚あたり平均=v.sum() / ww.sum() if len(v) else np.nan, 最大DD=dd,
                            合計割る最大DD=v.sum() / dd if len(v) and dd > 0 else np.nan, 半分の割合=float((ww < 1).mean()) if len(v) else np.nan))
    return out
if __name__ == '__main__':
    G = pd.read_pickle(W + '/S10sum.pkl'); A = G[G['残す'] & (G['使い方'] == '避ける')][['定義', '向き', '窓', '指標', '区分', '後半のみ']].drop_duplicates()
    S9 = pd.read_pickle(W + '/S9cal.pkl'); k = ['定義', '向き', '印', '使い方', '窓', '選び方']
    g = S9.groupby(k).agg(p=('平均', lambda v: (v > 0).sum()), c=('平均', 'median'), n=('年件数', 'median')).reset_index()
    b = g[g['印'] == '条件なし'][['定義', '向き', '窓', '選び方', 'c']].rename(columns={'c': 'b'}); g = g.merge(b, on=['定義', '向き', '窓', '選び方'])
    C9 = g[(g.p >= 3) & (g.c >= 20) & (g.n >= 10) & (g.c - g.b >= 20) & (g['使い方'] == '避ける')][['定義', '向き', '窓', '印']].drop_duplicates()
    C9 = C9.rename(columns={'印': '指標'}); C9['区分'] = '印あり'; C9['後半のみ'] = False
    A = pd.concat([A, C9], ignore_index=True)
    lab, side = sys.argv[1], sys.argv[2]
    d = {('現行', '順張り'): W + '/T', ('先物基準', '順張り'): W + '/F6W/T6', ('現行', '逆張り'): W + '/R', ('先物基準', '逆張り'): W + '/F6W/R6'}[(lab, side)]
    A = A[(A['定義'] == lab) & (A['向き'] == side)]
    Y, en, MN, F = load(d); evt = pd.read_pickle(d + '/evt.pkl'); en['px'] = en.ent.values if 'ent' in en else evt.B.values[en.ev.values]
    ok = ~en.long.values; yr = en.yr.values
    ba = make_bins(F.drop(columns=list(LATE)), ok & (yr <= 2021)); bl = make_bins(F[list(LATE)], ok & (yr == 2023))
    FL = flags(evt).iloc[en.ev.values].reset_index(drop=True)
    rows = []; one = np.ones(len(en))
    for w in SEGS:
        for r in evaluate(Y, en, one, w): r.update(定義=lab, 向き=side, 指標='条件なし', 区分='', 使い方='条件なし', 後半のみ=False); rows.append(r)
        for r in evaluate(Y, en, one, w, 2024): r.update(定義=lab, 向き=side, 指標='条件なし', 区分='', 使い方='条件なし', 後半のみ=True); rows.append(r)
    for n_, z in enumerate(A.itertuples()):
        late = bool(z.後半のみ)
        if z.区分 == '印あり': m = FL[z.指標].values.astype(bool)
        else: m = (bl if late else ba)[(z.指標, z.区分)]
        base = ~np.isnan(F[z.指標].values) if late else np.ones(len(en), bool)
        for use, wt in (('除外', np.where(m, 0.0, 1.0)), ('ロット半分', np.where(m, 0.5, 1.0))):
            wt = np.where(base, wt, 0.0)
            for r in evaluate(Y, en, wt, z.窓, 2024 if late else 0): r.update(定義=lab, 向き=side, 指標=z.指標, 区分=z.区分, 使い方=use, 後半のみ=late); rows.append(r)
        if n_ % 20 == 0: print(lab, side, n_, len(A), flush=True)
    pd.DataFrame(rows).to_pickle(W + '/S11avoid_%s_%s.pkl' % (lab, side))
