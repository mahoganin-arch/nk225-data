# 共通：中間データ読み込み・候補群の条件マスク再現
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/work/01/code'); from common6 import *
W = '/home/claude/work'
SEGS = {'D>N': ['D>N'], 'N>D': ['N>D'], '両方の窓': ['D>N', 'N>D']}
TBL = {0: '5-8時', 1: '9-11時', 2: '12-15時', 3: '16-18時', 4: '19-22時', 5: '23-4時'}
CBI = {(round(a, 3), round(b, 3), int(c)): i for i, (a, b, c) in enumerate(CB)}
def setup(side):
    d = W + ('/R' if side == '逆張り' else '/T'); Y, en, F = load(d)
    hr = F['時'].values; F2 = F.drop(columns=['時']).copy()
    F2['時間帯'] = np.select([(hr >= 5) & (hr <= 8), (hr >= 9) & (hr <= 11), (hr >= 12) & (hr <= 15), (hr >= 16) & (hr <= 18), (hr >= 19) & (hr <= 22)], [0, 1, 2, 3, 4], 5).astype(np.float32)
    return Y, en, F, F2
def b3lab(k, v):
    ok = ~np.isnan(v); u = np.unique(v[ok])
    if len(u) <= 6: return {(TBL[int(x)] if k == '時間帯' else ('月火水木金土日'[int(x)] if k == '曜日' else '%g' % x)): v == x for x in u}
    q = np.nanquantile(v, [1 / 3, 2 / 3]); b = np.searchsorted(q, v, side='right'); return {lab: ok & (b == i) for i, lab in enumerate(['低', '中', '高'])}
class Masker:
    """乖離幅ごとに、候補群（窓・条件）のエントリー行番号を返す"""
    def __init__(s, Y, en, F, F2): s.Y, s.en, s.F, s.F2 = Y, en, F, F2; s.cache = {}
    def xinfo(s, x):
        x = round(float(x), 4)
        if x not in s.cache:
            idx = np.nonzero((~s.en.long.values) & np.isclose(s.en.x.values, x))[0]
            s.cache[x] = dict(idx=idx, kind=s.en.kind.values[idx], half=s.en.half.values[idx], yr=s.en.yr.values[idx], ev=s.en.ev.values[idx], f1=s.F.iloc[idx], f2=s.F2.iloc[idx], c1={}, c2={})
        return s.cache[x]
    def rows(s, x, win, i1, l1, i2, l2):
        c = s.xinfo(x); mk = np.isin(c['kind'], SEGS[win])
        if not isinstance(i2, str) or i2 == '':
            if i1 not in c['c1']: c['c1'][i1] = dict(bins_for(c['f1'][i1].values.astype(float), None))
            lab = ('=' + l1[1:]) if l1.startswith('値') else l1
            mk = mk & c['c1'][i1][lab]
        else:
            for k, lab in ((i1, l1), (i2, l2)):
                if k not in c['c2']: c['c2'][k] = b3lab(k, c['f2'][k].values.astype(float))
                mk = mk & c['c2'][k][lab]
        return np.nonzero(mk)[0]
def readfam(side, sel):
    import glob
    pat = '/home/claude/work/z/04*/候補群全件_%s.csv.gz' if side == '逆張り' else '/home/claude/work/z/07*/順張り候補群全件_%s.csv.gz'
    d = pd.read_csv(glob.glob(pat % sel)[0], dtype={'区分1': str, '区分2': str, '指標2': str}, keep_default_na=False)
    if side == '順張り': d = d.rename(columns={'損切り位置(基準への戻り割合)': '利確', '利確幅(乖離幅の倍率)': '損切り'})
    XP = np.array([.03, .04, .05, .06, .075, .09, .1, .11, .125, .14, .15, .175, .2, .225, .25, .275, .3, .35, .4, .45, .5, .6, .7, .8, .9, 1.0, 1.2, 1.5])
    d['乖離幅%'] = XP[np.abs(d['乖離幅%'].values[:, None] - XP[None]).argmin(1)]  # CSVは小数2桁に丸められているため格子へ戻す
    return d
def perm_map(en, seed):
    """偶然との比較用：窓の種類ごとにイベントを入れ替え、全乖離幅で同じ対応を使う。
    エントリー（イベントe, 乖離幅x）には、入れ替え先イベントの同じ乖離幅のエントリー（無ければ最も近い小さい幅、次に大きい幅）の指標を割り当てる"""
    n = len(en); mp = np.arange(n)
    if seed == 0: return mp
    ok = ~en.long.values; XPu = np.array(sorted(en.x.unique())); xi = np.searchsorted(XPu, en.x.values - 1e-9)
    evs = np.unique(en.ev.values[ok]); eix = {e: i for i, e in enumerate(evs)}
    tab = np.full((len(evs), len(XPu)), -1, np.int64)
    r = np.nonzero(ok)[0]; tab[[eix[e] for e in en.ev.values[r]], xi[r]] = r
    ff = tab.copy()
    for j in range(1, len(XPu)): ff[:, j] = np.where(ff[:, j] >= 0, ff[:, j], ff[:, j - 1])
    for j in range(len(XPu) - 2, -1, -1): ff[:, j] = np.where(ff[:, j] >= 0, ff[:, j], ff[:, j + 1])
    kind_ev = pd.Series(en.kind.values[r], index=en.ev.values[r]).groupby(level=0).first().reindex(evs).values
    rng = np.random.default_rng(seed); pi = np.arange(len(evs))
    for k in np.unique(kind_ev):
        g = np.nonzero(kind_ev == k)[0]; pi[g] = rng.permutation(g)
    tgt = ff[pi[[eix[e] for e in en.ev.values[r]]], xi[r]]; mp[r] = tgt
    return mp
