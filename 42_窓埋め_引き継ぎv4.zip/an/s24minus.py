# 前向きでマイナスの候補を外す（まろ、2026-10-13）
#   前の付け方の順位に「前向き記録（2022〜t−1年）の合計がプラス」を加える。前向き記録がまだない候補（後半のみの指標で2024年の時点）は残す
#   外して空いた枠は、前の付け方の次の順位の候補で埋める（新しい付け方は元から合計プラスが条件）
#   今の採用候補は、前向き記録（2022〜2026/10/8）の合計がプラスのもの。外したものは「記録だけ」として別表
import sys
src = open('/home/claude/work/08/an/s22union.py').read(); exec(src[:src.index('PR = []')])
rank_old0 = rank_old
def fwd_ok(t, end_incl=False):
    past = WF[(WF['年'] <= t) if end_incl else (WF['年'] < t)]
    return past.groupby(['id', '窓の種類'])['損益'].sum()
def rank_old(t, end_incl=False):
    o = rank_old0(t); fs = fwd_ok(t, end_incl)
    return {k: [i for i in v if fs.get((i, k[0]), 1.0) > 0] for k, v in o.items()}
PR = []
for dn, dirs in (('両方のみ', ('両方',)), ('両方＋方向別', ('両方', '買いのみ', '売りのみ')), ('売りのみ', ('売りのみ',)), ('買いのみ', ('買いのみ',)), ('両方＋売りのみ', ('両方', '売りのみ'))):
    for N in (3, 5):
        for pol, pn in (('A1', '先着1本'), ('C1', '同じ向き2本'), ('D1', '両建て＋2本目')):
            H = simulate_u(N, pol, dirs).sort_values('手じまう時刻'); r = stats(H['損益'].values, 3)
            r.update(候補の集まり=dn, 上位N本=N, 方針=pn, 最悪の1窓=H.groupby('セッション')['損益'].sum().min(), 使った候補数=H['id'].nunique(),
                     買い合計=H.loc[H['向き'] == 1, '損益'].sum(), 売り合計=H.loc[H['向き'] == -1, '損益'].sum())
            for y, g in H.groupby('確かめる年'): r['%d年' % y] = g['損益'].sum()
            PR.append(r)
PR = pd.DataFrame(PR); PR.to_pickle(W + '/S24port.pkl')
old = rank_old(2026, True); rf = rank_rf(2026, end_incl=True); rows = []
U = union_list(old, rf, 5, ('両方', '買いのみ', '売りのみ'))
for (kind, side, dname), lst in U.items():
    for p, (i, both, ro, rn) in enumerate(lst, 1):
        z = C.loc[i]; v = WF[(WF['id'] == i) & (WF['窓の種類'] == kind)].sort_values('手じまう時刻'); s = stats(v['損益'].values, None)
        pk = PK[(PK['id'] == i) & (PK['評価'] == SCN) & (PK['選び方'] == METH) & (PK['t'] == 2026)]
        yr = v.groupby('年')['損益'].sum()
        cond = '条件なし' if z['指標'] == '条件なし' else (('「%s」のときだけ入る' if z['使い方'] == '入る' else '「%s」のときは入らない') % z['名前'])
        r = dict(上位N本=5, 窓の種類=kind, 向き=side, 売買=dname, 優先順位=p, 候補=str(z['名前']).replace('=-0', '=0'), 使い方=z['使い方'], 条件=cond, 定義=z['定義'], 候補の窓=z['窓'], テーマ=z['テーマ'],
                 両方に入る=both, 前の付け方の順位=ro if ro < 99 else np.nan, 新しい付け方の順位=rn if rn < 99 else np.nan,
                 今のルール=rule_text(side, pk['乖離幅'].iloc[0], tuple(pk['決済'].iloc[0])) if len(pk) else '', id=i)
        r.update({'前向き:' + k: x for k, x in s.items()}); r['プラスの年'] = int((yr > 0).sum()); r['年の数'] = len(yr)
        for y in range(2022, 2027): r['%d年' % y] = yr.get(y, np.nan)
        rows.append(r)
U = pd.DataFrame(rows); U.to_pickle(W + '/S24list.pkl')
O22 = pd.read_pickle(W + '/S22list.pkl'); key = lambda d: set(zip(d['id'], d['窓の種類']))
OUTL = O22[[k not in key(U) for k in zip(O22['id'], O22['窓の種類'])]]; NEWL = U[[k not in key(O22) for k in zip(U['id'], U['窓の種類'])]]
OUTL.to_pickle(W + '/S24out.pkl')
pd.set_option('display.width', 280); pd.set_option('display.max_colwidth', 30)
print('採用', len(U), '外した', len(OUTL), '入れ替わりで入った', len(NEWL), ' 前向きマイナスの残り', (U['前向き:合計'] <= 0).sum())
print(U.groupby(['窓の種類', '向き', '売買']).size().to_string())
print(NEWL[['窓の種類', '向き', '売買', '優先順位', '候補', '使い方', '前の付け方の順位', '前向き:件数', '前向き:PF', '前向き:合計', '前向き:最大DD', 'プラスの年']].round(2).to_string(index=False))
P22 = pd.read_pickle(W + '/S22port.pkl')
m = PR.merge(P22[['候補の集まり', '上位N本', '方針', '合計', '合計割る最大DD']], on=['候補の集まり', '上位N本', '方針'], suffixes=('', '_前'))
print(m[['候補の集まり', '上位N本', '方針', '件数', '勝率', 'PF', '合計', '最大DD', '合計割る最大DD', '合計_前', '合計割る最大DD_前', '買い合計', '売り合計', '2024年', '2025年', '2026年']].round(1).to_string(index=False))
