# 昼の窓：条件（指標・暦）のふるいと評価。夜・朝の窓と同じ手順・同じ基準
#   ふるい：両方＝前半(〜2021)と後半(2022〜)の上乗せの向きが同じ・後半|t|≥1・該当率3%以上（S10）／買いのみ・売りのみ＝後半|t|≥1、入るは該当率2%以上（S19）
#   1時間足の出来高の指標は 2023年で区切り、2024年〜でふるう（|t|≥1.5）・2024年〜で評価
#   評価：5つの評価の形、単点・周辺、13pt控除
#   使い方: python s35lunchscr.py <A_R|A_T|B_R|B_T>
import sys, numpy as np, pandas as pd
from s9cal import schemes, nbr_mean, maxdd, PERM, WORST, MINSEL, SP, CB, P, flags
from s10scr import make_bins, uplift, LATE
W = '/home/claude/work'; key = sys.argv[1]; d = W + '/LU/' + key
NY = {'S1 前半→後半': 4.77, 'S2 22-23→24-26': 2.77, 'WF後半': 3.77, 'WF全期間': 4.77, 'WF直近3年': 4.77}
Y = np.load(d + '/Y.npy', mmap_mode='r'); en = pd.read_pickle(d + '/en.pkl'); ev = pd.read_pickle(d + '/evt.pkl')
en = en.join(ev[['kind', 'long', 't0']], on='ev'); en['yr'] = en.t0.dt.year
F = pd.concat([pd.read_pickle(d + '/F6.pkl').drop(columns=['時']), pd.read_pickle(d + '/F7.pkl')], axis=1)
FL = flags(ev).iloc[en.ev.values].reset_index(drop=True).astype(float); F = pd.concat([F.reset_index(drop=True), FL], axis=1)
side = '逆張り' if key.endswith('R') else '順張り'
ok = np.ones(len(en), bool); yr = en.yr.values; buy = (en.d.values > 0) if side == '逆張り' else (en.d.values < 0)
N_ = np.zeros(len(en), np.float32)
for a in range(0, len(en), 5000): N_[a:a + 5000] = np.asarray(Y[a:a + 5000], np.float32).mean(1) / 100 * P
MN = N_ - SP * P / en.ent.values
XP = np.array(sorted(en.x.unique())); KIND = {'昼': ['L']}
ba = make_bins(F.drop(columns=list(LATE)), ok & (yr <= 2021)); bl = make_bins(F[list(LATE)], ok & (yr == 2023))
rows = []
for bins, late in ((ba, False), (bl, True)):
    keys = list(bins); Bm = np.array([bins[k] for k in keys])
    for dname, dm in (('両方', np.ones(len(en), bool)), ('買いのみ', buy), ('売りのみ', ~buy)):
        okd = ok & dm
        if late: tA, dA = uplift(Bm, MN, en, okd, yr == 2023, ['L'], XP); tB, dB = uplift(Bm, MN, en, okd, yr >= 2024, ['L'], XP)
        else: tA, dA = uplift(Bm, MN, en, okd, yr <= 2021, ['L'], XP); tB, dB = uplift(Bm, MN, en, okd, yr >= 2022, ['L'], XP)
        cov = Bm[:, okd & (yr >= 2022)].mean(1); thr = 1.5 if late else 1.0
        for i, k in enumerate(keys):
            if not np.isfinite(tB[i]): continue
            if dname == '両方': p = (np.sign(dA[i]) == np.sign(dB[i])) and abs(tB[i]) >= thr and cov[i] >= .03
            else: p = abs(tB[i]) >= thr and not (dB[i] > 0 and cov[i] < .02)
            if p: rows.append(dict(売買=dname, 指標=k[0], 区分=k[1], 後半のみ=late, 使い方='入る' if dB[i] > 0 else '避ける', 後半t=tB[i], 後半上乗せ=dB[i], 前半上乗せ=dA[i], 該当率=cov[i]))
S = pd.DataFrame(rows); print(key, 'ふるいを通った', S.groupby('売買').size().to_dict(), flush=True)
CACHE = {}
def fam_all():
    if not CACHE:
        for j, x in enumerate(XP):
            idx = np.nonzero(np.isclose(en.x.values, x))[0]; idx = idx[np.argsort(en.m.values[idx])]
            CACHE[j] = dict(idx=idx, yr=yr[idx], N=np.asarray(Y[idx], dtype=np.float32) / 100 * P - (SP * P / en.ent.values[idx]).astype(np.float32)[:, None])
    return CACHE
def evaluate(mask, tmin=0):
    base = fam_all(); fam = {j: dict(yr=b['yr'][mask[b['idx']]], N=b['N'][mask[b['idx']]]) for j, b in base.items()}
    Js = sorted(fam); out = []
    for scn, splits in schemes():
        res = {'単点': [], '周辺': []}; pk = {'単点': [], '周辺': []}
        for selfn, tstfn, ty in splits:
            Mn = np.full((len(Js), 1944), np.nan, np.float32); Wst = np.full((len(Js), 1944), np.nan, np.float32); cnt = np.zeros(len(Js), int)
            for q, j in enumerate(Js):
                s_ = selfn(fam[j]['yr']); cnt[q] = s_.sum()
                if cnt[q] >= MINSEL: Ns = fam[j]['N'][s_]; Mn[q] = Ns.mean(0); Wst[q] = Ns.min(0)
            if not (cnt >= MINSEL).any(): continue
            SM = nbr_mean(Mn[:, PERM].reshape(len(Js), 12, 18, 9)).reshape(len(Js), 1944); SMc = np.full_like(SM, np.nan); SMc[:, PERM] = SM
            okw = Wst >= WORST
            for meth, score in (('単点', Mn), ('周辺', SMc)):
                sc = np.where(np.isnan(Mn), -np.inf, score); sc2 = np.where(okw, sc, -np.inf); use = sc2 if np.isfinite(sc2).any() else sc
                q, e = np.unravel_index(int(np.argmax(use)), use.shape); j = Js[q]; t = tstfn(fam[j]['yr']) & (fam[j]['yr'] >= tmin)
                res[meth] += list(fam[j]['N'][t, e]); pk[meth].append('%g%%%s' % (XP[j], CB[e]))
        nyr = NY[scn] if tmin == 0 else 2.77
        for meth in ('単点', '周辺'):
            v = np.array(res[meth]); out.append(dict(評価=scn, 選び方=meth, 件数=len(v), 年件数=len(v) / nyr, 平均=v.mean() if len(v) else np.nan, 最大DD=maxdd(v) if len(v) else np.nan, 選ばれた点=' '.join(pk[meth])))
    return out
out = []
for dname, dm in (('両方', np.ones(len(en), bool)), ('買いのみ', buy), ('売りのみ', ~buy)):
    for r in evaluate(dm): r.update(売買=dname, 指標='条件なし', 区分='', 使い方='入る', 後半のみ=False); out.append(r)
    for r in evaluate(dm, 2024): r.update(売買=dname, 指標='条件なし(2024-)', 区分='', 使い方='入る', 後半のみ=True); out.append(r)
for n_, z in enumerate(S.itertuples()):
    dm = np.ones(len(en), bool) if z.売買 == '両方' else (buy if z.売買 == '買いのみ' else ~buy)
    m = (bl if z.後半のみ else ba)[(z.指標, z.区分)]; m = (m if z.使い方 == '入る' else ~m) & dm
    if z.後半のみ: m = m & ~np.isnan(F[z.指標].values)
    for r in evaluate(m, 2024 if z.後半のみ else 0): r.update(売買=z.売買, 指標=z.指標, 区分=z.区分, 使い方=z.使い方, 後半のみ=z.後半のみ); out.append(r)
    if n_ % 100 == 0: print(key, n_, len(S), flush=True)
R = pd.DataFrame(out); R['データ'] = key; R.to_pickle(W + '/S35eval_%s.pkl' % key); S.assign(データ=key).to_pickle(W + '/S35scr_%s.pkl' % key)
print('done', key, len(R))
