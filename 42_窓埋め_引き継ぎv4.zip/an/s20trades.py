# 買い売り両方の候補（S12、逆張りC・Bを除く）と、買い・売り別の候補（S16＝S19、ゆるい基準で残したもの）を1つの一覧にまとめ、方向別の候補のトレード一覧を作る
#   方向別の候補：id は 100000＋連番。売買＝買いのみ／売りのみ（両方の候補は「両方」）
#   トレード一覧：WF全期間・WF後半 × 単点・周辺 の年ごとのルール（S19eval の選ばれた点）。s13trades.py と同じ形
import re, sys, numpy as np, pandas as pd
from collections import Counter
sys.path.insert(0, '/home/claude/work/01/code'); import ld
from common6 import CB, P, jname
from s10scr import load, make_bins, LATE
W = '/home/claude/work'; SP = 13.0
DS = {('現行', '順張り'): W + '/T', ('先物基準', '順張り'): W + '/F6W/T6', ('現行', '逆張り'): W + '/R', ('先物基準', '逆張り'): W + '/F6W/R6'}
SEGS = {'D>N': ['D>N'], 'N>D': ['N>D'], '両方の窓': ['D>N', 'N>D']}
CBI = {(round(a, 3), round(b, 3), int(c)): i for i, (a, b, c) in enumerate(CB)}
YEARS = {'WF全期間': [2022, 2023, 2024, 2025, 2026], 'WF後半': [2023, 2024, 2025, 2026]}
TFJ = {'5m': '5分', '15m': '15分', '60m': '60分', '4h': '4時間', 'D': '日足', 'W': '週足'}
def nm(x):
    if x == '条件なし': return '条件なし'
    b_, _, tf = x.rpartition('_')
    if tf in TFJ and (not b_.isascii() or b_.isupper()): return TFJ[tf] + b_
    return jname(x)
src = open('/home/claude/work/08/an/s12group.py').read(); exec(src[src.index('def theme(name):'):src.index('def xmode(strs):')])
def parse(s): return [(float(x), (float(a), float(b), int(c))) for x, a, b, c in re.findall(r'([\d.]+)%\(([\d.]+), ([\d.]+), (\d+)\)', s)]
# ---- 方向別の候補一覧
G = pd.read_pickle(W + '/S19sum.pkl'); O19 = pd.concat([pd.read_pickle(W + '/S19eval_%s_%s.pkl' % k) for k in DS], ignore_index=True)
key = ['定義', '向き', '売買', '窓', '指標', '区分', '使い方', '後半のみ']
K = G[G['残す']].groupby(key).agg(選び方数=('選び方', 'size'), 中央=('中央', 'mean'), 最小=('最小', 'min'), プラス数=('プラス数', 'min'), 年件数=('年件数', 'mean'), 最大DD=('最大DD', 'mean'),
                                  前半の向き=('前半の向き', 'first')).reset_index()
K['id'] = 100000 + np.arange(len(K)); K['出所'] = 'S16方向別'; K['名前'] = [nm(x) for x in K['指標']]
K['名前'] = [n if i == '条件なし' else '%s %s' % (n, k_) for n, i, k_ in zip(K['名前'], K['指標'], K['区分'])]
K['テーマ'] = [('基本' if n == '条件なし' else theme(n)) for n in K['名前']]
O19k = O19.merge(K[key + ['id']], on=key)
K['x'] = K['id'].map(O19k.groupby('id')['選ばれた点'].apply(lambda v: Counter([p[0] for s in v for p in parse(s)]).most_common(1)[0][0]))
C0 = pd.read_pickle(W + '/S12cands.pkl'); C0 = C0[~C0['出所'].str.startswith('S6逆張り')].copy(); C0['売買'] = '両方'
CA = pd.concat([C0, K], ignore_index=True)
CA.to_pickle(W + '/S20cands.pkl'); print('候補', len(CA), CA.groupby(['向き', '売買']).size().to_dict(), flush=True)
# ---- 方向別の候補のトレード一覧
c5 = ld.bars(W + '/data/c5.csv', until='2026-10-09'); c1 = ld.bars(W + '/data/c1.csv', until='2026-10-09')
cx = pd.concat([c5[c5.m + 5 <= c1.m.iloc[0]], c1], ignore_index=True); cm = cx.m.values.astype(float)
blen = np.r_[np.diff(cm), 1.0]; blen = np.where(blen > 5, np.where(cm >= c1.m.iloc[0], 1.0, 5.0), blen)
REC = []; PKS = []
for key_d, d in DS.items():
    Y, en, MN, F = load(d); evt = pd.read_pickle(d + '/evt.pkl'); ok = ~en.long.values; yr = en.yr.values
    px = en.ent.values if 'ent' in en else evt.B.values[en.ev.values]
    EX = np.load(d + '/EX.npy', mmap_mode='r'); gk = np.load(d + '/gk.npy'); ep = np.load(d + '/entp.npy'); sess = evt.i.values[en.ev.values]
    ba = make_bins(F.drop(columns=list(LATE)), ok & (yr <= 2021)); bl = make_bins(F[list(LATE)], ok & (yr == 2023)); ba[('条件なし', '')] = np.ones(len(en), bool)
    side = key_d[1]; buy = (en.d.values < 0) if side == '順張り' else (en.d.values > 0); reo = en.reo.values
    sub = K[(K['定義'] == key_d[0]) & (K['向き'] == side)]
    for z in sub.itertuples():
        m = (bl if z.後半のみ else ba)[(z.指標, z.区分)]
        if z.使い方 == '避ける': m = ~m
        m = m & (buy if z.売買 == '買いのみ' else ~buy)
        if z.後半のみ: m = m & ~np.isnan(F[z.指標].values)
        base = ok & m & np.isin(en.kind.values, SEGS[z.窓])
        o = O19k[O19k['id'] == z.id]
        for scn in YEARS:
            for meth in ('単点', '周辺'):
                oo = o[(o['評価'] == scn) & (o['選び方'] == meth)]
                if len(oo) != 1: continue
                pk = parse(oo['選ばれた点'].iloc[0]); yy = [y for y in YEARS[scn] if not (z.後半のみ and y < 2024)]
                if len(pk) != len(yy): continue
                for t, (x, ex) in zip(yy, pk):
                    PKS.append(dict(id=z.id, 評価=scn, 選び方=meth, t=t, 乖離幅=x, 決済=ex))
                    e = CBI[(round(ex[0], 3), round(ex[1], 3), int(ex[2]))]
                    rows = np.nonzero(base & np.isclose(en.x.values, x) & (yr <= t))[0]
                    if len(rows) == 0: continue
                    pnl = np.asarray(Y[rows, e], float) / 100 * P - SP * P / px[rows]
                    code = np.asarray(EX[rows, e]).astype(int); g = gk[rows] + code // 4; typ = code % 4; g0 = gk[rows]
                    pos = en.d.values[rows] if side == '逆張り' else -en.d.values[rows]
                    t_in = cm[g0] if key_d[0] == '先物基準' else np.where(reo[rows], cm[g0] + blen[g0], cm[g0] + 0.5 * blen[g0])
                    t_out = np.where(typ == 2, cm[g], np.where(typ == 3, cm[g] + blen[g], cm[g] + 0.9 * blen[g]))
                    REC.append(pd.DataFrame(dict(id=z.id, 評価=scn, 選び方=meth, t=t, row=rows, セッション=sess[rows], 窓の種類=en.kind.values[rows], 年=yr[rows],
                                                 入る時刻=t_in, 入る値段=ep[rows], 向き=pos, 手じまう時刻=t_out, 損益=pnl, 円per値=P / px[rows])))
    print(key_d, len(REC), flush=True)
T = pd.concat(REC, ignore_index=True); T['手じまう値段'] = T['入る値段'] + T['向き'] * (T['損益'] + SP * T['円per値']) / T['円per値']
T0 = pd.read_pickle(W + '/S13trades.pkl'); TA = pd.concat([T0, T], ignore_index=True); TA.to_pickle(W + '/S20trades.pkl')
PA = pd.concat([pd.read_pickle(W + '/S13picks.pkl'), pd.DataFrame(PKS)], ignore_index=True); PA.to_pickle(W + '/S20picks.pkl')
print('トレード', TA.shape)
# 確認：年ごとのトレードの平均が S19 の評価と一致するか（WF全期間・周辺、抜き取り40件）
chk = T[(T['評価'] == 'WF全期間') & (T['選び方'] == '周辺') & (T['年'] == T['t'])].groupby('id')['損益'].agg(['mean', 'size'])
oo = O19k[(O19k['評価'] == 'WF全期間') & (O19k['選び方'] == '周辺')].set_index('id')
bad = 0; n = 0
for i in K['id'].sample(40, random_state=1):
    if i in chk.index and i in oo.index: n += 1; bad += abs(oo.loc[i, '平均'] - chk.loc[i, 'mean']) > 0.05 or oo.loc[i, '件数'] != chk.loc[i, 'size']
print('評価との一致の確認', n, '件中 不一致', bad)
