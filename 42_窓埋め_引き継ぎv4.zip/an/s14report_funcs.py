# s14report.py の成績計算・ルールの説明（他のスクリプトから使う）
import numpy as np
def stats(v, yrs=None):
    v = np.asarray(v, float)
    if len(v) == 0: return {}
    w = v[v > 0]; l = v[v <= 0]; c = np.cumsum(v); dd = float((np.maximum.accumulate(np.r_[0, c])[1:] - c).max())
    run = mx = 0
    for x in v:
        run = run + 1 if x <= 0 else 0; mx = max(mx, run)
    r = dict(件数=len(v), 勝率=len(w) / len(v) * 100, PF=w.sum() / -l.sum() if l.sum() < 0 else np.inf, 平均=v.mean(), 平均利益=w.mean() if len(w) else np.nan, 平均損失=l.mean() if len(l) else np.nan,
             損益比=(w.mean() / -l.mean()) if len(w) and len(l) and l.mean() < 0 else np.nan, 合計=v.sum(), 最大DD=dd, 合計割る最大DD=v.sum() / dd if dd > 0 else np.nan, 最悪の1回=v.min(), 最良の1回=v.max(), 最大連敗=mx)
    if yrs is not None: r['年あたり件数'] = len(v) / yrs
    return r
def rule_text(side, x, ex):
    fr, sk, tm = ex; t = '引けまで' if tm == 0 else '%d分' % tm
    if side == '逆張り':
        return '乖離%g%%で逆張り／利確：窓までの距離の%d%%%s／損切り：%s／時間：%s' % (x, round(fr * 100), '（基準を越えた位置）' if fr > 1 else '', 'なし' if sk == 0 else '乖離幅×%g' % sk, t)
    return '乖離%g%%で順張り／損切り：基準へ%d%%戻った位置%s／利確：%s／時間：%s' % (x, round(fr * 100), '（基準を越えた位置）' if fr > 1 else '', 'なし' if sk == 0 else '乖離幅×%g' % sk, t)
def cond_text(z):
    if z['使い方'] == '基本': return '条件なし'
    if z['出所'] == 'S6印': return ('%sのときだけ入る' if z['使い方'] == '入る' else '%sのときは入らない') % z['名前']
    return ('「%s」のときだけ入る' if z['使い方'] == '入る' else '「%s」のときは入らない') % z['名前']
