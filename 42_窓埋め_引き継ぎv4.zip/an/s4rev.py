# ②逆張り（独立したストラテジーとして）：C 投票方式 と B 2指標の組み合わせ
#   すべてコスト13pt控除後。選ぶ期間のデータだけで「区分の境目」「指標の選択」「乖離幅と決済」を決め、確かめる期間で評価
#   区分の境目：特徴ごとに、選ぶ期間の全エントリー（窓・乖離幅をまとめて）で決める（実装しやすい1つの値）
#   ふるい分けの尺度：1エントリーの「1,944決済の平均損益（控除後）」。条件なし（同じ窓・乖離幅・期間）との差＝上乗せ、乖離幅ごとのtの中央値
#   C：中央t ≥ 1.5 の区分（入る）と ≤ −1.5（避ける）から系統ごとに代表、各最大5つ。点数＝入る該当数−避ける該当数
#   B：|中央t| ≥ 1.0、該当率5〜60%の区分どうし（違う系統）の組み合わせから、中央tの上位20組（入る）
#   確かめ方：(1) 尺度での上乗せ（乖離幅ごと→中央値、プラスの幅の割合）(2) 選ぶ期間で周辺の方法で乖離幅と決済を1つ選び、確かめる期間の損益
import sys, time, numpy as np, pandas as pd
from lib import *
SP = 13.0; WORST = -1000; MINSEL = 15
Y, en, F, F2 = setup('逆張り'); ev = pd.read_pickle(W + '/R/evt.pkl'); Bp = ev.B.values[en.ev.values]
ok = ~en.long.values; yr = en.yr.values; XP = np.array(sorted(en.x.unique()))
cost = SP * P / Bp
try: MN = np.load(W + '/R/mnet.npy')
except FileNotFoundError:
    MN = np.zeros(len(en), np.float32)
    for a in range(0, len(en), 5000): MN[a:a + 5000] = np.asarray(Y[a:a + 5000], np.float32).mean(1) / 100 * P
    np.save(W + '/R/mnet.npy', MN)
MN = MN - cost
FEATS = [c for c in F.columns if c != '時']
FAM = {c: (c.rpartition('_')[0] if c.rpartition('_')[2] in ('5m', '15m', '60m', '4h', 'D', 'W') else c) for c in FEATS}
SPLITS = [('前半→後半', lambda y: y <= 2021, lambda y: y >= 2022), ('2017-21→2022-23', lambda y: y <= 2021, lambda y: (y >= 2022) & (y <= 2023)),
          ('2017-23→2024-26', lambda y: y <= 2023, lambda y: y >= 2024), ('2022-23→2024-26', lambda y: (y >= 2022) & (y <= 2023), lambda y: y >= 2024)]
FRi = np.arange(12); SKi = np.r_[1:18, 0]; TMi = np.r_[1:9, 0]
PERM = np.array([(f * 18 + s) * 9 + t for f in FRi for s in SKi for t in TMi])
def nbr_mean(A):
    V = np.nan_to_num(A); C = (~np.isnan(A)).astype(np.float32); Vs = np.zeros_like(V); Cs = np.zeros_like(C)
    pad = [(1, 1)] * 4; Vp = np.pad(V, pad); Cp = np.pad(C, pad); J, a, b, c = A.shape
    for d0 in range(3):
        for d1 in range(3):
            for d2 in range(3):
                for d3 in range(3):
                    Vs += Vp[d0:d0 + J, d1:d1 + a, d2:d2 + b, d3:d3 + c]; Cs += Cp[d0:d0 + J, d1:d1 + a, d2:d2 + b, d3:d3 + c]
    return np.where(C > 0, Vs / np.maximum(Cs, 1), np.nan)
def make_bins(sel):
    """選ぶ期間で境目を決めた区分：名前 → bool（全エントリー）"""
    out = {}
    for c in FEATS:
        v = F[c].values.astype(float); fin = ~np.isnan(v); u = np.unique(v[fin & sel])
        if len(u) <= 6:
            for x in u: out[(c, '=%g' % x)] = v == x
            continue
        vt = v[sel & fin]
        if len(vt) < 100: continue
        q3 = np.quantile(vt, [1 / 3, 2 / 3]); b3 = np.searchsorted(q3, v, side='right')
        for i, lab in enumerate(['3分割:低', '3分割:中', '3分割:高']): out[(c, lab)] = fin & (b3 == i)
        q5 = np.quantile(vt, [.2, .4, .6, .8]); b5 = np.searchsorted(q5, v, side='right')
        for i in range(5): out[(c, '5分割:%d' % (i + 1))] = fin & (b5 == i)
        lo, hi = np.quantile(vt, [.1, .9]); out[(c, '下位10%')] = fin & (v <= lo); out[(c, '上位10%')] = fin & (v >= hi)
    return out
def uplift_t(Bm, period, w):
    """区分（行列 Bm: nb×N）ごとに、乖離幅ごとの上乗せ t と差 → 中央値。Bm はブール (nb, N)"""
    kinds = SEGS[w]; T = []; D = []
    for x in XP:
        e = ok & period & np.isin(en.kind.values, kinds) & np.isclose(en.x.values, x)
        if e.sum() < 60: continue
        m = MN[e].astype(np.float64); Be = Bm[:, e].astype(np.float64); n = Be.sum(1); s = Be @ m; q = Be @ (m * m)
        mu = np.where(n > 0, s / np.maximum(n, 1), np.nan); var = np.where(n > 1, (q - n * mu ** 2) / np.maximum(n - 1, 1), np.nan)
        t = (mu - m.mean()) / np.sqrt(var / np.maximum(n, 1)); t[n < 20] = np.nan; d = mu - m.mean(); d[n < 20] = np.nan
        T.append(t); D.append(d)
    T = np.array(T); D = np.array(D); good = (~np.isnan(T)).sum(0) >= 8
    return np.where(good, np.nanmedian(T, 0), np.nan), np.where(good, np.nanmedian(D, 0), np.nan), np.where(good, (D > 0).sum(0) / np.maximum((~np.isnan(D)).sum(0), 1) * 100, np.nan)
def pick_exit(mask, sel, tst, w, xmin=0.0):
    """mask の付いたエントリーで、選ぶ期間に周辺の方法で (乖離幅, 決済) を選び、確かめる期間の損益を返す"""
    kinds = SEGS[w]; js = []; Mn = []; Wst = []; mats = {}
    for j, x in enumerate(XP):
        if x < xmin - 1e-9: continue
        r = np.nonzero(ok & mask & np.isin(en.kind.values, kinds) & np.isclose(en.x.values, x))[0]
        if len(r) == 0: continue
        r = r[np.argsort(en.m.values[r])]; s = sel[r]; js.append(j); mats[j] = r
        if s.sum() >= MINSEL:
            N = np.asarray(Y[r[s]], np.float32) / 100 * P - cost[r[s]][:, None]; Mn.append(N.mean(0)); Wst.append(N.min(0))
        else: Mn.append(np.full(1944, np.nan, np.float32)); Wst.append(np.full(1944, np.nan, np.float32))
    if not js: return None
    Mn = np.array(Mn); Wst = np.array(Wst)
    if np.isnan(Mn).all(): return None
    SM = nbr_mean(Mn[:, PERM].reshape(len(js), 12, 18, 9)).reshape(len(js), 1944); SMc = np.full_like(SM, np.nan); SMc[:, PERM] = SM
    sc = np.where(np.isnan(Mn), -np.inf, SMc); sc2 = np.where(Wst >= WORST, sc, -np.inf); use = sc2 if np.isfinite(sc2).any() else sc
    q, e = np.unravel_index(int(np.argmax(use)), use.shape); j = js[q]; r = mats[j]; t = tst[r]
    v = np.asarray(Y[r[t], e], float) / 100 * P - cost[r[t]]
    return dict(乖離幅=XP[j], 決済=CB[e], 選ぶ期間件数=int(sel[r].sum()), 選ぶ期間平均=float(Mn[q, e]), 確かめる件数=int(t.sum()), 確かめる平均=v.mean() if len(v) else np.nan,
                確かめる合計=v.sum(), 確かめる最悪=v.min() if len(v) else np.nan, rows=r[t], ex=e)
CROWS = []; BROWS = []; CPICK = []; TRADES = []; MASKS = {}   # 候補のエントリー行の印（重なりでまとめるときに使う）
t0 = time.time()
for sname, sf, tf in SPLITS:
    sel = sf(yr); tst = tf(yr); bins = make_bins(sel & ok); keys = list(bins); Bm = np.array([bins[k] for k in keys])
    cov = Bm[:, ok & sel].mean(1)
    for w in SEGS:
        tS, dS, _ = uplift_t(Bm, sel, w); tT, dT, pT = uplift_t(Bm, tst, w)
        # ---- C 投票方式
        df = pd.DataFrame({'key': keys, 't': tS}).dropna(); df['fam'] = [FAM[k[0]] for k in df.key]
        pos = df[df.t >= 1.5].sort_values('t', ascending=False).drop_duplicates('fam').head(5)
        neg = df[df.t <= -1.5].sort_values('t').drop_duplicates('fam').head(5)
        score = np.zeros(len(en), int)
        for k in pos.key: score += bins[k]
        for k in neg.key: score -= bins[k]
        kinds = np.isin(en.kind.values, SEGS[w])
        for lab, msk in (('条件なし', np.ones(len(en), bool)), ('点数≥1', score >= 1), ('点数≥2', score >= 2), ('点数=0', score == 0), ('点数≤−1', score <= -1)):
            # 尺度での上乗せ（乖離幅ごと）
            ups = []; nn = 0
            for x in XP:
                e = ok & tst & kinds & np.isclose(en.x.values, x)
                if e.sum() < 60 or (e & msk).sum() < 20: continue
                ups.append(MN[e & msk].mean() - MN[e].mean()); nn += (e & msk).sum()
            r = pick_exit(msk, sel, tst, w)
            rec = {'分け方': sname, '窓': w, '区分': lab, '入る指標': ' / '.join('%s=%s' % (jname(k[0]), k[1]) for k in pos.key), '避ける指標': ' / '.join('%s=%s' % (jname(k[0]), k[1]) for k in neg.key),
                   '確かめる:上乗せ中央(全決済平均)': np.median(ups) if ups else np.nan, '確かめる:上乗せプラスの幅%': (np.array(ups) > 0).mean() * 100 if ups else np.nan, '確かめる:のべ件数': nn}
            if r: rec.update({k: v for k, v in r.items() if k not in ('rows', 'ex')}); TRADES.append(('C', sname, w, lab, r['rows'], r['ex']))
            MASKS[('C', sname, w, lab)] = np.packbits(msk)
            CROWS.append(rec)
        # ---- B 2指標
        cand = np.nonzero((np.abs(np.nan_to_num(tS)) >= 1.0) & (cov >= .05) & (cov <= .6))[0]
        fams = np.array([FAM[keys[i][0]] for i in cand]); Bc = Bm[cand]
        # 乖離幅ごとに組み合わせのtを計算
        TT = []
        for x in XP:
            e = ok & sel & kinds & np.isclose(en.x.values, x)
            if e.sum() < 60: continue
            m = MN[e].astype(np.float64); Be = Bc[:, e].astype(np.float64)
            n = Be @ Be.T; s = (Be * m) @ Be.T; q = (Be * m * m) @ Be.T
            mu = s / np.maximum(n, 1); var = (q - n * mu ** 2) / np.maximum(n - 1, 1); t = (mu - m.mean()) / np.sqrt(np.maximum(var, 1e-9) / np.maximum(n, 1)); t[n < 20] = np.nan
            TT.append(t.astype(np.float32))
        TT = np.array(TT); good = (~np.isnan(TT)).sum(0) >= 8
        with np.errstate(all='ignore'): med = np.where(good, np.nanmedian(TT, 0), np.nan)
        iu = np.triu_indices(len(cand), 1); mv = med[iu]; diff = fams[iu[0]] != fams[iu[1]]; mv = np.where(diff, mv, np.nan)
        order = np.argsort(-np.nan_to_num(mv, nan=-1e9))[:20]
        for rank, o in enumerate(order):
            a, b = cand[iu[0][o]], cand[iu[1][o]]; msk = bins[keys[a]] & bins[keys[b]]
            ups = []
            for x in XP:
                e = ok & tst & kinds & np.isclose(en.x.values, x)
                if e.sum() < 60 or (e & msk).sum() < 20: continue
                ups.append(MN[e & msk].mean() - MN[e].mean())
            rec = {'分け方': sname, '窓': w, '順位': rank + 1, '指標1': '%s=%s' % (jname(keys[a][0]), keys[a][1]), '指標2': '%s=%s' % (jname(keys[b][0]), keys[b][1]),
                   '選ぶ期間:中央t': mv[o], '選ぶ期間:単独t(1)': tS[a], '選ぶ期間:単独t(2)': tS[b],
                   '確かめる:上乗せ中央(全決済平均)': np.median(ups) if ups else np.nan, '確かめる:上乗せプラスの幅%': (np.array(ups) > 0).mean() * 100 if ups else np.nan, '確かめる:幅の数': len(ups)}
            if rank < 20:
                r = pick_exit(msk, sel, tst, w)
                if r: rec.update({k: v for k, v in r.items() if k not in ('rows', 'ex')}); TRADES.append(('B', sname, w, rec['指標1'] + ' & ' + rec['指標2'], r['rows'], r['ex']))
            BROWS.append(rec); MASKS[('B', sname, w, rec['指標1'] + ' & ' + rec['指標2'])] = np.packbits(msk)
        print(sname, w, '入る', len(pos), '避ける', len(neg), '組み合わせ候補', len(cand), round(time.time() - t0), 's', flush=True)
pd.DataFrame(CROWS).to_pickle(W + '/S4C.pkl'); pd.DataFrame(BROWS).to_pickle(W + '/S4B.pkl')
pd.to_pickle(TRADES, W + '/S4trades.pkl'); pd.to_pickle(MASKS, W + '/S4masks.pkl')
