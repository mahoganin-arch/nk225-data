# 昼の窓：条件なしの評価（夜・朝の窓と同じ5つの評価の形、単点・周辺、13pt 控除）
#   買い売り両方／買いのみ／売りのみ × 定義A（CFD型）・B（先物型）× 逆張り・順張り
import sys, numpy as np, pandas as pd
from s9cal import schemes, nbr_mean, maxdd, PERM, WORST, MINSEL, SP, CB, P
W = '/home/claude/work'
NY = {'S1 前半→後半': 4.77, 'S2 22-23→24-26': 2.77, 'WF後半': 3.77, 'WF全期間': 4.77, 'WF直近3年': 4.77}
def ld(d):
    Y = np.load(d + '/Y.npy', mmap_mode='r'); en = pd.read_pickle(d + '/en.pkl'); ev = pd.read_pickle(d + '/evt.pkl')
    en = en.join(ev[['kind', 'long', 't0']], on='ev'); en['yr'] = en.t0.dt.year; return Y, en
def evaluate(Y, en, mask):
    XP = np.array(sorted(en.x.unique())); fam = {}
    for j, x in enumerate(XP):
        idx = np.nonzero(mask & np.isclose(en.x.values, x))[0]; idx = idx[np.argsort(en.m.values[idx])]
        N = np.asarray(Y[idx], dtype=np.float32) / 100 * P - (SP * P / en.ent.values[idx]).astype(np.float32)[:, None]
        fam[j] = dict(yr=en.yr.values[idx], N=N)
    Js = sorted(fam); out = []
    for scn, splits in schemes():
        res = {'単点': [], '周辺': []}; pk = {'単点': [], '周辺': []}; yrs = {'単点': [], '周辺': []}
        for selfn, tstfn, ty in splits:
            Mn = np.full((len(Js), 1944), np.nan, np.float32); Wst = np.full((len(Js), 1944), np.nan, np.float32); cnt = np.zeros(len(Js), int)
            for q, j in enumerate(Js):
                s_ = selfn(fam[j]['yr']); cnt[q] = s_.sum()
                if cnt[q] >= MINSEL: Ns = fam[j]['N'][s_]; Mn[q] = Ns.mean(0); Wst[q] = Ns.min(0)
            if not (cnt >= MINSEL).any(): continue
            SM = nbr_mean(Mn[:, PERM].reshape(len(Js), 12, 18, 9)).reshape(len(Js), 1944); SMc = np.full_like(SM, np.nan); SMc[:, PERM] = SM
            okw = Wst >= WORST
            for meth, score in (('単点', Mn), ('周辺', SMc)):
                sc = np.where(np.isnan(Mn), -np.inf, score); sc2 = np.where(okw, sc, -np.inf); use = sc2 if np.isfinite(sc2).any() else sc
                q, e = np.unravel_index(int(np.argmax(use)), use.shape); j = Js[q]; t = tstfn(fam[j]['yr'])
                res[meth] += list(fam[j]['N'][t, e]); yrs[meth] += list(fam[j]['yr'][t]); pk[meth].append('%g%%%s' % (XP[j], CB[e]))
        for meth in ('単点', '周辺'):
            v = np.array(res[meth]); y = np.array(yrs[meth])
            r = dict(評価=scn, 選び方=meth, 件数=len(v), 年件数=len(v) / NY[scn], 平均=v.mean() if len(v) else np.nan, 勝率=(v > 0).mean() * 100 if len(v) else np.nan,
                     最大DD=maxdd(v) if len(v) else np.nan, 選ばれた点=' '.join(pk[meth]))
            for yy in range(2022, 2027): r['%d年' % yy] = v[y == yy].sum() if len(v) else np.nan
            out.append(r)
    return out
if __name__ == '__main__':
    rows = []
    for key, nm in (('A_R', ('CFD型', '逆張り')), ('A_T', ('CFD型', '順張り')), ('B_R', ('先物型', '逆張り')), ('B_T', ('先物型', '順張り'))):
        Y, en = ld(W + '/LU/' + key)
        buy = (en.d.values > 0) if nm[1] == '逆張り' else (en.d.values < 0)
        for dname, m in (('両方', np.ones(len(en), bool)), ('買いのみ', buy), ('売りのみ', ~buy)):
            for r in evaluate(Y, en, m): r.update(定義=nm[0], 向き=nm[1], 売買=dname); rows.append(r)
            print(nm, dname, flush=True)
    R = pd.DataFrame(rows); R.to_pickle(W + '/S34lunch.pkl')
    G = R.groupby(['定義', '向き', '売買', '選び方']).agg(プラス数=('平均', lambda v: int((v > 0).sum())), 中央=('平均', 'median'), 最小=('平均', 'min'), 年件数=('年件数', 'median')).reset_index()
    pd.set_option('display.width', 250); print(G.round(1).to_string(index=False))
    print(R[R['評価'] == 'WF全期間'][['定義', '向き', '売買', '選び方', '件数', '平均', '勝率', '最大DD', '2022年', '2023年', '2024年', '2025年', '2026年', '選ばれた点']].round(1).to_string(index=False))
