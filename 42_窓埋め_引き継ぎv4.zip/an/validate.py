# 軸の効き目：前半で優位（前半で選んだ）候補群が、後半でどうだったか
import sys, numpy as np, pandas as pd
from lib import W
from scipy.stats import spearmanr
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 30)
AX = {'連続した幅の最大数': [0, 2, 4, 7, 11, 99], '通過した幅の数': [0, 4, 9, 14, 19, 99], '基準を満たす決済数': None, '前半プラス決済%': [-1, 50, 70, 80, 90, 101],
      '前半最悪': [-1e9, -2000, -1200, -1000, -800, -600, 0], '前半平均': None, '前半件数': None, '前半上乗せ': None, '前半勝率': None, '乖離幅%': [0, .1, .2, .3, .5, .8, 2]}
def table(T, col, edges):
    v = T[col]
    b = pd.qcut(v, 5, duplicates='drop') if edges is None else pd.cut(v, edges)
    g = T.groupby(b, observed=True).agg(件数=('後半平均', 'size'), 後半平均=('後半平均', 'mean'), 後半プラス率=('後半平均', lambda s: (s > 0).mean() * 100), 後半20円以上率=('後半平均', lambda s: (s >= 20).mean() * 100), 後半上乗せ=('後半上乗せ', 'mean'))
    return g.round(1)
rows = []
for side in sys.argv[1:]:
    T = pd.read_pickle(W + ('/R' if side == '逆張り' else '/T') + '/table.pkl'); A = T[T['選び方'] == '前半で優位']
    print('=' * 20, side)
    print(A.groupby('最悪の上限', sort=False).agg(件数=('後半平均', 'size'), 後半平均=('後半平均', 'mean'), 後半プラス率=('後半平均', lambda s: (s > 0).mean() * 100), 前半平均=('前半平均', 'mean'), 前半最悪の中央値=('前半最悪', 'median')).round(1))
    for k in ('なし', '-1000'):
        S = A[A['最悪の上限'] == k]; print('\n--- 最悪の上限', k, '件数', len(S))
        for col, ed in AX.items():
            r = spearmanr(S[col], S['後半平均'], nan_policy='omit')[0]; r2 = spearmanr(S[col], S['後半上乗せ'], nan_policy='omit')[0]
            rows.append((side, k, col, round(r, 3), round(r2, 3)))
            print('\n[%s] 順位相関 後半平均 %.3f / 後半上乗せ %.3f' % (col, r, r2)); print(table(S, col, ed).to_string())
        for col in ('種類', '窓'): print(S.groupby(col).agg(件数=('後半平均', 'size'), 後半平均=('後半平均', 'mean'), 後半プラス率=('後半平均', lambda s: (s > 0).mean() * 100)).round(1).to_string())
pd.DataFrame(rows, columns=['方向', '最悪の上限', '軸', '順位相関_後半平均', '順位相関_後半上乗せ']).to_csv(W + '/an/val_summary.csv', index=False)
