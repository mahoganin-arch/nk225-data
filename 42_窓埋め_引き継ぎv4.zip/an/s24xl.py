# 両方＋方向別の採用候補（案3）と前向き検証の Excel
import pandas as pd, numpy as np
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
W = '/home/claude/work'; OUT = W + '/08/results/S18_採用候補_前向きマイナス除外.xlsx'
PR = pd.read_pickle(W + '/S24port.pkl'); U = pd.read_pickle(W + '/S24list.pkl')
cols = ['窓の種類', '向き', '売買', '優先順位', '候補', '使い方', '条件', '定義', '候補の窓', 'テーマ', '両方に入る', '前の付け方の順位', '新しい付け方の順位', '今のルール',
        '前向き:件数', '前向き:勝率', '前向き:PF', '前向き:平均', '前向き:合計', '前向き:最大DD', '前向き:合計割る最大DD', '前向き:最悪の1回', '前向き:最大連敗', 'プラスの年', '年の数',
        '2022年', '2023年', '2024年', '2025年', '2026年', 'id']
desc = [
 ['この表について', 'S17（両方＋方向別の採用候補、案3）から、前向き（2022年〜）の合計がマイナスの候補を外したもの。まろ、2026-10-13：前向きでマイナスの候補を外す'],
 ['外し方', '前の付け方の順位に「前向き記録（2022〜t−1年）の合計がプラス」を加えた（新しい付け方は元から合計プラスが条件）。外して空いた枠は前の付け方の次の順位で埋めた。前向き記録がまだない候補（後半のみの指標の2024年時点）は残した'],
 ['今の採用候補', '前向き記録は2022年〜2026/10/8。S17の115本から12本を外し、10本が入れ替わりで入って113本。外した12本は「外した候補（記録だけ）」のシート'],
 ['前向き検証', '2024〜26年。各年の外す判断もその年より前のデータだけで行う。S17の結果（合計_前、合計割る最大DD_前）と並べた'],
 ['結果', '上位5本では改善（両方のみ 同じ向き2本：合計÷最大DD 3.9→8.5、両方＋売りのみ 同じ向き2本：4.9→8.0、合計51,104→60,234円）。上位3本ではやや悪化（両方のみ 5.1→4.2など）。買いのみは引き続きすべてマイナス'],
 ['金額', '1枚＝68,800円換算、13pt控除後、円'],
 ['シート', '採用候補（上位5本）／外した候補（記録だけ）／前向き検証'],
]
with pd.ExcelWriter(OUT, engine='openpyxl') as w:
    pd.DataFrame(desc, columns=['項目', '内容']).to_excel(w, sheet_name='説明', index=False)
    U[cols].round(2).to_excel(w, sheet_name='採用候補（上位5本）', index=False)
    pd.read_pickle(W + '/S24out.pkl')[cols].round(2).to_excel(w, sheet_name='外した候補（記録だけ）', index=False)
    PR.round(2).to_excel(w, sheet_name='前向き検証', index=False)
wb = load_workbook(OUT); red = Font(name='Arial', size=10, color='C00000')
for ws in wb:
    for row in ws.iter_rows():
        for c in row:
            c.font = Font(name='Arial', size=10, bold=c.row == 1)
            if c.row > 1 and isinstance(c.value, (int, float)) and not isinstance(c.value, bool) and c.value < 0: c.font = red
    for c in ws[1]: c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.freeze_panes = 'F2' if ws.title.startswith('採用') else 'A2'
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = 11
ws = wb['説明']; ws.column_dimensions['A'].width = 14; ws.column_dimensions['B'].width = 150
for c in ws['B']: c.alignment = Alignment(wrap_text=True, vertical='top')
for n in ('採用候補（上位5本）', '外した候補（記録だけ）'):
    ws = wb[n]; ws.column_dimensions['E'].width = 28; ws.column_dimensions['G'].width = 36; ws.column_dimensions['N'].width = 70
wb.save(OUT); print(OUT)
