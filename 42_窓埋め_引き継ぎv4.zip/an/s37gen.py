# Pine Script v6（ステップ2：条件なしの骨組み）を作る。売買する63本のルール（2026年）を埋め込む
import ast, pandas as pd
W = '/home/claude/work'
A = pd.read_pickle(W + '/S28inv.pkl'); S = A[A['扱い'] == '売買する'].sort_values('全体の優先順位')
WEAK = ((S['窓の種類'] == 'N>D') & (S['定義'] == '先物基準') & (S['向き'] == '逆張り') & S['名前'].str.contains('4時間60本高安の位置 5分割:3')) | ((S['窓の種類'] == 'D>N') & (S['定義'] == '先物基準') & (S['向き'] == '逆張り') & S['名前'].str.contains('4時間BBσ位置 3分割:中'))
assert WEAK.sum() == 2
S = S[~WEAK].reset_index(drop=True)
def arr(vals, fmt): return ', '.join(fmt(v) for v in vals)
kind = arr(S['窓の種類'], lambda v: '0' if v == 'D>N' else '1')
dfn = arr(S['定義'], lambda v: '0' if v == '現行' else '1')
side = arr(S['向き'], lambda v: '0' if v == '逆張り' else '1')
sell = arr(S['売買'], lambda v: 'true' if v == '売りのみ' else 'false')
xs = arr(S['乖離幅(%)'], lambda v: '%g' % v)
R = [ast.literal_eval(r) for r in S['決済(FR,SK,TM)']]
fr = arr([r[0] for r in R], lambda v: '%g' % v); sk = arr([r[1] for r in R], lambda v: '%g' % v); tm = arr([r[2] for r in R], lambda v: '%d' % v)
nm = arr(S['名前'], lambda v: '"%s"' % str(v).replace('"', ''))
pine = r'''//@version=6
// 窓埋め 売買用（61本）ステップ2：窓・基準・エントリー・手じまい・同じ向き2本・アラートの骨組み
// 61本の条件（指標）を入れた版。Python の「条件あり」と照合する
// チャート：FOREX.com JP225 の1分足。先物：OSE:NK225M1!（リアルタイム）
indicator("窓埋め61本 v0.8 条件あり", overlay = true, max_labels_count = 200, max_lines_count = 200)

FUT      = input.symbol("OSE:NK225M1!", "先物")
APPROACH = input.float(0.8, "接近アラート（乖離幅に対する割合）", minval = 0.1, maxval = 0.99, step = 0.05)
SHOW_TBL = input.bool(true, "表を出す")
NO_NIGHT = input.string("", "夜間が休みの日（YYYY-MM-DD をカンマ区切り。その日の夕方の D>N の窓を使わない）")
NO_DAY   = input.string("", "日中が休みの日（YYYY-MM-DD をカンマ区切り。その日の朝の N>D の窓を使わない）")
MAXPOS   = 2

// ---------- 候補（優先順位の順。kind 0=D>N 1=N>D、def 0=現行 1=先物基準、side 0=逆張り 1=順張り）
var array<int>    cKind = array.from(__KIND__)
var array<int>    cDef  = array.from(__DEF__)
var array<int>    cSide = array.from(__SIDE__)
var array<bool>   cSell = array.from(__SELL__)
var array<float>  cX    = array.from(__X__)
var array<float>  cFR   = array.from(__FR__)
var array<float>  cSK   = array.from(__SK__)
var array<int>    cTM   = array.from(__TM__)
var array<string> cName = array.from(__NAME__)
N = array.size(cX)


// ---------- 時刻（日本時間）
hh = hour(time, "Asia/Tokyo")
mi = minute(time, "Asia/Tokyo")
hm = hh * 100 + mi
dstr = str.format_time(time, "yyyy-MM-dd", "Asia/Tokyo")
dow = dayofweek(time, "Asia/Tokyo")
reo = not na(time[1]) and (time - time[1]) > 30 * 60000      // CFD が30分より長く止まったあとの最初の足

// ---------- CFD の値段：チャートが平均足などでも、ふつうのローソク足の値段を使う
[o_, h_, l_, c_] = request.security(ticker.standard(syminfo.tickerid), timeframe.period, [open, high, low, close])
// ---------- 先物（同じ1分足）。gaps_on：先物の足がない時刻は na
[fO, fH, fL, fC] = request.security(FUT, timeframe.period, [open, high, low, close], gaps = barmerge.gaps_on)
fLast = request.security(FUT, timeframe.period, close)        // 直近の先物終値（休み中も前の値）

// ---------- 窓の状態
var int   wKind  = -1        // 0=D>N 1=N>D
var bool  wOn    = false     // 窓が動いている
var bool  wLong  = false     // 休日をはさむ窓（使わない）
var float B      = na        // CFD の基準（現行）
var float Bf     = na        // 先物の基準（先物基準）
var bool  fOpen  = false     // 先物が寄った
var float fGap   = na        // 先物の寄りの窓（%、符号つき）
var bool  wClosed = false    // 寄り後に CFD が基準に戻った（現行は以後入らない）
var bool  fBack  = false     // 寄り後に先物が基準に戻った（先物基準は以後入らない）
var int   gapSign = 0
var bool  anyExit = false    // この窓で手じまいが出た
var bool  apUp   = false
var bool  apDn   = false
var int   tStart = na
// 候補ごとの状態：0=まだ 1=入った/済み（その窓で1回だけ）
var array<int> cDone = array.new<int>(0)
if barstate.isfirst
    cDone := array.new<int>(N, 0)
// ポジション
var array<int>   pId  = array.new<int>(0)
var array<int>   pDir = array.new<int>(0)
var array<float> pE   = array.new<float>(0)
var array<float> pTP  = array.new<float>(0)
var array<float> pSL  = array.new<float>(0)
var array<int>   pTmEnd = array.new<int>(0)    // 時間切れの時刻（ms、0=なし）
var array<int>   pBar = array.new<int>(0)
// 先物基準の「次の足の始値で入る」予約
var array<int>   qId  = array.new<int>(0)
var array<int>   qDir = array.new<int>(0)
var array<float> qFd  = array.new<float>(0)

// ======================= 指標（Python と同じ定義） =======================
// 5分・15分・60分足：TradingView の足（Python の 5分足からの集計と同じ区切り）。確定した足の値だけを使う（[1] と lookahead_on）
// 4時間・日足・週足：60分足から Python と同じ区切りで作る（4時間＝UTC 0時基準、日足＝日本時間7時区切り、週足＝月曜7時区切り）
SYM = ticker.standard(syminfo.tickerid)
f_ich(simple int a) =>
    (ta.highest(high, a) + ta.lowest(low, a)) / 2
f_nat15() =>
    hc = (open + high + low + close) / 4
    var float ho = na
    ho := na(ho) ? (open + close) / 2 : (ho + hc[1]) / 2
    col = math.sign(hc - ho)
    var float run = 0.0
    run := na(col[1]) or col != col[1] ? col : run + col
    [dp, dm, adx] = ta.dmi(14, 14)
    di = dp - dm
    ma20 = ta.sma(close, 20)
    sd20 = ta.stdev(close, 20, false)
    bw = 4 * sd20 / ma20 * 100
    float bwr = na
    if not na(bw)
        lt = 0
        eq = 0
        cnt = 0
        for k = 0 to 119
            v = bw[k]
            if not na(v)
                cnt += 1
                if v < bw
                    lt += 1
                else if v == bw
                    eq += 1
        bwr := cnt >= 60 ? (lt + (eq + 1) / 2.0) / cnt : na
    chi = (close - close[26]) / close * 100
    rng = ta.highest(high, 14) - ta.lowest(low, 14)
    st = rng == 0 ? na : (close - ta.lowest(low, 14)) / rng * 100 - 50
    tk = f_ich(9)
    kj = f_ich(26)
    i52 = f_ich(52)
    tkkj = (tk + kj) / 2
    sa = tkkj[26]
    sb = i52[26]
    top = math.max(sa, sb)
    bot = math.min(sa, sb)
    cloud = na(sa) or na(sb) ? na : close > top ? 1.0 : close < bot ? -1.0 : 0.0
    ma25 = ta.sma(close, 25)
    ma75 = ta.sma(close, 75)
    r_ma25 = (close - ma25) / ma25 * 100
    r_ma75 = (close - ma75) / ma75 * 100
    ret20 = (close / close[20] - 1) * 100
    [run[1], di[1], bwr[1], chi[1], st[1], adx[1], cloud[1], r_ma25[1], ret20[1], r_ma75[1]]
f_nat60() =>
    ma20 = ta.sma(close, 20)
    slope = (ma20 / ma20[5] - 1) * 100
    tk = f_ich(9)
    kj = f_ich(26)
    i52 = f_ich(52)
    tkkj = (tk + kj) / 2
    sa = tkkj[26]
    sb = i52[26]
    tw = math.sign(sa - sb)
    twf = math.sign(tkkj - i52)
    nej = na(sa) or na(sb) or na(twf) ? na : tw != twf ? 1.0 : 0.0
    macd = (ta.ema(close, 12) - ta.ema(close, 26)) / close * 100
    rsi = ta.rsi(close, 14) - 50
    [slope[1], nej[1], macd[1], rsi[1]]
f_nat5() =>
    ma20 = ta.sma(close, 20)
    slope = (ma20 / ma20[5] - 1) * 100
    [dp, dm, adx] = ta.dmi(14, 14)
    di = dp - dm
    [slope[1], di[1]]
[n15_harun, n15_di, n15_bwr, n15_chi, n15_st, n15_adx, n15_cloud, n15_ma25, n15_ret20, n15_ma75] = request.security(SYM, "15", f_nat15(), lookahead = barmerge.lookahead_on)
[n60_slope, n60_nej, n60_macd, n60_rsi] = request.security(SYM, "60", f_nat60(), lookahead = barmerge.lookahead_on)
[n5_slope, n5_di] = request.security(SYM, "5", f_nat5(), lookahead = barmerge.lookahead_on)

// ---------- 配列の上の計算（最後の要素が今の足）
f_hl(array<float> H, array<float> L, int n) =>
    sz = array.size(H)
    float hi = na
    float lo = na
    if sz >= n
        hi := array.get(H, sz - 1)
        lo := array.get(L, sz - 1)
        for k = sz - n to sz - 1
            hi := math.max(hi, array.get(H, k))
            lo := math.min(lo, array.get(L, k))
    [hi, lo]
f_hlat(array<float> H, array<float> L, int n, int e) =>
    float hi = na
    float lo = na
    if e - n + 1 >= 0
        hi := array.get(H, e)
        lo := array.get(L, e)
        for k = e - n + 1 to e
            hi := math.max(hi, array.get(H, k))
            lo := math.min(lo, array.get(L, k))
    [hi, lo]
f_mean(array<float> C, int n) =>
    sz = array.size(C)
    float r = na
    if sz >= n
        s_ = 0.0
        for k = sz - n to sz - 1
            s_ += array.get(C, k)
        r := s_ / n
    r
f_sd(array<float> C, int n) =>
    sz = array.size(C)
    float r = na
    if sz >= n
        m_ = f_mean(C, n)
        q = 0.0
        for k = sz - n to sz - 1
            q += math.pow(array.get(C, k) - m_, 2)
        r := math.sqrt(q / (n - 1))
    r
f_back(array<float> C, int k) =>
    sz = array.size(C)
    sz > k ? array.get(C, sz - 1 - k) : na
// 一目（配列）：[雲の厚さ, ねじれ前, 基準線乖離]
f_ichA(array<float> H, array<float> L, array<float> C) =>
    sz = array.size(C)
    e = sz - 1
    float thick = na
    float nej = na
    float kij = na
    if sz >= 78
        [h9, l9] = f_hlat(H, L, 9, e - 26)
        [h26, l26] = f_hlat(H, L, 26, e - 26)
        [h52, l52] = f_hlat(H, L, 52, e - 26)
        sa = ((h9 + l9) / 2 + (h26 + l26) / 2) / 2
        sb = (h52 + l52) / 2
        c = array.get(C, e)
        thick := (math.max(sa, sb) - math.min(sa, sb)) / c * 100
        [h9n, l9n] = f_hlat(H, L, 9, e)
        [h26n, l26n] = f_hlat(H, L, 26, e)
        [h52n, l52n] = f_hlat(H, L, 52, e)
        twf = math.sign(((h9n + l9n) / 2 + (h26n + l26n) / 2) / 2 - (h52n + l52n) / 2)
        nej := math.sign(sa - sb) != twf ? 1.0 : 0.0
        kij := (c - (h26n + l26n) / 2) / c * 100
    [thick, nej, kij]
f_stA(array<float> H, array<float> L, array<float> C) =>
    [hi, lo] = f_hl(H, L, 14)
    c = array.get(C, array.size(C) - 1)
    na(hi) or hi == lo ? na : (c - lo) / (hi - lo) * 100 - 50
f_p60A(array<float> H, array<float> L, array<float> C) =>
    [hi, lo] = f_hl(H, L, 60)
    c = array.get(C, array.size(C) - 1)
    na(hi) or hi == lo ? na : (c - lo) / (hi - lo) - 0.5
f_bbA(array<float> C) =>
    c = array.get(C, array.size(C) - 1)
    sd = f_sd(C, 20)
    na(sd) or sd == 0 ? na : (c - f_mean(C, 20)) / sd
f_retA(array<float> C, int k) =>
    p = f_back(C, k)
    c = array.get(C, array.size(C) - 1)
    na(p) ? na : (c / p - 1) * 100
f_trim(array<float> A, int n) =>
    if array.size(A) > n
        array.shift(A)

// ---------- 60分足から 4時間・日足・週足を作る。A＝今のまとまりを確定とみなした値、B＝確定したまとまりだけの値
f_htf() =>
    tmin = time / 60000
    k4 = math.floor(tmin / 240)
    kD = math.floor((tmin + 120) / 1440)
    kW = math.floor((kD + 3) / 7)
    var array<float> H4 = array.new<float>()
    var array<float> L4 = array.new<float>()
    var array<float> C4 = array.new<float>()
    var array<float> HD = array.new<float>()
    var array<float> LD = array.new<float>()
    var array<float> CD = array.new<float>()
    var array<float> CW = array.new<float>()
    var array<float> HW = array.new<float>()
    var array<float> LW = array.new<float>()
    var int ck4 = na
    var int ckD = na
    var int ckW = na
    var float o4 = na
    var float h4 = na
    var float l4 = na
    var float c4 = na
    var float oD = na
    var float hD = na
    var float lD = na
    var float cD = na
    var float oW = na
    var float hW = na
    var float lW = na
    var float cW = na
    // 平均足・ワイルダーの状態（確定したまとまりまで）
    var float ho4 = na
    var float hc4 = na
    var float hoD = na
    var float hcD = na
    var float colD = na
    var float runD = 0.0
    var float hoW = na
    var float hcW = na
    var float atrD = na
    var float pcD = na
    var float spW = na
    var float smW = na
    var float stW = na
    var float phW = na
    var float plW = na
    var float pcW = na
    var int nD = 0
    var int nW = 0
    // 月（確定した日から）
    var int mKey = na
    var float mH = na
    var float mL = na
    var float mC = na
    var float pmH = na
    var float pmL = na
    var float pmC = na
    // B の値（確定したときに計算して保存）
    var float b4_st = na
    var float b4_nej = na
    var float b4_bb = na
    var float b4_th = na
    var float b4_kj = na
    var float b4_hb = na
    var float b4_p60 = na
    var float bD_th = na
    var float bD_run = na
    var float bD_ret5 = na
    var float bD_bb = na
    var float bD_atr = na
    var float bD_h = na
    var float bD_l = na
    var float bW_mx = na
    var float bW_hb = na
    var float bW_chi = na
    var float bW_ret5 = na
    var float bW_di = na
    var float bW_h = na
    var float bW_l = na
    var float bW_c = na
    // ---- 4時間
    if na(ck4) or k4 != ck4
        if not na(ck4)
            array.push(H4, h4), array.push(L4, l4), array.push(C4, c4)
            f_trim(H4, 120), f_trim(L4, 120), f_trim(C4, 120)
            hoN = na(ho4) ? (o4 + c4) / 2 : (ho4 + hc4) / 2
            hcN = (o4 + h4 + l4 + c4) / 4
            ho4 := hoN
            hc4 := hcN
            b4_hb := math.abs(hcN - hoN) / math.max(math.max(h4, hoN, hcN) - math.min(l4, hoN, hcN), 1e-9)
            [th, nj, kjv] = f_ichA(H4, L4, C4)
            b4_th := th
            b4_nej := nj
            b4_kj := kjv
            b4_st := f_stA(H4, L4, C4)
            b4_bb := f_bbA(C4)
            b4_p60 := f_p60A(H4, L4, C4)
        ck4 := k4
        o4 := open
        h4 := high
        l4 := low
        c4 := close
    else
        h4 := math.max(h4, high)
        l4 := math.min(l4, low)
        c4 := close
    // ---- 日足
    if na(ckD) or kD != ckD
        if not na(ckD)
            array.push(HD, hD), array.push(LD, lD), array.push(CD, cD)
            f_trim(HD, 120), f_trim(LD, 120), f_trim(CD, 120)
            hoN = na(hoD) ? (oD + cD) / 2 : (hoD + hcD) / 2
            hcN = (oD + hD + lD + cD) / 4
            colN = math.sign(hcN - hoN)
            runD := na(colD) or colN != colD ? colN : runD + colN
            colD := colN
            hoD := hoN
            hcD := hcN
            tr = na(pcD) ? hD - lD : math.max(hD - lD, math.abs(hD - pcD), math.abs(lD - pcD))
            atrD := na(atrD) ? tr : atrD + (tr - atrD) / 14
            pcD := cD
            nD += 1
            [th, nj, kjv] = f_ichA(HD, LD, CD)
            bD_th := th
            bD_run := runD
            bD_ret5 := f_retA(CD, 5)
            bD_bb := f_bbA(CD)
            bD_atr := nD >= 14 ? atrD / cD * 100 : na
            bD_h := hD
            bD_l := lD
            // 月：日の始まり（日本時間7時）の日付の月
            dm = month(((ckD * 1440) - 120) * 60000, "Asia/Tokyo") + 100 * year(((ckD * 1440) - 120) * 60000, "Asia/Tokyo")
            if na(mKey) or dm != mKey
                pmH := mH
                pmL := mL
                pmC := mC
                mKey := dm
                mH := hD
                mL := lD
                mC := cD
            else
                mH := math.max(mH, hD)
                mL := math.min(mL, lD)
                mC := cD
        ckD := kD
        oD := open
        hD := high
        lD := low
        cD := close
    else
        hD := math.max(hD, high)
        lD := math.min(lD, low)
        cD := close
    // ---- 週足
    if na(ckW) or kW != ckW
        if not na(ckW)
            array.push(HW, hW), array.push(LW, lW), array.push(CW, cW)
            f_trim(HW, 120), f_trim(LW, 120), f_trim(CW, 120)
            hoN = na(hoW) ? (oW + cW) / 2 : (hoW + hcW) / 2
            hcN = (oW + hW + lW + cW) / 4
            hoW := hoN
            hcW := hcN
            bW_hb := math.abs(hcN - hoN) / math.max(math.max(hW, hoN, hcN) - math.min(lW, hoN, hcN), 1e-9)
            if not na(phW)
                up_ = hW - phW
                dn_ = plW - lW
                pdm = up_ > dn_ and up_ > 0 ? up_ : 0.0
                mdm = dn_ > up_ and dn_ > 0 ? dn_ : 0.0
                tr = math.max(hW - lW, math.abs(hW - pcW), math.abs(lW - pcW))
                spW := na(spW) ? pdm : spW + (pdm - spW) / 14
                smW := na(smW) ? mdm : smW + (mdm - smW) / 14
                stW := na(stW) ? tr : stW + (tr - stW) / 14
                nW += 1
            phW := hW
            plW := lW
            pcW := cW
            bW_di := nW >= 14 and stW > 0 ? 100 * (spW - smW) / stW : na
            m13 = f_mean(CW, 13)
            m26 = f_mean(CW, 26)
            bW_mx := na(m26) ? na : (m13 - m26) / m26 * 100
            p26 = f_back(CW, 26)
            bW_chi := na(p26) ? na : (cW - p26) / cW * 100
            bW_ret5 := f_retA(CW, 5)
            bW_h := hW
            bW_l := lW
            bW_c := cW
        ckW := kW
        oW := open
        hW := high
        lW := low
        cW := close
    else
        hW := math.max(hW, high)
        lW := math.min(lW, low)
        cW := close
    // ---- A の値：今のまとまりを一時的に足して計算
    array.push(H4, h4), array.push(L4, l4), array.push(C4, c4)
    [a4_th, a4_nej, a4_kj] = f_ichA(H4, L4, C4)
    a4_st = f_stA(H4, L4, C4)
    a4_bb = f_bbA(C4)
    a4_p60 = f_p60A(H4, L4, C4)
    array.pop(H4), array.pop(L4), array.pop(C4)
    ho4A = na(ho4) ? (o4 + c4) / 2 : (ho4 + hc4) / 2
    hc4A = (o4 + h4 + l4 + c4) / 4
    a4_hb = math.abs(hc4A - ho4A) / math.max(math.max(h4, ho4A, hc4A) - math.min(l4, ho4A, hc4A), 1e-9)
    array.push(HD, hD), array.push(LD, lD), array.push(CD, cD)
    [aD_th, aD_nj, aD_kj] = f_ichA(HD, LD, CD)
    aD_ret5 = f_retA(CD, 5)
    aD_bb = f_bbA(CD)
    array.pop(HD), array.pop(LD), array.pop(CD)
    hoDA = na(hoD) ? (oD + cD) / 2 : (hoD + hcD) / 2
    colA = math.sign((oD + hD + lD + cD) / 4 - hoDA)
    aD_run = na(colD) or colA != colD ? colA : runD + colA
    trA = na(pcD) ? hD - lD : math.max(hD - lD, math.abs(hD - pcD), math.abs(lD - pcD))
    aD_atr = nD >= 13 and not na(atrD) ? (atrD + (trA - atrD) / 14) / cD * 100 : na
    array.push(CW, cW)
    m13A = f_mean(CW, 13)
    m26A = f_mean(CW, 26)
    aW_mx = na(m26A) ? na : (m13A - m26A) / m26A * 100
    p26A = f_back(CW, 26)
    aW_chi = na(p26A) ? na : (cW - p26A) / cW * 100
    aW_ret5 = f_retA(CW, 5)
    array.pop(CW)
    hoWA = na(hoW) ? (oW + cW) / 2 : (hoW + hcW) / 2
    hcWA = (oW + hW + lW + cW) / 4
    aW_hb = math.abs(hcWA - hoWA) / math.max(math.max(hW, hoWA, hcWA) - math.min(lW, hoWA, hcWA), 1e-9)
    float aW_di = na
    if not na(phW) and not na(stW)
        up_ = hW - phW
        dn_ = plW - lW
        pdm = up_ > dn_ and up_ > 0 ? up_ : 0.0
        mdm = dn_ > up_ and dn_ > 0 ? dn_ : 0.0
        tr = math.max(hW - lW, math.abs(hW - pcW), math.abs(lW - pcW))
        sp = spW + (pdm - spW) / 14
        sm = smW + (mdm - smW) / 14
        st_ = stW + (tr - stW) / 14
        aW_di := nW >= 13 and st_ > 0 ? 100 * (sp - sm) / st_ : na
    e4 = (ck4 + 1) * 240 * 60000
    eD = ((ckD + 1) * 1440 - 120) * 60000
    eW = (((ckW + 1) * 7 - 3) * 1440 - 120) * 60000
    // 月：今の日を確定とみなしたとき、その日が新しい月なら、今までの月が「前月」になる
    dmA = month(((ckD * 1440) - 120) * 60000, "Asia/Tokyo") + 100 * year(((ckD * 1440) - 120) * 60000, "Asia/Tokyo")
    aM_h = dmA != mKey ? mH : pmH
    aM_l = dmA != mKey ? mL : pmL
    float e4f = e4
    float eDf = eD
    float eWf = eW
    [e4f[1], a4_st[1], b4_st[1], a4_nej[1], b4_nej[1], a4_bb[1], b4_bb[1], a4_th[1], b4_th[1], a4_kj[1], b4_kj[1], a4_hb[1], b4_hb[1], a4_p60[1], b4_p60[1], eDf[1], aD_th[1], bD_th[1], aD_run[1], bD_run[1], aD_ret5[1], bD_ret5[1], aD_bb[1], bD_bb[1], aD_atr[1], bD_atr[1], hD[1], bD_h[1], lD[1], bD_l[1], eWf[1], aW_mx[1], bW_mx[1], aW_hb[1], bW_hb[1], aW_chi[1], bW_chi[1], aW_ret5[1], bW_ret5[1], aW_di[1], bW_di[1], hW[1], bW_h[1], lW[1], bW_l[1], cW[1], bW_c[1], aM_h[1], pmH[1], aM_l[1], pmL[1]]
[x_e4, a4_st, b4_st, a4_nej, b4_nej, a4_bb, b4_bb, a4_th, b4_th, a4_kj, b4_kj, a4_hb, b4_hb, a4_p60, b4_p60, x_eD, aD_th, bD_th, aD_run, bD_run, aD_ret5, bD_ret5, aD_bb, bD_bb, aD_atr, bD_atr, aD_h, bD_h, aD_l, bD_l, x_eW, aW_mx, bW_mx, aW_hb, bW_hb, aW_chi, bW_chi, aW_ret5, bW_ret5, aW_di, bW_di, aW_h, bW_h, aW_l, bW_l, aW_c, bW_c, aM_h, bM_h, aM_l, bM_l] = request.security(SYM, "60", f_htf(), lookahead = barmerge.lookahead_on)
// 今の時刻で、まとまりが終わっていれば A、まだなら B
u4 = time >= x_e4
uD = time >= x_eD
uW = time >= x_eW
h4_st = u4 ? a4_st : b4_st
h4_nej = u4 ? a4_nej : b4_nej
h4_bb = u4 ? a4_bb : b4_bb
h4_th = u4 ? a4_th : b4_th
h4_kj = u4 ? a4_kj : b4_kj
h4_hb = u4 ? a4_hb : b4_hb
h4_p60 = u4 ? a4_p60 : b4_p60
hD_th = uD ? aD_th : bD_th
hD_run = uD ? aD_run : bD_run
hD_ret5 = uD ? aD_ret5 : bD_ret5
hD_bb = uD ? aD_bb : bD_bb
hD_atr = uD ? aD_atr : bD_atr
hD_h = uD ? aD_h : bD_h
hD_l = uD ? aD_l : bD_l
hW_mx = uW ? aW_mx : bW_mx
hW_hb = uW ? aW_hb : bW_hb
hW_chi = uW ? aW_chi : bW_chi
hW_ret5 = uW ? aW_ret5 : bW_ret5
hW_di = uW ? aW_di : bW_di
hW_h = uW ? aW_h : bW_h
hW_l = uW ? aW_l : bW_l
hW_c = uW ? aW_c : bW_c
hM_h = aM_h
hM_l = aM_l

// ---------- 先物：SQ値（SQ日の 8:45 の始値、11:00 から使う）、日足の出来高比
f_sq() =>
    y = year(time, "Asia/Tokyo")
    m = month(time, "Asia/Tokyo")
    d = dayofmonth(time, "Asia/Tokyo")
    hm_ = hour(time, "Asia/Tokyo") * 100 + minute(time, "Asia/Tokyo")
    fd = dayofweek(timestamp("Asia/Tokyo", y, m, 1, 0, 0), "Asia/Tokyo")
    sf = 1 + (6 - fd + 7) % 7 + 7
    var float last845 = na
    var int last845m = na
    var int doneM = na
    var float sqCur = na
    var float sqPrev = na
    var int sqAv = na
    var float msqCur = na
    var float msqPrev = na
    var int msqAv = na
    ym = y * 100 + m
    bool rec = false
    float v = na
    int av = na
    if hm_ == 845
        last845 := open
        last845m := ym
        if d == sf and doneM != ym
            rec := true
            v := open
            av := time + 135 * 60000
    if not rec and d > sf and doneM != ym and last845m == ym
        rec := true
        v := last845
        av := time
    if rec
        doneM := ym
        sqPrev := sqCur
        sqCur := v
        sqAv := av
        if m == 3 or m == 6 or m == 9 or m == 12
            msqPrev := msqCur
            msqCur := v
            msqAv := av
    float sqAvF = sqAv
    float msqAvF = msqAv
    [sqCur[1], sqPrev[1], sqAvF[1], msqCur[1], msqPrev[1], msqAvF[1]]
[sqCur, sqPrev, sqAv, msqCur, msqPrev, msqAv] = request.security(FUT, "15", f_sq(), lookahead = barmerge.lookahead_on)
SQV = time >= sqAv ? sqCur : sqPrev
MSQV = time >= msqAv ? msqCur : msqPrev
f_vr5() =>
    r = volume / ta.sma(volume[1], 5)
    r[1]
volR5 = request.security(FUT, "D", f_vr5(), lookahead = barmerge.lookahead_on)
fVol = request.security(FUT, timeframe.period, volume, gaps = barmerge.gaps_on)

// ---------- チャートで追うもの：前のセッション（CFD）、窓の連続、日中の1時間ごとの先物出来高
var float sesO = na
var float sesH = na
var float sesL = na
var float pO = na
var float pH = na
var float pL = na
var float pB = na
var float streak = 0.0
var float gPrev = na
var float runW = na
var int lastFutT = na
var array<float> vHr = array.new<float>(0)
var float lateR = na
var float lateW = na
var float hrH = na
var float hrL = na
var int wDateT = na
inSes = (hh * 100 + minute(time, "Asia/Tokyo") >= 845 and hh * 100 + minute(time, "Asia/Tokyo") < 1545) or hh >= 17 or hh < 6
if barstate.isconfirmed and not na(fO)
    newSes = na(lastFutT) or time - lastFutT > 30 * 60000
    if newSes
        // 先物の寄り：この窓の窓の向き（CFD の寄りの始値 − CFD の基準）を記録して、連続を更新
        if not na(B)
            g = math.sign(o_ - B)
            streak := not na(gPrev) and g == gPrev ? streak + g : g
            gPrev := g
        sesO := o_
        sesH := h_
        sesL := l_
        array.clear(vHr)
    else if inSes
        sesH := math.max(sesH, h_)
        sesL := math.min(sesL, l_)
    lastFutT := time
    // 日中の1時間ごとの先物出来高（8:45 から60分ごと、15:45 より前）
    hmx = hh * 100 + minute(time, "Asia/Tokyo")
    if hmx >= 845 and hmx < 1545 and not na(fVol)
        mins = (hh * 60 + minute(time, "Asia/Tokyo")) - (8 * 60 + 45)
        blk = math.floor(mins / 60)
        while array.size(vHr) <= blk
            array.push(vHr, 0.0)
        array.set(vHr, blk, array.get(vHr, blk) + fVol)
        if array.size(vHr) >= 5
            lateR := array.get(vHr, array.size(vHr) - 1) / array.avg(vHr)

// ---------- 候補ごとの指標の値と条件（Python の区分のしきい値。向きのある指標は「窓と同じ向き＝プラス」）
f_sqweek(int ts) =>
    y = year(ts, "Asia/Tokyo")
    m = month(ts, "Asia/Tokyo")
    fd = dayofweek(timestamp("Asia/Tokyo", y, m, 1, 0, 0), "Asia/Tokyo")
    sf = 1 + (6 - fd + 7) % 7 + 7
    sqT = timestamp("Asia/Tokyo", y, m, sf, 12, 0)
    dw = dayofweek(ts, "Asia/Tokyo")
    mon = ts - ((dw + 5) % 7) * 86400000
    dwS = dayofweek(sqT, "Asia/Tokyo")
    monS = sqT - ((dwS + 5) % 7) * 86400000
    not (m == 3 or m == 6 or m == 9 or m == 12) and str.format_time(mon, "yyyyMMdd", "Asia/Tokyo") == str.format_time(monS, "yyyyMMdd", "Asia/Tokyo")
f_val(int i, bool up, float ep) =>
    s = up ? 1.0 : -1.0
    isF = array.get(cDef, i) == 1
    Bx = isF ? Bf : B
    x = array.get(cX, i)
    entp = isF ? ep : B * (1 + s * x / 100)
    float v = na
    switch i
        0 => v := h4_st * s
        1 => v := f_sqweek(wDateT) ? 1.0 : 0.0
        2 => v := n15_harun * s
        3 => v := h4_nej
        4 => v := runW * s
        5 => v := ((s > 0 ? hD_h : hD_l) - entp) / Bx * 100 * s
        6 => v := (SQV - entp) / Bx * 100 * s
        7 => v := ((s > 0 ? hM_h : hM_l) - entp) / Bx * 100 * s
        8 => v := n15_di * s
        9 => v := math.min(entp % 500, 500 - entp % 500) / Bx * 100
        10 => v := n60_slope * s
        11 => v := (MSQV - entp) / Bx * 100 * s
        12 => v := h4_bb * s
        13 => v := hD_th
        14 => v := hW_mx * s
        15 => v := h4_th
        16 => v := n15_bwr
        17 => v := hW_hb
        18 => v := n60_nej
        19 => v := math.floor((dayofmonth(wDateT, "Asia/Tokyo") - 1) / 7) + 1
        20 => v := h4_st * s
        21 => v := (pB - pO) / math.max(pH - pL, 1e-9) * s
        22 => v := hD_run * s
        23 => v := n60_macd * s
        24 => v := n15_chi * s
        25 => v := n15_st * s
        26 => v := ((s > 0 ? hW_l : hW_h) - entp) / Bx * 100 * s
        27 => v := hW_chi * s
        28 => v := lateW
        29 => v := h4_th
        30 => v := (pB - pO) / math.max(pH - pL, 1e-9) * s
        31 => v := ((hrH - hrL) / Bx * 100) / hD_atr
        32 => v := (pH - pL) / Bx * 100
        33 => v := n15_st * s
        34 => v := (hW_c - entp) / Bx * 100 * s
        35 => v := (hW_c - entp) / Bx * 100 * s
        36 => v := hW_ret5 * s
        37 => v := n60_rsi * s
        38 => v := h4_kj * s
        39 => v := n15_bwr
        40 => v := h4_hb
        41 => v := volR5
        42 => v := n15_adx
        43 => v := n15_cloud * s
        44 => v := n15_bwr
        45 => v := h4_p60 * s
        46 => v := hW_mx * s
        47 => v := volR5
        48 => v := n15_ma25 * s
        49 => v := n5_slope * s
        50 => v := n60_slope * s
        51 => v := (hW_c - entp) / Bx * 100 * s
        52 => v := (s > 0 ? (Bx - pL) / math.max(pH - pL, 1e-9) : 1 - (Bx - pL) / math.max(pH - pL, 1e-9))
        53 => v := n15_ret20 * s
        54 => v := n5_di * s
        55 => v := hD_run * s
        56 => v := n15_adx
        57 => v := n15_ma75 * s
        58 => v := hD_ret5 * s
        59 => v := hD_bb * s
        60 => v := hW_di * s
    v
f_cond(int i, bool up, float ep) =>
    v = f_val(i, up, ep)
    bool r = true
    switch i
        0 => r := not na(v) and v >= -30.15625 and v < -8.333333015441895
        1 => r := not na(v) and v == 1
        2 => r := not (not na(v) and v >= 6.0)
        3 => r := not na(v) and v == 0.0
        4 => r := not na(v) and v >= -1.0 and v < 1.0
        5 => r := not na(v) and v >= 2.241568684577942
        6 => r := not na(v) and v >= 4.003775119781502
        7 => r := not na(v) and v <= -2.310772442817688
        8 => r := not na(v) and v < 3.907860994338987
        9 => r := not na(v) and v <= 0.10860278829932213
        10 => r := not na(v) and v >= 0.1793772578239441
        11 => r := not na(v) and v >= 6.640061378479004
        12 => r := not na(v) and v < -0.6263596415519714
        13 => r := not (not na(v) and v >= 3.4665439128875732)
        14 => r := not na(v) and v >= 5.224077224731445
        15 => r := not na(v) and v >= 1.9129126071929932
        16 => r := not na(v) and v < 0.3166666626930237
        17 => r := not na(v) and v >= 0.17704051733016968 and v < 0.3347514569759369
        18 => r := not na(v) and v == 1.0
        19 => r := not na(v) and v == 4.0
        20 => r := not na(v) and v < -30.15625
        21 => r := not na(v) and v >= 0.1818181872367859 and v < 0.5555555820465088
        22 => r := not na(v) and v >= 1.0 and v < 4.0
        23 => r := not na(v) and v >= -0.04635874032974208 and v < 0.05968056991696358
        24 => r := not na(v) and v >= -0.17587940394878387 and v < 0.09712929278612137
        25 => r := not na(v) and v >= 46.842105865478516
        26 => r := not na(v) and v >= -1.0575588941574097
        27 => r := not na(v) and v >= 3.98528790473938
        28 => r := not na(v) and v >= 1.2137454748153687
        29 => r := not na(v) and v >= 1.9129126071929932
        30 => r := not na(v) and v >= -0.5897436141967773 and v < -0.2380952388048172
        31 => r := not (not na(v) and v >= 0.24360673874616623)
        32 => r := not na(v) and v >= 1.6114180088043213
        33 => r := not na(v) and v >= 19.805194854736328 and v < 38.5
        34 => r := not (not na(v) and v >= -0.6619280576705933 and v < 0.07872192561626434)
        35 => r := not (not na(v) and v >= -0.9475762248039246 and v < 0.3419572412967682)
        36 => r := not na(v) and v >= 1.2068672180175781 and v < 4.571042537689209
        37 => r := not na(v) and v >= -3.8397843837738037 and v < 7.729692459106445
        38 => r := not (not na(v) and v >= -0.31151872873306274 and v < 0.30156025290489197)
        39 => r := not na(v) and v < 0.28333333134651184
        40 => r := not na(v) and v >= 0.5292093753814697
        41 => r := not na(v) and v < 0.7868606448173523
        42 => r := not na(v) and v >= 17.32061767578125 and v < 21.96839141845703
        43 => r := not na(v) and v == -0.0
        44 => r := not na(v) and v >= 0.3166666626930237 and v < 0.6333333253860474
        45 => r := not (not na(v) and v >= -0.3192771077156067 and v < -0.10166666656732559)
        46 => r := not (not na(v) and v >= -0.6981928944587708 and v < 0.8675167560577393)
        47 => r := not na(v) and v < 0.7810482978820801
        48 => r := not na(v) and v >= 0.15102790296077728
        49 => r := not na(v) and v >= -0.025693945586681366 and v < 0.004638842772692442
        50 => r := not na(v) and v >= 0.30236440896987915
        51 => r := not na(v) and v >= 1.8660359740257264
        52 => r := not na(v) and v >= 0.31707316637039185 and v < 0.5770925283432007
        53 => r := not na(v) and v >= -0.0885661169886589 and v < 0.11153245717287064
        54 => r := not na(v) and v >= 18.666059494018555 and v < 25.87364387512207
        55 => r := not na(v) and v >= -4.0 and v < -1.0
        56 => r := not (not na(v) and v >= 20.351070404052734 and v < 29.843324661254883)
        57 => r := not na(v) and v >= 0.057746075093746185 and v < 0.29366081953048706
        58 => r := not (not na(v) and v >= 1.0303572416305542)
        59 => r := not (not na(v) and v >= -1.2120453119277954 and v < -0.3664289116859436)
        60 => r := not na(v) and v >= 7.269295692443848
    r
f_estE(int i, bool up) =>
    (array.get(cDef, i) == 0 ? B : Bf) * (1 + (up ? array.get(cX, i) : -array.get(cX, i)) / 100)

f_fmt(float v) => str.tostring(math.round(v), "#,###")
f_dirtxt(int d) => d > 0 ? "買い" : "売り"
f_kindtxt(int k) => k == 0 ? "D>N" : "N>D"

// 新しく入れるか（同じ向き2本・反対を持っていない・この窓で手じまいが出ていない・同じ候補を持っていない）
f_can(int i, int d) =>
    ok = not anyExit
    nSame = 0
    for j = 0 to array.size(pId) - 1
        if array.size(pId) == 0
            break
        if array.get(pDir, j) != d
            ok := false
        else
            nSame += 1
        if array.get(pId, j) == i
            ok := false
    ok and nSame < MAXPOS

// ポジションを追加して、利確・損切りを決める
f_open(int i, int d, float E, float w, float dist) =>
    tp = 0.0
    sl = 0.0
    if array.get(cSide, i) == 0
        tp := E + d * dist * array.get(cFR, i)
        sl := array.get(cSK, i) > 0 ? E - d * w * array.get(cSK, i) : na
    else
        sl := E - d * dist * array.get(cFR, i)
        tp := array.get(cSK, i) > 0 ? E + d * w * array.get(cSK, i) : na
    tmEnd = array.get(cTM, i) > 0 ? time + array.get(cTM, i) * 60000 : 0
    array.push(pId, i), array.push(pDir, d), array.push(pE, E), array.push(pTP, tp), array.push(pSL, sl), array.push(pTmEnd, tmEnd), array.push(pBar, bar_index)
    array.set(cDone, i, 1)
    n = array.size(pId)
    msg = "【入る】" + str.tostring(n) + "本目 " + f_dirtxt(d) + " " + f_fmt(E) + "\n #" + str.tostring(i + 1) + " " + f_kindtxt(array.get(cKind, i)) + " " + (array.get(cSide, i) == 0 ? "逆張り " : "順張り ") + (array.get(cDef, i) == 0 ? "現行 " : "先物基準 ") + array.get(cName, i) + "\n 利確 " + (na(tp) ? "なし" : f_fmt(tp)) + " / 損切り " + (na(sl) ? "なし" : f_fmt(sl)) + " / 時間切れ " + (tmEnd > 0 ? str.format_time(tmEnd, "HH:mm", "Asia/Tokyo") : "窓の終わり")
    alert(msg, alert.freq_all)
    log.info("ENTRY id={0} dir={1} E={2} tp={3} sl={4} v={5}", i + 1, d, E, tp, sl, f_val(i, array.get(cSide, i) == 0 ? d < 0 : d > 0, E))

// 手じまい
f_close(int j, float px, string why) =>
    i = array.get(pId, j)
    d = array.get(pDir, j)
    E = array.get(pE, j)
    yen = d * (px - E) / E * 68800 - 13 * 68800 / E
    alert("【手じまう】" + why + " " + f_dirtxt(d) + " #" + str.tostring(i + 1) + " " + f_fmt(px) + "（入 " + f_fmt(E) + "） " + str.tostring(math.round(yen)) + "円/1枚換算", alert.freq_all)
    log.info("EXIT id={0} why={1} px={2} yen={3}", i + 1, why, px, yen)
    array.remove(pId, j), array.remove(pDir, j), array.remove(pE, j), array.remove(pTP, j), array.remove(pSL, j), array.remove(pTmEnd, j), array.remove(pBar, j)

// ---------- 窓の始まり（基準が決まる）
// D>N：15:44 の足の終値が CFD の基準、15:45 の先物の足（引けの板寄せ）の終値が先物の基準 → 15:45 の足の確定でプレアラート
// N>D：5:59 の足の終値が CFD の基準。先物の基準は 6:00 の引け → CFD が再開した最初の足で確定してプレアラート
// 1分足は取引がない分は足が抜けることがあるので、時刻ちょうどの足に頼らない
// D>N の CFD の基準＝15:45 より前の最後の足の終値／N>D の CFD の基準＝6:00 より前の最後の足の終値
var float preDN = na
var float Bnd = na
var string doneDN = ""
inDay = hh >= 8 and hm < 1545
if barstate.isconfirmed and inDay
    preDN := c_
if barstate.isconfirmed and hh == 5
    Bnd := c_
isBaseDN = hm >= 1545 and hh < 17 and doneDN != dstr and not na(preDN)
isBaseND = not na(Bnd) and hh >= 6 and hh < 9 and wKind != 1

// ---------- 窓の終わり（基準が決まる前に処理する）
// D>N：5:55 以降の最初の足の始値で決済／N>D：15:45 以降の最初の足で、その前の足の終値で決済
endDNnow = wOn and wKind == 0 and ((hh == 5 and mi >= 55) or (hh >= 6 and hh < 9))
endNDnow = wOn and wKind == 1 and hm >= 1545 and hh < 17
if barstate.isconfirmed and (endDNnow or endNDnow)
    if array.size(pId) > 0
        for j = array.size(pId) - 1 to 0
            f_close(j, endDNnow ? o_ : c_[1], endDNnow ? "窓の終わり（5:55）" : "窓の終わり（引け）")
    wOn := false

if barstate.isconfirmed and isBaseDN
    wKind := 0
    wOn := true
    fOpen := false
    fGap := na
    wClosed := false
    fBack := false
    anyExit := false
    apUp := false
    apDn := false
    tStart := time
    for i = 0 to N - 1
        array.set(cDone, i, 0)
    B := preDN
    Bf := na(fC) ? fLast : fC
    pO := sesO
    pH := sesH
    pL := sesL
    pB := B
    runW := streak
    lateW := lateR
    hrH := na
    hrL := na
    wDateT := time
    doneDN := dstr
    preDN := na
    wLong := str.contains(NO_NIGHT, dstr) or dow == dayofweek.saturday or dow == dayofweek.sunday
if barstate.isconfirmed and isBaseND
    wKind := 1
    wOn := true
    fOpen := false
    fGap := na
    wClosed := false
    fBack := false
    anyExit := false
    apUp := false
    apDn := false
    tStart := time
    for i = 0 to N - 1
        array.set(cDone, i, 0)
    B := Bnd
    Bf := fLast
    pO := sesO
    pH := sesH
    pL := sesL
    pB := B
    runW := streak
    lateW := na
    hrH := na
    hrL := na
    wDateT := time
    Bnd := na
    wLong := str.contains(NO_DAY, dstr) or dow == dayofweek.saturday or dow == dayofweek.sunday or dow == dayofweek.monday and hh < 9

// プレアラート
if barstate.isconfirmed and (isBaseDN or isBaseND) and not wLong
    s = "【窓 " + f_kindtxt(wKind) + " " + str.format_time(time, "MM/dd HH:mm", "Asia/Tokyo") + "】基準 CFD " + f_fmt(B) + " / 先物 " + f_fmt(Bf)
    cnt = 0
    for i = 0 to N - 1
        if array.get(cKind, i) == wKind and cnt < 20
            for u = 0 to 1
                up = u == 0
                d = array.get(cSide, i) == 0 ? (up ? -1 : 1) : (up ? 1 : -1)
                if not (array.get(cSell, i) and d != -1) and f_cond(i, up, f_estE(i, up))
                    x = array.get(cX, i)
                    base = array.get(cDef, i) == 0 ? B : Bf
                    lv = base * (1 + (up ? x : -x) / 100)
                    s += "\n #" + str.tostring(i + 1) + " " + (array.get(cDef, i) == 0 ? "CFD " : "先物 ") + f_fmt(lv) + " " + f_dirtxt(d) + " " + array.get(cName, i)
                    cnt += 1
    alert(s, alert.freq_all)

// ---------- 窓の中
// 窓の終わり：D>N は 5:55（時間切れ0の決済は 5:55 の足の始値）、N>D は 15:44 の足の終値
endDN = false
endND = false
if wOn and not wLong and barstate.isconfirmed
    // 先物基準：予約していたエントリー（前の足で先物が届いた）→ この足の始値で入る
    if array.size(qId) > 0
        for j = 0 to array.size(qId) - 1
            i = array.get(qId, j)
            d = array.get(qDir, j)
            if f_cond(i, gapSign > 0, o_) and f_can(i, d)
                E = o_
                f_open(i, d, E, E * array.get(cX, i) / 100, E * array.get(qFd, j) / 100)
        array.clear(qId), array.clear(qDir), array.clear(qFd)
    // 手じまい（時間切れ → 損切り → 利確の順で判定。同じ足で両方なら損切り）
    if array.size(pId) > 0
        for j = array.size(pId) - 1 to 0
            d = array.get(pDir, j)
            tp = array.get(pTP, j)
            sl = array.get(pSL, j)
            te = array.get(pTmEnd, j)
            same = array.get(pBar, j) == bar_index
            if te > 0 and time >= te
                f_close(j, o_, "時間切れ")
                anyExit := true
            else if (wKind == 0 and endDN)
                f_close(j, o_, "窓の終わり（5:55）")
                anyExit := true
            else if not na(sl) and (d > 0 ? l_ <= sl : h_ >= sl)
                f_close(j, d > 0 ? math.min(sl, same ? sl : o_) : math.max(sl, same ? sl : o_), "損切り")
                anyExit := true
            else if not na(tp) and (same ? (d > 0 ? c_ >= tp : c_ <= tp) : (d > 0 ? h_ >= tp : l_ <= tp))
                f_close(j, same ? tp : (d > 0 ? math.max(tp, o_) : math.min(tp, o_)), "利確")
                anyExit := true
            else if endND
                f_close(j, c_, "窓の終わり（引け）")
                anyExit := true
    // 先物の寄り
    isFutOpen = not fOpen and not na(fO) and ((wKind == 0 and hm == 1700) or (wKind == 1 and hm == 845))
    if isFutOpen
        fOpen := true
        fGap := (fO - Bf) / Bf * 100
        gapSign := fO > Bf ? 1 : fO < Bf ? -1 : 0
    // 現行：寄り後に CFD が基準に戻ったら窓が閉じる
    if fOpen and not wClosed and ((gapSign > 0 and l_ <= B) or (gapSign < 0 and h_ >= B))
        wClosed := true
    canNew = not (wKind == 0 and hh == 5 and mi >= 55)
    // 現行のエントリー（CFD が基準±乖離幅に先に届いた側）
    if canNew and not (fOpen and wClosed)
        for i = 0 to N - 1
            if array.get(cKind, i) == wKind and array.get(cDef, i) == 0 and array.get(cDone, i) == 0
                x = array.get(cX, i)
                U = B * (1 + x / 100)
                L = B * (1 - x / 100)
                hu = h_ >= U
                hl = l_ <= L
                if hu and hl
                    array.set(cDone, i, 1)
                else if hu or hl
                    array.set(cDone, i, 1)
                    up = hu
                    d = array.get(cSide, i) == 0 ? (up ? -1 : 1) : (up ? 1 : -1)
                    if not (array.get(cSell, i) and d != -1) and f_cond(i, up, c_) and f_can(i, d)
                        E = reo ? c_ : (up ? math.max(U, o_) : math.min(L, o_))
                        f_open(i, d, E, B * x / 100, math.abs(E - B))
    // 先物基準のエントリー（寄りで届いていれば寄りの CFD 始値、寄り後に届いたら次の足の始値）
    if fOpen and not fBack and gapSign != 0 and canNew
        up = gapSign > 0
        back = up ? fL <= Bf : fH >= Bf
        gp = math.abs(fGap)
        for i = 0 to N - 1
            if array.get(cKind, i) == wKind and array.get(cDef, i) == 1 and array.get(cDone, i) == 0 and not na(fH)
                x = array.get(cX, i)
                d = array.get(cSide, i) == 0 ? (up ? -1 : 1) : (up ? 1 : -1)
                if isFutOpen and gp >= x
                    array.set(cDone, i, 1)
                    if not (array.get(cSell, i) and d != -1) and f_cond(i, up, o_) and f_can(i, d)
                        f_open(i, d, o_, o_ * x / 100, o_ * gp / 100)
                else if not back
                    Lf = Bf * (1 + (up ? x : -x) / 100)
                    if up ? fH >= Lf : fL <= Lf
                        array.set(cDone, i, 1)
                        if not (array.get(cSell, i) and d != -1) and true
                            array.push(qId, i), array.push(qDir, d), array.push(qFd, x)
                            if f_cond(i, up, c_)
                                alert("【まもなく入る】先物が " + f_fmt(Lf) + " に届いた → 次の足の始値で " + f_dirtxt(d) + " #" + str.tostring(i + 1) + " " + array.get(cName, i), alert.freq_all)
        if back
            fBack := true
    // 接近アラート（その向きで一番近い候補の80%、窓ごと・向きごとに1回）
    for u = 0 to 1
        up = u == 0
        if (up and not apUp) or (not up and not apDn)
            best = 0.0
            bi = -1
            for i = 0 to N - 1
                if array.get(cKind, i) == wKind and array.get(cDone, i) == 0
                    isF = array.get(cDef, i) == 1
                    if not isF or fOpen
                        x = array.get(cX, i)
                        base = isF ? Bf : B
                        px = isF ? (up ? fH : fL) : (up ? h_ : l_)
                        prog = na(px) ? 0.0 : (up ? (px - base) : (base - px)) / (base * x / 100)
                        d = array.get(cSide, i) == 0 ? (up ? -1 : 1) : (up ? 1 : -1)
                        if prog > best and prog < 1 and not (array.get(cSell, i) and d != -1) and f_cond(i, up, f_estE(i, up))
                            best := prog
                            bi := i
            if bi >= 0 and best >= APPROACH
                if up
                    apUp := true
                else
                    apDn := true
                isF = array.get(cDef, bi) == 1
                x = array.get(cX, bi)
                base = isF ? Bf : B
                alert("【近づいた】" + f_kindtxt(wKind) + (up ? " 上へ " : " 下へ ") + (isF ? "先物 " : "CFD ") + "#" + str.tostring(bi + 1) + " 入る値段 " + f_fmt(base * (1 + (up ? x : -x) / 100)) + " " + array.get(cName, bi), alert.freq_all)
    if endDN or endND
        wOn := false

if barstate.isconfirmed and wOn and wKind == 1 and not fOpen
    hrH := na(hrH) ? h_ : math.max(hrH, h_)
    hrL := na(hrL) ? l_ : math.min(hrL, l_)

// ---------- チャートに描く（最後の足で描き直す）
SHOW_LV = input.int(3, "向きごとに表示する入る値段の数", minval = 0, maxval = 8)
LBL_GAP = input.float(1.0, "ラベルの間隔（文字の高さの何倍）", minval = 0.5, maxval = 3, step = 0.1)
TBL_DARK = input.bool(true, "表をダークモード用の色にする")
TBL_SIZE = input.string("normal", "表の文字の大きさ", options = ["small", "normal", "large"])
TBL_POS = input.string("右下", "表の位置", options = ["右上", "右下", "左下", "左上"])
rng300 = ta.highest(h_, 300) - ta.lowest(l_, 300)
var array<line>  dL = array.new<line>(0)
var array<label> dB = array.new<label>(0)
var array<float>  qY = array.new<float>(0)
var array<string> qT = array.new<string>(0)
var array<color>  qC = array.new<color>(0)
f_lab(int x, float y, string t, color c) =>
    array.push(qY, y), array.push(qT, t), array.push(qC, c)
f_line(int x1, float y, color c, string st) =>
    array.push(dL, line.new(x1, y, bar_index + 30, y, color = c, width = 1, style = st == "dot" ? line.style_dotted : st == "dash" ? line.style_dashed : line.style_solid))
if barstate.islast
    for l in dL
        line.delete(l)
    for b in dB
        label.delete(b)
    array.clear(dL), array.clear(dB), array.clear(qY), array.clear(qT), array.clear(qC)
    x0 = bar_index + 2
    if wOn and not wLong and not na(B)
        ratio = na(fLast) ? 1.0 : c_ / fLast          // 先物 → CFD の換算（今の差）
        f_line(bar_index - 30, B, color.blue, "dot")
        f_lab(x0, B, "基準 CFD " + f_fmt(B) + (na(Bf) ? "" : " / 先物 " + f_fmt(Bf)), color.blue)
        // 入る値段：向きごとに、まだ入っていない・条件を満たす候補のうち、今の値段に近い順
        totalShown = 0
        nLeft = 0
        for u = 0 to 1
            up = u == 0
            idx = array.new<int>(0)
            dist = array.new<float>(0)
            for i = 0 to N - 1
                if array.get(cKind, i) == wKind and array.get(cDone, i) == 0
                    nLeft += 1
                    isF = array.get(cDef, i) == 1
                    d = array.get(cSide, i) == 0 ? (up ? -1 : 1) : (up ? 1 : -1)
                    ok = not anyExit and not (array.get(cSell, i) and d != -1) and f_cond(i, up, f_estE(i, up)) and not (isF and fBack) and not (not isF and fOpen and wClosed)
                    if isF and fOpen
                        ok := ok and (up ? gapSign > 0 : gapSign < 0)
                    if ok
                        x = array.get(cX, i)
                        lvF = (isF ? Bf : B) * (1 + (up ? x : -x) / 100)
                        lvC = isF ? lvF * ratio : lvF
                        array.push(idx, i)
                        array.push(dist, math.abs(lvC - c_))
            n = array.size(idx)
            shown = 0
            if n > 0
                ord = array.sort_indices(dist, order.ascending)
                for k = 0 to n - 1
                    if shown >= SHOW_LV
                        break
                    i = array.get(idx, array.get(ord, k))
                    isF = array.get(cDef, i) == 1
                    x = array.get(cX, i)
                    lvF = (isF ? Bf : B) * (1 + (up ? x : -x) / 100)
                    lvC = isF ? lvF * ratio : lvF
                    d = array.get(cSide, i) == 0 ? (up ? -1 : 1) : (up ? 1 : -1)
                    prog = (up ? (c_ - B) : (B - c_)) / (B * x / 100)
                    col = prog >= APPROACH ? color.orange : (d > 0 ? color.teal : color.maroon)
                    f_line(bar_index - 30, lvC, col, "dash")
                    w_ = (isF ? lvF : B) * x / 100
                    dd = isF ? lvF * x / 100 : math.abs(lvF - B)
                    tp = array.get(cSide, i) == 0 ? lvC + d * dd * array.get(cFR, i) : (array.get(cSK, i) > 0 ? lvC + d * w_ * array.get(cSK, i) : na)
                    sl = array.get(cSide, i) == 0 ? (array.get(cSK, i) > 0 ? lvC - d * w_ * array.get(cSK, i) : na) : lvC - d * dd * array.get(cFR, i)
                    t = "#" + str.tostring(i + 1) + " " + f_dirtxt(d) + " " + f_fmt(lvC) + (isF ? "（先物 " + f_fmt(lvF) + "で成行）" : "（指値・逆指値）") + "  利確 " + (na(tp) ? "なし" : f_fmt(tp)) + " 損切り " + (na(sl) ? "なし" : f_fmt(sl)) + (array.get(cTM, i) > 0 ? " 時間 " + str.tostring(array.get(cTM, i)) + "分" : "") + "  " + array.get(cName, i)
                    f_lab(x0, lvC, t, col)
                    shown += 1
                    totalShown += 1
        // 入る値段が1本も出ないときは、理由を出す
        if totalShown == 0
            why = anyExit ? "この窓は手じまいが出たので、もう入りません（入り直しなし）" : nLeft == 0 ? "この窓の候補は、すべて入った・判定済みです" : (fOpen and wClosed and fBack) ? "窓が閉じた（基準に戻った）ので、もう入りません" : "今、条件を満たす候補はありません"
            f_lab(x0, c_, why + "\n次の窓：" + (wKind == 1 ? "D>N（15:45 に基準が決まる）" : "N>D（CFD 再開時に基準が決まる）"), color.gray)
    else
        f_lab(x0, c_, "窓なし（" + (wLong ? "休日のため使わない窓" : "基準が決まるまで待ち") + "）\n次の窓：D>N は 15:45、N>D は CFD 再開時に基準が決まる", color.gray)
    // 持っているポジション：入った値段・利確・損切り
    if array.size(pId) > 0
        for j = 0 to array.size(pId) - 1
            i = array.get(pId, j)
            d = array.get(pDir, j)
            E = array.get(pE, j)
            tp = array.get(pTP, j)
            sl = array.get(pSL, j)
            te = array.get(pTmEnd, j)
            x1 = array.get(pBar, j)
            f_line(x1, E, color.gray, "solid")
            if not na(tp)
                f_line(x1, tp, color.green, "solid")
                f_lab(x0, tp, "利確 " + f_fmt(tp) + " #" + str.tostring(i + 1), color.green)
            if not na(sl)
                f_line(x1, sl, color.red, "solid")
                f_lab(x0, sl, "損切り " + f_fmt(sl) + " #" + str.tostring(i + 1), color.red)
            f_lab(x0, E, str.tostring(j + 1) + "本目 " + f_dirtxt(d) + " " + f_fmt(E) + " #" + str.tostring(i + 1) + " 時間切れ " + (te > 0 ? str.format_time(te, "HH:mm", "Asia/Tokyo") : "窓の終わり"), color.gray)
    // ラベルを値段の順に並べ、近すぎるものは上にずらす（ずらしたものは元の値段へ点線でつなぐ）
    nL = array.size(qY)
    if nL > 0
        gap = rng300 * 0.035 * LBL_GAP
        ord = array.sort_indices(qY, order.ascending)
        prev = -1e18
        for k = 0 to nL - 1
            m = array.get(ord, k)
            y = array.get(qY, m)
            ya = math.max(y, prev + gap)
            prev := ya
            c = array.get(qC, m)
            array.push(dB, label.new(x0 + 4, ya, array.get(qT, m), style = label.style_label_left, color = color.new(c, 30), textcolor = color.white, size = size.normal))
            array.push(dL, line.new(bar_index + 1, y, x0 + 4, ya, color = c, style = line.style_dotted, width = 1))

// ---------- 表
var table tb = table.new(TBL_POS == "右上" ? position.top_right : TBL_POS == "左下" ? position.bottom_left : TBL_POS == "左上" ? position.top_left : position.bottom_right, 2, 6, border_width = 1)
if SHOW_TBL and barstate.islast
    bgH = TBL_DARK ? color.rgb(42, 46, 57) : color.rgb(225, 230, 240)
    bgC = TBL_DARK ? color.rgb(19, 23, 34) : color.white
    fg  = TBL_DARK ? color.white : color.black
    fgK = TBL_DARK ? color.rgb(178, 181, 190) : color.rgb(80, 80, 80)
    ts  = TBL_SIZE == "small" ? size.small : TBL_SIZE == "large" ? size.large : size.normal
    table.set_border_color(tb, TBL_DARK ? color.rgb(67, 70, 81) : color.rgb(200, 200, 200))
    table.set_frame_color(tb, TBL_DARK ? color.rgb(67, 70, 81) : color.rgb(200, 200, 200))
    table.set_frame_width(tb, 1)
    hdr = array.from("窓", "基準 CFD / 先物", "先物の寄り", "持っている本数", "この窓で手じまい")
    vals = array.from(wOn ? f_kindtxt(wKind) + (wLong ? "（休日で使わない）" : "") : "なし", f_fmt(B) + " / " + f_fmt(Bf), fOpen ? str.tostring(fGap, "#.##") + "%" : "まだ", str.tostring(array.size(pId)) + " / 2", anyExit ? "あり（新しく入らない）" : "なし")
    if not chart.is_standard
        table.cell(tb, 0, 5, "注意", bgcolor = color.rgb(120, 30, 30), text_color = color.white, text_size = ts)
        table.cell(tb, 1, 5, "ふつうのローソク足ではないチャートです（計算は本物の値段で行っています）", bgcolor = color.rgb(120, 30, 30), text_color = color.white, text_size = ts)
    for r = 0 to 4
        table.cell(tb, 0, r, array.get(hdr, r), bgcolor = bgH, text_color = fgK, text_size = ts, text_halign = text.align_left)
        hot = (r == 3 and array.size(pId) > 0) or (r == 4 and anyExit)
        table.cell(tb, 1, r, array.get(vals, r), bgcolor = bgC, text_color = hot ? color.orange : fg, text_size = ts, text_halign = text.align_left)
'''
for k, v in (('__KIND__', kind), ('__DEF__', dfn), ('__SIDE__', side), ('__SELL__', sell), ('__X__', xs), ('__FR__', fr), ('__SK__', sk), ('__TM__', tm), ('__NAME__', nm)):
    pine = pine.replace(k, v)
open(W + '/08/results/窓埋め61本_v0.8_条件あり.pine', 'w').write(pine)
print(len(pine.splitlines()), 'lines')
