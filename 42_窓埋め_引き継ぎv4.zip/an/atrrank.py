# (ウ) ATRの逐次順位：各エントリーのATR（5分・15分）が、直近 N日（暦日）の同じ時間足ATRの分布の中で何番目か（0〜1）
#   分布は「基準時刻（先物引け）までに確定した足」だけで作る（先読みなし）。エントリー時のATRは F6 と同じ値
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/work/01/code'); import ld
W = '/home/claude/work'
c5 = ld.bars(W + '/data/c5.csv', until='2026-10-09')
x = c5.rename(columns={'open': 'o', 'high': 'h', 'low': 'l', 'close': 'c'})[['m', 'o', 'h', 'l', 'c']].copy(); x['m'] = x.m.astype('int64')
en = pd.read_pickle(W + '/T/en.pkl'); ev = pd.read_pickle(W + '/T/evt.pkl'); F = pd.read_pickle(W + '/T/F6.pkl')
out = pd.DataFrame(index=en.index)
for tf, k in (('5m', 5), ('15m', 15)):
    b = x.groupby(x.m // k).agg(h=('h', 'max'), l=('l', 'min'), c=('c', 'last'))
    pc = b.c.shift(1); tr = pd.concat([b.h - b.l, (b.h - pc).abs(), (b.l - pc).abs()], axis=1).max(axis=1)
    atr = (tr.ewm(alpha=1 / 14, adjust=False, min_periods=14).mean() / b.c * 100)
    av = (b.index.values + 1) * k; a = atr.values; ok = ~np.isnan(a); av = av[ok]; a = a[ok]
    # 検算：エントリー時点の値（確定済みの最後の足）が F6 と一致するか
    j = np.searchsorted(av, en.m.values.astype('int64'), side='right') - 1
    print(tf, 'F6との最大差', np.nanmax(np.abs(a[j] - F['atr_' + tf].values)))
    for days in (90, 365):
        r = np.full(len(ev), np.nan); pend = ev.pend.values.astype('int64')
        for i, pe in enumerate(pend):
            hi = np.searchsorted(av, pe, side='right'); lo = np.searchsorted(av, pe - days * 1440, side='left')
            if hi - lo >= 1000: r[i] = 0  # 印（下で計算）
        # イベントごとに分布をソートし、そのイベントのエントリーの値の順位を求める
        rank = np.full(len(en), np.nan); evi = en.ev.values; vals = F['atr_' + tf].values.astype(float)
        order = np.argsort(evi, kind='stable'); bounds = np.searchsorted(evi[order], np.arange(len(ev) + 1))
        for i, pe in enumerate(pend):
            if np.isnan(r[i]): continue
            hi = np.searchsorted(av, pe, side='right'); lo = np.searchsorted(av, pe - days * 1440, side='left')
            dist = np.sort(a[lo:hi]); rows = order[bounds[i]:bounds[i + 1]]
            rank[rows] = np.searchsorted(dist, vals[rows], side='right') / len(dist)
        out['rk_atr_%s_%dd' % (tf, days)] = rank
        print(tf, days, '日：順位あり', np.isfinite(rank).mean().round(3), '上位10%の割合', np.nanmean(rank >= 0.9).round(3))
out.to_pickle(W + '/T/atrrank.pkl')
yr = ev.t0.dt.year.values[en.ev.values]
print(out.assign(yr=yr).groupby('yr').agg(lambda s: np.nanmean(s >= 0.9)).round(3).to_string())
