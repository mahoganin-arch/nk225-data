# 今の候補の詳しい成績の Excel
import pandas as pd, numpy as np
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
W = '/home/claude/work'; OUT = W + '/08/results/S11_今の候補の成績.xlsx'
L = pd.read_pickle(W + '/S14list.pkl'); Y = pd.read_pickle(W + '/S14years.pkl'); PR = pd.read_pickle(W + '/S14port.pkl'); PY = pd.read_pickle(W + '/S14portyears.pkl')
for D in (L, Y): D['候補'] = D['候補'].str.replace('=-0', '=0', regex=False)
main = ['窓の種類', '向き', '順位', '候補', '条件', '定義', '候補の窓', 'テーマ', '今のルール', '順位の値_2017_25の1回平均', '順位の値_件数']
fw = [c for c in L.columns if c.startswith('前向き:')]; fa = [c for c in L.columns if c.startswith('全期間:')]
yp = Y[Y['記録'] == '前向き検証'].pivot_table(index=['窓の種類', '向き', '順位', '候補', '定義'], columns='年', values=['合計', '件数', '勝率', 'PF'], aggfunc='first')
yp.columns = ['%d年%s' % (y, k) for k, y in yp.columns]; yp = yp[sorted(yp.columns)].reset_index()
ya = Y[Y['記録'] == '今のルールで全期間'].pivot_table(index=['窓の種類', '向き', '順位', '候補', '定義'], columns='年', values=['合計', '件数', '勝率', 'PF'], aggfunc='first')
ya.columns = ['%d年%s' % (y, k) for k, y in ya.columns]; ya = ya[sorted(ya.columns)].reset_index()
pyp = PY.pivot_table(index=['方針', '上位N本'], columns='年', values=['合計', '件数', '勝率', 'PF', '最大DD'], aggfunc='first'); pyp.columns = ['%d年%s' % (y, k) for k, y in pyp.columns]; pyp = pyp[sorted(pyp.columns)].reset_index()
desc = [
 ['この表について', '運用の第一候補（重なりでまとめた代表（区切り0.5）から、窓の種類・向きごとに上位10本）の、候補ごとのトレード成績と、組み合わせたときの成績'],
 ['順位', '2026年に使うルール（2017〜2025年のデータで選んだ乖離幅・決済、周辺の選び方）の、2017〜2025年の1回あたり平均（15件以上）の順。上位5本＝順位1〜5'],
 ['成績の2種類', '前向き：2022〜2026年の記録。各年は、その年より前のデータで選んだルール（乖離幅・決済）で売買したもの。実力に近い／全期間：今のルールで2017〜2026/10/8 を通したもの。ルールを選んだ期間を含むので良く出やすい（参考）'],
 ['', '候補が「両方の窓」でも、この表ではその行の窓の種類（D>N または N>D）のトレードだけを数える'],
 ['金額', '1枚＝価格比を68,800円に換算、コスト（スプレッド13pt）控除後、円'],
 ['項目', '勝率＝プラスの割合、PF＝利益合計÷損失合計、損益比＝平均利益÷平均損失、最大DD＝累計損益のピークからの最大の下落、最大連敗＝0円以下が続いた最大回数'],
 ['組み合わせ', '先着1本・同じ向き2本・両建て＋2本目を、上位5本・10本で（前向き検証、2022〜2026年、入り直しなし）。最悪の1窓＝1つの窓での合計損益の最小'],
 ['注意', '前向きの件数が少ない候補（20件未満など）は数字の振れが大きい。候補自体は2026年までの成績を見て残したもの。最終判断はフォワード'],
 ['シート', '候補一覧／候補の年ごと（前向き）／候補の年ごと（全期間）／組み合わせ／組み合わせの年ごと／候補の年ごと（縦長）'],
]
with pd.ExcelWriter(OUT, engine='openpyxl') as w:
    pd.DataFrame(desc, columns=['項目', '内容']).to_excel(w, sheet_name='説明', index=False)
    L[main + fw + fa].round(2).to_excel(w, sheet_name='候補一覧', index=False)
    yp.round(2).to_excel(w, sheet_name='候補の年ごと（前向き）', index=False)
    ya.round(2).to_excel(w, sheet_name='候補の年ごと（全期間）', index=False)
    PR.round(2).to_excel(w, sheet_name='組み合わせ', index=False)
    pyp.round(2).to_excel(w, sheet_name='組み合わせの年ごと', index=False)
    Y.round(2).to_excel(w, sheet_name='候補の年ごと（縦長）', index=False)
wb = load_workbook(OUT); red = Font(name='Arial', size=10, color='C00000')
for ws in wb:
    for row in ws.iter_rows():
        for c in row:
            c.font = Font(name='Arial', size=10, bold=c.row == 1)
            if c.row > 1 and isinstance(c.value, (int, float)) and c.value < 0: c.font = red
    for c in ws[1]: c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.freeze_panes = 'E2' if ws.title.startswith('候補') else 'A2'
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = 11
ws = wb['説明']; ws.column_dimensions['A'].width = 14; ws.column_dimensions['B'].width = 150
for c in ws['B']: c.alignment = Alignment(wrap_text=True, vertical='top')
ws = wb['候補一覧']; ws.column_dimensions['D'].width = 30; ws.column_dimensions['E'].width = 40; ws.column_dimensions['I'].width = 70
wb.save(OUT); print(OUT)
