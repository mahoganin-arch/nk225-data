# Pine Script v6（ステップ2：条件なしの骨組み）を作る。売買する63本のルール（2026年）を埋め込む
import ast, pandas as pd
W = '/home/claude/work'
A = pd.read_pickle(W + '/S28inv.pkl'); S = A[A['扱い'] == '売買する'].sort_values('全体の優先順位')
WEAK = ((S['窓の種類'] == 'N>D') & (S['定義'] == '先物基準') & (S['向き'] == '逆張り') & S['名前'].str.contains('4時間60本高安の位置 5分割:3')) | ((S['窓の種類'] == 'D>N') & (S['定義'] == '先物基準') & (S['向き'] == '逆張り') & S['名前'].str.contains('4時間BBσ位置 3分割:中'))
assert WEAK.sum() == 2
S = S[~WEAK].reset_index(drop=True)
def arr(vals, fmt): return ', '.join(fmt(v) for v in vals)
kind = arr(S['窓の種類'], lambda v: '0' if v == 'D>N' else '1')
dfn = arr(S['定義'], lambda v: '0' if v == '現行' else '1')
side = arr(S['向き'], lambda v: '0' if v == '逆張り' else '1')
sell = arr(S['売買'], lambda v: 'true' if v == '売りのみ' else 'false')
xs = arr(S['乖離幅(%)'], lambda v: '%g' % v)
R = [ast.literal_eval(r) for r in S['決済(FR,SK,TM)']]
fr = arr([r[0] for r in R], lambda v: '%g' % v); sk = arr([r[1] for r in R], lambda v: '%g' % v); tm = arr([r[2] for r in R], lambda v: '%d' % v)
nm = arr(S['名前'], lambda v: '"%s"' % str(v).replace('"', ''))
pine = r'''//@version=6
// 窓埋め 売買用（61本）ステップ2：窓・基準・エントリー・手じまい・同じ向き2本・アラートの骨組み
// まだ指標の条件は入っていない（f_cond はいつも true）。Python の「条件なし」の計算と照合するための版
// チャート：FOREX.com JP225 の1分足。先物：OSE:NK225M1!（リアルタイム）
indicator("窓埋め61本 v0.7 骨組み（条件なし）", overlay = true, max_labels_count = 200, max_lines_count = 200)

FUT      = input.symbol("OSE:NK225M1!", "先物")
APPROACH = input.float(0.8, "接近アラート（乖離幅に対する割合）", minval = 0.1, maxval = 0.99, step = 0.05)
SHOW_TBL = input.bool(true, "表を出す")
NO_NIGHT = input.string("", "夜間が休みの日（YYYY-MM-DD をカンマ区切り。その日の夕方の D>N の窓を使わない）")
NO_DAY   = input.string("", "日中が休みの日（YYYY-MM-DD をカンマ区切り。その日の朝の N>D の窓を使わない）")
MAXPOS   = 2

// ---------- 候補（優先順位の順。kind 0=D>N 1=N>D、def 0=現行 1=先物基準、side 0=逆張り 1=順張り）
var array<int>    cKind = array.from(__KIND__)
var array<int>    cDef  = array.from(__DEF__)
var array<int>    cSide = array.from(__SIDE__)
var array<bool>   cSell = array.from(__SELL__)
var array<float>  cX    = array.from(__X__)
var array<float>  cFR   = array.from(__FR__)
var array<float>  cSK   = array.from(__SK__)
var array<int>    cTM   = array.from(__TM__)
var array<string> cName = array.from(__NAME__)
N = array.size(cX)

// ---------- 条件（ステップ4で指標を入れる）。up=true は窓が上に離れた側
f_cond(int i, bool up) =>
    true

// ---------- 時刻（日本時間）
hh = hour(time, "Asia/Tokyo")
mi = minute(time, "Asia/Tokyo")
hm = hh * 100 + mi
dstr = str.format_time(time, "yyyy-MM-dd", "Asia/Tokyo")
dow = dayofweek(time, "Asia/Tokyo")
reo = not na(time[1]) and (time - time[1]) > 30 * 60000      // CFD が30分より長く止まったあとの最初の足

// ---------- CFD の値段：チャートが平均足などでも、ふつうのローソク足の値段を使う
[o_, h_, l_, c_] = request.security(ticker.standard(syminfo.tickerid), timeframe.period, [open, high, low, close])
// ---------- 先物（同じ1分足）。gaps_on：先物の足がない時刻は na
[fO, fH, fL, fC] = request.security(FUT, timeframe.period, [open, high, low, close], gaps = barmerge.gaps_on)
fLast = request.security(FUT, timeframe.period, close)        // 直近の先物終値（休み中も前の値）

// ---------- 窓の状態
var int   wKind  = -1        // 0=D>N 1=N>D
var bool  wOn    = false     // 窓が動いている
var bool  wLong  = false     // 休日をはさむ窓（使わない）
var float B      = na        // CFD の基準（現行）
var float Bf     = na        // 先物の基準（先物基準）
var bool  fOpen  = false     // 先物が寄った
var float fGap   = na        // 先物の寄りの窓（%、符号つき）
var bool  wClosed = false    // 寄り後に CFD が基準に戻った（現行は以後入らない）
var bool  fBack  = false     // 寄り後に先物が基準に戻った（先物基準は以後入らない）
var int   gapSign = 0
var bool  anyExit = false    // この窓で手じまいが出た
var bool  apUp   = false
var bool  apDn   = false
var int   tStart = na
// 候補ごとの状態：0=まだ 1=入った/済み（その窓で1回だけ）
var array<int> cDone = array.new<int>(0)
if barstate.isfirst
    cDone := array.new<int>(N, 0)
// ポジション
var array<int>   pId  = array.new<int>(0)
var array<int>   pDir = array.new<int>(0)
var array<float> pE   = array.new<float>(0)
var array<float> pTP  = array.new<float>(0)
var array<float> pSL  = array.new<float>(0)
var array<int>   pTmEnd = array.new<int>(0)    // 時間切れの時刻（ms、0=なし）
var array<int>   pBar = array.new<int>(0)
// 先物基準の「次の足の始値で入る」予約
var array<int>   qId  = array.new<int>(0)
var array<int>   qDir = array.new<int>(0)
var array<float> qFd  = array.new<float>(0)

f_fmt(float v) => str.tostring(math.round(v), "#,###")
f_dirtxt(int d) => d > 0 ? "買い" : "売り"
f_kindtxt(int k) => k == 0 ? "D>N" : "N>D"

// 新しく入れるか（同じ向き2本・反対を持っていない・この窓で手じまいが出ていない・同じ候補を持っていない）
f_can(int i, int d) =>
    ok = not anyExit
    nSame = 0
    for j = 0 to array.size(pId) - 1
        if array.size(pId) == 0
            break
        if array.get(pDir, j) != d
            ok := false
        else
            nSame += 1
        if array.get(pId, j) == i
            ok := false
    ok and nSame < MAXPOS

// ポジションを追加して、利確・損切りを決める
f_open(int i, int d, float E, float w, float dist) =>
    tp = 0.0
    sl = 0.0
    if array.get(cSide, i) == 0
        tp := E + d * dist * array.get(cFR, i)
        sl := array.get(cSK, i) > 0 ? E - d * w * array.get(cSK, i) : na
    else
        sl := E - d * dist * array.get(cFR, i)
        tp := array.get(cSK, i) > 0 ? E + d * w * array.get(cSK, i) : na
    tmEnd = array.get(cTM, i) > 0 ? time + array.get(cTM, i) * 60000 : 0
    array.push(pId, i), array.push(pDir, d), array.push(pE, E), array.push(pTP, tp), array.push(pSL, sl), array.push(pTmEnd, tmEnd), array.push(pBar, bar_index)
    array.set(cDone, i, 1)
    n = array.size(pId)
    msg = "【入る】" + str.tostring(n) + "本目 " + f_dirtxt(d) + " " + f_fmt(E) + "\n #" + str.tostring(i + 1) + " " + f_kindtxt(array.get(cKind, i)) + " " + (array.get(cSide, i) == 0 ? "逆張り " : "順張り ") + (array.get(cDef, i) == 0 ? "現行 " : "先物基準 ") + array.get(cName, i) + "\n 利確 " + (na(tp) ? "なし" : f_fmt(tp)) + " / 損切り " + (na(sl) ? "なし" : f_fmt(sl)) + " / 時間切れ " + (tmEnd > 0 ? str.format_time(tmEnd, "HH:mm", "Asia/Tokyo") : "窓の終わり")
    alert(msg, alert.freq_all)
    log.info("ENTRY id={0} dir={1} E={2} tp={3} sl={4}", i + 1, d, E, tp, sl)

// 手じまい
f_close(int j, float px, string why) =>
    i = array.get(pId, j)
    d = array.get(pDir, j)
    E = array.get(pE, j)
    yen = d * (px - E) / E * 68800 - 13 * 68800 / E
    alert("【手じまう】" + why + " " + f_dirtxt(d) + " #" + str.tostring(i + 1) + " " + f_fmt(px) + "（入 " + f_fmt(E) + "） " + str.tostring(math.round(yen)) + "円/1枚換算", alert.freq_all)
    log.info("EXIT id={0} why={1} px={2} yen={3}", i + 1, why, px, yen)
    array.remove(pId, j), array.remove(pDir, j), array.remove(pE, j), array.remove(pTP, j), array.remove(pSL, j), array.remove(pTmEnd, j), array.remove(pBar, j)

// ---------- 窓の始まり（基準が決まる）
// D>N：15:44 の足の終値が CFD の基準、15:45 の先物の足（引けの板寄せ）の終値が先物の基準 → 15:45 の足の確定でプレアラート
// N>D：5:59 の足の終値が CFD の基準。先物の基準は 6:00 の引け → CFD が再開した最初の足で確定してプレアラート
// 1分足は取引がない分は足が抜けることがあるので、時刻ちょうどの足に頼らない
// D>N の CFD の基準＝15:45 より前の最後の足の終値／N>D の CFD の基準＝6:00 より前の最後の足の終値
var float preDN = na
var float Bnd = na
var string doneDN = ""
inDay = hh >= 8 and hm < 1545
if barstate.isconfirmed and inDay
    preDN := c_
if barstate.isconfirmed and hh == 5
    Bnd := c_
isBaseDN = hm >= 1545 and hh < 17 and doneDN != dstr and not na(preDN)
isBaseND = not na(Bnd) and hh >= 6 and hh < 9 and wKind != 1

// ---------- 窓の終わり（基準が決まる前に処理する）
// D>N：5:55 以降の最初の足の始値で決済／N>D：15:45 以降の最初の足で、その前の足の終値で決済
endDNnow = wOn and wKind == 0 and ((hh == 5 and mi >= 55) or (hh >= 6 and hh < 9))
endNDnow = wOn and wKind == 1 and hm >= 1545 and hh < 17
if barstate.isconfirmed and (endDNnow or endNDnow)
    if array.size(pId) > 0
        for j = array.size(pId) - 1 to 0
            f_close(j, endDNnow ? o_ : c_[1], endDNnow ? "窓の終わり（5:55）" : "窓の終わり（引け）")
    wOn := false

if barstate.isconfirmed and isBaseDN
    wKind := 0
    wOn := true
    fOpen := false
    fGap := na
    wClosed := false
    fBack := false
    anyExit := false
    apUp := false
    apDn := false
    tStart := time
    for i = 0 to N - 1
        array.set(cDone, i, 0)
    B := preDN
    Bf := na(fC) ? fLast : fC
    doneDN := dstr
    preDN := na
    wLong := str.contains(NO_NIGHT, dstr) or dow == dayofweek.saturday or dow == dayofweek.sunday
if barstate.isconfirmed and isBaseND
    wKind := 1
    wOn := true
    fOpen := false
    fGap := na
    wClosed := false
    fBack := false
    anyExit := false
    apUp := false
    apDn := false
    tStart := time
    for i = 0 to N - 1
        array.set(cDone, i, 0)
    B := Bnd
    Bf := fLast
    Bnd := na
    wLong := str.contains(NO_DAY, dstr) or dow == dayofweek.saturday or dow == dayofweek.sunday or dow == dayofweek.monday and hh < 9

// プレアラート
if barstate.isconfirmed and (isBaseDN or isBaseND) and not wLong
    s = "【窓 " + f_kindtxt(wKind) + " " + str.format_time(time, "MM/dd HH:mm", "Asia/Tokyo") + "】基準 CFD " + f_fmt(B) + " / 先物 " + f_fmt(Bf)
    cnt = 0
    for i = 0 to N - 1
        if array.get(cKind, i) == wKind and cnt < 20
            for u = 0 to 1
                up = u == 0
                d = array.get(cSide, i) == 0 ? (up ? -1 : 1) : (up ? 1 : -1)
                if not (array.get(cSell, i) and d != -1) and f_cond(i, up)
                    x = array.get(cX, i)
                    base = array.get(cDef, i) == 0 ? B : Bf
                    lv = base * (1 + (up ? x : -x) / 100)
                    s += "\n #" + str.tostring(i + 1) + " " + (array.get(cDef, i) == 0 ? "CFD " : "先物 ") + f_fmt(lv) + " " + f_dirtxt(d) + " " + array.get(cName, i)
                    cnt += 1
    alert(s, alert.freq_all)

// ---------- 窓の中
// 窓の終わり：D>N は 5:55（時間切れ0の決済は 5:55 の足の始値）、N>D は 15:44 の足の終値
endDN = false
endND = false
if wOn and not wLong and barstate.isconfirmed
    // 先物基準：予約していたエントリー（前の足で先物が届いた）→ この足の始値で入る
    if array.size(qId) > 0
        for j = 0 to array.size(qId) - 1
            i = array.get(qId, j)
            d = array.get(qDir, j)
            if f_can(i, d)
                E = o_
                f_open(i, d, E, E * array.get(cX, i) / 100, E * array.get(qFd, j) / 100)
        array.clear(qId), array.clear(qDir), array.clear(qFd)
    // 手じまい（時間切れ → 損切り → 利確の順で判定。同じ足で両方なら損切り）
    if array.size(pId) > 0
        for j = array.size(pId) - 1 to 0
            d = array.get(pDir, j)
            tp = array.get(pTP, j)
            sl = array.get(pSL, j)
            te = array.get(pTmEnd, j)
            same = array.get(pBar, j) == bar_index
            if te > 0 and time >= te
                f_close(j, o_, "時間切れ")
                anyExit := true
            else if (wKind == 0 and endDN)
                f_close(j, o_, "窓の終わり（5:55）")
                anyExit := true
            else if not na(sl) and (d > 0 ? l_ <= sl : h_ >= sl)
                f_close(j, d > 0 ? math.min(sl, same ? sl : o_) : math.max(sl, same ? sl : o_), "損切り")
                anyExit := true
            else if not na(tp) and (same ? (d > 0 ? c_ >= tp : c_ <= tp) : (d > 0 ? h_ >= tp : l_ <= tp))
                f_close(j, same ? tp : (d > 0 ? math.max(tp, o_) : math.min(tp, o_)), "利確")
                anyExit := true
            else if endND
                f_close(j, c_, "窓の終わり（引け）")
                anyExit := true
    // 先物の寄り
    isFutOpen = not fOpen and not na(fO) and ((wKind == 0 and hm == 1700) or (wKind == 1 and hm == 845))
    if isFutOpen
        fOpen := true
        fGap := (fO - Bf) / Bf * 100
        gapSign := fO > Bf ? 1 : fO < Bf ? -1 : 0
    // 現行：寄り後に CFD が基準に戻ったら窓が閉じる
    if fOpen and not wClosed and ((gapSign > 0 and l_ <= B) or (gapSign < 0 and h_ >= B))
        wClosed := true
    canNew = not (wKind == 0 and hh == 5 and mi >= 55)
    // 現行のエントリー（CFD が基準±乖離幅に先に届いた側）
    if canNew and not (fOpen and wClosed)
        for i = 0 to N - 1
            if array.get(cKind, i) == wKind and array.get(cDef, i) == 0 and array.get(cDone, i) == 0
                x = array.get(cX, i)
                U = B * (1 + x / 100)
                L = B * (1 - x / 100)
                hu = h_ >= U
                hl = l_ <= L
                if hu and hl
                    array.set(cDone, i, 1)
                else if hu or hl
                    array.set(cDone, i, 1)
                    up = hu
                    d = array.get(cSide, i) == 0 ? (up ? -1 : 1) : (up ? 1 : -1)
                    if not (array.get(cSell, i) and d != -1) and f_cond(i, up) and f_can(i, d)
                        E = reo ? c_ : (up ? math.max(U, o_) : math.min(L, o_))
                        f_open(i, d, E, B * x / 100, math.abs(E - B))
    // 先物基準のエントリー（寄りで届いていれば寄りの CFD 始値、寄り後に届いたら次の足の始値）
    if fOpen and not fBack and gapSign != 0 and canNew
        up = gapSign > 0
        back = up ? fL <= Bf : fH >= Bf
        gp = math.abs(fGap)
        for i = 0 to N - 1
            if array.get(cKind, i) == wKind and array.get(cDef, i) == 1 and array.get(cDone, i) == 0 and not na(fH)
                x = array.get(cX, i)
                d = array.get(cSide, i) == 0 ? (up ? -1 : 1) : (up ? 1 : -1)
                if isFutOpen and gp >= x
                    array.set(cDone, i, 1)
                    if not (array.get(cSell, i) and d != -1) and f_cond(i, up) and f_can(i, d)
                        f_open(i, d, o_, o_ * x / 100, o_ * gp / 100)
                else if not back
                    Lf = Bf * (1 + (up ? x : -x) / 100)
                    if up ? fH >= Lf : fL <= Lf
                        array.set(cDone, i, 1)
                        if not (array.get(cSell, i) and d != -1) and f_cond(i, up)
                            array.push(qId, i), array.push(qDir, d), array.push(qFd, x)
                            alert("【まもなく入る】先物が " + f_fmt(Lf) + " に届いた → 次の足の始値で " + f_dirtxt(d) + " #" + str.tostring(i + 1) + " " + array.get(cName, i), alert.freq_all)
        if back
            fBack := true
    // 接近アラート（その向きで一番近い候補の80%、窓ごと・向きごとに1回）
    for u = 0 to 1
        up = u == 0
        if (up and not apUp) or (not up and not apDn)
            best = 0.0
            bi = -1
            for i = 0 to N - 1
                if array.get(cKind, i) == wKind and array.get(cDone, i) == 0
                    isF = array.get(cDef, i) == 1
                    if not isF or fOpen
                        x = array.get(cX, i)
                        base = isF ? Bf : B
                        px = isF ? (up ? fH : fL) : (up ? h_ : l_)
                        prog = na(px) ? 0.0 : (up ? (px - base) : (base - px)) / (base * x / 100)
                        d = array.get(cSide, i) == 0 ? (up ? -1 : 1) : (up ? 1 : -1)
                        if prog > best and prog < 1 and not (array.get(cSell, i) and d != -1) and f_cond(i, up)
                            best := prog
                            bi := i
            if bi >= 0 and best >= APPROACH
                if up
                    apUp := true
                else
                    apDn := true
                isF = array.get(cDef, bi) == 1
                x = array.get(cX, bi)
                base = isF ? Bf : B
                alert("【近づいた】" + f_kindtxt(wKind) + (up ? " 上へ " : " 下へ ") + (isF ? "先物 " : "CFD ") + "#" + str.tostring(bi + 1) + " 入る値段 " + f_fmt(base * (1 + (up ? x : -x) / 100)) + " " + array.get(cName, bi), alert.freq_all)
    if endDN or endND
        wOn := false

// ---------- チャートに描く（最後の足で描き直す）
SHOW_LV = input.int(3, "向きごとに表示する入る値段の数", minval = 0, maxval = 8)
LBL_GAP = input.float(1.0, "ラベルの間隔（文字の高さの何倍）", minval = 0.5, maxval = 3, step = 0.1)
TBL_DARK = input.bool(true, "表をダークモード用の色にする")
TBL_SIZE = input.string("normal", "表の文字の大きさ", options = ["small", "normal", "large"])
TBL_POS = input.string("右下", "表の位置", options = ["右上", "右下", "左下", "左上"])
rng300 = ta.highest(h_, 300) - ta.lowest(l_, 300)
var array<line>  dL = array.new<line>(0)
var array<label> dB = array.new<label>(0)
var array<float>  qY = array.new<float>(0)
var array<string> qT = array.new<string>(0)
var array<color>  qC = array.new<color>(0)
f_lab(int x, float y, string t, color c) =>
    array.push(qY, y), array.push(qT, t), array.push(qC, c)
f_line(int x1, float y, color c, string st) =>
    array.push(dL, line.new(x1, y, bar_index + 30, y, color = c, width = 1, style = st == "dot" ? line.style_dotted : st == "dash" ? line.style_dashed : line.style_solid))
if barstate.islast
    for l in dL
        line.delete(l)
    for b in dB
        label.delete(b)
    array.clear(dL), array.clear(dB), array.clear(qY), array.clear(qT), array.clear(qC)
    x0 = bar_index + 2
    if wOn and not wLong and not na(B)
        ratio = na(fLast) ? 1.0 : c_ / fLast          // 先物 → CFD の換算（今の差）
        f_line(bar_index - 30, B, color.blue, "dot")
        f_lab(x0, B, "基準 CFD " + f_fmt(B) + (na(Bf) ? "" : " / 先物 " + f_fmt(Bf)), color.blue)
        // 入る値段：向きごとに、まだ入っていない・条件を満たす候補のうち、今の値段に近い順
        totalShown = 0
        nLeft = 0
        for u = 0 to 1
            up = u == 0
            idx = array.new<int>(0)
            dist = array.new<float>(0)
            for i = 0 to N - 1
                if array.get(cKind, i) == wKind and array.get(cDone, i) == 0
                    nLeft += 1
                    isF = array.get(cDef, i) == 1
                    d = array.get(cSide, i) == 0 ? (up ? -1 : 1) : (up ? 1 : -1)
                    ok = not anyExit and not (array.get(cSell, i) and d != -1) and f_cond(i, up) and not (isF and fBack) and not (not isF and fOpen and wClosed)
                    if isF and fOpen
                        ok := ok and (up ? gapSign > 0 : gapSign < 0)
                    if ok
                        x = array.get(cX, i)
                        lvF = (isF ? Bf : B) * (1 + (up ? x : -x) / 100)
                        lvC = isF ? lvF * ratio : lvF
                        array.push(idx, i)
                        array.push(dist, math.abs(lvC - c_))
            n = array.size(idx)
            shown = 0
            if n > 0
                ord = array.sort_indices(dist, order.ascending)
                for k = 0 to n - 1
                    if shown >= SHOW_LV
                        break
                    i = array.get(idx, array.get(ord, k))
                    isF = array.get(cDef, i) == 1
                    x = array.get(cX, i)
                    lvF = (isF ? Bf : B) * (1 + (up ? x : -x) / 100)
                    lvC = isF ? lvF * ratio : lvF
                    d = array.get(cSide, i) == 0 ? (up ? -1 : 1) : (up ? 1 : -1)
                    prog = (up ? (c_ - B) : (B - c_)) / (B * x / 100)
                    col = prog >= APPROACH ? color.orange : (d > 0 ? color.teal : color.maroon)
                    f_line(bar_index - 30, lvC, col, "dash")
                    w_ = (isF ? lvF : B) * x / 100
                    dd = isF ? lvF * x / 100 : math.abs(lvF - B)
                    tp = array.get(cSide, i) == 0 ? lvC + d * dd * array.get(cFR, i) : (array.get(cSK, i) > 0 ? lvC + d * w_ * array.get(cSK, i) : na)
                    sl = array.get(cSide, i) == 0 ? (array.get(cSK, i) > 0 ? lvC - d * w_ * array.get(cSK, i) : na) : lvC - d * dd * array.get(cFR, i)
                    t = "#" + str.tostring(i + 1) + " " + f_dirtxt(d) + " " + f_fmt(lvC) + (isF ? "（先物 " + f_fmt(lvF) + "で成行）" : "（指値・逆指値）") + "  利確 " + (na(tp) ? "なし" : f_fmt(tp)) + " 損切り " + (na(sl) ? "なし" : f_fmt(sl)) + (array.get(cTM, i) > 0 ? " 時間 " + str.tostring(array.get(cTM, i)) + "分" : "") + "  " + array.get(cName, i)
                    f_lab(x0, lvC, t, col)
                    shown += 1
                    totalShown += 1
        // 入る値段が1本も出ないときは、理由を出す
        if totalShown == 0
            why = anyExit ? "この窓は手じまいが出たので、もう入りません（入り直しなし）" : nLeft == 0 ? "この窓の候補は、すべて入った・判定済みです" : (fOpen and wClosed and fBack) ? "窓が閉じた（基準に戻った）ので、もう入りません" : "今、条件を満たす候補はありません"
            f_lab(x0, c_, why + "\n次の窓：" + (wKind == 1 ? "D>N（15:45 に基準が決まる）" : "N>D（CFD 再開時に基準が決まる）"), color.gray)
    else
        f_lab(x0, c_, "窓なし（" + (wLong ? "休日のため使わない窓" : "基準が決まるまで待ち") + "）\n次の窓：D>N は 15:45、N>D は CFD 再開時に基準が決まる", color.gray)
    // 持っているポジション：入った値段・利確・損切り
    if array.size(pId) > 0
        for j = 0 to array.size(pId) - 1
            i = array.get(pId, j)
            d = array.get(pDir, j)
            E = array.get(pE, j)
            tp = array.get(pTP, j)
            sl = array.get(pSL, j)
            te = array.get(pTmEnd, j)
            x1 = array.get(pBar, j)
            f_line(x1, E, color.gray, "solid")
            if not na(tp)
                f_line(x1, tp, color.green, "solid")
                f_lab(x0, tp, "利確 " + f_fmt(tp) + " #" + str.tostring(i + 1), color.green)
            if not na(sl)
                f_line(x1, sl, color.red, "solid")
                f_lab(x0, sl, "損切り " + f_fmt(sl) + " #" + str.tostring(i + 1), color.red)
            f_lab(x0, E, str.tostring(j + 1) + "本目 " + f_dirtxt(d) + " " + f_fmt(E) + " #" + str.tostring(i + 1) + " 時間切れ " + (te > 0 ? str.format_time(te, "HH:mm", "Asia/Tokyo") : "窓の終わり"), color.gray)
    // ラベルを値段の順に並べ、近すぎるものは上にずらす（ずらしたものは元の値段へ点線でつなぐ）
    nL = array.size(qY)
    if nL > 0
        gap = rng300 * 0.035 * LBL_GAP
        ord = array.sort_indices(qY, order.ascending)
        prev = -1e18
        for k = 0 to nL - 1
            m = array.get(ord, k)
            y = array.get(qY, m)
            ya = math.max(y, prev + gap)
            prev := ya
            c = array.get(qC, m)
            array.push(dB, label.new(x0 + 4, ya, array.get(qT, m), style = label.style_label_left, color = color.new(c, 30), textcolor = color.white, size = size.normal))
            array.push(dL, line.new(bar_index + 1, y, x0 + 4, ya, color = c, style = line.style_dotted, width = 1))

// ---------- 表
var table tb = table.new(TBL_POS == "右上" ? position.top_right : TBL_POS == "左下" ? position.bottom_left : TBL_POS == "左上" ? position.top_left : position.bottom_right, 2, 6, border_width = 1)
if SHOW_TBL and barstate.islast
    bgH = TBL_DARK ? color.rgb(42, 46, 57) : color.rgb(225, 230, 240)
    bgC = TBL_DARK ? color.rgb(19, 23, 34) : color.white
    fg  = TBL_DARK ? color.white : color.black
    fgK = TBL_DARK ? color.rgb(178, 181, 190) : color.rgb(80, 80, 80)
    ts  = TBL_SIZE == "small" ? size.small : TBL_SIZE == "large" ? size.large : size.normal
    table.set_border_color(tb, TBL_DARK ? color.rgb(67, 70, 81) : color.rgb(200, 200, 200))
    table.set_frame_color(tb, TBL_DARK ? color.rgb(67, 70, 81) : color.rgb(200, 200, 200))
    table.set_frame_width(tb, 1)
    hdr = array.from("窓", "基準 CFD / 先物", "先物の寄り", "持っている本数", "この窓で手じまい")
    vals = array.from(wOn ? f_kindtxt(wKind) + (wLong ? "（休日で使わない）" : "") : "なし", f_fmt(B) + " / " + f_fmt(Bf), fOpen ? str.tostring(fGap, "#.##") + "%" : "まだ", str.tostring(array.size(pId)) + " / 2", anyExit ? "あり（新しく入らない）" : "なし")
    if not chart.is_standard
        table.cell(tb, 0, 5, "注意", bgcolor = color.rgb(120, 30, 30), text_color = color.white, text_size = ts)
        table.cell(tb, 1, 5, "ふつうのローソク足ではないチャートです（計算は本物の値段で行っています）", bgcolor = color.rgb(120, 30, 30), text_color = color.white, text_size = ts)
    for r = 0 to 4
        table.cell(tb, 0, r, array.get(hdr, r), bgcolor = bgH, text_color = fgK, text_size = ts, text_halign = text.align_left)
        hot = (r == 3 and array.size(pId) > 0) or (r == 4 and anyExit)
        table.cell(tb, 1, r, array.get(vals, r), bgcolor = bgC, text_color = hot ? color.orange : fg, text_size = ts, text_halign = text.align_left)
'''
for k, v in (('__KIND__', kind), ('__DEF__', dfn), ('__SIDE__', side), ('__SELL__', sell), ('__X__', xs), ('__FR__', fr), ('__SK__', sk), ('__TM__', tm), ('__NAME__', nm)):
    pine = pine.replace(k, v)
open(W + '/08/results/窓埋め61本_v0.7_骨組み.pine', 'w').write(pine)
print(len(pine.splitlines()), 'lines')
