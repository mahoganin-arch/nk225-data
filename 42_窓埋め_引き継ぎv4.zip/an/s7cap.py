# 5-1 上限管理（順張り、両方の窓・条件なし）：損失が膨らんだら止め、止めている間も仮想売買で成績を追って再開する
#   止める条件（事前に固定）：
#     DD基準   … 実際の損益のピークからの下落が X円（2,000／3,000／4,000）に達したら停止
#     直近成績 … ルール自体（実際＋仮想）の直近N回（50／100）の合計がマイナスなら停止
#   再開の条件（事前に固定）：
#     DD基準   … (a) 停止後の仮想損益の合計がプラスに戻る  (b) ルール自体の直近50回の合計がプラス
#                再開時にピークを現在の資産に置き直す
#     直近成績 … 直近N回の合計がプラスに戻ったら再開
#   評価：最大DD、合計、合計÷最大DD、最悪の年、前半・後半の合計、停止回数、入った割合
import numpy as np, pandas as pd
from lib import *
SP = 13.0
Y, en, F, F2 = setup('順張り'); ev = pd.read_pickle(W + '/T/evt.pkl'); NE = len(ev); Bp = ev.B.values[en.ev.values]
ok = ~en.long.values; both = np.isin(en.kind.values, ['D>N', 'N>D']); yr_ev = ev.t0.dt.year.values
def series(x, ex):
    r = np.nonzero(ok & both & np.isclose(en.x.values, x))[0]; s = np.full(NE, np.nan)
    s[en.ev.values[r]] = np.asarray(Y[r, ex], float) / 100 * P - SP * P / Bp[r]; return s
def maxdd(v):
    c = np.cumsum(v); return float((np.maximum.accumulate(np.r_[0, c])[1:] - c).max()) if len(v) else np.nan
def run_dd(v, X, resume, n_res=50):
    """v: 発生順の損益（ルール自体）。戻り値: 入ったかどうか(bool配列)、停止回数"""
    on = np.zeros(len(v), bool); live = True; eq = 0.0; peak = 0.0; virt = 0.0; stops = 0
    for i, p in enumerate(v):
        if not live:
            if resume == 'a': ready = virt > 0
            else: ready = i >= n_res and v[i - n_res:i].sum() > 0
            if ready: live = True; peak = eq
        if live:
            on[i] = True; eq += p; peak = max(peak, eq)
            if peak - eq >= X: live = False; virt = 0.0; stops += 1
        else: virt += p
    return on, stops
def run_recent(v, n):
    on = np.zeros(len(v), bool); stops = 0; prev = True
    for i in range(len(v)):
        cur = i < n or v[i - n:i].sum() > 0
        if prev and not cur: stops += 1
        on[i] = cur; prev = cur
    return on, stops
def gates(v):
    g = {'常に入る': (np.ones(len(v), bool), 0)}
    for X in (2000, 3000, 4000):
        g['DD%d円・再開a(仮想合計>0)' % X] = run_dd(v, X, 'a'); g['DD%d円・再開b(直近50回>0)' % X] = run_dd(v, X, 'b')
    for n in (50, 100): g['直近%d回<0で停止' % n] = run_recent(v, n)
    return g
def evaluate(base, v, y, rows):
    for gname, (on, stops) in gates(v).items():
        a = v[on]; ya = y[on]; tot = a.sum(); dd = maxdd(a)
        yrs = {str(k): a[ya == k].sum() for k in range(2017, 2027)}; yrs_has = [a[ya == k].sum() for k in np.unique(y)]
        r = {'対象': base, '上限管理': gname, '入った割合%': on.mean() * 100, '件数': int(on.sum()), '停止回数': stops, '合計': tot, '前半合計': a[ya <= 2021].sum(), '後半合計': a[ya >= 2022].sum(),
             '最大DD': dd, '合計÷最大DD': tot / dd if dd > 0 else np.nan, '後半最大DD': maxdd(a[ya >= 2022]), '最悪の年': min(yrs_has), '止めた分の合計': v[~on].sum()}
        r.update(yrs); rows.append(r)
rows = []
RULES = [('中間：0.9%・戻り90%・利確×0.6・引け', .9, (0.9, .6, 0)), ('後半型：0.9%・戻り90%・利確×1.5・引け', .9, (0.9, 1.5, 0)), ('前半型：0.8%・戻り125%・利確×0.75・120分', .8, (1.25, .75, 120))]
for name, x_, exk in RULES:
    s = series(x_, CBI[exk]); t = ~np.isnan(s); evaluate('固定 ' + name, s[t], yr_ev[t], rows)
# 前向き検証の記録（年ごとに選び直したルール）
REC = pd.read_pickle(W + '/S2rec.pkl'); PK = pd.read_pickle(W + '/S2pick.pkl')
for scn in ('WF全期間', 'WF後半', 'WF直近3年'):
    pk = PK[(PK['評価'] == scn) & (PK['窓'] == '両方の窓') & (PK['戦略'] == '条件なし') & (PK['選び方'] == '周辺')]
    s_all = np.full(NE, np.nan)
    for _, p in pk.iterrows():
        s = series(p['乖離幅'], CBI[(round(p['決済'][0], 3), round(p['決済'][1], 3), int(p['決済'][2]))]); m = yr_ev == p['確かめる年']; s_all[m] = s[m]
    t = ~np.isnan(s_all); evaluate('前向き検証 ' + scn + '（周辺）', s_all[t], yr_ev[t], rows)
O = pd.DataFrame(rows); O.to_pickle(W + '/S7cap.pkl')
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 200)
print(O.drop(columns=[str(k) for k in range(2017, 2027)]).round(1).to_string(index=False))
