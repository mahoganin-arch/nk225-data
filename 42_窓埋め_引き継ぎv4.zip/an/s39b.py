exec(open('s39diag.py').read().split("print('\\n--- Pineだけ")[0].replace("print(", "(lambda *a, **k: None)("))
for _, p in po.iterrows():
    r = S.iloc[p.id - 1]; key = (r['定義'], r['向き']); en, F, FL = get(key); x = float(r['乖離幅(%)'])
    ev = pd.read_pickle(DS[key] + '/evt.pkl')
    mm = p.t.tz_convert('UTC').value // 60_000_000_000
    near = ev.index[(ev.qm0 <= mm + 1) & (ev.qm0 > mm - 14 * 60)] if 'qm0' in ev else []
    rows = en[(np.isclose(en.x, x)) & (np.abs(en.m - mm) <= 20 * 60)]
    out = [(pd.Timestamp(int(m) * 60, unit='s', tz='UTC').tz_convert('Asia/Tokyo').strftime('%m-%d %H:%M'), int(d), ev.loc[e, 't0'].strftime('%m-%d %H:%M')) for e, m, d in rows[['ev', 'm', 'd']].values]
    print(p.t.strftime('%m-%d %H:%M'), '#%d' % p.id, 'x=%s' % x, 'Pine dir', p.dir, '| Py rows:', out)
