# 追加検証3（決済を固定）・4（指標単位）。seed>0 なら条件をイベント単位で入れ替えた偶然版
import sys, time, numpy as np, pandas as pd, scipy.sparse as sp
from lib import *
side = sys.argv[1]; seed = int(sys.argv[2]); dd = W + ('/R' if side == '逆張り' else '/T')
Y, en, F, F2 = setup(side); mp = perm_map(en, seed); Fp = F.iloc[mp].reset_index(drop=True); F2p = F2.iloc[mp].reset_index(drop=True)
fam = pd.read_pickle(dd + '/resel_fam.pkl'); NF = len(fam)
two = fam['指標2'] != ''; groups = fam[two].groupby(['指標1', '指標2', '窓']).groups; singles = fam[~two]
XP = sorted(en.x.unique()); NX = len(XP); SN = ['D>N', 'N>D', '両方の窓']
# 固定する決済：(0) 全1,944決済の平均、(1) 条件なしで前半に最良だった決済（窓×乖離幅ごと）
res = {k: np.full((NF, NX), np.nan, np.float32) for k in ('nA', 'nB', 'LA0', 'LB0', 'LA1', 'LB1')}
ind = []
t0 = time.time()
def tt(v, bb): return (v.mean() - bb) / (v.std(ddof=1) / np.sqrt(len(v)) + 1e-9)
for xi, x in enumerate(XP):
    idx = np.nonzero((~en.long.values) & np.isclose(en.x.values, x))[0]
    kind = en.kind.values[idx]; half = en.half.values[idx]; segm = {s: np.isin(kind, g) for s, g in SEGS.items()}
    Yx = np.asarray(Y[idx], dtype=np.float32) / 100 * P; f1 = Fp.iloc[idx]; f2 = F2p.iloc[idx]; isB = half == 'B'
    col0 = Yx.mean(1); ebest = {}; base = {}
    for s, m in segm.items():
        ebest[s] = int(np.argmax(Yx[m & ~isB].mean(0)))
        base[s] = (col0[m & ~isB].mean(), col0[m & isB].mean(), Yx[m & ~isB, ebest[s]].mean(), Yx[m & isB, ebest[s]].mean())
    cols = {s: Yx[:, ebest[s]] for s in segm}
    # 3. 候補群（条件）ごと
    cache = {}
    def codes(k):
        if k not in cache:
            dct = b3lab(k, f2[k].values.astype(float)); labs = list(dct); c = np.full(len(idx), -1, np.int16)
            for i, lab in enumerate(labs): c[dct[lab]] = i
            cache[k] = (c, {lab: i for i, lab in enumerate(labs)})
        return cache[k]
    fid_l = []; rows_l = []
    for (a, b_, w), ids in groups.items():
        ca, la = codes(a); cb, lb = codes(b_); key = np.where(segm[w] & (ca >= 0) & (cb >= 0), ca * 64 + cb, -1)
        o = np.argsort(key, kind='stable'); ks = key[o]
        for i in ids:
            l1 = fam.at[i, '区分1']; l2 = fam.at[i, '区分2']
            if l1 not in la or l2 not in lb: continue
            t = la[l1] * 64 + lb[l2]; s0, s1 = np.searchsorted(ks, [t, t + 1])
            if s1 > s0: fid_l.append(i); rows_l.append(o[s0:s1].astype(np.int32))
    c1 = {}
    for i, r in singles.iterrows():
        if r['指標1'] not in c1: c1[r['指標1']] = dict(bins_for(f1[r['指標1']].values.astype(float), None))
        lab = ('=' + r['区分1'][1:]) if r['区分1'].startswith('値') else r['区分1']
        if lab in c1[r['指標1']]:
            rr = np.nonzero(segm[r['窓']] & c1[r['指標1']][lab])[0]
            if len(rr): fid_l.append(i); rows_l.append(rr.astype(np.int32))
    fid = np.array(fid_l); lens = np.array([len(v) for v in rows_l]); allr = np.concatenate(rows_l); del rows_l
    own = np.repeat(np.arange(len(fid), dtype=np.int32), lens); rr_ = own * 2 + isB[allr].astype(np.int32)
    M = sp.csr_matrix((np.ones(len(rr_), np.float32), (rr_, allr)), shape=(len(fid) * 2, len(idx)))
    Z = np.stack([col0, np.ones(len(idx), np.float32)] + [cols[s] for s in SN], 1)
    S = (M @ Z).reshape(len(fid), 2, -1); nA = S[:, 0, 1]; nB = S[:, 1, 1]; ok = (nA > 0) & (nB > 0)
    wi = fam['窓'].values[fid]; wcol = np.array([SN.index(w) for w in wi]) + 2
    bb = np.array([base[w] for w in wi])
    f = fid[ok]; Sa = S[ok]; wc = wcol[ok]; ar = np.arange(ok.sum()); b2 = bb[ok]
    res['nA'][f, xi] = nA[ok]; res['nB'][f, xi] = nB[ok]
    res['LA0'][f, xi] = Sa[:, 0, 0] / nA[ok] - b2[:, 0]; res['LB0'][f, xi] = Sa[:, 1, 0] / nB[ok] - b2[:, 1]
    res['LA1'][f, xi] = Sa[ar, 0, wc] / nA[ok] - b2[:, 2]; res['LB1'][f, xi] = Sa[ar, 1, wc] / nB[ok] - b2[:, 3]
    del M, S, allr, own, rr_
    # 4. 指標単独の全区分（候補群に残ったかどうかに関係なく、全指標・全区分）
    for k in [c for c in F.columns if c != '時']:
        for lab, mk in bins_for(f1[k].values.astype(float), None):
            for w, m in segm.items():
                rr = np.nonzero(m & mk)[0]; hb = isB[rr]
                if (~hb).sum() < 20 or hb.sum() < 20: continue
                b = base[w]; c = cols[w][rr]; v0 = col0[rr]
                ind.append((k, lab, w, x, (~hb).sum(), hb.sum(), v0[~hb].mean() - b[0], v0[hb].mean() - b[1], c[~hb].mean() - b[2], c[hb].mean() - b[3],
                            tt(v0[~hb], b[0]), tt(v0[hb], b[1]), tt(c[~hb], b[2]), tt(c[hb], b[3])))
    print('x', x, round(time.time() - t0), 's', flush=True)
np.savez_compressed(dd + '/t34_%d.npz' % seed, **res)
pd.DataFrame(ind, columns=['指標', '区分', '窓', '乖離幅%', '前半件数', '後半件数', '前半上乗せ_全決済', '後半上乗せ_全決済', '前半上乗せ_固定', '後半上乗せ_固定', '前半t_全決済', '後半t_全決済', '前半t_固定', '後半t_固定']).to_pickle(dd + '/t4_%d.pkl' % seed)
print('saved')
