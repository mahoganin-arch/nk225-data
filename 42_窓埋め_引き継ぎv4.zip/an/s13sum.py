# 運用方針の比較のまとめと Excel
#   設定（評価の形×選び方×候補の集まり×N×順位の基準×入り直し）ごとに方針を並べ、どの設定でも同じ結論になるかを見る
import glob, numpy as np, pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
W = '/home/claude/work'
R = pd.concat([pd.read_pickle(f) for f in glob.glob(W + '/S13sim_*.pkl')], ignore_index=True)
PN = {'S': 'S 最良1本', 'A1': 'A1 先着1本', 'A2': 'A2 ドテン', 'B': 'B 両建て', 'C1': 'C1 同じ向き2本', 'C2': 'C2 同じ向き2本(独立)', 'D1': 'D1 両建て＋2本目', 'D2': 'D2 両建て＋2本目(独立)'}
R['方針名'] = R['方針'].map(PN)
key = ['評価', '選び方', '候補の集まり', 'N', '入り直し', '順位の基準']
# A1（先着1本）を基準にした差
base = R[R['方針'] == 'A1'][key + ['年あたり合計', '最大DD', '合計割る最大DD', '最悪の1窓']].rename(columns=lambda c: c if c in key else 'A1:' + c)
X = R[(R['方針'] != 'S') & (R['N'] > 1)].merge(base, on=key)
for c in ('年あたり合計', '最大DD', '合計割る最大DD', '最悪の1窓'): X[c + 'の差(A1比)'] = X[c] - X['A1:' + c]
agg = X.groupby('方針名').agg(設定の数=('年あたり合計', 'size'), 年あたり合計_中央=('年あたり合計', 'median'), 最大DD_中央=('最大DD', 'median'), 合計割る最大DD_中央=('合計割る最大DD', 'median'),
                            最悪の1窓_中央=('最悪の1窓', 'median'), 年合計がA1より多い割合=('年あたり合計の差(A1比)', lambda v: (v > 0).mean() * 100),
                            合計DDがA1より良い割合=('合計割る最大DD の差(A1比)'.replace(' ', ''), lambda v: (v > 0).mean() * 100), 最大DDがA1より小さい割合=('最大DDの差(A1比)', lambda v: (v < 0).mean() * 100)).reset_index()
# 設定ごとに最良の方針（合計÷最大DD／年あたり合計）
best = X.loc[X.groupby(key)['合計割る最大DD'].idxmax()]['方針名'].value_counts().rename('合計÷DDで1位の回数')
best2 = X.loc[X.groupby(key)['年あたり合計'].idxmax()]['方針名'].value_counts().rename('年合計で1位の回数')
agg = agg.merge(best, left_on='方針名', right_index=True, how='left').merge(best2, left_on='方針名', right_index=True, how='left').fillna({'合計÷DDで1位の回数': 0, '年合計で1位の回数': 0})
# 2本目：そろったときの1回あたり平均 vs 1本目
two = R[R['方針'].isin(['C1', 'C2', 'D1', 'D2']) & (R['N'] > 1)].groupby('方針名').agg(二本目の平均_中央=('二本目の平均', 'median'), 一本目の平均_中央=('一本目の平均', 'median'), 二本目の数_中央=('二本目の数', 'median'),
        二本目が一本目より良い割合=('二本目の平均', lambda v: np.nan)).reset_index()
tmp = R[R['方針'].isin(['C1', 'C2', 'D1', 'D2']) & (R['N'] > 1)]
two['二本目が一本目より良い割合'] = two['方針名'].map(tmp.assign(b=tmp['二本目の平均'] > tmp['一本目の平均']).groupby('方針名')['b'].mean() * 100)
# 入り直しの効果
re = R[R['N'] > 1].pivot_table(index=['評価', '選び方', '候補の集まり', 'N', '順位の基準', '方針名'], columns='入り直し', values=['年あたり合計', '合計割る最大DD', '最大DD']).reset_index()
re.columns = [a if not b and b is not False else '%s(入り直し%s)' % (a, 'あり' if b else 'なし') for a, b in re.columns]
reagg = re.groupby('方針名').apply(lambda g: pd.Series({'年合計の差(あり−なし)_中央': (g['年あたり合計(入り直しあり)'] - g['年あたり合計(入り直しなし)']).median(),
                                                     '合計÷DDの差_中央': (g['合計割る最大DD(入り直しあり)'] - g['合計割る最大DD(入り直しなし)']).median(),
                                                     '最大DDの差_中央': (g['最大DD(入り直しあり)'] - g['最大DD(入り直しなし)']).median(),
                                                     '入り直しで合計÷DDが良くなる割合': ((g['合計割る最大DD(入り直しあり)'] > g['合計割る最大DD(入り直しなし)']).mean() * 100)})).reset_index()
# 感度：候補の集まり・N・順位の基準ごとの、方針の合計÷DD の中央値
sens = {k: X.pivot_table(index=k, columns='方針名', values='合計割る最大DD', aggfunc='median').round(2) for k in ('候補の集まり', 'N', '順位の基準', '評価', '選び方', '入り直し')}
R.to_pickle(W + '/S13all.pkl')
pd.set_option('display.width', 260); pd.set_option('display.max_columns', 30)
print(agg.round(1).to_string(index=False)); print(two.round(1).to_string(index=False)); print(reagg.round(2).to_string(index=False))
for k, v in sens.items(): print('---', k); print(v.to_string())
S1 = R[R['方針'] == 'S'].groupby(['評価', '選び方', '候補の集まり', '入り直し', '順位の基準'])[['年あたり合計', '最大DD', '合計割る最大DD', '件数']].median()
print('--- S 最良1本'); print(S1.groupby(level=['順位の基準']).median().round(1))
if __name__ == '__main__':
    OUT = W + '/08/results/S10_運用方針の比較.xlsx'
    desc = [
     ['この表について', '1口座・同時に最大1〜2本で、候補をどう組み合わせて運用するか（方針）を比べたもの。候補のトレードは前向き検証（年ごとに、その年より前のデータで乖離幅・決済を選んだもの）。13pt控除後、確かめる期間（WF全期間：2022〜26年、WF後半：2023〜26年）'],
     ['方針', 'S 最良1本：窓の種類ごとに選ぶ期間で最良の候補1本だけ／A1 先着1本／A2 ドテン：反対向きが出たらその値段で入れ替え／B 両建て：買い1・売り1まで／C1 同じ向き2本／C2 同じ向き2本（独立の候補だけ）／D1 両建て＋2本目（合計2本）／D2 D1の2本目を独立の候補だけ'],
     ['', '独立：入る側の条件の重なり（Ochiai）が0.3未満'],
     ['候補の集まりと順位', '窓の種類・向きごとに、選ぶ期間の成績で上位N本（N=1・5・10・20）。同時に出たら順位の高い候補を優先。順位の基準は1回あたり平均（合意）と合計（感度）。いずれも確かめる年より前のデータだけで決める'],
     ['', '候補の集まりの作り方（感度）：代表(0.5)・代表(0.4)・代表(0.6)（重なりのまとめの区切りを変えた代表）、代表(0.5・年件数順)（代表を年件数で選ぶ）、全候補'],
     ['入り直し', 'なし：その窓で一度手じまったら終わり／あり：先物が寄り後に前セッションの終値に届く（窓が閉まる）までは入り直す'],
     ['確認したこと', 'D>N と N>D の保有時間は重ならない（次の窓の入る時刻より後まで持つトレードは0件）。候補のトレード一覧の1年ごとの成績は、これまでの評価と一致（40件の抜き取りで不一致0）。ドテンの手じまい値段・損益を手計算で確認'],
     ['注意', '使う候補は2026年までの成績を見て残したもの。組み合わせの評価は前向き検証の形だが、候補選びの段階の当てはめは残る。最終判断はフォワード'],
     ['シート', '方針のまとめ／2本目／入り直し／感度（設定ごとの方針の合計÷最大DD の中央値）／全件'],
    ]
    with pd.ExcelWriter(OUT, engine='openpyxl') as w:
        pd.DataFrame(desc, columns=['項目', '内容']).to_excel(w, sheet_name='説明', index=False)
        agg.round(2).to_excel(w, sheet_name='方針のまとめ', index=False); two.round(1).to_excel(w, sheet_name='2本目', index=False); reagg.round(2).to_excel(w, sheet_name='入り直し', index=False)
        r0 = 0
        for k, v in sens.items():
            pd.DataFrame({k: ['【%s】' % k]}).to_excel(w, sheet_name='感度', startrow=r0, index=False, header=False); v.reset_index().to_excel(w, sheet_name='感度', startrow=r0 + 1, index=False); r0 += len(v) + 4
        R.drop(columns=['方針']).round(2).to_excel(w, sheet_name='全件', index=False)
    wb = load_workbook(OUT)
    for ws in wb:
        for row in ws.iter_rows():
            for c in row: c.font = Font(name='Arial', size=10, bold=c.row == 1)
        for c in ws[1]: c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
        for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = 14
    ws = wb['説明']; ws.column_dimensions['A'].width = 16; ws.column_dimensions['B'].width = 150
    for c in ws['B']: c.alignment = Alignment(wrap_text=True, vertical='top')
    wb.save(OUT); print(OUT)
