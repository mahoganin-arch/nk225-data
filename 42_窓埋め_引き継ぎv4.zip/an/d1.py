# D：単独指標の全区分について、効果の安定性を詳しく見る
#   上乗せ = 区分に入ったエントリーの平均 − 同じ窓・乖離幅・半期（または年）の条件なしの平均
#   成績の測り方：(全) 1,944決済の平均 / (固) 条件なしで前半に最良だった決済
#   追加：境目を前半だけで決めた版、外れ値を抑えた版、日足ATRで補正した版、年ごとの上乗せ
import sys, time, numpy as np, pandas as pd
from lib import *
side = sys.argv[1]; dd = W + ('/R' if side == '逆張り' else '/T')
Y, en, F, F2 = setup(side); XP = sorted(en.x.unique()); YRS = np.arange(2017, 2027)
atr = F['atr_D'].values.astype(float); atr = np.where(np.isnan(atr), np.nanmedian(atr), atr); ATRMED = np.nanmedian(atr)
FEATS = [c for c in F.columns if c != '時']
def bins_frozen(v, train):
    """bins_for と同じ区分を、境目だけ train（前半）のデータで決める"""
    ok = ~np.isnan(v); u = np.unique(v[ok]); out = []
    if len(u) <= 6:
        for x in u: out.append(('=%g' % x, v == x))
        return out
    vt = v[train & ok]
    q3 = np.quantile(vt, [1 / 3, 2 / 3]); b3 = np.searchsorted(q3, v, side='right')
    for i, lab in enumerate(['3分割:低', '3分割:中', '3分割:高']): out.append((lab, ok & (b3 == i)))
    q5 = np.quantile(vt, [.2, .4, .6, .8]); b5 = np.searchsorted(q5, v, side='right')
    for i in range(5): out.append(('5分割:%d' % (i + 1), ok & (b5 == i)))
    lo, hi = np.quantile(vt, [.1, .9]); out.append(('下位10%', ok & (v <= lo))); out.append(('上位10%', ok & (v >= hi)))
    return out
rows = []; t0 = time.time()
for xi, x in enumerate(XP):
    idx = np.nonzero((~en.long.values) & np.isclose(en.x.values, x))[0]
    kind = en.kind.values[idx]; isB = en.half.values[idx] == 'B'; yr = en.yr.values[idx] - 2017
    Yx = np.asarray(Y[idx], dtype=np.float32) / 100 * P; f1 = F.iloc[idx]
    col0 = Yx.mean(1).astype(np.float64); segm = {s: np.isin(kind, g) for s, g in SEGS.items()}
    norm = ATRMED / atr[idx]
    M = {}                                                                       # 測り方ごとの1トレード損益
    for s, m in segm.items():
        e = int(np.argmax(Yx[m & ~isB].mean(0))); c1 = Yx[:, e].astype(np.float64)
        M[s] = {'全': col0, '固': c1, '全_補正': col0 * norm, '固_補正': c1 * norm}
    # 外れ値を抑えた版：窓×乖離幅ごとに、条件なし全体の1%・99%点で切る
    for s, m in segm.items():
        for k in ('全', '固'):
            v = M[s][k]; lo, hi = np.quantile(v[m], [.01, .99]); M[s][k + '_抑制'] = np.clip(v, lo, hi)
    KS = ['全', '固', '全_補正', '固_補正', '全_抑制', '固_抑制']
    # 条件なしの基準（窓×測り方：半期・年）
    base = {}
    for s, m in segm.items():
        for k in KS:
            v = M[s][k]; base[s, k] = (v[m & ~isB].mean(), v[m & isB].mean(), np.array([v[m & (yr == j)].mean() if (m & (yr == j)).any() else np.nan for j in range(10)]))
    for feat in FEATS:
        vals = f1[feat].values.astype(float)
        full = dict(bins_for(vals, None)); froz = dict(bins_frozen(vals, ~isB))
        for lab, mk in full.items():
            mf = froz.get(lab)
            for s, m in segm.items():
                r = m & mk; a = r & ~isB; b = r & isB
                nA, nB = int(a.sum()), int(b.sum())
                if nA < 20 or nB < 20: continue
                rec = {'指標': feat, '区分': lab, '窓': s, '乖離幅%': x, '前半件数': nA, '後半件数': nB}
                for k in KS:
                    v = M[s][k]; bA, bB, bY = base[s, k]
                    rec['前半_' + k] = v[a].mean() - bA; rec['後半_' + k] = v[b].mean() - bB
                    if k in ('全', '固'):
                        sa = v[a].std(ddof=1) / np.sqrt(nA); sb = v[b].std(ddof=1) / np.sqrt(nB)
                        rec['前半t_' + k] = rec['前半_' + k] / (sa + 1e-9); rec['後半t_' + k] = rec['後半_' + k] / (sb + 1e-9)
                        cnt = np.bincount(yr[r], minlength=10); sm = np.bincount(yr[r], weights=v[r], minlength=10)
                        ly = np.where(cnt >= 3, sm / np.maximum(cnt, 1) - bY, np.nan)
                        for j in range(10): rec['%d_%s' % (2017 + j, k)] = ly[j]; rec['%d件数' % (2017 + j)] = cnt[j]
                        # 1年ずつ除いたときの半期の上乗せ（最小・最大）
                        for h, hm, yy in (('前半', a, range(0, 5)), ('後半', b, range(5, 10))):
                            lo = []
                            for j in yy:
                                keep = hm & (yr != j); keepu = m & (isB if h == '後半' else ~isB) & (yr != j)
                                if keep.sum() >= 10: lo.append(v[keep].mean() - v[keepu].mean())
                            rec[h + '_1年除外最小_' + k] = min(lo) if lo else np.nan; rec[h + '_1年除外最大_' + k] = max(lo) if lo else np.nan
                # 境目を前半だけで決めた版（後半のみ意味がある）
                if mf is not None:
                    bf = m & mf & isB
                    if bf.sum() >= 10:
                        rec['後半件数_前半境目'] = int(bf.sum())
                        for k in ('全', '固'): rec['後半_前半境目_' + k] = M[s][k][bf].mean() - base[s, k][1]
                rows.append(rec)
    print('x', x, len(rows), round(time.time() - t0), 's', flush=True)
D = pd.DataFrame(rows); D.to_pickle(dd + '/d1.pkl'); print('saved', D.shape)
