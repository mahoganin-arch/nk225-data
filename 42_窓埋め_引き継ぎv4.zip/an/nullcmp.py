# 実データ（seed 0）と、条件ラベルを入れ替えた偶然（seed 1〜）で、通過する候補群の数を比べる
import sys, glob, numpy as np, pandas as pd
from lib import W
from prep import runs
side = sys.argv[1]; dd = W + ('/R' if side == '逆張り' else '/T')
SELN = ['前半で優位', '後半で優位', '両方で優位']; rows = []
for f in sorted(glob.glob(dd + '/null_*.npz')):
    seed = int(f.split('_')[-1].split('.')[0]); z = np.load(f); sc = z['best_sc'][:, :, 0]; n, mr = runs(z['passbits'][:, :, 0])
    for si in range(3):
        ok = sc[:, si] > -1e8
        r = {'seed': seed, '種別': '実データ' if seed == 0 else '偶然', '選び方': SELN[si], '通過': int(ok.sum())}
        for t in (50, 100, 150): r['スコア%d円以上' % t] = int((sc[:, si] >= t).sum())
        for t in (5, 10, 15): r['連続%d幅以上' % t] = int((mr[:, si] >= t).sum())
        r['連続10幅以上かつスコア50円以上'] = int(((mr[:, si] >= 10) & (sc[:, si] >= 50)).sum())
        rows.append(r)
D = pd.DataFrame(rows); pd.set_option('display.width', 250)
for si in SELN:
    S = D[D['選び方'] == si]; print('==', side, si); print(S.drop(columns='選び方').to_string(index=False))
D.to_csv(dd + '/nullcmp.csv', index=False)
