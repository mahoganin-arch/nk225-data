# 足の違いの確認：後半も5分足だけで計算した場合（T5）と、通常（2020/11以降1分足、T）の比較
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/work/01/code'); from common6 import *
W = '/home/claude/work'; SEGS = {'D>N': ['D>N'], 'N>D': ['N>D'], '両方の窓': ['D>N', 'N>D']}
CBI = {(round(a, 3), round(b, 3), int(c)): i for i, (a, b, c) in enumerate(CB)}
RULES = [('後半型：0.9%・戻り90%・利確×1.5・引け', .9, .9, 1.5, 0), ('後半型：0.9%・戻り80%・利確×2・引け', .9, .8, 2, 0),
         ('前半型：0.8%・戻り125%・利確×0.75・120分', .8, 1.25, .75, 120), ('中間：0.9%・戻り90%・利確×0.6・引け', .9, .9, .6, 0)]
rows = []
for tag in ('T', 'T5'):
    Y, en, F = load(W + '/' + tag) if tag == 'T' else (np.load(W + '/T5/Y.npy', mmap_mode='r'), None, None)
    if tag == 'T5':
        en = pd.read_pickle(W + '/T5/en.pkl'); ev = pd.read_pickle(W + '/T5/evt.pkl'); en = en.join(ev[['kind', 'long', 't0']], on='ev'); en['yr'] = en.t0.dt.year
    ev = pd.read_pickle(W + '/' + tag + '/evt.pkl'); Bp = ev.B.values[en.ev.values]
    for name, x, sl, tp, tm in RULES:
        idx = np.nonzero((~en.long.values) & np.isclose(en.x.values, x) & np.isin(en.kind.values, SEGS['両方の窓']))[0]
        e = CBI[(round(sl, 3), round(tp, 3), tm)]; v = np.asarray(Y[idx, e], float) / 100 * P - 13 * P / Bp[idx]; yr = en.yr.values[idx]
        r = {'足': '2020/11以降1分足' if tag == 'T' else '全期間5分足', 'ルール': name, '件数': len(v), '前半平均': v[yr <= 2021].mean(), '後半平均': v[yr >= 2022].mean()}
        for y in range(2017, 2027): r[str(y)] = v[yr == y].mean()
        rows.append(r)
    # 条件なし・全決済の平均（後半）を幅ごとに
    for x in (.6, .7, .8, .9, 1.0, 1.2):
        idx = np.nonzero((~en.long.values) & np.isclose(en.x.values, x) & np.isin(en.kind.values, SEGS['両方の窓']))[0]; yr = en.yr.values[idx]
        G = np.asarray(Y[idx], np.float32) / 100 * P - (13 * P / Bp[idx])[:, None]
        rows.append({'足': '2020/11以降1分足' if tag == 'T' else '全期間5分足', 'ルール': '全決済平均 幅%g' % x, '件数': len(idx), '前半平均': G[yr <= 2021].mean(), '後半平均': G[yr >= 2022].mean(),
                     **{str(y): G[yr == y].mean() for y in range(2017, 2027)}})
O = pd.DataFrame(rows); O.to_pickle(W + '/S2bar.pkl')
pd.set_option('display.width', 250); print(O.round(1).to_string(index=False))
