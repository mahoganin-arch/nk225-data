# 重なりでまとめた結果の Excel
import pandas as pd, numpy as np
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
W = '/home/claude/work'; OUT = W + '/08/results/S9_重なりでまとめた候補.xlsx'
C = pd.read_pickle(W + '/S12cands.pkl'); gs = pd.read_pickle(W + '/S12groups.pkl'); P = pd.read_pickle(W + '/S12pairs.pkl'); CF = pd.read_pickle(W + '/S12conf.pkl'); RO = pd.read_pickle(W + '/S12repov.pkl')
gs = gs.sort_values(['向き', '代表:中央'], ascending=[True, False])
cc = ['向き', 'グループ', '大グループ(0.3)', 'グループの安定性', 'グループ内の平均の似かた', '代表', 'グループ内順位', '出所', '定義', '窓', '名前', '使い方', 'テーマ', '後半のみ', 'x',
      '選び方数', '中央', '最小', 'プラス数', '年件数', '最大DD', '改善', '条件の該当数(2022-)', '入る窓の数(2022-)', '条件なしのうち入る割合', '指標', '区分', 'id']
desc = [
 ['この表について', 'これまでに残した候補（S7の指標、S6のSQ・祝日・月末月初と逆張りC・B、S2のATR系、条件なし）490件を、拾う窓の重なりでまとめたもの'],
 ['似かたの測り方', '乖離幅0.2〜1.5%の格子で、条件を満たす (セッション, 乖離幅) の集合を2022年以降で作り（1時間足の出来高は2023年以降）、Ochiai（共通 ÷ √(Aの数×Bの数)）で比べる。乖離幅の選び方に左右されないようにするため'],
 ['', '現行と先物基準はセッション番号で共通化（同じ窓を同じものとして数える）。「避ける」は外す集合どうしで比べる。条件なしはまとめの対象外'],
 ['まとめ方', '向き×種類（入る／避ける）ごとに平均連結の階層クラスタリング。似かた0.5で切ったものを「グループ」、0.3で切ったものを「大グループ」。0.4・0.6でも切り、グループが変わるかを「安定性」に記録（分かれる(0.6)／合わさる(0.4)／安定）'],
 ['代表の選び方', 'グループ内で ①単点・周辺の両方で残った ②5つの評価の形の最悪（最小）が高い ③年件数が多い の順。定義・窓・テーマが違うものから「2番目」も残す。メンバーはすべて残す（候補から外さない）'],
 ['結果', 'グループ数：順張り189（大グループ110）、逆張り69（大グループ46）。メンバー1件だけのグループが多く、候補の条件は互いにあまり重ならない。大きいグループは中身がまとまっている（週足・日足のトレンドが強い、5分の勢い、ATR、60分の位置など）'],
 ['', '同じ条件の現行と先物基準は25組すべて同じグループ。同じ条件の別の窓は42組中30組が同じグループ'],
 ['確認', '矛盾：「入る」候補の条件の半分以上が、同じ定義・窓の「避ける」候補の外す区分に入る組（71組。うち「避ける」の外す割合が5割未満のもの22組）。外す割合の大きい「避ける」（例：キリ250を越えた=1）は多くと重なるのが自然'],
 ['', '「入る」候補が条件なしの窓のうち入る割合は、ほとんど1〜3割（最大0.78）。ほぼ条件なしと同じ候補はない'],
 ['', '代表どうしの入る窓の重なり（代表の乖離幅、似かた0.3以上）：同時運用の段階で、同じ窓に重ねて入る組の目安'],
 ['シート', 'グループ一覧／候補とグループ（全490件）／似ている組（似かた0.4以上または入れ子0.8以上）／矛盾の確認／代表どうしの重なり'],
]
with pd.ExcelWriter(OUT, engine='openpyxl') as w:
    pd.DataFrame(desc, columns=['項目', '内容']).to_excel(w, sheet_name='説明', index=False)
    gs.round(2).to_excel(w, sheet_name='グループ一覧', index=False)
    C[cc].sort_values(['向き', 'グループ', 'グループ内順位']).round(2).to_excel(w, sheet_name='候補とグループ', index=False)
    P.round(2).to_excel(w, sheet_name='似ている組', index=False)
    CF.round(2).to_excel(w, sheet_name='矛盾の確認', index=False)
    RO.round(2).to_excel(w, sheet_name='代表どうしの重なり', index=False)
wb = load_workbook(OUT)
for ws in wb:
    for row in ws.iter_rows():
        for c in row: c.font = Font(name='Arial', size=10, bold=c.row == 1)
    for c in ws[1]: c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.freeze_panes = 'A2'
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = 12
ws = wb['説明']; ws.column_dimensions['A'].width = 14; ws.column_dimensions['B'].width = 150
for c in ws['B']: c.alignment = Alignment(wrap_text=True, vertical='top')
wb['候補とグループ'].column_dimensions['K'].width = 30; wb['グループ一覧'].column_dimensions['I'].width = 80
wb.save(OUT); print(OUT)
