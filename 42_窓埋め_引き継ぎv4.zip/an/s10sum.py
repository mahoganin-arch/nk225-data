# s10eval の結果をまとめ、残す基準で候補を選ぶ
#   残す：5つの評価の形のうち3つ以上でプラス、中央値+20円以上、年10件以上、かつ条件なし（同じ窓・選び方）より中央値で+20円以上良い
#   後半のみの指標は、2024年以降の確かめる期間で、条件なし(2024-)と比べる
import glob, numpy as np, pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
import sys; sys.path.insert(0, '/home/claude/work/01/code'); from common6 import jname
W = '/home/claude/work'
O = pd.concat([pd.read_pickle(f) for f in sorted(glob.glob(W + '/S10eval_*.pkl'))], ignore_index=True)
k = ['定義', '向き', '指標', '区分', '使い方', '後半のみ', '窓', '選び方']
G = O.groupby(k).agg(プラス数=('平均', lambda v: int((v > 0).sum())), 中央=('平均', 'median'), 最小=('平均', 'min'), 年件数=('年件数', 'median'), 最大DD=('最大DD', 'median'), 最悪=('最悪', 'min')).reset_index()
base = G[G['指標'].isin(['条件なし', '条件なし(2024-)'])][['定義', '向き', '窓', '選び方', '後半のみ', '中央']].rename(columns={'中央': '条件なし中央'})
G = G.merge(base, on=['定義', '向き', '窓', '選び方', '後半のみ'], how='left'); G['改善'] = G['中央'] - G['条件なし中央']
F6c = set(pd.read_pickle(W + '/T/F6.pkl').columns); G['新しい指標'] = ~G['指標'].isin(F6c) & ~G['指標'].str.startswith('条件なし')
TFJ = {'5m': '5分', '15m': '15分', '60m': '60分', '4h': '4時間', 'D': '日足', 'W': '週足'}
def nm(x):
    b, _, tf = x.rpartition('_')
    if tf in TFJ and (not b.isascii() or b.isupper()): return TFJ[tf] + b          # 新しい指標（日本語名_時間足、CCI）
    return jname(x)
G['指標名'] = [nm(x) for x in G['指標']]
G['残す'] = (G['プラス数'] >= 3) & (G['中央'] >= 20) & (G['年件数'] >= 10) & (G['改善'] >= 20) & ~G['指標'].str.startswith('条件なし')
G.to_pickle(W + '/S10sum.pkl')
K = G[G['残す']].sort_values(['向き', '定義', '窓', '改善'], ascending=[True, True, True, False])
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)
print(G.groupby(['定義', '向き'])['残す'].agg(['sum', 'size']))
print(K.groupby(['定義', '向き', '窓'])['新しい指標'].agg(['sum', 'size']))
cols = ['定義', '向き', '窓', '選び方', '指標名', '区分', '使い方', '後半のみ', '新しい指標', 'プラス数', '中央', '最小', '条件なし中央', '改善', '年件数', '最大DD', '最悪']
if __name__ == '__main__':
    OUT = W + '/08/results/S7_新しい指標.xlsx'
    desc = [
     ['この表について', '新しい指標（F7、103個）と既存の指標（F6、150個）の全区分を、逆張り・順張り × 現行・先物基準 × 3窓で、条件なし＋1つの条件（入る／避ける）として評価したもの。13pt控除後、円/回'],
     ['手順', '①ふるい：1,944決済の平均損益での上乗せが前半・後半で同じ向き、後半の中央t の絶対値≥1、後半の該当率3%以上。区分の境目は前半（2017〜21）だけで決定'],
     ['', '②評価：ふるいを通った区分を、ステップ2と同じ5つの評価の形・単点／周辺で評価（選ぶ期間で最悪−1,000円以上・15件以上）'],
     ['', '③残す：5つの形のうち3つ以上でプラス、中央値+20円以上、年10件以上、条件なし（同じ窓・選び方）より中央値で+20円以上良い'],
     ['後半のみの指標', '1時間足の出来高（前セッション最後1時間の出来高比、出来高最多価格まで／をまたいだ、出来高の多い価格帯の端まで）は2022/12以降しかないため、境目は2023年で決め、確かめる期間は2024年以降だけ'],
     ['キリ番', 'キリ250（250円刻みすべて）、キリ500（500円刻み）、キリ250・750のみ（下3桁が250・750の価格）を追加。既存の「節目まで」は1,000円刻み'],
     ['SQ値', '先物（ミニ・つなぎ）のSQ日の8:45の始値で近似し、11:00から使う'],
     ['シート', '候補：残す基準を満たしたもの／まとめ全件：評価した全区分／指標一覧：新しい指標の説明'],
    ]
    with pd.ExcelWriter(OUT, engine='openpyxl') as w:
        pd.DataFrame(desc, columns=['項目', '内容']).to_excel(w, sheet_name='説明', index=False)
        K[cols].round(1).to_excel(w, sheet_name='候補', index=False)
        G[cols + ['残す']].round(1).to_excel(w, sheet_name='まとめ全件', index=False)
        pd.DataFrame({'指標': pd.read_pickle(W + '/T/F7.pkl').columns}).to_excel(w, sheet_name='指標一覧', index=False)
    wb = load_workbook(OUT)
    for ws in wb:
        for row in ws.iter_rows():
            for c in row: c.font = Font(name='Arial', size=10, bold=c.row == 1)
        for c in ws[1]: c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
        ws.freeze_panes = 'A2'
        for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = 12
    ws = wb['説明']; ws.column_dimensions['A'].width = 16; ws.column_dimensions['B'].width = 150
    for ws_ in (wb['候補'], wb['まとめ全件']): ws_.column_dimensions['E'].width = 26
    wb['指標一覧'].column_dimensions['A'].width = 34
    wb.save(OUT); print(OUT, len(K))
