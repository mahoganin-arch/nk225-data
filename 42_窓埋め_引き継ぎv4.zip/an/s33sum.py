# s33tv の結果のまとめ：4時間足の区切り（Python／TradingView）で、残る候補がどう変わるか
import glob, numpy as np, pandas as pd
W = '/home/claude/work'
O = pd.concat([pd.read_pickle(f) for f in glob.glob(W + '/S33eval_*.pkl')], ignore_index=True)
S = pd.concat([pd.read_pickle(f) for f in glob.glob(W + '/S33scr_*.pkl')], ignore_index=True)
k = ['定義', '向き', '区切り', '売買', '窓', '指標', '区分', '使い方', '選び方']
G = O.groupby(k).agg(プラス数=('平均', lambda v: int((v > 0).sum())), 中央=('平均', 'median'), 最小=('平均', 'min'), 年件数=('年件数', 'median'), 最大DD=('最大DD', 'median')).reset_index()
base = G[G['指標'] == '条件なし'][['定義', '向き', '売買', '窓', '選び方', '中央']].rename(columns={'中央': '条件なし中央'})
G = G[G['指標'] != '条件なし'].merge(base, on=['定義', '向き', '売買', '窓', '選び方'], how='left'); G['改善'] = G['中央'] - G['条件なし中央']
scr = set(map(tuple, S[['定義', '向き', '区切り', '売買', '窓', '指標', '区分', '使い方']].values))
G['ふるい通過'] = [tuple(r) in scr for r in G[['定義', '向き', '区切り', '売買', '窓', '指標', '区分', '使い方']].values]
G['基準を満たす'] = (G['プラス数'] >= 3) & (G['中央'] >= 20) & (G['年件数'] >= 10) & np.where(G['売買'] == '両方', G['改善'] >= 20, True)
G['残す'] = G['基準を満たす'] & G['ふるい通過']
key = ['定義', '向き', '売買', '窓', '指標', '区分', '使い方']
K = G.groupby(key + ['区切り']).agg(残す=('残す', 'any'), 中央=('中央', 'mean'), プラス数=('プラス数', 'min'), 年件数=('年件数', 'mean'), 改善=('改善', 'mean')).reset_index()
P = K.pivot_table(index=key, columns='区切り', values=['残す', '中央', 'プラス数', '年件数'], aggfunc='first')
P.columns = ['%s_%s' % (a, b) for a, b in P.columns]; P = P.reset_index()
for c in ('残す_Python', '残す_TV'): P[c] = P[c].fillna(False).astype(bool)
P['結果'] = np.where(P['残す_Python'] & P['残す_TV'], '両方で残る', np.where(P['残す_Python'], 'Pythonだけ残る', np.where(P['残す_TV'], 'TVだけ残る', '両方で残らない')))
P.to_pickle(W + '/S33sum.pkl')
print(P.groupby(['売買', '結果']).size().unstack(fill_value=0))
# 今の候補一覧（売買する／記録だけ）にある4時間足の候補
A = pd.read_pickle(W + '/S26all.pkl'); Cc = pd.read_pickle(W + '/S21cands.pkl').set_index('id')
A = A.assign(指標=A['id'].map(Cc['指標']), 区分=A['id'].map(Cc['区分']), 窓=A['候補の窓'])
A = A[A['指標'].str.endswith('_4h', na=False)]
M = A[['扱い', '窓の種類'] + key + ['候補']].merge(P, on=key, how='left')
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 200)
print(M[['扱い', '窓の種類', '定義', '向き', '売買', '候補', '使い方', '結果', '中央_Python', '中央_TV', 'プラス数_Python', 'プラス数_TV']].round(1).to_string(index=False))
T = P[P['結果'] == 'TVだけ残る'].sort_values('中央_TV', ascending=False)
print(T[key + ['中央_Python', '中央_TV', 'プラス数_Python', 'プラス数_TV', '年件数_TV']].round(1).head(30).to_string(index=False))
