import sys; sys.path.insert(0, '/home/claude/work/01/code'); import ld, pandas as pd, numpy as np
c = ld.bars('data/c1.csv'); f = ld.bars('data/f5.csv')
c = c.set_index('t'); f = f.set_index('t')
W = [('2026-09-03 17:00', 64214), ('2026-09-04 08:45', 64667), ('2026-09-04 17:00', 65003), ('2026-09-09 08:45', 65058), ('2026-09-09 17:00', 65218), ('2026-09-10 08:45', 64368),
     ('2026-09-16 08:45', 63681), ('2026-09-18 08:45', 64956), ('2026-09-01 08:45', 65809), ('2026-09-02 08:45', 64865), ('2026-09-11 08:45', 64083), ('2026-09-15 08:45', 63391), ('2026-09-17 08:45', 64439)]
for t0, B in W:
    t = pd.Timestamp(t0, tz='Asia/Tokyo')
    co = c.loc[t:t + pd.Timedelta('2min')]; fo = f.loc[t - pd.Timedelta('5min'):t + pd.Timedelta('5min')]
    print(t0, 'B', B, '| CFD open', co.open.iloc[0] if len(co) else None, 'gapCFD', (co.open.iloc[0] - B) if len(co) else None, '| fut5', fo[['open']].T.to_dict('records'))
