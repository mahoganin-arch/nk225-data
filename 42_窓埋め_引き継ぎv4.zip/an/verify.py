from lib import *
import time
for side in ('逆張り', '順張り'):
    Y, en, F, F2 = setup(side); M = Masker(Y, en, F, F2)
    for sel in ('前半で最良', '後半で最良', '両方で最良'):
        d = readfam(side, sel).sample(400, random_state=1); bad = 0; t = time.time()
        for _, r in d.iterrows():
            rw = M.rows(r['乖離幅%'], r['窓'], r['指標1'], r['区分1'], r['指標2'], r['区分2']); c = M.xinfo(r['乖離幅%'])
            y = np.asarray(Y[c['idx'][rw], CBI[(round(r['利確'], 3), round(r['損切り'], 3), int(r['時間切れ']))]], float) / 100 * P; hh = c['half'][rw]
            for h, col in (('A', '前半'), ('B', '後半')):
                v = y[hh == h]
                if len(v) != int(r[col + '件数']) or (len(v) and abs(v.mean() - r[col + '平均']) > 0.6): bad += 1; break
        print(side, sel, '不一致', bad, '/ 400', round(time.time() - t, 1), 's', flush=True)
