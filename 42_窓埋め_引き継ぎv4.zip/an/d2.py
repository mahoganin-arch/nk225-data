# D の集計：指標×区分×窓ごとに、28乖離幅をまたいで安定性をまとめる
import sys, numpy as np, pandas as pd
from lib import W, jname
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 40); pd.set_option('display.max_colwidth', 40)
def summarize(side):
    dd = W + ('/R' if side == '逆張り' else '/T'); D = pd.read_pickle(dd + '/d1.pkl')
    K = ['指標', '区分', '窓']; YR = [str(y) for y in range(2017, 2027)]
    g = D.groupby(K)
    S = g.agg(幅の数=('乖離幅%', 'size'), 幅の最小=('乖離幅%', 'min'), 幅の最大=('乖離幅%', 'max'), 前半件数=('前半件数', 'median'), 後半件数=('後半件数', 'median')).reset_index()
    for k in ('全', '固'):
        A = g['前半_' + k].mean().values; B = g['後半_' + k].mean().values
        S['前半_' + k] = A; S['後半_' + k] = B
        dirn = np.where((A > 0) & (B > 0), 1, np.where((A < 0) & (B < 0), -1, 0)); S['向き_' + k] = dirn
        same = D.assign(s=np.sign(D['前半_' + k]) * np.sign(D['後半_' + k]) > 0, p=np.sign(D['前半_' + k])).groupby(K).apply(lambda d: d['s'].mean() * 100, include_groups=False).values
        S['同じ向きの幅%_' + k] = same
        S['強さ_' + k] = np.where(dirn != 0, dirn * np.minimum(np.abs(A), np.abs(B)), 0)
        S['前半t中央_' + k] = g['前半t_' + k].median().values; S['後半t中央_' + k] = g['後半t_' + k].median().values
        for v in ('補正', '抑制'):
            S['前半_%s_%s' % (k, v)] = g['前半_%s_%s' % (k, v)].mean().values; S['後半_%s_%s' % (k, v)] = g['後半_%s_%s' % (k, v)].mean().values
        S['後半_前半境目_' + k] = g['後半_前半境目_' + k].mean().values
        S['後半_1年除外の悪い側_' + k] = np.where(dirn >= 0, g['後半_1年除外最小_' + k].mean().values, g['後半_1年除外最大_' + k].mean().values)
        S['前半_1年除外の悪い側_' + k] = np.where(dirn >= 0, g['前半_1年除外最小_' + k].mean().values, g['前半_1年除外最大_' + k].mean().values)
        Yl = g[['%s_%s' % (y, k) for y in YR]].mean()
        Yl.columns = ['%s_%s' % (y, k) for y in YR]; Yl = Yl.reset_index(drop=True)
        S = pd.concat([S, Yl], axis=1)
        sgn = np.where(dirn == 0, np.sign(A + B), dirn)[:, None]
        S['同じ向きの年数_' + k] = (np.sign(Yl.values) == sgn).sum(1); S['年数_' + k] = np.isfinite(Yl.values).sum(1)
        # 頑健性チェック（向きが変わらないか）
        ok = dirn != 0
        for v, c in (('補正', ['前半_%s_補正' % k, '後半_%s_補正' % k]), ('抑制', ['前半_%s_抑制' % k, '後半_%s_抑制' % k]), ('前半境目', ['後半_前半境目_' + k]), ('1年除外', ['前半_1年除外の悪い側_' + k, '後半_1年除外の悪い側_' + k])):
            ck = np.ones(len(S), bool)
            for cc in c: ck &= np.sign(S[cc].values) == dirn
            S['維持_%s_%s' % (v, k)] = ok & ck
        S['維持数_' + k] = S[['維持_%s_%s' % (v, k) for v in ('補正', '抑制', '前半境目', '1年除外')]].sum(1)
    S['名前'] = [jname(a) for a in S['指標']]; S['系統'] = [a.rpartition('_')[0] if a.rpartition('_')[2] in ('5m', '15m', '60m', '4h', 'D', 'W') else a for a in S['指標']]
    S.to_pickle(dd + '/d2.pkl'); return S
if __name__ == '__main__':
    for side in sys.argv[1:]:
        S = summarize(side); print('=' * 30, side, '指標×区分×窓', len(S))
        for k in ('全', '固'):
            print('\n[測り方=%s] 向きの内訳' % ('全決済の平均' if k == '全' else '条件なしで前半最良の決済'), S['向き_' + k].value_counts().to_dict())
            for dn, nm in ((1, 'プラス（入る場面）'), (-1, 'マイナス（避ける場面）')):
                T = S[S['向き_' + k] == dn]
                print('  %s %d件 / 同じ向きの幅60%%以上 %d / 維持数4 %d / 維持数4かつ幅60%%以上 %d' % (nm, len(T), (T['同じ向きの幅%_' + k] >= 60).sum(), (T['維持数_' + k] == 4).sum(), ((T['維持数_' + k] == 4) & (T['同じ向きの幅%_' + k] >= 60)).sum()))
