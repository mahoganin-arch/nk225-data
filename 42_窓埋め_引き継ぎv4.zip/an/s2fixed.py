# 固定ルールの全期間の成績（参考：2025年までのデータで選んだ形なので 2026年のみが未使用データ）
import numpy as np, pandas as pd
from lib import *
pd.set_option('display.width', 250)
Y, en, F, F2 = setup('順張り'); ev = pd.read_pickle(W + '/T/evt.pkl'); Bp = ev.B.values[en.ev.values]
def maxdd(v):
    c = np.cumsum(v); return float((np.maximum.accumulate(np.r_[0, c])[1:] - c).max()) if len(v) else np.nan
def run(x, sl, tp, tm, win='両方の窓', sp=13):
    idx = np.nonzero((~en.long.values) & np.isclose(en.x.values, x) & np.isin(en.kind.values, SEGS[win]))[0]; idx = idx[np.argsort(en.m.values[idx])]
    e = CBI[(round(sl, 3), round(tp, 3), tm)]; g = np.asarray(Y[idx, e], float) / 100 * P; ppt = P / Bp[idx]; v = g - sp * ppt
    return idx, v, g, ppt
FR = [.1, .2, .3, .4, .5, .6, .7, .8, .9, 1.0, 1.25, 1.5]; SK = [0, .1, .2, .3, .4, .5, .6, .75, .9, 1, 1.25, 1.5, 2, 2.5, 3, 4, 5, 6]; TM = [0, 15, 30, 60, 90, 120, 180, 240, 360]
XP = sorted(en.x.unique())
RULES = [('後半型：0.9%・戻り90%・利確×1.5・引け', .9, .9, 1.5, 0), ('後半型：0.9%・戻り80%・利確×2・引け', .9, .8, 2, 0),
         ('前半型：0.8%・戻り125%・利確×0.75・120分', .8, 1.25, .75, 120), ('中間：0.9%・戻り90%・利確×0.6・引け', .9, .9, .6, 0)]
out = []; yr_rows = []
for name, x, sl, tp, tm in RULES:
    for win in ('両方の窓', 'D>N', 'N>D'):
        idx, v, g, ppt = run(x, sl, tp, tm, win); yr = en.yr.values[idx]
        r = {'ルール': name, '窓': win, '件数': len(v), '全期間平均': v.mean(), '前半平均': v[yr <= 2021].mean(), '後半平均': v[yr >= 2022].mean(), '2024-26平均': v[yr >= 2024].mean(), '2026平均(未使用)': v[yr == 2026].mean(), '2026件数': int((yr == 2026).sum()),
             '後半勝率%': (v[yr >= 2022] > 0).mean() * 100, '後半最悪': v[yr >= 2022].min(), '後半最大DD': maxdd(v[yr >= 2022]), '全期間最大DD': maxdd(v), '後半損益分岐pt': g[yr >= 2022].sum() / ppt[yr >= 2022].sum()}
        for y in range(2017, 2027): r[str(y)] = v[yr == y].mean()
        # 周辺（幅・損切り・利確・時間の隣）の後半平均の範囲
        xi = XP.index(min(XP, key=lambda q: abs(q - x))); fi = FR.index(sl); si = SK.index(tp); ti = TM.index(tm)
        SKo = SK[1:] + [0]; TMo = TM[1:] + [0]; sio = SKo.index(tp); tio = TMo.index(tm); nb = []
        for dx in (-1, 0, 1):
            for df in (-1, 0, 1):
                for ds in (-1, 0, 1):
                    for dt in (-1, 0, 1):
                        a, b_, c, d = xi + dx, fi + df, sio + ds, tio + dt
                        if 0 <= a < len(XP) and 0 <= b_ < 12 and 0 <= c < 18 and 0 <= d < 9:
                            i2, v2, _, _ = run(XP[a], FR[b_], SKo[c], TMo[d], win); y2 = en.yr.values[i2]; nb.append(v2[y2 >= 2022].mean())
        nb = np.array(nb); r['周辺の後半平均:最小'] = nb.min(); r['周辺の後半平均:中央'] = np.median(nb); r['周辺で後半プラス%'] = (nb > 0).mean() * 100; r['周辺数'] = len(nb)
        out.append(r)
O = pd.DataFrame(out); O.to_pickle(W + '/S2fixed.pkl')
print(O.round(1).to_string(index=False))
