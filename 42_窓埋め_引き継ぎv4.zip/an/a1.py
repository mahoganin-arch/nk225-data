# A：条件なし＋少数フィルター（前半で決めて後半で確かめる）
#   選び方：clean＝前半の成績だけでフィルターを選ぶ / D＝Dの候補（前半・後半の両方を見て選んだ）
#   決済：前半で、最悪の1回が -1000円以上の決済のうち平均が最も良いもの（なければ制約なし）
#   境目：3分割・5分割・上下10%の区切りは前半のデータだけで決める
import sys, time, numpy as np, pandas as pd
from lib import *
WORST = -1000; YRS = np.arange(2017, 2027)
def bins_frozen(v, train):
    ok = ~np.isnan(v); u = np.unique(v[ok]); out = {}
    if len(u) <= 6:
        for x in u: out['=%g' % x] = v == x
        return out
    vt = v[train & ok]
    q3 = np.quantile(vt, [1 / 3, 2 / 3]); b3 = np.searchsorted(q3, v, side='right')
    for i, lab in enumerate(['3分割:低', '3分割:中', '3分割:高']): out[lab] = ok & (b3 == i)
    q5 = np.quantile(vt, [.2, .4, .6, .8]); b5 = np.searchsorted(q5, v, side='right')
    for i in range(5): out['5分割:%d' % (i + 1)] = ok & (b5 == i)
    lo, hi = np.quantile(vt, [.1, .9]); out['下位10%'] = ok & (v <= lo); out['上位10%'] = ok & (v >= hi)
    return out
def pick(side, track, w, k=3):
    S = pd.read_pickle(W + ('/R' if side == '逆張り' else '/T') + '/d2.pkl'); S = S[S['窓'] == w]
    if track == 'clean':
        S = S.assign(sc=S['前半t中央_全'])
        pos = S[S.sc >= 1.5].sort_values('sc', ascending=False).drop_duplicates('系統').head(k)
        neg = S[S.sc <= -1.5].sort_values('sc').drop_duplicates('系統').head(k)
    else:
        C = S[(S['維持数_全'] == 4) & (S['同じ向きの幅%_全'] >= 60)].assign(sc=lambda d: d['強さ_全'].abs())
        pos = C[C['向き_全'] == 1].sort_values('sc', ascending=False).drop_duplicates('系統').head(k)
        neg = C[C['向き_全'] == -1].sort_values('sc', ascending=False).drop_duplicates('系統').head(k)
    return [(r['指標'], r['区分']) for _, r in pos.iterrows()], [(r['指標'], r['区分']) for _, r in neg.iterrows()]
def maxdd(v):
    c = np.cumsum(v); return float((np.maximum.accumulate(np.r_[0, c])[1:] - c).max()) if len(v) else np.nan
def evaluate(Ys, isB, yr, order):
    """Ys: エントリー×1,944決済の損益（円）。前半で決済を選び、両半期の成績を返す"""
    a = ~isB; b = isB
    if a.sum() < 20 or b.sum() < 20: return None
    YA = Ys[a]; mA = YA.mean(0); wA = YA.min(0); ok = wA >= WORST
    e = int(np.argmax(np.where(ok, mA, -1e9))) if ok.any() else int(np.argmax(mA))
    r = {'決済': CB[e], '最悪制約を満たす決済あり': bool(ok.any())}
    for h, m in (('前半', a), ('後半', b)):
        v = Ys[m, e]; o = np.argsort(order[m]); vs = v[o]; s = np.sort(v)
        r.update({h + '件数': int(m.sum()), h + '平均': v.mean(), h + '勝率': (v > 0).mean() * 100, h + '最悪': s[0], h + '2番目に悪い': s[1], h + '最大DD': maxdd(vs),
                  h + '合計': v.sum()})
        yy = yr[m]; cnt = np.bincount(yy - 2017, minlength=10); sm = np.bincount(yy - 2017, weights=v, minlength=10)
        for j in range(10):
            if cnt[j]: r['%d' % (2017 + j)] = sm[j] / cnt[j]
        ok3 = cnt >= 3; rng = range(0, 5) if h == '前半' else range(5, 10)
        r[h + 'プラス年'] = int(sum((sm[j] > 0) and ok3[j] for j in rng)); r[h + '年数'] = int(sum(ok3[j] for j in rng))
    mB = Ys[b].mean(0); top = np.argsort(-mA)[:max(1, len(mA) // 10)]
    r['後半プラス決済%'] = (mB > 0).mean() * 100; r['前半上位10%決済の後半平均'] = mB[top].mean()
    return r
rows = []; t0 = time.time()
YR_, en, F, F2 = setup('逆張り'); YT_ = np.load(W + '/T/Y.npy', mmap_mode='r')
XP = sorted(en.x.unique())
for w in SEGS:
    sel = {s: {tr: pick(s, tr, w) for tr in ('clean', 'D')} for s in ('逆張り', '順張り')}
    for s in sel:
        for tr in sel[s]: print(w, s, tr, '入る', sel[s][tr][0], '避ける', sel[s][tr][1], flush=True)
    for x in XP:
        idx = np.nonzero((~en.long.values) & np.isclose(en.x.values, x) & np.isin(en.kind.values, SEGS[w]))[0]
        if len(idx) < 60: continue
        isB = en.half.values[idx] == 'B'; yr = en.yr.values[idx]; order = en.m.values[idx]; f1 = F.iloc[idx]
        Y = {'逆張り': np.asarray(YR_[idx], dtype=np.float32) / 100 * P, '順張り': np.asarray(YT_[idx], dtype=np.float32) / 100 * P}
        cache = {}
        def mask(feat, lab):
            if feat not in cache: cache[feat] = bins_frozen(f1[feat].values.astype(float), ~isB)
            return cache[feat].get(('=' + lab[1:]) if lab.startswith('値') else lab, np.zeros(len(idx), bool))
        def add(side, track, name, keep, Ys=None):
            Ys = Y[side] if Ys is None else Ys
            r = evaluate(Ys[keep], isB[keep], yr[keep], order[keep])
            if r is not None: r.update({'方向': side, '選び方': track, '窓': w, '乖離幅%': x, '戦略': name}); rows.append(r)
        allm = np.ones(len(idx), bool)
        for side in ('逆張り', '順張り'):
            add(side, '-', '条件なし', allm)
            for tr in ('clean', 'D'):
                pos, neg = sel[side][tr]
                for f_, l_ in pos: add(side, tr, '入る:' + jname(f_) + '=' + l_, mask(f_, l_))
                for f_, l_ in neg: add(side, tr, '避ける:' + jname(f_) + '=' + l_, ~mask(f_, l_))
                anyp = np.zeros(len(idx), bool); anyn = np.zeros(len(idx), bool)
                for f_, l_ in pos: anyp |= mask(f_, l_)
                for f_, l_ in neg: anyn |= mask(f_, l_)
                if pos: add(side, tr, '入る:いずれか', anyp)
                if neg: add(side, tr, '避ける:すべて', ~anyn)
                if pos and neg: add(side, tr, '入る:いずれか＆避ける:すべて', anyp & ~anyn)
        # 切り替え：逆張りの「避ける」区分では順張り、それ以外は逆張り
        for tr in ('clean', 'D'):
            neg = sel['逆張り'][tr][1]; anyn = np.zeros(len(idx), bool)
            for f_, l_ in neg: anyn |= mask(f_, l_)
            if neg:
                Ysw = np.where(anyn[:, None], Y['順張り'], Y['逆張り'])
                add('切替', tr, '切替:避ける区分は順張り', allm, Ysw)
                add('切替', tr, '順張りのみ:逆張りの避ける区分', anyn, Y['順張り'])
    print(w, 'done', len(rows), round(time.time() - t0), 's', flush=True)
R = pd.DataFrame(rows); R.to_pickle(W + '/A1.pkl'); print('saved', R.shape)
