# A の集計：戦略ごとに、乖離幅を前半で選ぶ場合と、幅をまたいだ安定性
import numpy as np, pandas as pd
from lib import W
pd.set_option('display.width', 260); pd.set_option('display.max_columns', 40); pd.set_option('display.max_colwidth', 46)
R = pd.read_pickle(W + '/A1.pkl')
K = ['方向', '選び方', '窓', '戦略']
base = R[R['戦略'] == '条件なし'].set_index(['方向', '窓', '乖離幅%'])[['前半平均', '後半平均']]
def bk(r):
    side = '逆張り' if r['方向'] in ('逆張り', '切替') else r['方向']
    b = base.loc[(side, r['窓'], r['乖離幅%'])]; return pd.Series({'条件なし前半': b['前半平均'], '条件なし後半': b['後半平均']})
R = pd.concat([R, R.apply(bk, axis=1)], axis=1)
out = []
for key, g in R.groupby(K):
    g = g[g['前半件数'] >= 30]
    if g.empty: continue
    good = g[g['前半平均'] >= 20]
    best = g.loc[g['前半平均'].idxmax()]                                       # 前半で最良の幅
    rec = dict(zip(K, key))
    rec.update({'前半で選んだ幅': best['乖離幅%'], '決済(利確,損切り,時間)': best['決済'], '前半件数': best['前半件数'], '後半件数': best['後半件数'],
                '前半平均': best['前半平均'], '後半平均': best['後半平均'], '後半(条件なし)': best['条件なし後半'], '後半勝率': best['後半勝率'], '後半最悪': best['後半最悪'], '後半最大DD': best['後半最大DD'],
                '後半プラス年': best['後半プラス年'], '後半年数': best['後半年数'], '後半プラス決済%': best['後半プラス決済%'],
                '前半+20円以上の幅数': len(good), 'その幅の後半平均(中央)': good['後半平均'].median() if len(good) else np.nan,
                'その幅で後半プラス%': (good['後半平均'] > 0).mean() * 100 if len(good) else np.nan, 'その幅の後半(条件なし,中央)': good['条件なし後半'].median() if len(good) else np.nan})
    out.append(rec)
S = pd.DataFrame(out); S.to_pickle(W + '/A2.pkl')
cols = ['戦略', '前半で選んだ幅', '決済(利確,損切り,時間)', '前半件数', '後半件数', '前半平均', '後半平均', '後半(条件なし)', '後半最悪', '後半最大DD', '後半プラス年', '前半+20円以上の幅数', 'その幅の後半平均(中央)', 'その幅で後半プラス%', 'その幅の後半(条件なし,中央)']
for side in ('逆張り', '順張り', '切替'):
    for tr in ('clean', 'D'):
        for w in ('D>N', 'N>D', '両方の窓'):
            T = S[(S['方向'] == side) & (S['窓'] == w) & (S['選び方'].isin([tr, '-']))]
            if T.empty: continue
            print('\n==== %s / 選び方=%s / %s' % (side, '前半のみ' if tr == 'clean' else 'Dの候補（後半は参考）', w)); print(T[cols].round(1).to_string(index=False))
