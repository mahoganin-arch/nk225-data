# 「避ける」の使い方（除外／ロット半分）のまとめと Excel
import glob, numpy as np, pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
import sys; sys.path.insert(0, '/home/claude/work/01/code'); from common6 import jname
W = '/home/claude/work'
O = pd.concat([pd.read_pickle(f) for f in sorted(glob.glob(W + '/S11avoid_*.pkl'))], ignore_index=True)
k = ['定義', '向き', '窓', '選び方', '指標', '区分', '後半のみ', '使い方']
G = O.groupby(k).agg(プラス数=('一枚あたり平均', lambda v: int((v > 0).sum())), 年あたり合計=('年あたり合計', 'median'), 一枚あたり平均=('一枚あたり平均', 'median'),
                     最大DD=('最大DD', 'median'), 合計割る最大DD=('合計割る最大DD', 'median'), 年件数=('件数', 'median')).reset_index()
b = G[G['使い方'] == '条件なし'][['定義', '向き', '窓', '選び方', '後半のみ', '年あたり合計', '最大DD', '合計割る最大DD']].rename(columns=lambda c: c if c in ('定義', '向き', '窓', '選び方', '後半のみ') else '条件なし:' + c)
G = G[G['使い方'] != '条件なし'].merge(b, on=['定義', '向き', '窓', '選び方', '後半のみ'], how='left')
G['年合計の差'] = G['年あたり合計'] - G['条件なし:年あたり合計']; G['最大DDの差'] = G['最大DD'] - G['条件なし:最大DD']; G['合計÷DDの差'] = G['合計割る最大DD'] - G['条件なし:合計割る最大DD']
TFJ = {'5m': '5分', '15m': '15分', '60m': '60分', '4h': '4時間', 'D': '日足', 'W': '週足'}
def nm(x):
    b_, _, tf = x.rpartition('_')
    if tf in TFJ and (not b_.isascii() or b_.isupper()): return TFJ[tf] + b_
    return jname(x)
G['指標名'] = [nm(x) for x in G['指標']]
P = G.pivot_table(index=['定義', '向き', '窓', '選び方', '指標名', '区分', '後半のみ'], columns='使い方', values=['年合計の差', '最大DDの差', '合計÷DDの差', '一枚あたり平均'])
P.columns = [a + '(' + b + ')' for a, b in P.columns]; P = P.reset_index()
P['合計÷DDで良い方'] = np.where(P['合計÷DDの差(除外)'] >= P['合計÷DDの差(ロット半分)'], '除外', 'ロット半分')
G.to_pickle(W + '/S11sum.pkl'); P.to_pickle(W + '/S11piv.pkl')
pd.set_option('display.width', 250)
print(G.groupby(['向き', '使い方'])[['年合計の差', '最大DDの差', '合計÷DDの差']].median().round(2))
print(G.groupby(['向き', '使い方']).apply(lambda g: pd.Series({'年合計が増える%': (g['年合計の差'] > 0).mean() * 100, 'DDが減る%': (g['最大DDの差'] < 0).mean() * 100, '合計÷DDが良くなる%': (g['合計÷DDの差'] > 0).mean() * 100})).round(0))
print(P['合計÷DDで良い方'].value_counts())
if __name__ == '__main__':
    OUT = W + '/08/results/S8_避けるの使い方.xlsx'
    desc = [
     ['この表について', '「避ける」候補（S7の指標と、S6のSQ・祝日・月末月初）を、除外（その区分では入らない）とロット半分（その区分では0.5枚）で使った場合を、条件なし（常に1枚）と比べたもの。13pt控除後'],
     ['方法', '乖離幅と決済は、選ぶ期間の1枚あたり平均（Σ枚数×損益÷Σ枚数）で、単点／周辺の方法で選ぶ。5つの評価の形の確かめる期間で、年あたりの損益合計・1枚あたり平均・最大DD・合計÷最大DD を出し、5つの中央値で比べる'],
     ['', '1時間足の出来高の指標は、指標のある期間（2023年〜）のトレードだけで、確かめる期間は2024年以降'],
     ['見方', '「差」は、条件なし（同じ窓・選び方）との差。年合計の差はプラスが良い、最大DDの差はマイナスが良い、合計÷DDの差はプラスが良い'],
     ['シート', '比べ：候補ごとに除外とロット半分を横に並べたもの／全件：使い方ごとの全数値／評価の形ごと：5つの評価の形の個別の値'],
    ]
    with pd.ExcelWriter(OUT, engine='openpyxl') as w:
        pd.DataFrame(desc, columns=['項目', '内容']).to_excel(w, sheet_name='説明', index=False)
        P.round(2).to_excel(w, sheet_name='比べ', index=False)
        G.round(2).to_excel(w, sheet_name='全件', index=False)
        O.round(2).to_excel(w, sheet_name='評価の形ごと', index=False)
    wb = load_workbook(OUT)
    for ws in wb:
        for row in ws.iter_rows():
            for c in row: c.font = Font(name='Arial', size=10, bold=c.row == 1)
        for c in ws[1]: c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
        ws.freeze_panes = 'A2'
        for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = 12
    ws = wb['説明']; ws.column_dimensions['A'].width = 16; ws.column_dimensions['B'].width = 150
    wb['比べ'].column_dimensions['E'].width = 26
    wb.save(OUT); print(OUT)
