# 買い売り両方＋方向別の候補で、案3（前の付け方と前向きRFの上位を合わせる）の採用候補と前向き検証
#   区分（バケツ）：窓の種類（D>N・N>D）× 向き（順張り・逆張り）× 売買（両方・買いのみ・売りのみ）
#   前の付け方：その区分の代表から、t年のルールの選ぶ期間（〜t−1年）の1回平均（15件以上、その窓の種類のトレード）の順
#   新しい付け方：その区分の全候補から、前向き記録（2022〜t−1年、5×年数件以上、合計プラス、選ぶ期間2017〜21年もプラス）のRF順、重なりの同じグループは最上位だけ
#   合わせ方：区分ごとに両方の上位N本を合わせる。同時に出たときの優先順位（全区分共通）：①両方に入る ②2つの順位の良い方 ③前の付け方の順位
#   比べる候補の集まり：両方のみ（S17と同じ）／方向別のみ／両方＋方向別
#   確かめる期間：2024〜26年。方針：先着1本・同じ向き2本・両建て＋2本目、N=3・5
import sys, numpy as np, pandas as pd
sys.argv = [sys.argv[0]]
exec(open('/home/claude/work/08/an/s13sim.py').read().split("if __name__ == '__main__':")[0])
from s14report_funcs import stats, rule_text, cond_text
SCN, METH = 'WF全期間', '周辺'
C = pd.read_pickle(W + '/S21cands.pkl').set_index('id')
T0 = pd.read_pickle(W + '/S20trades.pkl'); T0 = T0[(T0['評価'] == SCN) & (T0['選び方'] == METH)]
PK = pd.read_pickle(W + '/S20picks.pkl')
WF = T0[T0['年'] == T0['t']]; SELP = T0[(T0['t'] == 2022) & (T0['年'] <= 2021)]
selsum = SELP.groupby(['id', '窓の種類'])['損益'].sum()
GRP = C['グループ']; SIDE = C['向き']; DIRN = C['売買']
REPS = set(C.index[C['代表'].isin(['代表', '基本'])])
# 両方の候補の代表は、S13 と同じ代表(0.5)を使う
REPS = (REPS - set(C.index[C['売買'] == '両方'])) | (set(C.index[C['売買'] == '両方']) & UNIV['代表(0.5)'])
BK = [(k, s, d) for k in ('D>N', 'N>D') for s in ('順張り', '逆張り') for d in ('両方', '買いのみ', '売りのみ')]
def rank_old(t):
    Tt = T0[(T0['t'] == t) & T0['id'].isin(REPS)]; out = {}
    for kind in ('D>N', 'N>D'):
        tk = Tt[(Tt['窓の種類'] == kind) & (Tt['年'] < t)]; ins = tk.groupby('id')['損益'].agg(['mean', 'size']); ins = ins[ins['size'] >= 15]['mean'].sort_values(ascending=False)
        for s_ in ('順張り', '逆張り'):
            for d_ in ('両方', '買いのみ', '売りのみ'): out[(kind, s_, d_)] = [i for i in ins.index if SIDE[i] == s_ and DIRN[i] == d_]
    return out
def rank_rf(t, end_incl=False):
    past = WF[(WF['年'] <= t) if end_incl else (WF['年'] < t)]; ny = (t - 2022 + 1) if end_incl else (t - 2022); minn = 20 if end_incl else 5 * ny
    g = past.sort_values('手じまう時刻').groupby(['id', '窓の種類'])['損益']
    sc = []
    for (i, kind), v in g:
        v = v.values
        if len(v) < minn or v.sum() <= 0 or selsum.get((i, kind), -1) <= 0: continue
        c = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, c])[1:] - c).max(); sc.append((i, kind, v.sum() / max(dd, 1.0)))
    S = pd.DataFrame(sc, columns=['id', 'kind', 'rf']).sort_values('rf', ascending=False); S['g'] = S['id'].map(GRP); S = S.drop_duplicates(['kind', 'g'])
    out = {}
    for kind in ('D>N', 'N>D'):
        sk = S[S['kind'] == kind]['id']
        for s_ in ('順張り', '逆張り'):
            for d_ in ('両方', '買いのみ', '売りのみ'): out[(kind, s_, d_)] = [i for i in sk if SIDE[i] == s_ and DIRN[i] == d_]
    return out
def union_list(old, rf, N, dirs):
    out = {}
    for key in BK:
        if key[2] not in dirs: continue
        a = old.get(key, [])[:N]; b = rf.get(key, [])[:N]; ids = list(dict.fromkeys(a + b))
        rows = [(i, i in a and i in b, a.index(i) + 1 if i in a else 99, b.index(i) + 1 if i in b else 99) for i in ids]
        rows.sort(key=lambda r: (not r[1], min(r[2], r[3]), r[2])); out[key] = rows
    return out
def simulate_u(N, pol, dirs):
    out = []
    for t in (2024, 2025, 2026):
        L = union_list(rank_old(t), rank_rf(t), N, dirs)
        allr = [(k, r) for k, rows in L.items() for r in rows]; allr.sort(key=lambda kr: (not kr[1][1], min(kr[1][2], kr[1][3]), kr[1][2]))
        pr = {(r[0], k[0]): p for p, (k, r) in enumerate(allr)}
        test = T0[(T0['t'] == t) & (T0['年'] == t)].copy(); test['順位'] = [pr.get((a, b), np.nan) for a, b in zip(test['id'], test['窓の種類'])]
        test = test[test['順位'].notna()].sort_values(['セッション', '入る時刻', '順位'])
        for s_, tr in test.groupby('セッション', sort=False):
            for h in run_window(tr.to_dict('records'), pol, False, fill.get(s_, np.inf)): h['確かめる年'] = t; out.append(h)
    return pd.DataFrame(out)
PR = []
for dn, dirs in (('両方のみ', ('両方',)), ('方向別のみ', ('買いのみ', '売りのみ')), ('両方＋方向別', ('両方', '買いのみ', '売りのみ')), ('売りのみ', ('売りのみ',)), ('買いのみ', ('買いのみ',)), ('両方＋売りのみ', ('両方', '売りのみ'))):
    for N in (3, 5):
        for pol, pn in (('A1', '先着1本'), ('C1', '同じ向き2本'), ('D1', '両建て＋2本目')):
            H = simulate_u(N, pol, dirs).sort_values('手じまう時刻'); r = stats(H['損益'].values, 3)
            r.update(候補の集まり=dn, 上位N本=N, 方針=pn, 最悪の1窓=H.groupby('セッション')['損益'].sum().min(), 使った候補数=H['id'].nunique(),
                     買い件数=int((H['向き'] == 1).sum()), 買い合計=H.loc[H['向き'] == 1, '損益'].sum(), 売り件数=int((H['向き'] == -1).sum()), 売り合計=H.loc[H['向き'] == -1, '損益'].sum())
            for y, g in H.groupby('確かめる年'): r['%d年' % y] = g['損益'].sum()
            PR.append(r); print(dn, N, pn, round(r['合計']), round(r['合計割る最大DD'], 2), flush=True)
PR = pd.DataFrame(PR); PR.to_pickle(W + '/S22port.pkl')
# ---- 今の採用候補（N=5）
old = rank_old(2026); rf = rank_rf(2026, end_incl=True); rows = []
for N in (5,):
    U = union_list(old, rf, N, ('両方', '買いのみ', '売りのみ'))
    for (kind, side, dname), lst in U.items():
        for p, (i, both, ro, rn) in enumerate(lst, 1):
            z = C.loc[i]; v = WF[(WF['id'] == i) & (WF['窓の種類'] == kind)].sort_values('手じまう時刻'); s = stats(v['損益'].values, None)
            pk = PK[(PK['id'] == i) & (PK['評価'] == SCN) & (PK['選び方'] == METH) & (PK['t'] == 2026)]
            yr = v.groupby('年')['損益'].sum()
            cond = '条件なし' if z['指標'] == '条件なし' else (('「%s」のときだけ入る' if z['使い方'] == '入る' else '「%s」のときは入らない') % z['名前'])
            r = dict(上位N本=N, 窓の種類=kind, 向き=side, 売買=dname, 優先順位=p, 候補=str(z['名前']).replace('=-0', '=0'), 使い方=z['使い方'], 条件=cond, 定義=z['定義'], 候補の窓=z['窓'], テーマ=z['テーマ'],
                     両方に入る=both, 前の付け方の順位=ro if ro < 99 else np.nan, 新しい付け方の順位=rn if rn < 99 else np.nan,
                     今のルール=rule_text(side, pk['乖離幅'].iloc[0], tuple(pk['決済'].iloc[0])) if len(pk) else '', id=i)
            r.update({'前向き:' + k: x for k, x in s.items()}); r['プラスの年'] = int((yr > 0).sum()); r['年の数'] = len(yr)
            for y in range(2022, 2027): r['%d年' % y] = yr.get(y, np.nan)
            rows.append(r)
U = pd.DataFrame(rows); U.to_pickle(W + '/S22list.pkl')
pd.set_option('display.width', 280); pd.set_option('display.max_colwidth', 32)
print(PR[['候補の集まり', '上位N本', '方針', '件数', '勝率', 'PF', '平均', '合計', '最大DD', '合計割る最大DD', '最悪の1窓', '買い合計', '売り合計', '2024年', '2025年', '2026年']].round(1).to_string(index=False))
print(U.groupby(['窓の種類', '向き', '売買']).size())
print(U[['窓の種類', '向き', '売買', '優先順位', '候補', '使い方', '定義', '両方に入る', '前の付け方の順位', '新しい付け方の順位', '前向き:件数', '前向き:PF', '前向き:平均', '前向き:最大DD']].round(2).to_string(index=False))
