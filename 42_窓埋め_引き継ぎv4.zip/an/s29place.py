# 「置いておける版」の前向き検証（2024〜26年）。売買する候補（各年の一覧＝s27topk と同じ、63本の決め方）
#   注文はその窓の基準が決まった時点（D>N 15:45、N>D 6:00 または朝の操作時刻）の指標で判定し、CFD の指値・逆指値＋利確・損切り（IFD-OCO）で置く
#   置く注文：買い・売りそれぞれ、全体の優先順位の上位2本まで（同じ向きで最大2本）。約定したら自動で持つ（反対向きの両建ても起こりうる）
#   シナリオ C：先物基準の候補も CFD の基準（引けた時の CFD）から計算した値段に置く。向きは決まっていないので両方向に置く
#   シナリオ F：現行の候補は置く。先物基準の候補は元のルール（先物で判定、CFD 成行）でアラートを見て入る。同じ向き2本・反対を持っていない・その窓で手じまいが出ていない時だけ入る
#   手じまい：E0＝検証どおり（時間切れも守る、D>N は 5:55）。E1＝時間切れは使わず、D>N の残りは朝の操作時刻、N>D の残りは 15:45 直前で決済
#   朝の操作時刻（AM）：D>N の残りの決済、N>D の注文を置く時刻。AM より前に値段を通り過ぎた N>D の注文は置かない
#   約定：指値・逆指値の値段に届いた足で約定。窓をあけて越えたら始値。利確・損切りは約定の次の足から。同じ足で両方なら損切り
import sys, numpy as np, pandas as pd
sys.argv = [sys.argv[0]]
src = open('/home/claude/work/08/an/s27topk.py').read(); exec(src[:src.index('PR = []\nfor K')])
sys.path.insert(0, '/home/claude/work/01/code'); import ld
from s10scr import load as load10, LATE
from s9cal import flags
P_ = 68800.0; SPT = 13.0
C = pd.read_pickle(W + '/S21cands.pkl').set_index('id')
PKw = PK[(PK['評価'] == 'WF全期間') & (PK['選び方'] == '周辺')].set_index(['id', 't'])
# ---- CFD 1分足と先物セッション
c5 = ld.bars(W + '/data/c5.csv', until='2026-10-09'); c1 = ld.bars(W + '/data/c1.csv', until='2026-10-09')
cx = pd.concat([c5[c5.m + 5 <= c1.m.iloc[0]], c1], ignore_index=True)
cm = cx.m.values; co = cx.open.values; ch = cx.high.values; cl = cx.low.values; cc = cx.close.values
f = ld.bars(W + '/data/f5.csv', until='2026-10-09'); f['sid'] = (f.m.diff() > 15).cumsum()
s = f.groupby('sid').agg(m0=('m', 'first'), m1=('m', 'last'), t0=('t', 'first')); lh = f.groupby('sid').t.last().dt.strftime('%H:%M')
s['end'] = np.where(lh.isin(['15:15', '15:45', '05:30', '06:00']), s.m1, s.m1 + 5); s = s.reset_index(drop=True)
# ---- 置く時点の指標（PL）としきい値
EVP = pd.read_pickle(W + '/PL/evt.pkl'); ENP = pd.read_pickle(W + '/PL/en.pkl')
FP = pd.concat([pd.read_pickle(W + '/PL/F6.pkl').drop(columns=['時']), pd.read_pickle(W + '/PL/F7.pkl')], axis=1)
FLP = flags(EVP)
RIX = {(e, round(x, 3), d): i for i, (e, x, d) in enumerate(zip(ENP.ev.values, ENP.x.values, ENP.d.values))}
DS = {('現行', '順張り'): W + '/T', ('先物基準', '順張り'): W + '/F6W/T6', ('現行', '逆張り'): W + '/R', ('先物基準', '逆張り'): W + '/F6W/R6'}
need = set()
for t in LS:
    for (i, k) in LS[t]: need.add(i)
CUT = {}
for key_d, d in DS.items():
    ids = [i for i in need if (C.at[i, '定義'], C.at[i, '向き']) == key_d and C.at[i, '指標'] != '条件なし']
    if not ids: continue
    Y, en, MN, F = load10(d); ok = ~en.long.values; yr = en.yr.values
    for i in ids:
        ind, kb = C.at[i, '指標'], C.at[i, '区分']
        if ind not in F.columns: CUT[i] = ('flag', ind); continue
        v = F[ind].values.astype(float); vt = v[ok & ~np.isnan(v) & ((yr == 2023) if ind in LATE else (yr <= 2021))]
        if kb.startswith('='): CUT[i] = ('eq', float(kb[1:])); continue
        if kb.startswith('3分割'): q = np.quantile(vt, [1 / 3, 2 / 3]); j = ['低', '中', '高'].index(kb[-1])
        elif kb.startswith('5分割'): q = np.quantile(vt, [.2, .4, .6, .8]); j = int(kb[-1]) - 1
        else:
            lo, hi = np.quantile(vt, [.1, .9]); CUT[i] = ('ge', hi) if kb == '上位10%' else ('le', lo); continue
        CUT[i] = ('rng', q[j - 1] if j > 0 else -np.inf, q[j] if j < len(q) else np.inf)
    del Y
def cond(i, ev_j, x, d):
    """置く時点の条件（d：窓の向き、上に離れた側の注文は d=-1）"""
    if C.at[i, '指標'] == '条件なし': return True
    r = RIX.get((ev_j, round(x, 3), d))
    if r is None: return False
    ct = CUT[i]
    if ct[0] == 'flag': inb = bool(FLP.iloc[ev_j][ct[1]]); v = 0.0
    else:
        v = float(FP.iloc[r][C.at[i, '指標']])
        if np.isnan(v): inb = False
        elif ct[0] == 'eq': inb = v == ct[1]
        elif ct[0] == 'ge': inb = v >= ct[1]
        elif ct[0] == 'le': inb = v <= ct[1]
        else: inb = ct[1] <= v < ct[2]
    if C.at[i, '後半のみ'] and ct[0] != 'flag' and np.isnan(v): return False
    return inb if C.at[i, '使い方'] != '避ける' else not inb
# ---- 1つのポジションの手じまい
def exit_of(k, E, dr, tp, sl, k_end, end_px, end_open, k_tm):
    """k：約定の足。tp/sl：値段（なしは nan）。期限は k_end の足（end_open なら始値、そうでなければ終値の end_px）。k_tm：時間切れの足の始値"""
    if k_tm is not None and k_tm <= k_end: last = k_tm - 1; fin = (k_tm, co[k_tm], '時間切れ')
    else: last = k_end - 1 if end_open else k_end; fin = (k_end, end_px, '期限')
    a = k + 1
    if a <= last:
        H = ch[a:last + 1]; L = cl[a:last + 1]; O = co[a:last + 1]
        it = np.nonzero((H >= tp) if dr > 0 else (L <= tp))[0] if not np.isnan(tp) else []
        isl = np.nonzero((L <= sl) if dr > 0 else (H >= sl))[0] if not np.isnan(sl) else []
        it = it[0] if len(it) else 10**9; isl = isl[0] if len(isl) else 10**9
        if isl < 10**9 and isl <= it: return a + isl, (min(sl, O[isl]) if dr > 0 else max(sl, O[isl])), '損切り'
        if it < 10**9: return a + it, (max(tp, O[it]) if dr > 0 else min(tp, O[it])), '利確'
    return fin
def run(scen, mode, AM, drop_tm=False, static2=True, oco=False, closerule='none', dyn=False, open_only=False):
    out = []
    EV6 = pd.read_pickle(W + '/F6W/T6/evt.pkl').set_index('i')
    for t in (2024, 2025, 2026):
        L = LS[t]
        live = T0[(T0['t'] == t) & (T0['年'] == t)]
        for j in EVP.index[(EVP.t0.dt.year == t) & ~EVP.long]:
            e = EVP.loc[j]; kind = e.kind; B = e.B; q = s.iloc[e.i]; qend = q.end; pend = e.pend
            ka = np.searchsorted(cm, pend + 1) if True else 0
            # 期限：D>N は朝の操作時刻（E0 は 5:55 の足の始値）、N>D は引け直前の足の終値
            if kind == 'D>N':
                if mode == 'E0': k_end = np.searchsorted(cm, qend - 5); endp = co[min(k_end, len(co) - 1)]
                else: k_end = np.searchsorted(cm, qend + (AM - 6) * 60); endp = co[min(k_end, len(co) - 1)]
                k_place = ka
            else:
                k_end = np.searchsorted(cm, qend) - 1; endp = cc[k_end]
                k_place = ka if (mode == 'E0' or AM <= 6) else np.searchsorted(cm, pend + (AM - 6) * 60)
            if k_end <= ka or k_end >= len(cm): continue
            # 置く注文
            cands = []
            for (i, kk), p in sorted(L.items(), key=lambda z: z[1]):
                if kk != kind: continue
                if scen in ('F', 'G') and C.at[i, '定義'] == '先物基準': continue
                if (i, t) not in PKw.index: continue
                x = float(PKw.loc[(i, t), '乖離幅']); FR, SK, TM = PKw.loc[(i, t), '決済']
                if drop_tm and TM > 0: continue
                side = C.at[i, '向き']
                for up in (True, False):
                    d = -1 if up else 1; dr = (-1 if up else 1) if side == '逆張り' else (1 if up else -1)
                    if C.at[i, '売買'] == '売りのみ' and dr != -1: continue
                    if C.at[i, '売買'] == '買いのみ' and dr != 1: continue
                    if not cond(i, j, x, d): continue
                    cands.append(dict(id=i, p=p, x=x, FR=FR, SK=SK, TM=TM, up=up, dr=dr, lv=B * (1 + x / 100) if up else B * (1 - x / 100), side=side, defn=C.at[i, '定義']))
            # 各注文の約定の足
            ko = np.searchsorted(cm, e.qm0)
            BIGK = 10**9
            for o in cands:
                o['k'] = BIGK
                if k_place > ka and ((ch[ka:k_place].max() >= o['lv']) if o['up'] else (cl[ka:k_place].min() <= o['lv'])): continue
                hit = np.nonzero(ch[k_place:k_end] >= o['lv'])[0] if o['up'] else np.nonzero(cl[k_place:k_end] <= o['lv'])[0]
                if len(hit): o['k'] = k_place + hit[0]
            # 窓が閉じた足（先物の寄り後、CFD が基準に戻った）
            zc = np.nonzero((cl[ko:k_end] <= B) & (ch[ko:k_end] >= B))[0]
            if closerule == 'gap':
                g0 = co[ko] - B if ko < len(co) else 0
                zc = np.nonzero(cl[ko:k_end] <= B)[0] if g0 > 0 else (np.nonzero(ch[ko:k_end] >= B)[0] if g0 < 0 else np.array([0]))
            kc = ko + zc[0] if len(zc) else BIGK
            if static2:
                sel = []
                for dr in (1, -1):
                    seen = []
                    for o in cands:
                        if o['dr'] == dr and o['id'] not in seen and len(seen) < 2: seen.append(o['id']); sel.append(o)
                cands = sel
            pos = []; done_ids = set()
            for o in sorted(cands, key=lambda o: (o['k'], o['p'])):
                k = o['k']
                if k >= BIGK: continue
                if oco and o['id'] in done_ids: continue
                if closerule == 'open' and k >= ko: continue
                if closerule == 'gap' and k >= ko and k >= kc: continue
                if dyn:
                    held = [h for h in pos if h['k'] <= k < h['kx']]
                    if any(h['kx'] <= k for h in pos): continue
                    if any(h['dr'] != o['dr'] for h in held) or sum(h['dr'] == o['dr'] for h in held) >= 2 or any(h['id'] == o['id'] for h in held): continue
                E = max(o['lv'], co[k]) if o['up'] else min(o['lv'], co[k])
                w = (B if o['defn'] == '現行' else E) * o['x'] / 100; dist = abs(E - B) if o['defn'] == '現行' else E * o['x'] / 100
                if o['side'] == '逆張り': tp = E + o['dr'] * dist * o['FR']; sl = E - o['dr'] * w * o['SK'] if o['SK'] > 0 else np.nan
                else: sl = E - o['dr'] * dist * o['FR']; tp = E + o['dr'] * w * o['SK'] if o['SK'] > 0 else np.nan
                k_tm = np.searchsorted(cm, cm[k] + o['TM']) if (mode == 'E0' and o['TM'] > 0) else None
                kx, px, why = exit_of(k, E, o['dr'], tp, sl, k_end, endp, kind == 'D>N', k_tm)
                pos.append(dict(id=o['id'], 種類='置く', k=k, kx=kx, E=E, X=px, dr=o['dr'], why=why)); done_ids.add(o['id'])
            if scen == 'F':
                lv_ = live[(live['セッション'] == e.i) & (live['窓の種類'] == kind)]
                lv_ = lv_[np.array([(a, kind) in L and C.at[a, '定義'] == '先物基準' for a in lv_['id']], bool)].copy() if len(lv_) else lv_
                lv_ = lv_.assign(p=[L[(a, kind)] for a in lv_['id']]).sort_values(['入る時刻', 'p'])
                for r in lv_.itertuples():
                    i = r.id; x = float(PKw.loc[(i, t), '乖離幅']); FR, SK, TM = PKw.loc[(i, t), '決済']
                    if drop_tm and TM > 0: continue
                    k = np.searchsorted(cm, r.入る時刻)
                    if open_only and r.入る時刻 > e.qm0 + 1: continue
                    if k >= k_end: continue
                    held = [h for h in pos if h['k'] <= k < h['kx']]
                    if any(h['kx'] <= k for h in pos): continue
                    if any(h['dr'] != r.向き for h in held) or sum(h['dr'] == r.向き for h in held) >= 2 or any(h['id'] == i for h in held): continue
                    E = r.入る値段; side = C.at[i, '向き']; gp = float(EV6.at[r.セッション, 'gap%']); fd = gp if gp >= x else x
                    w = E * x / 100; dist = E * fd / 100; dr = r.向き
                    if side == '逆張り': tp = E + dr * dist * FR; sl = E - dr * w * SK if SK > 0 else np.nan
                    else: sl = E - dr * dist * FR; tp = E + dr * w * SK if SK > 0 else np.nan
                    k_tm = np.searchsorted(cm, cm[k] + TM) if (mode == 'E0' and TM > 0) else None
                    kx, px, why = exit_of(k, E, dr, tp, sl, k_end, endp, kind == 'D>N', k_tm)
                    pos.append(dict(id=i, 種類='アラート', k=k, kx=kx, E=E, X=px, dr=dr, why=why))
            hedge = any(a['dr'] != b['dr'] and a['k'] < b['kx'] and b['k'] < a['kx'] for a in pos for b in pos)
            for h in pos:
                h.update(年=t, 窓=kind, セッション=e.i, 両建て=hedge, 損益=h['dr'] * (h['X'] - h['E']) / h['E'] * P_ - SPT * P_ / h['E'], 手じまう時刻=cm[h['kx']]); out.append(h)
    return pd.DataFrame(out)
if __name__ == '__main__':
    SCENS = ('F',); R = []; ALL = {}
    MG = {'a 置きっぱなし（上位2本・両方向）': dict(), 'b OCO＋先物の寄りで取消': dict(oco=True, closerule='open'), 'c OCO＋窓が閉じたら取消': dict(oco=True, closerule='gap')}
    for scen in SCENS:
        for mg, kw in MG.items():
            for mode, AM in (('E0', 6), ('E1', 6), ('E1', 7.5), ('E1', 8.5)):
                H = run(scen, mode, AM, **kw); ALL[(scen, mg, mode, AM)] = H
                H = H.sort_values('手じまう時刻'); r = stats(H['損益'].values, 3)
                r.update(シナリオ=scen, 管理=mg, 手じまい=mode, 朝の時刻=AM, 両建ての窓=H.loc[H['両建て'], 'セッション'].nunique())
                for y, g in H.groupby('年'): r['%d年' % y] = g['損益'].sum()
                for k_, g in H.groupby('窓'): r[k_] = g['損益'].sum()
                for k_, g in H.groupby('種類'): r['件数:' + k_] = len(g)
                for k_, g in H.groupby('why'): r['手じまい:' + k_] = len(g)
                R.append(r); print(scen, mg, mode, AM, round(r['合計']), round(r['合計割る最大DD'], 2), flush=True)
    R = pd.DataFrame(R); R.to_pickle(W + '/S29place_%s.pkl' % ''.join(SCENS)); pd.to_pickle(ALL, W + '/S29trades_%s.pkl' % ''.join(SCENS))
    pd.set_option('display.width', 320)
    print(R[['シナリオ', '管理', '手じまい', '朝の時刻', '件数', '勝率', 'PF', '合計', '最大DD', '合計割る最大DD', '両建ての窓', '2024年', '2025年', '2026年', 'D>N', 'N>D']].round(1).to_string(index=False))
