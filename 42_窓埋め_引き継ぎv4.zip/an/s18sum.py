# 買い・売り別の分析のまとめと Excel
#   残す：5つの形のうち3つ以上でプラス、中央値+20円以上、年10件以上、条件なし（買い売り両方、同じ窓・選び方）より中央値で+20円以上良い
#   追加の比べ：同じ条件の買い売り両方（S10）との差＝方向で分けた効果
import glob, sys, numpy as np, pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
sys.path.insert(0, '/home/claude/work/08/an'); from s14report_funcs import stats
sys.path.insert(0, '/home/claude/work/01/code'); from common6 import jname
W = '/home/claude/work'
TFJ = {'5m': '5分', '15m': '15分', '60m': '60分', '4h': '4時間', 'D': '日足', 'W': '週足'}
def nm(x):
    if x == '条件なし': return '条件なし'
    b_, _, tf = x.rpartition('_')
    if tf in TFJ and (not b_.isascii() or b_.isupper()): return TFJ[tf] + b_
    return jname(x)
O = pd.concat([pd.read_pickle(f) for f in sorted(glob.glob(W + '/S18eval_*.pkl'))], ignore_index=True)
k = ['定義', '向き', '売買', '窓', '指標', '区分', '後半のみ', '選び方']
G = O.groupby(k).agg(プラス数=('平均', lambda v: int((v > 0).sum())), 中央=('平均', 'median'), 最小=('平均', 'min'), 年件数=('年件数', 'median'), 最大DD=('最大DD', 'median'), 最悪=('最悪', 'min')).reset_index()
B10 = pd.concat([pd.read_pickle(f) for f in glob.glob(W + '/S10eval_*.pkl')], ignore_index=True)
b = B10[B10['指標'].isin(['条件なし', '条件なし(2024-)'])].groupby(['定義', '向き', '窓', '選び方', '後半のみ'])['平均'].median().rename('条件なし(両方)中央').reset_index()
G = G.merge(b, on=['定義', '向き', '窓', '選び方', '後半のみ'], how='left'); G['改善'] = G['中央'] - G['条件なし(両方)中央']
same = B10[~B10['指標'].str.startswith('条件なし') & (B10['使い方'] == '入る')].groupby(['定義', '向き', '窓', '指標', '区分', '選び方'])['平均'].median().rename('同じ条件(両方)中央').reset_index()
G = G.merge(same, on=['定義', '向き', '窓', '指標', '区分', '選び方'], how='left')
nob = G[G['指標'] == '条件なし'][['定義', '向き', '窓', '選び方', '売買', '中央']].rename(columns={'中央': '条件なし(同じ方向)中央'})
G = G.merge(nob, on=['定義', '向き', '窓', '選び方', '売買'], how='left')
G['指標名'] = [nm(x) for x in G['指標']]
G['残す'] = (G['プラス数'] >= 3) & (G['中央'] >= 20) & (G['年件数'] >= 10) & ((G['改善'] >= 20) | (G['指標'] == '条件なし'))
G.to_pickle(W + '/S18sum.pkl')
# 単点・周辺の両方で残るもの
key = ['定義', '向き', '売買', '窓', '指標名', '区分', '後半のみ']
B = G[G['残す']].groupby(key).agg(選び方数=('選び方', 'size'), 中央=('中央', 'mean'), 最小=('最小', 'min'), 年件数=('年件数', 'mean'), 最大DD=('最大DD', 'mean'), 改善=('改善', 'mean'),
                                 同じ条件の両方=('同じ条件(両方)中央', 'mean'), 条件なし同じ方向=('条件なし(同じ方向)中央', 'mean')).reset_index()
B['方向で分けた効果'] = B['中央'] - B['同じ条件の両方']
B.to_pickle(W + '/S18both.pkl')
pd.set_option('display.width', 260); pd.set_option('display.max_rows', 200)
print('残す（どちらかの選び方）', G['残す'].sum(), ' 両方の選び方', (B['選び方数'] == 2).sum())
print(B[B['選び方数'] == 2].groupby(['向き', '売買', '定義']).size())
nb = G[G['指標'] == '条件なし'].pivot_table(index=['定義', '向き', '窓', '売買'], columns='選び方', values=['中央', 'プラス数', '年件数']).round(1); print(nb)
for (s_, d_), g in B[B['選び方数'] == 2].groupby(['向き', '売買']):
    print('=====', s_, d_, len(g)); print(g.sort_values('中央', ascending=False).head(12).round(1).to_string(index=False))
if __name__ == '__main__':
    # 今の採用候補の買い売り別（S17、上位5本・10本）
    T = pd.read_pickle(W + '/S13trades.pkl'); T = T[(T['評価'] == 'WF全期間') & (T['選び方'] == '周辺')]; WF = T[T['年'] == T['t']]
    U = pd.read_pickle(W + '/S17list.pkl'); rows = []
    for r in U.itertuples():
        v = WF[(WF['id'] == r.id) & (WF['窓の種類'] == r.窓の種類)]
        dct = {'上位N本': r.上位N本, '窓の種類': r.窓の種類, '向き': r.向き, '優先順位': r.優先順位, '候補': r.候補, '使い方': r.使い方, '定義': r.定義}
        for labl, sg in (('買い', 1), ('売り', -1)):
            x = v[v['向き'] == sg].sort_values('手じまう時刻')['損益'].values; s = stats(x) if len(x) else {}
            for kk in ('件数', '勝率', 'PF', '平均', '合計', '最大DD'): dct['%s:%s' % (labl, kk)] = s.get(kk, np.nan)
            for y in range(2022, 2027): dct['%s:%d年' % (labl, y)] = v[(v['向き'] == sg) & (v['年'] == y)]['損益'].sum()
        rows.append(dct)
    CU = pd.DataFrame(rows)
    H = pd.read_pickle(W + '/S14port_C1_10.pkl'); PY = []
    for y, g in H.groupby('確かめる年'):
        for labl, sg in (('買い', 1), ('売り', -1)):
            x = g[g['向き'] == sg]['損益'].values; s = stats(x); PY.append(dict(年=y, 売買=labl, 件数=s['件数'], 勝率=s['勝率'], PF=s['PF'], 合計=s['合計']))
    PY = pd.DataFrame(PY)
    OUT = W + '/08/results/S15_買い売り別.xlsx'
    desc = [
     ['この表について', '買いと売りに分けた分析（まろ、2026-10-13：2023年以降の上昇相場で買いの放置が良く見えるだけではないか、売りでも成績が出ているか、片方だけなら良い候補はないか）'],
     ['①今の採用候補', 'S17の採用候補（案3）の前向き（2022〜26年）の成績を、買いと売りに分けたもの。組み合わせ（同じ向き2本・上位10本、前の付け方）の年ごとの買い売り別も'],
     ['②広く分析し直し', '条件なし＋F6・F7 の全区分を「買いのみ」「売りのみ」にして、現行・先物基準×順張り・逆張り×3窓でふるい→評価。買い＝順張りは上に離れた窓、逆張りは下に離れた窓'],
     ['', 'ふるい：前半（2017〜21年）と後半（2022〜26年）の両方で、条件なし（買い売り両方）より上乗せがプラス、後半の中央t≥1。前半でも同じ向きを求めるので、2023年以降の上昇相場だけで良く見えるものは通りにくい'],
     ['', '残す：5つの評価の形のうち3つ以上でプラス、中央値+20円以上、年10件以上、条件なし（買い売り両方）より中央値で+20円以上良い。方向だけの条件なし（買いのみ・売りのみ）は参考に全部載せる'],
     ['列', '改善＝条件なし（買い売り両方）との差／方向で分けた効果＝同じ条件の買い売り両方（S7）との差／条件なし同じ方向＝方向だけで条件なしの成績'],
     ['金額', '1枚＝68,800円換算、13pt控除後、円'],
     ['シート', '今の候補の買い売り別／組み合わせの年ごと買い売り／方向だけの条件なし／残した候補（単点・周辺の両方）／まとめ全件'],
    ]
    with pd.ExcelWriter(OUT, engine='openpyxl') as w:
        pd.DataFrame(desc, columns=['項目', '内容']).to_excel(w, sheet_name='説明', index=False)
        CU.round(1).to_excel(w, sheet_name='今の候補の買い売り別', index=False)
        PY.round(1).to_excel(w, sheet_name='組み合わせの年ごと買い売り', index=False)
        G[G['指標'] == '条件なし'].round(1).to_excel(w, sheet_name='方向だけの条件なし', index=False)
        B[B['選び方数'] == 2].sort_values(['向き', '売買', '中央'], ascending=[True, True, False]).round(1).to_excel(w, sheet_name='残した候補', index=False)
        G.round(1).to_excel(w, sheet_name='まとめ全件', index=False)
    wb = load_workbook(OUT); red = Font(name='Arial', size=10, color='C00000')
    for ws in wb:
        for row in ws.iter_rows():
            for c in row:
                c.font = Font(name='Arial', size=10, bold=c.row == 1)
                if c.row > 1 and isinstance(c.value, (int, float)) and not isinstance(c.value, bool) and c.value < 0: c.font = red
        for c in ws[1]: c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
        ws.freeze_panes = 'A2'
        for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = 11
    ws = wb['説明']; ws.column_dimensions['A'].width = 16; ws.column_dimensions['B'].width = 150
    for c in ws['B']: c.alignment = Alignment(wrap_text=True, vertical='top')
    wb['今の候補の買い売り別'].column_dimensions['E'].width = 28; wb['残した候補'].column_dimensions['E'].width = 26
    wb.save(OUT); print(OUT)
