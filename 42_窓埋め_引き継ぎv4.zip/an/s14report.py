# 今の候補（運用の第一候補：代表(0.5)、窓の種類・向きごとに選ぶ期間の1回あたり平均で上位10本）の詳しい成績
#   順位：2026年に使うルール（2017〜2025年のデータで選んだ乖離幅・決済、周辺の選び方）の、2017〜2025年の1回あたり平均
#   成績① 前向き検証の記録（2022〜2026年。各年は、その年より前のデータで選んだルールで売買したもの）← 実力に近い
#   成績② 今のルールでの全期間（2017〜2026/10/8。ルールを選んだ期間を含むので良く出やすい）← 参考
#   組み合わせ：先着1本（A1）、同じ向き2本（C1）、両建て＋2本目（D1）を上位5本・10本で。いずれも13pt控除後、円（1枚＝68,800円換算）
import sys, numpy as np, pandas as pd
sys.argv = [sys.argv[0]]
src = open('/home/claude/work/08/an/s13sim.py').read().split("if __name__ == '__main__':")[0]; exec(src)
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
SCN, METH, UNI, NMAX = 'WF全期間', '周辺', '代表(0.5)', 10
PK = pd.read_pickle(W + '/S13picks.pkl')
TT = T0[(T0['評価'] == SCN) & (T0['選び方'] == METH)]
def stats(v, yrs=None):
    v = np.asarray(v, float)
    if len(v) == 0: return {}
    w = v[v > 0]; l = v[v <= 0]; c = np.cumsum(v); dd = float((np.maximum.accumulate(np.r_[0, c])[1:] - c).max())
    run = mx = 0
    for x in v:
        run = run + 1 if x <= 0 else 0; mx = max(mx, run)
    r = dict(件数=len(v), 勝率=len(w) / len(v) * 100, PF=w.sum() / -l.sum() if l.sum() < 0 else np.inf, 平均=v.mean(), 平均利益=w.mean() if len(w) else np.nan, 平均損失=l.mean() if len(l) else np.nan,
             損益比=(w.mean() / -l.mean()) if len(w) and len(l) and l.mean() < 0 else np.nan, 合計=v.sum(), 最大DD=dd, 合計割る最大DD=v.sum() / dd if dd > 0 else np.nan, 最悪の1回=v.min(), 最良の1回=v.max(), 最大連敗=mx)
    if yrs is not None: r['年あたり件数'] = len(v) / yrs
    return r
def rule_text(side, x, ex):
    fr, sk, tm = ex; t = '引けまで' if tm == 0 else '%d分' % tm
    if side == '逆張り':
        return '乖離%g%%で逆張り／利確：窓までの距離の%d%%%s／損切り：%s／時間：%s' % (x, round(fr * 100), '（基準を越えた位置）' if fr > 1 else '', 'なし' if sk == 0 else '乖離幅×%g' % sk, t)
    return '乖離%g%%で順張り／損切り：基準へ%d%%戻った位置%s／利確：%s／時間：%s' % (x, round(fr * 100), '（基準を越えた位置）' if fr > 1 else '', 'なし' if sk == 0 else '乖離幅×%g' % sk, t)
def cond_text(z):
    if z['使い方'] == '基本': return '条件なし'
    if z['出所'] == 'S6印': return ('%sのときだけ入る' if z['使い方'] == '入る' else '%sのときは入らない') % z['名前']
    return ('「%s」のときだけ入る' if z['使い方'] == '入る' else '「%s」のときは入らない') % z['名前']
# ---- 順位（2026年のルール、2017〜2025年の1回あたり平均）
t = 2026; Tt = TT[TT['t'] == t]; Tt = Tt[Tt['id'].isin(UNIV[UNI])]
rows = []; YR = []
for kind in ('D>N', 'N>D'):
    tk = Tt[Tt['窓の種類'] == kind]
    ins = tk[tk['年'] < t].groupby('id')['損益'].agg(['mean', 'size']); ins = ins[ins['size'] >= 15]
    for side in ('順張り', '逆張り'):
        ids = [i for i in ins.sort_values('mean', ascending=False).index if C.loc[i, '向き'] == side][:NMAX]
        for rank, i in enumerate(ids, 1):
            z = C.loc[i]; p = PK[(PK['id'] == i) & (PK['評価'] == SCN) & (PK['選び方'] == METH) & (PK['t'] == t)].iloc[0]
            wf = TT[(TT['id'] == i) & (TT['窓の種類'] == kind) & (TT['年'] == TT['t'])].sort_values('手じまう時刻')
            full = tk[tk['id'] == i].sort_values('手じまう時刻')
            r = dict(id=i, 窓の種類=kind, 向き=side, 順位=rank, 候補=z['名前'], 条件=cond_text(z), 定義=z['定義'], 候補の窓=z['窓'], テーマ=z['テーマ'], グループ=z['グループ'],
                     今のルール=rule_text(side, p['乖離幅'], p['決済']), 順位の値_2017_25の1回平均=ins.loc[i, 'mean'], 順位の値_件数=int(ins.loc[i, 'size']))
            r.update({'前向き:' + k: v for k, v in stats(wf['損益'].values, 4.77).items()})
            r.update({'全期間:' + k: v for k, v in stats(full['損益'].values, 9.77).items()})
            rows.append(r)
            for lab, df in (('前向き検証', wf), ('今のルールで全期間', full)):
                for y, g in df.groupby('年'):
                    s_ = stats(g['損益'].values); YR.append(dict(窓の種類=kind, 向き=side, 順位=rank, 候補=z['名前'], 定義=z['定義'], 記録=lab, 年=int(y), 件数=s_['件数'], 勝率=s_['勝率'], PF=s_['PF'], 平均=s_['平均'], 合計=s_['合計'], 最大DD=s_['最大DD']))
L = pd.DataFrame(rows); Y_ = pd.DataFrame(YR)
# ---- 組み合わせ（2022〜2026年、前向き検証）
PR = []; PY = []
for N in (5, 10):
    for pol, nm in (('A1', '先着1本'), ('C1', '同じ向き2本'), ('D1', '両建て＋2本目')):
        H = simulate(SCN, METH, UNI, N, pol, False).sort_values('手じまう時刻')
        r = dict(方針=nm, 上位N本=N); r.update(stats(H['損益'].values, 4.77)); r['最悪の1窓'] = H.groupby('セッション')['損益'].sum().min()
        r['2本目の数'] = int((H['種類'] == '2本目').sum()); r['2本目の平均'] = H.loc[H['種類'] == '2本目', '損益'].mean(); r['両建ての数'] = int((H['種類'] == '両建て').sum())
        PR.append(r)
        for y, g in H.groupby('確かめる年'):
            s_ = stats(g['損益'].values); PY.append(dict(方針=nm, 上位N本=N, 年=int(y), 件数=s_['件数'], 勝率=s_['勝率'], PF=s_['PF'], 平均=s_['平均'], 合計=s_['合計'], 最大DD=s_['最大DD']))
        H.to_pickle(W + '/S14port_%s_%d.pkl' % (pol, N))
PR = pd.DataFrame(PR); PY = pd.DataFrame(PY)
L.to_pickle(W + '/S14list.pkl'); Y_.to_pickle(W + '/S14years.pkl'); PR.to_pickle(W + '/S14port.pkl'); PY.to_pickle(W + '/S14portyears.pkl')
pd.set_option('display.width', 260); pd.set_option('display.max_colwidth', 60)
print(L[['窓の種類', '向き', '順位', '候補', '定義', '候補の窓', '前向き:件数', '前向き:勝率', '前向き:PF', '前向き:平均', '前向き:合計', '前向き:最大DD', '全期間:PF', '全期間:平均']].round(2).to_string(index=False))
print(PR.round(2).to_string(index=False)); print(PY.pivot_table(index=['方針', '上位N本'], columns='年', values='合計').round(0))
