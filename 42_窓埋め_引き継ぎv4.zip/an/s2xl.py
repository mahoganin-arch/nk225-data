import numpy as np, pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter
from lib import W, CB
def dec(t):
    if isinstance(t, (int, np.integer)): t = CB[int(t)]
    sl, tp, tm = t; return '損切り:戻り%d%% / 利確:%s / 時間:%s' % (round(sl * 100), 'なし' if tp == 0 else '幅×%g' % tp, '次の引け' if tm == 0 else '%d分' % tm)
ORD = ['S1 前半→後半', 'S2 22-23→24-26', 'WF後半', 'WF全期間', 'WF直近3年']
S = pd.read_pickle(W + '/S2sum.pkl'); S['評価'] = pd.Categorical(S['評価'], ORD); S = S.sort_values(['窓', '戦略', '評価', '選び方'])
S['v'] = S['平均']
Pv = S.pivot_table(index=['窓', '戦略'], columns=['評価', '選び方'], values='平均', observed=True).round(1)
Pn = S.pivot_table(index=['窓', '戦略'], columns=['評価', '選び方'], values='件数', observed=True)
Pv.columns = ['%s_%s_平均' % c for c in Pv.columns]; Pn.columns = ['%s_%s_件数' % c for c in Pn.columns]
Pv['5つの形で周辺がプラスの数'] = (Pv[[c for c in Pv.columns if '_周辺_' in c]] > 0).sum(1); Pv['5つの形で単点がプラスの数'] = (Pv[[c for c in Pv.columns if '_単点_' in c]] > 0).sum(1)
SUM = pd.concat([Pv, Pn], axis=1).reset_index()
PK = pd.read_pickle(W + '/S2pick.pkl'); PK['決済'] = PK['決済'].map(dec)
C = pd.read_pickle(W + '/S2combo.pkl'); CY = pd.read_pickle(W + '/S2comboY.pkl')
FX = pd.read_pickle(W + '/S2fixed.pkl'); BR = pd.read_pickle(W + '/S2bar.pkl')
en = pd.read_pickle(W + '/T/en.pkl'); ev = pd.read_pickle(W + '/T/evt.pkl'); RK = pd.read_pickle(W + '/T/atrrank.pkl')
yr = ev.t0.dt.year.values[en.ev.values]; ok = ~ev.long.values[en.ev.values]
AR = RK[ok].assign(年=yr[ok]).groupby('年').agg(lambda s: np.nanmean(s >= 0.9) * 100).round(1).reset_index()
AR.columns = ['年'] + ['%s 上位10%%の割合%%' % c for c in AR.columns[1:]]
exp = [
 ['ステップ2：順張りの具体ルール化（2026-10-13）'], [''],
 ['コスト', '13pt（1回 = 13 ÷ 基準価格 × 68,800円）を控除した後の値。すべての選び方もコスト控除後の成績で行う'],
 ['選び方：単点', '選ぶ期間で平均が最良の (乖離幅, 決済) 1点'],
 ['選び方：周辺', '乖離幅・損切り・利確・時間の各軸で隣（±1）を含む最大81点の平均が最良の点（頑健な選び方）。利確なしは最大利確の隣、時間「次の引け」は360分の隣として並べた'],
 ['共通の制約', '選ぶ期間で最悪の1回 −1,000円以上の決済に限る（なければ制約なし）。選ぶ期間15件以上の幅のみ'],
 ['評価の形', 'S1 前半(2017-21)→後半(2022-26/10/8) ／ S2 2022-23→2024-26 ／ WF後半：2022〜前年で選び翌年（2023〜2026）／ WF全期間：2017〜前年で選び翌年（2022〜2026）／ WF直近3年：前3年で選び翌年（2022〜2026）'],
 ['', 'いずれも「選ぶ期間」と「確かめる期間」が重ならない。WFは毎年選び直し、確かめた年のトレードをつなげて評価'],
 ['戦略 (a)', '条件なし／避ける:15分MA並び=0。窓は D>N・N>D・両方の窓'],
 ['戦略 (b)', '乖離幅0.2%以上に限定。5分・15分ATRの上位10%。境目は (ウ) 直近90日・365日（暦日）の同じ時間足ATRの分布での順位（基準時刻までの足のみ）。比較用に (ア) 前半固定'],
 ['組み合わせ', '確かめる期間のトレードを時刻順につなげたもの。両方保有＝同じ窓で2本持つことがある。ATR優先＝ATR側が入った窓では条件なし側を入らない'],
 ['固定ルール', '注意：2025年までのデータを見て選んだ形。2026年だけが未使用データ。参考として全期間の成績と、周辺81点（54点）の後半平均の範囲を示す'],
 ['足の確認', '2020/11以降を1分足で計算した通常版と、全期間5分足で計算した版の比較。後半の成績はほぼ同じ'],
 ['決済の表記', '損切り:戻り○% ＝ 基準方向へ乖離距離の○%戻ったら損切り（100%超は基準を越えた位置）／利確:幅×○ ＝ エントリーから乖離幅の○倍進んだら利確／時間:次の引け ＝ 次の先物セッション引けで決済'],
 ['確認', '単点のS1はステップ1の①と一致。WF後半2025（両方の窓・条件なし・周辺）は固定ルールの2025年平均と一致'],
]
out = W + '/S2_順張りルール化.xlsx'
with pd.ExcelWriter(out, engine='openpyxl') as xw:
    pd.DataFrame(exp).to_excel(xw, sheet_name='説明', index=False, header=False)
    SUM.to_excel(xw, sheet_name='評価の形ごとのまとめ', index=False)
    S.drop(columns='v').round(1).to_excel(xw, sheet_name='評価の形ごとの詳細', index=False)
    PK.round(1).to_excel(xw, sheet_name='選んだ幅と決済', index=False)
    C.round(1).to_excel(xw, sheet_name='組み合わせ', index=False)
    CY.round(1).to_excel(xw, sheet_name='組み合わせ_年ごと', index=False)
    FX.round(1).to_excel(xw, sheet_name='固定ルール(参考)', index=False)
    BR.round(1).to_excel(xw, sheet_name='足の確認', index=False)
    AR.to_excel(xw, sheet_name='ATR順位の該当率', index=False)
wb = load_workbook(out); hf = PatternFill('solid', fgColor='DDEBF7')
for ws in wb:
    for row in ws.iter_rows():
        for c in row: c.font = Font(name='Arial', size=10, bold=(c.row == 1))
    if ws.title == '説明':
        ws.column_dimensions['A'].width = 18; ws.column_dimensions['B'].width = 150; continue
    for c in ws[1]: c.fill = hf; c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.row_dimensions[1].height = 60; ws.freeze_panes = 'C2'
    for i in range(1, ws.max_column + 1): ws.column_dimensions[get_column_letter(i)].width = 12
    for i, c in enumerate(ws[1], 1):
        if c.value in ('戦略', '組み合わせ', 'ルール'): ws.column_dimensions[get_column_letter(i)].width = 34
        if c.value == '決済': ws.column_dimensions[get_column_letter(i)].width = 40
wb.save(out); print(out)
