# 再選定・詳細の結果を1つの表（候補群×選び方×制約）にまとめる
import sys, numpy as np, pandas as pd
from lib import *
SELN = ['前半で優位', '後半で優位', '両方で優位']; KN = ['-600', '-800', '-1000', '-1200', 'なし']
def runs(bits, n=28):
    b = np.stack([(bits >> i) & 1 for i in range(n)], -1).astype(np.int16)
    cur = np.zeros(bits.shape, np.int16); mx = cur.copy()
    for i in range(n): cur = (cur + 1) * b[..., i]; mx = np.maximum(mx, cur)
    return b.sum(-1), mx
def baseline(side, Y, en):
    """条件なし：窓×乖離幅×決済ごとの前半・後半平均"""
    XP = sorted(en.x.unique()); B = {}
    for s, g in SEGS.items():
        arr = np.full((len(XP), 2, NCB), np.nan, np.float32)
        for xi, x in enumerate(XP):
            m = (~en.long.values) & np.isclose(en.x.values, x) & np.isin(en.kind.values, g)
            for hi, h in enumerate('AB'):
                ii = np.nonzero(m & (en.half.values == h))[0]
                if len(ii): arr[xi, hi] = np.asarray(Y[ii], dtype=np.float64).mean(0) / 100 * P
        B[s] = arr
    return B
def build(side):
    dd = W + ('/R' if side == '逆張り' else '/T'); Y, en, F = load(dd)
    z = dict(np.load(dd + '/resel.npz')); dt = dict(np.load(dd + '/detail.npz')); fam = pd.read_pickle(dd + '/resel_fam.pkl')
    XP = z['XP']; B = baseline(side, Y, en); npass, mrun = runs(z['passbits'])
    out = []
    for si in range(3):
        for k in range(5):
            f = np.nonzero(z['best_x'][:, si, k] >= 0)[0]; xi = z['best_x'][f, si, k]; e = z['best_e'][f, si, k]
            d = fam.iloc[f][['窓', '指標1', '区分1', '指標2', '区分2']].copy(); d['fid'] = f
            d['選び方'] = SELN[si]; d['最悪の上限'] = KN[k]; d['乖離幅%'] = XP[xi]
            cb = np.array(CB)[e]; d['利確'] = cb[:, 0]; d['損切り'] = cb[:, 1]; d['時間切れ'] = cb[:, 2].astype(int)
            for c, s in (('前半件数', 'nA'), ('前半平均', 'mA'), ('後半件数', 'nB'), ('後半平均', 'mB'), ('前半プラス決済%', 'pA'), ('後半プラス決済%', 'pB'), ('基準を満たす決済数', 'cnt')): d[c] = z[s][f, si, k]
            for c, s in (('前半最悪', 'wA'), ('後半最悪', 'wB'), ('前半2番目に悪い', 'w2A'), ('後半2番目に悪い', 'w2B'), ('前半勝率', 'winA'), ('後半勝率', 'winB'), ('前半PF', 'pfA'), ('後半PF', 'pfB'), ('前半プラス年', 'ypA'), ('前半年数', 'ynA'), ('後半プラス年', 'ypB'), ('後半年数', 'ynB')): d[c] = dt[s][f, si, k]
            for j, yr in enumerate(range(2017, 2027)): d[str(yr)] = dt['YM'][f, si, k, j]
            d['通過した幅の数'] = npass[f, si, k]; d['連続した幅の最大数'] = mrun[f, si, k]
            base = np.stack([B[w][a, :, c] for w, a, c in zip(d['窓'], xi, e)])
            d['条件なし前半'] = base[:, 0]; d['条件なし後半'] = base[:, 1]; d['前半上乗せ'] = d['前半平均'] - base[:, 0]; d['後半上乗せ'] = d['後半平均'] - base[:, 1]
            out.append(d)
    T = pd.concat(out, ignore_index=True)
    T['種類'] = np.where(T['指標2'] == '', '指標単独', np.where(T['指標1'].isin(['時間帯', '曜日']) | T['指標2'].isin(['時間帯', '曜日']), '指標×時間・曜日', '指標×指標'))
    T['条件'] = [jname(a) + '=' + b + ((' × ' + jname(c) + '=' + e) if c else '') for a, b, c, e in zip(T['指標1'], T['区分1'], T['指標2'], T['区分2'])]
    T.to_pickle(dd + '/table.pkl'); print(side, len(T)); return T
if __name__ == '__main__':
    for s in sys.argv[1:]: build(s)
