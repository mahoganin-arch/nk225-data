# 最悪の制約つき再選定：全候補群 × 28乖離幅 × 1,944決済
# 出力：side/resel.npz（候補群×選び方×制約ごとの最良と、通過した乖離幅のビット）
import sys, time, numpy as np, pandas as pd, scipy.sparse as sp
from lib import *
side = sys.argv[1]; ONLYX = [float(v) for v in sys.argv[2:]]
Y, en, F, F2 = setup(side)
SELS = ['前半で最良', '後半で最良', '両方で最良']
WL = [-600, -800, -1000, -1200]; NK = len(WL) + 1                      # 制約 k=0..3 は WL、k=4 は制約なし
FLOOR_A = -100                                                         # 後半で優位：前半平均の最低ライン
KEY = ['窓', '指標1', '区分1', '指標2', '区分2']
fam = pd.concat([readfam(side, s)[KEY] for s in SELS]).drop_duplicates().reset_index(drop=True)
NF = len(fam); print(side, '候補群（条件）', NF, flush=True)
XP = sorted(en.x.unique())
# 結果の器
sh = (NF, 3, NK)
best_sc = np.full(sh, -1e9, np.float32); best_x = np.full(sh, -1, np.int8); best_e = np.full(sh, -1, np.int16)
o_mA = np.full(sh, np.nan, np.float32); o_mB = o_mA.copy(); o_nA = np.zeros(sh, np.int16); o_nB = o_nA.copy()
o_cnt = np.zeros(sh, np.int16); o_pA = o_mA.copy(); o_pB = o_mA.copy(); passbits = np.zeros(sh, np.int64)
two = fam['指標2'] != ''
groups = fam[two].groupby(['指標1', '指標2', '窓']).groups                # (a,b,窓) → 候補群番号
singles = fam[~two]
t0 = time.time()
for xi, x in enumerate(XP):
    if ONLYX and not any(np.isclose(x, v) for v in ONLYX): continue
    idx = np.nonzero((~en.long.values) & np.isclose(en.x.values, x))[0]
    if len(idx) < 60: continue
    kind = en.kind.values[idx]; half = en.half.values[idx]; yi = en.yr.values[idx] - 2017
    f1 = F.iloc[idx]; f2 = F2.iloc[idx]; segm = {s: np.isin(kind, g) for s, g in SEGS.items()}
    # 候補群ごとの行
    fid_l = []; rows_l = []; cache = {}
    def codes(k):
        if k not in cache:
            dct = b3lab(k, f2[k].values.astype(float)); labs = list(dct); c = np.full(len(idx), -1, np.int16)
            for i, lab in enumerate(labs): c[dct[lab]] = i
            cache[k] = (c, {lab: i for i, lab in enumerate(labs)})
        return cache[k]
    for (a, b, w), ids in groups.items():
        ca, la = codes(a); cb, lb = codes(b); key = np.where(segm[w] & (ca >= 0) & (cb >= 0), ca * 64 + cb, -1)
        o = np.argsort(key, kind='stable'); ks = key[o]
        for i in ids:
            r = fam.iloc[i] if False else None
            l1 = fam.at[i, '区分1']; l2 = fam.at[i, '区分2']
            if l1 not in la or l2 not in lb: continue
            t = la[l1] * 64 + lb[l2]; s0, s1 = np.searchsorted(ks, [t, t + 1])
            if s1 > s0: fid_l.append(i); rows_l.append(o[s0:s1].astype(np.int32))
    c1 = {}
    for i, r in singles.iterrows():
        if r['指標1'] not in c1: c1[r['指標1']] = dict(bins_for(f1[r['指標1']].values.astype(float), None))
        lab = ('=' + r['区分1'][1:]) if r['区分1'].startswith('値') else r['区分1']
        if lab not in c1[r['指標1']]: continue
        rr = np.nonzero(segm[r['窓']] & c1[r['指標1']][lab])[0]
        if len(rr): fid_l.append(i); rows_l.append(rr.astype(np.int32))
    # 件数・年の条件（決済によらない）
    nf = len(fid_l); lens = np.array([len(v) for v in rows_l]); allr = np.concatenate(rows_l); del rows_l; own = np.repeat(np.arange(nf, dtype=np.int32), lens)
    NY = np.bincount(own * 10 + yi[allr], minlength=nf * 10).reshape(nf, 10)
    nA = NY[:, :5].sum(1); nB = NY[:, 5:].sum(1)
    okA = (nA >= 20) & ((NY[:, :5] >= 3).sum(1) >= 4); okB = (nB >= 20) & ((NY[:, 5:] >= 3).sum(1) >= 4)
    keep = np.nonzero(okA | okB)[0]                                      # どちらの半期も基準外なら、どの選び方でも通過しない
    Yx = np.asarray(Y[idx], dtype=np.float32) / 100 * P
    Benc = np.zeros(Yx.shape, np.float64)
    for k, w in enumerate(WL): Benc += (Yx < w) * float(2048 ** k)
    hrow = (half[allr] == 'B').astype(np.int32); del cache
    for c0 in range(0, len(keep), 6000):
        ch = keep[c0:c0 + 6000]; m = len(ch); pos = np.zeros(nf, np.int32) - 1; pos[ch] = np.arange(m)
        sel_e = pos[own] >= 0; po = pos[own]; sel_e = po >= 0; rr_ = po[sel_e] * 2 + hrow[sel_e]; cc_ = allr[sel_e]
        M = sp.csr_matrix((np.ones(len(rr_), np.float32), (rr_, cc_)), shape=(m * 2, len(idx)))
        S = (M @ Yx).reshape(m, 2, -1); Bc = (M.astype(np.float64) @ Benc).reshape(m, 2, -1)
        nAc = nA[ch][:, None].astype(np.float32); nBc = nB[ch][:, None].astype(np.float32)
        mA = S[:, 0] / np.maximum(nAc, 1); mB = S[:, 1] / np.maximum(nBc, 1)
        bad = []                                                          # bad[k] = (前半に下回る回数, 後半)
        BA = Bc[:, 0].astype(np.int64); BB = Bc[:, 1].astype(np.int64)
        for k in range(len(WL)): bad.append(((BA >> (11 * k)) & 2047, (BB >> (11 * k)) & 2047))
        pA = (mA > 0).mean(1) * 100; pB = (mB > 0).mean(1) * 100
        oa = okA[ch][:, None]; ob = okB[ch][:, None]
        base = [(oa & (mA >= 20), mA), (ob & (mB >= 20) & (nAc > 0) & (mA >= FLOOR_A), mB), (oa & ob & (mA >= 20) & (mB >= 20), np.minimum(mA, mB))]
        fids = np.array(fid_l)[ch]
        for si, (ok0, sc) in enumerate(base):
            for k in range(NK):
                if k < len(WL):
                    ba, bb = bad[k]; cons = (ba == 0) if si == 0 else ((bb == 0) if si == 1 else ((ba == 0) & (bb == 0)))
                    okm = ok0 & cons
                else: okm = ok0
                cnt = okm.sum(1); has = cnt > 0
                if not has.any(): continue
                sc2 = np.where(okm, sc, -1e9); j = sc2.argmax(1); v = sc2[np.arange(m), j]
                f = fids[has]; passbits[f, si, k] |= np.int64(1) << xi
                better = has & (v > best_sc[fids, si, k]); f = fids[better]; jj = j[better]; rws = np.nonzero(better)[0]
                best_sc[f, si, k] = v[better]; best_x[f, si, k] = xi; best_e[f, si, k] = jj
                o_mA[f, si, k] = mA[rws, jj]; o_mB[f, si, k] = mB[rws, jj]; o_nA[f, si, k] = nA[ch][rws]; o_nB[f, si, k] = nB[ch][rws]
                o_cnt[f, si, k] = cnt[better]; o_pA[f, si, k] = pA[rws]; o_pB[f, si, k] = pB[rws]
        del S, Bc, M
    print('x', x, 'エントリー', len(idx), '候補群', nf, '対象', len(keep), round(time.time() - t0), 's', flush=True)
out = W + ('/R' if side == '逆張り' else '/T') + ('/resel_test.npz' if ONLYX else '/resel.npz')
np.savez_compressed(out, best_sc=best_sc, best_x=best_x, best_e=best_e, mA=o_mA, mB=o_mB, nA=o_nA, nB=o_nB, cnt=o_cnt, pA=o_pA, pB=o_pB, passbits=passbits, XP=np.array(XP), WL=np.array(WL))
fam.to_pickle(out.replace('.npz', '_fam.pkl')); print('saved', out)
