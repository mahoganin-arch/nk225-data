# D の結果を Excel に書き出す
import numpy as np, pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from lib import W
OUT = W + '/D_指標の安定性.xlsx'
YR = [str(y) for y in range(2017, 2027)]
def prep(side):
    S = pd.read_pickle(W + ('/R' if side == '逆張り' else '/T') + '/d2.pkl').copy()
    S['区分'] = S['区分'].map(lambda v: ('値' + v[1:]) if isinstance(v, str) and v.startswith('=') else v)
    S['向き'] = S['向き_全'].map({1: 'プラス（入る場面）', -1: 'マイナス（避ける場面）', 0: '不一致'})
    for k in ('全',):
        for v in ('補正', '抑制', '前半境目', '1年除外'): S['%s維持' % v] = np.where(S['維持_%s_%s' % (v, k)], '○', '×')
    cols = {'向き': '向き', '名前': '指標', '区分': '区分', '窓': '窓', '系統': '系統', '幅の数': '幅の数', '幅の最小': '幅の最小%', '幅の最大': '幅の最大%',
            '前半件数': '前半件数(中央)', '後半件数': '後半件数(中央)', '前半_全': '前半上乗せ', '後半_全': '後半上乗せ', '同じ向きの幅%_全': '同じ向きの幅%',
            '前半t中央_全': '前半t(中央)', '後半t中央_全': '後半t(中央)', '後半_前半境目_全': '後半上乗せ(境目は前半で決定)', '前半_全_補正': '前半上乗せ(ATR補正)', '後半_全_補正': '後半上乗せ(ATR補正)',
            '前半_全_抑制': '前半上乗せ(外れ値抑制)', '後半_全_抑制': '後半上乗せ(外れ値抑制)', '前半_1年除外の悪い側_全': '前半(1年除外の悪い側)', '後半_1年除外の悪い側_全': '後半(1年除外の悪い側)',
            '補正維持': 'ATR補正で維持', '抑制維持': '外れ値抑制で維持', '前半境目維持': '前半境目で維持', '1年除外維持': '1年除外で維持', '維持数_全': '維持数(4つ中)', '同じ向きの年数_全': '同じ向きの年数', '年数_全': '年数',
            '前半_固': '前半上乗せ(固定決済)', '後半_固': '後半上乗せ(固定決済)', '向き_固': '向き(固定決済)', '維持数_固': '維持数(固定決済)'}
    for y in YR: cols['%s_全' % y] = y
    T = S[list(cols)].rename(columns=cols)
    T['向き(固定決済)'] = T['向き(固定決済)'].map({1: 'プラス', -1: 'マイナス', 0: '不一致'})
    T['_abs'] = np.minimum(T['前半上乗せ'].abs(), T['後半上乗せ'].abs()) * (T['向き'] != '不一致')
    T = T.sort_values(['_abs'], ascending=False).drop(columns='_abs')
    cand = T[(T['向き'] != '不一致') & (T['維持数(4つ中)'] == 4) & (T['同じ向きの幅%'] >= 60)]
    fx = lambda d: d.round(1).assign(**{'幅の最小%': d['幅の最小%'].round(3), '幅の最大%': d['幅の最大%'].round(3)})
    return fx(T), fx(cand)
expl = [('この表について', '単独の指標×区分×窓ごとに、条件なしと比べた上乗せ（円）が、前半(2017-2021)・後半(2022-2026)で同じ向きか、またそれが崩れにくいかをまとめたもの'),
        ('上乗せ', '区分に入ったエントリーの平均損益 − 同じ窓・乖離幅・期間の条件なしの平均損益。28の乖離幅それぞれで計算し、平均したもの'),
        ('成績の測り方', '主な列は1,944決済すべての平均（決済の選び方に左右されない）。「固定決済」は、窓×乖離幅ごとに条件なしで前半に最良だった決済1つで測ったもの'),
        ('注意：逆張りと順張り', '1,944決済の平均で見ると、逆張りと順張りの上乗せはほぼ正反対（相関-0.998）。同じ乖離点で逆向きに入るため。2つは別々の発見ではなく、「入った後に続くか戻るか」という1つの事実の裏表'),
        ('向き', 'プラス=前半・後半とも上乗せがプラス（入る場面）、マイナス=両方マイナス（避ける場面）、不一致=前半と後半で向きが違う'),
        ('同じ向きの幅%', '28の乖離幅のうち、前半と後半で上乗せの向きが一致した幅の割合'),
        ('t(中央)', '乖離幅ごとの上乗せのt値（偶然でないかの目安）の中央値'),
        ('境目は前半で決定', '3分割・5分割・上下10%の区切りの値を前半のデータだけで決め、そのまま後半に当てはめた場合の後半の上乗せ。実運用に近い（将来のデータを使わない）'),
        ('ATR補正', '各トレードの損益を、日足ATRが全期間の中央値だった場合の金額に換算したもの。値動きが荒い時期の損益の大きさに引っ張られていないかを確認'),
        ('外れ値抑制', '各トレードの損益を、条件なし全体の1%点・99%点で頭打ちにしたもの。少数の極端なトレードに引っ張られていないかを確認'),
        ('1年除外の悪い側', '各半期から1年ずつ除いて計算し、向きにとって最も不利だった値（プラスなら最小、マイナスなら最大）'),
        ('維持数', 'ATR補正・外れ値抑制・前半境目・1年除外の4つの確認のうち、向きが変わらなかった数'),
        ('候補シート', '向きが一致、4つの確認すべてで維持、同じ向きの幅60%以上のもの'),
        ('年ごとの列', 'その年の上乗せ（28幅の平均）。件数3未満の年は空欄'),
        ('金額', '68,800円換算、コスト未控除。2026年10月9日以降のデータは使っていない')]
with pd.ExcelWriter(OUT, engine='openpyxl') as w:
    pd.DataFrame(expl, columns=['項目', '説明']).to_excel(w, sheet_name='説明', index=False)
    for side in ('逆張り', '順張り'):
        T, C = prep(side); C.to_excel(w, sheet_name=side + '_候補', index=False); T.to_excel(w, sheet_name=side + '_全件', index=False)
wb = load_workbook(OUT); hf = PatternFill('solid', start_color='DDE4EE'); body = Font(name='Arial', size=10)
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c in row: c.font = body
    for c in ws[1]: c.font = Font(name='Arial', size=10, bold=True); c.fill = hf; c.alignment = Alignment(wrap_text=True, vertical='center')
    ws.freeze_panes = 'A2' if ws.title == '説明' else 'E2'
    if ws.title != '説明': ws.auto_filter.ref = ws.dimensions
    for col in ws.columns:
        L = max(len(str(c.value)) if c.value is not None else 0 for c in list(col)[:200])
        ws.column_dimensions[col[0].column_letter].width = min(max(8, L * (1.8 if ws.title == '説明' else 1.1) + 2), 90 if ws.title == '説明' else 22)
    ws.row_dimensions[1].height = 42 if ws.title != '説明' else 18
wb.save(OUT); print('ok', OUT)
for s in wb.sheetnames: print(s, wb[s].max_row - 1)
