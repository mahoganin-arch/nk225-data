# 案3（両方の上位を合わせる）の Excel
import pandas as pd, numpy as np
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
W = '/home/claude/work'; OUT = W + '/08/results/S14_採用候補_案3.xlsx'
PR = pd.read_pickle(W + '/S17port.pkl'); U = pd.read_pickle(W + '/S17list.pkl')
cols = ['上位N本', '窓の種類', '向き', '優先順位', '候補', '使い方', '条件', '定義', '候補の窓', 'テーマ', '両方に入る', '前の付け方の順位', '新しい付け方の順位', '今のルール',
        '前向き:件数', '前向き:勝率', '前向き:PF', '前向き:平均', '前向き:平均利益', '前向き:平均損失', '前向き:合計', '前向き:最大DD', '前向き:合計割る最大DD', '前向き:最悪の1回', '前向き:最大連敗',
        'プラスの年', '年の数', '2022年', '2023年', '2024年', '2025年', '2026年', 'id']
desc = [
 ['この表について', '案3（まろ、2026-10-13）：前の付け方と新しい付け方の上位を合わせた採用候補と、その前向き検証'],
 ['2つの付け方', '前の付け方：重なりの代表から、その年のルールの選ぶ期間（〜前年）の1回平均（15件以上）の順／新しい付け方：全候補から、前向き記録（2022年〜）のリカバリーファクター順（件数下限・合計プラス・選ぶ期間2017〜21年もプラス）。重なりの同じグループは最上位だけ'],
 ['合わせ方', '窓の種類・向きごとに、両方の上位N本を合わせる。優先順位（同時にシグナルが出たとき）は ①両方に入る候補 ②2つの順位の良い方（同じなら前の付け方）'],
 ['採用候補リスト', '今（2026/10/8まで）のデータで付けた順位。前の付け方＝2026年のルールの2017〜25年の平均（その窓の種類のトレードで）、新しい付け方＝2022〜2026/10/8 の前向き記録（20件以上）。成績の数字は前向き（2022〜26年）'],
 ['前向き検証', '2024〜26年（新しい付け方は前向き記録が2年以上必要なため）。各年の順位はその年より前のデータだけで付ける。前の付け方は平均の取り方で結果が大きく変わる（その窓の種類のトレードだけ／両方の窓まとめて）ので両方を載せた'],
 ['結果', '案3は、前の付け方と新しい付け方の中間（合計÷最大DD 2.6〜6.9）。前の付け方は設定によって3.2〜12.4と振れが大きく、新しい付け方は2.0〜4.7で2024年がマイナス。案3は合計が最も大きく、3年ともプラスの設定が多いが、最大DDも大きい'],
 ['注意', '前の付け方の上位には、前向きでマイナスの候補が含まれる（案3の性質上そのまま残る）。金額は1枚＝68,800円換算、13pt控除後'],
 ['シート', '採用候補（上位5本）／採用候補（上位10本）／前向き検証'],
]
with pd.ExcelWriter(OUT, engine='openpyxl') as w:
    pd.DataFrame(desc, columns=['項目', '内容']).to_excel(w, sheet_name='説明', index=False)
    U[U['上位N本'] == 5][cols].round(2).to_excel(w, sheet_name='採用候補（上位5本）', index=False)
    U[U['上位N本'] == 10][cols].round(2).to_excel(w, sheet_name='採用候補（上位10本）', index=False)
    PR.round(2).to_excel(w, sheet_name='前向き検証', index=False)
wb = load_workbook(OUT); red = Font(name='Arial', size=10, color='C00000')
for ws in wb:
    for row in ws.iter_rows():
        for c in row:
            c.font = Font(name='Arial', size=10, bold=c.row == 1)
            if c.row > 1 and isinstance(c.value, (int, float)) and not isinstance(c.value, bool) and c.value < 0: c.font = red
    for c in ws[1]: c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.freeze_panes = 'F2' if ws.title.startswith('採用') else 'A2'
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = 11
ws = wb['説明']; ws.column_dimensions['A'].width = 16; ws.column_dimensions['B'].width = 150
for c in ws['B']: c.alignment = Alignment(wrap_text=True, vertical='top')
for n in ('採用候補（上位5本）', '採用候補（上位10本）'): wb[n].column_dimensions['E'].width = 28; wb[n].column_dimensions['G'].width = 36; wb[n].column_dimensions['N'].width = 70
wb.save(OUT); print(OUT)
