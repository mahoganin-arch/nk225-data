# ③ 順張りの主軸と逆張りの候補を同時に運用したときの重なり（逆張りの候補は確かめる期間でプラスだったもの、30件以上）
import numpy as np, pandas as pd
from lib import *
pd.set_option('display.width', 260)
SP = 13.0
Yr, enr, _, _ = setup('逆張り'); Yt = np.load(W + '/T/Y.npy', mmap_mode='r'); ev = pd.read_pickle(W + '/T/evt.pkl'); NE = len(ev); Bp = ev.B.values[enr.ev.values]
yr_ev = ev.t0.dt.year.values
def tseries(x, ex):
    r = np.nonzero((~enr.long.values) & np.isin(enr.kind.values, ['D>N', 'N>D']) & np.isclose(enr.x.values, x))[0]; s = np.full(NE, np.nan)
    s[enr.ev.values[r]] = np.asarray(Yt[r, ex], float) / 100 * P - SP * P / Bp[r]; return s
TR = {'順張り 中間（0.9%・戻り90%・利確×0.6・引け）': tseries(.9, CBI[(.9, .6, 0)]), '順張り 後半型（0.9%・戻り90%・利確×1.5・引け）': tseries(.9, CBI[(.9, 1.5, 0)])}
C = pd.read_pickle(W + '/S4C.pkl'); B = pd.read_pickle(W + '/S4B.pkl'); TRD = pd.read_pickle(W + '/S4trades.pkl')
def maxdd(v):
    c = np.cumsum(v); return float((np.maximum.accumulate(np.r_[0, c])[1:] - c).max()) if len(v) else np.nan
rows = []
for kind, sname, w, lab, rws, ex in TRD:
    v = np.asarray(Yr[rws, ex], float) / 100 * P - SP * P / Bp[rws]
    if len(v) < 30 or v.mean() <= 0: continue
    rs = np.full(NE, np.nan); evs = enr.ev.values[rws]; rs[evs] = v
    yrs = np.unique(yr_ev[evs]); per = np.isin(yr_ev, yrs) & (yr_ev >= yrs.min())
    for tn, ts in TR.items():
        t2 = np.where(per, ts, np.nan); both = ~np.isnan(rs) & ~np.isnan(t2); anyt = ~np.isnan(rs) | ~np.isnan(t2)
        comb = np.nan_to_num(rs) + np.nan_to_num(t2); order = np.nonzero(anyt)[0]
        rows.append({'逆張り候補': '%s %s %s %s' % (kind, sname, w, lab), '逆張り件数': len(v), '逆張り平均': v.mean(), '順張り': tn, '順張り件数(同期間)': int((~np.isnan(t2)).sum()), '順張り平均(同期間)': np.nanmean(t2),
                     '同じ窓で両方入った件数': int(both.sum()), '逆張りのうち重なる%': both.sum() / len(v) * 100, '重なった窓の損益相関': np.corrcoef(rs[both], t2[both])[0, 1] if both.sum() > 5 else np.nan,
                     '重なった窓の逆張り平均': rs[both].mean() if both.any() else np.nan, '重なった窓の順張り平均': t2[both].mean() if both.any() else np.nan,
                     '合算の合計': comb[order].sum(), '順張りだけの合計': np.nansum(t2), '逆張りだけの合計': v.sum(), '合算の最大DD': maxdd(comb[order]), '順張りだけの最大DD': maxdd(np.nan_to_num(t2)[order]),
                     '合算の最悪の1窓': comb[order].min(), '順張りだけの最悪の1窓': np.nanmin(t2)})
O = pd.DataFrame(rows); O.to_pickle(W + '/S5overlap.pkl'); print(O.round(1).to_string(index=False))
