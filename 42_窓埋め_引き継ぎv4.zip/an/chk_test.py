from lib import *
z = np.load(W + '/R/resel_test.npz'); fam = pd.read_pickle(W + '/R/resel_test_fam.pkl')
KEY = ['窓', '指標1', '区分1', '指標2', '区分2']; fam['fid'] = np.arange(len(fam))
for si, sel in enumerate(['前半で最良', '後半で最良', '両方で最良']):
    d = readfam('逆張り', sel); d = d[np.isclose(d['乖離幅%'], 0.5)].merge(fam, on=KEY)
    if si == 1: d = d[d['前半平均'] >= -100]
    sc = z['best_sc'][d.fid.values, si, 4]; orig = d['score'].values
    e = z['best_e'][d.fid.values, si, 4]; oe = [CBI[(round(a, 3), round(b, 3), int(c))] for a, b, c in zip(d['利確'], d['損切り'], d['時間切れ'])]
    print(sel, len(d), 'スコア一致', int((np.abs(sc - orig) < 0.6).sum()), '新>旧', int((sc > orig + 0.6).sum()), '新<旧', int((sc < orig - 0.6).sum()), '決済一致', int((e == np.array(oe)).sum()), ' 基準決済数一致', int((z['cnt'][d.fid.values, si, 4] == d['基準を満たす決済数'].values).sum()))
    for k in range(4): print('   制約', z['WL'][k], '通過', int((z['best_x'][d.fid.values, si, k] >= 0).sum()))
