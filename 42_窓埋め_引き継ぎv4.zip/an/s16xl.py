# 合意した基準でのランキングの Excel
import pandas as pd, numpy as np
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
W = '/home/claude/work'; OUT = W + '/08/results/S13_ランキング_前向きRF.xlsx'
A = pd.read_pickle(W + '/S16rank.pkl'); PR = pd.read_pickle(W + '/S16port.pkl')
cols = ['窓の種類', '向き', '順位', '候補', '使い方', '条件', '定義', '候補の窓', 'テーマ', '今のルール', 'RF', '前向き:件数', '前向き:勝率', '前向き:PF', '前向き:平均', '前向き:平均利益', '前向き:平均損失',
        '前向き:合計', '前向き:最大DD', '前向き:最悪の1回', '前向き:最大連敗', 'プラスの年', '年の数', '2022年', '2023年', '2024年', '2025年', '2026年', '選ぶ期間:件数', '選ぶ期間:PF', '選ぶ期間:平均', '選ぶ期間:合計', 'グループ', 'id']
desc = [
 ['この表について', 'まろと合意した基準（2026-10-13）での候補ランキング。順張り・逆張り × D>N・N>D 別'],
 ['基準', 'データ：前向きの記録（2022〜26年。各年は、その年より前のデータで選んだルールで売買したもの）。条件：前向きの件数20件以上、前向きの合計がプラス、選ぶ期間（2017〜21年、2022年に使ったルール）の合計もプラス。並べる指標：前向きのリカバリーファクター（RF＝合計÷最大DD）'],
 ['', '重なりのグループ（区切り0.5）が同じ候補はほぼ同じトレードなので、グループ内で最上位だけを順位付け（他は「全件」シートに残す）'],
 ['注意1', '「避ける」の候補は、条件なしからその区分だけ除いたもの。件数が多いのでRFが高く出やすく、D>N順張りの上位の多くは「条件なしの順張り＋少しの除外」でほぼ同じトレード'],
 ['注意2（重要）', 'この順位の付け方を前向きで試すと（各年の順位をその年より前の前向き記録だけで付けて、2024〜26年に組み合わせで売買）、前の順位（選ぶ期間の1回平均）より成績が悪い（組み合わせシート）。前向き記録の良し悪しは翌年の成績をほとんど予測しないため（S12の持続性と同じ結果）'],
 ['金額', '1枚＝68,800円換算、13pt控除後、円'],
 ['シート', '順位（採用候補）／全件（条件を満たさないもの・同じグループで外れたものを含む）／組み合わせ（順位の付け方の比較、2024〜26年）'],
]
with pd.ExcelWriter(OUT, engine='openpyxl') as w:
    pd.DataFrame(desc, columns=['項目', '内容']).to_excel(w, sheet_name='説明', index=False)
    A[A['採用候補']].sort_values(['窓の種類', '向き', '順位'])[cols].round(2).to_excel(w, sheet_name='順位', index=False)
    A.sort_values(['窓の種類', '向き', '条件を満たす', 'RF'], ascending=[True, True, False, False])[cols + ['条件を満たす', '採用候補', '同じグループの上位']].round(2).to_excel(w, sheet_name='全件', index=False)
    PR.round(2).to_excel(w, sheet_name='組み合わせ', index=False)
wb = load_workbook(OUT); red = Font(name='Arial', size=10, color='C00000')
for ws in wb:
    for row in ws.iter_rows():
        for c in row:
            c.font = Font(name='Arial', size=10, bold=c.row == 1)
            if c.row > 1 and isinstance(c.value, (int, float)) and c.value < 0: c.font = red
    for c in ws[1]: c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.freeze_panes = 'E2' if ws.title in ('順位', '全件') else 'A2'
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = 11
ws = wb['説明']; ws.column_dimensions['A'].width = 16; ws.column_dimensions['B'].width = 150
for c in ws['B']: c.alignment = Alignment(wrap_text=True, vertical='top')
for n in ('順位', '全件'): wb[n].column_dimensions['D'].width = 28; wb[n].column_dimensions['F'].width = 36; wb[n].column_dimensions['J'].width = 70
wb.save(OUT); print(OUT)
