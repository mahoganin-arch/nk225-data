# 買い・売り別（ゆるい基準）のまとめと Excel
#   残す：5つの評価の形のうち3つ以上でプラス、中央値+20円以上、年10件以上（13pt控除後）。改善の条件は付けない（件数以外では落とさない）
#   参考の列：条件なし（買い売り両方）・条件なし（同じ方向）・同じ条件の買い売り両方（S7）との差、前半（2017〜21年）の上乗せの向き
import glob, sys, numpy as np, pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
sys.path.insert(0, '/home/claude/work/01/code'); from common6 import jname
W = '/home/claude/work'
TFJ = {'5m': '5分', '15m': '15分', '60m': '60分', '4h': '4時間', 'D': '日足', 'W': '週足'}
def nm(x):
    if x == '条件なし': return '条件なし'
    b_, _, tf = x.rpartition('_')
    if tf in TFJ and (not b_.isascii() or b_.isupper()): return TFJ[tf] + b_
    return jname(x)
O = pd.concat([pd.read_pickle(f) for f in sorted(glob.glob(W + '/S19eval_*.pkl'))], ignore_index=True)
k = ['定義', '向き', '売買', '窓', '指標', '区分', '使い方', '後半のみ', '選び方']
G = O.groupby(k).agg(プラス数=('平均', lambda v: int((v > 0).sum())), 中央=('平均', 'median'), 最小=('平均', 'min'), 年件数=('年件数', 'median'), 最大DD=('最大DD', 'median'), 最悪=('最悪', 'min')).reset_index()
B10 = pd.concat([pd.read_pickle(f) for f in glob.glob(W + '/S10eval_*.pkl')], ignore_index=True)
b = B10[B10['指標'].isin(['条件なし', '条件なし(2024-)'])].groupby(['定義', '向き', '窓', '選び方', '後半のみ'])['平均'].median().rename('条件なし(両方)').reset_index()
G = G.merge(b, on=['定義', '向き', '窓', '選び方', '後半のみ'], how='left')
nob = G[G['指標'] == '条件なし'][['定義', '向き', '窓', '選び方', '売買', '中央']].rename(columns={'中央': '条件なし(同じ方向)'})
G = G.merge(nob, on=['定義', '向き', '窓', '選び方', '売買'], how='left')
same = B10[~B10['指標'].str.startswith('条件なし')].groupby(['定義', '向き', '窓', '指標', '区分', '使い方', '選び方'])['平均'].median().rename('同じ条件(両方)').reset_index()
G = G.merge(same, on=['定義', '向き', '窓', '指標', '区分', '使い方', '選び方'], how='left')
SC = pd.read_pickle(W + '/S19scr.pkl')[['定義', '向き', '売買', '窓', '指標', '区分', '使い方', '前半上乗せ', '後半t']]
G = G.merge(SC.drop_duplicates(['定義', '向き', '売買', '窓', '指標', '区分', '使い方']), on=['定義', '向き', '売買', '窓', '指標', '区分', '使い方'], how='left')
G['前半の向き'] = np.where(G['指標'] == '条件なし', '', np.where(G['前半上乗せ'].isna(), '', np.where((G['前半上乗せ'] > 0) == (G['使い方'] == '入る'), '同じ', '逆')))
G['指標名'] = [nm(x) for x in G['指標']]
G['残す'] = (G['プラス数'] >= 3) & (G['中央'] >= 20) & (G['年件数'] >= 10)
S10 = pd.read_pickle(W + '/S10sum.pkl'); s10keep = set(map(tuple, S10[S10['残す']][['定義', '向き', '窓', '指標', '区分', '使い方']].values))
G['両方では残っていない'] = [tuple(r) not in s10keep for r in G[['定義', '向き', '窓', '指標', '区分', '使い方']].values]
G.to_pickle(W + '/S19sum.pkl')
key = ['定義', '向き', '売買', '窓', '指標名', '区分', '使い方', '後半のみ']
B = G[G['残す']].groupby(key).agg(選び方数=('選び方', 'size'), 中央=('中央', 'mean'), 最小=('最小', 'min'), プラス数=('プラス数', 'min'), 年件数=('年件数', 'mean'), 最大DD=('最大DD', 'mean'), 最悪の1回=('最悪', 'min'),
                                 条件なし両方=('条件なし(両方)', 'mean'), 条件なし同じ方向=('条件なし(同じ方向)', 'mean'), 同じ条件の両方=('同じ条件(両方)', 'mean'),
                                 前半の向き=('前半の向き', 'first'), 両方では残っていない=('両方では残っていない', 'first')).reset_index()
B.to_pickle(W + '/S19keep.pkl')
pd.set_option('display.width', 270); pd.set_option('display.max_rows', 200)
print('評価した区分', G.groupby(key).ngroups, ' 残す（どちらかの選び方）', B.shape[0], ' 両方の選び方', (B['選び方数'] == 2).sum())
print(B.groupby(['向き', '売買', '使い方'])['選び方数'].agg(['size', lambda v: (v == 2).sum()]))
print('両方では残っていなかったもの', B['両方では残っていない'].sum(), ' 前半も同じ向き', (B['前半の向き'] == '同じ').sum())
nb = G[G['指標'] == '条件なし'].pivot_table(index=['向き', '定義', '窓', '売買'], columns='選び方', values=['中央', 'プラス数', '年件数']).round(1); print(nb)
for (s_, d_), g in B.groupby(['向き', '売買']):
    print('=====', s_, d_, len(g)); print(g.sort_values('中央', ascending=False).head(10).round(1).to_string(index=False))
if __name__ == '__main__':
    OUT = W + '/08/results/S16_買い売り別_ゆるい基準.xlsx'
    desc = [
     ['この表について', '買い・売りに分けて、候補を絞り込み過ぎない基準で分析し直したもの（まろ、2026-10-13：売り買い両方で基準を満たさなくても、売りだけで優位性があれば売りのみのストラテジーも組む）'],
     ['前回（S15）からの変更', 'ふるいで前半（2017〜21年）の向きを問わない／比べる相手を同じ方向の条件なしにする／「避ける」（その区分を除いて入る）も評価／残す基準から「条件なしより+20円良い」を外す'],
     ['ふるい', '条件なし＋F6・F7の全区分 × 買いのみ・売りのみ × 現行・先物基準 × 順張り・逆張り × 3窓。後半（2022〜26年）の上乗せ（同じ方向の条件なし比、1,944決済平均）の中央t の絶対値≥1。プラスなら「入る」、マイナスなら「避ける」'],
     ['残す', '5つの評価の形のうち3つ以上でプラス、中央値+20円以上、年10件以上（13pt控除後）。方向だけの条件なしは全部載せる'],
     ['参考の列', '条件なし両方＝買い売り両方の条件なし／条件なし同じ方向＝方向だけの条件なし／同じ条件の両方＝同じ条件の買い売り両方（S7）／前半の向き＝前半（2017〜21年）でも同じ向きの上乗せか（同じ／逆）。上昇相場だけの効果を見分ける目安／両方では残っていない＝S7（買い売り両方）では残らなかった条件'],
     ['買い・売り', '買い＝順張りは上に離れた窓、逆張りは下に離れた窓'],
     ['金額', '1枚＝68,800円換算、13pt控除後、円'],
     ['シート', '方向だけの条件なし／順張り・売り／順張り・買い／逆張り・売り／逆張り・買い（それぞれ残した候補）／まとめ全件'],
    ]
    with pd.ExcelWriter(OUT, engine='openpyxl') as w:
        pd.DataFrame(desc, columns=['項目', '内容']).to_excel(w, sheet_name='説明', index=False)
        G[G['指標'] == '条件なし'].round(1).to_excel(w, sheet_name='方向だけの条件なし', index=False)
        for s_ in ('順張り', '逆張り'):
            for d_ in ('売りのみ', '買いのみ'):
                B[(B['向き'] == s_) & (B['売買'] == d_)].sort_values(['選び方数', '中央'], ascending=[False, False]).round(1).to_excel(w, sheet_name='%s・%s' % (s_, d_[:1]), index=False)
        G.round(1).to_excel(w, sheet_name='まとめ全件', index=False)
    wb = load_workbook(OUT); red = Font(name='Arial', size=10, color='C00000')
    for ws in wb:
        for row in ws.iter_rows():
            for c in row:
                c.font = Font(name='Arial', size=10, bold=c.row == 1)
                if c.row > 1 and isinstance(c.value, (int, float)) and not isinstance(c.value, bool) and c.value < 0: c.font = red
        for c in ws[1]: c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
        ws.freeze_panes = 'A2'
        for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = 11
        if ws.title not in ('説明',): ws.column_dimensions['E'].width = 26
    ws = wb['説明']; ws.column_dimensions['A'].width = 18; ws.column_dimensions['B'].width = 150
    for c in ws['B']: c.alignment = Alignment(wrap_text=True, vertical='top')
    wb.save(OUT); print(OUT)
