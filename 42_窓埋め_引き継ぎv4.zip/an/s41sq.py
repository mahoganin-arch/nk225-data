# Pine v1.0：SQ値が取れない時（先物の過去データが SQ 日まで届かない）の手入力と、表への表示
W = '/home/claude/work/08/results/'
p = open(W + '窓埋め61本_v0.9_条件あり.txt').read()
def rep(a, b):
    global p
    assert p.count(a) == 1, (p.count(a), a[:60]); p = p.replace(a, b)
rep('indicator("窓埋め61本 v0.9 条件あり"', 'indicator("窓埋め61本 v1.0 条件あり"')
rep('LOGV = input.bool(true, "照合用の詳しいログ（OPEN・SKIP）を出す")', 'LOGV = input.bool(true, "照合用の詳しいログ（OPEN・SKIP）を出す")\nSQ_MAN = input.float(0, "SQ値の手入力（チャートで取れない時だけ使う。0=使わない）")\nMSQ_MAN = input.float(0, "メジャーSQ値の手入力（同上。0=使わない）")')
rep("""SQV = time >= sqAv ? sqCur : sqPrev
MSQV = time >= msqAv ? msqCur : msqPrev""", """SQV0 = time >= sqAv ? sqCur : sqPrev
MSQV0 = time >= msqAv ? msqCur : msqPrev
SQV = na(SQV0) and SQ_MAN > 0 ? SQ_MAN : SQV0
MSQV = na(MSQV0) and MSQ_MAN > 0 ? MSQ_MAN : MSQV0""")
rep('position.bottom_right, 2, 6, border_width = 1)', 'position.bottom_right, 2, 7, border_width = 1)')
rep('hdr = array.from("窓", "基準 CFD / 先物", "先物の寄り", "持っている本数", "この窓で手じまい")', 'hdr = array.from("窓", "基準 CFD / 先物", "先物の寄り", "持っている本数", "この窓で手じまい", "SQ値 / メジャーSQ値")')
rep('anyExit ? "あり（新しく入らない）" : "なし")', 'anyExit ? "あり（新しく入らない）" : "なし", (na(SQV) ? "取れない（手入力して）" : f_fmt(SQV) + (na(SQV0) ? "（手入力）" : "")) + " / " + (na(MSQV) ? "取れない（手入力して）" : f_fmt(MSQV) + (na(MSQV0) ? "（手入力）" : "")))')
rep('table.cell(tb, 0, 5, "注意"', 'table.cell(tb, 0, 6, "注意"')
rep('table.cell(tb, 1, 5, "ふつうの', 'table.cell(tb, 1, 6, "ふつうの')
rep("""    for r = 0 to 4
        table.cell(tb, 0, r""", """    for r = 0 to 5
        table.cell(tb, 0, r""")
rep('hot = (r == 3 and array.size(pId) > 0) or (r == 4 and anyExit)', 'hot = (r == 3 and array.size(pId) > 0) or (r == 4 and anyExit) or (r == 5 and (na(SQV) or na(MSQV)))')
open(W + '窓埋め61本_v1.0_条件あり.txt', 'w').write(p); open(W + '窓埋め61本_v1.0_条件あり.pine', 'w').write(p)
print('ok', len(p.splitlines()))
