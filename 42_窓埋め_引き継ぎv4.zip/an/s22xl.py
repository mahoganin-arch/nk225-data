# 両方＋方向別の採用候補（案3）と前向き検証の Excel
import pandas as pd, numpy as np
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
W = '/home/claude/work'; OUT = W + '/08/results/S17_採用候補_両方と方向別.xlsx'
PR = pd.read_pickle(W + '/S22port.pkl'); U = pd.read_pickle(W + '/S22list.pkl')
cols = ['窓の種類', '向き', '売買', '優先順位', '候補', '使い方', '条件', '定義', '候補の窓', 'テーマ', '両方に入る', '前の付け方の順位', '新しい付け方の順位', '今のルール',
        '前向き:件数', '前向き:勝率', '前向き:PF', '前向き:平均', '前向き:合計', '前向き:最大DD', '前向き:合計割る最大DD', '前向き:最悪の1回', '前向き:最大連敗', 'プラスの年', '年の数',
        '2022年', '2023年', '2024年', '2025年', '2026年', 'id']
desc = [
 ['この表について', '買い売り両方の候補（S7など、479件）と、買い・売りに分けた候補（S16、2,255件）を1つにまとめ、案3（前の付け方と前向きRFの上位を合わせる）で採用候補を出したもの。まろ、2026-10-13：両方の候補と方向別の候補を両方洗い出す'],
 ['手順', '①方向別の候補にも年ごとのルールでトレード一覧を作成（S19の評価と一致を確認）②方向別の候補を重なりでまとめた（向き×売買×入る/避ける、区切り0.5）③区分（窓の種類×向き×売買）ごとに、前の付け方（代表の選ぶ期間の1回平均）と新しい付け方（前向きRF、件数下限・合計プラス・2017〜21年もプラス）の上位N本を合わせる'],
 ['優先順位', '同時に出たとき（全区分共通）：①両方の物差しに入る ②2つの順位の良い方 ③前の付け方の順位'],
 ['前向き検証', '2024〜26年。各年の順位はその年より前のデータだけで付ける。候補の集まり：両方のみ／方向別のみ／両方＋方向別／売りのみ／買いのみ／両方＋売りのみ'],
 ['結果', '両方のみ：合計÷最大DD 3.7〜5.1。売りのみ：1.7〜2.8（プラス）。買いのみ：すべてマイナス（−8,099〜−19,158円）。両方＋売りのみ：2.3〜5.9（両方のみと同程度、合計は最大 51,104円）。両方＋方向別（買いを含む）は両方のみより悪い'],
 ['注意', '方向別の候補は1件ずつでは基準を満たしているが、物差しで上位を選んで組み合わせると、買いのみは2024〜26年で負けた。ゆるい基準で多く残した分、当てはめで良く見えている候補が多い可能性。採用候補リストには残すが、買いのみは記録だけにする判断もありうる'],
 ['金額', '1枚＝68,800円換算、13pt控除後、円'],
 ['シート', '採用候補（上位5本、区分ごと）／前向き検証'],
]
with pd.ExcelWriter(OUT, engine='openpyxl') as w:
    pd.DataFrame(desc, columns=['項目', '内容']).to_excel(w, sheet_name='説明', index=False)
    U[cols].round(2).to_excel(w, sheet_name='採用候補（上位5本）', index=False)
    PR.round(2).to_excel(w, sheet_name='前向き検証', index=False)
wb = load_workbook(OUT); red = Font(name='Arial', size=10, color='C00000')
for ws in wb:
    for row in ws.iter_rows():
        for c in row:
            c.font = Font(name='Arial', size=10, bold=c.row == 1)
            if c.row > 1 and isinstance(c.value, (int, float)) and not isinstance(c.value, bool) and c.value < 0: c.font = red
    for c in ws[1]: c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.freeze_panes = 'F2' if ws.title.startswith('採用') else 'A2'
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = 11
ws = wb['説明']; ws.column_dimensions['A'].width = 14; ws.column_dimensions['B'].width = 150
for c in ws['B']: c.alignment = Alignment(wrap_text=True, vertical='top')
ws = wb['採用候補（上位5本）']; ws.column_dimensions['E'].width = 28; ws.column_dimensions['G'].width = 36; ws.column_dimensions['N'].width = 70
wb.save(OUT); print(OUT)
