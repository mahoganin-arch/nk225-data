# 買い・売り別：ふるいを通った区分（と方向だけの条件なし）を5つの評価の形で評価（13pt控除後、単点／周辺）
#   使い方: python s18direval.py <定義> <向き>
import sys, numpy as np, pandas as pd
from s10eval import evaluate
from s10scr import load, make_bins, LATE
W = '/home/claude/work'
lab, side = sys.argv[1], sys.argv[2]
d = {('現行', '順張り'): W + '/T', ('先物基準', '順張り'): W + '/F6W/T6', ('現行', '逆張り'): W + '/R', ('先物基準', '逆張り'): W + '/F6W/R6'}[(lab, side)]
S = pd.read_pickle(W + '/S18scr.pkl'); S = S[(S['定義'] == lab) & (S['向き'] == side) & S['通過']]
Y, en, MN, F = load(d); en['px'] = en.ent.values if 'ent' in en else pd.read_pickle(d + '/evt.pkl').B.values[en.ev.values]
ok = ~en.long.values; yr = en.yr.values; buy = (en.d.values < 0) if side == '順張り' else (en.d.values > 0)
ba = make_bins(F.drop(columns=list(LATE)), ok & (yr <= 2021)); bl = make_bins(F[list(LATE)], ok & (yr == 2023)); ba[('条件なし', '')] = np.ones(len(en), bool)
rows = []
for n_, z in enumerate(S.itertuples()):
    late = bool(z.後半のみ); m = (bl if late else ba)[(z.指標, z.区分)] & (buy if z.売買 == '買いのみ' else ~buy)
    if late: m = m & ~np.isnan(F[z.指標].values)
    for r in evaluate(Y, en, m, z.窓, 2024 if late else 0): r.update(定義=lab, 向き=side, 売買=z.売買, 指標=z.指標, 区分=z.区分, 後半のみ=late); rows.append(r)
    if n_ % 100 == 0: print(lab, side, n_, len(S), flush=True)
pd.DataFrame(rows).to_pickle(W + '/S18eval_%s_%s.pkl' % (lab, side))
