# Pine Script v6 の準備：売買する63本＋記録だけ62本が使う指標・時間足・区分のしきい値・今のルールの一覧
#   しきい値：make_bins と同じ（その候補の定義×向きのエントリー全体、2017〜21年。後半のみの指標は2023年）。向きのある指標は「窓と同じ向き（さらに離れる側）＝プラス」に符号をそろえた値
#   区分の意味：3分割・5分割の k 番目＝ q[k−1] ≦ 値 ＜ q[k]（両端はなし）、上位10%＝値 ≧ q90、下位10%＝値 ≦ q10、=x＝値がちょうど x
import sys, re, numpy as np, pandas as pd
from s10scr import load, LATE
W = '/home/claude/work'
DS = {('現行', '順張り'): W + '/T', ('先物基準', '順張り'): W + '/F6W/T6', ('現行', '逆張り'): W + '/R', ('先物基準', '逆張り'): W + '/F6W/R6'}
A = pd.read_pickle(W + '/S26all.pkl'); C = pd.read_pickle(W + '/S21cands.pkl').set_index('id'); PK = pd.read_pickle(W + '/S20picks.pkl')
for k in ('指標', '区分', '後半のみ', '名前'): A[k + '_'] = A['id'].map(C[k])
TFJ = {'5m': '5分', '15m': '15分', '60m': '60分', '4h': '4時間', 'D': '日足', 'W': '週足'}
def family(ind):
    if ind == '条件なし': return ('なし', '')
    b, _, tf = ind.rpartition('_')
    if tf in TFJ: return ('CFDの時間足の指標', TFJ[tf])
    if ind in LATE: return ('先物の1時間足の出来高（2022/12/30〜）', '先物60分')
    if ind.startswith('日足出来高'): return ('先物の日足出来高', '先物日足')
    if ind.startswith('SQ週') or ind in ('SQ当日', 'SQ前日') or '祝日' in ind or ind.startswith('月末') or ind.startswith('月初'): return ('日付・時刻', 'SQ・祝日の暦')
    if 'SQ' in ind: return ('SQ値（先物のSQ日8:45の始値）', '先物')
    if any(w in ind for w in ('前日', '前週', '前月', '20日', '60日', 'ピボット', 'キリ', '節目', 'またいだ節目')): return ('価格の節目（CFD）', '日足・週足・月足')
    if any(w in ind for w in ('月の何週目', '四半期末月', '年末年始', '決算発表期', '配当権利前後', '米国夏時間', '曜日', '時')) and len(ind) <= 8: return ('日付・時刻', '')
    if any(w in ind for w in ('窓', '前セッション', '前々セッション', '引け', '停止中', '経過分', '寄り', '平均値幅', '上に離れた')): return ('窓・セッションの情報（CFD）', '5分（セッション単位）')
    return ('その他', '')
TH = {}
for key_d, d in DS.items():
    Y, en, MN, F = load(d); ok = ~en.long.values; yr = en.yr.values
    for i in A.index[(A['定義'] == key_d[0]) & (A['向き'] == key_d[1])]:
        ind, kb = A.at[i, '指標_'], A.at[i, '区分_']
        if ind == '条件なし': TH[i] = ('', np.nan, np.nan); continue
        if ind not in F.columns: TH[i] = ('印あり（%s の週・日）' % ind, np.nan, np.nan); continue
        v = F[ind].values.astype(float); sel = ok & ~np.isnan(v) & ((yr == 2023) if ind in LATE else (yr <= 2021)); vt = v[sel]
        if kb.startswith('='): TH[i] = ('値がちょうど %s' % kb[1:], np.nan, np.nan); continue
        if kb.startswith('3分割'): q = np.quantile(vt, [1 / 3, 2 / 3]); j = ['低', '中', '高'].index(kb[-1])
        elif kb.startswith('5分割'): q = np.quantile(vt, [.2, .4, .6, .8]); j = int(kb[-1]) - 1
        else:
            lo, hi = np.quantile(vt, [.1, .9])
            TH[i] = (('値 ≧ %.4g' % hi, hi, np.nan) if kb == '上位10%' else ('値 ≦ %.4g' % lo, np.nan, lo)); continue
        a = q[j - 1] if j > 0 else np.nan; b = q[j] if j < len(q) else np.nan
        TH[i] = (('%s値 < %.4g' % ('%.4g ≦ ' % a if j > 0 else '', b)) if j < len(q) else '値 ≧ %.4g' % a, a, b)
A['しきい値'] = [TH[i][0] for i in A.index]; A['下限(以上)'] = [TH[i][1] for i in A.index]; A['上限(未満)'] = [TH[i][2] for i in A.index]
A['種類'] = [family(x)[0] for x in A['指標_']]; A['時間足'] = [family(x)[1] for x in A['指標_']]
A['向きの符号'] = ['なし（ADX・ATR・幅など）' if re.match(r'^(adx|atr|雲の厚さ|BB幅順位|実現ボラ比|平均足実体比|平均値幅|前セッション値幅|停止中値幅|節目まで|キリ|日足出来高|前セッション最後|曜日|時|月の|四半期|年末|決算|配当|米国)', x) else '窓と同じ向き＝プラス' for x in A['指標_']]
pk = PK[(PK['評価'] == 'WF全期間') & (PK['選び方'] == '周辺') & (PK['t'] == 2026)].set_index('id')
A['乖離幅(%)'] = A['id'].map(pk['乖離幅']); A['決済(FR,SK,TM)'] = A['id'].map(pk['決済'].astype(str))
A['売買'] = A['売買']; A = A.rename(columns={'指標_': '指標(内部名)', '名前_': '名前'})
A.to_pickle(W + '/S28inv.pkl')
S = A[A['扱い'] == '売買する']
print('売買する：指標の数', S['指標(内部名)'].nunique(), ' 記録だけを含む：', A['指標(内部名)'].nunique())
print(pd.crosstab(A['種類'], A['扱い'].str[:4]))
print(A[A['種類'] == 'CFDの時間足の指標'].groupby('時間足')['指標(内部名)'].nunique())
print(A[A['種類'] == 'その他'][['指標(内部名)']].drop_duplicates().to_string())
print(S[['全体の優先順位', '名前', '定義', 'しきい値', '種類', '時間足', '乖離幅(%)', '決済(FR,SK,TM)']].sort_values('全体の優先順位').head(8).to_string(index=False))
