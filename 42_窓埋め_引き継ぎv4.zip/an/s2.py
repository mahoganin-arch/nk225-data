# ステップ2：順張りの具体ルール化（コスト13pt控除後）
#   選び方：
#     単点   … 選ぶ期間の平均が最良の (乖離幅, 決済) 1点（従来）
#     周辺   … (乖離幅, 損切り, 利確, 時間) の各軸で隣を含めた最大81点の平均が最良の点（頑健な選び方）
#     いずれも選ぶ期間で「最悪の1回 −1,000円以上」の決済に限る（なければ制約なし）、選ぶ期間15件以上の幅のみ
#   評価の形（すべて：選ぶ期間 → 確かめる期間）：
#     S1 前半→後半 / S2 22-23→24-26 / WF後半（2022〜前年で選び翌年）/ WF全期間（2017〜前年）/ WF直近3年（前3年）
import sys, numpy as np, pandas as pd
from lib import *
SP = 13.0; WORST = -1000; MINSEL = 15
Y, en, F, F2 = setup('順張り'); ev = pd.read_pickle(W + '/T/evt.pkl'); Bp = ev.B.values[en.ev.values]
RK = pd.read_pickle(W + '/T/atrrank.pkl')
XP = np.array(sorted(en.x.unique()))
# 決済の並びを「隣」が意味を持つ順に：利確なし(0)は最大の後ろ、時間切れ0(次の引け)は最長の後ろ
FRi = np.arange(12); SKi = np.r_[1:18, 0]; TMi = np.r_[1:9, 0]
PERM = np.array([(f * 18 + s) * 9 + t for f in FRi for s in SKi for t in TMi])   # 並べ替え後の位置 → CB番号
def frozen_hi(v, train):
    t = v[train & ~np.isnan(v)]; return v >= np.quantile(t, .9) if len(t) else np.zeros(len(v), bool)
STRATS = [  # (名前, 種類, 最小乖離幅, フィルター)
    ('条件なし', 'a', 0, None), ('避ける:15分MA並び=0', 'a', 0, ('ne0', 'maord_15m')),
    ('ATR5分上位10%(90日)', 'b', .2, ('rk', 'rk_atr_5m_90d')), ('ATR5分上位10%(365日)', 'b', .2, ('rk', 'rk_atr_5m_365d')),
    ('ATR15分上位10%(90日)', 'b', .2, ('rk', 'rk_atr_15m_90d')), ('ATR15分上位10%(365日)', 'b', .2, ('rk', 'rk_atr_15m_365d')),
    ('ATR5分上位10%(前半固定)', 'b', .2, ('fz', 'atr_5m')), ('ATR15分上位10%(前半固定)', 'b', .2, ('fz', 'atr_15m'))]
def schemes():
    yield 'S1 前半→後半', [(lambda y: y <= 2021, lambda y: y >= 2022, 0)]
    yield 'S2 22-23→24-26', [(lambda y: (y >= 2022) & (y <= 2023), lambda y: y >= 2024, 0)]
    yield 'WF後半', [((lambda y, t=t: (y >= 2022) & (y < t)), (lambda y, t=t: y == t), t) for t in range(2023, 2027)]
    yield 'WF全期間', [((lambda y, t=t: y < t), (lambda y, t=t: y == t), t) for t in range(2022, 2027)]
    yield 'WF直近3年', [((lambda y, t=t: (y >= t - 3) & (y < t)), (lambda y, t=t: y == t), t) for t in range(2022, 2027)]
def nbr_mean(A):
    """A: (J,12,18,9) に NaN を含む。各点の隣（±1）の平均（NaN除く）"""
    V = np.nan_to_num(A); C = (~np.isnan(A)).astype(np.float32); Vs = np.zeros_like(V); Cs = np.zeros_like(C)
    pad = [(1, 1)] * 4; Vp = np.pad(V, pad); Cp = np.pad(C, pad); J, a, b, c = A.shape
    for d0 in range(3):
        for d1 in range(3):
            for d2 in range(3):
                for d3 in range(3):
                    Vs += Vp[d0:d0 + J, d1:d1 + a, d2:d2 + b, d3:d3 + c]; Cs += Cp[d0:d0 + J, d1:d1 + a, d2:d2 + b, d3:d3 + c]
    return np.where(C > 0, Vs / np.maximum(Cs, 1), np.nan)
recs = []; picks = []
for w in SEGS:
    base = {}
    for j, x in enumerate(XP):
        idx = np.nonzero((~en.long.values) & np.isclose(en.x.values, x) & np.isin(en.kind.values, SEGS[w]))[0]
        idx = idx[np.argsort(en.m.values[idx])]; yr = en.yr.values[idx]
        G = np.asarray(Y[idx], dtype=np.float32) / 100 * P; ppt = (P / Bp[idx]).astype(np.float32)
        base[j] = dict(idx=idx, yr=yr, G=G, N=G - SP * ppt[:, None], ppt=ppt)
    for sname, typ, xmin, flt in STRATS:
        fam = {}
        for j, b in base.items():
            if XP[j] < xmin - 1e-9: continue
            if flt is None: k = np.ones(len(b['idx']), bool)
            elif flt[0] == 'ne0': k = ~(F[flt[1]].values[b['idx']] == 0)
            elif flt[0] == 'rk': k = RK[flt[1]].values[b['idx']] >= 0.9
            else: k = frozen_hi(F[flt[1]].values[b['idx']].astype(float), b['yr'] <= 2021)
            fam[j] = {kk: (v[k] if isinstance(v, np.ndarray) else v) for kk, v in b.items()}
        Js = sorted(fam)
        for scn, splits in schemes():
            for selfn, tstfn, ty in splits:
                Mn = np.full((len(Js), 1944), np.nan, np.float32); Wst = np.full((len(Js), 1944), np.nan, np.float32); cnt = np.zeros(len(Js), int)
                for q, j in enumerate(Js):
                    s = selfn(fam[j]['yr']); cnt[q] = s.sum()
                    if cnt[q] >= MINSEL: Ns = fam[j]['N'][s]; Mn[q] = Ns.mean(0); Wst[q] = Ns.min(0)
                if not (cnt >= MINSEL).any(): continue
                SM = nbr_mean(Mn[:, PERM].reshape(len(Js), 12, 18, 9)).reshape(len(Js), 1944)
                SMc = np.full_like(SM, np.nan); SMc[:, PERM] = SM                      # CB番号の並びに戻す
                okw = Wst >= WORST
                for meth, score in (('単点', Mn), ('周辺', SMc)):
                    sc = np.where(np.isnan(Mn), -np.inf, score); sc2 = np.where(okw, sc, -np.inf)
                    use = sc2 if np.isfinite(sc2).any() else sc
                    q, e = np.unravel_index(int(np.argmax(use)), use.shape); j = Js[q]; fj = fam[j]
                    t = tstfn(fj['yr'])
                    picks.append(dict(評価=scn, 確かめる年=ty, 窓=w, 戦略=sname, 種類=typ, 選び方=meth, 乖離幅=XP[j], 決済=CB[e], 選ぶ期間件数=int(cnt[q]),
                                      選ぶ期間平均=float(Mn[q, e]), 選ぶ期間周辺平均=float(SMc[q, e]), 最悪制約=bool(np.isfinite(sc2).any()), 確かめる件数=int(t.sum())))
                    for r in np.nonzero(t)[0]:
                        recs.append((scn, ty, w, sname, typ, meth, XP[j], e, int(fj['idx'][r]), int(fj['yr'][r]), float(fj['N'][r, e]), float(fj['G'][r, e]), float(fj['ppt'][r])))
        print(w, sname, len(recs), flush=True)
R = pd.DataFrame(recs, columns=['評価', '確かめる年', '窓', '戦略', '種類', '選び方', '乖離幅', '決済番号', 'row', '年', '損益', '控除前', '円per pt'])
R['ev'] = en.ev.values[R.row]; R['m'] = en.m.values[R.row]
R.to_pickle(W + '/S2rec.pkl'); pd.DataFrame(picks).to_pickle(W + '/S2pick.pkl'); print(R.shape, len(picks))
