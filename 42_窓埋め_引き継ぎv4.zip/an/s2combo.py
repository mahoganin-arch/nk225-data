# 組み合わせ運用：記録（確かめる期間のトレード）を時刻順につなげて評価
import numpy as np, pandas as pd
from lib import W
pd.set_option('display.width', 260); pd.set_option('display.max_rows', 300)
R = pd.read_pickle(W + '/S2rec.pkl')
def maxdd(v):
    c = np.cumsum(v); return float((np.maximum.accumulate(np.r_[0, c])[1:] - c).max()) if len(v) else np.nan
def part(scn, meth, w, s): return R[(R['評価'] == scn) & (R['選び方'] == meth) & (R['窓'] == w) & (R['戦略'] == s)]
B = 'ATR5分上位10%(365日)'
COMBOS = {
    'D>N条件なし＋N>D条件なし（窓ごとに選ぶ）': lambda sc, me: [part(sc, me, 'D>N', '条件なし'), part(sc, me, 'N>D', '条件なし')],
    '両方の窓 条件なし（まとめて選ぶ）': lambda sc, me: [part(sc, me, '両方の窓', '条件なし')],
    'D>N条件なしのみ': lambda sc, me: [part(sc, me, 'D>N', '条件なし')],
    '両方の窓：条件なし＋ATR5分(365日) 両方保有': lambda sc, me: [part(sc, me, '両方の窓', '条件なし'), part(sc, me, '両方の窓', B)],
    '両方の窓：条件なし＋ATR5分(365日) ATR優先': lambda sc, me: 'prio',
    'D>N：条件なし＋ATR5分(365日) 両方保有': lambda sc, me: [part(sc, me, 'D>N', '条件なし'), part(sc, me, 'D>N', B)],
}
rows = []; yrows = []
for sc in R['評価'].unique():
    for me in ('単点', '周辺'):
        for name, f in COMBOS.items():
            ps = f(sc, me)
            if isinstance(ps, str):
                a = part(sc, me, '両方の窓', '条件なし'); b = part(sc, me, '両方の窓', B); a = a[~a.ev.isin(b.ev)]; ps = [a, b]
            g = pd.concat(ps).sort_values('m')
            if g.empty: continue
            v = g['損益'].values; ny = g['年'].max() - g['年'].min() + 1
            # 同じ窓（イベント）での同時保有の数
            sim = g.groupby('ev').size()
            r = {'評価': sc, '選び方': me, '組み合わせ': name, '件数': len(v), '年あたり件数': len(v) / ny, '平均': v.mean(), '勝率%': (v > 0).mean() * 100, '最悪の1回': v.min(),
                 '同じ窓で2本の割合%': (sim >= 2).mean() * 100, '最悪の1窓(合計)': g.groupby('ev')['損益'].sum().min(), '最大DD': maxdd(v), '合計': v.sum(), '年あたり合計': v.sum() / ny,
                 '損益分岐pt': g['控除前'].sum() / g['円per pt'].sum()}
            for y, gg in g.groupby('年'):
                r['%d合計' % y] = gg['損益'].sum(); yrows.append({'評価': sc, '選び方': me, '組み合わせ': name, '年': y, '件数': len(gg), '平均': gg['損益'].mean(), '合計': gg['損益'].sum(), '年内最大DD': maxdd(gg['損益'].values)})
            rows.append(r)
C = pd.DataFrame(rows); C.to_pickle(W + '/S2combo.pkl'); pd.DataFrame(yrows).to_pickle(W + '/S2comboY.pkl')
c = ['評価', '選び方', '組み合わせ', '件数', '年あたり件数', '平均', '勝率%', '最悪の1回', '最悪の1窓(合計)', '最大DD', '年あたり合計', '損益分岐pt'] + ['%d合計' % y for y in range(2022, 2027)]
print(C[c].round(0).to_string(index=False))
