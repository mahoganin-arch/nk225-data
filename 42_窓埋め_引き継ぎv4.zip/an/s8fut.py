# 5-4 先物基準の窓：条件なしの逆張り・順張り（コスト13pt控除後）を、ステップ2と同じ選び方・評価の形で評価
#   変種：窓の大きさの下限（寄りの窓 0／0.05／0.1%以上）
#   選び方：単点／周辺（各軸±1、最大81点の平均）。選ぶ期間で最悪 −1,000円以上・15件以上
#   評価の形：S1 前半→後半 / S2 22-23→24-26 / WF後半 / WF全期間 / WF直近3年
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/work/01/code'); from common6 import CB, P
W = '/home/claude/work'; SP = 13.0; WORST = -1000; MINSEL = 15
SEGS = {'D>N': ['D>N'], 'N>D': ['N>D'], '両方の窓': ['D>N', 'N>D']}
FRi = np.arange(12); SKi = np.r_[1:18, 0]; TMi = np.r_[1:9, 0]
PERM = np.array([(f * 18 + s) * 9 + t for f in FRi for s in SKi for t in TMi])
def schemes():
    yield 'S1 前半→後半', [(lambda y: y <= 2021, lambda y: y >= 2022, 0)]
    yield 'S2 22-23→24-26', [(lambda y: (y >= 2022) & (y <= 2023), lambda y: y >= 2024, 0)]
    yield 'WF後半', [((lambda y, t=t: (y >= 2022) & (y < t)), (lambda y, t=t: y == t), t) for t in range(2023, 2027)]
    yield 'WF全期間', [((lambda y, t=t: y < t), (lambda y, t=t: y == t), t) for t in range(2022, 2027)]
    yield 'WF直近3年', [((lambda y, t=t: (y >= t - 3) & (y < t)), (lambda y, t=t: y == t), t) for t in range(2022, 2027)]
def nbr_mean(A):
    V = np.nan_to_num(A); C = (~np.isnan(A)).astype(np.float32); Vs = np.zeros_like(V); Cs = np.zeros_like(C)
    pad = [(1, 1)] * 4; Vp = np.pad(V, pad); Cp = np.pad(C, pad); J, a, b, c = A.shape
    for d0 in range(3):
        for d1 in range(3):
            for d2 in range(3):
                for d3 in range(3):
                    Vs += Vp[d0:d0 + J, d1:d1 + a, d2:d2 + b, d3:d3 + c]; Cs += Cp[d0:d0 + J, d1:d1 + a, d2:d2 + b, d3:d3 + c]
    return np.where(C > 0, Vs / np.maximum(Cs, 1), np.nan)
def maxdd(v):
    c = np.cumsum(v); return float((np.maximum.accumulate(np.r_[0, c])[1:] - c).max()) if len(v) else np.nan
def load(side, d):
    Y = np.load(d + '/Y.npy', mmap_mode='r'); en = pd.read_pickle(d + '/en.pkl'); ev = pd.read_pickle(d + '/evt.pkl')
    en = en.join(ev[['kind', 'long', 't0']], on='ev'); en['yr'] = en.t0.dt.year
    if 'gap%' in ev: en['gap%'] = ev['gap%'].values[en.ev.values]; en['px'] = en.ent.values
    else: en['gap%'] = np.inf; en['px'] = ev.B.values[en.ev.values]
    return Y, en
def evaluate(label, side, Y, en, gmin):
    XP = np.array(sorted(en.x.unique())); recs = []; picks = []
    for w in SEGS:
        fam = {}
        for j, x in enumerate(XP):
            idx = np.nonzero((~en.long.values) & np.isclose(en.x.values, x) & np.isin(en.kind.values, SEGS[w]) & (en['gap%'].values >= gmin))[0]
            idx = idx[np.argsort(en.m.values[idx])]
            G = np.asarray(Y[idx], dtype=np.float32) / 100 * P; ppt = (P / en.px.values[idx]).astype(np.float32)
            fam[j] = dict(idx=idx, yr=en.yr.values[idx], G=G, N=G - SP * ppt[:, None], ppt=ppt)
        Js = sorted(fam)
        for scn, splits in schemes():
            for selfn, tstfn, ty in splits:
                Mn = np.full((len(Js), 1944), np.nan, np.float32); Wst = np.full((len(Js), 1944), np.nan, np.float32); cnt = np.zeros(len(Js), int)
                for q, j in enumerate(Js):
                    s = selfn(fam[j]['yr']); cnt[q] = s.sum()
                    if cnt[q] >= MINSEL: Ns = fam[j]['N'][s]; Mn[q] = Ns.mean(0); Wst[q] = Ns.min(0)
                if not (cnt >= MINSEL).any(): continue
                SM = nbr_mean(Mn[:, PERM].reshape(len(Js), 12, 18, 9)).reshape(len(Js), 1944); SMc = np.full_like(SM, np.nan); SMc[:, PERM] = SM
                okw = Wst >= WORST
                for meth, score in (('単点', Mn), ('周辺', SMc)):
                    sc = np.where(np.isnan(Mn), -np.inf, score); sc2 = np.where(okw, sc, -np.inf); use = sc2 if np.isfinite(sc2).any() else sc
                    q, e = np.unravel_index(int(np.argmax(use)), use.shape); j = Js[q]; fj = fam[j]; t = tstfn(fj['yr'])
                    picks.append(dict(定義=label, 向き=side, 窓の下限=gmin, 評価=scn, 確かめる年=ty, 窓=w, 選び方=meth, 乖離幅=XP[j], 決済=CB[e], 選ぶ期間件数=int(cnt[q]), 選ぶ期間平均=float(Mn[q, e]), 確かめる件数=int(t.sum())))
                    for r in np.nonzero(t)[0]: recs.append((label, side, gmin, scn, w, meth, int(fj['yr'][r]), int(fj['idx'][r]), float(fj['N'][r, e]), float(fj['G'][r, e]), float(fj['ppt'][r])))
    return recs, picks
allrec = []; allpick = []
RUNS = [('先物基準', '順張り', W + '/F6W/T6', (0, .05, .1)), ('先物基準', '逆張り', W + '/F6W/R6', (0, .05, .1)), ('現行(CFD基準)', '順張り', W + '/T', (0,)), ('現行(CFD基準)', '逆張り', W + '/R', (0,))]
for label, side, d, gs in RUNS:
    Y, en = load(side, d)
    for gm in gs:
        r, p = evaluate(label, side, Y, en, gm); allrec += r; allpick += p; print(label, side, gm, len(allrec), flush=True)
R = pd.DataFrame(allrec, columns=['定義', '向き', '窓の下限', '評価', '窓', '選び方', '年', 'row', '損益', '控除前', '円per pt'])
PK = pd.DataFrame(allpick); R.to_pickle(W + '/S8rec.pkl'); PK.to_pickle(W + '/S8pick.pkl')
def summ(g):
    v = g['損益'].values; return pd.Series({'件数': len(v), '年あたり件数': len(v) / max(1, g['年'].nunique()), '平均': v.mean(), '勝率%': (v > 0).mean() * 100, '最悪': v.min(), '最大DD': maxdd(v), '合計': v.sum(),
                                            '損益分岐pt': g['控除前'].sum() / g['円per pt'].sum(), **{str(y): g.loc[g['年'] == y, '損益'].mean() for y in range(2022, 2027)}})
K = ['定義', '向き', '窓の下限', '評価', '窓', '選び方']
S = R.sort_values('row').groupby(K, sort=False).apply(summ).reset_index(); S.to_pickle(W + '/S8sum.pkl')
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 400)
print(S[K + ['件数', '平均', '最大DD', '損益分岐pt']].round(1).to_string(index=False))
