# 5-4 先物基準の窓の Excel
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
W = '/home/claude/work'; OUT = W + '/08/results/S5_先物基準の窓.xlsx'
S = pd.read_pickle(W + '/S8sum.pkl'); FX = pd.read_pickle(W + '/S8fixed.pkl'); PK = pd.read_pickle(W + '/S8pick.pkl'); PK['決済'] = PK['決済'].astype(str)
idx = ['向き', '窓', '選び方', '定義', '窓の下限']
pv = S.pivot_table(index=idx, columns='評価', values='平均').reset_index()
pv['プラスの数(5つ中)'] = (S.pivot_table(index=idx, columns='評価', values='平均') > 0).sum(axis=1).values
pv['年あたり件数(WF全期間)'] = S.pivot_table(index=idx, columns='評価', values='年あたり件数')['WF全期間'].values
desc = [
 ['この表について', '5-4 先物基準の窓（信号は先物、売買はCFD）を、条件なしの逆張り・順張りでステップ2と同じ選び方・評価の形で評価し、現行（CFD基準）と比べたもの。コスト13pt控除後、円/回'],
 ['定義', '基準＝前セッションの先物の終値。判定は先物の寄りから。寄りで既にx%以上（窓と同じ向き）なら寄りで入る（CFDの寄り時刻の足の始値）。寄り後に基準からx%届いたら、その先物の足が終わった時刻のCFDの足の始値で入る。届く前に基準まで戻ったら（同じ足で両方も）入らない'],
 ['', '利確・損切りはCFDのエントリー価格からの割合の距離で、CFDの価格で判定。逆張りの利確の基準＝先物の基準からの乖離（寄りで入った場合は寄りの窓の大きさ）。夜間引け6:00の時期は5:55で手じまい'],
 ['', '先物は2023/10/16以降1分足、それ以前5分足。窓の大きさの下限は 0／0.05／0.1% を比較'],
 ['母集団', '先物基準の入る件数は小さい乖離幅ほど「寄りで入る」が大半（0.1%で75%、0.9%で10%）。0.9%のD>Nでは現行の87%が既に寄り後のエントリーで、先物基準との重なり312窓、損益の相関0.88（同じ決済で）'],
 ['結果（順張り）', 'D>N：先物基準は5つの評価の形すべてプラス（単点 +39〜+121円、周辺 +29〜+89円）で、現行（+13〜+73、WF後半はマイナス）より良い。固定の後半型でも後半 +119円 vs 現行 +97円、後半DD 3,231 vs 4,841円'],
 ['', 'N>D：先物基準は弱い（5つ中プラス0〜2）。現行のN>Dの方が良い'],
 ['', '両方の窓：先物基準と現行はほぼ同程度。固定ルールでは現行の方が前半・全期間DDとも良い（中間型 全期間DD 6,888 vs 13,623円）'],
 ['結果（逆張り）', '先物基準でも条件なしはほぼマイナス。N>Dの先物基準だけ4/5プラスだが年13件・+2〜+61円で、試した数から見て偶然の範囲'],
 ['窓の大きさの下限', '0／0.05／0.1%でほぼ差なし。逆張りの利確距離・順張りの損切り距離は乖離幅x以上なので、小さすぎる窓の問題は小さい乖離幅（コスト負け）として既に現れている'],
 ['注意', 'D>Nは先物基準、N>Dは現行という組み合わせは、結果を見てから選んだもの。偶然の可能性があり、2026/10/9以降のデータでの確認が必要'],
 ['シート', '評価の形ごと：5つの評価の形の確かめる期間の平均／まとめ全件：件数・勝率・最大DD・年ごと／固定ルール：同じ固定ルールの年ごと比較／選ばれた点：各評価で選ばれた乖離幅・決済'],
]
with pd.ExcelWriter(OUT, engine='openpyxl') as w:
    pd.DataFrame(desc, columns=['項目', '内容']).to_excel(w, sheet_name='説明', index=False)
    pv.round(1).to_excel(w, sheet_name='評価の形ごと', index=False)
    S.round(1).to_excel(w, sheet_name='まとめ全件', index=False)
    FX.round(1).to_excel(w, sheet_name='固定ルール', index=False)
    PK.round(1).to_excel(w, sheet_name='選ばれた点', index=False)
wb = load_workbook(OUT)
for ws in wb:
    for row in ws.iter_rows():
        for c in row: c.font = Font(name='Arial', size=10, bold=c.row == 1)
    for c in ws[1]: c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.freeze_panes = 'A2'
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = 13
ws = wb['説明']; ws.column_dimensions['A'].width = 18; ws.column_dimensions['B'].width = 150
for c in ws['B']: c.alignment = Alignment(wrap_text=True, vertical='top')
wb['固定ルール'].column_dimensions['B'].width = 36
wb.save(OUT); print(OUT)
