# 63本の決め方で、①同時に持つ方針ごとの年別成績 ②全体の優先順位の上位K本だけ使ったときの成績
#   各年 t の一覧・優先順位はその年より前のデータだけで決める（s25narrow と同じ）。上位K本は全体の優先順位で切る
src = open('/home/claude/work/08/an/s25narrow.py').read(); exec(src[:src.index("DIRS = ('両方', '売りのみ'); PR = []")])
DIRS = ('両方', '売りのみ'); LS = {}
for t in (2024, 2025, 2026):
    L = narrow(union_list(rank_old(t), rank_rf(t), 5, DIRS), fwd_stats(t), .75, 1.2)
    allr = [(k, r) for k, rows in L.items() for r in rows]; allr.sort(key=lambda kr: (not kr[1][1], min(kr[1][2], kr[1][3]), kr[1][2]))
    LS[t] = {(r[0], k[0]): p for p, (k, r) in enumerate(allr)}
def sim_k(K, pol):
    out = []
    for t in (2024, 2025, 2026):
        pr = {k: p for k, p in LS[t].items() if p < K}
        test = T0[(T0['t'] == t) & (T0['年'] == t)].copy(); test['順位'] = [pr.get((a, b), np.nan) for a, b in zip(test['id'], test['窓の種類'])]
        test = test[test['順位'].notna()].sort_values(['セッション', '入る時刻', '順位'])
        for s_, tr in test.groupby('セッション', sort=False):
            for h in run_window(tr.to_dict('records'), pol, False, fill.get(s_, np.inf)): h['確かめる年'] = t; out.append(h)
    return pd.DataFrame(out)
PR = []
for K in (5, 10, 15, 20, 30, 40, 50, 999):
    for pol, pn in (('A1', '1本だけ（先着）'), ('B', '買い1本＋売り1本（両建て）'), ('C1', '同じ向き2本'), ('D1', '両建て＋2本目')):
        H = sim_k(K, pol).sort_values('手じまう時刻'); r = stats(H['損益'].values, 3)
        r.update(上位K本=('全部' if K == 999 else K), 方針=pn, 各年の本数=' / '.join(str(min(K, len(LS[t]))) for t in LS),
                 同時に2本持った窓=int((H.groupby('セッション').size() >= 2).sum()))
        for y, g in H.groupby('確かめる年'):
            v = g.sort_values('手じまう時刻')['損益'].values; c = np.cumsum(v)
            r['%d年' % y] = v.sum(); r['%d年DD' % y] = (np.maximum.accumulate(np.r_[0, c])[1:] - c).max()
        PR.append(r)
PR = pd.DataFrame(PR); PR.to_pickle(W + '/S27topk.pkl')
pd.set_option('display.width', 280)
print(PR[['上位K本', '方針', '各年の本数', '件数', '勝率', 'PF', '合計', '最大DD', '合計割る最大DD', '同時に2本持った窓', '2024年', '2024年DD', '2025年', '2025年DD', '2026年', '2026年DD']].round(1).to_string(index=False))
