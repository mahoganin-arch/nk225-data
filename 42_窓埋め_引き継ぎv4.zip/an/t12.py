# 追加検証1（逆方向）・2（未検証の軸）
import os, numpy as np, pandas as pd
from lib import *
from scipy.stats import spearmanr
pd.set_option('display.width', 250)
def base_year(side):
    """条件なし：窓×乖離幅×年×決済の平均と件数（キャッシュ）"""
    dd = W + ('/R' if side == '逆張り' else '/T'); fn = dd + '/base_year.npz'
    if os.path.exists(fn): z = np.load(fn); return z['M'], z['N']
    Y, en, F = load(dd); XP = sorted(en.x.unique()); M = np.full((3, len(XP), 10, NCB), np.nan, np.float32); N = np.zeros((3, len(XP), 10), int)
    for si, (s, g) in enumerate(SEGS.items()):
        for xi, x in enumerate(XP):
            m = (~en.long.values) & np.isclose(en.x.values, x) & np.isin(en.kind.values, g)
            for yr in range(10):
                ii = np.nonzero(m & (en.yr.values == 2017 + yr))[0]; N[si, xi, yr] = len(ii)
                if len(ii): M[si, xi, yr] = np.asarray(Y[ii], dtype=np.float64).mean(0) / 100 * P
    np.savez(fn, M=M, N=N); return M, N
SI = {s: i for i, s in enumerate(SEGS)}
XP = np.array([.03, .04, .05, .06, .075, .09, .1, .11, .125, .14, .15, .175, .2, .225, .25, .275, .3, .35, .4, .45, .5, .6, .7, .8, .9, 1.0, 1.2, 1.5])
def add_base(d, side):
    M, N = base_year(side); w = d['窓'].map(SI).values; xi = np.searchsorted(XP, d['乖離幅%'].values - 1e-9)
    e = np.array([CBI[(round(a, 3), round(b, 3), int(c))] for a, b, c in zip(d['利確'], d['損切り'], d['時間切れ'])])
    for h, sl in (('前半', slice(0, 5)), ('後半', slice(5, 10))):
        mm = M[w, xi, sl, e] if False else M[w[:, None], xi[:, None], np.arange(10)[sl][None], e[:, None]]; nn = N[w[:, None], xi[:, None], np.arange(10)[sl][None]]
        d['条件なし' + h] = (mm * nn).sum(1) / np.maximum(nn.sum(1), 1)
        d[h + '上乗せ'] = d[h + '平均'] - d['条件なし' + h]
    return d
def axis_report(d, sel_h, test_h, axes, title):
    tgt = test_h + '上乗せ'; print('\n====', title, '件数', len(d))
    print(' %s上乗せ 平均 %.1f / %s上乗せ 平均 %.1f / %s上乗せ>0 %.1f%% / 順位相関(%s上乗せ×%s上乗せ) %.3f' % (sel_h, d[sel_h + '上乗せ'].mean(), test_h, d[tgt].mean(), test_h, (d[tgt] > 0).mean() * 100, sel_h, test_h, spearmanr(d[sel_h + '上乗せ'], d[tgt], nan_policy='omit')[0]))
    out = []
    for a in axes:
        v = d[a].astype(float); r = spearmanr(v, d[tgt], nan_policy='omit')[0]
        q = pd.qcut(v.rank(method='first'), 5, labels=False); g = d.groupby(q)[tgt].agg(['mean', lambda s: (s > 0).mean() * 100])
        out.append((a, round(r, 3), *[round(x, 1) for x in g['mean']], round(g.iloc[-1, 1], 1)))
    R = pd.DataFrame(out, columns=['軸', '順位相関', '下位20%', '20-40%', '40-60%', '60-80%', '上位20%', '上位20%の上乗せ>0率'])
    print(R.to_string(index=False)); return R
res = []
for side in ('逆張り', '順張り'):
    # 1. 逆方向：後半で選ぶ → 前半で確かめる（元のCSV、前半の最低ラインなし）
    d = add_base(readfam(side, '後半で最良'), side)
    d['後半プラス年率'] = d['後半プラス年'] / d['後半年数']; d['−log p'] = -np.log10(d['後半p'].clip(1e-12))
    d['単独'] = (d['指標2'] == '').astype(int)
    r = axis_report(d, '後半', '前半', ['後半平均', '後半上乗せ', '−log p', '後半件数', '後半勝率', '後半プラス年率', '後半プラス決済%', '基準を満たす決済数', '通過した幅の数', '連続した幅の最大数', '単独'], side + ' 1.逆方向（後半で選び→前半）'); r.insert(0, '検証', side + ' 逆方向'); res.append(r)
    # 2. 未検証の軸：前半で選ぶ → 後半（元のCSV）＋年ごとの安定性（再選定の表）
    d = add_base(readfam(side, '前半で最良'), side)
    d['前半プラス年率'] = d['前半プラス年'] / d['前半年数']; d['−log p'] = -np.log10(d['前半p'].clip(1e-12)); d['単独'] = (d['指標2'] == '').astype(int)
    T = pd.read_pickle(W + ('/R' if side == '逆張り' else '/T') + '/table.pkl'); T = T[(T['選び方'] == '前半で優位') & (T['最悪の上限'] == 'なし')]
    M, N = base_year(side); w = T['窓'].map(SI).values; xi = np.searchsorted(XP, T['乖離幅%'].values - 1e-9)
    e = np.array([CBI[(round(a, 3), round(b, 3), int(c))] for a, b, c in zip(T['利確'], T['損切り'], T['時間切れ'])])
    yl = T[[str(y) for y in range(2017, 2022)]].values - M[w[:, None], xi[:, None], np.arange(5)[None], e[:, None]]
    T = T.assign(年上乗せプラス数=np.nansum(yl > 0, 1), 年上乗せ最小=np.nanmin(yl, 1), 年上乗せばらつき=-np.nanstd(yl, 1))
    K = ['窓', '指標1', '区分1', '指標2', '区分2']
    d['乖離幅%r'] = d['乖離幅%'].round(4); T['乖離幅%r'] = T['乖離幅%'].round(4)
    d = d.merge(T[K + ['乖離幅%r', '利確', '損切り', '時間切れ', '年上乗せプラス数', '年上乗せ最小', '年上乗せばらつき']], on=K + ['乖離幅%r', '利確', '損切り', '時間切れ'], how='left')
    print(side, '年別の結合', int(d['年上乗せプラス数'].notna().sum()), '/', len(d))
    r = axis_report(d, '前半', '後半', ['−log p', '前半件数', '前半勝率', '前半プラス年率', '年上乗せプラス数', '年上乗せ最小', '年上乗せばらつき', '単独'], side + ' 2.未検証の軸（前半で選び→後半）'); r.insert(0, '検証', side + ' 未検証の軸'); res.append(r)
pd.concat(res).to_csv(W + '/an/t12.csv', index=False)
