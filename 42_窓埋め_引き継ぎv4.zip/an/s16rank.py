# 合意した基準（まろ、2026-10-13）での候補ランキング
#   データ：前向きの記録（2022〜26年。各年はその年より前のデータで選んだルール＝WF全期間・周辺）
#   条件：前向きの件数20件以上（その窓の種類で）、前向きの合計がプラス、かつ選ぶ期間（2017〜21年。2022年に使ったルール＝2017〜21年で選んだルール）の合計もプラス
#   並べる指標：前向きのリカバリーファクター（合計÷最大DD）
#   順張り・逆張り × D>N・N>D 別。重なりのグループ（区切り0.5）が同じ候補は、ほぼ同じトレードなのでグループ内で最上位だけを残す（他は「同じグループ」として一覧に残す）
#   対象：残したすべての候補（逆張りC・Bは年ごとのルールがないため除く）
#   追加の確認：この順位の付け方で組み合わせたときの前向き検証（各年 t の順位は 2022〜t−1 年の前向き記録だけで付ける。件数の下限は年数に合わせて 5×年数件）
import sys, numpy as np, pandas as pd
sys.argv = [sys.argv[0]]
exec(open('/home/claude/work/08/an/s13sim.py').read().split("if __name__ == '__main__':")[0])
from s14report_funcs import stats, rule_text, cond_text
SCN, METH = 'WF全期間', '周辺'
PK = pd.read_pickle(W + '/S13picks.pkl'); TT = T0[(T0['評価'] == SCN) & (T0['選び方'] == METH)]
WF = TT[TT['年'] == TT['t']]
SELP = TT[(TT['t'] == 2022) & (TT['年'] <= 2021)]           # 選ぶ期間：2022年のルールで 2017〜21年
CUR = TT[TT['t'] == 2026]
rows = []
for (i, kind), v in WF.groupby(['id', '窓の種類']):
    v = v.sort_values('手じまう時刻'); s = stats(v['損益'].values, None); z = C.loc[i]
    sp = SELP[(SELP['id'] == i) & (SELP['窓の種類'] == kind)].sort_values('手じまう時刻'); ss = stats(sp['損益'].values, None) if len(sp) else {}
    p = PK[(PK['id'] == i) & (PK['評価'] == SCN) & (PK['選び方'] == METH) & (PK['t'] == 2026)]
    yr = v.groupby('年')['損益'].sum()
    r = dict(id=i, 窓の種類=kind, 向き=z['向き'], 候補=z['名前'].replace('=-0', '=0'), 使い方=z['使い方'], 条件=cond_text(z), 定義=z['定義'], 候補の窓=z['窓'], テーマ=z['テーマ'], グループ=z['グループ'],
             今のルール=rule_text(z['向き'], p['乖離幅'].iloc[0], p['決済'].iloc[0]) if len(p) else '', プラスの年=int((yr > 0).sum()), 年の数=len(yr))
    r.update({'前向き:' + k: x for k, x in s.items()}); r.update({'選ぶ期間:' + k: x for k, x in ss.items()})
    for y in range(2022, 2027): r['%d年' % y] = yr.get(y, np.nan)
    rows.append(r)
A = pd.DataFrame(rows)
A['条件を満たす'] = (A['前向き:件数'] >= 20) & (A['前向き:合計'] > 0) & (A['選ぶ期間:合計'].fillna(-1) > 0)
A['RF'] = A['前向き:合計割る最大DD']
A = A.sort_values(['窓の種類', '向き', '条件を満たす', 'RF'], ascending=[True, True, False, False])
A['グループ内の順'] = A.groupby(['窓の種類', '向き', 'グループ', '条件を満たす']).cumcount() + 1
A['採用候補'] = A['条件を満たす'] & (A['グループ内の順'] == 1)
A['順位'] = np.nan
for (k, s_), g in A[A['採用候補']].groupby(['窓の種類', '向き']): A.loc[g.index, '順位'] = np.arange(1, len(g) + 1)
# 同じグループで外れた候補の名前
best = A[A['採用候補']].set_index(['窓の種類', '向き', 'グループ'])['候補']
A['同じグループの上位'] = [best.get((r.窓の種類, r.向き, r.グループ), '') if (r.条件を満たす and not r.採用候補) else '' for r in A.itertuples()]
A.to_pickle(W + '/S16rank.pkl')
# ---- この順位の付け方での組み合わせ（前向き検証、2024〜26年）
def simulate_rf(N, pol, mode):
    T = TT[TT['id'].isin(set(C.index))]; out = []
    for t in (2024, 2025, 2026):
        past = WF[(WF['年'] < t)]
        sc = {}
        for (i, kind), v in past.groupby(['id', '窓の種類']):
            v = v.sort_values('手じまう時刻')['損益'].values; ny = t - 2022
            if mode == 'RF':
                if len(v) < 5 * ny or v.sum() <= 0: continue
                sel = SELP[(SELP['id'] == i) & (SELP['窓の種類'] == kind)]['損益'].sum()
                if sel <= 0: continue
                c = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, c])[1:] - c).max(); sc[(i, kind)] = v.sum() / max(dd, 1.0)
        test = T[(T['t'] == t) & (T['年'] == t)].copy()
        if mode == 'RF':
            test['順位'] = [-sc.get((a, b), np.nan) for a, b in zip(test['id'], test['窓の種類'])]
            grp = C['グループ']; test = test[test['順位'].notna()]
            # グループ内で最上位だけ
            tops = test.groupby(['窓の種類', test['id'].map(grp)])['順位'].transform('min'); test = test[test['順位'] == tops]
        else:
            Tt = T[T['t'] == t]; ins = Tt[Tt['年'] < t].groupby('id')['損益'].agg(['mean', 'size']); ins = ins[ins['size'] >= 15]['mean']
            test = test[test['id'].isin(UNIV['代表(0.5)'])]; test['順位'] = -test['id'].map(ins); test = test[test['順位'].notna()]
        keep = []
        for kind in ('D>N', 'N>D'):
            tk = test[test['窓の種類'] == kind]
            for side, g in tk.groupby(tk['id'].map(C['向き'])):
                ids = g.groupby('id')['順位'].first().sort_values().head(N).index; keep.append(g[g['id'].isin(ids)])
        test = pd.concat(keep).sort_values(['セッション', '入る時刻', '順位'])
        for s_, tr in test.groupby('セッション', sort=False):
            for h in run_window(tr.to_dict('records'), pol, False, fill.get(s_, np.inf)): h['確かめる年'] = t; out.append(h)
    return pd.DataFrame(out)
PR = []
for mode, nm in (('RF', '新しい順位（前向きRF）'), ('OLD', '前の順位（選ぶ期間の平均）')):
    for N in (5, 10):
        for pol in ('A1', 'C1', 'D1'):
            H = simulate_rf(N, pol, mode); r = stats(H.sort_values('手じまう時刻')['損益'].values, 3)
            r.update(順位の付け方=nm, 上位N本=N, 方針={'A1': '先着1本', 'C1': '同じ向き2本', 'D1': '両建て＋2本目'}[pol], 最悪の1窓=H.groupby('セッション')['損益'].sum().min())
            for y, g in H.groupby('確かめる年'): r['%d年' % y] = g['損益'].sum()
            PR.append(r)
PR = pd.DataFrame(PR); PR.to_pickle(W + '/S16port.pkl')
pd.set_option('display.width', 280); pd.set_option('display.max_colwidth', 40)
for (k, s_), g in A[A['採用候補']].groupby(['窓の種類', '向き']):
    print('=====', k, s_, len(g)); print(g[['順位', '候補', '使い方', '定義', '前向き:件数', '前向き:勝率', '前向き:PF', '前向き:平均', '前向き:合計', '前向き:最大DD', 'RF', 'プラスの年', '年の数', '選ぶ期間:合計']].head(15).round(2).to_string(index=False))
print(A.groupby(['窓の種類', '向き'])[['条件を満たす', '採用候補']].sum())
print(PR[['順位の付け方', '上位N本', '方針', '件数', '勝率', 'PF', '平均', '合計', '最大DD', '合計割る最大DD', '最悪の1窓', '2024年', '2025年', '2026年']].round(1).to_string(index=False))
