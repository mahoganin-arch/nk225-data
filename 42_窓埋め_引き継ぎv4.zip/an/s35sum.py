# 昼の窓：評価のまとめと残す候補（夜・朝の窓と同じ基準）
import glob, numpy as np, pandas as pd, sys
sys.path.insert(0, '/home/claude/work/01/code'); from common6 import jname
W = '/home/claude/work'
O = pd.concat([pd.read_pickle(f) for f in glob.glob(W + '/S35eval_*.pkl')], ignore_index=True)
NM = {'A_R': ('CFD型', '逆張り'), 'A_T': ('CFD型', '順張り'), 'B_R': ('先物型', '逆張り'), 'B_T': ('先物型', '順張り')}
O['定義'] = O['データ'].map(lambda k: NM[k][0]); O['向き'] = O['データ'].map(lambda k: NM[k][1])
k = ['定義', '向き', '売買', '指標', '区分', '使い方', '後半のみ', '選び方']
G = O.groupby(k).agg(プラス数=('平均', lambda v: int((v > 0).sum())), 中央=('平均', 'median'), 最小=('平均', 'min'), 年件数=('年件数', 'median'), 最大DD=('最大DD', 'median'),
                     WF全期間=('平均', lambda v: np.nan)).reset_index()
wf = O[O['評価'] == 'WF全期間'].set_index(k)['平均']; G['WF全期間'] = [wf.get(tuple(r), np.nan) for r in G[k].values]
base = G[G['指標'].str.startswith('条件なし')][['定義', '向き', '売買', '後半のみ', '選び方', '中央']].rename(columns={'中央': '条件なし中央'})
G = G.merge(base, on=['定義', '向き', '売買', '後半のみ', '選び方'], how='left'); G['改善'] = G['中央'] - G['条件なし中央']
TFJ = {'5m': '5分', '15m': '15分', '60m': '60分', '4h': '4時間', 'D': '日足', 'W': '週足'}
def nm(x):
    if x.startswith('条件なし') or x in ('SQ週(メジャー)', 'SQ週(ミニ)', 'SQ当日', 'SQ前日', '祝日前日', '祝日翌日(連休明け含む)', '祝日取引中', '月末3営業日', '月初3営業日'): return x
    b, _, tf = x.rpartition('_')
    if tf in TFJ and (not b.isascii() or b.isupper()): return TFJ[tf] + b
    try: return jname(x)
    except Exception: return x
G['指標名'] = [nm(x) for x in G['指標']]
cond = ~G['指標'].str.startswith('条件なし')
G['残す'] = cond & (G['プラス数'] >= 3) & (G['中央'] >= 20) & (G['年件数'] >= 10) & np.where(G['売買'] == '両方', G['改善'] >= 20, True)
G.to_pickle(W + '/S35sum.pkl')
K = G[G['残す']].groupby(['定義', '向き', '売買', '指標名', '区分', '使い方', '後半のみ']).agg(選び方数=('選び方', 'size'), 中央=('中央', 'mean'), 最小=('最小', 'min'), プラス数=('プラス数', 'min'),
                                                                                  年件数=('年件数', 'mean'), WF全期間=('WF全期間', 'mean'), 条件なし中央=('条件なし中央', 'mean')).reset_index()
K.to_pickle(W + '/S35keep.pkl')
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 300)
print('評価した区分', G[cond].groupby(['定義', '向き', '売買']).ngroups if False else G[cond][['定義', '向き', '売買', '指標', '区分', '使い方']].drop_duplicates().shape[0], ' 残す', len(K), ' 両方の選び方で', (K['選び方数'] == 2).sum())
print(K.groupby(['定義', '向き', '売買']).agg(本数=('中央', 'size'), 両方の選び方=('選び方数', lambda v: (v == 2).sum()), 中央の平均=('中央', 'mean')).round(1))
print(G[~cond].pivot_table(index=['定義', '向き', '売買', '後半のみ'], columns='選び方', values=['中央', 'プラス数']).round(1))
print(K.sort_values(['選び方数', '中央'], ascending=False).head(40).round(1).to_string(index=False))
