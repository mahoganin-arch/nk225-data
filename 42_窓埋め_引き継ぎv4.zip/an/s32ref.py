# Pine ステップ2（条件なし）と照合するための Python の答え：63本のルール（2026年）を条件なしで、同じ向き2本・入り直しなしで動かしたトレード一覧（2026/9/1〜10/8）
import sys, ast, numpy as np, pandas as pd
sys.argv = [sys.argv[0]]
exec(open('/home/claude/work/08/an/s13sim.py').read().split("if __name__ == '__main__':")[0])
sys.path.insert(0, '/home/claude/work/01/code'); import ld
from common6 import CB, P
from s10scr import load
W = '/home/claude/work'; SP = 13.0
A = pd.read_pickle(W + '/S28inv.pkl'); S = A[A['扱い'] == '売買する'].sort_values('全体の優先順位')
WEAK = ((S['窓の種類'] == 'N>D') & (S['定義'] == '先物基準') & (S['向き'] == '逆張り') & S['名前'].str.contains('4時間60本高安の位置 5分割:3')) | ((S['窓の種類'] == 'D>N') & (S['定義'] == '先物基準') & (S['向き'] == '逆張り') & S['名前'].str.contains('4時間BBσ位置 3分割:中'))
S = S[~WEAK].reset_index(drop=True)
CBI = {(round(a, 3), round(b, 3), int(c)): i for i, (a, b, c) in enumerate(CB)}
DS = {('現行', '順張り'): W + '/T', ('先物基準', '順張り'): W + '/F6W/T6', ('現行', '逆張り'): W + '/R', ('先物基準', '逆張り'): W + '/F6W/R6'}
c5 = ld.bars(W + '/data/c5.csv', until='2026-10-09'); c1 = ld.bars(W + '/data/c1.csv', until='2026-10-09')
cx = pd.concat([c5[c5.m + 5 <= c1.m.iloc[0]], c1], ignore_index=True); cm = cx.m.values.astype(float)
REC = []
for key_d, d in DS.items():
    sub = S[(S['定義'] == key_d[0]) & (S['向き'] == key_d[1])]
    if not len(sub): continue
    Y, en, MN, F = load(d); evt = pd.read_pickle(d + '/evt.pkl'); EX = np.load(d + '/EX.npy', mmap_mode='r'); gk = np.load(d + '/gk.npy'); ep = np.load(d + '/entp.npy')
    px = en.ent.values if 'ent' in en else evt.B.values[en.ev.values]; sess = evt.i.values[en.ev.values]
    buy = (en.d.values < 0) if key_d[1] == '順張り' else (en.d.values > 0); pos = en.d.values if key_d[1] == '逆張り' else -en.d.values
    t0 = evt.t0.values[en.ev.values]
    for r in sub.itertuples():
        x = r._19 if False else r[S.columns.get_loc('乖離幅(%)') + 1]; ex = ast.literal_eval(r[S.columns.get_loc('決済(FR,SK,TM)') + 1])
        m = (~en.long.values) & (en.kind.values == r.窓の種類) & np.isclose(en.x.values, x) & (evt.t0.values[en.ev.values] >= np.datetime64('2026-08-31T15:00'))
        if r.売買 == '売りのみ': m &= ~buy
        rows = np.nonzero(m)[0]
        if not len(rows): continue
        e = CBI[(round(ex[0], 3), round(ex[1], 3), int(ex[2]))]
        pnl = np.asarray(Y[rows, e], float) / 100 * P - SP * P / px[rows]
        code = np.asarray(EX[rows, e]).astype(int); g = gk[rows] + code // 4; typ = code % 4
        REC.append(pd.DataFrame(dict(id=r.Index, 優先=r.全体の優先順位, 名前=r.名前, 定義=key_d[0], 向き=key_d[1], 窓の種類=r.窓の種類, セッション=sess[rows], 入る時刻=cm[gk[rows]], 入る値段=ep[rows],
                                     売買=np.where(pos[rows] > 0, '買い', '売り'), 向き値=pos[rows], 手じまう時刻=cm[g], 手じまい=np.array(['損切り', '利確', '時間切れ', '窓の終わり'])[typ], 損益=pnl, 円per値=P / px[rows])))
T = pd.concat(REC, ignore_index=True); T['順位'] = T['優先']; T['向き'] = T['向き値']
out = []
for s_, tr in T.sort_values(['セッション', '入る時刻', '順位']).groupby('セッション', sort=False):
    out += run_window(tr.to_dict('records'), 'C1', False, np.inf)
H = pd.DataFrame(out).sort_values('入る時刻')
tz = lambda v: pd.to_datetime(np.asarray(v, float) * 60, unit='s', utc=True).tz_convert('Asia/Tokyo').strftime('%Y-%m-%d %H:%M')
H['入る（日本時間）'] = tz(H['入る時刻']); H['手じまう（日本時間）'] = tz(H['手じまう時刻'])
H['手じまう値段'] = H['入る値段'] + H['向き'] * (H['損益'] + SP * H['円per値']) / H['円per値']
cols = ['入る（日本時間）', '窓の種類', 'id', '名前', '定義', '売買', '入る値段', '手じまう（日本時間）', '手じまい', '手じまう値段', '損益']
H['id'] = H['id'] + 1
H[cols].round(1).to_csv(W + '/08/results/照合用_条件なし_61本_2026-09-01_10-08.csv', index=False, encoding='utf-8-sig')
print(len(H), H['損益'].sum().round()); print(H[cols].tail(12).round(1).to_string(index=False))
