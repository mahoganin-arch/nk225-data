# 追加検証3・4の集計：実データ（seed 0）と偶然（seed 1〜）の比較
import sys, glob, numpy as np, pandas as pd
from lib import W
from scipy.stats import spearmanr
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 30)
side = sys.argv[1]; dd = W + ('/R' if side == '逆張り' else '/T')
rows3 = []; rows4 = []
for fn in sorted(glob.glob(dd + '/t34_*.npz')):
    seed = int(fn.split('_')[-1].split('.')[0]); z = np.load(fn); ok = (z['nA'] >= 20) & (z['nB'] >= 20)
    for c, nm in (('0', '全決済の平均'), ('1', '条件なしで前半最良の決済')):
        LA = np.where(ok, z['LA' + c], np.nan); LB = np.where(ok, z['LB' + c], np.nan); m = ok.ravel()
        r = spearmanr(LA.ravel()[m], LB.ravel()[m])[0]
        has = ok.any(1); j = np.nanargmax(np.where(ok, LA, -np.inf)[has], 1); la = LA[has][np.arange(has.sum()), j]; lb = LB[has][np.arange(has.sum()), j]
        q99 = la >= np.quantile(la, .99); q90 = la >= np.quantile(la, .9)
        rows3.append((seed, nm, int(m.sum()), round(r, 4), round(np.nanmean(lb), 2), round((lb > 0).mean() * 100, 1), round(lb[q90].mean(), 2), round(lb[q99].mean(), 2), round(spearmanr(la, lb)[0], 4)))
    t = pd.read_pickle(dd + '/t4_%d.pkl' % seed)
    for c, nm in (('全決済', '全決済の平均'), ('固定', '条件なしで前半最良の決済')):
        a = t['前半t_' + c]; b = t['後半t_' + c]
        rows4.append((seed, nm, len(t), round(spearmanr(t['前半上乗せ_' + c], t['後半上乗せ_' + c])[0], 4), int(((a > 2) & (b > 2)).sum()), int(((a < -2) & (b < -2)).sum()), int(((a > 2) & (b < -2) | (a < -2) & (b > 2)).sum()),
                      round(((a > 2) & (b > 0)).sum() / max((a > 2).sum(), 1) * 100, 1)))
R3 = pd.DataFrame(rows3, columns=['seed', '決済', '件数(候補群×幅)', '順位相関 前半上乗せ×後半上乗せ', '前半で最良の幅を選んだ時の後半上乗せ', 'その後半上乗せ>0%', '前半上位10%の後半上乗せ', '前半上位1%の後半上乗せ', '最良幅での順位相関'])
R4 = pd.DataFrame(rows4, columns=['seed', '決済', '件数(指標×区分×窓×幅)', '順位相関 前半上乗せ×後半上乗せ', '両方t>2（プラスで一致）', '両方t<-2（マイナスで一致）', '逆向きで有意', '前半t>2のうち後半プラス%'])
for nm, R in (('3. 候補群（条件）・決済固定', R3), ('4. 指標単独の全区分', R4)):
    print('====', side, nm)
    for c in R['決済'].unique(): print(R[R['決済'] == c].drop(columns='決済').to_string(index=False))
R3.to_csv(dd + '/a3.csv', index=False); R4.to_csv(dd + '/a4.csv', index=False)
# 実データで前半・後半とも一貫している指標（複数の幅で）
t = pd.read_pickle(dd + '/t4_0.pkl')
for c in ('全決済', '固定'):
    g = t.assign(一致=((t['前半t_' + c] > 2) & (t['後半t_' + c] > 2)) | ((t['前半t_' + c] < -2) & (t['後半t_' + c] < -2)), 符号一致=np.sign(t['前半上乗せ_' + c]) == np.sign(t['後半上乗せ_' + c]))
    G = g.groupby(['指標', '区分', '窓']).agg(幅の数=('一致', 'size'), 両方有意の幅=('一致', 'sum'), 符号一致の幅=('符号一致', 'sum'), 前半上乗せ=('前半上乗せ_' + c, 'mean'), 後半上乗せ=('後半上乗せ_' + c, 'mean')).reset_index()
    G = G.sort_values(['両方有意の幅', '符号一致の幅'], ascending=False); G.to_csv(dd + '/a4_top_%s.csv' % c, index=False)
    print('\n--- 実データ：両方の半期で有意な幅が多い指標区分（決済=%s）' % c); print(G.head(15).round(1).to_string(index=False))
