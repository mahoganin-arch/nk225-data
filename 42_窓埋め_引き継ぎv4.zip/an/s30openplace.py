# 「寄りで置く版」：先物基準の候補を、先物の寄り（17:00・8:45）の時点で CFD の逆指値・指値（IFD-OCO）に置き換える
#   CFD の値段 ＝ 寄りの CFD 始値 ×（先物の到達値段 ÷ 先物の寄り値）。寄りで既に乖離幅以上なら寄りの CFD 始値で入る
#   条件は引けた時点の指標（置く版と同じ）。向きは先物の寄りの窓の向き。置くのは上位2本まで
#   取消：A＝窓の終わりまで置きっぱなし、B＝届く前に CFD が基準相当（寄りの CFD 始値×先物基準÷先物寄り値）に戻ったら取消（元のルールに近い、要操作）
#   現行の候補は置く版 b（引けで置く、OCO、先物の寄りで取消）。手じまいは E1（時間切れなし、D>N の残りは朝の操作時刻、N>D は引け直前）
import sys
sys.argv = [sys.argv[0]]
src = open('/home/claude/work/08/an/s29place.py').read(); exec(src[:src.index("if __name__ == '__main__':")])
EV6 = pd.read_pickle(W + '/F6W/T6/evt.pkl').set_index('i')
def run_open(mode, AM, cancel_base, drop_tm=False):
    out = []
    G = run('G', mode, AM, drop_tm=drop_tm, oco=True, closerule='open')
    for t in (2024, 2025, 2026):
        L = LS[t]
        for j in EVP.index[(EVP.t0.dt.year == t) & ~EVP.long]:
            e = EVP.loc[j]; kind = e.kind; q = s.iloc[e.i]; qend = q.end
            if e.i not in EV6.index: continue
            v6 = EV6.loc[e.i]; Bf = v6.B; g = v6.gap
            if g == 0 or v6.long: continue
            up = g > 0; gp = abs(g) / Bf * 100; fo = Bf + g
            k0 = np.searchsorted(cm, e.qm0)
            if k0 >= len(cm) or cm[k0] - e.qm0 > 5: continue
            if kind == 'D>N':
                k_end = np.searchsorted(cm, qend - 5) if mode == 'E0' else np.searchsorted(cm, qend + (AM - 6) * 60); endp = co[min(k_end, len(co) - 1)]
            else: k_end = np.searchsorted(cm, qend) - 1; endp = cc[k_end]
            if k_end <= k0 or k_end >= len(cm): continue
            ratio = co[k0] / fo; Bc = Bf * ratio
            cands = []
            for (i, kk), p in sorted(L.items(), key=lambda z: z[1]):
                if kk != kind or C.at[i, '定義'] != '先物基準' or (i, t) not in PKw.index: continue
                x = float(PKw.loc[(i, t), '乖離幅']); FR, SK, TM = PKw.loc[(i, t), '決済']
                if drop_tm and TM > 0: continue
                side = C.at[i, '向き']; dr = (-1 if up else 1) if side == '逆張り' else (1 if up else -1)
                if C.at[i, '売買'] == '売りのみ' and dr != -1: continue
                if not cond(i, j, x, -1 if up else 1): continue
                cands.append(dict(id=i, p=p, x=x, FR=FR, SK=SK, TM=TM, dr=dr, side=side))
            seen = []
            for o in cands:
                if len(seen) >= 2: break
                seen.append(o['id'])
                x = o['x']
                if gp >= x: k = k0; E = co[k0]; fd = gp
                else:
                    lv = Bf * (1 + x / 100 if up else 1 - x / 100) * ratio
                    hit = np.nonzero(ch[k0:k_end] >= lv)[0] if up else np.nonzero(cl[k0:k_end] <= lv)[0]
                    if not len(hit): continue
                    k = k0 + hit[0]
                    if cancel_base:
                        back = np.nonzero(cl[k0:k + 1] <= Bc)[0] if up else np.nonzero(ch[k0:k + 1] >= Bc)[0]
                        if len(back): continue
                    E = max(lv, co[k]) if up else min(lv, co[k]); fd = x
                dr = o['dr']; w = E * x / 100; dist = E * fd / 100
                if o['side'] == '逆張り': tp = E + dr * dist * o['FR']; sl = E - dr * w * o['SK'] if o['SK'] > 0 else np.nan
                else: sl = E - dr * dist * o['FR']; tp = E + dr * w * o['SK'] if o['SK'] > 0 else np.nan
                k_tm = np.searchsorted(cm, cm[k] + o['TM']) if (mode == 'E0' and o['TM'] > 0) else None
                kx, px, why = exit_of(k, E, dr, tp, sl, k_end, endp, kind == 'D>N', k_tm)
                out.append(dict(id=o['id'], 種類='寄りで置く', k=k, kx=kx, E=E, X=px, dr=dr, why=why, 年=t, 窓=kind, セッション=e.i,
                                損益=dr * (px - E) / E * P_ - SPT * P_ / E, 手じまう時刻=cm[kx]))
    H = pd.concat([G, pd.DataFrame(out)], ignore_index=True)
    # 同時に持った本数
    mx = {}
    for sid, g in H.groupby('セッション'):
        ev_ = sorted([(k, 1) for k in g['k']] + [(k, -1) for k in g['kx']], key=lambda z: (z[0], z[1])); c_ = 0; m_ = 0
        for _, dlt in ev_: c_ += dlt; m_ = max(m_, c_)
        mx[sid] = m_
    H['窓の最大本数'] = H['セッション'].map(mx)
    return H
if __name__ == '__main__':
    R = []; ALL = {}
    for cb in (False, True):
        for mode, AM in (('E0', 6), ('E1', 6), ('E1', 7.5), ('E1', 8.5)):
            H = run_open(mode, AM, cb).sort_values('手じまう時刻'); ALL[(cb, mode, AM)] = H; r = stats(H['損益'].values, 3)
            r.update(基準に戻ったら取消=cb, 手じまい=mode, 朝の時刻=AM, 最大本数=H['窓の最大本数'].max(), 三本以上の窓=H.loc[H['窓の最大本数'] >= 3, 'セッション'].nunique())
            for y, g in H.groupby('年'): r['%d年' % y] = g['損益'].sum()
            for k_, g in H.groupby('窓'): r[k_] = g['損益'].sum()
            for k_, g in H.groupby('種類'): r['件数:' + k_] = len(g); r['損益:' + k_] = g['損益'].sum()
            R.append(r); print(cb, mode, AM, round(r['合計']), round(r['合計割る最大DD'], 2), flush=True)
    R = pd.DataFrame(R); R.to_pickle(W + '/S30open.pkl'); pd.to_pickle(ALL, W + '/S30trades.pkl')
    pd.set_option('display.width', 320)
    print(R[['基準に戻ったら取消', '手じまい', '朝の時刻', '件数', '勝率', 'PF', '合計', '最大DD', '合計割る最大DD', '最大本数', '三本以上の窓', '2024年', '2025年', '2026年', 'D>N', 'N>D'] + [c for c in R.columns if ':' in c]].round(1).to_string(index=False))
