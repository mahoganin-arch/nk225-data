# ステップ1：A の主要な順張り戦略にコスト（スプレッド）を反映
#   コスト(円/回) = SP ÷ 基準価格 × 68,800（SP=13ポイント、往復でスプレッド1回分）
#   評価の仕方（すべてコスト控除後の値で決済を選ぶ）
#     前半選択   : 前半(2017-21)で決済を選び、後半(2022-26)で確かめる（A と同じ）
#     後半内選択 : 2022-23 で決済を選び、2024-26/10/8 で確かめる（後半重視。後半の中での前向き検証）
#     決済選択の条件：選ぶ期間で最悪の1回 -1,000円以上の決済のうち平均最良（なければ制約なし）
#   区分の境目（ATR上位10%）は A と同じく窓×乖離幅ごとに前半のデータで決める
import sys, numpy as np, pandas as pd
from lib import *
SP = 13.0; WORST = -1000
STRATS = [('条件なし', None), ('入る:5分ATR上位10%', ('atr_5m', 'hi')), ('入る:15分ATR上位10%', ('atr_15m', 'hi')), ('避ける:15分MA並び=0', ('maord_15m', 'ne0'))]
ORIG = {('入る:5分ATR上位10%', '両方の窓'), ('入る:15分ATR上位10%', 'N>D'), ('避ける:15分MA並び=0', 'D>N')} | {('条件なし', w) for w in SEGS}
Y, en, F, F2 = setup('順張り'); ev = pd.read_pickle(W + '/T/evt.pkl'); Bp = ev.B.values[en.ev.values]
XP = sorted(en.x.unique())
def maxdd(v):
    c = np.cumsum(v); return float((np.maximum.accumulate(np.r_[0, c])[1:] - c).max()) if len(v) else np.nan
def choose(Ys, m):
    YA = Ys[m]; mA = YA.mean(0); ok = YA.min(0) >= WORST
    return int(np.argmax(np.where(ok, mA, -1e9))) if ok.any() else int(np.argmax(mA)), bool(ok.any())
def stats(v, ppt, pre):
    if len(v) == 0: return {}
    s = np.sort(v)
    return {pre + '件数': len(v), pre + '平均': v.mean(), pre + '勝率': (v > 0).mean() * 100, pre + '最悪': s[0], pre + '最大DD': maxdd(v), pre + '合計': v.sum()}
rows = []; yrows = []
for w in SEGS:
    for x in XP:
        idx = np.nonzero((~en.long.values) & np.isclose(en.x.values, x) & np.isin(en.kind.values, SEGS[w]))[0]
        if len(idx) < 60: continue
        idx = idx[np.argsort(en.m.values[idx])]
        yr = en.yr.values[idx]; isB = yr >= 2022; f1 = F.iloc[idx]
        G = np.asarray(Y[idx], dtype=np.float32) / 100 * P                      # コスト控除前（円）
        ppt = P / Bp[idx]                                                        # 1ポイントあたりの円
        cost = SP * ppt; N = G - cost[:, None]
        for name, cond in STRATS:
            if cond is None: keep = np.ones(len(idx), bool); thr = np.nan
            else:
                v = f1[cond[0]].values.astype(float)
                if cond[1] == 'hi': thr = np.nanquantile(v[~isB], .9); keep = v >= thr
                else: thr = np.nan; keep = ~(v == 0)
            if (keep & ~isB).sum() < 20 or (keep & isB).sum() < 20: continue
            Gk, Nk, yk, pk, ck = G[keep], N[keep], yr[keep], ppt[keep], cost[keep]
            r = {'窓': w, '乖離幅%': x, '戦略': name, 'A主要': (name, w) in ORIG, 'ATR境目%': thr, '平均コスト前半': ck[yk <= 2021].mean(), '平均コスト後半': ck[yk >= 2022].mean()}
            # 前半選択
            a = yk <= 2021; b = ~a; e, okc = choose(Nk, a); r['前半選択_決済'] = CB[e]; r['前半選択_最悪制約'] = okc
            r.update(stats(Nk[a, e], pk[a], '前半選択_前半')); r.update(stats(Nk[b, e], pk[b], '前半選択_後半'))
            r['前半選択_後半_控除前'] = Gk[b, e].mean(); r['前半選択_後半_損益分岐pt'] = Gk[b, e].sum() / pk[b].sum()
            mA = Nk[a].mean(0); mB = Nk[b].mean(0); top = np.argsort(-mA)[:194]
            r['全決済平均_前半'] = mA.mean(); r['全決済平均_後半'] = mB.mean(); r['後半プラス決済%'] = (mB > 0).mean() * 100; r['前半上位10%決済の後半平均'] = mB[top].mean()
            # 後半内選択（2022-23で選び 2024-26 で確かめる）
            s1 = (yk >= 2022) & (yk <= 2023); s2 = yk >= 2024
            if s1.sum() >= 15 and s2.sum() >= 15:
                e2, ok2 = choose(Nk, s1); r['後半内_決済'] = CB[e2]; r['後半内_最悪制約'] = ok2
                r.update(stats(Nk[s1, e2], pk[s1], '後半内_22-23')); r.update(stats(Nk[s2, e2], pk[s2], '後半内_24-26'))
                r['後半内_24-26_損益分岐pt'] = Gk[s2, e2].sum() / pk[s2].sum()
                m1 = Nk[s1].mean(0); m2 = Nk[s2].mean(0); top2 = np.argsort(-m1)[:194]
                r['22-23上位10%決済の24-26平均'] = m2[top2].mean(); r['24-26プラス決済%'] = (m2 > 0).mean() * 100
            rows.append(r)
            for col, ee in (('前半選択', e),) + ((('後半内', e2),) if 'e2' in dir() and s1.sum() >= 15 and s2.sum() >= 15 else ()):
                for y in range(2017, 2027):
                    mm = yk == y
                    if mm.any(): yrows.append({'窓': w, '乖離幅%': x, '戦略': name, '決済の選び方': col, '年': y, '件数': int(mm.sum()), '平均(控除後)': Nk[mm, ee].mean(), '平均(控除前)': Gk[mm, ee].mean(), '合計(控除後)': Nk[mm, ee].sum()})
            if 'e2' in dir(): del e2
R = pd.DataFrame(rows); YRt = pd.DataFrame(yrows)
R.to_pickle(W + '/S1.pkl'); YRt.to_pickle(W + '/S1y.pkl'); print(R.shape, YRt.shape)
