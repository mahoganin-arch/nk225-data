# 5-5（5:55決済）と 5-1（上限管理）の Excel
import pandas as pd, numpy as np
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
W = '/home/claude/work'; OUT = W + '/08/results/S4_決済時刻修正_上限管理.xlsx'
c = ['ルール', '窓', '件数', '前半平均', '後半平均', '2026平均(未使用)', '後半勝率%', '後半最大DD', '全期間最大DD', '周辺の後半平均:中央']
a = pd.read_pickle(W + '/v0/S2fixed.pkl')[c]; b = pd.read_pickle(W + '/S2fixed.pkl')[c]
fx = a.merge(b, on=['ルール', '窓'], suffixes=('（旧）', '（新）'))
k = ['評価', '窓', '戦略', '選び方']
s0 = pd.read_pickle(W + '/v0/S2sum.pkl'); s1 = pd.read_pickle(W + '/S2sum.pkl')
sm = s0[k + ['件数', '平均', '最大DD']].merge(s1[k + ['件数', '平均', '最大DD']], on=k, suffixes=('（旧）', '（新）')); sm['平均の差'] = sm['平均（新）'] - sm['平均（旧）']
sm = sm[sm['戦略'].isin(['条件なし', '避ける:15分MA並び=0'])].sort_values(k)
cap = pd.read_pickle(W + '/S7cap.pkl')
desc = [
    ['この表について', ''],
    ['5-5 決済時刻の修正', '「次の引けまで保有」（時間切れ0）と、それ以外の時間切れ・損切り・利確も含め、夜間引けが6:00の時期（2021/9以降）の D>N の窓は 5:55 の足の始値で手じまい（CFDの日替わり6:00の前）。5:55以降の新規エントリーはなし'],
    ['', '注：夜間引けが6:00になったのは 2021/9 から（v3メモの「2024/11以降」はデータ上 2021/9 以降）'],
    ['', '影響：エントリーは1件減のみ（77,474→77,473）。両方の窓・条件なしの主要結果はほぼ不変（後半型 後半 +85.3→+85.9円、中間型 +67.9→+67.2円）'],
    ['', 'D>N 単独の前向き検証（WF後半・WF直近3年の周辺）は、選ばれる決済が入れ替わり悪化（例：WF後半 D>N 周辺 +20→−11円）。D>N 単独は選び直しに弱く、両方の窓をまとめて選ぶ方針を支持'],
    ['5-1 上限管理', '対象：順張り・両方の窓・条件なし。固定ルール3つ（2025年までを見て選んだ形）と、前向き検証の記録（年ごとに選び直したルール、周辺）。コスト13pt控除後'],
    ['止める条件（事前固定）', 'DD基準：実際の損益のピークからの下落が 2,000／3,000／4,000円で停止。直近成績：ルール自体（実際＋仮想）の直近50／100回の合計がマイナスで停止'],
    ['再開の条件（事前固定）', 'DD基準：(a) 停止後の仮想損益の合計がプラス、(b) 直近50回の合計がプラス。再開時にピークを置き直す。直近成績：合計がプラスに戻ったら再開'],
    ['結果', '中間型：どの上限管理でも最大DDはほぼ減らない（6,888円→最良 6,472円）。後半の合計はDD3,000/4,000円ならほぼ失わない（停止は前半の1〜2回のみ）'],
    ['', '後半型：DD基準はかえって最大DDが悪化（止めた直後に戻る）。直近100回は最大DD 9,934→6,388円だが、事前固定の50回ではなく当てはめの可能性（ステップ3と同じ）'],
    ['', '前向き検証の記録：どの上限管理も「常に入る」の合計・最大DDを改善しない'],
    ['解釈', '上限管理で成績を上げる根拠はない。実運用では「中間型＋DD4,000円で停止・仮想合計がプラスで再開」を安全弁として付ける案（過去10年で発動2回、失う利益 約400円）'],
    ['シート', '固定ルール_旧新：固定ルールの旧（引けまで）と新（5:55）の比較／前向き検証_旧新：S2のまとめの比較／上限管理：全件'],
]
with pd.ExcelWriter(OUT, engine='openpyxl') as w:
    pd.DataFrame(desc, columns=['項目', '内容']).to_excel(w, sheet_name='説明', index=False)
    fx.round(1).to_excel(w, sheet_name='固定ルール_旧新', index=False)
    sm.round(1).to_excel(w, sheet_name='前向き検証_旧新', index=False)
    cap.round(1).to_excel(w, sheet_name='上限管理', index=False)
wb = load_workbook(OUT)
for ws in wb:
    for row in ws.iter_rows():
        for cell in row: cell.font = Font(name='Arial', size=10, bold=cell.row == 1)
    for cell in ws[1]: cell.fill = PatternFill('solid', fgColor='DDEBF7'); cell.alignment = Alignment(wrap_text=True, vertical='top')
    ws.freeze_panes = 'A2'
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = 14
ws = wb['説明']; ws.column_dimensions['A'].width = 22; ws.column_dimensions['B'].width = 140
for ws_name in ('固定ルール_旧新', '上限管理'): wb[ws_name].column_dimensions['A'].width = 40
wb['上限管理'].column_dimensions['B'].width = 28
wb.save(OUT); print(OUT)
