# Pine v0.9：v0.8 の照合（9/1〜10/15）で見つかった食い違いを直す
#  ① 先物の寄りの判定を「17:00／8:45 以降の最初の足」にする（先物の1分足が無くても寄りとして扱う）
#  ② 現行の「窓が閉じた」は Python と同じく、寄りの足の CFD 始値と CFD 基準の上下で判定（同じなら寄りで閉じる）
#  ③ 調べやすくするログ：寄りの様子（OPEN）、届いたのに入らなかった候補（SKIP と理由・指標の値）
W = '/home/claude/work/08/results/'
p = open(W + '窓埋め61本_v0.8_条件あり.txt').read()
def rep(a, b, n=1):
    global p
    assert p.count(a) == n, (p.count(a), a[:60]); p = p.replace(a, b)
rep('indicator("窓埋め61本 v0.8 条件あり"', 'indicator("窓埋め61本 v0.9 条件あり"')
rep('SHOW_TBL = input.bool(true, "表を出す")', 'SHOW_TBL = input.bool(true, "表を出す")\nLOGV = input.bool(true, "照合用の詳しいログ（OPEN・SKIP）を出す")')
rep('var int   gapSign = 0', 'var int   gapSign = 0         // 先物の寄りの向き（先物基準で使う）\nvar int   cSign = 0           // CFD の寄りの向き（現行の「閉じた」で使う）')
rep("""    isFutOpen = not fOpen and not na(fO) and ((wKind == 0 and hm == 1700) or (wKind == 1 and hm == 845))
    if isFutOpen
        fOpen := true
        fGap := (fO - Bf) / Bf * 100
        gapSign := fO > Bf ? 1 : fO < Bf ? -1 : 0
    // 現行：寄り後に CFD が基準に戻ったら窓が閉じる
    if fOpen and not wClosed and ((gapSign > 0 and l_ <= B) or (gapSign < 0 and h_ >= B))
        wClosed := true""", """    isFutOpen = not fOpen and ((wKind == 0 and (hm >= 1700 or hh < 6)) or (wKind == 1 and hm >= 845))
    if isFutOpen
        fOpen := true
        fGap := na(fO) ? na : (fO - Bf) / Bf * 100
        gapSign := na(fO) ? 0 : fO > Bf ? 1 : fO < Bf ? -1 : 0
        cSign := o_ > B ? 1 : o_ < B ? -1 : 0
        if LOGV
            log.info("OPEN kind={0} B={1} o={2} cs={3} Bf={4} fO={5} fs={6}", wKind, B, o_, cSign, Bf, fO, gapSign)
    // 現行：寄り後に CFD が基準に戻ったら窓が閉じる（寄りの CFD 始値が基準と同じなら、寄りで閉じる）
    if fOpen and not wClosed and (cSign == 0 or (cSign > 0 and l_ <= B) or (cSign < 0 and h_ >= B))
        wClosed := true""")
rep("""                    if not (array.get(cSell, i) and d != -1) and f_cond(i, up, c_) and f_can(i, d)
                        E = reo ? c_ : (up ? math.max(U, o_) : math.min(L, o_))
                        f_open(i, d, E, B * x / 100, math.abs(E - B))""", """                    if not (array.get(cSell, i) and d != -1) and f_cond(i, up, c_) and f_can(i, d)
                        E = reo ? c_ : (up ? math.max(U, o_) : math.min(L, o_))
                        f_open(i, d, E, B * x / 100, math.abs(E - B))
                    else if LOGV
                        log.info("SKIP id={0} dir={1} v={2} why={3}", i + 1, d, f_val(i, up, c_), (array.get(cSell, i) and d != -1) ? "売りのみ" : not f_cond(i, up, c_) ? "条件" : "本数/入り直し")""")
rep("""                    if not (array.get(cSell, i) and d != -1) and f_cond(i, up, o_) and f_can(i, d)
                        f_open(i, d, o_, o_ * x / 100, o_ * gp / 100)""", """                    if not (array.get(cSell, i) and d != -1) and f_cond(i, up, o_) and f_can(i, d)
                        f_open(i, d, o_, o_ * x / 100, o_ * gp / 100)
                    else if LOGV
                        log.info("SKIP id={0} dir={1} v={2} why={3}", i + 1, d, f_val(i, up, o_), (array.get(cSell, i) and d != -1) ? "売りのみ" : not f_cond(i, up, o_) ? "条件" : "本数/入り直し")""")
rep("""            if f_cond(i, gapSign > 0, o_) and f_can(i, d)
                E = o_
                f_open(i, d, E, E * array.get(cX, i) / 100, E * array.get(qFd, j) / 100)""", """            if f_cond(i, gapSign > 0, o_) and f_can(i, d)
                E = o_
                f_open(i, d, E, E * array.get(cX, i) / 100, E * array.get(qFd, j) / 100)
            else if LOGV
                log.info("SKIP id={0} dir={1} v={2} why={3}", i + 1, d, f_val(i, gapSign > 0, o_), not f_cond(i, gapSign > 0, o_) ? "条件" : "本数/入り直し")""")
p = p.replace('// 61本の条件（指標）を入れた版。Python の「条件あり」と照合する', '// 61本の条件（指標）を入れた版（v0.9：寄りの判定と「閉じた」の判定を Python に合わせ、照合用ログを追加）')
open(W + '窓埋め61本_v0.9_条件あり.txt', 'w').write(p); open(W + '窓埋め61本_v0.9_条件あり.pine', 'w').write(p)
print(len(p.splitlines()), 'lines')
