# 条件なしの成績：前半で最良の決済を選び、後半でどうだったか（窓×乖離幅ごと）
import numpy as np, pandas as pd
from lib import *
from prep import baseline
from scipy.stats import spearmanr
for side in ('逆張り', '順張り'):
    Y, en, F = load(W + ('/R' if side == '逆張り' else '/T')); B = baseline(side, Y, en); XP = sorted(en.x.unique())
    rows = []
    for w, arr in B.items():
        a = arr[:, 0, :]; b = arr[:, 1, :]
        print(side, w, ' 全決済×全乖離幅での 前半平均と後半平均の順位相関 %.3f' % spearmanr(a.ravel(), b.ravel(), nan_policy='omit')[0])
        for xi, x in enumerate(XP):
            j = np.nanargmax(a[xi]); n = int(((~en.long) & np.isclose(en.x, x) & en.kind.isin(SEGS[w])).sum())
            rows.append((w, x, n, CB[j], round(a[xi, j], 1), round(b[xi, j], 1), round(np.nanmax(b[xi]), 1)))
    D = pd.DataFrame(rows, columns=['窓', '乖離幅%', '件数', '前半で最良の決済(利確,損切り,時間)', '前半平均', 'その決済の後半平均', '後半で最良の場合']); pd.set_option('display.width', 250)
    print(D[D['窓'] == '両方の窓'].to_string(index=False))
