# 昼の窓：残った区分を、夜・朝の窓と同じ流れで採用候補にし、昼だけの前向き検証をする（独立した成績）
#   ①トレード一覧（WF全期間・周辺の年ごとのルール）②重なりでまとめる（2022年以降の入った窓の Jaccard、平均連結 0.5）
#   ③区分（向き×売買）ごとに案3（前の付け方＝選ぶ期間の1回平均／新しい付け方＝前向きRF）上位5本 ④前向きでマイナスを外す ⑤重なり75%でまとめる＋PF1.2
#   ⑥前向き検証 2024〜26年（各年の判断はその年より前のデータだけ）：先着1本／同じ向き2本（入り直しなし）
import re, sys, numpy as np, pandas as pd
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.spatial.distance import squareform
from s9cal import flags, SP, CB, P
from s10scr import make_bins, LATE
from s14report_funcs import stats, rule_text
W = '/home/claude/work'
NM = {'A_R': ('CFD型', '逆張り'), 'A_T': ('CFD型', '順張り'), 'B_R': ('先物型', '逆張り'), 'B_T': ('先物型', '順張り')}
CBI = {(round(a, 3), round(b, 3), int(c)): i for i, (a, b, c) in enumerate(CB)}
def parse(s): return [(float(x), (float(a), float(b), int(c))) for x, a, b, c in re.findall(r'([\d.]+)%\(([\d.]+), ([\d.]+), (\d+)\)', s)]
G = pd.read_pickle(W + '/S35sum.pkl'); O = pd.concat([pd.read_pickle(W + '/S35eval_%s.pkl' % k) for k in NM], ignore_index=True)
O['定義'] = O['データ'].map(lambda k: NM[k][0]); O['向き'] = O['データ'].map(lambda k: NM[k][1])
key = ['定義', '向き', '売買', '指標', '区分', '使い方', '後半のみ']
K = G[G['残す']].groupby(key).agg(選び方数=('選び方', 'size'), 中央=('中央', 'mean'), 最小=('最小', 'min'), 年件数=('年件数', 'mean'), 指標名=('指標名', 'first')).reset_index()
K['id'] = np.arange(len(K)); K['名前'] = [n if i.startswith('条件なし') else '%s %s' % (n, k_) for n, i, k_ in zip(K['指標名'], K['指標'], K['区分'])]
print('候補', len(K), flush=True)
# ---- ① トレード一覧
REC = []
for dk, (dfn, side) in NM.items():
    d = W + '/LU/' + dk; Y = np.load(d + '/Y.npy', mmap_mode='r'); en = pd.read_pickle(d + '/en.pkl'); ev = pd.read_pickle(d + '/evt.pkl')
    en = en.join(ev[['t0']], on='ev'); yr = en.t0.dt.year.values; EX = np.load(d + '/EX.npy', mmap_mode='r')
    F = pd.concat([pd.read_pickle(d + '/F6.pkl').drop(columns=['時']), pd.read_pickle(d + '/F7.pkl')], axis=1).reset_index(drop=True)
    F = pd.concat([F, flags(ev).iloc[en.ev.values].reset_index(drop=True).astype(float)], axis=1)
    ok = np.ones(len(en), bool); buy = (en.d.values > 0) if side == '逆張り' else (en.d.values < 0); pos = en.d.values if side == '逆張り' else -en.d.values
    ba = make_bins(F.drop(columns=list(LATE)), ok & (yr <= 2021)); bl = make_bins(F[list(LATE)], ok & (yr == 2023))
    cmn = pd.read_pickle(d + '/en.pkl').m.values
    sub = K[(K['定義'] == dfn) & (K['向き'] == side)]
    for z in sub.itertuples():
        m = (bl if z.後半のみ else ba)[(z.指標, z.区分)]; m = m if z.使い方 == '入る' else ~m
        if z.売買 != '両方': m = m & (buy if z.売買 == '買いのみ' else ~buy)
        if z.後半のみ: m = m & ~np.isnan(F[z.指標].values)
        oo = O[(O['データ'] == dk) & (O['売買'] == z.売買) & (O['指標'] == z.指標) & (O['区分'] == z.区分) & (O['使い方'] == z.使い方) & (O['評価'] == 'WF全期間') & (O['選び方'] == '周辺')]
        if len(oo) != 1: continue
        pk = parse(oo['選ばれた点'].iloc[0])
        for t, (x, ex) in zip(range(2022, 2027), pk):
            e = CBI[(round(ex[0], 3), round(ex[1], 3), int(ex[2]))]
            rows = np.nonzero(m & np.isclose(en.x.values, x) & (yr <= t))[0]
            if z.後半のみ: rows = rows[yr[rows] >= 2024] if t >= 2024 else rows[:0]
            if not len(rows): continue
            pnl = np.asarray(Y[rows, e], float) / 100 * P - SP * P / en.ent.values[rows]
            code = np.asarray(EX[rows, e]).astype(int)
            REC.append(pd.DataFrame(dict(id=z.id, t=t, x=x, 決済=[ex] * len(rows), セッション=en.ev.values[rows], 年=yr[rows], 入る時刻=cmn[rows], 向き=pos[rows], 損益=pnl, 手じまい足=code // 4, 手じまい種類=code % 4)))
    print(dk, flush=True)
T0 = pd.concat(REC, ignore_index=True)
# 手じまう時刻（分）：エントリーの足から何本目か → CFD の足の時刻
sys.path.insert(0, W + '/01/code'); import ld
c5 = ld.bars(W + '/data/c5.csv', until='2026-10-09'); c1 = ld.bars(W + '/data/c1.csv', until='2026-10-09')
cm = pd.concat([c5[c5.m + 5 <= c1.m.iloc[0]], c1], ignore_index=True).m.values
k0 = np.searchsorted(cm, T0['入る時刻'].values); T0['手じまう時刻'] = cm[np.minimum(k0 + T0['手じまい足'].values, len(cm) - 1)]
T0.to_pickle(W + '/S36trades.pkl')
WF = T0[T0['年'] == T0['t']]; SEL = T0[(T0['t'] == 2022) & (T0['年'] <= 2021)].groupby('id')['損益'].sum()
# ---- ② 重なりでまとめる（向き×売買×使い方ごと）
SES = WF.groupby('id')['セッション'].apply(set).to_dict()
K['グループ'] = -1; gid = 0
for _, sub in K.groupby(['向き', '売買', '使い方']):
    ids = [i for i in sub['id'] if i in SES]
    if len(ids) == 1: K.loc[K['id'] == ids[0], 'グループ'] = gid; gid += 1; continue
    if not ids: continue
    n = len(ids); S = np.eye(n)
    for a in range(n):
        for b in range(a + 1, n):
            A_, B_ = SES[ids[a]], SES[ids[b]]; S[a, b] = S[b, a] = len(A_ & B_) / np.sqrt(len(A_) * len(B_))
    g = fcluster(linkage(squareform(1 - S, checks=False), 'average'), .5, 'distance')
    for i, gg in zip(ids, g): K.loc[K['id'] == i, 'グループ'] = gid + gg
    gid += g.max() + 1
K = K.sort_values(['グループ', '選び方数', '最小', '年件数'], ascending=[True, False, False, False]); K['代表'] = ~K.duplicated('グループ'); K = K.set_index('id', drop=False)
REPS = set(K.index[K['代表']]); BK = [(s_, d_) for s_ in ('順張り', '逆張り') for d_ in ('両方', '買いのみ', '売りのみ')]
def rank_old(t):
    Tt = T0[(T0['t'] == t) & (T0['年'] < t) & T0['id'].isin(REPS)]; ins = Tt.groupby('id')['損益'].agg(['mean', 'size']); ins = ins[ins['size'] >= 15]['mean'].sort_values(ascending=False)
    return {b: [i for i in ins.index if (K.at[i, '向き'], K.at[i, '売買']) == b] for b in BK}
def fwd(t, incl=False):
    past = WF[(WF['年'] <= t) if incl else (WF['年'] < t)].sort_values('手じまう時刻'); out = {}
    for i, g in past.groupby('id'):
        v = g['損益'].values; c = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, c])[1:] - c).max(); gp, gl = v[v > 0].sum(), -v[v < 0].sum()
        out[i] = dict(n=len(v), tot=v.sum(), rf=v.sum() / max(dd, 1.0), pf=gp / gl if gl > 0 else np.inf, ses=set(g['セッション']))
    return out
def rank_rf(t, incl=False):
    fs = fwd(t, incl); ny = (t - 2022 + 1) if incl else (t - 2022); minn = 20 if incl else 5 * ny
    S_ = sorted([(i, f['rf']) for i, f in fs.items() if f['n'] >= minn and f['tot'] > 0 and SEL.get(i, -1) > 0], key=lambda z: -z[1])
    seen = set(); out = {b: [] for b in BK}
    for i, _ in S_:
        if K.at[i, 'グループ'] in seen: continue
        seen.add(K.at[i, 'グループ']); out[(K.at[i, '向き'], K.at[i, '売買'])].append(i)
    return out
def build(t, incl=False, N=5, dirs=('両方', '買いのみ', '売りのみ')):
    fs = fwd(t, incl); old = rank_old(t); rf = rank_rf(t, incl); L = {}
    for b in BK:
        if b[1] not in dirs: continue
        a = [i for i in old[b] if fs.get(i, dict(tot=1))['tot'] > 0][:N]; c = rf[b][:N]; ids = list(dict.fromkeys(a + c))
        rows = [(i, i in a and i in c, a.index(i) + 1 if i in a else 99, c.index(i) + 1 if i in c else 99) for i in ids]
        for r in rows: L[r[0]] = r
    # ⑤ PF1.2 と重なり75%
    keys = [i for i in L if i not in fs or fs[i]['pf'] >= 1.2]; keep = []
    for i in sorted(keys, key=lambda i: -fs[i]['rf'] if i in fs else 0):
        if all(not (i in fs and q in fs and len(fs[i]['ses'] & fs[q]['ses']) / max(len(fs[i]['ses'] | fs[q]['ses']), 1) >= .75) for q in keep): keep.append(i)
    rows = sorted([L[i] for i in keep], key=lambda r: (not r[1], min(r[2], r[3]), r[2]))
    return {r[0]: p for p, r in enumerate(rows)}
def sim(pol, dirs, N=5):
    out = []
    for t in (2024, 2025, 2026):
        pr = build(t, False, N, dirs); test = WF[(WF['年'] == t) & WF['id'].isin(pr)].copy(); test['順位'] = test['id'].map(pr)
        for s_, tr in test.sort_values(['セッション', '入る時刻', '順位']).groupby('セッション', sort=False):
            held = []; done = False
            for r in tr.to_dict('records'):
                still = []
                for h in held:
                    if h['手じまう時刻'] <= r['入る時刻']: out.append(h); done = True
                    else: still.append(h)
                held = still
                if done: continue
                same = [h for h in held if h['向き'] == r['向き']]
                if pol == 'A1' and held: continue
                if pol == 'C1' and (len(held) >= 2 or len(same) < len(held) or any(h['id'] == r['id'] for h in held)): continue
                held.append(r)
            out += held
    return pd.DataFrame(out)
PR = []
for dn, dirs in (('両方のみ', ('両方',)), ('売りのみ', ('売りのみ',)), ('買いのみ', ('買いのみ',)), ('両方＋売りのみ', ('両方', '売りのみ')), ('全部', ('両方', '買いのみ', '売りのみ'))):
    for pol, pn in (('A1', '先着1本'), ('C1', '同じ向き2本')):
        H = sim(pol, dirs).sort_values('手じまう時刻'); r = stats(H['損益'].values, 3) if len(H) else {}
        r.update(候補の集まり=dn, 方針=pn, 使った候補数=H['id'].nunique() if len(H) else 0)
        for y in (2024, 2025, 2026): r['%d年' % y] = H.loc[H['年'] == y, '損益'].sum() if len(H) else 0
        PR.append(r); print(dn, pn, round(r.get('合計', 0)), round(r.get('合計割る最大DD', 0), 2), flush=True)
PR = pd.DataFrame(PR); PR.to_pickle(W + '/S36port.pkl')
# 今の候補一覧（2026年の時点）
fs = fwd(2026, True); L26 = build(2026, True); rows = []
for i, p in sorted(L26.items(), key=lambda z: z[1]):
    z = K.loc[i]; v = WF[WF['id'] == i].sort_values('手じまう時刻'); s = stats(v['損益'].values, None); yrs = v.groupby('年')['損益'].sum()
    pk = T0[(T0['id'] == i) & (T0['t'] == 2026)].iloc[0]
    r = dict(優先順位=p + 1, 定義=z['定義'], 向き=z['向き'], 売買=z['売買'], 候補=z['名前'], 使い方=z['使い方'], 今のルール=rule_text(z['向き'], pk['x'], tuple(pk['決済'])), id=i)
    r.update({'前向き:' + k: x for k, x in s.items()})
    for y in range(2022, 2027): r['%d年' % y] = yrs.get(y, np.nan)
    rows.append(r)
U = pd.DataFrame(rows); U.to_pickle(W + '/S36list.pkl')
pd.set_option('display.width', 250)
print(PR[['候補の集まり', '方針', '件数', '勝率', 'PF', '合計', '最大DD', '合計割る最大DD', '2024年', '2025年', '2026年', '使った候補数']].round(2).to_string(index=False))
print(len(U)); print(U[['優先順位', '定義', '向き', '売買', '候補', '使い方', '前向き:件数', '前向き:PF', '前向き:合計', '前向き:合計割る最大DD']].round(2).to_string(index=False))
