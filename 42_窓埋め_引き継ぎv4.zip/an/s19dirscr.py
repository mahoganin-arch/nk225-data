# 買い・売り別の分析し直し（まろ、2026-10-13：売りだけで優位性があれば売りのみのストラテジーも組む。候補を絞り込み過ぎない）
#   前回（s18）からの変更：
#     ・ふるいで前半（2017〜21年）の向きを問わない（後半の中央t の絶対値 ≥ 1 だけ）
#     ・比べる相手を「同じ方向の条件なし」にする（売りのみの中で、さらに良い区分／悪い区分）
#     ・「入る」（上乗せプラス）だけでなく「避ける」（上乗せマイナスの区分を除いて入る）も
#     ・方向だけの条件なし（買いのみ・売りのみ）は必ず評価
#   1時間足の出来高（2023年〜）の指標は、2023年で境目を決め 2024〜26年でふるう（中央t の絶対値 ≥ 1.5）
import sys, numpy as np, pandas as pd
from s10scr import load, make_bins, uplift, LATE
W = '/home/claude/work'
SEGS = {'D>N': ['D>N'], 'N>D': ['N>D'], '両方の窓': ['D>N', 'N>D']}
RUNS = [('現行', '順張り', W + '/T'), ('先物基準', '順張り', W + '/F6W/T6'), ('現行', '逆張り', W + '/R'), ('先物基準', '逆張り', W + '/F6W/R6')]
rows = []
for lab, side, d in RUNS:
    Y, en, MN, F = load(d); ok = ~en.long.values; yr = en.yr.values; XP = np.array(sorted(en.x.unique()))
    buy = (en.d.values < 0) if side == '順張り' else (en.d.values > 0)
    ba = make_bins(F.drop(columns=list(LATE)), ok & (yr <= 2021)); bl = make_bins(F[list(LATE)], ok & (yr == 2023))
    for dname, dm in (('買いのみ', buy), ('売りのみ', ~buy)):
        okd = ok & dm                                                    # 比べる相手＝同じ方向の条件なし
        rows += [dict(定義=lab, 向き=side, 売買=dname, 窓=w, 指標='条件なし', 区分='', 後半のみ=False, 使い方='入る', 通過=True) for w in SEGS]
        for bins, late in ((ba, False), (bl, True)):
            keys = list(bins); Bm = np.array([bins[k] for k in keys])
            for w, kinds in SEGS.items():
                if late: tB, dB = uplift(Bm, MN, en, okd, yr >= 2024, kinds, XP); tA, dA = uplift(Bm, MN, en, okd, yr == 2023, kinds, XP)
                else: tB, dB = uplift(Bm, MN, en, okd, yr >= 2022, kinds, XP); tA, dA = uplift(Bm, MN, en, okd, yr <= 2021, kinds, XP)
                cov = Bm[:, okd & np.isin(en.kind.values, kinds) & (yr >= 2022)].mean(1)
                thr = 1.5 if late else 1.0
                for i, k in enumerate(keys):
                    if not (np.abs(tB[i]) >= thr): continue
                    use = '入る' if dB[i] > 0 else '避ける'
                    if use == '入る' and cov[i] < .02: continue
                    rows.append(dict(定義=lab, 向き=side, 売買=dname, 窓=w, 指標=k[0], 区分=k[1], 後半のみ=late, 使い方=use, 該当率=cov[i], 前半t=tA[i], 前半上乗せ=dA[i], 後半t=tB[i], 後半上乗せ=dB[i], 通過=True))
        print(lab, side, dname, len(rows), flush=True)
S = pd.DataFrame(rows); S.to_pickle(W + '/S19scr.pkl')
print(S.groupby(['定義', '向き', '売買', '使い方']).size().to_string())
