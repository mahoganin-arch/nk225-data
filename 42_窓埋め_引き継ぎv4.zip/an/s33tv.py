# 4時間足の区切りの違い（Python：UTC 0時基準／TradingView：CFD の取引再開から4時間ごと）で、候補の評価が変わるか
#   4時間足の指標（35列）だけを、両方の区切りで「今の手順」どおりにふるい→5つの評価の形で評価し直す
#   ふるい：買い売り両方＝S10 と同じ（前半と後半の上乗せの向きが同じ、後半 |t|≥1、該当率3%以上）／買いのみ・売りのみ＝S19 と同じ（後半 |t|≥1、入るは該当率2%以上）
#   評価は s19eval と同じ計算（13pt 控除、単点・周辺）。両方の区切りで、どちらかがふるいを通った区分は両方とも評価する
#   使い方: python s33tv.py <定義> <向き>
import sys, numpy as np, pandas as pd
from s9cal import schemes, nbr_mean, maxdd, PERM, SEGS, WORST, MINSEL, SP, CB, P
from s10scr import load, make_bins, uplift
W = '/home/claude/work'
NY = {'S1 前半→後半': 4.77, 'S2 22-23→24-26': 2.77, 'WF後半': 3.77, 'WF全期間': 4.77, 'WF直近3年': 4.77}
lab, side = sys.argv[1], sys.argv[2]
d = {('現行', '順張り'): 'T', ('先物基準', '順張り'): 'F6W/T6', ('現行', '逆張り'): 'R', ('先物基準', '逆張り'): 'F6W/R6'}[(lab, side)]
Y, en, MN, F = load(W + '/' + d)
C4 = [c for c in F.columns if c.endswith('_4h')]
FT = pd.concat([pd.read_pickle(W + '/TV4/%s/F6.pkl' % d.replace('/', '_')), pd.read_pickle(W + '/TV4/%s/F7.pkl' % d.replace('/', '_'))], axis=1)
FV = {'Python': F[C4], 'TV': FT[C4]}
px = en.ent.values if 'ent' in en else pd.read_pickle(W + '/' + d + '/evt.pkl').B.values[en.ev.values]
ok = ~en.long.values; yr = en.yr.values; buy = (en.d.values < 0) if side == '順張り' else (en.d.values > 0)
XP = np.array(sorted(en.x.unique()))
BINS = {v: make_bins(f, ok & (yr <= 2021)) for v, f in FV.items()}
# ---- ふるい
rows = []
for v, bins in BINS.items():
    keys = list(bins); Bm = np.array([bins[k] for k in keys])
    for dname, dm in (('両方', np.ones(len(en), bool)), ('買いのみ', buy), ('売りのみ', ~buy)):
        okd = ok & dm
        for w, kinds in SEGS.items():
            tA, dA = uplift(Bm, MN, en, okd, yr <= 2021, kinds, XP); tB, dB = uplift(Bm, MN, en, okd, yr >= 2022, kinds, XP)
            cov = Bm[:, okd & np.isin(en.kind.values, kinds) & (yr >= 2022)].mean(1)
            for i, k in enumerate(keys):
                if dname == '両方': p = (np.sign(dA[i]) == np.sign(dB[i])) and abs(tB[i]) >= 1.0 and cov[i] >= .03
                else: p = abs(tB[i]) >= 1.0 and not (dB[i] > 0 and cov[i] < .02)
                if p: rows.append(dict(区切り=v, 売買=dname, 窓=w, 指標=k[0], 区分=k[1], 使い方='入る' if dB[i] > 0 else '避ける', 後半t=tB[i], 後半上乗せ=dB[i], 前半上乗せ=dA[i], 該当率=cov[i]))
S = pd.DataFrame(rows)
print(lab, side, 'ふるいを通った', S.groupby(['区切り', '売買']).size().to_dict(), flush=True)
# ---- 評価（s19eval と同じ）
CACHE = {}
def fam_all(w):
    if w not in CACHE:
        fam = {}
        for j, x in enumerate(XP):
            idx = np.nonzero(ok & np.isclose(en.x.values, x) & np.isin(en.kind.values, SEGS[w]))[0]; idx = idx[np.argsort(en.m.values[idx])]
            N = np.asarray(Y[idx], dtype=np.float32) / 100 * P - (SP * P / px[idx]).astype(np.float32)[:, None]
            fam[j] = dict(idx=idx, yr=yr[idx], N=N)
        CACHE.clear(); CACHE[w] = fam
    return CACHE[w]
def evaluate(mask, w):
    base = fam_all(w); fam = {j: dict(yr=b['yr'][mask[b['idx']]], N=b['N'][mask[b['idx']]]) for j, b in base.items()}
    Js = sorted(fam); out = []
    for scn, splits in schemes():
        res = {'単点': [], '周辺': []}
        for selfn, tstfn, ty in splits:
            Mn = np.full((len(Js), 1944), np.nan, np.float32); Wst = np.full((len(Js), 1944), np.nan, np.float32); cnt = np.zeros(len(Js), int)
            for q, j in enumerate(Js):
                s_ = selfn(fam[j]['yr']); cnt[q] = s_.sum()
                if cnt[q] >= MINSEL: Ns = fam[j]['N'][s_]; Mn[q] = Ns.mean(0); Wst[q] = Ns.min(0)
            if not (cnt >= MINSEL).any(): continue
            SM = nbr_mean(Mn[:, PERM].reshape(len(Js), 12, 18, 9)).reshape(len(Js), 1944); SMc = np.full_like(SM, np.nan); SMc[:, PERM] = SM
            okw = Wst >= WORST
            for meth, score in (('単点', Mn), ('周辺', SMc)):
                sc = np.where(np.isnan(Mn), -np.inf, score); sc2 = np.where(okw, sc, -np.inf); use = sc2 if np.isfinite(sc2).any() else sc
                q, e = np.unravel_index(int(np.argmax(use)), use.shape); j = Js[q]; t = tstfn(fam[j]['yr'])
                res[meth] += list(fam[j]['N'][t, e])
        for meth in ('単点', '周辺'):
            v = np.array(res[meth]); out.append(dict(評価=scn, 選び方=meth, 件数=len(v), 年件数=len(v) / NY[scn], 平均=v.mean() if len(v) else np.nan, 最大DD=maxdd(v) if len(v) else np.nan))
    return out
# 今の候補一覧（記録だけを含む）にある4時間足の候補も必ず評価する
A = pd.read_pickle(W + '/S26all.pkl'); Cc = pd.read_pickle(W + '/S21cands.pkl').set_index('id')
A = A.assign(指標=A['id'].map(Cc['指標']), 区分=A['id'].map(Cc['区分']))
A = A[(A['定義'] == lab) & (A['向き'] == side) & A['指標'].str.endswith('_4h', na=False)]
need = S[['売買', '窓', '指標', '区分', '使い方']].drop_duplicates()
cur = A.rename(columns={'候補の窓': '窓'})[['売買', '窓', '指標', '区分', '使い方']].drop_duplicates()
need = pd.concat([need, cur], ignore_index=True).drop_duplicates().sort_values('窓')
out = []
for n_, z in enumerate(need.itertuples()):
    dm = np.ones(len(en), bool) if z.売買 == '両方' else (buy if z.売買 == '買いのみ' else ~buy)
    for v, bins in BINS.items():
        if (z.指標, z.区分) not in bins: continue
        m = bins[(z.指標, z.区分)]; m = (m if z.使い方 == '入る' else ~m) & dm
        for r in evaluate(m, z.窓): r.update(定義=lab, 向き=side, 区切り=v, 売買=z.売買, 窓=z.窓, 指標=z.指標, 区分=z.区分, 使い方=z.使い方); out.append(r)
    if n_ % 100 == 0: print(lab, side, n_, len(need), flush=True)
# 条件なし（改善の比較用）
for w in SEGS:
    for dname, dm in (('両方', np.ones(len(en), bool)), ('買いのみ', buy), ('売りのみ', ~buy)):
        for r in evaluate(dm, w): r.update(定義=lab, 向き=side, 区切り='共通', 売買=dname, 窓=w, 指標='条件なし', 区分='', 使い方='入る'); out.append(r)
pd.DataFrame(out).to_pickle(W + '/S33eval_%s_%s.pkl' % (lab, side)); S.assign(定義=lab, 向き=side).to_pickle(W + '/S33scr_%s_%s.pkl' % (lab, side))
print('done', lab, side, len(out))
