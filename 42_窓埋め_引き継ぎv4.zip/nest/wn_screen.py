# ふるい（s10scr の「両方」、s19dirscr の「買いのみ／売りのみ」）を、確かめる年 C より前のデータだけでやり直す
#   python3 wn_screen.py [null種]   … null種を付けると、区分を「日ごとに続きやすい、でたらめな区分」に置き換える（偶然の目安）
#   出力：out/scr[_null種].pkl  (定義, 向き, コスト, C, 出所, 売買, 窓, 指標, 区分, 後半のみ, 使い方)
import sys, numpy as np, pandas as pd
from scipy.signal import lfilter
from wn_common import *
CS = [2023, 2024, 2025, 2026, 2027]; COSTS = ['flat', '13pt']
SEED = int(sys.argv[1]) if (__name__ == '__main__' and len(sys.argv) > 1) else None

def null_bins(D, bins, seed):
    """本物の区分を、同じ該当率で、セッションの並びで続きやすい（AR(1)・係数0.9）でたらめな区分に置き換える（入る側の行ごとに同じ値）"""
    rng = np.random.default_rng(seed * 1000 + KEYS.index(D['key']))
    sess = D['sess']; us, inv = np.unique(sess, return_inverse=True); n = len(us)
    out = {}
    for k, m in bins.items():
        e = rng.standard_normal(n) * np.sqrt(1 - .81); e[0] = rng.standard_normal()
        z = lfilter([1.0], [1.0, -.9], e)
        cov = m[D['ok']].mean() if D['ok'].any() else m.mean()
        thr = np.quantile(z, 1 - cov) if 0 < cov < 1 else (np.inf if cov == 0 else -np.inf)
        v = (z >= thr)[inv]
        if k[0] in D['F'].columns: v = v & ~np.isnan(D['F'][k[0]].values.astype(float))      # 値の無い行は区分にも入らない（本物と同じ）
        out[k] = v
    return out

def run(D, seed=None):
    rows = []
    ok = D['ok']; yr = D['yr']; kind = D['kind']
    for late in (False, True):
        bins = D['bl'] if late else D['ba']
        if seed is not None: bins = null_bins(D, bins, seed + (100 if late else 0))
        keys = list(bins); Bm = np.array([bins[k] for k in keys])
        for cost in COSTS:
            val = D['MN'] - cost_vec(D, cost)
            for w, kks in WINS.items():
                # 両方（s10scr）：前半と後半で上乗せの向きが同じ、後半の |t|≥1（後半のみの指標は 2024年〜で 1.5）、該当率3%以上
                pA = (yr == 2023) if late else (yr <= 2021)
                tA, dA = uplift(Bm, val, D, ok, pA, kks)
                for C in CS:
                    if late and C <= 2024: continue
                    pB = ((yr >= 2024) if late else (yr >= 2022)) & (yr < C)
                    tB, dB = uplift(Bm, val, D, ok, pB, kks)
                    cov = Bm[:, ok & np.isin(kind, kks) & (yr >= 2022) & (yr < C)].mean(1)
                    thr = 1.5 if late else 1.0
                    pas = (np.sign(dA) == np.sign(dB)) & (np.abs(tB) >= thr) & (cov >= .03)
                    for i in np.flatnonzero(pas):
                        rows.append((D['key'][0], D['key'][1], cost, C, 'S10', '両方', w, keys[i][0], keys[i][1], late, '入る' if dB[i] > 0 else '避ける'))
                # 買い・売り別（s19dirscr）：比べる相手は同じ方向の条件なし。後半の |t| だけ、「入る」は該当率2%以上
                for dname, dm in (('買いのみ', D['buy']), ('売りのみ', ~D['buy'])):
                    okd = ok & dm
                    for C in CS:
                        if late and C <= 2024: continue
                        pB = ((yr >= 2024) if late else (yr >= 2022)) & (yr < C)
                        tB, dB = uplift(Bm, val, D, okd, pB, kks)
                        cov = Bm[:, okd & np.isin(kind, kks) & (yr >= 2022) & (yr < C)].mean(1)
                        thr = 1.5 if late else 1.0
                        for i in np.flatnonzero(np.abs(tB) >= thr):
                            use = '入る' if dB[i] > 0 else '避ける'
                            if use == '入る' and cov[i] < .02: continue
                            rows.append((D['key'][0], D['key'][1], cost, C, 'S19', dname, w, keys[i][0], keys[i][1], late, use))
            print(D['key'], late, cost, len(rows), flush=True)
    return rows

if __name__ == '__main__':
    import os; os.makedirs(OUT, exist_ok=True)
    R = []
    for key in KEYS:
        D = load_ds(key, light=True); R += run(D, SEED)
        if SEED is not None: pd.to_pickle({k: np.packbits(v) for k, v in null_bins(D, D['ba'], SEED).items()} | {k: np.packbits(v) for k, v in null_bins(D, D['bl'], SEED + 100).items()}, OUT + '/nullbins_%d_%s%s.pkl' % (SEED, *key))
    S = pd.DataFrame(R, columns=['定義', '向き', 'コスト', 'C', '出所', '売買', '窓', '指標', '区分', '後半のみ', '使い方'])
    S.to_pickle(OUT + '/scr%s.pkl' % ('' if SEED is None else '_null%d' % SEED))
    print(S.groupby(['コスト', 'C', '出所']).size().unstack())
