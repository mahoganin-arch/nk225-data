# 窓埋め：本当の前向き（入れ子）用の共通部分
#   元の手順（s9cal / s10scr / s10eval / s19dirscr / s19eval）と同じ計算を、年ごとの和から組み立てられる形にしたもの
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/work/01/code'); sys.path.insert(0, '/home/claude/work/08/an')
from common6 import CB, P
W = '/home/claude/work'; OUT = W + '/40nest/out'
DS = {('現行', '順張り'): W + '/T', ('先物基準', '順張り'): W + '/F6W/T6', ('現行', '逆張り'): W + '/R', ('先物基準', '逆張り'): W + '/F6W/R6'}
KEYS = list(DS)
YEARS = list(range(2017, 2027)); YI = {y: i for i, y in enumerate(YEARS)}
YW = {y: (0.77 if y == 2026 else 1.0) for y in YEARS}           # 年件数の分母（2026年は10/8まで）
KINDS = ['D>N', 'N>D']; WINS = {'D>N': [0], 'N>D': [1], '両方の窓': [0, 1]}
LATE = ('前セッション最後1時間の出来高比', '出来高最多価格まで', '出来高最多価格をまたいだ', '出来高の多い価格帯の端まで')
SP = 13.0; WORST = -1000; MINSEL = 15
FRi = np.arange(12); SKi = np.r_[1:18, 0]; TMi = np.r_[1:9, 0]
PERM = np.array([(f * 18 + s) * 9 + t for f in FRi for s in SKi for t in TMi])
FLAGS = ['SQ週(メジャー)', 'SQ週(ミニ)', 'SQ当日', 'SQ前日', '祝日前日', '祝日翌日(連休明け含む)', '祝日取引中', '月末3営業日', '月初3営業日']

def make_bins(F, sel):
    out = {}
    for c in F.columns:
        v = F[c].values.astype(float); fin = ~np.isnan(v); vt = v[sel & fin]; u = np.unique(vt)
        if len(vt) < 100: continue
        if len(u) <= 6:
            for x in u: out[(c, '=%g' % x)] = v == x
            continue
        q3 = np.quantile(vt, [1 / 3, 2 / 3]); b3 = np.searchsorted(q3, v, side='right')
        for i, lab in enumerate(['3分割:低', '3分割:中', '3分割:高']): out[(c, lab)] = fin & (b3 == i)
        q5 = np.quantile(vt, [.2, .4, .6, .8]); b5 = np.searchsorted(q5, v, side='right')
        for i in range(5): out[(c, '5分割:%d' % (i + 1))] = fin & (b5 == i)
        lo, hi = np.quantile(vt, [.1, .9]); out[(c, '下位10%')] = fin & (v <= lo); out[(c, '上位10%')] = fin & (v >= hi)
    return out

def load_ds(key, light=False):
    from s9cal import flags
    d = DS[key]
    en = pd.read_pickle(d + '/en.pkl'); ev = pd.read_pickle(d + '/evt.pkl')
    en = en.join(ev[['kind', 'long', 't0']], on='ev'); en['yr'] = en.t0.dt.year
    px = (en.ent.values if 'ent' in en else ev.B.values[en.ev.values]).astype(float)
    F = pd.concat([pd.read_pickle(d + '/F6.pkl').drop(columns=['時']), pd.read_pickle(d + '/F7.pkl')], axis=1)
    MN = np.load(d + '/mnet_gross.npy').astype(float)
    side = key[1]; buy = (en.d.values < 0) if side == '順張り' else (en.d.values > 0)
    D = dict(key=key, d=d, en=en, ev=ev, px=px, F=F, MN=MN, buy=buy, ok=~en.long.values, yr=en.yr.values, kind=np.where(en.kind.values == 'D>N', 0, 1),
             sess=ev.i.values[en.ev.values], FL=flags(ev).iloc[en.ev.values].reset_index(drop=True))
    D['XP'] = np.array(sorted(en.x.unique()))
    D['xj'] = np.searchsorted(D['XP'], en.x.values - 1e-9)
    ok = D['ok']; yr = D['yr']
    D['ba'] = make_bins(F.drop(columns=list(LATE)), ok & (yr <= 2021)); D['bl'] = make_bins(F[list(LATE)], ok & (yr == 2023))
    # 窓の種類・乖離幅ごとの行（時刻順、長い休み明けは除く）
    IDX = {}
    for kk in (0, 1):
        for j in range(len(D['XP'])):
            r = np.nonzero(ok & (D['kind'] == kk) & (D['xj'] == j))[0]; r = r[np.argsort(en.m.values[r], kind='stable')]
            IDX[(kk, j)] = r
    D['IDX'] = IDX
    if not light:
        D['Y'] = np.load(d + '/Y.npy', mmap_mode='r')
    return D

def cost_vec(D, cost):
    """1回あたりのコスト（円）：13pt＝13pt÷値段×68,800、flat＝毎回13円（コストの重さをそろえる）"""
    return SP * P / D['px'] if cost == '13pt' else np.full(len(D['px']), SP)

def uplift(Bm, val, D, okm, period, kk_list):
    """s10scr.uplift と同じ：乖離幅ごとの t と上乗せの中央値（6つ以上の乖離幅で計算できたものだけ）"""
    T = []; Dd = []
    kind = D['kind']; xj = D['xj']
    for j in range(len(D['XP'])):
        e = okm & period & np.isin(kind, kk_list) & (xj == j)
        if e.sum() < 60: continue
        m = val[e]; Be = Bm[:, e].astype(np.float64); n = Be.sum(1); s = Be @ m; q = Be @ (m * m)
        mu = np.where(n > 0, s / np.maximum(n, 1), np.nan); var = np.where(n > 1, (q - n * mu ** 2) / np.maximum(n - 1, 1), np.nan)
        with np.errstate(all='ignore'): t = (mu - m.mean()) / np.sqrt(var / np.maximum(n, 1))
        dd = mu - m.mean(); t[n < 20] = np.nan; dd[n < 20] = np.nan; T.append(t); Dd.append(dd)
    if not T: return np.full(Bm.shape[0], np.nan), np.full(Bm.shape[0], np.nan)
    T = np.array(T); Dd = np.array(Dd); good = (~np.isnan(T)).sum(0) >= 6
    with np.errstate(all='ignore'): return np.where(good, np.nanmedian(T, 0), np.nan), np.where(good, np.nanmedian(Dd, 0), np.nan)

def box3(A):
    """4次元（乖離幅・利確・損切り・時間）の 3^4 の近所の和（端は0で埋める）。最初の軸はまとめて計算する本数"""
    out = A
    for ax in range(1, 5):
        p = [(0, 0)] * 5; p[ax] = (1, 1); B = np.pad(out, p); n = out.shape[ax]
        sl = lambda a, b: tuple(slice(a, b) if i == ax else slice(None) for i in range(5))
        out = B[sl(0, n)] + B[sl(1, n + 1)] + B[sl(2, n + 2)]
    return out

import numba
@numba.njit(cache=True)
def _nbr(A, out):
    # s9cal.nbr_mean と同じ足し算の順番（d0, d1, d2, d3 の順、float32）で、K 本まとめて
    K, J, a, b, c = A.shape
    for k in range(K):
        for j in range(J):
            for f in range(a):
                for s in range(b):
                    for t in range(c):
                        if np.isnan(A[k, j, f, s, t]):
                            out[k, j, f, s, t] = np.nan; continue
                        vs = np.float32(0.0); cs = np.float32(0.0)
                        for d0 in range(3):
                            jj = j + d0 - 1
                            if jj < 0 or jj >= J: continue
                            for d1 in range(3):
                                ff = f + d1 - 1
                                if ff < 0 or ff >= a: continue
                                for d2 in range(3):
                                    ss = s + d2 - 1
                                    if ss < 0 or ss >= b: continue
                                    for d3 in range(3):
                                        tt = t + d3 - 1
                                        if tt < 0 or tt >= c: continue
                                        v = A[k, jj, ff, ss, tt]
                                        if not np.isnan(v):
                                            vs += v; cs += np.float32(1.0)
                        out[k, j, f, s, t] = vs / max(cs, np.float32(1.0))

def nbr_mean_k(Mn):
    """s9cal.nbr_mean を K 本まとめて：Mn (K, 28, 1944) float32 → 周辺の平均 (K, 28, 1944)"""
    K, J, _ = Mn.shape
    A = np.ascontiguousarray(Mn[:, :, PERM].reshape(K, J, 12, 18, 9)).astype(np.float32)
    SM = np.empty_like(A); _nbr(A, SM)
    out = np.full((K, J, 1944), np.nan, np.float32); out[:, :, PERM] = SM.reshape(K, J, 1944)
    return out

# 選び方の「選ぶ期間」の集まり（確かめる年とは独立に、選ぶ期間だけで決まる）
def sel_sets():
    S = {'S1': [y for y in YEARS if y <= 2021], 'S2': [2022, 2023]}
    for t in range(2023, 2027): S['後半_%d' % t] = list(range(2022, t))
    for t in range(2019, 2027): S['全期間_%d' % t] = list(range(2017, t))
    for t in range(2022, 2027): S['直近3_%d' % t] = list(range(t - 3, t))
    for t in range(2022, 2027): S['直近5_%d' % t] = [y for y in range(t - 5, t) if y >= 2017]
    return S
SELS = sel_sets(); SELK = list(SELS)

def forms(C, tmin=0):
    """C 年より前に確かめられる部分だけの5つの評価の形：{形: [(選ぶ期間の名前, [確かめる年])]}。確かめる年が無い形は除く"""
    F = {'S1 前半→後半': [('S1', list(range(2022, C)))],
         'S2 22-23→24-26': [('S2', list(range(2024, C)))],
         'WF後半': [('後半_%d' % t, [t]) for t in range(2023, C)],
         'WF全期間': [('全期間_%d' % t, [t]) for t in range(2022, C)],
         'WF直近3年': [('直近3_%d' % t, [t]) for t in range(2022, C)]}
    out = {}
    for k, v in F.items():
        v = [(s, [y for y in te if y >= tmin and y <= 2026]) for s, te in v]; v = [(s, te) for s, te in v if te]
        if v: out[k] = v
    return out
