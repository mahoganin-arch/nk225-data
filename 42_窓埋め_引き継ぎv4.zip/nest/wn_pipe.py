# 本当の前向き（入れ子）：候補選びの全段階（評価・残す → 重なりでまとめる → 案3 → マイナス除外 → 重なり75%・PF1.2 → 同じ向き2本）を
#   確かめる年 C より前のデータだけでやり直し、C 年を売買する。C=2027 は元の手順（2026年までのデータで候補を選び、2024〜26年を前向き検証）
import sys, numpy as np, pandas as pd, pickle, os
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.spatial.distance import squareform
from wn_common import *
XG = np.array([.2, .3, .4, .5, .6, .7, .8, .9, 1.0, 1.2, 1.5])
SIDES = {('現行', '順張り'): '順張り', ('先物基準', '順張り'): '順張り', ('現行', '逆張り'): '逆張り', ('先物基準', '逆張り'): '逆張り'}

class Cfg:
    def __init__(self, cost='flat', scheme='全期間', plus=3, med=20, ycnt=10, imp=20, null=None, N=5, dirs=('両方', '売りのみ'), dedup=.75, pfmin=1.2, pol='C1'):
        self.cost = cost; self.scheme = scheme; self.plus = plus; self.med = med; self.ycnt = ycnt; self.imp = imp; self.null = null
        self.N = N; self.dirs = dirs; self.dedup = dedup; self.pfmin = pfmin; self.pol = pol
    def suf(self): return '' if self.null is None else '_null%d' % self.null

SUMS = {}
def sums(key, null=None):
    k = (key, null)
    if k not in SUMS:
        SUMS.clear(); SUMS[k] = pd.read_pickle(OUT + '/sums_%s_%s%s.pkl' % (key[0], key[1], '' if null is None else '_null%d' % null))
    return SUMS[k]

def rule_sel(scheme, t): return '%s_%d' % ('全期間' if scheme == '全期間' else '直近5', t)

# ---------------------------------------------------------------- 1. 評価と残す
def evaluate(cfg, C):
    """各データの条件 × 窓 × 選び方 の5つの評価の形の成績と、残す判定。戻り値：候補表"""
    scr = pd.read_pickle(OUT + '/scr%s.pkl' % cfg.suf()); scr = scr[(scr['コスト'] == cfg.cost) & (scr['C'] == C)]
    out = []
    for key in KEYS:
        S = sums(key, cfg.null); conds = S['conds']; R = S['R']
        ck = {tuple(r): i for i, r in enumerate(conds[['売買', '指標', '区分', '後半のみ', '使い方']].itertuples(index=False))}
        sc = scr[(scr['定義'] == key[0]) & (scr['向き'] == key[1])]
        todo = []                              # (条件番号, 窓, 出所)
        for r in sc.itertuples(): todo.append((ck[(r.売買, r.指標, r.区分, r.後半のみ, r.使い方)], r.窓, r.出所))
        for w in WINS:
            todo.append((ck[('両方', '条件なし', '', False, '入る')], w, 'NC'))
            for dn in ('買いのみ', '売りのみ'): todo.append((ck[(dn, '条件なし', '', False, '入る')], w, 'S19'))
            for f in FLAGS:
                for u in ('入る', '避ける'): todo.append((ck[('両方', f, '印あり', False, u)], w, 'FL'))
        todo = pd.DataFrame(todo, columns=['k', '窓', '出所']).drop_duplicates(['k', '窓'])
        for w, g in todo.groupby('窓'):
            ks = g.k.values; kk = WINS[w]
            for meth in ('単点', '周辺'):
                for late in (False, True):
                    sel = conds.後半のみ.values[ks] == late; kz = ks[sel]
                    if not len(kz): continue
                    FM = forms(C, 2024 if late else 0)
                    res = {}
                    for fn, splits in FM.items():
                        tsum = np.zeros(len(kz)); tcnt = np.zeros(len(kz)); yrs = set()
                        for s, te in splits:
                            d = R[(cfg.cost, w, meth, s)]; has = d['q'][kz] >= 0
                            ys = d['ys'][kz][:, kk].sum(1); yc = d['yc'][kz][:, kk].sum(1)
                            ti = [YI[y] for y in te]; yrs |= set(te)
                            tsum += np.where(has, ys[:, ti].sum(1), 0); tcnt += np.where(has, yc[:, ti].sum(1), 0)
                        ny = sum(YW[y] for y in yrs)
                        with np.errstate(all='ignore'): res[fn] = (np.where(tcnt > 0, tsum / np.maximum(tcnt, 1), np.nan), tcnt / ny)
                    if not res: continue
                    V = np.array([res[f][0] for f in res]).T; Nc = np.array([res[f][1] for f in res]).T
                    with np.errstate(all='ignore'):
                        plus = (V > 0).sum(1); med = np.nanmedian(V, 1); mn = np.nanmin(V, 1); ycm = np.median(Nc, 1)
                    src = g.set_index('k').loc[kz, '出所'].values
                    out.append(pd.DataFrame(dict(定義=key[0], 向き=key[1], k=kz, 窓=w, 選び方=meth, 後半のみ=late, 出所=src, プラス数=plus, 中央=med, 最小=mn, 年件数=ycm, 形の数=len(res))))
    E = pd.concat(out, ignore_index=True)
    # 条件の中身
    meta = []
    for key in KEYS:
        c = sums(key, cfg.null)['conds'].copy(); c['定義'] = key[0]; c['向き'] = key[1]; c['k'] = np.arange(len(c)); meta.append(c.drop(columns=['出所']))
    E = E.merge(pd.concat(meta), on=['定義', '向き', 'k', '後半のみ'])
    # 条件なしとの差（両方の候補の基準）
    base = E[(E.出所 == 'NC')][['定義', '向き', '窓', '選び方', '中央']].rename(columns={'中央': '条件なし中央'})
    E = E.merge(base, on=['定義', '向き', '窓', '選び方'], how='left')
    if C > 2024:   # 後半のみの指標は 2024年〜の条件なしと比べる
        L = []
        for key in KEYS:
            S = sums(key, cfg.null); conds = S['conds']; R = S['R']; k0 = int(np.flatnonzero((conds.売買 == '両方') & (conds.指標 == '条件なし'))[0])
            for w, kk in WINS.items():
                for meth in ('単点', '周辺'):
                    V = []
                    for fn, splits in forms(C, 2024).items():
                        ts = tc = 0.0
                        for s, te in splits:
                            d = R[(cfg.cost, w, meth, s)]
                            if d['q'][k0] < 0: continue
                            ti = [YI[y] for y in te]; ts += d['ys'][k0][kk][:, ti].sum(); tc += d['yc'][k0][kk][:, ti].sum()
                        V.append(ts / tc if tc > 0 else np.nan)
                    L.append(dict(定義=key[0], 向き=key[1], 窓=w, 選び方=meth, 条件なし中央24=np.nanmedian(V)))
        E = E.merge(pd.DataFrame(L), on=['定義', '向き', '窓', '選び方'], how='left')
        E.loc[E.後半のみ, '条件なし中央'] = E.loc[E.後半のみ, '条件なし中央24']
    E['改善'] = E['中央'] - E['条件なし中央']
    base_ok = (E.プラス数 >= cfg.plus) & (E.中央 >= cfg.med) & (E.年件数 >= cfg.ycnt)
    E['残す'] = np.where(E.出所.isin(['S10', 'FL']), base_ok & (E.改善 >= cfg.imp), np.where(E.出所 == 'S19', base_ok, False))
    return E

def candidates(E):
    """残った条件（どちらかの選び方）を候補に。条件なし（両方）は基本として必ず入れる"""
    k = ['定義', '向き', 'k', '窓', '出所', '売買', '指標', '区分', '後半のみ', '使い方']
    K = E[E.残す].groupby(k).agg(選び方数=('選び方', 'size'), 最小=('最小', 'min'), 年件数=('年件数', 'mean'), 中央=('中央', 'mean')).reset_index()
    B = E[E.出所 == 'NC'].groupby(k).agg(中央=('中央', 'mean')).reset_index(); B['選び方数'] = 0; B['最小'] = np.nan; B['年件数'] = np.nan
    Cd = pd.concat([K, B], ignore_index=True)
    Cd['基本'] = Cd.指標 == '条件なし'
    Cd['id'] = np.arange(len(Cd))
    return Cd

# ---------------------------------------------------------------- 2. 重なりでまとめる
DSL = {}
def dsl(key):
    if key not in DSL: DSL.clear(); DSL[key] = load_ds(key, light=True)
    return DSL[key]
NULLB = {}
def bin_of(D, r, null):
    if r.指標 in FLAGS:
        if null is None: return D['FL'][r.指標].values.astype(bool)
        from wn_screen import null_bins
        k = (D['key'], null, r.指標)
        if k not in NULLB: NULLB[k] = null_bins(D, {(r.指標, '印あり'): D['FL'][r.指標].values.astype(bool)}, null + 200)[(r.指標, '印あり')]
        return NULLB[k]
    if null is None: return {**D['ba'], **D['bl']}[(r.指標, r.区分)]
    k = (D['key'], null)
    if k not in NULLB:
        NB = pd.read_pickle(OUT + '/nullbins_%d_%s%s.pkl' % (null, *D['key'])); n = len(D['en'])
        NULLB.clear(); NULLB[k] = {kk: np.unpackbits(v)[:n].astype(bool) for kk, v in NB.items()}
    return NULLB[k][(r.指標, r.区分)]

def group(Cd, C, null=None):
    """両方：向き × 種類（入る／避ける）、方向別：向き × 売買 × 種類 で、(セッション, 乖離幅) の集合の Ochiai・平均連結・0.5で切る。代表は 選び方数・最小・年件数 の順"""
    ROW = {}
    for key in KEYS:
        sub = Cd[(Cd.定義 == key[0]) & (Cd.向き == key[1]) & ~Cd.基本]
        if not len(sub): continue
        D = dsl(key); en = D['en']; yr = D['yr']; F = D['F']
        keyx = D['sess'] * 100 + np.round(en.x.values * 10).astype(int); grid = np.isin(np.round(en.x.values, 3), XG)
        for r in sub.itertuples():
            per = D['ok'] & np.isin(D['kind'], WINS[r.窓]) & (yr >= 2022) & (yr < C) & grid
            if r.後半のみ: per &= (yr >= 2023) & ~np.isnan(F[r.指標].values.astype(float))
            if r.売買 == '買いのみ': per &= D['buy']
            elif r.売買 == '売りのみ': per &= ~D['buy']
            b = bin_of(D, r, null)
            ROW[r.id] = set(keyx[per & b]) if r.使い方 == '避ける' else set(keyx[per & b])
    Cd = Cd.copy(); Cd['グループ'] = ''; Cd['代表'] = False
    Cd['dirg'] = np.where(Cd.売買 == '両方', '両方', '方向別')
    NB_ = Cd[~Cd.基本].copy(); NB_['dn_'] = np.where(NB_.売買 == '両方', '', NB_.売買); NB_['use_'] = np.where(NB_.使い方 == '避ける', '避ける', '入る')
    for (side, dg, dn, use), sub in NB_.groupby(['向き', 'dirg', 'dn_', 'use_']):
        ids = list(sub.id); n = len(ids)
        if n == 1: g = np.array([1])
        else:
            L = [ROW[i] for i in ids]; S = np.eye(n)
            for a in range(n):
                for b in range(a + 1, n):
                    d = np.sqrt(len(L[a]) * len(L[b])); S[a, b] = S[b, a] = len(L[a] & L[b]) / d if d else 0
            g = fcluster(linkage(squareform(1 - S, checks=False), 'average'), .5, 'distance')
        lab = ['%s・%s・%s・%s・%04d' % (side, dg, dn, use, x) for x in g]
        Cd.loc[sub.index, 'グループ'] = lab
        df = sub.assign(g=g).sort_values(['g', '選び方数', '最小', '年件数'], ascending=[True, False, False, False])
        Cd.loc[df.groupby('g').head(1).index, '代表'] = True
    b = Cd.基本
    Cd.loc[b, 'グループ'] = Cd.loc[b, '向き'] + '・' + Cd.loc[b, '売買'] + '・基本'; Cd.loc[b, '代表'] = True
    return Cd

# ---------------------------------------------------------------- 3. トレード（年ごとのルール）
class Trades:
    """候補（データ・条件・窓）の、各年のルール（その年より前のデータで選んだ乖離幅・決済、周辺）でのその年のトレード"""
    def __init__(self):
        sys.path.insert(0, '/home/claude/work/01/code'); import ld
        c5 = ld.bars(W + '/data/c5.csv', until='2026-10-09'); c1 = ld.bars(W + '/data/c1.csv', until='2026-10-09')
        cx = pd.concat([c5[c5.m + 5 <= c1.m.iloc[0]], c1], ignore_index=True); self.cm = cx.m.values.astype(float)
        bl = np.r_[np.diff(self.cm), 1.0]; self.blen = np.where(bl > 5, np.where(self.cm >= c1.m.iloc[0], 1.0, 5.0), bl)
        self.cache = {}; self.D = {}
    def ds(self, key):
        if key not in self.D:
            D = load_ds(key, light=True); d = DS[key]
            D['Y'] = np.load(d + '/Y.npy', mmap_mode='r'); D['EX'] = np.load(d + '/EX.npy', mmap_mode='r'); D['gk'] = np.load(d + '/gk.npy')
            for k in ('F', 'ba', 'bl', 'FL'): D.pop(k, None)
            self.D[key] = D
        return self.D[key]
    def get(self, key, k, w, cost, scheme, null, mask_fn, years):
        ck = (key, k, w, cost, scheme, null)
        if ck in self.cache: return self.cache[ck]
        S = sums(key, null); R = S['R']; D = self.ds(key); en = D['en']
        m = mask_fn(); base = D['ok'] & m & np.isin(D['kind'], WINS[w]); out = []
        for t in years:
            if (cost, w, '周辺', rule_sel(scheme, t)) not in R: continue
            d = R[(cost, w, '周辺', rule_sel(scheme, t))]; q = int(d['q'][k]); e = int(d['e'][k])
            if q < 0: continue
            rows = np.nonzero(base & (D['xj'] == q) & (D['yr'] == t))[0]
            if not len(rows): continue
            pnl = np.asarray(D['Y'][rows, e], np.float32).astype(float) / 100 * P - cost_vec(D, cost)[rows]
            code = np.asarray(D['EX'][rows, e]).astype(int); g0 = D['gk'][rows]; g = g0 + code // 4; typ = code % 4
            if key[0] == '先物基準': tin = self.cm[g0]
            else: tin = np.where(en.reo.values[rows], self.cm[g0] + self.blen[g0], self.cm[g0] + .5 * self.blen[g0])
            tout = np.where(typ == 2, self.cm[g], np.where(typ == 3, self.cm[g] + self.blen[g], self.cm[g] + .9 * self.blen[g]))
            pos = en.d.values[rows] if key[1] == '逆張り' else -en.d.values[rows]
            out.append(pd.DataFrame(dict(年=t, セッション=D['sess'][rows], 窓の種類=np.where(D['kind'][rows] == 0, 'D>N', 'N>D'), 入る時刻=tin, 手じまう時刻=tout, 向き=pos, 損益=pnl)))
        T = pd.concat(out, ignore_index=True) if out else pd.DataFrame(columns=['年', 'セッション', '窓の種類', '入る時刻', '手じまう時刻', '向き', '損益'])
        self.cache[ck] = T
        return T

def cond_mask_fn(key, r, null):
    def f():
        D = TR.ds(key); n = len(D['en'])
        if r.指標 == '条件なし': m = np.ones(n, bool)
        else:
            Dl = dsl(key); m = bin_of(Dl, r, null)
        if r.使い方 == '避ける': m = ~m
        if r.売買 == '買いのみ': m = m & D['buy']
        elif r.売買 == '売りのみ': m = m & ~D['buy']
        if r.後半のみ: m = m & ~np.isnan(dsl(key)['F'][r.指標].values.astype(float))
        return m
    return f
TR = None

# ---------------------------------------------------------------- 4. 案3・マイナス除外・重なり75%・PF1.2・運用
def sel_stats(Cd, cfg, t):
    """t年のルールの、選ぶ期間（ルールを選んだ年）の窓の種類ごとの1回平均と件数、2017〜21年の合計（t=2022のルール）"""
    rows = []
    for key in KEYS:
        sub = Cd[(Cd.定義 == key[0]) & (Cd.向き == key[1])]
        if not len(sub): continue
        R = sums(key, cfg.null)['R']
        for w, g in sub.groupby('窓'):
            d = R[(cfg.cost, w, '周辺', rule_sel(cfg.scheme, t))]; ks = g.k.values
            ys = d['ys'][ks]; yc = d['yc'][ks]; has = d['q'][ks] >= 0
            yrs = SELS[rule_sel(cfg.scheme, t)]; yi = [YI[y] for y in yrs]
            d0 = R[(cfg.cost, w, '周辺', '全期間_2022')]; s0 = d0['ys'][ks][:, :, [YI[y] for y in range(2017, 2022)]].sum(2); h0 = d0['q'][ks] >= 0
            for kk in WINS[w]:
                rows.append(pd.DataFrame(dict(id=g.id.values, 窓の種類=KINDS[kk], 選ぶ平均=np.where(has, ys[:, kk, yi].sum(1) / np.maximum(yc[:, kk, yi].sum(1), 1), np.nan),
                                              選ぶ件数=np.where(has, yc[:, kk, yi].sum(1), 0), 前半合計=np.where(h0, s0[:, kk], -1))))
    return pd.concat(rows, ignore_index=True)

def fwd(Cd, cfg, upto, years_from=2022):
    """前向き記録：各年のルールでのその年のトレード（years_from〜upto−1年）"""
    out = []
    yrs = list(range(years_from, upto))
    for r in Cd.itertuples():
        key = (r.定義, r.向き)
        T = TR.get(key, r.k, r.窓, cfg.cost, cfg.scheme, cfg.null, cond_mask_fn(key, r, cfg.null), list(range(2019, 2027)))
        T = T[T.年.isin(yrs)]
        if len(T): out.append(T.assign(id=r.id))
    return pd.concat(out, ignore_index=True) if out else pd.DataFrame(columns=['年', 'セッション', '窓の種類', '入る時刻', '手じまう時刻', '向き', '損益', 'id'])

def stats_rec(F):
    out = {}
    for (i, kind), g in F.sort_values('手じまう時刻').groupby(['id', '窓の種類']):
        v = g.損益.values; c = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, c])[1:] - c).max(); gp = v[v > 0].sum(); gl = -v[v < 0].sum()
        out[(i, kind)] = dict(n=len(v), sum=v.sum(), rf=v.sum() / max(dd, 1.0), pf=gp / gl if gl > 0 else np.inf, ses=set(g.セッション))
    return out

def run_window(tr, pol):
    held = []; done = []; closed_any = False
    for r in tr:
        tin = r['入る時刻']; still = []
        for h in held:
            if h['手じまう時刻'] <= tin: done.append(h); closed_any = True
            else: still.append(h)
        held = still
        if closed_any: continue
        same = [h for h in held if h['向き'] == r['向き']]; opp = [h for h in held if h['向き'] != r['向き']]
        new = dict(r)
        if pol == 'A1':
            if held: continue
        elif pol == 'C1':
            if opp or len(held) >= 2: continue
            if same and same[0]['id'] == r['id']: continue
        elif pol == 'D1':
            if len(held) >= 2: continue
            if same and same[0]['id'] == r['id']: continue
        held.append(new)
    return done + held

def choose(Cd, cfg, t):
    """t年に使う候補と優先順位（t年より前のデータだけ）"""
    SS = sel_stats(Cd, cfg, t).set_index(['id', '窓の種類'])
    FR = fwd(Cd, cfg, t); FS = stats_rec(FR)
    side = Cd.set_index('id')['向き']; dirn = Cd.set_index('id')['売買']; grp = Cd.set_index('id')['グループ']; reps = set(Cd.id[Cd.代表])
    BK = [(k, s, d) for k in KINDS for s in ('順張り', '逆張り') for d in ('両方', '買いのみ', '売りのみ')]
    old = {b: [] for b in BK}; rf = {b: [] for b in BK}
    x = SS.reset_index(); x = x[x.id.isin(reps) & (x.選ぶ件数 >= 15)].sort_values('選ぶ平均', ascending=False, kind='stable')
    for r in x.itertuples():
        if FS.get((r.id, r.窓の種類), dict(sum=1.0))['sum'] <= 0: continue          # 前向き記録がマイナスは外す（記録が無いものは残す）
        old[(r.窓の種類, side[r.id], dirn[r.id])].append(r.id)
    ny = t - 2022; minn = 5 * ny; sc = []
    for (i, kind), s in FS.items():
        if s['n'] < minn or s['sum'] <= 0: continue
        p0 = SS['前半合計'].get((i, kind), -1)
        if p0 <= 0: continue
        sc.append((i, kind, s['rf']))
    sc = pd.DataFrame(sc, columns=['id', 'kind', 'rf']).sort_values('rf', ascending=False, kind='stable')
    if len(sc): sc['g'] = sc.id.map(grp); sc = sc.drop_duplicates(['kind', 'g'])
    for r in sc.itertuples(): rf[(r.kind, side[r.id], dirn[r.id])].append(r.id)
    L = {}
    for b in BK:
        if b[2] not in cfg.dirs: continue
        a = old[b][:cfg.N]; c = rf[b][:cfg.N]; ids = list(dict.fromkeys(a + c))
        L[b] = [(i, i in a and i in c, a.index(i) + 1 if i in a else 99, c.index(i) + 1 if i in c else 99) for i in ids]
    keys = [(r[0], b[0]) for b, rows in L.items() for r in rows]
    if cfg.pfmin: keys = [k for k in keys if k not in FS or FS[k]['pf'] >= cfg.pfmin]
    if cfg.dedup:
        keep = []
        for k in sorted(keys, key=lambda k: -FS[k]['rf'] if k in FS else 0):
            okk = True
            for q in keep:
                if q[1] != k[1] or k not in FS or q not in FS: continue
                A, B = FS[k]['ses'], FS[q]['ses']
                if A and B and len(A & B) / len(A | B) >= cfg.dedup: okk = False; break
            if okk: keep.append(k)
        keys = keep
    ks = set(keys)
    allr = [(b, r) for b, rows in L.items() for r in rows if (r[0], b[0]) in ks]
    allr.sort(key=lambda br: (not br[1][1], min(br[1][2], br[1][3]), br[1][2]))
    return {(r[0], b[0]): p for p, (b, r) in enumerate(allr)}

def simulate(Cd, cfg, t, pr):
    ids = set(i for i, _ in pr)
    T = fwd(Cd[Cd.id.isin(ids)], cfg, t + 1, t)
    T = T[[(i, k) in pr for i, k in zip(T.id, T.窓の種類)]].copy()
    T['順位'] = [pr[(i, k)] for i, k in zip(T.id, T.窓の種類)]
    T = T.sort_values(['セッション', '入る時刻', '順位'], kind='stable'); out = []
    for s, tr in T.groupby('セッション', sort=False): out += run_window(tr.to_dict('records'), cfg.pol)
    H = pd.DataFrame(out);
    if len(H): H['確かめる年'] = t
    return H

def summ(H):
    if not len(H): return dict(件数=0, 合計=0.0, 最大DD=0.0)
    H = H.sort_values('手じまう時刻'); v = H.損益.values; c = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, c])[1:] - c).max()
    gp = v[v > 0].sum(); gl = -v[v < 0].sum()
    return dict(件数=len(v), 合計=v.sum(), 最大DD=dd, 一回平均=v.mean(), 勝率=(v > 0).mean() * 100, PF=gp / gl if gl > 0 else np.inf)

def run(cfg, Cs, valid_years=(2024, 2025, 2026), tag=''):
    """Cs の各 C で候補を選び、C 年を売買（C=2027 のときは valid_years を前向き検証）"""
    global TR
    if TR is None: TR = Trades()
    res = {}
    for C in Cs:
        E = evaluate(cfg, C); Cd = group(candidates(E), C, cfg.null)
        tests = list(valid_years) if C == 2027 else [C]
        Hs = []; PRs = {}
        for t in tests:
            pr = choose(Cd, cfg, t); PRs[t] = pr
            H = simulate(Cd, cfg, t, pr); Hs.append(H)
            print(tag, 'C', C, 't', t, '候補', len(Cd), '使う', len(pr), '合計', round(H.損益.sum()) if len(H) else 0, flush=True)
        res[C] = dict(E=E, Cd=Cd, PR=PRs, H=pd.concat(Hs, ignore_index=True) if Hs else pd.DataFrame())
    return res
