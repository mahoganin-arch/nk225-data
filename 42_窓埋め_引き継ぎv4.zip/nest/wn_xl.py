# 窓埋めの本当の前向き：Excel
import pickle, os, sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/work/01/code'); sys.path.insert(0, '/home/claude/work/08/an')
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
import wn_pipe as wp
from common6 import jname
O = wp.OUT; XL = '/home/claude/work/40nest/S30_窓埋め_本当の前向き.xlsx'
SM = pd.read_pickle(O + '/summary.pkl'); T = SM['T']; LD = SM['LD']
DT = pd.read_pickle(O + '/detail.pkl')
TFJ = {'5m': '5分', '15m': '15分', '60m': '60分', '4h': '4時間', 'D': '日足', 'W': '週足'}
def nm(x):
    if x == '条件なし' or x in wp.FLAGS: return x
    b_, _, tf = x.rpartition('_')
    if tf in TFJ and (not b_.isascii() or b_.isupper()): return TFJ[tf] + b_
    try: return jname(x)
    except Exception: return x
def used_list(run, C, t):
    r = pickle.load(open(O + '/run_%s.pkl' % run, 'rb'))['res'][C]; Cd = r['Cd'].set_index('id'); PR = r['PR'][t]; H = r['H']; H = H[H.確かめる年 == t]
    rows = []
    for (i, k), p in sorted(PR.items(), key=lambda kv: kv[1]):
        z = Cd.loc[i]; h = H[(H.id == i) & (H.窓の種類 == k)]
        rows.append(dict(優先順位=p + 1, 窓の種類=k, 向き=z.向き, 売買=z.売買, 定義=z.定義, 候補の窓=z.窓, 条件=('条件なし' if z.指標 == '条件なし' else '%s %s' % (nm(z.指標), z.区分)), 使い方=z.使い方,
                         その年に持った件数=len(h), その年の損益=h.損益.sum()))
    return pd.DataFrame(rows)
L = {}
L['2026年に使う一覧_重さ統一'] = used_list('main_flat', 2026, 2026)
L['2026年に使う一覧_13pt'] = used_list('main_13', 2026, 2026)
L['元の手順の2026年の一覧_13pt'] = used_list('valid13', 2027, 2026)
lg = pickle.load(open(O + '/long_flat.pkl', 'rb')); Cl = lg['Cd'].set_index('id'); YT = lg['YT']
YT['候補'] = [f"{Cl.loc[i, '定義']}・{Cl.loc[i, '向き']}・{Cl.loc[i, '売買']}・{Cl.loc[i, '窓']}" for i in YT.id]
P1 = YT.pivot_table(index=['候補', '窓の種類'], columns='年', values='sum', aggfunc='sum').round(0)
P1['2019〜26合計'] = P1.sum(1); P1['2024〜26合計'] = P1[[c for c in P1.columns if c in (2024, 2025, 2026)]].sum(1); P1['プラスの年'] = (P1[[c for c in P1.columns if isinstance(c, (int, np.integer))]] > 0).sum(1)
P1 = P1.reset_index().sort_values('2024〜26合計', ascending=False)
desc = [
 ['この表について', '窓埋め（61本の作り方）を「確かめる年より前のデータだけ」で選び直した、本当の前向き検証。2026-10-20'],
 ['元の手順', '2026年までのデータで候補を選び、その候補で 2024〜26年を前向き検証したもの（今の61本の決め方。13pt固定で +59,085円、作り直しでの再現は +61,216円：2025・2026年は完全一致、2024年は1本違い）'],
 ['本当の前向き', '確かめる年 C ごとに、ふるい → 5つの評価の形 → 残す → 重なりでまとめる → 案3（上位5本） → 前向きマイナスを外す → 重なり75%・PF1.2 → 同じ向き2本・入り直しなし を、C年より前のデータだけでやり直し、C年を売買'],
 ['コスト', '13pt固定：毎回13pt（昔の値段の安い時期ほど重い）／重さをそろえる：毎回13円（値段に対して同じ割合、前半と後半を公平に比べる）'],
 ['A', '確かめる年に2023年を加える（2023〜26の4年）。2023年の判断は、後半のデータが2022年の1年だけ'],
 ['B', '売買のルール（乖離幅・決済）と優先順位を、直近5年のデータで選ぶ（元は前の全部の年）'],
 ['C', '残す基準：ゆるく＝2つ以上プラス・中央+10円・年8件・改善+10円、厳しく＝4つ以上プラス・中央+30円・年12件・改善+30円（元は3つ・+20円・10件・+20円）'],
 ['D', '指標の条件を付けない候補（定義2×向き2×窓3×売買3＝36本）だけ。候補選びに先のデータを使わないので2019年から確かめられる。各年の初めに、前向き記録の合計がマイナスのものを外し、選ぶ期間の1回平均の順で同じ向き2本'],
 ['偶然の目安', '本物の区分（指標・SQ・祝日の印）を、同じ該当率・日ごとに続きやすいでたらめな区分に置き換え、まったく同じ手順に通したもの（種3つ、重さをそろえるコスト）'],
 ['含めていないもの', 'ATR上位10%系（S2、8本）と逆張りC・B（S4）は作り直していない。元の手順でもこれらは今の61本に入っていない'],
 ['ずれ', '決済の候補に成績がまったく同じものが多く、同点の選び方が元の計算と少しずれる（評価の形の平均が0.1円以内で一致するのは約97%）'],
]
with pd.ExcelWriter(XL, engine='openpyxl') as w:
    pd.DataFrame(desc, columns=['項目', '内容']).to_excel(w, sheet_name='説明', index=False)
    T.round(1).to_excel(w, sheet_name='まとめ', index=False)
    LD.round(0).to_excel(w, sheet_name='D_条件なしだけ', index=False)
    P1.to_excel(w, sheet_name='D_条件なし1本ずつ', index=False)
    for (n, col), t in DT.items():
        t.reset_index().to_excel(w, sheet_name=('分類別_' + ('重さ統一' if n == 'main_flat' else '13pt') + '_' + col)[:31], index=False)
    for k, v in L.items(): v.round(1).to_excel(w, sheet_name=k[:31], index=False)
wb = load_workbook(XL)
for ws in wb:
    for row in ws.iter_rows():
        for c in row: c.font = Font(name='Arial', size=10, bold=c.row == 1)
    for c in ws[1]: c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.freeze_panes = 'A2'
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = 13
ws = wb['説明']; ws.column_dimensions['A'].width = 16; ws.column_dimensions['B'].width = 140
wb['まとめ'].column_dimensions['A'].width = 40; wb['まとめ'].column_dimensions['B'].width = 36
for n in wb.sheetnames:
    if 'D_' in n: wb[n].column_dimensions['A'].width = 36; wb[n].column_dimensions['B'].width = 26
    if '一覧' in n: wb[n].column_dimensions['G'].width = 30
wb.save(XL); print(XL)
