#!/bin/bash
cd /home/claude/work/40nest
(until grep -q '^done' out/log_sums_現行_逆張り.txt; do sleep 20; done; python3 wn_sums.py 先物基準 順張り > out/log_sums_先物基準_順張り.txt 2>&1) &
(until grep -q '^done' out/log_sums_現行_順張り.txt; do sleep 20; done; python3 wn_sums.py 先物基準 逆張り > out/log_sums_先物基準_逆張り.txt 2>&1) &
wait
echo done > out/chain2.done
