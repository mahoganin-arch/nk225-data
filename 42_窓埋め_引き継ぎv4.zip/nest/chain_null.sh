#!/bin/bash
cd /home/claude/work/40nest
for s in 1 2 3; do
 for k in "現行 逆張り" "現行 順張り" "先物基準 逆張り" "先物基準 順張り"; do
  set -- $k
  python3 wn_sums.py $1 $2 $s > out/log_sums_$1_$2_null$s.txt 2>&1
 done
done
echo done > out/chain_null.done
