#!/bin/bash
cd /home/claude/work/40nest
python3 wn_run.py main_flat cost=flat Cs=2023,2024,2025,2026,2027 > out/log_main_flat.txt 2>&1
python3 wn_run.py main_13 cost=13pt Cs=2023,2024,2025,2026 > out/log_main_13.txt 2>&1
python3 wn_run.py B_flat cost=flat scheme=直近5 Cs=2024,2025,2026,2027 > out/log_B_flat.txt 2>&1
python3 wn_run.py C_loose cost=flat plus=2 med=10 ycnt=8 imp=10 Cs=2024,2025,2026,2027 > out/log_C_loose.txt 2>&1
python3 wn_run.py C_strict cost=flat plus=4 med=30 ycnt=12 imp=30 Cs=2024,2025,2026,2027 > out/log_C_strict.txt 2>&1
python3 wn_long.py flat > out/log_long_flat.txt 2>&1
python3 wn_long.py 13pt > out/log_long_13.txt 2>&1
echo done > out/runall.done
