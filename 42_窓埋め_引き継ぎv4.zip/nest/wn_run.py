# 実行：python3 wn_run.py <名前> [key=value ...]
#   例：python3 wn_run.py valid13 cost=13pt Cs=2027     … 元の手順の再現（59,085円になるか）
#       python3 wn_run.py main_flat cost=flat Cs=2024,2025,2026,2027
import sys, pickle, numpy as np, pandas as pd
import wn_pipe as wp
name = sys.argv[1]; kv = dict(a.split('=', 1) for a in sys.argv[2:])
Cs = [int(x) for x in kv.pop('Cs', '2024,2025,2026').split(',')]
conv = dict(cost=str, scheme=str, plus=int, med=float, ycnt=float, imp=float, null=int, N=int, pol=str)
cfg = wp.Cfg(**{k: conv[k](v) for k, v in kv.items()})
res = wp.run(cfg, Cs, tag=name)
out = {}
for C, r in res.items():
    H = r['H']; s = wp.summ(H); yrs = H.groupby('確かめる年').損益.sum().to_dict() if len(H) else {}
    print(name, 'C', C, {k: round(v, 1) if isinstance(v, float) else v for k, v in s.items()}, {k: round(v) for k, v in yrs.items()}, flush=True)
    out[C] = dict(Cd=r['Cd'], PR=r['PR'], H=H, E=r['E'][r['E'].残す])
pickle.dump(dict(cfg=vars(cfg), res=out), open(wp.OUT + '/run_%s.pkl' % name, 'wb'))
