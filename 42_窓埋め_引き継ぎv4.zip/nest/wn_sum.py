# 結果のまとめ：パターンごとの本当の前向き（各 C 年）と元の手順（C=2027）の年別・合計・最大DD
import pickle, glob, os, numpy as np, pandas as pd
import wn_pipe as wp
O = wp.OUT
def load(n):
    f = O + '/run_%s.pkl' % n
    return pickle.load(open(f, 'rb')) if os.path.exists(f) else None
def nested_H(r, Cs): return pd.concat([r['res'][C]['H'] for C in Cs if C in r['res'] and len(r['res'][C]['H'])], ignore_index=True)
def row(name, how, H, yrs):
    s = wp.summ(H); d = dict(パターン=name, 手順=how, **{k: s.get(k) for k in ('件数', '合計', '最大DD', '一回平均', '勝率', 'PF')})
    by = H.groupby('確かめる年').損益.sum() if len(H) else pd.Series(dtype=float)
    for y in yrs: d['%d年' % y] = by.get(y, np.nan)
    d['マイナスの年'] = int((by < 0).sum())
    return d
ROWS = []
YRS = [2023, 2024, 2025, 2026]
PAT = [('基本（コストの重さをそろえる）', 'main_flat'), ('基本（13pt固定）', 'main_13'), ('B 選ぶ期間を直近5年', 'B_flat'), ('C 残す基準をゆるく', 'C_loose'), ('C 残す基準を厳しく', 'C_strict')]
for lab, n in PAT:
    r = load(n)
    if r is None: continue
    if 2027 in r['res']: ROWS.append(row(lab, '元の手順（2026年までのデータで選んだ候補）', r['res'][2027]['H'], YRS))
    elif n == 'main_13':
        v = load('valid13'); ROWS.append(row(lab, '元の手順（2026年までのデータで選んだ候補）', v['res'][2027]['H'], YRS))
    ROWS.append(row(lab, '本当の前向き 2024〜26', nested_H(r, [2024, 2025, 2026]), YRS))
    if 2023 in r['res']: ROWS.append(row('A 確かめる年を長く（' + lab + '）', '本当の前向き 2023〜26', nested_H(r, [2023, 2024, 2025, 2026]), YRS))
for s in (1, 2, 3):
    r = load('null%d' % s)
    if r is None: continue
    if 2027 in r['res']: ROWS.append(row('偶然の目安 種%d' % s, '元の手順', r['res'][2027]['H'], YRS))
    ROWS.append(row('偶然の目安 種%d' % s, '本当の前向き 2024〜26', nested_H(r, [2024, 2025, 2026]), YRS))
T = pd.DataFrame(ROWS)
# パターンD
LD = []
for cost, lab in (('flat', 'コストの重さをそろえる'), ('13pt', '13pt固定')):
    f = O + '/long_%s.pkl' % cost
    if not os.path.exists(f): continue
    L = pickle.load(open(f, 'rb'))
    for pool, H in L['H'].items():
        d = row('D 条件なしだけ（%s）' % lab, '本当の前向き・' + pool, H, list(range(2019, 2027)))
        h3 = H[H.確かめる年 >= 2024]; d['2024〜26合計'] = h3.損益.sum(); LD.append(d)
LD = pd.DataFrame(LD)
pd.to_pickle(dict(T=T, LD=LD), O + '/summary.pkl')
pd.set_option('display.width', 250)
print(T.round(1).to_string(index=False)); print(LD.round(0).to_string(index=False))
