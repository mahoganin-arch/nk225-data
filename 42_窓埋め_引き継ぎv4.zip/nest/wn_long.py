# パターンD：条件なしの長い前向き（2019〜2026）
#   条件なしの候補（定義2 × 向き2 × 窓3 × 売買3（両方・買いのみ・売りのみ）＝36本）は、候補選びに先のデータを使わないので、2019年から本当の前向きを作れる
#   各年 t のルール：t年より前のデータで選んだ乖離幅・決済（WF全期間・周辺）
#   (a) 1本ずつの年ごとの成績
#   (b) 口座：各年の初めに、前向き記録（2019〜t−1年）の合計がマイナスの候補を外し、選ぶ期間の1回平均の順で優先順位を付け、同じ向き2本・入り直しなし
#       候補の集まり：両方＋売りのみ（今の決定）／全部
#   python3 wn_long.py <コスト>
import sys, pickle, numpy as np, pandas as pd
import wn_pipe as wp
from wn_common import *
cost = sys.argv[1]
wp.TR = wp.Trades()
rows = []
for key in KEYS:
    conds = wp.sums(key)['conds']
    for dn in ('両方', '買いのみ', '売りのみ'):
        k = int(np.flatnonzero((conds.売買 == dn) & (conds.指標 == '条件なし'))[0])
        for w in WINS: rows.append(dict(定義=key[0], 向き=key[1], k=k, 窓=w, 出所='NC', 売買=dn, 指標='条件なし', 区分='', 後半のみ=False, 使い方='入る'))
Cd = pd.DataFrame(rows); Cd['id'] = np.arange(len(Cd)); Cd['基本'] = True; Cd['代表'] = True; Cd['グループ'] = Cd.向き + Cd.売買 + Cd.窓
cfg = wp.Cfg(cost=cost)
FR = wp.fwd(Cd, cfg, 2027, 2019)
YT = FR.groupby(['id', '窓の種類', '年']).損益.agg(['sum', 'size']).reset_index()
OUT_ = {}
for pool, dirs in (('両方＋売りのみ', ('両方', '売りのみ')), ('全部', ('両方', '買いのみ', '売りのみ'))):
    Hs = []
    for t in range(2019, 2027):
        SS = wp.sel_stats(Cd, cfg, t); past = FR[(FR.年 < t)]; FS = past.groupby(['id', '窓の種類']).損益.sum()
        x = SS[SS.id.isin(Cd.id[Cd.売買.isin(dirs)]) & (SS.選ぶ件数 >= 15)].copy()
        x = x[[FS.get((i, k), 1.0) > 0 for i, k in zip(x.id, x.窓の種類)]].sort_values('選ぶ平均', ascending=False, kind='stable')
        pr = {(i, k): p for p, (i, k) in enumerate(zip(x.id, x.窓の種類))}
        H = wp.simulate(Cd, cfg, t, pr); Hs.append(H)
        print(pool, t, len(pr), round(H.損益.sum()) if len(H) else 0, flush=True)
    H = pd.concat(Hs, ignore_index=True); OUT_[pool] = H
    print(pool, wp.summ(H), H.groupby('確かめる年').損益.sum().round().to_dict(), flush=True)
pickle.dump(dict(Cd=Cd, YT=YT, H=OUT_), open(OUT + '/long_%s.pkl' % cost, 'wb'))
