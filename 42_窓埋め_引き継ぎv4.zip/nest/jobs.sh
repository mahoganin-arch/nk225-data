#!/bin/bash
# 足りない偶然の目安の計算を、同時に2つまでで順に実行する（途中のものは再開、終わったものは飛ばす）
cd /home/claude/work/40nest
run() { python3 wn_sums.py $1 $2 $3 > out/log_sums_$1_$2_null$3.txt.run 2>&1; }
# 今動いている2つ（null2・null3 の 現行 順張り）が終わるのを待ってから
while pgrep -f "wn_sums.py" > /dev/null; do sleep 30; done
(run 先物基準 逆張り 1; run 先物基準 順張り 1; run 現行 逆張り 2; run 先物基準 逆張り 2) &
(run 現行 逆張り 3; run 先物基準 逆張り 3; run 先物基準 順張り 3; run 先物基準 順張り 2) &
wait
echo done > out/jobs.done
