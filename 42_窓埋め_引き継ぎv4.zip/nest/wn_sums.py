# 条件ごとに「年ごとの損益の和」を作り、選ぶ期間ごとに乖離幅・決済を選び（単点／周辺、s10eval と同じ）、選んだ点の年ごとの成績を保存する
#   python3 wn_sums.py <定義> <向き> [null種]
#   出力：out/sums_<定義>_<向き>[_null種].pkl
#     conds：条件の一覧（出所, 売買, 指標, 区分, 後半のみ, 使い方）
#     R[(コスト, 窓, 選び方, 選ぶ期間)] = dict(q, e, ys, yc)  q,e：選んだ乖離幅の番号・決済の番号（−1＝選べない）
#        ys/yc：選んだ点の、窓の種類ごと・年ごとの損益の和と件数 (K, 2, 10)
import os, sys, time, numpy as np, pandas as pd, scipy.sparse as sp
from wn_common import *
key = (sys.argv[1], sys.argv[2]); SEED = int(sys.argv[3]) if len(sys.argv) > 3 else None
SUF = '' if SEED is None else '_null%d' % SEED
COSTS = ['flat', '13pt'] if SEED is None else ['flat']
import os as _os
if _os.path.exists(OUT + '/sums_%s_%s%s.pkl' % (key[0], key[1], SUF)) and not _os.environ.get('LIMIT'): print('既にある'); sys.exit(0)
D = load_ds(key)
en = D['en']; ok = D['ok']; yr = D['yr']; F = D['F']
scr = pd.read_pickle(OUT + '/scr%s.pkl' % SUF); scr = scr[(scr['定義'] == key[0]) & (scr['向き'] == key[1]) & scr['コスト'].isin(COSTS)]
if SEED is not None:
    NB = pd.read_pickle(OUT + '/nullbins_%d_%s%s.pkl' % (SEED, *key)); n = len(en)
    BINS = {k: np.unpackbits(v)[:n].astype(bool) for k, v in NB.items()}
else:
    BINS = {**D['ba'], **D['bl']}
# ---- 条件の一覧
U = scr[['出所', '売買', '指標', '区分', '後半のみ', '使い方']].drop_duplicates()
rows = [('NC', '両方', '条件なし', '', False, '入る'), ('NC', '買いのみ', '条件なし', '', False, '入る'), ('NC', '売りのみ', '条件なし', '', False, '入る')]
for f in FLAGS:
    for u in ('入る', '避ける'): rows.append(('FL', '両方', f, '印あり', False, u))
rows += [tuple(r) for r in U.itertuples(index=False)]
conds = pd.DataFrame(rows, columns=['出所', '売買', '指標', '区分', '後半のみ', '使い方']).drop_duplicates(['売買', '指標', '区分', '後半のみ', '使い方']).reset_index(drop=True)
# 「両方」と方向別で同じ区分・使い方は、マスクが違う（方向で絞る）ので別の条件。S10 と S19 で同じ（両方）になることは無い
if SEED is not None:
    # 偶然の目安：印（SQ・祝日など）も同じ該当率のでたらめな区分に置き換える
    from wn_screen import null_bins
    FLB = null_bins(D, {(f, '印あり'): D['FL'][f].values.astype(bool) for f in FLAGS}, SEED + 200)
def mask(r):
    if r.出所 == 'NC': m = np.ones(len(en), bool)
    elif r.出所 == 'FL': m = FLB[(r.指標, '印あり')] if SEED is not None else D['FL'][r.指標].values.astype(bool)
    else: m = BINS[(r.指標, r.区分)]
    if r.使い方 == '避ける': m = ~m
    if r.売買 == '買いのみ': m = m & D['buy']
    elif r.売買 == '売りのみ': m = m & ~D['buy']
    if r.後半のみ: m = m & ~np.isnan(F[r.指標].values.astype(float))
    return m & ok
import os
if os.environ.get('LIMIT'): conds = conds.iloc[:int(os.environ['LIMIT'])]; SUF += '_test'
print(key, '条件', len(conds), flush=True)
# ---- 乖離幅ごとの損益（控除前）を読み込んでおく
J = len(D['XP']); NE = 1944
GC = {}; YB = {}; C13 = {}; NEGF = {}; NEG13 = {}
c13all = SP * P / D['px']
for kk in (0, 1):
    for j in range(J):
        r = D['IDX'][(kk, j)]
        Yr = np.asarray(D['Y'][r]); G = Yr.astype(np.float32) / np.float32(100) * np.float32(P)
        GC[(kk, j)] = Yr; C13[(kk, j)] = c13all[r].astype(np.float32)
        YB[(kk, j)] = np.searchsorted(yr[r], YEARS + [2027])
        NEGF[(kk, j)] = sp.csr_matrix((G < WORST + SP).astype(np.float32))
        NEG13[(kk, j)] = sp.csr_matrix((G < WORST + C13[(kk, j)][:, None]).astype(np.float32))
        del G
print('読み込み', sum(g.nbytes for g in GC.values()) / 1e9, 'GB', flush=True)
# 選ぶ期間（すべて連続した年の範囲）
SR = {s: (YI[ys[0]], YI[ys[-1]] + 1) for s, ys in SELS.items()}
BK = 40; R = {}
for c in COSTS:
    for w in WINS:
        for m in ('単点', '周辺'):
            for s in SELK: R[(c, w, m, s)] = dict(q=[], e=[], ys=[], yc=[])
t0 = time.time()
CKP = OUT + '/sums_%s_%s%s.part.pkl' % (key[0], key[1], SUF); start = 0
if os.path.exists(CKP):
    R, start = pd.read_pickle(CKP); print('再開', start, flush=True)
for b0 in range(start, len(conds), BK):
    sub = conds.iloc[b0:b0 + BK]; K = len(sub)
    M = np.array([mask(r) for r in sub.itertuples()])
    S = np.zeros((K, 2, J, 10, NE), np.float64); CN = np.zeros((K, 2, J, 10), np.float64); CP = np.zeros((K, 2, J, 10), np.float64)
    NGf = np.zeros((K, 2, J, 10, NE), np.float32); NG13 = np.zeros_like(NGf) if '13pt' in COSTS else None
    for kk in (0, 1):
        for j in range(J):
            r = D['IDX'][(kk, j)]; Mk = M[:, r].astype(np.float64); yb = YB[(kk, j)]; G = GC[(kk, j)]
            for yi in range(10):
                a, b = yb[yi], yb[yi + 1]
                if b <= a: continue
                Ma = Mk[:, a:b]
                if not Ma.any(): continue
                S[:, kk, j, yi] = Ma @ (G[a:b].astype(np.float32) / np.float32(100) * np.float32(P)).astype(np.float64); CN[:, kk, j, yi] = Ma.sum(1); CP[:, kk, j, yi] = Ma @ C13[(kk, j)][a:b].astype(np.float64)
                NGf[:, kk, j, yi] = (NEGF[(kk, j)][a:b].T @ Ma.T.astype(np.float32)).T
                if NG13 is not None: NG13[:, kk, j, yi] = (NEG13[(kk, j)][a:b].T @ Ma.T.astype(np.float32)).T
    for c in COSTS:
        Sc = S - (CP if c == '13pt' else SP * CN)[..., None]; NG = NG13 if c == '13pt' else NGf
        for w, kks in WINS.items():
            Sw = Sc[:, kks].sum(1); Cw = CN[:, kks].sum(1); Nw = NG[:, kks].sum(1)        # (K, J, 10, NE)
            cS = np.concatenate([np.zeros_like(Sw[:, :, :1]), np.cumsum(Sw, 2)], 2); cC = np.concatenate([np.zeros_like(Cw[:, :, :1]), np.cumsum(Cw, 2)], 2)
            cN = np.concatenate([np.zeros_like(Nw[:, :, :1]), np.cumsum(Nw, 2)], 2)
            for s in SELK:
                a, b = SR[s]
                Ssel = cS[:, :, b] - cS[:, :, a]; Csel = cC[:, :, b] - cC[:, :, a]; Nsel = cN[:, :, b] - cN[:, :, a]
                okc = Csel >= MINSEL
                with np.errstate(all='ignore'): Mn = np.where(okc[..., None], Ssel / np.maximum(Csel, 1)[..., None], np.nan).astype(np.float32)
                okw = Nsel < 0.5
                SMc = nbr_mean_k(Mn)
                for meth, score in (('単点', Mn), ('周辺', SMc)):
                    sc = np.where(np.isnan(Mn), -np.inf, score); sc2 = np.where(okw, sc, -np.inf)
                    has2 = np.isfinite(sc2.reshape(K, -1)).any(1); use = np.where(has2[:, None, None], sc2, sc).reshape(K, -1)
                    has = okc.any(1)
                    fl = np.argmax(use, 1); q, e = np.divmod(fl, NE); q = np.where(has, q, -1); e = np.where(has, e, -1)
                    qq = np.maximum(q, 0); ee = np.maximum(e, 0); ar = np.arange(K)
                    ys = Sc[ar, :, qq, :, ee]; yc = CN[ar, :, qq, :]              # (K, 2, 10)
                    ys[~has] = 0; yc[~has] = 0
                    d = R[(c, w, meth, s)]; d['q'].append(q.astype(np.int16)); d['e'].append(e.astype(np.int16)); d['ys'].append(ys.astype(np.float64)); d['yc'].append(yc.astype(np.float32))
    del S, NGf, NG13
    print(key, b0 + K, len(conds), round(time.time() - t0), 's', flush=True)
    if (b0 // BK) % 10 == 9: pd.to_pickle((R, b0 + K), CKP)
for k, d in R.items():
    for f in ('q', 'e', 'ys', 'yc'): d[f] = np.concatenate(d[f])
pd.to_pickle(dict(conds=conds, R=R), OUT + '/sums_%s_%s%s.pkl' % (key[0], key[1], SUF))
print('done', round(time.time() - t0), flush=True)
