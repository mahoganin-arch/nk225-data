import pickle, numpy as np, pandas as pd
import wn_pipe as wp
O = wp.OUT
out = {}
for n in ('main_flat', 'main_13'):
    r = pickle.load(open(O + '/run_%s.pkl' % n, 'rb'))['res']
    rows = []
    for C in (2024, 2025, 2026):
        H = r[C]['H'].copy(); Cd = r[C]['Cd'].set_index('id')
        H['分類'] = [('%s・%s・%s' % (Cd.loc[i, '向き'], Cd.loc[i, '売買'], k)) for i, k in zip(H.id, H.窓の種類)]
        H['条件'] = np.where(Cd.loc[H.id, '基本'].values | (Cd.loc[H.id, '指標'].values == '条件なし'), '条件なし', '条件あり')
        H['定義'] = Cd.loc[H.id, '定義'].values
        rows.append(H)
    H = pd.concat(rows)
    for col in ('分類', '条件', '定義'):
        t = H.pivot_table(index=col, columns='確かめる年', values='損益', aggfunc='sum').round(0); t['合計'] = t.sum(1); t['件数'] = H.groupby(col).size()
        print(n, col); print(t.to_string()); out[(n, col)] = t
    # コスト感度：1回あたり +7円（20pt相当）・+17円（30pt相当）
    for add in (7, 17): print(n, 'コスト +%d円' % add, round(H.損益.sum() - add * len(H)))
    # 上位10日の割合
    d = H.groupby('セッション').損益.sum().sort_values(ascending=False); print(n, '上位10窓の割合', round(d.head(10).sum() / H.損益.sum() * 100), '%')
# 今の61本（元の手順2026）と、本当の前向き2026の一覧の重なり
v = pickle.load(open(O + '/run_valid13.pkl', 'rb'))['res'][2027]; Cv = v['Cd'].set_index('id')
key = lambda Cd, i, k: (Cd.loc[i, '定義'], Cd.loc[i, '向き'], Cd.loc[i, '売買'], Cd.loc[i, '窓'], Cd.loc[i, '指標'], Cd.loc[i, '区分'], Cd.loc[i, '使い方'], k)
now = set(key(Cv, i, k) for i, k in v['PR'][2026])
for n in ('main_flat', 'main_13'):
    r = pickle.load(open(O + '/run_%s.pkl' % n, 'rb'))['res']
    for C in (2024, 2025, 2026):
        Cd = r[C]['Cd'].set_index('id'); s = set(key(Cd, i, k) for i, k in r[C]['PR'][C])
        print(n, C, '本当の前向きで使う', len(s), '今の一覧（元の手順2026）', len(now), '重なり', len(s & now))
pd.to_pickle(out, O + '/detail.pkl')
