#!/bin/bash
cd /home/claude/work/40nest
for k in "先物基準 順張り" "先物基準 逆張り" "現行 逆張り" "現行 順張り"; do
  set -- $k
  python3 wn_sums.py $1 $2 3 > out/log_sums_$1_$2_null3.txt 2>&1
done
echo done > out/chain_null3.done
