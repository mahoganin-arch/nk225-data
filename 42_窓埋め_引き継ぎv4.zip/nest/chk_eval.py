# 確認：C=2027・13pt の評価が、元の S10eval（両方）・S19eval（方向別）と一致するか
import sys, numpy as np, pandas as pd
import wn_pipe as wp
from wn_common import *
key = (sys.argv[1], sys.argv[2])
import os
S = pd.read_pickle(OUT + '/sums_%s_%s%s.pkl' % (key[0], key[1], os.environ.get('SFX', ''))); conds = S['conds']; R = S['R']
FN = {'S1 前半→後半': 'S1 前半→後半', 'S2 22-23→24-26': 'S2 22-23→24-26', 'WF後半': 'WF後半', 'WF全期間': 'WF全期間', 'WF直近3年': 'WF直近3年'}
def mine(k, w, meth, late):
    out = {}
    for fn, splits in forms(2027, 2024 if late else 0).items():
        ts = tc = 0.0; pk = []
        for s, te in splits:
            d = R[('13pt', w, meth, s)]
            if d['q'][k] < 0: continue
            ti = [YI[y] for y in te]; ts += d['ys'][k][WINS[w]][:, ti].sum(); tc += d['yc'][k][WINS[w]][:, ti].sum(); pk.append((int(d['q'][k]), int(d['e'][k])))
        out[fn] = (ts / tc if tc else np.nan, tc, pk)
    return out
XP = None
O = pd.read_pickle(W + '/S10eval_%s_%s.pkl' % key)
O19 = pd.read_pickle(W + '/S19eval_%s_%s.pkl' % key)
ck = {tuple(r): i for i, r in enumerate(conds[['売買', '指標', '区分', '後半のみ', '使い方']].itertuples(index=False))}
import re
from common6 import CB
CBI = {(round(a, 3), round(b, 3), int(c)): i for i, (a, b, c) in enumerate(CB)}
XPs = [0.03, 0.04, 0.05, 0.06, 0.075, 0.09, 0.1, 0.11, 0.125, 0.14, 0.15, 0.175, 0.2, 0.225, 0.25, 0.275, 0.3, 0.35, 0.4, 0.45, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.2, 1.5]
def parse(s): return [(XPs.index(float(x)), CBI[(round(float(a), 3), round(float(b), 3), int(c))]) for x, a, b, c in re.findall(r'([\d.]+)%\(([\d.]+), ([\d.]+), (\d+)\)', s)]
res = []
for src, OO in (('S10', O), ('S19', O19)):
    for r in OO.itertuples():
        ind = r.指標
        if ind.startswith('条件なし'):
            if ind == '条件なし(2024-)': continue
            kk = ('両方' if src == 'S10' else r.売買, '条件なし', '', False, '入る')
        else: kk = ('両方' if src == 'S10' else r.売買, ind, r.区分, bool(r.後半のみ), r.使い方)
        if kk not in ck: continue
        m = mine(ck[kk], r.窓, r.選び方, bool(r.後半のみ))[r.評価]
        pk_o = parse(r.選ばれた点)
        res.append(dict(src=src, 平均差=abs((m[0] if m[1] else np.nan) - r.平均) if r.件数 else (0 if not m[1] else 99), 件数差=m[1] - r.件数, 点一致=pk_o == m[2]))
X = pd.DataFrame(res)
print(X.groupby('src').agg(n=('src', 'size'), 点一致=('点一致', 'mean'), 平均差0_1以下=('平均差', lambda v: (v <= .1).mean()), 件数一致=('件数差', lambda v: (v == 0).mean())))
print(X[X.get('一致') == '条件なし'].shape if '一致' in X else 0)
