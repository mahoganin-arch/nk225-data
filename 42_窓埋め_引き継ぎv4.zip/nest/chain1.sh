#!/bin/bash
cd /home/claude/work/40nest
while pgrep -f "wn_sums.py 現行 逆張り" > /dev/null; do sleep 20; done
for k in "現行 順張り" "先物基準 逆張り" "先物基準 順張り"; do
  set -- $k
  python3 wn_sums.py $1 $2 > out/log_sums_$1_$2.txt 2>&1
done
echo done > out/chain1.done
