#!/bin/bash
# 窓埋めのエンジン・指標の作り直し（新しいチャット用。まだ通しで動かしていないので、エラーが出たら直すこと）
#   前提：W/01/code（01→10〜28番→42 の順に上書き）、W/data/{c1,c5,f1,f5}.csv、GitHub の nk225-data を REPO に取得済み
set -e
W=/home/claude/work; C=$W/01/code; D=$W/data; REPO=/home/claude/mahoganin-arch/nk225-data
cd $W; mkdir -p OUT2 R T F6W
python3 $C/eng2.py $C $D/f5.csv $D/c5.csv $W/OUT2                       # 窓の一覧（OUT2/evt.pkl）
python3 $C/cal.py  $C $D/f5.csv $W/OUT2/cal.pkl                          # 休場日カレンダー
python3 $C/eng5.py  $C $D/f5.csv $D/c5.csv $D/c1.csv $W/R                # 現行・逆張り
python3 $C/eng5f.py $C $D/f5.csv $D/c5.csv $D/c1.csv $W/T                # 現行・順張り
python3 $C/eng6.py  $C $D/f5.csv $D/f1.csv $D/c5.csv $D/c1.csv $W/F6W    # 先物基準（F6W/R6, F6W/T6）
for d in R T F6W/R6 F6W/T6; do
  python3 $C/feat6.py $C $D/c5.csv $D/c1.csv $W/OUT2/evt.pkl $W/$d
  python3 $C/feat7.py $C $D $REPO $W/OUT2/evt.pkl $W/OUT2/cal.pkl $W/$d
done
python3 - <<'PY'
# エントリーの足の番号（gk）・エントリー価格（entp）・1,944決済の平均（控除前、mnet_gross）を別ファイルに
import numpy as np, pandas as pd
P = 68800; W = '/home/claude/work'
for d in ('R', 'T', 'F6W/R6', 'F6W/T6'):
    p = W + '/' + d; en = pd.read_pickle(p + '/en.pkl'); ev = pd.read_pickle(p + '/evt.pkl')
    if 'gk' in en: np.save(p + '/gk.npy', en.gk.values.astype(np.int64))
    else: print('注意：', d, 'の en.pkl に gk が無い（エンジンの保存部分を確認）')
    ep = en.entp_.values if 'entp_' in en else (en.ent.values if 'ent' in en else None)
    if ep is not None: np.save(p + '/entp.npy', ep.astype(float))
    else: print('注意：', d, 'に entp が無い')
    Y = np.load(p + '/Y.npy', mmap_mode='r'); MN = np.zeros(len(en), np.float32)
    for a in range(0, len(en), 5000): MN[a:a + 5000] = np.asarray(Y[a:a + 5000], np.float32).mean(1) / 100 * P
    np.save(p + '/mnet_gross.npy', MN); print(d, len(en))
PY
echo REBUILD_DONE
