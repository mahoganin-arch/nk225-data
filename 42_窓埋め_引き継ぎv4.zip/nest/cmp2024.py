import sys, pickle, pandas as pd, numpy as np
sys_path_fix = __import__('sys').path.insert(0, '/home/claude/work/08/an')
sys.argv=[sys.argv[0]]
src = open('/home/claude/work/08/an/s25narrow.py').read(); exec(src[:src.index("DIRS = ('両方', '売りのみ'); PR = []")])
L = narrow(union_list(rank_old(2024), rank_rf(2024), 5, ('両方', '売りのみ')), fwd_stats(2024), .75, 1.2)
orig = [(C.loc[i, '出所'], C.loc[i, '定義'], C.loc[i, '向き'], C.loc[i, '売買'], C.loc[i, '窓'], C.loc[i, '指標'], C.loc[i, '区分'], C.loc[i, '使い方'], k[0]) for k, rows in L.items() for (i, *_ ) in rows]
r = pickle.load(open('/home/claude/work/40nest/out/run_valid13.pkl', 'rb'))['res'][2027]; Cd = r['Cd'].set_index('id')
mine = [(Cd.loc[i, '出所'], Cd.loc[i, '定義'], Cd.loc[i, '向き'], Cd.loc[i, '売買'], Cd.loc[i, '窓'], Cd.loc[i, '指標'], Cd.loc[i, '区分'], Cd.loc[i, '使い方'], k) for (i, k) in r['PR'][2024]]
f = lambda t: (t[1], t[2], t[3] if t[3] != '両方' else '両方', t[4], t[5], t[6] if t[5] != '条件なし' else '', t[8])
so = set(map(f, orig)); sm = set(map(f, mine))
print('元', len(so), '作り直し', len(sm), '共通', len(so & sm))
print('元だけ'); [print(' ', x) for x in sorted(so - sm)]
print('作り直しだけ'); [print(' ', x) for x in sorted(sm - so)]
