# 昼の窓（現物の昼休み 11:30〜12:30）の総当たり。先物・CFD は昼休みも動く
#   定義A「CFD型」（夜・朝の現行に相当）：基準＝11:30 直前の CFD の足の終値。11:30 から、基準±x% に先に届いた側で入る（届いた足で、窓をあけたら始値）
#      12:30（現物の後場寄り）の後に CFD が基準に戻ったら、その窓では以後入らない
#   定義B「先物型」（先物基準に相当）：基準＝11:30 直前の先物の足の終値。12:30 から判定。12:30 の足の始値で既に x% 以上離れていたら、その時刻の CFD の足の始値で入る
#      12:30 の後に先物が x% に届いたら、その先物の足が終わった時刻の CFD の足の始値で入る。届く前に（同じ足も）基準まで戻ったら入らない
#   利確・損切り：逆張り＝利確 窓までの距離×FR、損切り 乖離幅×SK（0=なし）／順張り＝損切り 基準方向へ FR、利確 乖離幅×SK（0=なし）。同じ足で両方ならその戦略に不利な側
#   時間切れ0＝日中の引け（引け直前の足の終値）
#   使い方: python eng7l.py <codeフォルダ> 先物5分 先物1分 CFD5分 CFD1分 出力フォルダ
import sys, os, pandas as pd, numpy as np
sys.path.insert(0, sys.argv[1]); import ld
U = '2026-10-09'
f5 = ld.bars(sys.argv[2], until=U); f1 = ld.bars(sys.argv[3], until=U); c5 = ld.bars(sys.argv[4], until=U); c1 = ld.bars(sys.argv[5], until=U); OUT = sys.argv[6]
f1 = f1[f1.t >= pd.Timestamp('2023-10-16 08:45', tz='Asia/Tokyo')]; fm1 = f1.m.iloc[0]
fx = pd.concat([f5[f5.m < fm1], f1], ignore_index=True); fx['tf'] = np.where(fx.m < fm1, 5, 1)
cm1 = c1.m.iloc[0]; c = pd.concat([c5[c5.m + 5 <= cm1], c1], ignore_index=True); c['tf'] = np.where(c.m < cm1, 5, 1)
ro_all = (c.m.diff() > 30).values; cm = c.m.values; co = c.open.values; ch = c.high.values; cl = c.low.values; cc = c.close.values; ctf = c.tf.values
fm = fx.m.values; fo = fx.open.values; fh = fx.high.values; fl = fx.low.values; fc = fx.close.values; ftf = fx.tf.values
f = f5.copy(); f['sid'] = (f.m.diff() > 15).cumsum()
s = f.groupby('sid').agg(m0=('m', 'first'), m1=('m', 'last'), n=('m', 'size'), t0=('t', 'first')); lh = f.groupby('sid').t.last().dt.strftime('%H:%M')
s['end'] = np.where(lh.isin(['15:15', '15:45', '05:30', '06:00']), s.m1, s.m1 + 5); s['kind'] = np.where(s.t0.dt.hour.between(8, 9), 'D', 'N'); s = s.reset_index(drop=True)
XP = np.array([.03, .04, .05, .06, .075, .09, .1, .11, .125, .14, .15, .175, .2, .225, .25, .275, .3, .35, .4, .45, .5, .6, .7, .8, .9, 1.0, 1.2, 1.5])
FR = np.array([.1, .2, .3, .4, .5, .6, .7, .8, .9, 1.0, 1.25, 1.5]); SK = np.array([0, .1, .2, .3, .4, .5, .6, .75, .9, 1, 1.25, 1.5, 2, 2.5, 3, 4, 5, 6])
TM = np.array([0, 15, 30, 60, 90, 120, 180, 240, 360]); BIG = 10**9
def first_ge(a, lv):
    i = np.searchsorted(a, lv); return np.where(i >= len(a), BIG, i)
def exits(H, L, O, C, M, RO, ent, s0, up, w, dist, n):
    """逆張りの向きで考える（窓が上 → 売り）。戻り値：逆張りの (損益%, 決済コード)、順張りの (損益%, 決済コード)"""
    Hd = np.where(RO, C, H); Ld = np.where(RO, C, L); Os = np.where(RO, C, O)
    adv = np.maximum.accumulate((Hd[s0:] - ent) if up else (ent - Ld[s0:])); fav = np.maximum.accumulate((ent - Ld[s0:]) if up else (Hd[s0:] - ent))
    si = first_ge(adv, SK * w) + s0; si = np.where((si >= BIG) | (SK == 0), BIG, si); ti = first_ge(fav, FR * dist) + s0
    lvS = ent + SK * w if up else ent - SK * w; lvT = ent - FR * dist if up else ent + FR * dist
    sic = np.minimum(si, n - 1); tic = np.minimum(ti, n - 1)
    pS = np.where(si == s0, lvS, np.maximum(lvS, Os[sic]) if up else np.minimum(lvS, Os[sic])); pT = np.where(ti == s0, lvT, np.minimum(lvT, Os[tic]) if up else np.maximum(lvT, Os[tic]))
    tt = np.minimum(np.array([n] + [int(np.searchsorted(M, M[0] + tm)) for tm in TM[1:]]), n); pt = np.where(tt < n, O[np.minimum(tt, n - 1)], C[-1])
    SI = si[None, :, None]; TI = ti[:, None, None]; TT = tt[None, None, :]; sgn = -1 if up else 1; outs = []
    for rev in (True, False):
        if rev: a_ = (SI <= TI) & (SI < TT); b_ = (~a_) & (TI < TT); px = np.where(a_, pS[None, :, None], np.where(b_, pT[:, None, None], pt[None, None, :])); typ = np.where(a_, 0, np.where(b_, 1, np.where(TT < n, 2, 3))); idx = np.where(a_, SI, np.where(b_, TI, np.where(TT < n, TT, n - 1)))
        else: a_ = (TI <= SI) & (TI < TT); b_ = (~a_) & (SI < TT); px = np.where(a_, pT[:, None, None], np.where(b_, pS[None, :, None], pt[None, None, :])); typ = np.where(a_, 1, np.where(b_, 0, np.where(TT < n, 2, 3))); idx = np.where(a_, TI, np.where(b_, SI, np.where(TT < n, TT, n - 1)))
        idx = np.broadcast_to(idx, px.shape); typ = np.broadcast_to(typ, px.shape)
        outs.append((((sgn if rev else -sgn) * (px - ent) / ent * 100).astype(np.float16).ravel(), (idx * 4 + typ).astype(np.int16).ravel()))
    return outs
R = {k: dict(Y=[], X=[], E=[]) for k in ('A_R', 'A_T', 'B_R', 'B_T')}; EV = []
for i in range(len(s)):
    q = s.iloc[i]
    if q.kind != 'D' or q.n < 24: continue
    day = q.t0.tz_convert('Asia/Tokyo').normalize(); mb = int((day + pd.Timedelta(hours=11, minutes=30)).timestamp() // 60); mo = mb + 60
    if not (q.m0 < mb - 60 and q.end > mo + 60): continue
    # CFD の基準：11:30 より前の最後の足（15分以内）
    j = np.searchsorted(cm, mb) - 1; jf = np.searchsorted(fm, mb) - 1
    if j < 0 or mb - cm[j] > 15 or jf < 0 or mb - fm[jf] > 10: continue
    B = cc[j]; Bf = fc[jf]
    a = j + 1; e = np.searchsorted(cm, q.end)
    if e - a < 12: continue
    ko = np.searchsorted(cm, mo) - a
    H = ch[a:e]; L = cl[a:e]; O = co[a:e]; C = cc[a:e]; M = cm[a:e]; RO = ro_all[a:e]; n = e - a
    EV.append((i, q.t0, 'L', False, B, mb, mo, Bf)); evn = len(EV) - 1
    # ---- 定義A（CFD型）
    g = O[ko] - B if 0 <= ko < n else 0
    zc = np.nonzero(L[ko:] <= B)[0] if g > 0 else (np.nonzero(H[ko:] >= B)[0] if g < 0 else np.array([0])); ci = zc[0] + ko if len(zc) else BIG
    Hd = np.where(RO, C, H); Ld = np.where(RO, C, L); rmaxH = np.maximum.accumulate(Hd); rminL = np.minimum.accumulate(Ld)
    for x in XP:
        w = B * x / 100; iu = np.searchsorted(rmaxH, B + w); idn = np.searchsorted(-rminL, -(B - w))
        iu = iu if iu < n else BIG; idn = idn if idn < n else BIG
        if iu == idn: continue
        k = min(iu, idn); up = iu < idn
        if k >= ko and k >= ci: continue
        reo = bool(RO[k]); ent = C[k] if reo else (max(B + w, O[k]) if up else min(B - w, O[k])); s0 = 1 if reo else 0
        if k + s0 >= n - 1: continue
        outs = exits(H[k:], L[k:], O[k:], C[k:], M[k:], RO[k:].copy(), ent, s0, up, w, abs(ent - B), n - k)
        for key, (y, xcode) in zip(('A_R', 'A_T'), outs):
            R[key]['Y'].append(y); R[key]['X'].append(xcode); R[key]['E'].append((evn, x, M[k], -1 if up else 1, k < ko, reo, ent, abs(ent - B) / B * 100, a + k))
    # ---- 定義B（先物型）
    fa = np.searchsorted(fm, mo); fb = np.searchsorted(fm, q.end)
    if fb - fa < 6 or fm[fa] - mo > 5: continue
    gB = fo[fa] - Bf
    if gB == 0: continue
    upB = gB > 0; gp = abs(gB) / Bf * 100
    FH = fh[fa:fb]; FL = fl[fa:fb]; FM = fm[fa:fb]; FT = ftf[fa:fb]
    fz = np.nonzero(FL <= Bf)[0] if upB else np.nonzero(FH >= Bf)[0]; fi = fz[0] if len(fz) else BIG
    rmax = np.maximum.accumulate(FH); rmin = np.minimum.accumulate(FL)
    for x in XP:
        Lx = Bf * (1 + x / 100) if upB else Bf * (1 - x / 100)
        if gp >= x: r = -1; tm_ent = fm[fa]; fdist = gp
        else:
            r = np.searchsorted(rmax, Lx) if upB else np.searchsorted(-rmin, -Lx)
            if r >= len(FH) or fi <= r: continue
            tm_ent = FM[r] + FT[r]; fdist = x
        k = np.searchsorted(cm, tm_ent)
        if k >= e - 1 or cm[k] - tm_ent > 5: continue
        H2 = ch[k:e]; L2 = cl[k:e]; O2 = co[k:e]; C2 = cc[k:e]; M2 = cm[k:e]; RO2 = ro_all[k:e].copy(); n2 = e - k
        reo = bool(RO2[0]); ent = C2[0] if reo else O2[0]; s0 = 1 if reo else 0
        if s0 >= n2 - 1: continue
        outs = exits(H2, L2, O2, C2, M2, RO2, ent, s0, upB, ent * x / 100, ent * fdist / 100, n2)
        for key, (y, xcode) in zip(('B_R', 'B_T'), outs):
            R[key]['Y'].append(y); R[key]['X'].append(xcode); R[key]['E'].append((evn, x, M2[0], -1 if upB else 1, r < 0, reo, ent, fdist, k))
ev = pd.DataFrame(EV, columns=['i', 't0', 'kind', 'long', 'B', 'pend', 'qm0', 'Bf'])
for key, r in R.items():
    d = OUT + '/' + key; os.makedirs(d, exist_ok=True)
    en = pd.DataFrame(r['E'], columns=['ev', 'x', 'm', 'd', 'closed', 'reo', 'ent', 'fdist', 'gk'])
    np.save(d + '/Y.npy', np.vstack(r['Y'])); np.save(d + '/EX.npy', np.vstack(r['X'])); en.to_pickle(d + '/en.pkl'); ev.to_pickle(d + '/evt.pkl')
    np.save(d + '/gk.npy', en.gk.values); np.save(d + '/entp.npy', en.ent.values)
    print(key, 'entries', len(en))
print('windows', len(ev))
