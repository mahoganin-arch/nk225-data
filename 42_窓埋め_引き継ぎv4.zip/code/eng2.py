# 窓埋め逆張りの総当たり（v2：先物5分足でセッション判定、損切り1倍未満を追加）
import sys, collections, pandas as pd, numpy as np
sys.path.insert(0, sys.argv[1]); import ld
f = ld.bars(sys.argv[2], until='2026-10-09'); c = ld.bars(sys.argv[3], until='2026-10-09')
cm = c.m.values; co = c.open.values; ch = c.high.values; cl = c.low.values; cc = c.close.values
f['sid'] = (f.m.diff() > 15).cumsum()
s = f.groupby('sid').agg(m0=('m', 'first'), m1=('m', 'last'), n=('m', 'size'), t0=('t', 'first'), fo=('open', 'first'), fc=('close', 'last'))
lh = f.groupby('sid').t.last().dt.strftime('%H:%M')
s['end'] = np.where(lh.isin(['15:15', '15:45', '05:30', '06:00']), s.m1, s.m1 + 5)
s['kind'] = np.where(s.t0.dt.hour.between(8, 9), 'D', 'N'); s = s.reset_index(drop=True)
XP = [.05, .1, .15, .2, .3, .4, .6, .8, 1.0, 1.5]
SK = [0, .25, .5, .75, 1, 2, 3, 4, 6]; TM = [0, 60, 120, 240]; BIG = 10**9
N = 4_500_000
R = dict(eid=np.zeros(N, np.int32), pp=np.zeros(N, np.float32), tg=np.zeros(N, np.int8), sk=np.zeros(N, np.float32), tm=np.zeros(N, np.int16), res=np.zeros(N, np.int8), hold=np.zeros(N, np.int16))
E = []; EV = []; nr = 0; amb = 0; rng = collections.deque(maxlen=20)
for i in range(1, len(s)):
    p, q = s.iloc[i - 1], s.iloc[i]
    j = np.searchsorted(cm, p.end) - 1
    ok = p.n >= 24 and q.n >= 24 and p.kind != q.kind and j >= 0 and p.end - cm[j] <= 15
    if ok:
        a = j + 1; e = np.searchsorted(cm, q.end); ko = np.searchsorted(cm, q.m0) - a
        ok = e - a >= 6 and 0 <= ko < e - a
    a0 = np.searchsorted(cm, p.m0)
    if ok and len(rng) == 20 and j > a0:
        B = cc[j]; H = ch[a:e]; L = cl[a:e]; O = co[a:e]; C = cc[a:e]; M = cm[a:e]; n = e - a
        lng = (q.m0 - p.end) > (80 if p.kind == 'D' else 200); sig = float(np.mean(rng)); g = O[ko] - B
        j60 = np.searchsorted(cm, p.end - 60) - 1
        EV.append((i, q.t0, p.kind + '>' + q.kind, lng, B, g, sig, p.m0, p.end, q.m0, q.end, co[a0], ch[a0:j + 1].max(), cl[a0:j + 1].min(), cc[j60], q.fo - p.fc))
        for x in XP:
            w = B * x / 100; U = B + w; Dn = B - w
            iu = np.nonzero(H >= U)[0]; idn = np.nonzero(L <= Dn)[0]
            iu = iu[0] if len(iu) else BIG; idn = idn[0] if len(idn) else BIG
            if iu == idn: continue
            k = min(iu, idn); d = -1 if iu < idn else 1
            ent = max(U, O[k]) if d < 0 else min(Dn, O[k])
            adv = (H[k:] - ent) if d < 0 else (ent - L[k:])
            sis = {0: BIG}
            for sk in SK[1:]:
                z = np.nonzero(adv >= sk * w)[0]; sis[sk] = z[0] + k if len(z) else BIG
            tts = {0: n}
            for tm in TM[1:]: tts[tm] = int(np.searchsorted(M, M[k] + tm))
            for cth in (0, 5, 10):
                if k >= ko:
                    if abs(g) <= cth: continue
                    z = np.nonzero(L[ko:] <= B + cth)[0] if g > 0 else np.nonzero(H[ko:] >= B - cth)[0]
                    ci = z[0] + ko if len(z) else BIG
                    if k == ci: amb += 1; continue
                    if k > ci: continue
                eid = len(E); E.append((len(EV) - 1, x, cth, M[k], d, ent, w, 'closed' if k < ko else 'open'))
                for tg in ((0, 1) if cth == 0 else (2,) if cth == 5 else (3,)):
                    T = (B + ent) / 2 if tg == 1 else (B + cth if d < 0 else B - cth)
                    z = np.nonzero(L[k + 1:] <= T)[0] if d < 0 else np.nonzero(H[k + 1:] >= T)[0]
                    ti = z[0] + k + 1 if len(z) else BIG
                    for sk in SK:
                        si = sis[sk]
                        for tm in TM:
                            tt = tts[tm]
                            if si <= ti and si < tt:
                                lvl = ent + sk * w if d < 0 else ent - sk * w
                                px = lvl if si == k else (max(lvl, O[si]) if d < 0 else min(lvl, O[si])); rs = 2; h = si - k
                            elif ti < tt:
                                px = min(T, O[ti]) if d < 0 else max(T, O[ti]); rs = 1; h = ti - k
                            elif tt < n: px = O[tt]; rs = 3; h = tt - k
                            else: px = C[-1]; rs = 3; h = n - 1 - k
                            R['eid'][nr] = eid; R['pp'][nr] = d * (px - ent) / B * 100; R['tg'][nr] = tg; R['sk'][nr] = sk; R['tm'][nr] = tm; R['res'][nr] = rs; R['hold'][nr] = h; nr += 1
    if p.n >= 24 and j > a0: rng.append((ch[a0:j + 1].max() - cl[a0:j + 1].min()) / cc[j])
r = pd.DataFrame({k: v[:nr] for k, v in R.items()})
en = pd.DataFrame(E, columns=['ev', 'x', 'cth', 'm', 'd', 'ent', 'w', 'zone'])
ev = pd.DataFrame(EV, columns=['i', 't0', 'kind', 'long', 'B', 'gap', 'sig', 'pm0', 'pend', 'qm0', 'qend', 'po', 'ph', 'pl', 'c60', 'fgap'])
r.to_pickle(sys.argv[4] + '/r.pkl'); en.to_pickle(sys.argv[4] + '/en.pkl'); ev.to_pickle(sys.argv[4] + '/evt.pkl')
print('rows', nr, 'entries', len(en), 'events', len(ev), ev.kind.value_counts().to_dict(), '長い休み', int(ev.long.sum()), '判定不能', amb, ev.t0.iloc[0], ev.t0.iloc[-1])
print('CFD窓と先物窓の相関', round(ev.gap.corr(ev.fgap), 3))
