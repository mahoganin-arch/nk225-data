# 段階1-b：既存の3,894候補に指標条件を1つ加えたときの改善
import sys, time, numpy as np, pandas as pd
sys.path.insert(0, sys.argv[1]); from common6 import *
d = sys.argv[2]; Y, en, F = load(d); C = pd.read_pickle(d + '/cand.pkl')
CBI = {(round(a, 3), round(b, 3), int(c)): i for i, (a, b, c) in enumerate(CB)}
FEATS = [k for k in F.columns if k not in ('曜日', '時')]; WD = {k: i for i, k in enumerate('月火水木金土日')}
BX = {}
for x in sorted(C['乖離幅%'].unique()):
    idx = np.nonzero((~en.long.values) & np.isclose(en.x.values, x))[0]; f = F.iloc[idx]; labs = []; mats = []
    for k in FEATS:
        for lab, m in bins_for(f[k].values.astype(float), None): labs.append((k, lab)); mats.append(m)
    BX[x] = (idx, labs, np.array(mats, dtype=np.float32))
OUT = []; t0 = time.time()
for ci, row in C.iterrows():
    idx, labs, Mb = BX[row['乖離幅%']]; sub = en.iloc[idx]
    mk = sub.kind.values == row['窓']
    for tok in row['条件'].split():
        if tok in WD: mk &= sub.wd.values == WD[tok]
        elif tok.endswith('時'): mk &= sub.hr.values == int(tok[:-1])
        elif tok in ('上', '下'): mk &= sub.dir.values == tok
    pos = np.nonzero(mk)[0]; y = np.asarray(Y[idx[pos], CBI[row['決済キー']]], dtype=np.float32) / 100 * P; yi = sub.yr.values[pos] - 2017
    Mc = Mb[:, pos]; Oy = np.zeros((len(pos), 10), np.float32); Oy[np.arange(len(pos)), yi] = 1
    N = Mc @ Oy; Sm = Mc @ (Oy * y[:, None]); Wn = Mc @ (Oy * (y > 0)[:, None])
    sel = row['選び方']; hs = ['A', 'B'] if ('両方' in sel or ('前半' in sel and '後半' in sel)) else (['A'] if sel.startswith('前半') else ['B'])
    st = {}
    for h, sl in (('A', slice(0, 5)), ('B', slice(5, 10))):
        n = N[:, sl].sum(1); s = Sm[:, sl].sum(1); st[h] = dict(n=n, mean=s / np.maximum(n, 1), win=Wn[:, sl].sum(1) / np.maximum(n, 1) * 100, yn=(N[:, sl] >= 3).sum(1), yp=((Sm[:, sl] > 0) & (N[:, sl] >= 3)).sum(1))
    base = {'A': row['前半平均'], 'B': row['後半平均']}
    ok = np.ones(len(labs), bool); imp = np.full(len(labs), np.inf)
    for h in hs:
        ok &= (st[h]['n'] >= 20) & (st[h]['yn'] >= 4) & (st[h]['mean'] >= 20) & (st[h]['n'] < (sub.half.values[pos] == h).sum()); imp = np.minimum(imp, st[h]['mean'] - base[h])
    ok &= imp > 0
    for j in np.argsort(-np.where(ok, imp, -np.inf))[:5]:
        if not ok[j]: break
        k, lab = labs[j]
        OUT.append((ci, jname(k), lab, theme(k), imp[j]) + tuple(v for h in ('A', 'B') for v in (st[h]['n'][j], st[h]['mean'][j], st[h]['win'][j], st[h]['yp'][j], st[h]['yn'][j])))
print('done', round(time.time() - t0), 's', len(OUT))
R = pd.DataFrame(OUT, columns=['候補番号', '追加する指標', '区分', '種類', '改善幅'] + [h + c for h in ('前半', '後半') for c in ('件数', '平均', '勝率', 'プラス年', '年数')])
R.to_pickle(d + '/s1b.pkl'); print('改善できた候補', R['候補番号'].nunique(), '/', len(C)); print(R['種類'].value_counts().to_dict())
print(R.groupby('追加する指標').size().sort_values(ascending=False).head(15).to_dict())
