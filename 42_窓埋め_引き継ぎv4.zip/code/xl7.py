import sys, numpy as np, pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
sys.path.insert(0, sys.argv[1]); from common6 import *
d = sys.argv[2]; out = sys.argv[3]; Y, en, F = load(d); Fm = pd.read_pickle(d + '/families.pkl')
CBI = {(round(a, 3), round(b, 3), int(c)): i for i, (a, b, c) in enumerate(CB)}
hr = F['時'].values; F2 = F.drop(columns=['時']).copy()
F2['時間帯'] = np.select([(hr >= 5) & (hr <= 8), (hr >= 9) & (hr <= 11), (hr >= 12) & (hr <= 15), (hr >= 16) & (hr <= 18), (hr >= 19) & (hr <= 22)], [0, 1, 2, 3, 4], 5).astype(np.float32)
TBL = {0: '5-8時', 1: '9-11時', 2: '12-15時', 3: '16-18時', 4: '19-22時', 5: '23-4時'}; SEGS = {'D>N': ['D>N'], 'N>D': ['N>D'], '両方の窓': ['D>N', 'N>D']}
def b3lab(k, v):
    ok = ~np.isnan(v); u = np.unique(v[ok])
    if len(u) <= 6: return {(TBL[int(x)] if k == '時間帯' else ('月火水木金土日'[int(x)] if k == '曜日' else '%g' % x)): v == x for x in u}
    q = np.nanquantile(v, [1 / 3, 2 / 3]); b = np.searchsorted(q, v, side='right'); return {lab: ok & (b == i) for i, lab in enumerate(['低', '中', '高'])}
Fm['低い方の平均'] = np.minimum(Fm['前半平均'], Fm['後半平均'])
TOP = 30000
sheets = {'両方で優位': Fm[Fm['選び方'] == '両方で最良'].sort_values(['低い方の平均'], ascending=False).head(TOP),
          '後半で優位': Fm[Fm['選び方'] == '後半で最良'].sort_values('後半平均', ascending=False).head(TOP),
          '前半で優位': Fm[Fm['選び方'] == '前半で最良'].sort_values('前半平均', ascending=False).head(TOP),
          '高勝率': Fm[Fm['選び方'].str.contains('高勝率')].assign(勝率=lambda v: np.where(v['選び方'].str.startswith('前半'), v['前半勝率'], v['後半勝率'])).sort_values(['勝率', '低い方の平均'], ascending=False).head(TOP).drop(columns='勝率')}
sheets['安定(幅が広い)'] = Fm[Fm['選び方'] == '両方で最良'].sort_values(['連続した幅の最大数', '低い方の平均'], ascending=False).head(TOP)
allrep = pd.concat(sheets.values()).drop_duplicates(['窓', '指標1', '区分1', '指標2', '区分2', '選び方']).reset_index(drop=True)
W = np.full((len(allrep), 4), np.nan); bad = 0
for x, grp in allrep.groupby('乖離幅%'):
    idx = np.nonzero((~en.long.values) & np.isclose(en.x.values, x))[0]; sub = en.iloc[idx]; half = sub.half.values; f1 = F.iloc[idx]; f2 = F2.iloc[idx]; c1 = {}; c2 = {}
    for i, r in grp.iterrows():
        mk = np.isin(sub.kind.values, SEGS[r['窓']])
        if r['指標2'] == '':
            if r['指標1'] not in c1: c1[r['指標1']] = dict(bins_for(f1[r['指標1']].values.astype(float), None))
            mk = mk & c1[r['指標1']][r['区分1']]
        else:
            for k, lab in ((r['指標1'], r['区分1']), (r['指標2'], r['区分2'])):
                if k not in c2: c2[k] = b3lab(k, f2[k].values.astype(float))
                mk = mk & c2[k][lab]
        y = np.asarray(Y[idx[mk], CBI[(round(float(r['利確']), 3), round(float(r['損切り']), 3), int(r['時間切れ']))]], dtype=np.float64) / 100 * P; hh = half[mk]
        for j, h in enumerate(('A', 'B')):
            v = y[hh == h]
            if len(v): W[i, j] = v.min(); W[i, j + 2] = v[v > 0].sum() / max(-v[v < 0].sum(), 1e-6)
        for h, col in (('A', '前半'), ('B', '後半')):
            v = y[hh == h]
            if len(v) != int(r[col + '件数']) or (len(v) and abs(v.mean() - r[col + '平均']) > 0.5): bad += 1
print('検算の不一致', bad, '/', len(allrep))
allrep['前半最悪'] = W[:, 0]; allrep['後半最悪'] = W[:, 1]; allrep['前半PF'] = W[:, 2]; allrep['後半PF'] = W[:, 3]
K = ['窓', '指標1', '区分1', '指標2', '区分2', '選び方']; ext = allrep[K + ['前半最悪', '後半最悪', '前半PF', '後半PF']]
fixlab = lambda v: ('値' + v[1:]) if isinstance(v, str) and v.startswith('=') else v
def fmt(df):
    df = df.merge(ext, on=K, how='left').copy(); df['区分1'] = df['区分1'].map(fixlab); df['区分2'] = df['区分2'].map(fixlab)
    df['条件'] = [jname(a) + '=' + b + ((' × ' + jname(c) + '=' + e) if c else '') for a, b, c, e in zip(df['指標1'], df['区分1'], df['指標2'], df['区分2'])]
    df['損切り'] = df['損切り'].map(lambda v: 'なし' if v == 0 else v); df['時間切れ'] = df['時間切れ'].map(lambda v: '引けまで' if v == 0 else int(v))
    cols = ['種類', '選び方', '窓', '条件', '乖離幅%', '利確', '損切り', '時間切れ', '前半件数', '前半平均', '前半勝率', '前半PF', '前半最悪', '前半プラス年', '前半年数', '前半p', '前半プラス決済%',
            '後半件数', '後半平均', '後半勝率', '後半PF', '後半最悪', '後半プラス年', '後半年数', '後半p', '後半プラス決済%', '低い方の平均', '通過した幅の数', '連続した幅の最大数', '基準を満たす決済数', '指標1', '区分1', '指標2', '区分2']
    df = df[cols]; n = df.select_dtypes('number').columns; df[n] = df[n].astype(float).round(2); return df
# 既存候補への上乗せ
C = pd.read_pickle(d + '/cand.pkl'); B1 = pd.read_pickle(d + '/s1b.pkl')
B1 = B1.merge(C[['窓', '乖離幅%', '粒度', '条件', '決済キー', '選び方', '前半平均', '後半平均']].rename(columns={'前半平均': '元の前半平均', '後半平均': '元の後半平均', '条件': '時間の条件'}), left_on='候補番号', right_index=True)
B1['利確'] = [k[0] for k in B1['決済キー']]; B1['損切り'] = [('なし' if k[1] == 0 else k[1]) for k in B1['決済キー']]; B1['時間切れ'] = [('引けまで' if k[2] == 0 else k[2]) for k in B1['決済キー']]
B1 = B1[['候補番号', '選び方', '窓', '乖離幅%', '粒度', '時間の条件', '利確', '損切り', '時間切れ', '元の前半平均', '元の後半平均', '追加する指標', '区分', '種類', '改善幅', '前半件数', '前半平均', '前半勝率', '前半プラス年', '前半年数', '後半件数', '後半平均', '後半勝率', '後半プラス年', '後半年数']].sort_values('改善幅', ascending=False)
B1['区分'] = B1['区分'].map(fixlab); B1[B1.select_dtypes('number').columns] = B1.select_dtypes('number').round(2)
cnt = Fm.groupby(['種類', '選び方']).size().unstack().fillna(0).astype(int)
expl = [('この表について', '段階1（指標単独）・段階2（2条件の組み合わせ）で見つかった逆張り候補を「候補群」にまとめたもの'),
        ('候補群', '同じ窓・同じ条件で、乖離幅や決済だけが違うものを1つにまとめ、代表（その選び方で最も成績が良い乖離幅と決済）を1行で表示'),
        ('種類', '指標単独＝指標1つの条件、指標×指標＝異なる種類の指標2つ、指標×時間・曜日＝指標と時間帯（6区分）または曜日'),
        ('条件の区分', '指標単独は3分割（低/中/高）・5分割（1〜5）・上位/下位10%・値そのもの（=1など）。2条件は3分割または値そのもの。区切りの値は乖離幅ごとに全期間で決めている'),
        ('指標の向き', '方向のある指標（RSI、移動平均乖離、MACD、DMI差、雲位置、平均足など）は「離れた方向と同じ向きなら高・プラス」に揃えている。例：RSI=高は、上に離れたときRSIが高い／下に離れたときRSIが低い'),
        ('窓', 'D>N=日中引け→夜間、N>D=夜間引け→日中、両方の窓=両方を合わせたもの。週末・祝日またぎは除く'),
        ('基準', '平均+20円以上、各半期20件以上、5年中4年以上で年3回以上（両方で優位は前半・後半とも）'),
        ('通過した幅の数 / 連続した幅の最大数', '28通りの乖離幅のうち、同じ条件で基準を満たした幅の数／隣り合う幅で続けて満たした最大数。大きいほど乖離幅の選び方に左右されにくい'),
        ('基準を満たす決済数', '代表の乖離幅で、1,944通りの決済のうち基準を満たした数'),
        ('プラス決済%', '代表の乖離幅で、1,944通りの決済のうち平均がプラスだった割合'),
        ('p', '参考値（多数の条件から選んだことは考慮していない）'),
        ('件数の上限', '各シートは上位3万件まで。全件は別ファイルのCSV（gz圧縮）にあります'),
        ('組み合わせの一次選考', '2条件の組み合わせは、代表100通りの決済で基準を満たしたものだけを1,944通りで詰め直している。100通りのどれでも基準に届かなかった組み合わせは載っていない'),
        ('既存候補への上乗せ', '前回の3,894候補（曜日・時間・方向の条件）に指標を1つ加えて、基準を満たしたまま平均が上がったもの。候補ごとに改善の大きい順に最大5つ'),
        ('金額', '68,800円換算、コスト未控除。前半=2017〜2021年、後半=2022〜2026年')]
with pd.ExcelWriter(out, engine='openpyxl') as w:
    pd.DataFrame(expl, columns=['項目', '説明']).to_excel(w, sheet_name='説明', index=False)
    cnt.reset_index().to_excel(w, sheet_name='件数', index=False)
    for nm, df in sheets.items(): fmt(df).to_excel(w, sheet_name=nm, index=False)
    B1.to_excel(w, sheet_name='既存候補への上乗せ', index=False)
wb = load_workbook(out); hf = PatternFill('solid', start_color='DDE4EE')
for ws in wb.worksheets:
    for c in ws[1]: c.font = Font(name='Arial', size=10, bold=True); c.fill = hf; c.alignment = Alignment(wrap_text=True, vertical='center')
    ws.freeze_panes = 'A2'
    if ws.title not in ('説明',): ws.auto_filter.ref = ws.dimensions
    for col in ws.columns:
        Lm = max(len(str(c.value)) if c.value is not None else 0 for c in list(col)[:300]); ws.column_dimensions[col[0].column_letter].width = min(max(8, Lm * 1.6 if ws.title == '説明' else Lm + 2), 70)
wb.save(out)
full = Fm.copy(); full['区分1'] = full['区分1'].map(fixlab); full['区分2'] = full['区分2'].map(fixlab); full['条件'] = [jname(a) + '=' + b + ((' × ' + jname(c) + '=' + e) if c else '') for a, b, c, e in zip(full['指標1'], full['区分1'], full['指標2'], full['区分2'])]
full.round(2).to_csv(sys.argv[4], index=False, encoding='utf-8-sig', compression='gzip'); print('ok')
