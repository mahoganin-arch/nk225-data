import sys, itertools, pandas as pd, numpy as np
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
d = sys.argv[1]; out = sys.argv[2]; R = pd.read_pickle(d + '/rows.pkl'); FU = pd.read_pickle(d + '/full.pkl')
Y = np.load(d + '/Y.npy'); en = pd.read_pickle(d + '/en.pkl'); ev = pd.read_pickle(d + '/evt.pkl'); P = 68800
FR = [.1, .2, .3, .4, .5, .6, .7, .8, .9, 1.0, 1.25, 1.5]; SK = [0, .1, .2, .3, .4, .5, .6, .75, .9, 1, 1.25, 1.5, 2, 2.5, 3, 4, 5, 6]; TM = [0, 15, 30, 60, 90, 120, 180, 240, 360]; CB = list(itertools.product(FR, SK, TM))
num = R.select_dtypes('number').columns; R[num] = R[num].astype(float).round(2); R['時間切れ'] = R['時間切れ'].astype(int)
def tidy(df):
    df = df.copy(); df['損切り'] = df['損切り'].map(lambda v: 'なし' if v == 0 else v); df['時間切れ'] = df['時間切れ'].map(lambda v: '引けまで' if v == 0 else int(v)); return df
both = R[(R['選び方'] == '両方で最良') & (R['前半件数'] >= 10) & (R['後半件数'] >= 10)].assign(低い方の平均=lambda v: np.minimum(v['前半平均'], v['後半平均'])).sort_values('低い方の平均', ascending=False)
lateB = R[(R['選び方'] == '後半で最良') & (R['後半件数'] >= 10)].sort_values('後半平均', ascending=False)
earlyA = R[(R['選び方'] == '前半で最良') & (R['前半件数'] >= 10)].sort_values('前半平均', ascending=False)
hw = R[R['選び方'].isin(['前半・高勝率', '後半・高勝率'])].copy(); hw['基準の勝率'] = np.where(hw['選び方'] == '前半・高勝率', hw['前半勝率'], hw['後半勝率']); hw = hw.sort_values(['基準の勝率', '前半平均'], ascending=False)
# 曜日×時間：決済を固定した成績（完全な窓埋め・損切り1倍/2倍/なし、引けまで）
en2 = en.join(ev[['kind', 'long', 't0']], on='ev'); en2['窓'] = np.where(en2.long, '週末祝日', en2.kind); en2['half'] = np.where(en2.t0.dt.year <= 2021, '前半', '後半')
t = pd.to_datetime(en2.m * 60, unit='s', utc=True).dt.tz_convert('Asia/Tokyo'); en2['曜日'] = t.dt.dayofweek.map(dict(enumerate('月火水木金土日'))); en2['時'] = t.dt.hour
mats = []
for ex, lab in (((1.0, 1, 0), '完全埋め・損切り1倍'), ((1.0, 2, 0), '完全埋め・損切り2倍'), ((1.0, 0, 0), '完全埋め・損切りなし')):
    q = en2.assign(y=Y[:, CB.index(ex)].astype(float) / 100 * P); q = q[q.x.isin([.05, .1, .15, .2, .3, .4, .5])]
    g = q.groupby(['窓', 'x', '曜日', '時', 'half']).y.agg(件数='size', 平均='mean', 勝率=lambda v: (v > 0).mean() * 100).round(1).unstack('half')
    g.columns = [b + a for a, b in g.columns]; g = g.reset_index().rename(columns={'x': '乖離幅%'}); g.insert(0, '決済', lab); mats.append(g)
M = pd.concat(mats); M = M[['決済', '窓', '乖離幅%', '曜日', '時', '前半件数', '前半平均', '前半勝率', '後半件数', '後半平均', '後半勝率']]
wd_order = {k: i for i, k in enumerate('月火水木金土日')}; M = M.sort_values(['決済', '窓', '乖離幅%', '曜日', '時'], key=lambda s: s.map(wd_order) if s.name == '曜日' else s)
full = FU.copy(); fn = full.select_dtypes('number').columns; full[fn] = full[fn].astype(float).round(2)
expl = [('この表について', ''), ('対象', '日経225 CFD（FOREXCOM Japan 225）。2020/11/9以降は1分足、それ以前は5分足。2026/10/9より前のみ'),
        ('前半 / 後半', '前半=2017〜2021年、後半=2022〜2026年（窓の発生日で区分）'),
        ('窓', 'D>N=日中引け→夜間、N>D=夜間引け→日中、週末祝日=週末・祝日またぎ'),
        ('基準', '先物引け（板寄せ時刻）直前のCFD終値'),
        ('乖離幅%', '基準からこの割合だけ離れたら逆張りでエントリー（指値）。先物寄り後に基準へ触れた窓では以後入らない。1つの窓で1回'),
        ('利確', '基準までの距離に対する割合。1.0=完全な窓埋め、0.5=半分、1.25/1.5=基準を越えた先で利確'),
        ('損切り', '乖離幅の倍率（エントリー価格からの距離）。なし=損切りしない'),
        ('時間切れ', 'エントリーから何分で決済するか。引けまで=次の先物セッションの引けで決済'),
        ('平均・最悪', '1回あたりの損益（円）。価格比を68,800円に換算。コスト（スプレッド）は未控除'),
        ('勝率', '損益がプラスだった割合（%）'), ('PF', 'プラスの合計 ÷ マイナスの合計'),
        ('プラス年 / 年数', 'その半期の各年のうち平均がプラスだった年の数 / 3件以上あった年の数'),
        ('p', '参考値。偶然でこれ以上の平均が出る確率の目安（多数の条件から選んだことは考慮していない）'),
        ('プラス決済%', 'その条件で試した1,944通りの決済のうち、平均がプラスだった割合。高いほど決済の選び方に左右されにくい'),
        ('選び方', '前半で最良/後半で最良=その半期の平均が最大の決済、両方で最良=前半と後半の低い方が最大の決済、高勝率=勝率80%以上で平均プラスのうち平均が最大の決済'),
        ('粒度', '条件の細かさ。曜日・時間・方向（上=上に離れて売り、下=下に離れて買い）の組み合わせ。曜日と時間はエントリー時刻（日本時間）'),
        ('件数の下限', '各半期10件以上の条件だけ載せています（少数のものは件数を見て判断してください）'),
        ('同じ足の扱い', '損切りと利確が同じ足で起きた場合は損切りとして計算。休止明け最初の足では入らず、確定後の終値で判定'),
        ('全組み合わせ', '条件なしの全組み合わせ（乖離幅×利確×損切り×時間切れ）は別ファイルのCSVにあります')]
with pd.ExcelWriter(out, engine='openpyxl') as w:
    pd.DataFrame(expl, columns=['項目', '説明']).to_excel(w, sheet_name='説明', index=False)
    tidy(both.drop(columns='選び方')).to_excel(w, sheet_name='両方で優位', index=False)
    tidy(lateB.drop(columns='選び方')).to_excel(w, sheet_name='後半で優位', index=False)
    tidy(earlyA.drop(columns='選び方')).to_excel(w, sheet_name='前半で優位', index=False)
    tidy(hw).to_excel(w, sheet_name='少数・高勝率', index=False)
    M.to_excel(w, sheet_name='曜日×時間(決済固定)', index=False)
wb = load_workbook(out); hf = PatternFill('solid', start_color='DDE4EE')
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c in row: c.font = Font(name='Arial', size=10, bold=(c.row == 1))
    for c in ws[1]: c.fill = hf; c.alignment = Alignment(wrap_text=True, vertical='center')
    ws.freeze_panes = 'A2'
    if ws.title != '説明': ws.auto_filter.ref = ws.dimensions
    for col in ws.columns:
        L = max(len(str(c.value)) if c.value is not None else 0 for c in list(col)[:200]); ws.column_dimensions[col[0].column_letter].width = min(max(8, L * 1.6 if ws.title == '説明' else L + 2), 90)
wb.save(out)
full = tidy(full); full.to_csv(sys.argv[3], index=False, encoding='utf-8-sig')
print({ws.title: ws.max_row for ws in wb.worksheets}, 'full', len(full))
