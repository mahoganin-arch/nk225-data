# Pineのロジックと同じ手順で5分足を新形式(Y)に詰め、ld.pyで復元して元と比べる
import sys, csv, math, pandas as pd, numpy as np
sys.path.insert(0, sys.argv[1]); import ld
AL = ld.AL
def ch(v): return AL[v:v + 1]
def enc(v):
    if v < 62: return ch(v)
    if v < 3844: return '.' + ch(int(math.floor(v / 62))) + ch(v % 62)
    q1 = int(math.floor(v / 62)); q2 = int(math.floor(q1 / 62)); q3 = int(math.floor(q2 / 62))
    return '_' + ch(q3 % 62) + ch(q2 % 62) + ch(q1 % 62) + ch(v % 62)
zz = lambda v: 2 * v if v >= 0 else -2 * v - 1
def pack(d, tf, tick, maxLen=4000):
    out = []; body = ''; n = 0; t0 = base = prevC = prevT = 0
    for tm, o, h, l, c in zip(d.m.astype(int), *(np.round(d[k] / tick).astype(int) for k in ('open', 'high', 'low', 'close'))):
        if n == 0: t0 = tm; base = o; prevC = o; prevT = tm
        g = tm - prevT; jp = o - prevC; rec = ''
        if n > 0 and g != tf: rec += '*' + enc(g)
        if jp != 0: rec += '!' + enc(zz(jp))
        rec += enc(max(h - o, 0)) + enc(max(o - l, 0)) + enc(zz(c - o))
        body += rec; n += 1; prevC = c; prevT = tm
        if len(body) >= maxLen:
            out.append('Y%d~%d,%d,%s,%d~%s~E' % (n, t0, base, str(tick), tf, body)); body = ''; n = 0
    if n: out.append('Y%d~%d,%d,%s,%d~%s~E' % (n, t0, base, str(tick), tf, body))
    return out
for name, src, tick in (('CFD', sys.argv[2], 1), ('先物', sys.argv[3], 5)):
    d = ld.bars(src); cs = pack(d, 5, tick)
    p = sys.argv[4] + '/' + name + '.csv'
    with open(p, 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.writer(fh); w.writerow(['トレード番号', 'シグナル']); [w.writerow([i, s]) for i, s in enumerate(cs)]
    r = ld.bars(p)
    same = len(r) == len(d) and all(np.array_equal(r[k].values, d[k].values) for k in ('m', 'open', 'high', 'low', 'close'))
    tot = sum(map(len, cs)); print(name, '本数', len(d), '復元一致', same, 'コメント数', len(cs), '最大長', max(map(len, cs)), '1足あたり文字', round(tot / len(d), 2), '本体合計MB', round(tot / 1e6, 2))
# 値の大きさの分布（1文字で収まる割合）
d = ld.bars(sys.argv[2]); b = (d.high - d.open); c = (d.open - d.low); z = (d.close - d.open).abs() * 2
for y in (2017, 2021, 2025, 2026):
    m = d.t.dt.year == y; print(y, '5分足で1文字に収まる割合 高値幅', round((b[m] < 62).mean(), 3), '安値幅', round((c[m] < 62).mean(), 3), '終値差', round((z[m] < 62).mean(), 3), ' 高値幅の平均', round(b[m].mean(), 1))
