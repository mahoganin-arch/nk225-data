import sys, pandas as pd, numpy as np
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
d = sys.argv[1]; out = sys.argv[2]; C = pd.read_pickle(d + '/cand.pkl'); L = pd.read_pickle(d + '/candflag.pkl'); G = pd.read_pickle(d + '/flagbase.pkl')
C = C.reset_index().rename(columns={'index': '候補番号'})
C['利確'] = [k[0] for k in C['決済キー']]; C['損切り'] = [('なし' if k[1] == 0 else k[1]) for k in C['決済キー']]; C['時間切れ'] = [('引けまで' if k[2] == 0 else k[2]) for k in C['決済キー']]
C['低い方の平均'] = np.minimum(C['前半平均'], C['後半平均'])
cols = ['候補番号', '選び方', '窓', '乖離幅%', '粒度', '条件', '利確', '損切り', '時間切れ', '前半件数', '前半平均', '前半勝率', '前半PF', '前半最悪', '前半プラス年', '前半年数', '前半p', '前半プラス決済%',
        '後半件数', '後半平均', '後半勝率', '後半PF', '後半最悪', '後半プラス年', '後半年数', '後半p', '後半プラス決済%', '低い方の平均', '除外すると両半期とも改善する印']
C = C[cols].sort_values('低い方の平均', ascending=False); num = C.select_dtypes('number').columns; C[num] = C[num].round(2)
L2 = C[['候補番号', '選び方', '窓', '乖離幅%', '粒度', '条件', '利確', '損切り', '時間切れ', '前半平均', '後半平均']].rename(columns={'前半平均': '前半平均(全体)', '後半平均': '後半平均(全体)'}).merge(L, on='候補番号')
L2[L2.select_dtypes('number').columns] = L2.select_dtypes('number').round(2)
G[G.select_dtypes('number').columns] = G.select_dtypes('number').round(2)
expl = [('この表について', '逆張り候補を絞り込み、SQ・祝日・月末月初の印ごとに成績を分けたもの'),
        ('絞り込みの基準', '平均+20円以上、各半期20件以上、5年中4年以上で年3回以上発生。両方で最良は前半・後半の両方に適用、それ以外は選んだ半期に適用。週末祝日またぎの窓は除く'),
        ('窓の日付', '日中→夜間は引けた日、夜間→日中は日中セッションの日。印はこの日付で判定'),
        ('SQ週(メジャー)/(ミニ)', 'SQ日を含む週（月〜金）。メジャー=3・6・9・12月、ミニ=その他の月'),
        ('SQ当日・SQ前日', 'SQ日=第2金曜（休場なら前の営業日）。前日=その前の営業日'),
        ('祝日前日・祝日翌日', '次の平日が祝日・年末年始休場なら祝日前日。前の平日が祝日なら祝日翌日（連休明けを含む）'),
        ('祝日取引中', '2022年9月以降、祝日に先物が取引された日の窓'),
        ('月末3営業日・月初3営業日', 'その月の最後の3営業日、最初の3営業日'),
        ('該当 / 除外後', '該当=その印が付いた取引だけの成績、除外後=その印の取引を除いた成績'),
        ('除外すると両半期とも改善する印', '該当時の平均がどちらかの半期でマイナスで、除外すると前半・後半とも平均が上がる印。件数が数件でも拾うので、該当件数を必ず確認してください'),
        ('印の全体傾向', '条件なし（曜日・時間などで絞らない）で、決済を固定したときの印ごとの成績'),
        ('その他の列', '前回の表と同じ意味（金額は68,800円換算・コスト未控除、最悪=1回の最大損失、プラス年=平均プラスの年数など）'),
        ('祝日の出典', 'Pythonの holidays ライブラリ（日本の祝日、2019年の即位関連・2020/21年の五輪移動を含む）に年末年始(12/31・1/2・1/3)を追加。先物データの休場日と照合済み')]
with pd.ExcelWriter(out, engine='openpyxl') as w:
    pd.DataFrame(expl, columns=['項目', '説明']).to_excel(w, sheet_name='説明', index=False)
    C.to_excel(w, sheet_name='候補一覧', index=False)
    L2.to_excel(w, sheet_name='候補×印', index=False)
    G.to_excel(w, sheet_name='印の全体傾向', index=False)
wb = load_workbook(out); hf = PatternFill('solid', start_color='DDE4EE')
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c in row: c.font = Font(name='Arial', size=10, bold=(c.row == 1))
    for c in ws[1]: c.fill = hf; c.alignment = Alignment(wrap_text=True, vertical='center')
    ws.freeze_panes = 'A2'
    if ws.title != '説明': ws.auto_filter.ref = ws.dimensions
    for col in ws.columns:
        Lm = max(len(str(c.value)) if c.value is not None else 0 for c in list(col)[:200]); ws.column_dimensions[col[0].column_letter].width = min(max(8, Lm * 1.6 if ws.title == '説明' else Lm + 2), 90)
wb.save(out); print({ws.title: ws.max_row for ws in wb.worksheets})
