# v5：逆張りの細かい総当たり（ベクトル化）。CFDは2020/11以降1分足、それ以前は5分足
import sys, pandas as pd, numpy as np
sys.path.insert(0, sys.argv[1]); import ld
f = ld.bars(sys.argv[2], until='2026-10-09'); c5 = ld.bars(sys.argv[3], until='2026-10-09'); c1 = ld.bars(sys.argv[4], until='2026-10-09')
m1 = c1.m.iloc[0]; c = pd.concat([c5[c5.m + 5 <= m1], c1], ignore_index=True)
print('CFD', len(c), '1分足開始', c1.t.iloc[0])
ro_all = (c.m.diff() > 30).values; cm = c.m.values; co = c.open.values; ch = c.high.values; cl = c.low.values; cc = c.close.values
f['sid'] = (f.m.diff() > 15).cumsum()
s = f.groupby('sid').agg(m0=('m', 'first'), m1=('m', 'last'), n=('m', 'size'), t0=('t', 'first')); lh = f.groupby('sid').t.last().dt.strftime('%H:%M')
s['end'] = np.where(lh.isin(['15:15', '15:45', '05:30', '06:00']), s.m1, s.m1 + 5); s['kind'] = np.where(s.t0.dt.hour.between(8, 9), 'D', 'N'); s['lh'] = lh; s = s.reset_index(drop=True)
XP = np.array([.03, .04, .05, .06, .075, .09, .1, .11, .125, .14, .15, .175, .2, .225, .25, .275, .3, .35, .4, .45, .5, .6, .7, .8, .9, 1.0, 1.2, 1.5])
FR = np.array([.1, .2, .3, .4, .5, .6, .7, .8, .9, 1.0, 1.25, 1.5])                       # 利確：窓までの距離に対する割合（1超は基準を越えて取る）
SK = np.array([0, .1, .2, .3, .4, .5, .6, .75, .9, 1, 1.25, 1.5, 2, 2.5, 3, 4, 5, 6])      # 損切り：乖離幅の倍率（0=なし）
TM = np.array([0, 15, 30, 60, 90, 120, 180, 240, 360])                                      # 時間切れ（分、0=次の先物セッション引け）
NF, NS, NT = len(FR), len(SK), len(TM); BIG = 10**9
Y = []; E = []; EV = []; EX = []; GK = []; EP = []   # EX：決済の位置（(足の番号−エントリーの足)×4＋種類 0=SK水準 1=FR水準 2=時間 3=最後の足の終値）
for i in range(1, len(s)):
    p, q = s.iloc[i - 1], s.iloc[i]; j = np.searchsorted(cm, p.end) - 1
    if not (p.n >= 24 and q.n >= 24 and p.kind != q.kind and j >= 0 and p.end - cm[j] <= 15): continue
    a = j + 1; e = np.searchsorted(cm, q.end); ko = np.searchsorted(cm, q.m0) - a
    if not (e - a >= 6 and 0 <= ko < e - a): continue
    B = cc[j]; H = ch[a:e]; L = cl[a:e]; O = co[a:e]; C = cc[a:e]; M = cm[a:e]; n = e - a; RO = ro_all[a:e]
    Hd = np.where(RO, C, H); Ld = np.where(RO, C, L); Os = np.where(RO, C, O)
    lng = (q.m0 - p.end) > (80 if p.kind == 'D' else 200); g = O[ko] - B
    EV.append((i, q.t0, p.kind + '>' + q.kind, lng, B, p.end, q.m0, M[1] - M[0] if n > 1 else 1))
    zc = np.nonzero(L[ko:] <= B)[0] if g > 0 else (np.nonzero(H[ko:] >= B)[0] if g < 0 else np.array([0])); ci = zc[0] + ko if len(zc) else BIG
    cut = int(np.searchsorted(M, q.end - 5)) if (q.kind == 'N' and q.lh == '06:00') else n   # 夜間引け6:00の時期はCFD日替わり前の5:55で手じまい
    rmaxH = np.maximum.accumulate(Hd); rminL = np.minimum.accumulate(Ld)
    for x in XP:
        w = B * x / 100; U = B + w; Dn = B - w
        iu = np.searchsorted(rmaxH, U); idn = np.searchsorted(-rminL, -Dn)
        iu = iu if iu < n else BIG; idn = idn if idn < n else BIG
        if iu == idn: continue
        k = min(iu, idn); d = -1 if iu < idn else 1
        if k >= ko and k >= ci: continue
        reo = bool(RO[k]); ks = k + 1 if reo else k
        if ks >= n - 1 or ks >= cut: continue
        ent = C[k] if reo else (max(U, O[k]) if d < 0 else min(Dn, O[k])); dist = abs(ent - B)
        adv = np.maximum.accumulate((H[ks:] - ent) if d < 0 else (ent - L[ks:]))
        si = np.searchsorted(adv, SK * w) + ks; si = np.where((si >= n) | (SK == 0), BIG, si)
        lvl = ent + SK * w if d < 0 else ent - SK * w; sic = np.minimum(si, n - 1)
        ps = np.where(si == k, lvl, np.maximum(lvl, Os[sic]) if d < 0 else np.minimum(lvl, Os[sic]))
        T = ent - dist * FR if d < 0 else ent + dist * FR
        if d < 0: fav = np.minimum.accumulate(L[k + 1:]); til = np.searchsorted(-fav, -T) + k + 1
        else: fav = np.maximum.accumulate(H[k + 1:]); til = np.searchsorted(fav, T) + k + 1
        til = np.where(til >= n, BIG, til); tic = np.minimum(til, n - 1)
        ptl = np.minimum(T, O[tic]) if d < 0 else np.maximum(T, O[tic])
        cert = (~np.bool_(reo)) & ((C[k] <= T) if d < 0 else (C[k] >= T))
        tt = np.minimum(np.array([n] + [int(np.searchsorted(M, M[k] + tm)) for tm in TM[1:]]), cut); pt = np.where(tt < n, O[np.minimum(tt, n - 1)], C[-1])
        # 順張り：同じ足で重なったら順張りに不利な側（＝逆張りの利確水準＝順張りの損切り）を先とする
        SI = si[None, :, None]; TIB = np.broadcast_to(np.where(cert, k, til)[:, None, None], (len(FR), len(SK), 1)); TT = tt[None, None, :]
        PT_tp = np.where(TIB == k, T[:, None, None], ptl[:, None, None])
        rtf = (TIB <= SI) & (TIB < TT); stf = (~rtf) & (SI < TT)
        px = np.where(rtf, PT_tp, np.where(stf, ps[None, :, None], pt[None, None, :]))
        Y.append((-d * (px - ent) / B * 100).astype(np.float16).ravel())
        TIBb = np.broadcast_to(TIB, rtf.shape); IDX = np.where(rtf, TIBb, np.where(stf, np.broadcast_to(SI, rtf.shape), np.broadcast_to(TT, rtf.shape)))
        TYP = np.where(rtf, 1, np.where(stf, 0, np.where(np.broadcast_to(TT, rtf.shape) < n, 2, 3))); IDX = np.where(TYP == 3, n - 1, IDX)
        EX.append(((IDX - k) * 4 + TYP).astype(np.int16).ravel()); GK.append(a + k); EP.append(ent)
        E.append((len(EV) - 1, x, M[k], d, k < ko, reo, M[k] >= m1))
Y = np.vstack(Y); en = pd.DataFrame(E, columns=['ev', 'x', 'm', 'd', 'closed', 'reo', 'is1m']); ev = pd.DataFrame(EV, columns=['i', 't0', 'kind', 'long', 'B', 'pend', 'qm0', 'res'])
np.save(sys.argv[5] + '/EX.npy', np.vstack(EX)); en['gk'] = np.array(GK, np.int64); en['entp_'] = np.array(EP, float); np.save(sys.argv[5] + '/Y.npy', Y); en.to_pickle(sys.argv[5] + '/en.pkl'); ev.to_pickle(sys.argv[5] + '/evt.pkl')
print('entries', Y.shape, 'events', len(ev), '1分足のエントリー', int(en.is1m.sum()), 'MB', Y.nbytes / 1e6)
