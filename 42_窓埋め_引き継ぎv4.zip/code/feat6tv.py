# v5のエントリー（1分足対応）に指標を付ける。指標は5分足CFDから、各時間足で確定済みの足だけを使う
import sys, pandas as pd, numpy as np
sys.path.insert(0, sys.argv[1]); import ld, indlib
d = sys.argv[5]; en = pd.read_pickle(d + '/en.pkl'); ev = pd.read_pickle(d + '/evt.pkl')
c5 = ld.bars(sys.argv[2], until='2026-10-09'); c1 = ld.bars(sys.argv[3], until='2026-10-09'); f = None
m1 = c1.m.iloc[0]; c = pd.concat([c5[c5.m + 5 <= m1], c1], ignore_index=True)
x = c5.rename(columns={'open': 'o', 'high': 'h', 'low': 'l', 'close': 'c'})[['m', 'o', 'h', 'l', 'c']].copy(); x['m'] = x.m.astype('int64')
F = en[['m']].copy(); F['m'] = F.m.astype('int64'); F['row'] = np.arange(len(F)); F = F.sort_values('m')
_dk4 = (x.m + 120) // 1440; _st4 = x.groupby(_dk4).m.transform('min'); _bn4 = (x.m - _st4) // 240; _K4 = _dk4 * 100 + _bn4
_AV4 = pd.Series((_st4 + (_bn4 + 1) * 240).values, index=_K4.values).groupby(level=0).first()
agg = dict(o=('o', 'first'), h=('h', 'max'), l=('l', 'min'), c=('c', 'last')); dayk = (x.m + 120) // 1440
tfs = [('5m', x.m // 5, lambda k: (k + 1) * 5, [20, 25, 75, 100, 200]), ('15m', x.m // 15, lambda k: (k + 1) * 15, [20, 25, 75, 100, 200]), ('60m', x.m // 60, lambda k: (k + 1) * 60, [20, 25, 75, 100, 200]),
       ('4h', _K4, lambda k: _AV4.loc[k].values, [20, 25, 75, 100, 200]), ('D', dayk, lambda k: (k + 1) * 1440 - 120, [20, 25, 75, 100, 200, 13, 26]), ('W', (dayk + 3) // 7, lambda k: ((k + 1) * 7 - 3) * 1440 - 120, [20, 25, 75, 100, 13, 26])]
parts = []
for name, key, av, mas in tfs:
    b = x.groupby(key).agg(**agg); i = indlib.ind(b, mas); i.columns = [k + '_' + name for k in i.columns]
    i['avail'] = av(b.index.values); i = i.sort_values('avail')
    if name == 'D': prevD = pd.DataFrame({'avail': av(b.index.values), 'pdh': b.h.values, 'pdl': b.l.values}).sort_values('avail')
    F = pd.merge_asof(F, i, left_on='m', right_on='avail', direction='backward').drop(columns='avail')
F = pd.merge_asof(F, prevD, left_on='m', right_on='avail', direction='backward').drop(columns='avail')
F = F.sort_values('row').set_index('row'); F.index = en.index
s = -en.d.values; NOND = ('adx', 'atr')
for k in list(F.columns):
    if k not in ('m', 'pdh', 'pdl') and k.split('_')[0] not in NOND: F[k] = F[k] * s
e = ev.loc[en.ev.values]; B = e.B.values; ent = en.ent.values if 'ent' in en else None
# 前セッション情報（v2の事象表）
pm0 = pd.read_pickle(sys.argv[4]).set_index('i').reindex(e.i.values)
X = {}
X['前セッション騰落'] = (B - pm0.po.values) / B * 100 * s; X['前セッション値幅'] = (pm0.ph.values - pm0.pl.values) / B * 100; X['引け前60分'] = (B - pm0.c60.values) / B * 100 * s
pos = (B - pm0.pl.values) / np.maximum(pm0.ph.values - pm0.pl.values, 1e-9); X['引け位置'] = np.where(s > 0, pos, 1 - pos)
X['平均値幅20'] = pm0.sig.values * 100; X['経過分'] = (en.m.values - e.pend.values).astype(float)
# 追加：エントリー価格（乖離幅ちょうどと近似）から前日高安・節目までの距離
entp = B * (1 + s * en.x.values / 100)
ext = np.where(s > 0, F.pdh.values, F.pdl.values); X['前日高安まで'] = (ext - entp) / B * 100 * s      # プラス＝まだ手前、マイナス＝越えている
X['節目まで'] = np.minimum(entp % 1000, 1000 - entp % 1000) / B * 100; X['節目を越えた'] = (np.floor(B / 1000) != np.floor(entp / 1000)).astype(float)
# 追加：先物停止中（引け〜エントリー時点まで、ただし先物寄りまで）のCFD値幅、寄り時の窓
cm = c.m.values; ch = c.high.values; cl = c.low.values; co = c.open.values
a0 = np.searchsorted(cm, e.pend.values); a1 = np.searchsorted(cm, np.minimum(en.m.values, e.qm0.values))
rng = np.full(len(en), np.nan)
for i_, (u, v) in enumerate(zip(a0, a1)):
    if v > u: rng[i_] = (ch[u:v].max() - cl[u:v].min()) / B[i_] * 100
X['停止中値幅'] = rng
ko = np.searchsorted(cm, e.qm0.values); gap = (co[np.minimum(ko, len(co) - 1)] - B) / B * 100 * s; X['寄り時の窓'] = np.where(en.closed.values, np.nan, gap)
t = pd.to_datetime(en.m.values * 60, unit='s', utc=True).tz_convert('Asia/Tokyo')
X['曜日'] = t.dayofweek.astype(float); X['時'] = t.hour.astype(float); X['寄り後'] = (~en.closed.values).astype(float); X['上に離れた'] = (s > 0).astype(float)
F = pd.concat([F.drop(columns=['m', 'pdh', 'pdl']), pd.DataFrame(X, index=F.index)], axis=1).astype('float32'); F.to_pickle(d + '/F6.pkl')
print(F.shape, 'NaN率上位', F.isna().mean().sort_values().tail(5).round(3).to_dict())
print(F[['前日高安まで', '節目まで', '節目を越えた', '停止中値幅', '寄り時の窓', '経過分']].describe().round(3).to_string())
