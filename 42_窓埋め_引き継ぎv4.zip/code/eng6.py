# v6：先物基準の窓（信号は先物、売買はCFD）。逆張り・順張りを同時に計算
#   基準 = 前セッションの先物の終値（最後の足の終値）
#   判定は先物の寄りから。寄りで既に乖離幅x%以上（窓と同じ向き）なら寄りで入る（CFDの寄り時刻の足の始値）
#   寄り後に基準から窓と同じ向きにx%届いたら、その先物の足が終わった時刻のCFDの足の始値で入る
#   届く前に基準まで戻ったら（同じ足で両方なら）その窓は入らない
#   利確・損切りは CFDのエントリー価格からの割合の距離で、CFDの価格で判定
#     逆張り：利確 = 窓までの距離（先物の基準からの乖離%）× FR、損切り = 乖離幅 × SK（0=なし）
#     順張り：損切り = 基準方向への戻り FR、利確 = 乖離幅 × SK（0=なし）
#     同じ足で両方に届いたら、その戦略に不利な側
#   時間切れ0 = その先物セッションの引け（夜間引け6:00の時期は5:55の足の始値）
#   先物は2023/10以降1分足、それ以前5分足。CFDは2020/11以降1分足、それ以前5分足
#   使い方: python eng6.py <codeフォルダ> 先物5分 先物1分 CFD5分 CFD1分 出力フォルダ
import sys, pandas as pd, numpy as np
sys.path.insert(0, sys.argv[1]); import ld
U = '2026-10-09'
f5 = ld.bars(sys.argv[2], until=U); f1 = ld.bars(sys.argv[3], until=U); c5 = ld.bars(sys.argv[4], until=U); c1 = ld.bars(sys.argv[5], until=U); OUT = sys.argv[6]
# 先物：1分足は最初の完全なセッション（翌営業日の朝）から
f1 = f1[f1.t >= pd.Timestamp('2023-10-16 08:45', tz='Asia/Tokyo')]; fm1 = f1.m.iloc[0]
fx = pd.concat([f5[f5.m < fm1], f1], ignore_index=True); fx['tf'] = np.where(fx.m < fm1, 5, 1)
cm1 = c1.m.iloc[0]; c = pd.concat([c5[c5.m + 5 <= cm1], c1], ignore_index=True)
ro_all = (c.m.diff() > 30).values; cm = c.m.values; co = c.open.values; ch = c.high.values; cl = c.low.values; cc = c.close.values
fm = fx.m.values; fo = fx.open.values; fh = fx.high.values; fl = fx.low.values; ftf = fx.tf.values
# セッションは先物5分足で判定（従来と同じ）
f = f5.copy(); f['sid'] = (f.m.diff() > 15).cumsum()
s = f.groupby('sid').agg(m0=('m', 'first'), m1=('m', 'last'), n=('m', 'size'), t0=('t', 'first'), cl=('close', 'last')); lh = f.groupby('sid').t.last().dt.strftime('%H:%M')
s['end'] = np.where(lh.isin(['15:15', '15:45', '05:30', '06:00']), s.m1, s.m1 + 5); s['kind'] = np.where(s.t0.dt.hour.between(8, 9), 'D', 'N'); s['lh'] = lh; s = s.reset_index(drop=True)
XP = np.array([.03, .04, .05, .06, .075, .09, .1, .11, .125, .14, .15, .175, .2, .225, .25, .275, .3, .35, .4, .45, .5, .6, .7, .8, .9, 1.0, 1.2, 1.5])
FR = np.array([.1, .2, .3, .4, .5, .6, .7, .8, .9, 1.0, 1.25, 1.5]); SK = np.array([0, .1, .2, .3, .4, .5, .6, .75, .9, 1, 1.25, 1.5, 2, 2.5, 3, 4, 5, 6])
TM = np.array([0, 15, 30, 60, 90, 120, 180, 240, 360]); BIG = 10**9
YR = []; YT = []; E = []; EV = []; XR = []; XT = []   # 決済の位置（(足の番号−エントリーの足)×4＋種類 0=SK水準 1=FR水準 2=時間 3=最後の足の終値）
def first_ge(cummax_arr, lv):
    i = np.searchsorted(cummax_arr, lv); return np.where(i >= len(cummax_arr), BIG, i)
for i in range(1, len(s)):
    p, q = s.iloc[i - 1], s.iloc[i]
    if not (p.n >= 24 and q.n >= 24 and p.kind != q.kind): continue
    Bf = p.cl; lng = (q.m0 - p.end) > (80 if p.kind == 'D' else 200)
    a = np.searchsorted(fm, q.m0); b = np.searchsorted(fm, q.end)        # 寄り〜引け（引けの板寄せ足は除く）
    if b - a < 6 or fm[a] != q.m0: continue
    g = fo[a] - Bf
    if g == 0: continue
    up = g > 0; gp = abs(g) / Bf * 100
    FH = fh[a:b]; FL = fl[a:b]; FM = fm[a:b]; FT = ftf[a:b]
    fz = np.nonzero(FL <= Bf)[0] if up else np.nonzero(FH >= Bf)[0]; fi = fz[0] if len(fz) else BIG   # 基準まで戻った足
    ce = np.searchsorted(cm, q.end); cut_m = q.end - 5 if (q.kind == 'N' and q.lh == '06:00') else None
    EV.append((i, q.t0, p.kind + '>' + q.kind, lng, Bf, p.end, q.m0, g, gp)); evn = len(EV) - 1
    rmax = np.maximum.accumulate(FH); rmin = np.minimum.accumulate(FL)
    for x in XP:
        Lx = Bf * (1 + x / 100) if up else Bf * (1 - x / 100)
        if gp >= x: r = -1; tm_ent = q.m0; fdist = gp                          # 寄りで既に届いている
        else:
            r = np.searchsorted(rmax, Lx) if up else np.searchsorted(-rmin, -Lx)
            if r >= len(FH) or fi <= r: continue                                # 届かない／先に（同じ足で）基準まで戻った
            tm_ent = FM[r] + FT[r]; fdist = x
        if cut_m is not None and tm_ent >= cut_m: continue
        k = np.searchsorted(cm, tm_ent)
        if k >= ce - 1 or cm[k] - tm_ent > 5: continue
        e = ce; H = ch[k:e]; L = cl[k:e]; O = co[k:e]; C = cc[k:e]; M = cm[k:e]; RO = ro_all[k:e].copy(); RO[0] = ro_all[k]; n = e - k
        reo = bool(RO[0]); ent = C[0] if reo else O[0]; s0 = 1 if reo else 0
        if s0 >= n - 1: continue
        Hd = np.where(RO, C, H); Ld = np.where(RO, C, L); Os = np.where(RO, C, O)
        w = ent * x / 100; dist = ent * fdist / 100
        # 逆張りの向きで考える（窓が上 → 売り）。adv = 逆張りに不利な動き、fav = 逆張りに有利な動き
        adv = np.maximum.accumulate((Hd[s0:] - ent) if up else (ent - Ld[s0:])); fav = np.maximum.accumulate((ent - Ld[s0:]) if up else (Hd[s0:] - ent))
        si = first_ge(adv, SK * w) + s0; si = np.where((si >= BIG) | (SK == 0), BIG, si)
        ti = first_ge(fav, FR * dist) + s0
        lvS = ent + SK * w if up else ent - SK * w; lvT = ent - FR * dist if up else ent + FR * dist
        sic = np.minimum(si, n - 1); tic = np.minimum(ti, n - 1)
        pS = np.where(si == s0, lvS, np.maximum(lvS, Os[sic]) if up else np.minimum(lvS, Os[sic]))      # 窓をあけて飛んだら始値（不利側）
        pT = np.where(ti == s0, lvT, np.minimum(lvT, Os[tic]) if up else np.maximum(lvT, Os[tic]))      # 有利側に飛んだら始値
        cut = int(np.searchsorted(M, cut_m)) if cut_m is not None else n
        tt = np.minimum(np.array([n] + [int(np.searchsorted(M, M[0] + tm)) for tm in TM[1:]]), cut); pt = np.where(tt < n, O[np.minimum(tt, n - 1)], C[-1])
        SI = si[None, :, None]; TI = ti[:, None, None]; TT = tt[None, None, :]
        sgn = -1 if up else 1                                                    # 逆張りの損益の向き
        # 逆張り：同じ足なら損切り先
        st = (SI <= TI) & (SI < TT); tp = (~st) & (TI < TT)
        px = np.where(st, pS[None, :, None], np.where(tp, pT[:, None, None], pt[None, None, :]))
        YR.append((sgn * (px - ent) / ent * 100).astype(np.float16).ravel())
        sh = st.shape; TTb = np.broadcast_to(TT, sh); SIb = np.broadcast_to(SI, sh); TIb = np.broadcast_to(TI, sh)
        typ = np.where(st, 0, np.where(tp, 1, np.where(TTb < n, 2, 3))); idx = np.where(st, SIb, np.where(tp, TIb, np.where(TTb < n, TTb, n - 1))); XR.append((idx * 4 + typ).astype(np.int16).ravel())
        # 順張り：同じ足なら（逆張りの利確水準＝順張りの損切り）先
        rt = (TI <= SI) & (TI < TT); stf = (~rt) & (SI < TT)
        px = np.where(rt, pT[:, None, None], np.where(stf, pS[None, :, None], pt[None, None, :]))
        YT.append((-sgn * (px - ent) / ent * 100).astype(np.float16).ravel())
        sh = rt.shape; TTb = np.broadcast_to(TT, sh); SIb = np.broadcast_to(SI, sh); TIb = np.broadcast_to(TI, sh)
        typ = np.where(rt, 1, np.where(stf, 0, np.where(TTb < n, 2, 3))); idx = np.where(rt, TIb, np.where(stf, SIb, np.where(TTb < n, TTb, n - 1))); XT.append((idx * 4 + typ).astype(np.int16).ravel())
        E.append((evn, x, M[0], -1 if up else 1, r < 0, reo, ent, fdist, tm_ent - q.m0, k))
en = pd.DataFrame(E, columns=['ev', 'x', 'm', 'd', 'atopen', 'reo', 'ent', 'fdist', '寄りから分', 'gk']); en['closed'] = False
ev = pd.DataFrame(EV, columns=['i', 't0', 'kind', 'long', 'B', 'pend', 'qm0', 'gap', 'gap%'])
import os
for nm, Y, X_ in (('R6', YR, XR), ('T6', YT, XT)):
    os.makedirs(OUT + '/' + nm, exist_ok=True); np.save(OUT + '/' + nm + '/Y.npy', np.vstack(Y)); np.save(OUT + '/' + nm + '/EX.npy', np.vstack(X_)); en.to_pickle(OUT + '/' + nm + '/en.pkl'); ev.to_pickle(OUT + '/' + nm + '/evt.pkl')
print('entries', len(en), 'events', len(ev), '寄りで入る', int(en.atopen.sum()), ev.kind.value_counts().to_dict())
