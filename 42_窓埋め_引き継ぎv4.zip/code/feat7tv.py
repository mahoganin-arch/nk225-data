# 追加の指標（F7）。F6と同じく、エントリー時刻までに確定した足だけを使い、向きのある指標は「窓と同じ向き（さらに離れる側）＝プラス」にそろえる
#   使い方: python feat7.py <codeフォルダ> <データフォルダ> <nk225-dataフォルダ> <OUT2/evt.pkl> <cal.pkl> <出力フォルダ（en.pkl, evt.pkl がある）>
#   ① 一目の位置関係（15分〜週足）：基準とエントリーの間にある線の数、エントリー価格の雲位置、雲の厚さ、先の雲の向き、ねじれ前、遅行スパン
#   ② 平均足の形（60分〜週足）：実体の割合、ヒゲなし（強い形）
#   ③ 価格の節目：前日終値、前週・前月の高安終値、20日・60日の高安、ピボット、SQ値（先物のSQ日の寄り値で近似）、キリ番（250・500・250/750のみ）
#   ④ 出来高：先物日足（全期間）の出来高比、1時間足（2022/12/30以降）の前セッション最後の1時間の出来高比・価格帯別出来高（直近10日、100円刻み）
#   ⑤ 相場の状態：窓÷ATR、窓の大きさの直近順位、停止中値幅÷ATR、前セッションの形、直近20窓の埋まり率、同じ向きの窓の連続、前セッション値幅比、
#      ボリンジャー、ストキャスティクス、CCI、N本の高安の中の位置、実現ボラの比
#   ⑥ 時期：月の何週目、四半期末月、年末年始、決算期、配当権利前後、米国夏時間
import sys, glob, datetime as dt, pandas as pd, numpy as np
sys.path.insert(0, sys.argv[1]); import ld
DATA, REPO, EVT2, CAL, d = sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6]
U = '2026-10-09'
en = pd.read_pickle(d + '/en.pkl'); ev = pd.read_pickle(d + '/evt.pkl'); e = ev.loc[en.ev.values].reset_index(drop=True)
s = -en.d.values.astype(float); B = e.B.values; M = en.m.values.astype('int64')
entp = en.ent.values if 'ent' in en else B * (1 + s * en.x.values / 100)
c5 = ld.bars(DATA + '/c5.csv', until=U); c1 = ld.bars(DATA + '/c1.csv', until=U); f5 = ld.bars(DATA + '/f5.csv', until=U)
x = c5.rename(columns={'open': 'o', 'high': 'h', 'low': 'l', 'close': 'c'})[['m', 'o', 'h', 'l', 'c']].copy(); x['m'] = x.m.astype('int64')
dayk = (x.m + 120) // 1440
_dk4 = (x.m + 120) // 1440; _st4 = x.groupby(_dk4).m.transform('min'); _bn4 = (x.m - _st4) // 240; _K4 = _dk4 * 100 + _bn4
_AV4 = pd.Series((_st4 + (_bn4 + 1) * 240).values, index=_K4.values).groupby(level=0).first()
TFS = {'5m': (x.m // 5, lambda k: (k + 1) * 5), '15m': (x.m // 15, lambda k: (k + 1) * 15), '60m': (x.m // 60, lambda k: (k + 1) * 60), '4h': (_K4, lambda k: _AV4.loc[k].values),
       'D': (dayk, lambda k: (k + 1) * 1440 - 120), 'W': ((dayk + 3) // 7, lambda k: ((k + 1) * 7 - 3) * 1440 - 120)}
agg = dict(o=('o', 'first'), h=('h', 'max'), l=('l', 'min'), c=('c', 'last'))
BARS = {}
for k, (key, av) in TFS.items():
    b = x.groupby(key).agg(**agg); b['avail'] = av(b.index.values); BARS[k] = b.sort_values('avail').reset_index(drop=True)
order = np.argsort(M); X = {}
def asof(df, cols):
    """df（avail列つき）の値を各エントリー時刻（M）に合わせる"""
    r = pd.merge_asof(pd.DataFrame({'m': M[order]}), df[['avail'] + cols].dropna(subset=['avail']), left_on='m', right_on='avail', direction='backward')
    out = {}
    for c_ in cols:
        v = np.full(len(M), np.nan); v[order] = r[c_].values; out[c_] = v
    return out
between = lambda L: ((L - B) * (L - entp) < 0).astype(float)                   # 基準とエントリーの間にある
ahead = lambda L: (L - entp) / B * 100 * s                                       # プラス＝まだ先（窓の向き）、マイナス＝越えた
# ---------- ① 一目
for k in ('15m', '60m', '4h', 'D', 'W'):
    b = BARS[k].copy(); h, l, c = b.h, b.l, b.c; mid = lambda n: (h.rolling(n).max() + l.rolling(n).min()) / 2
    tk, kj = mid(9), mid(26); sa = ((tk + kj) / 2).shift(26); sb = mid(52).shift(26); saf = (tk + kj) / 2; sbf = mid(52)
    b['tk'] = tk; b['kj'] = kj; b['top'] = np.maximum(sa, sb); b['bot'] = np.minimum(sa, sb); b['tw'] = np.sign(sa - sb); b['twf'] = np.sign(saf - sbf); b['chi'] = (c - c.shift(26)) / c * 100; b['cc'] = c
    A = asof(b, ['tk', 'kj', 'top', 'bot', 'tw', 'twf', 'chi', 'cc'])
    X['一目線またぎ数_' + k] = sum(np.nan_to_num(between(A[q])) for q in ('tk', 'kj', 'top', 'bot')); X['一目線またぎ数_' + k][np.isnan(A['bot'])] = np.nan
    X['エントリー雲位置_' + k] = np.where(np.isnan(A['bot']), np.nan, np.where(entp > A['top'], 1.0, np.where(entp < A['bot'], -1.0, 0.0)) * s)
    X['雲の厚さ_' + k] = (A['top'] - A['bot']) / A['cc'] * 100; X['先の雲の向き_' + k] = A['twf'] * s; X['ねじれ前_' + k] = np.where(np.isnan(A['tw']) | np.isnan(A['twf']), np.nan, (A['tw'] != A['twf']).astype(float))
    X['遅行スパン_' + k] = A['chi'] * s
# ---------- ② 平均足の形
for k in ('60m', '4h', 'D', 'W'):
    b = BARS[k].copy(); hc = ((b.o + b.h + b.l + b.c) / 4).values; ho = np.empty(len(b)); ho[0] = (b.o.iloc[0] + b.c.iloc[0]) / 2
    for i in range(1, len(b)): ho[i] = (ho[i - 1] + hc[i - 1]) / 2
    hh = np.maximum.reduce([b.h.values, ho, hc]); hl = np.minimum.reduce([b.l.values, ho, hc]); col = np.sign(hc - ho)
    b['body'] = np.abs(hc - ho) / np.maximum(hh - hl, 1e-9); b['strong'] = np.where((col > 0) & (hl >= ho - 1e-9), 1.0, np.where((col < 0) & (hh <= ho + 1e-9), -1.0, 0.0))
    A = asof(b, ['body', 'strong']); X['平均足実体比_' + k] = A['body']; X['平均足ヒゲなし_' + k] = A['strong'] * s
# ---------- ③ 価格の節目
dd = x.groupby(dayk).agg(**agg); dd['avail'] = (dd.index.values + 1) * 1440 - 120
dd['pdc'] = dd.c; dd['h20'] = dd.h.rolling(20).max(); dd['l20'] = dd.l.rolling(20).min(); dd['h60'] = dd.h.rolling(60).max(); dd['l60'] = dd.l.rolling(60).min()
P_ = (dd.h + dd.l + dd.c) / 3; dd['P'] = P_; dd['R1'] = 2 * P_ - dd.l; dd['S1'] = 2 * P_ - dd.h; dd['R2'] = P_ + dd.h - dd.l; dd['S2'] = P_ - dd.h + dd.l
A = asof(dd.reset_index(drop=True), ['pdc', 'h20', 'l20', 'h60', 'l60', 'P', 'R1', 'S1', 'R2', 'S2'])
X['前日終値まで'] = ahead(A['pdc'])
X['20日高安まで'] = np.where(s > 0, ahead(A['h20']), ahead(A['l20'])); X['60日高安まで'] = np.where(s > 0, ahead(A['h60']), ahead(A['l60']))
PV = np.vstack([A[q] for q in ('S2', 'S1', 'P', 'R1', 'R2')]); X['ピボットまたぎ数'] = np.where(np.isnan(PV).any(0), np.nan, between(PV).sum(0))
dist = np.where(((PV - entp) * s) > 0, np.abs(PV - entp), np.inf).min(0); X['先のピボットまで'] = np.where(np.isfinite(dist), dist / B * 100, np.nan)
wk = x.groupby(TFS['W'][0]).agg(**agg); wk['avail'] = TFS['W'][1](wk.index.values); A = asof(wk.reset_index(drop=True), ['h', 'l', 'c'])
X['前週高安まで'] = np.where(s > 0, ahead(A['h']), ahead(A['l'])); X['前週安高まで'] = np.where(s > 0, ahead(A['l']), ahead(A['h'])); X['前週終値まで'] = ahead(A['c'])
dts = pd.to_datetime(dd.index.values * 1440 * 60 + 16 * 3600, unit='s'); mk = dts.year * 12 + dts.month - 1
mo = dd.groupby(mk.values).agg(h=('h', 'max'), l=('l', 'min'), c=('c', 'last'), avail=('avail', 'last')); A = asof(mo.reset_index(drop=True), ['h', 'l', 'c'])
X['前月高安まで'] = np.where(s > 0, ahead(A['h']), ahead(A['l'])); X['前月終値まで'] = ahead(A['c'])
LV = np.vstack([X[q] for q in ('前日終値まで', '前週終値まで', '前月終値まで')] + [ahead(A['h']), ahead(A['l'])]); X['またいだ節目数(終値・高安)'] = np.nansum(LV < 0, 0).astype(float)
# SQ値（先物のSQ日の8:45の始値で近似、11:00から使う）
cal = pd.read_pickle(CAL); lib, nodata = cal['lib'], cal['nodata']
def isbiz(z): return z.weekday() < 5 and z not in nodata and not (z > dt.date(2026, 10, 8) and z in lib)
def sqdate(y, m_):
    first = dt.date(y, m_, 1); z = first + dt.timedelta(days=(4 - first.weekday()) % 7 + 7)
    while not isbiz(z): z -= dt.timedelta(days=1)
    return z
f5['date'] = f5.t.dt.date; f5['hm'] = f5.t.dt.strftime('%H:%M'); sq = []
for y in range(2016, 2027):
    for m_ in range(1, 13):
        z = sqdate(y, m_); r = f5[(f5.date == z) & (f5.hm == '08:45')]
        if len(r): sq.append((int(r.m.iloc[0]) + 135, float(r.open.iloc[0]), m_ in (3, 6, 9, 12)))
sq = pd.DataFrame(sq, columns=['avail', 'v', 'major']); A = asof(sq, ['v']); X['SQ値まで'] = ahead(A['v']); X['SQ値をまたいだ'] = between(A['v'])
A = asof(sq[sq.major].reset_index(drop=True), ['v']); X['メジャーSQ値まで'] = ahead(A['v'])
# キリ番
for u, nm in ((250, '250'), (500, '500')):
    X['キリ%sまで' % nm] = np.minimum(entp % u, u - entp % u) / B * 100; X['キリ%sを越えた' % nm] = (np.floor(B / u) != np.floor(entp / u)).astype(float)
q = (entp - 250) % 500; X['キリ250・750のみまで'] = np.minimum(q, 500 - q) / B * 100; X['キリ250・750のみを越えた'] = (np.floor((B - 250) / 500) != np.floor((entp - 250) / 500)).astype(float)
# ---------- ④ 出来高
fd = pd.read_csv(glob.glob(REPO + '/OSE_NK225M1!, 1D 6.csv')[0]); fd['date'] = pd.to_datetime(fd.time, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.date
fd['t0'] = fd.time; fd = fd.groupby('date').agg(v=('Volume', 'sum'), t0=('t0', 'first')).reset_index(); fd['r20'] = fd.v / fd.v.shift(1).rolling(20).mean(); fd['r5'] = fd.v / fd.v.shift(1).rolling(5).mean()
# TradingViewの日足（OSE）は、その日の夜間＋翌日の日中で1本（時刻はその日の夜間の寄り）。確定は翌日の日中の引け → 次の足の始まりから使う
fd['avail'] = fd.t0.shift(-1) // 60; fd = fd.dropna(subset=['avail']).copy(); fd['avail'] = fd['avail'].astype('int64'); A = asof(fd, ['r20', 'r5']); X['日足出来高比20'] = A['r20']; X['日足出来高比5'] = A['r5']
f3 = pd.read_csv(glob.glob(REPO + '/OSE_NK225M1!, 3.csv')[0]); f3['m'] = (f3.time // 60).astype('int64'); f3 = f3[f3.m < int(pd.Timestamp(U, tz='Asia/Tokyo').timestamp() // 60)].sort_values('m').reset_index(drop=True)
m3 = f3.m.values; v3 = f3.Volume.values.astype(float); p3 = ((f3.high + f3.low + f3.close) / 3).values.astype(float)   # 「, 3」のファイルは1時間足（2022/12/30〜）
ev2 = pd.read_pickle(EVT2).set_index('i'); pm0 = ev2.pm0.reindex(ev.i.values).values
late = np.full(len(ev), np.nan); poc = np.full(len(ev), np.nan); hvn_hi = np.full(len(ev), np.nan); hvn_lo = np.full(len(ev), np.nan)
for j, (pe, p0) in enumerate(zip(ev.pend.values, pm0)):
    if pe < m3[0] + 7 * 1440 or np.isnan(p0): continue
    a = np.searchsorted(m3, p0); b_ = np.searchsorted(m3, pe)
    if b_ - a >= 5:
        vv = v3[a:b_]; late[j] = vv[-1] / vv.mean()                                          # 前セッション最後の1時間足の出来高 ÷ セッション平均
    a5 = np.searchsorted(m3, pe - 10 * 1440)                                                  # 直近10日（暦日）の1時間足
    if b_ - a5 >= 60:
        bins_ = np.floor(p3[a5:b_] / 100) * 100; df_ = pd.Series(v3[a5:b_]).groupby(bins_).sum(); poc[j] = df_.idxmax() + 50
        thr = df_.quantile(.8); hv = df_.index.values[df_.values >= thr] + 50; hvn_hi[j] = hv.max(); hvn_lo[j] = hv.min()
evi = en.ev.values
X['前セッション最後1時間の出来高比'] = late[evi]; X['出来高最多価格まで'] = ahead(poc[evi]); X['出来高最多価格をまたいだ'] = np.where(np.isnan(poc[evi]), np.nan, between(poc[evi]))
HV = np.where(s > 0, hvn_hi[evi], hvn_lo[evi]); X['出来高の多い価格帯の端まで'] = ahead(HV)
# ---------- ⑤ 相場の状態
F6 = pd.read_pickle(d + '/F6.pkl'); atrD = F6['atr_D'].values
X['寄り時の窓÷日ATR'] = F6['寄り時の窓'].values / atrD; X['停止中値幅÷日ATR'] = F6['停止中値幅'].values / atrD; X['乖離幅÷日ATR'] = en.x.values / atrD
ev2s = ev2.sort_values('pend'); ev2s['B_'] = ev2s.B
cm = c5.m.values.astype('int64'); ch = c5.high.values; cl_ = c5.low.values; co = c5.open.values
if len(c1):
    cA = pd.concat([c5[c5.m + 5 <= c1.m.iloc[0]], c1], ignore_index=True); cm = cA.m.values.astype('int64'); ch = cA.high.values; cl_ = cA.low.values; co = cA.open.values
gq = np.full(len(ev2s), np.nan); fill = np.full(len(ev2s), np.nan)
for j, (Bb, q0, qe) in enumerate(zip(ev2s.B.values, ev2s.qm0.values, ev2s.qend.values)):
    a = np.searchsorted(cm, q0); b_ = np.searchsorted(cm, qe)
    if b_ - a < 3: continue
    g = co[a] - Bb; gq[j] = g / Bb * 100
    fill[j] = float((cl_[a:b_].min() <= Bb) if g > 0 else (ch[a:b_].max() >= Bb)) if g != 0 else np.nan
ev2s['gq'] = gq; ev2s['fill'] = fill
ev2s['埋まり率20'] = pd.Series(fill, index=ev2s.index).shift(1).rolling(20, min_periods=15).mean().values
ag = np.abs(gq)
rk = np.full(len(ag), np.nan)
for j in range(60, len(ag)):
    w_ = ag[j - 60:j]; w_ = w_[~np.isnan(w_)]
    if len(w_) >= 40 and not np.isnan(ag[j]): rk[j] = (w_ < ag[j]).mean()
ev2s['窓順位60'] = rk
sg = np.sign(gq); run = np.zeros(len(sg))
for j in range(1, len(sg)): run[j] = (run[j - 1] + sg[j - 1]) if (j > 1 and sg[j - 1] == sg[j - 2]) else sg[j - 1]
ev2s['前の窓の連続'] = run; ev2s['前々セッション騰落'] = ((ev2s.B - ev2s.po) / ev2s.B * 100).shift(1).values; ev2s['前セッション値幅比'] = ((ev2s.ph - ev2s.pl) / (ev2s.ph - ev2s.pl).shift(1)).values
E2 = ev2s.reindex(ev.i.values)
X['直近20窓の埋まり率'] = E2['埋まり率20'].values[evi]; X['前の窓の連続(向き)'] = E2['前の窓の連続'].values[evi] * s; X['前々セッション騰落'] = E2['前々セッション騰落'].values[evi] * s
X['前セッション値幅比'] = E2['前セッション値幅比'].values[evi]
wr = np.where(en.closed.values, np.nan, E2['窓順位60'].values[evi]) if 'closed' in en else E2['窓順位60'].values[evi]; X['窓の大きさ順位60'] = wr
po = E2.po.values[evi]; ph = E2.ph.values[evi]; pl = E2.pl.values[evi]; Bp = E2.B.values[evi]; rg = np.maximum(ph - pl, 1e-9)
X['前セッション実体比'] = (Bp - po) / rg * s; X['前セッション向き側ヒゲ比'] = np.where(s > 0, ph - np.maximum(Bp, po), np.minimum(Bp, po) - pl) / rg; X['前セッション逆側ヒゲ比'] = np.where(s > 0, np.minimum(Bp, po) - pl, ph - np.maximum(Bp, po)) / rg
for k in ('15m', '60m', '4h', 'D'):
    b = BARS[k].copy(); c = b.c; h = b.h; l = b.l; ma = c.rolling(20).mean(); sd = c.rolling(20).std()
    b['bb'] = (c - ma) / sd; bw = 4 * sd / ma * 100; b['bwr'] = bw.rolling(120, min_periods=60).rank(pct=True)
    b['st'] = (c - l.rolling(14).min()) / (h.rolling(14).max() - l.rolling(14).min()).replace(0, np.nan) * 100 - 50
    tp = (h + l + c) / 3; md = tp.rolling(20).apply(lambda z: np.abs(z - z.mean()).mean(), raw=True); b['cci'] = (tp - tp.rolling(20).mean()) / (0.015 * md)
    b['p60'] = (c - l.rolling(60).min()) / (h.rolling(60).max() - l.rolling(60).min()).replace(0, np.nan) - .5
    A = asof(b, ['bb', 'bwr', 'st', 'cci', 'p60'])
    X['BBσ位置_' + k] = A['bb'] * s; X['BB幅順位_' + k] = A['bwr']; X['ストキャス_' + k] = A['st'] * s; X['CCI_' + k] = A['cci'] * s; X['60本高安の位置_' + k] = A['p60'] * s
for k, (ns, nl) in (('5m', (12, 288)), ('60m', (6, 120))):
    b = BARS[k].copy(); r = np.log(b.c).diff(); b['rv'] = r.rolling(ns).std() / r.rolling(nl).std(); X['実現ボラ比_' + k] = asof(b, ['rv'])['rv']
# ---------- ⑥ 時期
toD = lambda m_: pd.Timestamp(int(m_) * 60, unit='s', tz='Asia/Tokyo').date()
wd = np.array([toD(r.pend) if r.kind == 'D>N' else toD(r.qm0) for r in ev.itertuples()])[evi]
def bizdays(y, m_):
    z = dt.date(y, m_, 1); out = []
    while z.month == m_:
        if isbiz(z): out.append(z)
        z += dt.timedelta(days=1)
    return out
BD = {}
def bdays(y, m_):
    if (y, m_) not in BD: BD[(y, m_)] = bizdays(y, m_)
    return BD[(y, m_)]
def us_dst(z):
    y = z.year; s2 = dt.date(y, 3, 8); s2 += dt.timedelta(days=(6 - s2.weekday()) % 7); n1 = dt.date(y, 11, 1); n1 += dt.timedelta(days=(6 - n1.weekday()) % 7)
    return s2 <= z < n1
X['月の何週目'] = np.array([(z.day - 1) // 7 + 1 for z in wd], float); X['四半期末月'] = np.array([z.month in (3, 6, 9, 12) for z in wd], float)
X['年末年始'] = np.array([(z.month == 12 and z.day >= 20) or (z.month == 1 and z.day <= 10) for z in wd], float)
X['決算発表期'] = np.array([(z.month, z.day) >= (4, 20) and (z.month, z.day) <= (5, 20) or (z.month, z.day) >= (7, 20) and (z.month, z.day) <= (8, 15) or (z.month, z.day) >= (10, 20) and (z.month, z.day) <= (11, 15) or (z.month, z.day) >= (1, 20) and (z.month, z.day) <= (2, 15) for z in wd], float)
X['配当権利前後'] = np.array([(z.month in (3, 9) and z in bdays(z.year, z.month)[-5:]) or (z.month in (4, 10) and z in bdays(z.year, z.month)[:3]) for z in wd], float)
X['米国夏時間'] = np.array([us_dst(z) for z in wd], float)
F7 = pd.DataFrame(X, index=en.index).astype('float32'); F7.to_pickle(d + '/F7.pkl')
print(F7.shape); na = F7.isna().mean(); print('NaN率の高いもの', na[na > .2].round(2).to_dict())
