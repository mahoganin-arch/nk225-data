# 段階1-a：指標単独の新規発掘（乖離幅28×決済1,944）
import sys, time, numpy as np, pandas as pd, scipy.sparse as sp
sys.path.insert(0, sys.argv[1]); from common6 import *
d = sys.argv[2]; Y, en, F = load(d)
SEGS = [('D>N', ['D>N']), ('N>D', ['N>D']), ('両方の窓', ['D>N', 'N>D'])]
FEATS = [k for k in F.columns if k not in ('曜日', '時')]
ROWS = []; t0 = time.time()
for x in sorted(en.x.unique()):
    idx = np.nonzero((~en.long.values) & np.isclose(en.x.values, x))[0]
    if len(idx) < 40: continue
    sub = en.iloc[idx]; Yx = np.asarray(Y[idx], dtype=np.float32) / 100 * P; f = F.iloc[idx]; yi = sub.yr.values - 2017
    cells = []; rows = []; cols = []
    for k in FEATS:
        for lab, m in bins_for(f[k].values.astype(float), None):
            for sname, segs in SEGS:
                mm = m & np.isin(sub.kind.values, segs)
                if mm.sum() < 40: continue
                c = len(cells); cells.append((sname, k, lab)); e_ = np.nonzero(mm)[0]; rows.append(c * 10 + yi[e_]); cols.append(e_)
    rows = np.concatenate(rows); cols = np.concatenate(cols); nc = len(cells)
    M = sp.csr_matrix((np.ones(len(rows), np.float32), (rows, cols)), shape=(nc * 10, len(idx)))
    S = (M @ Yx).reshape(nc, 10, NCB); Q = (M @ (Yx * Yx)).reshape(nc, 10, NCB); W = (M @ (Yx > 0).astype(np.float32)).reshape(nc, 10, NCB)
    N = np.asarray(M.sum(1)).reshape(nc, 10)
    res = {}
    for h, sl in (('A', slice(0, 5)), ('B', slice(5, 10))):
        n = N[:, sl].sum(1); s = S[:, sl].sum(1); q = Q[:, sl].sum(1); w = W[:, sl].sum(1); mean = s / np.maximum(n, 1)[:, None]
        var = np.maximum(q / np.maximum(n, 1)[:, None] - mean ** 2, 1e-6); tt = mean / np.sqrt(var) * np.sqrt(np.maximum(n, 1))[:, None]
        ym = S[:, sl] / np.maximum(N[:, sl], 1)[:, :, None]; yp = ((ym > 0) & (N[:, sl] >= 3)[:, :, None]).sum(1); yn = (N[:, sl] >= 3).sum(1)
        pos = s.clip(min=None); res[h] = dict(n=n, mean=mean, win=w / np.maximum(n, 1)[:, None] * 100, t=tt, yp=yp, yn=yn, sh=(mean > 0).mean(1) * 100, ok=(n >= 20) & (yn >= 4))
    A, Bh = res['A'], res['B']
    sels = [('前半で最良', A['ok'][:, None] & (A['mean'] >= 20), A['mean']), ('後半で最良', Bh['ok'][:, None] & (Bh['mean'] >= 20), Bh['mean']),
            ('両方で最良', (A['ok'] & Bh['ok'])[:, None] & (A['mean'] >= 20) & (Bh['mean'] >= 20), np.minimum(A['mean'], Bh['mean'])),
            ('前半・高勝率', A['ok'][:, None] & (A['mean'] >= 20) & (A['win'] >= 80), A['mean']), ('後半・高勝率', Bh['ok'][:, None] & (Bh['mean'] >= 20) & (Bh['win'] >= 80), Bh['mean'])]
    for nm, okm, sc in sels:
        sc2 = np.where(okm, sc, -1e9); j = sc2.argmax(1)
        for c in np.nonzero(sc2[np.arange(nc), j] > -1e8)[0]:
            jj = j[c]; sname, k, lab = cells[c]
            ROWS.append((nm, sname, x, k, lab) + CB[jj] + tuple(v for h in (A, Bh) for v in (h['n'][c], h['mean'][c, jj], h['win'][c, jj], h['yp'][c, jj], h['yn'][c], float(pval(h['t'][c, jj])), h['sh'][c])) + (int(okm[c].sum()),))
    print('x', x, 'entries', len(idx), 'cells', nc, 'rows', len(ROWS), round(time.time() - t0), 's', flush=True)
cols = ['選び方', '窓', '乖離幅%', '指標', '区分', '利確', '損切り', '時間切れ'] + [h + c for h in ('前半', '後半') for c in ('件数', '平均', '勝率', 'プラス年', '年数', 'p', 'プラス決済%')] + ['基準を満たす決済数']
R = pd.DataFrame(ROWS, columns=cols); R.to_pickle(d + '/s1a.pkl'); print('rows', len(R), R['選び方'].value_counts().to_dict())
