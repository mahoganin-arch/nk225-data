# 段階2：2条件の組み合わせ。代表100決済で一次選考 → 通過したマスを1,944決済で詰め直す
import sys, time, itertools, numpy as np, pandas as pd, scipy.sparse as sp
sys.path.insert(0, sys.argv[1]); from common6 import *
d = sys.argv[2]; Y, en, F = load(d)
hr = F['時'].values; F = F.drop(columns=['時']); F['時間帯'] = np.select([(hr >= 5) & (hr <= 8), (hr >= 9) & (hr <= 11), (hr >= 12) & (hr <= 15), (hr >= 16) & (hr <= 18), (hr >= 19) & (hr <= 22)], [0, 1, 2, 3, 4], 5).astype(np.float32)
TBL = {0: '5-8時', 1: '9-11時', 2: '12-15時', 3: '16-18時', 4: '19-22時', 5: '23-4時'}
def theme2(k): return 'time' if k == '時間帯' else theme(k)
FEATS = list(F.columns); PAIRS = [(a, b) for a, b in itertools.combinations(FEATS, 2) if theme2(a) != theme2(b)]; print('組み合わせ', len(PAIRS))
REP = [CB.index(c) for c in itertools.product([.5, .8, 1.0, 1.25, 1.5], [0, .5, 1, 2, 3], [0, 60, 120, 240])]
SEGS = [('D>N', ['D>N']), ('N>D', ['N>D']), ('両方の窓', ['D>N', 'N>D'])]
def b3(v):
    ok = ~np.isnan(v); u = np.unique(v[ok])
    if len(u) <= 6: m = {x: i for i, x in enumerate(u)}; return np.array([m.get(x, -1) if x == x else -1 for x in v]), [('%g' % x) for x in u]
    q = np.nanquantile(v, [1 / 3, 2 / 3]); b = np.searchsorted(q, v, side='right'); b[~ok] = -1; return b, ['低', '中', '高']
def stats(S, Q, W, N):
    out = {}
    for h, sl in (('A', slice(0, 5)), ('B', slice(5, 10))):
        n = N[:, sl].sum(1); s = S[:, sl].sum(1); mean = s / np.maximum(n, 1)[:, None]; var = np.maximum(Q[:, sl].sum(1) / np.maximum(n, 1)[:, None] - mean ** 2, 1e-6)
        ym = S[:, sl] / np.maximum(N[:, sl], 1)[:, :, None]
        out[h] = dict(n=n, mean=mean, win=W[:, sl].sum(1) / np.maximum(n, 1)[:, None] * 100, t=mean / np.sqrt(var) * np.sqrt(np.maximum(n, 1))[:, None],
                      yp=((ym > 0) & (N[:, sl] >= 3)[:, :, None]).sum(1), yn=(N[:, sl] >= 3).sum(1), sh=(mean > 0).mean(1) * 100, ok=(n >= 20) & ((N[:, sl] >= 3).sum(1) >= 4))
    return out
def selmasks(A, Bh):
    return [('前半で最良', A['ok'][:, None] & (A['mean'] >= 20), A['mean']), ('後半で最良', Bh['ok'][:, None] & (Bh['mean'] >= 20), Bh['mean']),
            ('両方で最良', (A['ok'] & Bh['ok'])[:, None] & (A['mean'] >= 20) & (Bh['mean'] >= 20), np.minimum(A['mean'], Bh['mean'])),
            ('前半・高勝率', A['ok'][:, None] & (A['mean'] >= 20) & (A['win'] >= 80), A['mean']), ('後半・高勝率', Bh['ok'][:, None] & (Bh['mean'] >= 20) & (Bh['win'] >= 80), Bh['mean'])]
def run(M, Yx, nc):
    S = (M @ Yx).reshape(nc, 10, -1); Q = (M @ (Yx * Yx)).reshape(nc, 10, -1); W = (M @ (Yx > 0).astype(np.float32)).reshape(nc, 10, -1); N = np.asarray(M.sum(1)).reshape(nc, 10); return S, Q, W, N
COLS = ['選び方', '窓', '乖離幅%', '指標1', '区分1', '指標2', '区分2', '利確', '損切り', '時間切れ'] + [h + c for h in ('前半', '後半') for c in ('件数', '平均', '勝率', 'プラス年', '年数', 'p', 'プラス決済%')] + ['基準を満たす決済数']
ROWS = []; t0 = time.time(); npass = 0
for x in sorted(en.x.unique()):
    idx = np.nonzero((~en.long.values) & np.isclose(en.x.values, x))[0]
    if len(idx) < 60: continue
    sub = en.iloc[idx]; f = F.iloc[idx]; yi = sub.yr.values - 2017; Yfull = np.asarray(Y[idx], dtype=np.float32) / 100 * P; Yr = Yfull[:, REP]
    BB = {k: b3(f[k].values.astype(float)) for k in FEATS}; segm = {s: np.isin(sub.kind.values, g) for s, g in SEGS}
    passed = []
    for ch in range(0, len(PAIRS), 600):
        cells = []; rows = []; cols = []
        for a, b in PAIRS[ch:ch + 600]:
            ba, la = BB[a]; bb, lb = BB[b]; okp = (ba >= 0) & (bb >= 0); cid = ba * 8 + bb
            for sname, sm in segm.items():
                mm = okp & sm
                for c_ in np.unique(cid[mm]):
                    e_ = np.nonzero(mm & (cid == c_))[0].astype(np.int32)
                    if len(e_) < 40: continue
                    cells.append((sname, a, la[c_ // 8], b, lb[c_ % 8], e_)); c = len(cells) - 1; rows.append(c * 10 + yi[e_]); cols.append(e_)
        if not cells: continue
        nc = len(cells); M = sp.csr_matrix((np.ones(sum(map(len, cols)), np.float32), (np.concatenate(rows), np.concatenate(cols))), shape=(nc * 10, len(idx)))
        st = stats(*run(M, Yr, nc)); anyok = np.zeros(nc, bool)
        for _, okm, _ in selmasks(st['A'], st['B']): anyok |= okm.any(1)
        passed += [cells[i] for i in np.nonzero(anyok)[0]]
    # 詰め直し（1,944決済）
    for p0 in range(0, len(passed), 1500):
        pc = passed[p0:p0 + 1500]; nc = len(pc); rows = np.concatenate([i * 10 + yi[c[5]] for i, c in enumerate(pc)]); cols = np.concatenate([c[5] for c in pc])
        M = sp.csr_matrix((np.ones(len(rows), np.float32), (rows, cols)), shape=(nc * 10, len(idx)))
        st = stats(*run(M, Yfull, nc)); A, Bh = st['A'], st['B']
        for nm, okm, sc in selmasks(A, Bh):
            sc2 = np.where(okm, sc, -1e9); j = sc2.argmax(1)
            for c in np.nonzero(sc2[np.arange(nc), j] > -1e8)[0]:
                jj = j[c]; sname, a, la_, b, lb_, _ = pc[c]
                lab = lambda k, v: (TBL[int(float(v))] if k == '時間帯' else ('月火水木金土日'[int(float(v))] if k == '曜日' else v))
                ROWS.append((nm, sname, x, a, lab(a, la_), b, lab(b, lb_)) + CB[jj] + tuple(v for h in (A, Bh) for v in (h['n'][c], h['mean'][c, jj], h['win'][c, jj], h['yp'][c, jj], h['yn'][c], float(pval(h['t'][c, jj])), h['sh'][c])) + (int(okm[c].sum()),))
        del st, A, Bh, M
    pd.DataFrame(ROWS, columns=COLS).to_pickle('%s/s2parts/x%.3f.pkl' % (d, x)); nrows_tot = globals().get('nrows_tot', 0) + len(ROWS); globals()['nrows_tot'] = nrows_tot; ROWS = []
    npass += len(passed); print('x', x, 'entries', len(idx), '一次通過', len(passed), 'rows', nrows_tot, round(time.time() - t0), 's', flush=True)
print('done', nrows_tot)
