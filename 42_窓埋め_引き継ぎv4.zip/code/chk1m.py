import sys, io, csv, pandas as pd, numpy as np
sys.path.insert(0, sys.argv[1]); import ld
pd.set_option('display.width', 220)
def load(p):
    rows = list(csv.reader(io.open(p, encoding='utf-8-sig'))); h = rows[0]; ci = h.index('シグナル'); cs = [r[ci] for r in rows[1:]]
    u = [s for s in dict.fromkeys(cs) if '~' in s]; bad = [s[:30] for s in u if not (s.startswith('Y') and s.endswith('~E'))]
    print('  行', len(cs), 'コメント', len(u), '最大長', max(map(len, u)), '最小長', min(map(len, u)), '不正', len(bad), bad[:3], '足の分数', set(s.split('~')[1].split(',')[3] for s in u), 'ティック', set(s.split('~')[1].split(',')[2] for s in u))
    return ld.bars(p)
for nm, p, p5, tick in (('CFD', sys.argv[2], sys.argv[4], 1), ('先物', sys.argv[3], sys.argv[5], 5)):
    print('##', nm); d = load(p)
    print('  本数', len(d), d.t.iloc[0], '->', d.t.iloc[-1], '重複', int(d.m.duplicated().sum()), ' 整合', bool(((d.high >= d[['open', 'close']].max(axis=1)) & (d.low <= d[['open', 'close']].min(axis=1))).all()))
    print('  年別', d.groupby(d.t.dt.year).size().to_dict())
    g = d.m.diff(); print('  間隔(分) 上位', g.value_counts().head(8).to_dict()); big = d[g > 4 * 1440]; print('  4日超の空白', len(big), big.t.dt.strftime('%Y-%m-%d').tolist()[:10])
    mth = d.groupby(d.t.dt.strftime('%Y-%m')).size(); print('  月数', len(mth), ' 少ない月', mth[mth < mth.median() * .7].to_dict())
    # 5分足との突き合わせ
    f = ld.bars(p5); d['b'] = (d.m // 5) * 5
    a = d.groupby('b').agg(o=('open', 'first'), h=('high', 'max'), l=('low', 'min'), c=('close', 'last'), n=('m', 'size'))
    j = f.set_index('m').join(a, how='inner'); f2 = f[(f.m >= d.m.iloc[0]) & (f.m <= d.m.iloc[-1])]
    print('  5分足との対応', len(j), '/', len(f2), ' 1分足側にしか無い5分枠', int((~a.index.isin(f.m)).sum()))
    for k, kk in (('open', 'o'), ('high', 'h'), ('low', 'l'), ('close', 'c')): print('   ', k, '一致率', round(float((j[k] == j[kk]).mean()), 4), ' 差の95%点', float((j[k] - j[kk]).abs().quantile(.95)), ' 最大差', float((j[k] - j[kk]).abs().max()))
    d.drop(columns='b').to_pickle(sys.argv[6] + '/' + ('cfd1' if nm == 'CFD' else 'fut1') + '.pkl')
    if nm == 'CFD':
        d['pc'] = d.close.shift(1); z = d[g > 30]; print('  休止明け最初の1分足：始値=前の終値の割合', round(float((z.open == z.pc).mean()), 3), ' 件数', len(z)); print(z.tail(3)[['t', 'pc', 'open', 'high', 'low', 'close']].to_string())
