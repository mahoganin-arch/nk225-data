# 同じ窓での再エントリー：1回目が利確（完全な窓埋め）で終わった後、再び乖離幅に届いた場合
import sys, pandas as pd, numpy as np
sys.path.insert(0, sys.argv[1]); import ld
f = ld.bars(sys.argv[2], until='2026-10-09'); c = ld.bars(sys.argv[3], until='2026-10-09'); P = 68800
ro_all = (c.m.diff() > 30).values; cm = c.m.values; co = c.open.values; ch = c.high.values; cl = c.low.values; cc = c.close.values
f['sid'] = (f.m.diff() > 15).cumsum()
s = f.groupby('sid').agg(m0=('m', 'first'), m1=('m', 'last'), n=('m', 'size'), t0=('t', 'first')); lh = f.groupby('sid').t.last().dt.strftime('%H:%M')
s['end'] = np.where(lh.isin(['15:15', '15:45', '05:30', '06:00']), s.m1, s.m1 + 5); s['kind'] = np.where(s.t0.dt.hour.between(8, 9), 'D', 'N'); s = s.reset_index(drop=True)
out = []
for i in range(1, len(s)):
    p, q = s.iloc[i - 1], s.iloc[i]; j = np.searchsorted(cm, p.end) - 1
    if not (p.n >= 24 and q.n >= 24 and p.kind != q.kind and j >= 0 and p.end - cm[j] <= 15): continue
    a = j + 1; e = np.searchsorted(cm, q.end); ko = np.searchsorted(cm, q.m0) - a
    if not (e - a >= 6 and 0 <= ko < e - a) or (q.m0 - p.end) > (80 if p.kind == 'D' else 200): continue
    B = cc[j]; H = ch[a:e]; L = cl[a:e]; O = co[a:e]; C = cc[a:e]; RO = ro_all[a:e]; n = e - a; half = 'A' if q.t0.year <= 2021 else 'B'
    for x in (.1, .15, .2, .3):
        w = B * x / 100; start = 0; closed_at = None
        for seq in (1, 2, 3):
            k = None
            for b in range(start, n):
                if b >= ko:                                   # 先物寄り後：寄り以降に基準へ触れたら窓は閉じた
                    if closed_at is None:
                        g = O[ko] - B
                        z = np.nonzero((L[ko:] <= B) if g > 0 else (H[ko:] >= B))[0] if g != 0 else np.array([0])
                        closed_at = z[0] + ko if len(z) else 10**9
                    if b >= closed_at: break
                hi = C[b] if RO[b] else H[b]; lo = C[b] if RO[b] else L[b]
                if hi >= B + w or lo <= B - w:
                    if hi >= B + w and lo <= B - w: break
                    k = b; d = -1 if hi >= B + w else 1; break
            if k is None: break
            ent = C[k] if RO[k] else (max(B + w, O[k]) if d < 0 else min(B - w, O[k])); res = 'time'; px = C[-1]; xb = n
            for b in range(k + 1 if RO[k] else k, n):
                adv = (H[b] - ent) if d < 0 else (ent - L[b])
                if adv >= w: res = 'stop'; px = ent + w if d < 0 else ent - w; xb = b; break
                if b > k and ((L[b] <= B) if d < 0 else (H[b] >= B)): res = 'tgt'; px = B; xb = b; break
            out.append((p.kind + '>' + q.kind, half, x, seq, d * (px - ent) / B * 100 / 100 * P, res, k < ko))
            if res != 'tgt' or xb >= ko: break               # 再エントリーは「先物停止中に利確した」場合だけ
            start = xb + 1
r = pd.DataFrame(out, columns=['kind', 'half', 'x', 'seq', 'y', 'res', 'pre']); pd.set_option('display.width', 200)
g = r.groupby(['x', 'seq', 'half']).agg(件数=('y', 'size'), 勝率=('y', lambda v: (v > 0).mean() * 100), 平均=('y', 'mean'), t=('y', lambda v: v.mean() / v.std() * len(v) ** .5)).round(1)
print(g.unstack('half').to_string())
one = r[r.seq == 1].groupby('x').apply(lambda v: pd.Series({'1回目': len(v), '停止中に利確': int(((v.res == 'tgt')).sum())})); print(one.to_string())
print(r[r.seq >= 2].groupby(['kind', 'x']).y.agg(['size', 'mean']).round(1).unstack(0).to_string())
