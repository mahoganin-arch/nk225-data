import sys, itertools, pandas as pd, numpy as np
from math import erf, sqrt
d = sys.argv[1]; Y = np.load(d + '/Y.npy'); en = pd.read_pickle(d + '/en.pkl'); ev = pd.read_pickle(d + '/evt.pkl'); P = 68800
FR = [.1, .2, .3, .4, .5, .6, .7, .8, .9, 1.0, 1.25, 1.5]; SK = [0, .1, .2, .3, .4, .5, .6, .75, .9, 1, 1.25, 1.5, 2, 2.5, 3, 4, 5, 6]; TM = [0, 15, 30, 60, 90, 120, 180, 240, 360]
CB = list(itertools.product(FR, SK, TM)); NCB = len(CB)
en = en.join(ev[['kind', 'long', 't0']], on='ev'); en['seg'] = np.where(en.long, '週末祝日', en.kind); en['yr'] = en.t0.dt.year; en['half'] = np.where(en.yr <= 2021, 'A', 'B')
t = pd.to_datetime(en.m * 60, unit='s', utc=True).dt.tz_convert('Asia/Tokyo'); en['wd'] = t.dt.dayofweek; en['hr'] = t.dt.hour; en['dir'] = np.where(en.d < 0, '上', '下')
# 検算：5分足の期間（2019年以前）は前回(v4)と同じ値になるはず
import itertools as it
z4 = np.load(sys.argv[2] + '/r.npz'); e4 = pd.read_pickle(sys.argv[2] + '/en.pkl'); v4ev = pd.read_pickle(sys.argv[2] + '/evt.pkl'); e4 = e4.join(v4ev[['long', 't0', 'kind']], on='ev')
c4 = list(it.product([.1, .25, .5, .75, .9, 1.0], [0, .1, .25, .5, .75, 1, 1.5, 2, 3, 4, 6], [0, 30, 60, 120, 240]))
for (fr, sk, tm), x in (((1.0, 1, 0), .2), ((1.0, 2, 0), .1), ((.5, 1, 60), .3), ((1.0, 0, 0), .4)):
    a = e4.assign(y=z4['pa'][c4.index((fr, sk, tm))::330] / 100 * P); a = a[(~a.long) & (a.x == x) & (a.t0.dt.year <= 2019)]
    b = en.assign(y=Y[:, CB.index((fr, sk, tm))].astype(float) / 100 * P); b = b[(~b.long) & (b.x == x) & (b.yr <= 2019)]
    print('検算', (fr, sk, tm), x, '前回', len(a), round(a.y.mean(), 2), '今回', len(b), round(b.y.mean(), 2))
WDN = '月火水木金土日'
GRANS = [('曜日×時間', ['wd', 'hr']), ('曜日×時間×方向', ['wd', 'hr', 'dir']), ('時間×方向', ['hr', 'dir']), ('時間', ['hr']), ('曜日', ['wd']), ('曜日×方向', ['wd', 'dir']), ('方向', ['dir']), ('全体', [])]
def red(Yx, gid, ng):
    o = np.argsort(gid, kind='stable'); g = gid[o]; Ys = Yx[o]; st = np.searchsorted(g, np.arange(ng)); cnt = np.diff(np.append(st, len(g)))
    ok = cnt > 0; stt = st[ok]
    out = {k: np.zeros((ng, NCB), np.float32) for k in ('s', 'ss', 'w', 'pos', 'neg')}; mn = np.zeros((ng, NCB), np.float32)
    out['s'][ok] = np.add.reduceat(Ys, stt, axis=0); out['ss'][ok] = np.add.reduceat(Ys * Ys, stt, axis=0); out['w'][ok] = np.add.reduceat((Ys > 0).astype(np.float32), stt, axis=0)
    out['pos'][ok] = np.add.reduceat(np.clip(Ys, 0, None), stt, axis=0); out['neg'][ok] = np.add.reduceat(np.clip(Ys, None, 0), stt, axis=0); mn[ok] = np.minimum.reduceat(Ys, stt, axis=0)
    out['mn'] = mn; out['n'] = cnt.astype(np.float32); return out
pval = np.vectorize(lambda tt: 1 - erf(abs(tt) / sqrt(2)))
ROWS = []; FULL = []
for x in sorted(en.x.unique()):
    sub = en[en.x == x]; Yx = Y[sub.index.values].astype(np.float32) / 100 * P
    for gname, keys in GRANS:
        kk = ['seg'] + keys; cell = sub.groupby(kk).ngroup().values; ncell = cell.max() + 1; hidx = (sub.half.values == 'B').astype(int)
        cinfo = sub.assign(c=cell).drop_duplicates('c').set_index('c')[kk].sort_index()
        R = red(Yx, cell * 2 + hidx, ncell * 2); yi = sub.yr.values - 2017; Ry = red(Yx, cell * 10 + yi, ncell * 10)
        def get(h):  # h=0:A 1:B
            n = R['n'][h::2][:, None]; s = R['s'][h::2]; mean = s / np.maximum(n, 1); var = np.maximum(R['ss'][h::2] / np.maximum(n, 1) - mean ** 2, 1e-6)
            return dict(n=n[:, 0], mean=mean, win=R['w'][h::2] / np.maximum(n, 1) * 100, pf=R['pos'][h::2] / np.maximum(-R['neg'][h::2], 1e-6), worst=R['mn'][h::2], t=mean / np.sqrt(var) * np.sqrt(np.maximum(n, 1)))
        A = get(0); Bh = get(1)
        ym = Ry['s'].reshape(ncell, 10, NCB) / np.maximum(Ry['n'].reshape(ncell, 10)[:, :, None], 1); yn = Ry['n'].reshape(ncell, 10)
        yA = ((ym > 0) & (yn[:, :, None] >= 3))[:, :5].sum(1); yB = ((ym > 0) & (yn[:, :, None] >= 3))[:, 5:].sum(1); ynA = (yn >= 3)[:, :5].sum(1); ynB = (yn >= 3)[:, 5:].sum(1)
        shA = (A['mean'] > 0).mean(1) * 100; shB = (Bh['mean'] > 0).mean(1) * 100
        if gname == '全体':
            for c_ in range(ncell):
                for j in range(NCB):
                    FULL.append((cinfo.iloc[c_]['seg'], x) + CB[j] + (A['n'][c_], A['mean'][c_, j], A['win'][c_, j], A['pf'][c_, j], A['worst'][c_, j], yA[c_, j], ynA[c_], Bh['n'][c_], Bh['mean'][c_, j], Bh['win'][c_, j], Bh['pf'][c_, j], Bh['worst'][c_, j], yB[c_, j], ynB[c_]))
        sels = []
        okA = A['n'] >= 10; okB = Bh['n'] >= 10
        sels.append(('前半で最良', okA, np.where(okA[:, None], A['mean'], -1e9)))
        sels.append(('後半で最良', okB, np.where(okB[:, None], Bh['mean'], -1e9)))
        sels.append(('両方で最良', okA & okB, np.where((okA & okB)[:, None], np.minimum(A['mean'], Bh['mean']), -1e9)))
        sels.append(('前半・高勝率', okA, np.where(okA[:, None] & (A['win'] >= 80) & (A['mean'] > 0), A['mean'], -1e9)))
        sels.append(('後半・高勝率', okB, np.where(okB[:, None] & (Bh['win'] >= 80) & (Bh['mean'] > 0), Bh['mean'], -1e9)))
        for nm, ok, sc in sels:
            j = sc.argmax(1); good = ok & (sc[np.arange(ncell), j] > -1e8)
            for c_ in np.nonzero(good)[0]:
                jj = j[c_]; inf = cinfo.iloc[c_]
                cond = ' '.join([(WDN[int(inf[k])] if k == 'wd' else ('%d時' % inf[k] if k == 'hr' else inf[k])) for k in keys]) or '全体'
                ROWS.append((nm, inf['seg'], x, gname, cond) + CB[jj] + (A['n'][c_], A['mean'][c_, jj], A['win'][c_, jj], A['pf'][c_, jj], A['worst'][c_, jj], yA[c_, jj], ynA[c_], float(pval(A['t'][c_, jj])), shA[c_],
                                                                       Bh['n'][c_], Bh['mean'][c_, jj], Bh['win'][c_, jj], Bh['pf'][c_, jj], Bh['worst'][c_, jj], yB[c_, jj], ynB[c_], float(pval(Bh['t'][c_, jj])), shB[c_]))
    print('x', x, len(ROWS), flush=True)
cols = ['選び方', '窓', '乖離幅%', '粒度', '条件', '利確', '損切り', '時間切れ', '前半件数', '前半平均', '前半勝率', '前半PF', '前半最悪', '前半プラス年', '前半年数', '前半p', '前半プラス決済%', '後半件数', '後半平均', '後半勝率', '後半PF', '後半最悪', '後半プラス年', '後半年数', '後半p', '後半プラス決済%']
R = pd.DataFrame(ROWS, columns=cols); R.to_pickle(d + '/rows.pkl')
Fc = ['窓', '乖離幅%', '利確', '損切り', '時間切れ', '前半件数', '前半平均', '前半勝率', '前半PF', '前半最悪', '前半プラス年', '前半年数', '後半件数', '後半平均', '後半勝率', '後半PF', '後半最悪', '後半プラス年', '後半年数']
FU = pd.DataFrame(FULL, columns=Fc); FU.to_pickle(d + '/full.pkl'); print('rows', len(R), 'full', len(FU))
