# 順張り用：列名と説明を順張りの意味に置き換える（Excel/CSV）
import sys, pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font
MAP = {'利確': '損切り位置(基準への戻り割合)', '損切り': '利確幅(乖離幅の倍率)'}
NOTE = ('順張りの読み方', '順張り＝乖離幅に届いた方向へ逆指値でエントリー。「損切り位置」は基準価格の方向へどこまで戻ったら損切りするか（1.0＝基準まで戻ったら、0.5＝半分戻ったら、1.25/1.5＝基準を越えて戻ったら）。「利確幅」はエントリー価格からさらに乖離幅の何倍進んだら利確するか（なし＝利確しない）。同じ足で損切りと利確が重なった場合は損切りとして計算。それ以外の列の意味は逆張りと同じ')
for p in sys.argv[1:]:
    if p.endswith('.xlsx'):
        wb = load_workbook(p)
        for ws in wb.worksheets:
            for c in ws[1]:
                if c.value in MAP: c.value = MAP[c.value]
            if ws.title == '説明':
                ws.insert_rows(2); ws['A2'] = NOTE[0]; ws['B2'] = NOTE[1]; ws['A2'].font = Font(name='Arial', size=10, bold=True); ws['B2'].font = Font(name='Arial', size=10)
                for row in ws.iter_rows(min_row=3):
                    for c in row:
                        if isinstance(c.value, str): c.value = c.value.replace('逆張り', '順張り')
        wb.save(p)
    else:
        df = pd.read_csv(p); df = df.rename(columns=MAP); df.to_csv(p, index=False, encoding='utf-8-sig', compression='gzip' if p.endswith('.gz') else None)
    print('ok', p)
