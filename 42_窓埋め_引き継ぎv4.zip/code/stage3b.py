# 段階3（省メモリ版）：文字列を番号にして候補群ごとの最良行・通過幅を集計
import sys, glob, numpy as np, pandas as pd
sys.path.insert(0, sys.argv[1]); from common6 import *
d = sys.argv[2]; Y, en, F = load(d)
XS = sorted(en.x.unique()); XI = {round(x, 4): i for i, x in enumerate(XS)}
def parts():
    s1 = pd.read_pickle(d + '/s1a.pkl'); s1['指標1'] = s1['指標']; s1['区分1'] = s1['区分']; s1['指標2'] = ''; s1['区分2'] = ''; yield s1.drop(columns=['指標', '区分'])
    for p_ in sorted(glob.glob(d + '/s2parts/*.pkl')): yield pd.read_pickle(p_)
V = {c: {} for c in ('窓', '選び方', '指標1', '区分1', '指標2', '区分2')}
def code(col, s):
    voc = V['指標1' if col in ('指標1', '指標2') else ('区分1' if col in ('区分1', '区分2') else col)]
    for u in pd.unique(s):
        if u not in voc: voc[u] = len(voc)
    return s.map(voc).astype(np.int64).values
NUM = ['乖離幅%', '利確', '損切り', '時間切れ'] + [h + c for h in ('前半', '後半') for c in ('件数', '平均', '勝率', 'プラス年', '年数', 'p', 'プラス決済%')] + ['基準を満たす決済数']
best = None; xs = []; ntot = 0
for R in parts():
    ntot += len(R)
    c = {k: code(k, R[k]) for k in ('窓', '選び方', '指標1', '区分1', '指標2', '区分2')}
    key = (((c['窓'] * 400 + c['指標1']) * 400 + c['区分1']) * 400 + c['指標2']) * 400 + c['区分2']
    sel = R['選び方'].values; sc = np.where(sel == '両方で最良', np.minimum(R['前半平均'], R['後半平均']), np.where(pd.Series(sel).str.startswith('前半').values, R['前半平均'], R['後半平均']))
    D = pd.DataFrame({k: R[k].values.astype(np.float32) for k in NUM}); D['key'] = key; D['sel'] = c['選び方']; D['score'] = sc.astype(np.float32)
    xs.append(np.unique(np.stack([key, c['選び方'], R['乖離幅%'].round(4).map(XI).values.astype(np.int64)], 1), axis=0))
    D = D.sort_values('score', ascending=False).drop_duplicates(['key', 'sel'])
    best = D if best is None else pd.concat([best, D]).sort_values('score', ascending=False).drop_duplicates(['key', 'sel'])
    print('part', len(R), 'families', len(best), flush=True)
X = np.unique(np.concatenate(xs), axis=0)                                    # (key, sel, xi) ソート済み
same = np.r_[False, (X[1:, 0] == X[:-1, 0]) & (X[1:, 1] == X[:-1, 1])]; step = same & np.r_[False, X[1:, 2] == X[:-1, 2] + 1]
rid = np.cumsum(~step); rl = np.bincount(rid); gid = np.cumsum(~same)
G = pd.DataFrame({'key': X[:, 0], 'sel': X[:, 1], 'gid': gid, 'rl': rl[rid]}).groupby(['key', 'sel']).agg(通過した幅の数=('gid', 'size'), 連続した幅の最大数=('rl', 'max')).reset_index()
best = best.merge(G, on=['key', 'sel'])
inv = {k: {v: s for s, v in V[k].items()} for k in ('窓', '選び方', '指標1', '区分1')}
k = best.key.values; best['区分2'] = (k % 400); k = k // 400; best['指標2'] = k % 400; k = k // 400; best['区分1'] = k % 400; k = k // 400; best['指標1'] = k % 400; best['窓'] = k // 400
for col, voc in (('窓', '窓'), ('指標1', '指標1'), ('指標2', '指標1'), ('区分1', '区分1'), ('区分2', '区分1')): best[col] = best[col].map(inv[voc])
best['選び方'] = best['sel'].map(inv['選び方'])
t2 = best['指標1'].isin(['時間帯', '曜日']) | best['指標2'].isin(['時間帯', '曜日'])
best['種類'] = np.where(best['指標2'] == '', '指標単独', np.where(t2, '指標×時間・曜日', '指標×指標'))
best.drop(columns=['key', 'sel']).to_pickle(d + '/families.pkl')
print('行の合計', ntot, ' 候補群×選び方', len(best)); print(best.groupby(['種類', '選び方']).size().unstack().to_string())
