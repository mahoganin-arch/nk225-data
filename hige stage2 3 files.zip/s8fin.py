import pickle, numpy as np, pandas as pd, glob, sys
from s7 import load
pd.set_option('display.width',240,'display.max_colwidth',34,'display.unicode.east_asian_width',True)
C,T=pickle.load(open('real8.pkl','rb')); T['c1']='';T['c2']='';T['shape']=''
for tf in (60,30):
    P=load(tf); sh=np.array(P['shapes']); n0=np.array(P['names']); n1=np.array(P['names1']); nx=np.array(P['namesX']); NC=len(nx); m=T.tf==tf
    T.loc[m,'shape']=sh[T.si[m]]
    for fam,nm in ((0,n0),(1,n1)): mm=m&(T.fam==fam); T.loc[mm,'c1']=nm[T.key[mm]]
    mm=m&(T.fam==2); T.loc[mm,'c1']=nx[T.key[mm]//NC]; T.loc[mm,'c2']=nx[T.key[mm]%NC]
    del P
T.to_pickle('T8.pkl')
N=[]
for f in glob.glob('null8_*.pkl'): N+=pickle.load(open(f,'rb'))
N=np.array(N); print('偽データ回数',len(N))
for fam,fn in enumerate(('局面×形','形×形','髭×2条件')):
    for side,sn in enumerate(('買い','売り')):
        print(fn,sn,' / '.join(f"{lab}: 本番{int(C[fam,side,i])} 偽{N[:,fam,side,i].mean():.0f}({N[:,fam,side,i].min():.0f}〜{N[:,fam,side,i].max():.0f})" for i,lab in enumerate(('基準通過','z>=2','z>=3','z>=4'))))
