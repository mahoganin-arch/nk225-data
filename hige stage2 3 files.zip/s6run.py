import pickle, numpy as np, pandas as pd, time, sys
from s6 import *
mode=sys.argv[1]
if mode=='real':
    rows=[]
    for tf in (60,30):
        P=pickle.load(open(f'P{tf}.pkl','rb')); EV=evlists(P,False); nst=len(P['names']); t0=time.time()
        for (side,conf,H),(ret,xi) in P['cfg'].items():
            for si in range(len(EV)):
                out=kern(EV[si],ret,xi,P['act'],P['per'],0,0,1,nst)
                rows.append((tf,side,conf,H,si,out.astype(np.float32)))
        print(tf,'本番',round(time.time()-t0),'秒',flush=True)
    pickle.dump(rows,open('real.pkl','wb'),protocol=4)
else:
    seed=int(sys.argv[2]); nrun=int(sys.argv[3]); rng=np.random.default_rng(seed); res=[]
    Ps={tf:pickle.load(open(f'P{tf}.pkl','rb')) for tf in (60,30)}; EVs={tf:evlists(Ps[tf],True) for tf in (60,30)}
    for r in range(nrun):
        hist=np.zeros((2,2,80)); mx=np.full((2,2),-99.0); u=rng.uniform(0.1,0.9); t0=time.time()
        for tf in (60,30):
            P=Ps[tf]; m=int((P['per']==0).sum())-P['warm']; run_null(P,int(u*m),EVs[tf],hist,mx)
        res.append((u,hist,mx)); pickle.dump(res,open(f'null_{seed}.pkl','wb'))
        print(r,round(time.time()-t0),'秒',mx.round(2).tolist(),flush=True)
