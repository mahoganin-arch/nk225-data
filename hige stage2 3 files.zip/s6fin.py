import pickle, numpy as np, pandas as pd, glob
pd.set_option('display.width',250,'display.max_colwidth',70,'display.unicode.east_asian_width',True,'display.max_rows',200)
T=pd.read_pickle('T2.pkl'); S=T[(T.si>0)&(T.state!='(全体)')&(T.na>=100)].copy()
N=[]
for f in glob.glob('null_1[12].pkl'): N+=pickle.load(open(f,'rb'))
print('偽データ回数',len(N),' 本番の評価対象',len(S))
H=np.array([h for _,h,_ in N]); MX=np.array([m for _,_,m in N])
def cnt(h,x): return h[...,int((x+10)*4):].sum(-1)
for side,sn in ((0,'買い'),(1,'売り')):
    s=S[S.side==side]; good=(s.pfa>=1.3)&(s.ma>0)
    print(f'\n== {sn} ==  本番の最大t: 全体 {s.ta.max():.2f} / PF1.3以上 {s.ta[good].max():.2f}')
    for g,gn in ((0,'全体'),(1,'PF1.3以上')):
        m=MX[:,side,g]; rt=(s.ta if g==0 else s.ta[good]).max()
        print(f'  偽データの最大t({gn}): 中央 {np.median(m):.2f}  上位5% {np.quantile(m,.95):.2f}  → 本番を上回った割合 {100*(m>=rt).mean():.0f}%')
        for x in (2,2.5,3,3.5,4):
            real=int(((s.ta>=x)&(good if g else True)).sum()); nu=cnt(H[:,side,g],x)
            print(f'    t>={x}: 本番 {real:6d}  偽 平均 {nu.mean():8.1f} (5%〜95%: {np.quantile(nu,.05):.0f}〜{np.quantile(nu,.95):.0f})  偽物率の目安 {min(1,nu.mean()/max(real,1))*100:.0f}%')
# 確認期間：17-22上位の23-26通過率 vs 無作為
S['passb']=(S.nb>=30)&(S.pfb>=1.3)&(S.mb>S.bmb)
for side,sn in ((0,'買い'),(1,'売り')):
    s=S[(S.side==side)&(S.nb>=30)]
    print(f'\n{sn} 23-26通過率(PF1.3以上かつ形だけを上回る): 無作為 {100*s.passb.mean():.1f}%', {f't>={x}': f"{100*s.passb[(s.ta>=x)&(s.pfa>=1.3)].mean():.1f}% ({int(((s.ta>=x)&(s.pfa>=1.3)).sum())}件)" for x in (2,3,3.5)})
S.to_pickle('S2.pkl')
