# 第1・2段：髭の再定義（色・比率・大きさ・終値位置・反対髭）×出た場所。上昇分を除いた超過で評価、偽データ＝成績系列を時間方向にずらす
import pandas as pd, numpy as np, pickle, sys, time, itertools, warnings; warnings.filterwarnings('ignore')
from numba import njit
from s1 import atr_
HS=(1,2,3,5,10,20,40,60)
def build(tf):
    P=pickle.load(open(f'P{tf}.pkl','rb')); b=P['b']; n=P['n']; o,h,l,c,v=b.open,b.high,b.low,b.close,b.volume; a=atr_(h,l,c)
    body=(c-o).abs(); up=h-np.maximum(o,c); lo=np.minimum(o,c)-l; rng=h-l; M=dict(zip(P['shapes'],P['M']))
    f=lambda s:np.asarray(pd.Series(s).fillna(False),bool)
    D={};
    for d,w,ow,far in (('上髭',up,lo,(c-l)/rng<=1/3),('下髭',lo,up,(h-c)/rng<=1/3)):
        R={'実体の2倍':(body>0)&(w>=2*body),'実体の3倍':(body>0)&(w>=3*body),'実体の5倍':(body>0)&(w>=5*body),'値幅の50%':(rng>0)&(w>=0.5*rng),'値幅の67%':(rng>0)&(w>=0.67*rng)}
        S={'下限なし':w>=0,'ATR0.3倍':w>=0.3*a,'ATR0.5倍':w>=0.5*a,'ATR1.0倍':w>=1.0*a}
        C={'色不問':c==c,'陽線':c>o,'陰線':c<o}; F={'終値不問':c==c,'終値が髭の反対側1/3':far}; O={'反対髭不問':c==c,'反対髭ほぼなし':ow<=0.1*rng}
        for (rk,r),(sk,s),(ck,cc),(fk,ff),(ok,oo) in itertools.product(R.items(),S.items(),C.items(),F.items(),O.items()):
            D[(d,rk,sk,ck,fk,ok)]=f(r&s&cc&ff&oo)
    mom5=(c.shift(1)-c.shift(6))/a; mom20=(c.shift(1)-c.shift(21))/a; lv=('P','R1','S1','R2','S2'); K={}
    for d,t1,t2 in (('上髭','に下から触れて反落','高値スイープ'),('下髭','に上から触れて反発','安値スイープ')):
        k={'場所不問':np.ones(n,bool)}
        for N in (20,50,100): k[f'髭先が{N}本高安を突いて戻る']=M[f'高安|{N}本{t2}']
        k['髭先が週次ピボットを突いて戻る']=np.any([M[f'ピボット|週次ピボット{x}{t1}'] for x in lv],0)
        k['髭先が日次ピボットを突いて戻る']=np.any([M[f'ピボット|日次ピボット{x}{t1}'] for x in lv],0)
        k['髭先が前日高安を突いて戻る']=M['高安|前日'+t2]; k['髭先がVWAPを突いて戻る']=M['押し戻り|VWAP'+t1]; k['髭先が500円の節目を突いて戻る']=M['切りの良い価格|500円の節目'+t1]
        k['直前5本が上昇(+0.7ATR超)']=f(mom5>0.7); k['直前5本が下落(-0.7ATR未満)']=f(mom5<-0.7); k['直前20本が上昇(+1.5ATR超)']=f(mom20>1.5); k['直前20本が下落(-1.5ATR未満)']=f(mom20<-1.5)
        k['出来高が20本平均の1.5倍超']=f(v>v.rolling(20).mean()*1.5); K[d]=k
    # 成績：次足始値→H本目終値。前後約1か月の平均（上昇分）を引き、時間帯×値幅の大きさごとの平均も引く
    ov,cv=o.values,c.values; W=920*60//tf; hr=b.t.dt.hour.values; rq=pd.qcut((rng/a).fillna(0),5,labels=False,duplicates='drop').values; cell=hr*5+rq
    warm=P['warm']; valid=np.zeros(n,bool); valid[warm:n-70]=True; RAW={};X={};E={}
    for H in HS:
        raw=np.full(n,np.nan); raw[:n-H]=(cv[H:]-ov[1:n-H+1])/cv[:n-H]*100
        x=raw-pd.Series(raw).rolling(W,center=True,min_periods=W//2).mean().values
        g=pd.Series(np.where(valid,x,np.nan)).groupby(cell).transform('mean').values; RAW[H]=raw; X[H]=x; E[H]=x-g
    return dict(D=D,K=K,RAW=RAW,X=X,E=E,cost=(10/cv*100),per=(b.t.dt.year.values>=2023).astype(np.int64),valid=valid,n=n,warm=warm,yr=b.t.dt.year.values)
@njit(cache=True)
def ev1(idx,H,e,per):
    q=np.zeros((2,3)); free=0
    for i in idx:
        if i<free or np.isnan(e[i]): continue
        free=i+H+1; p=per[i]; q[p,0]+=1; q[p,1]+=e[i]; q[p,2]+=e[i]*e[i]
    return q
@njit(cache=True)
def ev2(idx,H,e,x,raw,cost,per):
    q=np.zeros((2,11)); free=0   # n,Σe,Σe²,[買い超過 利益,損失],[売り超過],[買い実損益],[売り実損益]
    for i in idx:
        if i<free or np.isnan(e[i]): continue
        free=i+H+1; p=per[i]; q[p,0]+=1; q[p,1]+=e[i]; q[p,2]+=e[i]*e[i]
        for k,v in enumerate((x[i]-cost[i],-x[i]-cost[i],raw[i]-cost[i],-raw[i]-cost[i])):
            if v>0: q[p,3+2*k]+=v
            else: q[p,4+2*k]-=v
    return q
def tz(q):
    n=q[:,0]; mu=q[:,1]/np.maximum(n,1); sd=np.sqrt(np.maximum((q[:,2]-n*mu*mu)/np.maximum(n-1,1),1e-12)/np.maximum(n,1)); return n,mu,mu/sd
def sigs(B):
    out=[]
    for key,m in B['D'].items():
        for kn,km in B['K'][key[0]].items():
            idx=np.where(m&km&B['valid'])[0]
            if (B['per'][idx]==0).sum()>=60 and (B['per'][idx]==1).sum()>=30: out.append((key,kn,idx))
    return out
if __name__=='__main__':
    Bs={tf:build(tf) for tf in (60,30)}; SG={tf:sigs(Bs[tf]) for tf in (60,30)}; print({tf:len(SG[tf]) for tf in SG},flush=True)
    if sys.argv[1]=='real':
        rows=[]
        for tf in (60,30):
            B=Bs[tf]
            for key,kn,idx in SG[tf]:
                for H in HS:
                    q=ev2(idx,H,B['E'][H],B['X'][H],B['RAW'][H],B['cost'],B['per']); rows.append((tf,)+key+(kn,H)+tuple(q.ravel()))
        cols=['tf','向き','比率','大きさ','色','終値','反対髭','場所','H']+[f'{p}{i}' for p in 'ab' for i in range(11)]
        pd.DataFrame(rows,columns=cols).to_pickle('real9.pkl'); print('本番',len(rows))
    else:
        rng=np.random.default_rng(int(sys.argv[2])); res=[]; t0=time.time()
        for r in range(int(sys.argv[3])):
            Z=[[],[]]; u=rng.uniform(0.1,0.9)
            for tf in (60,30):
                B=Bs[tf]; w0=B['warm']; w1=B['n']-70; sh=int(u*(w1-w0))
                for H in HS:
                    e=B['E'][H].copy(); e[w0:w1]=np.roll(e[w0:w1],sh)
                    for key,kn,idx in SG[tf]:
                        q=ev1(idx,H,e,B['per'])
                        if q[0,0]>=60 and q[1,0]>=30:
                            n,mu,t=tz(q); Z[0 if kn=='場所不問' else 1].append((t[0],t[1]))
            res.append([np.array(z,np.float32) for z in Z])
            if r==0: print('1回',round(time.time()-t0),'秒',flush=True)
        pickle.dump(res,open(f'null9_{sys.argv[2]}.pkl','wb')); print('完了',round(time.time()-t0))
