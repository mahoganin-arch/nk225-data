import pickle, numpy as np, pandas as pd, gc
from s7 import load
R1,R2=pickle.load(open('real7.pkl','rb')); K1=[];K2=[]; H={1:np.zeros((2,2,80)),2:np.zeros((2,2,80))}; MX={1:np.full((2,2),-99.),2:np.full((2,2),-99.)}
PB={(f,s):np.zeros((4,2)) for f in (1,2) for s in (0,1)}   # 23-26通過率：行=全体/t>=2/t>=3/t>=3.5、列=件数/通過
def stats(out,pfdirect):
    d={}
    for p,l in ((0,'a'),(1,'b')):
        q=out[:,p].astype(float); n=q[:,0]; mu=q[:,1]/np.maximum(n,1); var=(q[:,2]-n*mu*mu)/np.maximum(n-1,1)
        loss=q[:,4] if pfdirect else q[:,3]-q[:,1]
        d['n'+l]=n; d['m'+l]=mu; d['pf'+l]=q[:,3]/np.maximum(loss,1e-9); d['t'+l]=(mu-mu[0])/np.sqrt(np.maximum(var,1e-12)/np.maximum(n,1)); d['bm'+l]=mu[0]; d['bpf'+l]=d['pf'+l][0]; d['bn'+l]=n[0]
    return pd.DataFrame(d)
def acc(f,fam,side):
    good=(f.pfa>=1.3)&(f.ma>0); k=np.clip(((f.ta+10)*4).astype(int),0,79)
    H[fam][side,0]+=np.bincount(k,minlength=80); H[fam][side,1]+=np.bincount(k[good],minlength=80)
    MX[fam][side,0]=max(MX[fam][side,0],f.ta.max()); 
    if good.any(): MX[fam][side,1]=max(MX[fam][side,1],f.ta[good].max())
    v=f[f.nb>=30]; pb=(v.pfb>=1.3)&(v.mb>v.bmb); g=(v.pfa>=1.3)
    for r,mk in enumerate((np.ones(len(v),bool),g&(v.ta>=2),g&(v.ta>=3),g&(v.ta>=3.5))): PB[(fam,side)][r]+=[mk.sum(),(pb&mk).sum()]
AD={(60,0,0,40,'髭|上髭2倍'):[('(全体)','固有|A時間帯(8:45〜11:30)')],(60,0,0,40,'髭|上髭3倍'):[('1時間|一目|雲|雲の上','固有|出来高が20本平均の1.5倍超')],
    (60,0,1,20,'髭|下髭5倍'):[('(全体)','1時間|一目|三役|三役逆転')],(30,0,1,20,'髭|下髭2倍'):[('固有|D安値スイープ(高値スイープ除く)','固有|D直前5本の勢い-2〜-0.7ATR')]}
for tf in (60,30):
    P=load(tf); sh=P['shapes']; n1=np.array(P['names1']); nx=np.array(P['namesX']); NC=len(nx)
    for (t,side,conf,H_,si,out) in R1:
        if t!=tf: continue
        f=stats(out,True); f['c1']=n1; f['c2']=''; f=f.iloc[1:]; f=f[f.na>=100]
        if len(f)==0: continue
        acc(f,1,side); f=f[f.ta>=2.5].copy(); f['tf']=tf; f['side']=side; f['conf']=conf; f['H']=H_; f['shape']=sh[si]; K1.append(f)
    for (t,side,conf,H_,si,keep,out) in R2:
        if t!=tf: continue
        f=stats(out,False); f['c1']=nx[keep//NC]; f['c2']=nx[keep%NC]; f=f.iloc[1:]
        acc(f,2,side); key=(tf,side,conf,H_,sh[si]); mk=(f.ta>=2.5)
        for a,b in AD.get(key,[]): mk|=((f.c1==a)&(f.c2==b))
        f=f[mk].copy(); f['tf']=tf; f['side']=side; f['conf']=conf; f['H']=H_; f['shape']=sh[si]; K2.append(f)
    del P; gc.collect()
pickle.dump((pd.concat(K1,ignore_index=True),pd.concat(K2,ignore_index=True),H,MX,PB,AD),open('A7.pkl','wb'))
print({k:int(v[:,0].sum()) for k,v in H.items()})
