# 段階2-3：ゆるい基準（両期間PF1.3以上・形だけを上回る・17-22年60回以上/23-26年30回以上）での一覧と、同基準での偽データ件数
import pandas as pd, numpy as np, pickle, sys, time, warnings; warnings.filterwarnings('ignore')
from s6 import kern, evlists
from s7 import load, kern2
TIERS=(0,2,3,4)
def st(q,loss_direct):
    q=q.astype(float); n=q[:,0]; mu=q[:,1]/np.maximum(n,1); var=(q[:,2]-n*mu*mu)/np.maximum(n-1,1)
    loss=q[:,4] if loss_direct else q[:,3]-q[:,1]; return n,mu,q[:,3]/np.maximum(loss,1e-9),np.sqrt(np.maximum(var,1e-12)/np.maximum(n,1))
def judge(out,ld,idx):
    na,ma,pa,sa=st(out[:,0],ld); nb,mb,pb,sb=st(out[:,1],ld); b=0
    ok=(na>=60)&(nb>=30)&(pa>=1.3)&(pb>=1.3)&(ma>ma[b])&(mb>mb[b]); ok[b]=False
    z=((ma-ma[b])/sa+(mb-mb[b])/sb)/np.sqrt(2); k=np.where(ok)[0]
    return k,z[k],dict(key=idx[k],na=na[k],pfa=pa[k],ma=ma[k],bpfa=np.full(len(k),pa[b]),nb=nb[k],pfb=pb[k],mb=mb[k],bpfb=np.full(len(k),pb[b]),z=z[k])
def run(Ps,u,keep):
    C=np.zeros((3,2,len(TIERS))); rows=[]
    for tf in (60,30):
        P=Ps[tf]; n=P['n']; seg0=P['warm']; m=n-50-seg0; shift=0 if u==0 else int(u*m); EV=P['EV']; NC=len(P['namesX']); out2,free=P['buf']
        for (side,conf,H),(ret,xi) in P['cfg'].items():
            for fam in (0,1,2):
                for si in (P['spike'] if fam==2 else range(1,len(EV))):
                    if fam==0: out=kern(EV[si],ret,xi,P['act'],P['per'],shift,seg0,m,len(P['names'])); idx=np.arange(len(out))
                    elif fam==1: out=kern(EV[si],ret,xi,P['act1'],P['per'],shift,seg0,m,len(P['names1'])); out[si]=0; idx=np.arange(len(out))
                    else:
                        kern2(EV[si],ret,xi,P['actX'],P['per'],shift,seg0,m,NC,out2,free); idx=np.where((out2[:,0,0]>=60)&(out2[:,1,0]>=30))[0]; idx=np.concatenate([[0],idx[idx>0]]); out=out2[idx]
                    k,z,d=judge(out,fam<2,idx)
                    for ti,t in enumerate(TIERS): C[fam,side,ti]+=(z>=t).sum()
                    if keep and len(k):
                        f=pd.DataFrame(d); f=f[f.z>=2]; f['fam']=fam; f['tf']=tf; f['side']=side; f['conf']=conf; f['H']=H; f['si']=si; rows.append(f)
    return C,rows
if __name__=='__main__':
    Ps={tf:load(tf) for tf in (60,30)}
    for tf in (60,30):
        P=Ps[tf]; P['EV']=evlists(P,False); NC=len(P['namesX']); P['buf']=(np.zeros((NC*NC,2,4)),np.zeros(NC*NC,np.int64))
    if sys.argv[1]=='real':
        t0=time.time(); C,rows=run(Ps,0,True); T=pd.concat(rows,ignore_index=True); pickle.dump((C,T),open('real8.pkl','wb')); print(round(time.time()-t0),'秒',len(T)); print(C.astype(int).tolist())
    else:
        rng=np.random.default_rng(int(sys.argv[2])); res=[]
        for r in range(int(sys.argv[3])):
            t0=time.time(); C,_=run(Ps,rng.uniform(0.1,0.9),False); res.append(C); pickle.dump(res,open(f'null8_{sys.argv[2]}.pkl','wb')); print(r,round(time.time()-t0),flush=True)
