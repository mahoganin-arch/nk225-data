import pickle, numpy as np, pandas as pd, glob
K1,K2,H,MX,PB,AD=pickle.load(open('A7.pkl','rb')); N=[]
for f in glob.glob('null7_*.pkl'): N+=pickle.load(open(f,'rb'))
print('偽データ回数',len(N))
def cnt(h,x): return h[...,int((x+10)*4):].sum(-1)
for fam,fn,hi,mi in ((1,'形×形',1,2),(2,'髭×条件×条件',3,4)):
    NH=np.array([r[hi] for r in N]); NM=np.array([r[mi] for r in N])
    for side,sn in ((0,'買い'),(1,'売り')):
        m=NM[:,side,0]; rt=MX[fam][side,0]
        print(f'\n== {fn} {sn} == 評価対象 {int(H[fam][side,0].sum())}  本番最大t {rt:.2f} | 偽: 中央 {np.median(m):.2f} 上位5% {np.quantile(m,.95):.2f} 本番以上の割合 {100*(m>=rt).mean():.0f}%')
        for g,gn in ((0,'全体'),(1,'PF1.3以上')):
            print('  '+gn+': '+' / '.join(f"t>={x}: 本番{int(cnt(H[fam][side,g],x))} 偽{cnt(NH[:,side,g],x).mean():.0f}({np.quantile(cnt(NH[:,side,g],x),.05):.0f}〜{np.quantile(cnt(NH[:,side,g],x),.95):.0f})" for x in (2,3,3.5,4,4.5)))
        pb=PB[(fam,side)]; print('  23-26通過率: 無作為 %.1f%%, t>=2 %.1f%%(%d件), t>=3 %.1f%%(%d件), t>=3.5 %.1f%%(%d件)'%(100*pb[0,1]/pb[0,0],100*pb[1,1]/max(pb[1,0],1),pb[1,0],100*pb[2,1]/max(pb[2,0],1),pb[2,0],100*pb[3,1]/max(pb[3,0],1),pb[3,0]))
NH=np.array([r[3] for r in N])[:,0,0]
for nm,t in (('A',1.95),('B',2.77),('C',1.26),('D',3.44)):
    x=np.floor(t*4)/4; print(f'候補{nm} t>={x}: 本番 {int(cnt(H[2][0,0],x))} 件, 偽 平均 {cnt(NH,x).mean():.0f} 件 (5〜95%: {np.quantile(cnt(NH,x),.05):.0f}〜{np.quantile(cnt(NH,x),.95):.0f})')
