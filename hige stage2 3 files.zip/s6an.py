import pickle, numpy as np, pandas as pd
from s6 import *
rows=pickle.load(open('real.pkl','rb')); R=[]
for tf in (60,30):
    P=pickle.load(open(f'P{tf}.pkl','rb')); nm=np.array(P['names']); sh=P['shapes']
    for (t,side,conf,H,si,out) in rows:
        if t!=tf: continue
        out=out.astype(float); d={}
        for p,l in ((0,'a'),(1,'b')):
            q=out[:,p]; n=q[:,0]; mu=q[:,1]/np.maximum(n,1); var=(q[:,2]-n*mu*mu)/np.maximum(n-1,1); bm=mu[0]
            d['n'+l]=n; d['m'+l]=mu; d['pf'+l]=q[:,3]/np.maximum(q[:,4],1e-9); d['t'+l]=(mu-bm)/np.sqrt(np.maximum(var,1e-12)/np.maximum(n,1)); d['bm'+l]=np.full(len(n),bm); d['bpf'+l]=np.full(len(n),q[0,3]/max(q[0,4],1e-9)); d['bn'+l]=np.full(len(n),n[0])
        f=pd.DataFrame(d); f['tf']=tf; f['side']=side; f['conf']=conf; f['H']=H; f['shape']=sh[si]; f['state']=nm; f['si']=si
        R.append(f[(f.na>=30)])
T=pd.concat(R,ignore_index=True); T.to_pickle('T2.pkl'); print(len(T))
