# 段階2：局面×形の2部品総当たり（重複なし・コスト10円込み）＋ 局面を時間方向にずらした偽データでの偽物率測定
import pandas as pd, numpy as np, warnings, sys, time, pickle; warnings.filterwarnings('ignore')
from numba import njit
from ld import bars
from s2 import feats
from s3 import regime
exec(open('s4.py').read().split('ST=[];EV=[]')[0])   # D, piv, profile, touch, build
HS=(5,20,40); COST=10.0
def states(tf,b,b1):
    d=D; LD=regime(d.open,d.high,d.low,d.close)
    k=np.searchsorted(d.t.values,b.t.values,side='right')-1; LDb=LD.iloc[np.clip(k-1,0,None)].reset_index(drop=True)
    L1=regime(b1.open,b1.high,b1.low,b1.close)
    x=b1.set_index('t'); h4=x.resample('4h').agg({'open':'first','high':'max','low':'min','close':'last'}).dropna()
    L4=regime(h4.open,h4.high,h4.low,h4.close).shift(1).fillna('nan'); L4b=L4.reindex(pd.DatetimeIndex(b.t),method='ffill').reset_index(drop=True).fillna('nan')
    if tf==60: L1b=L1
    else:
        j=np.searchsorted(b1.m.values,b.m.values-30,side='right')-1; L1b=L1.iloc[np.clip(j,0,None)].reset_index(drop=True); L1b[j<0]='nan'
    X={}
    X['複合|日足SMA75 × 4時間SMA50']=('日足'+LDb['MA位置|終値vsSMA75']+'・4H'+L4b['MA位置|終値vsSMA50']).values
    X['複合|日足SMA200 × 4時間SMA50']=('日足'+LDb['MA位置|終値vsSMA200']+'・4H'+L4b['MA位置|終値vsSMA50']).values
    X['複合|日足雲 × 4時間雲']=('日足'+LDb['一目|雲']+'・4H'+L4b['一目|雲']).values
    X['複合|4時間雲 × 1時間雲']=('4H'+L4b['一目|雲']+'・1H'+L1b['一目|雲']).values
    X['複合|4時間SMA50 × 1時間SMA50']=('4H'+L4b['MA位置|終値vsSMA50']+'・1H'+L1b['MA位置|終値vsSMA50']).values
    X['複合|日足SMA75 × 4時間SMA50 × 1時間SMA50']=('日足'+LDb['MA位置|終値vsSMA75']+'・4H'+L4b['MA位置|終値vsSMA50']+'・1H'+L1b['MA位置|終値vsSMA50']).values
    X['複合|日足三役 × 1時間三役']=('日足'+LDb['一目|三役']+'・1H'+L1b['一目|三役']).values
    LX=pd.DataFrame(X); LX=LX.where(~LX.apply(lambda s:s.str.contains('nan')),'nan')
    return [('日足',LDb),('4時間',L4b),('1時間',L1b),('複合',LX)]
def prep(tf):
    f='h1.csv' if tf==60 else 'm30.csv'; b1=bars('h1.csv')
    b,S4,E4=build(f,tf); E,_=feats(b,tf); E.update(E4); n=len(b)
    groups=states(tf,b,b1)+[('位置',S4)]
    names=['(全体)']; cols=[np.zeros(n,np.int16)]
    for g,L in groups:
        for col in L.columns:
            x=np.asarray(L[col].values,dtype=object).astype(str); a=np.full(n,-1,np.int16)
            for u in pd.unique(x):
                if u=='nan': continue
                a[x==u]=len(names); names.append(f'{g}|{col}|{u}')
            cols.append(a)
    act=np.ascontiguousarray(np.stack(cols,1))
    shapes=['全足|全足']+list(E.keys()); M=[np.ones(n,bool)]+[E[k] for k in E]
    o,h,l,c=[b[x].values.astype(float) for x in ('open','high','low','close')]
    cfg={}
    for side in (0,1):
        for conf in (0,1):
            e,j=entry(o,h,l,c,side,conf)
            for H in HS:
                ret=np.full(n,np.nan); xi=np.zeros(n,np.int64); ok=(j>=0)&(j+H-1<n); x=j[ok]+H-1; xi[ok]=x
                pnl=(c[x]-e[ok]) if side==0 else (e[ok]-c[x]); ret[ok]=(pnl-COST)/c[ok]*100; cfg[(side,conf,H)]=(ret,xi)
    yr=b.t.dt.year.values; per=(yr>=2023).astype(np.int64); warm=1300*60//tf
    return dict(b=b,act=act,names=names,shapes=shapes,M=M,cfg=cfg,per=per,warm=warm,n=n)
@njit(cache=True)
def entry(o,h,l,c,side,conf):
    n=len(c); e=np.full(n,np.nan); j=np.full(n,-1,np.int64)
    for i in range(n-1):
        if conf==0: j[i]=i+1; e[i]=o[i+1]
        else:
            lv=h[i]+5 if side==0 else l[i]-5
            for q in range(i+1,min(i+4,n)):
                if side==0 and h[q]>=lv: j[i]=q; e[i]=max(lv,o[q]); break
                if side==1 and l[q]<=lv: j[i]=q; e[i]=min(lv,o[q]); break
    return e,j
@njit(cache=True)
def kern(ev,ret,xi,act,per,shift,seg0,m,nst):
    out=np.zeros((nst,2,5)); free=np.zeros(nst,np.int64); nd=act.shape[1]
    for i in ev:
        r=ret[i]
        if np.isnan(r): continue
        row=i if shift==0 else seg0+((i-seg0+shift)%m); p=per[i]; x=xi[i]+1
        for d in range(nd):
            s=act[row,d]
            if s<0 or i<free[s]: continue
            free[s]=x; q=out[s,p]; q[0]+=1; q[1]+=r; q[2]+=r*r
            if r>0: q[3]+=r
            else: q[4]-=r
    return out
@njit(cache=True)
def summ(out,hist,mx,side,minn):
    b=out[0,0]
    if b[0]<2: return
    bm=b[1]/b[0]
    for s in range(1,out.shape[0]):
        q=out[s,0]; nn=q[0]
        if nn<minn: continue
        mu=q[1]/nn; var=(q[2]-nn*mu*mu)/(nn-1)
        if var<=0: continue
        t=(mu-bm)/np.sqrt(var/nn); pf=q[3]/max(q[4],1e-9); k=int(min(max((t+10)*4,0),79)); good=1 if (pf>=1.3 and mu>0) else 0
        hist[side,0,k]+=1
        if good: hist[side,1,k]+=1
        if t>mx[side,0]: mx[side,0]=t
        if good and t>mx[side,1]: mx[side,1]=t
def evlists(P,only0):
    n=P['n']; base=np.zeros(n,bool); base[P['warm']:n-50]=True
    if only0: base&=(P['per']==0)
    return [np.where(m&base)[0] for m in P['M']]
def run_null(P,shift,EV,hist,mx,minn=100):
    seg0=P['warm']; m=int((P['per']==0).sum())-seg0; nst=len(P['names'])
    for (side,conf,H),(ret,xi) in P['cfg'].items():
        for si in range(1,len(EV)):
            out=kern(EV[si],ret,xi,P['act'],P['per'],shift,seg0,m,nst); summ(out,hist,mx,side,minn)
if __name__=='__main__':
    mode=sys.argv[1]
    for tf in (60,30):
        t0=time.time(); P=prep(tf); pickle.dump(P,open(f'P{tf}.pkl','wb'),protocol=4)
        print(tf,'準備',round(time.time()-t0),'秒  足数',P['n'],' 状態数',len(P['names'])-1,' 定義数',P['act'].shape[1]-1,' 形',len(P['shapes'])-1,flush=True)
