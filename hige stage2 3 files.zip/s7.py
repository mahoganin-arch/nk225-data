# 段階2-2：(1) 形×形  (2) 髭×条件×条件（条件＝局面784＋髭以外の形＋A〜D固有条件）。偽データ＝条件側を時間方向にずらす
import pandas as pd, numpy as np, pickle, sys, time, warnings; warnings.filterwarnings('ignore')
from numba import njit
from s6 import kern, summ, evlists
from s1 import atr_
def load(tf):
    P=pickle.load(open(f'P{tf}.pkl','rb')); b=P['b']; o,h,l,c,v=b.open,b.high,b.low,b.close,b.volume; a=atr_(h,l,c); n=P['n']
    hr=b.t.dt.hour+b.t.dt.minute/60; ph=h.shift().rolling(20).max(); pl=l.shift().rolling(20).min(); mom=(c.shift(1)-c.shift(6))/a
    X={'固有|A時間帯(8:45〜11:30)':(hr>=8.75)&(hr<11.5),'固有|出来高が20本平均の1.5倍超':v>v.rolling(20).mean()*1.5,
       '固有|D安値スイープ(高値スイープ除く)':(l<pl)&(c>pl)&~((h>ph)&(c<ph)),'固有|D直前5本の勢い-2〜-0.7ATR':(mom>-2)&(mom<=-0.7)}
    X={k:np.asarray(x.fillna(False),bool) for k,x in X.items()}
    sh=P['shapes']; spike=[i for i,s in enumerate(sh) if s.startswith('髭|')]; other=[i for i,s in enumerate(sh) if i>0 and not s.startswith('髭|')]
    # (2)用：条件行列（局面＋髭以外の形＋固有）
    names=list(P['names']); cols=[P['act'].astype(np.int32)]
    for i in other: cols.append(np.where(P['M'][i],len(names),-1).astype(np.int32)[:,None]); names.append('形|'+sh[i])
    for k,x in X.items(): cols.append(np.where(x,len(names),-1).astype(np.int32)[:,None]); names.append(k)
    P['actX']=np.ascontiguousarray(np.hstack(cols)); P['namesX']=names; P['spike']=spike
    # (1)用：形＋固有だけの条件行列
    n1=['(全体)']; c1=[np.zeros((n,1),np.int32)]
    for i in range(1,len(sh)): c1.append(np.where(P['M'][i],len(n1),-1).astype(np.int32)[:,None]); n1.append(sh[i])
    for k,x in X.items(): c1.append(np.where(x,len(n1),-1).astype(np.int32)[:,None]); n1.append(k)
    P['act1']=np.ascontiguousarray(np.hstack(c1)).astype(np.int16); P['names1']=n1
    return P
@njit(cache=True)
def kern2(ev,ret,xi,act,per,shift,seg0,m,NC,out,free):
    out[:]=0; free[:]=0; nd=act.shape[1]; ids=np.empty(nd,np.int64)
    for i in ev:
        r=ret[i]
        if np.isnan(r): continue
        row=i if shift==0 else seg0+((i-seg0+shift)%m); p=per[i]; x=xi[i]+1; k=0
        for d in range(nd):
            s=act[row,d]
            if s>=0: ids[k]=s; k+=1
        g=r if r>0 else 0.0
        for a in range(k):
            base=ids[a]*NC
            for b in range(a if a==0 else a+1,k):
                key=base+ids[b]
                if i<free[key]: continue
                free[key]=x; q=out[key,p]; q[0]+=1; q[1]+=r; q[2]+=r*r; q[3]+=g
@njit(cache=True)
def summ2(out,hist,mx,side,minn):
    b=out[0,0]; bm=b[1]/b[0]
    for s in range(1,out.shape[0]):
        q=out[s,0]; nn=q[0]
        if nn<minn: continue
        mu=q[1]/nn; var=(q[2]-nn*mu*mu)/(nn-1)
        if var<=0: continue
        t=(mu-bm)/np.sqrt(var/nn); pf=q[3]/max(q[3]-q[1],1e-9); k=int(min(max((t+10)*4,0),79)); good=1 if (pf>=1.3 and mu>0) else 0
        hist[side,0,k]+=1
        if good: hist[side,1,k]+=1
        if t>mx[side,0]: mx[side,0]=t
        if good and t>mx[side,1]: mx[side,1]=t
def null1(P,shift,EV,hist,mx):
    seg0=P['warm']; m=int((P['per']==0).sum())-seg0; nst=len(P['names1'])
    for (side,conf,H),(ret,xi) in P['cfg'].items():
        for si in range(1,len(EV)):
            out=kern(EV[si],ret,xi,P['act1'],P['per'],shift,seg0,m,nst)
            if shift==0: out[si]=0          # 自分自身との組は除く
            summ(out,hist,mx,side,100)
def null2(P,shift,EV,hist,mx,buf):
    seg0=P['warm']; m=int((P['per']==0).sum())-seg0; NC=len(P['namesX']); out,free=buf
    for (side,conf,H),(ret,xi) in P['cfg'].items():
        for si in P['spike']:
            kern2(EV[si],ret,xi,P['actX'],P['per'],shift,seg0,m,NC,out,free); summ2(out,hist,mx,side,100)
if __name__=='__main__':
    mode=sys.argv[1]; Ps={tf:load(tf) for tf in (60,30)}
    if mode=='real':
        R1=[];R2=[]
        for tf in (60,30):
            P=Ps[tf]; EV=evlists(P,False); NC=len(P['namesX']); out=np.zeros((NC*NC,2,4)); free=np.zeros(NC*NC,np.int64); t0=time.time()
            for (side,conf,H),(ret,xi) in P['cfg'].items():
                for si in range(1,len(EV)):
                    o1=kern(EV[si],ret,xi,P['act1'],P['per'],0,0,1,len(P['names1'])); o1[si]=0; R1.append((tf,side,conf,H,si,o1.astype(np.float32)))
                for si in P['spike']:
                    kern2(EV[si],ret,xi,P['actX'],P['per'],0,0,1,NC,out,free)
                    n=out[:,0,0]; keep=np.where(n>=100)[0]; keep=np.concatenate([[0],keep[keep>0]]); R2.append((tf,side,conf,H,si,keep.astype(np.int32),out[keep].astype(np.float32)))
            print(tf,'本番',round(time.time()-t0),'秒',flush=True)
        pickle.dump((R1,R2),open('real7.pkl','wb'),protocol=4)
    else:
        seed=int(sys.argv[2]); nrun=int(sys.argv[3]); rng=np.random.default_rng(seed); res=[]
        EVs={tf:evlists(Ps[tf],True) for tf in (60,30)}; NC=len(Ps[60]['namesX']); buf=(np.zeros((NC*NC,2,4)),np.zeros(NC*NC,np.int64))
        for r in range(nrun):
            h1=np.zeros((2,2,80)); m1=np.full((2,2),-99.0); h2=np.zeros((2,2,80)); m2=np.full((2,2),-99.0); u=rng.uniform(0.1,0.9); t0=time.time()
            for tf in (60,30):
                P=Ps[tf]; m=int((P['per']==0).sum())-P['warm']; null1(P,int(u*m),EVs[tf],h1,m1); ta=time.time(); null2(P,int(u*m),EVs[tf],h2,m2,buf)
            res.append((u,h1,m1,h2,m2)); pickle.dump(res,open(f'null7_{seed}.pkl','wb'))
            print(r,round(time.time()-t0),'秒',m1.round(2).tolist(),m2.round(2).tolist(),flush=True)
