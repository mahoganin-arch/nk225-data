import pickle, numpy as np, pandas as pd, glob
pd.set_option('display.width',250,'display.max_colwidth',26,'display.unicode.east_asian_width',True)
T=pd.read_pickle('real9.pkl')
def tz(n,s,ss):
    mu=s/np.maximum(n,1); sd=np.sqrt(np.maximum((ss-n*mu*mu)/np.maximum(n-1,1),1e-12)/np.maximum(n,1)); return mu,mu/sd
T=T[(T.a0>=60)&(T.b0>=30)].copy()
T['ma'],T['ta']=tz(T.a0,T.a1,T.a2); T['mb'],T['tb']=tz(T.b0,T.b1,T.b2); T['z']=(T.ta+T.tb)/np.sqrt(2)
T['売買']=np.where(T.z>0,'買い','売り'); buy=T.z>0
for p in 'ab':
    T['超過PF'+p]=np.where(buy,T[p+'3']/T[p+'4'].clip(lower=1e-9),T[p+'5']/T[p+'6'].clip(lower=1e-9)); T['実PF'+p]=np.where(buy,T[p+'7']/T[p+'8'].clip(lower=1e-9),T[p+'9']/T[p+'10'].clip(lower=1e-9))
T.to_pickle('T9.pkl')
N=[]
for f in glob.glob('null9_4*.pkl'): N+=pickle.load(open(f,'rb'))
print('偽データ回数',len(N))
def counts(ta,tb):
    z=(ta+tb)/np.sqrt(2); both=(np.sign(ta)==np.sign(tb))
    return [len(z),np.abs(z).max()]+[int((np.abs(z)>=x).sum()) for x in (2,3,4)]+[int((both&(np.abs(ta)>=2)&(np.abs(tb)>=2)).sum()),int((z>=3).sum()),int((z<=-3).sum())]
lab=['評価数','最大|z|','|z|>=2','|z|>=3','|z|>=4','両期間とも|t|>=2で同方向','買い向きz>=3','売り向きz<=-3']
for fam,fn in ((0,'第1段：髭の定義のみ'),(1,'第2段：髭の定義×場所')):
    s=T[(T.場所=='場所不問')==(fam==0)]; r=counts(s.ta.values,s.tb.values); nn=np.array([counts(x[fam][:,0],x[fam][:,1]) for x in N])
    print('\n'+fn)
    for i,l in enumerate(lab): print(f'  {l}: 本番 {r[i]:.2f}' if i==1 else f'  {l}: 本番 {int(r[i])}', f' 偽 平均 {nn[:,i].mean():.1f} (5〜95%: {np.quantile(nn[:,i],.05):.1f}〜{np.quantile(nn[:,i],.95):.1f})')
