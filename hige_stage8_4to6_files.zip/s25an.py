# 第6回bの集計：従来のz・上乗せz・状態だけのz を、系統別に偽データと比べる
import pandas as pd, numpy as np
OUT='/mnt/user-data/outputs/'
def prep(T,dcol):
    T=T.rename(columns={'分類':'基準',dcol:'水準の側','条件':'髭足との関係'}); b=T['基準']
    T['種類']=np.where(b=='戻し','戻し',np.where(b.str.startswith('掛け合わせ'),'掛け合わせ',np.where(T['髭足との関係'].str.startswith('抜けた幅'),'更新の幅','関係'))); return T
def summ(T,zc,A,wick=True):
    az=T[zc].abs().values; out=[]; cols=['取り方','条件を見る足','種類','基準','水準の側']; grp=[('全体',np.ones(len(T),bool))]
    if wick: T['向き']=T['髭'].str[:2]+'×'+T['水準の側']; cols=['向き','髭の足']+cols
    else: cols=['入る足']+cols
    for k in cols: grp+=[(k+'：'+str(u),(T[k]==u).values) for u in T[k].unique()]
    dk='向き' if wick else '水準の側'; m=T['種類']!='掛け合わせ'
    grp+=[(d+'・'+r,((T[dk]==d)&(T['髭足との関係']==r)&m).values) for d in T[dk].unique() for r in T[m]['髭足との関係'].unique()]
    grp+=[(d+'・掛け合わせ・'+r,((T[dk]==d)&(T['髭足との関係']==r)&~m).values) for d in T[dk].unique() for r in T[~m]['髭足との関係'].unique()]
    for nm,sel in grp:
        if sel.sum()<50: continue
        a=A[:,sel]; mx=np.nanmax(a,1); d=dict(系統=nm,通り=int(sel.sum()),最大z_本番=az[sel].max(),最大z_偽平均=mx.mean(),最大z_偽上位5pct=np.percentile(mx,95))
        for k in (3,3.5): c=(a>=k).sum(1); n=int((az[sel]>=k).sum()); d[f'z{k}以上_本番']=n; d[f'z{k}以上_偽平均']=c.mean(); d[f'z{k}以上_偽上位5pct']=np.percentile(c,95); d[f'z{k}_偽が本番以上の割合']=(c>=n).mean()
        out.append(d)
    return pd.DataFrame(out).round(2)
def go():
    R={}; n='stage8_6b_髭足と水準の関係'; sv=lambda D,f: D.to_csv(OUT+f,index=False,encoding='utf-8-sig')
    T=prep(pd.read_pickle(f'T_{n}.pkl'),'トレンドの向き'); S0=summ(T,'z',np.load(f'null_{n}.npy')); sv(S0,n+'_偽データ比較.csv')
    try:
        S=pd.read_pickle('T_state8_6b.pkl'); sp=S['分類'].str.split('|',expand=True); S['分類']=sp[0]; S['d']=sp[1]; S=prep(S,'d'); R['状態']=(S,summ(S,'z',np.load('null_state8_6b.npy'),wick=False)); sv(R['状態'][1],'stage8_6b_状態だけ_偽データ比較.csv')
        Y=S[S.z.abs()>=2.5]; sv(Y.reindex(Y.z.abs().sort_values(ascending=False).index),'stage8_6b_状態だけ_一覧.csv')
    except FileNotFoundError: pass
    try:
        X=prep(pd.read_pickle('T_add8_6b.pkl'),'向き'); R['上乗せ']=(X,summ(X,'上乗せz',np.load('null_add8_6b.npy'))); sv(R['上乗せ'][1],'stage8_6b_髭の上乗せ_偽データ比較.csv')
        Y=X[X['上乗せz'].abs()>=2.5]; sv(Y.reindex(Y['上乗せz'].abs().sort_values(ascending=False).index),'stage8_6b_髭の上乗せ_一覧.csv')
        k=['髭の足','髭','大きさ','基準','髭足との関係','水準の側','条件を見る足','取り方','経過']; T=T.merge(X[k+['上乗せz']],on=k,how='left')
    except FileNotFoundError: pass
    R['従来']=(T,S0); Y=T[T.z.abs()>=2.5]; sv(Y.reindex(Y.z.abs().sort_values(ascending=False).index),n+'_一覧.csv'); pd.to_pickle(R,'R6b.pkl'); return R
if __name__=='__main__': go()
