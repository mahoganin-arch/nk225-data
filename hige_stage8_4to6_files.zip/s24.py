# 第8段 第6回a：髭 × 連続高値更新・連続安値更新（髭足の「前」の並び）。A 基準8種 × B 判定2種 × C 数え方12種 × 高値側・安値側。見る足は15分〜日足（髭足より短い足も含む）
import pandas as pd, numpy as np, sys, pickle, warnings; warnings.filterwarnings('ignore')
import s11, s17, s18, s20, s22
from s17 import gid, TFN
from s18 import streak
from s14 import m15, link
def tfv6(q,g,s,U):
    # 返り値：{(基準,判定): (updG, upd_f)} と補助。updG＝確定足ごとの更新の有無、upd_f＝15分足時点で形成中の足が更新しているか。s=-1 は価格を反転（安値更新）
    pc=s*q.close.values; ph=(q.high.values if s>0 else -q.low.values); G=int(g.max())+1; m=len(q)
    first=np.r_[True,g[1:]!=g[:-1]]; end=np.r_[g[1:]!=g[:-1],True]; H=pd.Series(ph).groupby(g).cummax().values; Hg=H[end]; Cg=pc[end]; hs=pd.Series(Hg)
    gd=s11.groups(q,'日足'); ic=q.t.groupby(gd).transform('max').dt.isocalendar(); gw=(ic.year.values.astype(np.int64)*100+ic.week.values.astype(np.int64)); hr=q.t.dt.hour.values; ses=np.unique(gd,return_inverse=True)[1]*2+((hr>=8)&(hr<16))
    run=lambda ids: hs.groupby(ids[first]).transform(lambda x:x.cummax().shift()).values
    hl='高' if s>0 else '安'; R={'1本前':hs.shift().values}
    for N in (5,10,20,50): R[f'直前{N}本']=hs.rolling(N).max().shift().values
    if U<1440: R['当日']=run(gd)
    if U<=240: R['セッション']=run(ses)
    R['今週']=run(gw); out={}
    with np.errstate(invalid='ignore'):
        for nm,ref in R.items():
            for jn,vg,vf in ((f'{hl}値が超えた',Hg,H),('終値が超えた',Cg,pc)): out[nm,jn]=(np.nan_to_num(vg>ref).astype(bool),np.nan_to_num(vf>ref[g]).astype(bool))
    return out,end
def stats(u):
    c=np.cumsum(u); i=np.arange(len(u)); last=np.maximum.accumulate(np.where(u,i,-10**6)); cnt=lambda M:c-np.r_[np.zeros(M,c.dtype),c[:-M]]
    return dict(run=streak(u),since=(i-last).astype(float),c5=cnt(5),c10=cnt(10),c20=cnt(20),c4=cnt(4),c9=cnt(9),c19=cnt(19))
def cset(run,c5,c10,c20,since):
    d={f'直前{k}本がすべて更新':run>=k for k in (2,3,4,5)}
    d.update({'直前5本のうち3本以上が更新':c5>=3,'直前5本のうち4本以上が更新':c5>=4,'直前10本のうち6本以上が更新':c10>=6,'直前20本のうち10本以上が更新':c20>=10})
    d.update({'最後の更新が直前の足':since==0,'最後の更新が2〜3本前':(since>=1)&(since<=2),'最後の更新が4〜10本前':(since>=3)&(since<=9),'直前10本に更新なし':since>=10}); return d
_C={};_L={}
def conds(q,tf,B,side):
    # 条件は上髭・下髭で共通（高値更新・安値更新の両方を、どちらの髭にも当てる）
    if tf in _L: return _L[tf]
    l=B['l']; out={}
    if tf==15: f=l
    else: P=pickle.load(open(f'P{tf}.pkl','rb')); f,_=link(P['b'],q,tf); f=np.clip(f,0,None)
    for U in (15,30,60,240,1440):
        g=gid(q,U).astype(np.int64)
        for s,dn in ((1,'高値更新'),(-1,'安値更新')):
            if (U,s) not in _C: _C[U,s]=tfv6(q,g,s,U)
            D,end=_C[U,s]
            if U==tf: modes=(('同じ足',g[l]-1),)
            elif U<tf: modes=(('短い足',np.where(f>=1,g[np.clip(f-1,0,None)],-1)),)
            else: modes=(('確定済み',g[l]-(~end[l]).astype(np.int64)),('形成中',None))
            for (ref,jn),(ug,uf) in D.items():
                S=stats(ug)
                for mode,jc in modes:
                    if jc is not None:
                        ok=jc>=0; j=np.clip(jc,0,None); C=cset(S['run'][j],S['c5'][j],S['c10'][j],S['c20'][j],S['since'][j])
                    else:
                        jp=g[l]-1; ok=jp>=0; j=np.clip(jp,0,None); u=uf[l]; C=cset(u*(S['run'][j]+1),S['c4'][j]+u,S['c9'][j]+u,S['c19'][j]+u,np.where(u,0.0,S['since'][j]+1))
                    for cn,v in C.items(): out[ref,jn+'／'+cn,dn,TFN[U],mode]=v&ok
    _L.clear(); _L[tf]=out; return out
if __name__=='__main__':
    a=sys.argv[1]; nm='stage8_6a_髭×連続更新'
    if a=='main': s18.run(nm,conds)
    if a=='add': s20.run('add8_6a',conds,NR=50)
    if a=='state': s22.conds=lambda q,tf,B,side:{(k[0]+'|'+k[2],)+k[1:]:v for k,v in conds(q,tf,B,side).items()}; s22.state('state8_6a')   # 状態だけ：更新の向きを分類に入れて残す
    if a=='test':
        q=m15(); B=s17.base(60,q); C=conds(q,60,B,'上髭'); v=B['valid']; print(len(C)); ks=[k for k in C if k[0]=='直前20本' and k[2]=='高値更新' and k[3] in ('1時間足','4時間足','15分足') and k[1].startswith('高')]
        for k in ks: print(k[3],k[4],k[1][7:],round(C[k][v].mean(),3))
