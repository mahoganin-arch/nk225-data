# 第5回の集計：従来のz・上乗せz・状態だけのz を、系統別に偽データと比べる
import pandas as pd, numpy as np, sys
OUT='/mnt/user-data/outputs/'
def summ(T,zc,A,extra=()):
    az=T[zc].abs().values; out=[]
    grp=[('全体',np.ones(len(T),bool))]+[('取り方：'+g,(T['取り方']==g).values) for g in ('同じ足','形成中','確定済み') if (T['取り方']==g).any()]
    grp+=[('分類：'+c,(T['分類']==c).values) for c in sorted(T['分類'].unique())]
    grp+=[('見る足：'+u,(T['条件を見る足']==u).values) for u in ('15分足','30分足','1時間足','4時間足','日足') if (T['条件を見る足']==u).any()]
    for k in extra: grp+=[(k+'：'+str(u),(T[k]==u).values) for u in T[k].unique()]
    grp+=[(c[:1]+'×'+g,((T['分類']==c)&(T['取り方']==g)).values) for c in sorted(T['分類'].unique()) for g in ('同じ足','形成中','確定済み')]
    for nm,sel in grp:
        if sel.sum()<50: continue
        a=A[:,sel]; mx=np.nanmax(a,1); d=dict(系統=nm,通り=int(sel.sum()),最大z_本番=az[sel].max(),最大z_偽平均=mx.mean(),最大z_偽上位5pct=np.percentile(mx,95))
        for k in (2.5,3,3.5): c=(a>=k).sum(1); n=int((az[sel]>=k).sum()); d[f'z{k}以上_本番']=n; d[f'z{k}以上_偽平均']=c.mean(); d[f'z{k}以上_偽上位5pct']=np.percentile(c,95); d[f'z{k}_偽が本番以上の割合']=(c>=n).mean()
        out.append(d)
    return pd.DataFrame(out).round(2)
def go():
    R={}
    T=pd.read_pickle('T_stage8_5_髭×値動きの大きさ.pkl').drop(columns='トレンドの向き'); T['髭の向き']=T['髭'].str[:2]; A=np.load('null_stage8_5_髭×値動きの大きさ.npy'); R['従来']=(T,summ(T,'z',A,('髭の向き','髭の足')))
    X=T[T.z.abs()>=2.5]; X.reindex(X.z.abs().sort_values(ascending=False).index).to_csv(OUT+'stage8_5_髭×値動きの大きさ_一覧.csv',index=False,encoding='utf-8-sig'); R['従来'][1].to_csv(OUT+'stage8_5_髭×値動きの大きさ_偽データ比較.csv',index=False,encoding='utf-8-sig')
    try:
        T=pd.read_pickle('T_state8_5.pkl'); A=np.load('null_state8_5.npy'); R['状態']=(T,summ(T,'z',A,('入る足',)))
        X=T[T.z.abs()>=2.5]; X.reindex(X.z.abs().sort_values(ascending=False).index).to_csv(OUT+'stage8_5_状態だけ_一覧.csv',index=False,encoding='utf-8-sig'); R['状態'][1].to_csv(OUT+'stage8_5_状態だけ_偽データ比較.csv',index=False,encoding='utf-8-sig')
    except FileNotFoundError: pass
    try:
        T=pd.read_pickle('T_add8_5.pkl').drop(columns='向き'); T['髭の向き']=T['髭'].str[:2]; A=np.load('null_add8_5.npy'); R['上乗せ']=(T,summ(T,'上乗せz',A,('髭の向き','髭の足')))
        X=T[T['上乗せz'].abs()>=2.5]; X.reindex(X['上乗せz'].abs().sort_values(ascending=False).index).to_csv(OUT+'stage8_5_髭の上乗せ_一覧.csv',index=False,encoding='utf-8-sig'); R['上乗せ'][1].to_csv(OUT+'stage8_5_髭の上乗せ_偽データ比較.csv',index=False,encoding='utf-8-sig')
    except FileNotFoundError: pass
    pd.to_pickle(R,'R5.pkl'); return R
if __name__=='__main__':
    R=go(); pd.set_option('display.width',250,'display.unicode.east_asian_width',True)
    for k,(T,S) in R.items():
        print('==',k,len(T)); print(S[['系統','通り','最大z_本番','最大z_偽平均','最大z_偽上位5pct','z3以上_本番','z3以上_偽平均','z3以上_偽上位5pct','z3_偽が本番以上の割合']].to_string(index=False))
