# 第8段 第5回：髭 × 値動きの大きさ（D-4）。A ATRの水準／B ATRの拡大・縮小／C 足の値幅／D 値幅の流れ・形／E 値動きの幅の指標／F 値動きの効率／G 窓・大きな足。枠組みは s18・s22 と同じ
import pandas as pd, numpy as np, sys, warnings; warnings.filterwarnings('ignore')
from numba import njit
import s17, s18, s20, s22
from s17 import gid, TFN
from s14 import m15
@njit(cache=True)
def se_range(g,st,ln,R):
    # 値幅を「同じ経過時点どうし」で直前の足と比べる。c[a]＝a+1本前の上位足の、同じ本数の15分足までの値幅
    m=len(g); M20=np.full(m,np.nan); MX20=np.full(m,np.nan); MX50=np.full(m,np.nan); MN20=np.full(m,np.nan); MN3=np.full(m,np.nan); MN6=np.full(m,np.nan); D=np.full(m,np.nan); UP=np.zeros(m,np.bool_); DN=np.zeros(m,np.bool_); c=np.zeros(50)
    for i in range(m):
        j=g[i]; k=i-st[j]; nb=min(j,50)
        for a in range(nb): p=j-1-a; c[a]=R[st[p]+min(k,ln[p]-1)]
        v=R[i]
        if nb>=3: MN3[i]=c[:3].min(); UP[i]=(v>c[0]) and (c[0]>c[1]) and (c[1]>c[2]); DN[i]=(v<c[0]) and (c[0]<c[1]) and (c[1]<c[2])
        if nb>=6: MN6[i]=c[:6].min()
        if nb>=20: M20[i]=c[:20].mean(); MX20[i]=c[:20].max(); MN20[i]=c[:20].min()
        if nb>=24: D[i]=((v+c[:4].sum())/5)/max(c[4:24].mean(),1e-9)
        if nb>=50: MX50[i]=c.max()
    return M20,MX20,MX50,MN20,MN3,MN6,D,UP,DN
@njit(cache=True)
def rank(x,Xc,g,N):
    # 形成中の値 x が、直前N本の確定足の値 Xc の中で下から何割の位置か
    m=len(x); out=np.full(m,np.nan)
    for i in range(m):
        j=g[i]
        if j<N or np.isnan(x[i]) or np.isnan(Xc[j-N]): continue
        n=0
        for p in range(j-N,j):
            if Xc[p]<x[i]: n+=1
        out[i]=n/N
    return out
def tfv5(q,g,s):
    up=s>0; tk=dict(up='上昇',dn='下落',yo='陽線',inn='陰線',U='上',D='下') if up else dict(up='下落',dn='上昇',yo='陰線',inn='陽線',U='下',D='上')
    pc=s*q.close.values; po=s*q.open.values; ph=(q.high.values if up else -q.low.values); pl=(q.low.values if up else -q.high.values); G=int(g.max())+1; m=len(q); g=g.astype(np.int64)
    first=np.r_[True,g[1:]!=g[:-1]]; end=np.r_[g[1:]!=g[:-1],True]; st=np.where(first)[0].astype(np.int64); ln=np.diff(np.r_[st,m]).astype(np.int64)
    H=pd.Series(ph).groupby(g).cummax().values; L=pd.Series(pl).groupby(g).cummin().values; O=po[first][g]
    Cg=pc[end]; Og=po[first]; Hg=H[end]; Lg=L[end]; cs=pd.Series(Cg); hs=pd.Series(Hg); ls=pd.Series(Lg)
    def lag(x,k): y=np.full(G+k,np.nan); y[k:]=x; return y[g]
    pC=cs.shift().values; TRg=np.fmax(np.fmax(Hg-Lg,np.abs(Hg-pC)),np.abs(Lg-pC)); c1=lag(Cg,1); tr=np.fmax(np.fmax(H-L,np.abs(H-c1)),np.abs(L-c1)); AC={};AT={}
    for n in (5,14,50): AC[n]=pd.Series(TRg).ewm(alpha=1/n,adjust=False,min_periods=n).mean().values; AT[n]=(lag(AC[n],1)*(n-1)+tr)/n
    a=AT[14]; ac=AC[14]; ap=lag(ac,1); R=H-L; F={}
    def add(cat,name,v_): F[cat,name]=np.nan_to_num(v_).astype(bool)
    with np.errstate(invalid='ignore',divide='ignore'):
        x=a/lag(pd.Series(ac).rolling(100).mean().values,1)
        for lo_,hi_,nm in ((0,0.7,'0.7倍未満'),(0.7,0.9,'0.7〜0.9倍'),(0.9,1.1,'0.9〜1.1倍'),(1.1,1.3,'1.1〜1.3倍'),(1.3,1.6,'1.3〜1.6倍'),(1.6,1e9,'1.6倍以上')): add('A ATRの水準',f'ATRが直前100本平均の{nm}',(x>=lo_)&(x<hi_))
        rk=rank(a,ac,g,100)
        add('A ATRの水準','ATRが直前100本の中で上位10%',rk>=0.9); add('A ATRの水準','ATRが直前100本の中で上位25%',rk>=0.75); add('A ATRの水準','ATRが直前100本の中で下位25%',rk<=0.25); add('A ATRの水準','ATRが直前100本の中で下位10%',rk<=0.1)
        x=a/lag(ac,5); add('B ATRの拡大・縮小','ATRが5本前より10%以上増',x>=1.1); add('B ATRの拡大・縮小','ATRが5本前より10%以上減',x<=0.9)
        x=a/lag(ac,20); add('B ATRの拡大・縮小','ATRが20本前より20%以上増',x>=1.2); add('B ATRの拡大・縮小','ATRが20本前より20%以上減',x<=0.8)
        x=AT[5]/AT[50]; add('B ATRの拡大・縮小','短期ATR（5本）が長期ATR（50本）の1.3倍以上',x>=1.3); add('B ATRの拡大・縮小','短期ATR（5本）が長期ATR（50本）の0.7倍以下',x<=0.7)
        a1,a2,a3=lag(ac,1),lag(ac,2),lag(ac,3); add('B ATRの拡大・縮小','ATRが3本連続で拡大',(a>a1)&(a1>a2)&(a2>a3)); add('B ATRの拡大・縮小','ATRが3本連続で縮小',(a<a1)&(a1<a2)&(a2<a3))
        M20,MX20,MX50,MN20,MN3,MN6,D,UP,DN=se_range(g,st,ln,R); x=R/np.where(M20>0,M20,np.nan)
        for lo_,hi_,nm in s22.BANDS: add('C 足の値幅',f'値幅が直前20本平均の{nm}',(x>=lo_)&(x<hi_))
        x=R/ap
        for lo_,hi_,nm in ((0,0.5,'0.5倍未満'),(0.5,1,'0.5〜1倍'),(1,1.5,'1〜1.5倍'),(1.5,1e9,'1.5倍以上')): add('C 足の値幅',f'値幅がATRの{nm}',(x>=lo_)&(x<hi_))
        add('C 足の値幅','値幅が直前20本の中で最大',R>MX20); add('C 足の値幅','値幅が直前50本の中で最大',R>MX50); add('C 足の値幅','値幅が直前20本の中で最小',R<MN20)
        add('D 値幅の流れ・形','値幅が直前4本の中で最小',R<MN3); add('D 値幅の流れ・形','値幅が直前7本の中で最小',R<MN6)
        h1,l1=lag(Hg,1),lag(Lg,1); add('D 値幅の流れ・形','はらみ足（前の足の内側）',(H<=h1)&(L>=l1)); add('D 値幅の流れ・形','包み足（前の足を包む）',(H>h1)&(L<l1))
        add('D 値幅の流れ・形','直近5本の値幅の平均が、その前20本の1.3倍以上',D>=1.3); add('D 値幅の流れ・形','直近5本の値幅の平均が、その前20本の0.7倍以下',D<=0.7)
        add('D 値幅の流れ・形','値幅が3本連続で拡大',UP); add('D 値幅の流れ・形','値幅が3本連続で縮小',DN)
        s1=lag(cs.rolling(19).sum().values,1)+pc; s2=lag((cs*cs).rolling(19).sum().values,1)+pc*pc; bw=4*np.sqrt(np.maximum(s2/20-(s1/20)**2,0)); BW=4*cs.rolling(20).std(ddof=0).values
        x=bw/lag(pd.Series(BW).rolling(100).mean().values,1); add('E 値動きの幅の指標','BB幅が直前100本平均の0.7倍以下',x<=0.7); add('E 値動きの幅の指標','BB幅が直前100本平均の1.3倍以上',x>=1.3)
        rk=rank(bw,BW,g,100); add('E 値動きの幅の指標','BB幅が直前100本の中で下位10%',rk<=0.1); add('E 値動きの幅の指標','BB幅が直前100本の中で上位10%',rk>=0.9)
        b5=lag(BW,5); add('E 値動きの幅の指標','BB幅が5本前より拡大',bw>b5); add('E 値動きの幅の指標','BB幅が5本前より縮小',bw<b5)
        rn=np.maximum(lag(hs.rolling(19).max().values,1),H)-np.minimum(lag(ls.rolling(19).min().values,1),L); RN=(hs.rolling(20).max()-ls.rolling(20).min()).values; rk=rank(rn,RN,g,100)
        add('E 値動きの幅の指標','直近20本の高値−安値の幅が直前100本の中で下位25%',rk<=0.25); add('E 値動きの幅の指標','直近20本の高値−安値の幅が直前100本の中で上位25%',rk>=0.75)
        ad=pd.Series(np.abs(np.diff(Cg,prepend=np.nan)))
        for N in (10,20):
            ch=pc-lag(Cg,N); er=np.abs(ch)/(lag(ad.rolling(N-1).sum().values,1)+np.abs(pc-c1))
            add('F 値動きの効率',f'直近{N}本が{tk["up"]}で効率比0.5以上',(ch>0)&(er>=0.5)); add('F 値動きの効率',f'直近{N}本が{tk["dn"]}で効率比0.5以上',(ch<0)&(er>=0.5)); add('F 値動きの効率',f'直近{N}本の効率比が0.2以下（もみ合い）',er<=0.2)
        gp=(O-c1)/ap; add('G 窓・大きな足',f'始値が前の足の終値よりATRの0.5倍以上{tk["U"]}（窓）',gp>=0.5); add('G 窓・大きな足',f'始値が前の足の終値よりATRの0.5倍以上{tk["D"]}（窓）',gp<=-0.5)
        big=(Hg-Lg)>=2*pd.Series(ac).shift().values
        add('G 窓・大きな足',f'直前5本以内に値幅がATRの2倍以上の{tk["yo"]}',lag(pd.Series((big&(Cg>Og)).astype(float)).rolling(5).max().values,1)>0); add('G 窓・大きな足',f'直前5本以内に値幅がATRの2倍以上の{tk["inn"]}',lag(pd.Series((big&(Cg<Og)).astype(float)).rolling(5).max().values,1)>0)
    e=np.where(end,np.arange(m),-1); e=np.maximum.accumulate(e); Cf={k:np.where(e>=0,v_[np.clip(e,0,None)],False) for k,v_ in F.items()}
    return F,Cf
_C={}
def conds(q,tf,B,side):
    s=1 if side=='上髭' else -1; out={}
    for U in (15,30,60,240,1440):
        if U<tf: continue
        if (U,s) not in _C: _C[U,s]=tfv5(q,gid(q,U),s)
        F,Cf=_C[U,s]
        for mode,V in (('同じ足',F),) if U==tf else (('形成中',F),('確定済み',Cf)):
            for (cat,nm),v in V.items(): out[cat,nm,cat[0],TFN[U],mode]=v[B['l']]
    return out
if __name__=='__main__':
    a=sys.argv[1]
    if a=='main': s18.run('stage8_5_髭×値動きの大きさ',conds)
    if a=='add': s20.run('add8_5',conds)
    if a=='state': s22.conds=conds; s22.state('state8_5')
    if a=='test':
        q=m15()
        for U in (15,240):
            F,Cf=tfv5(q,gid(q,U),1); print(U,len(F),' '.join(f'{v[20000:].mean():.2f}' for v in F.values()))
