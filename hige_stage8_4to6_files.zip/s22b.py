# 第4回の追加確認：状態だけ上位（日足・直近20本で価格上昇×出来高増・確定済み）の年別と、4時間足RSI70以上との重なり
import pandas as pd, numpy as np, warnings; warnings.filterwarnings('ignore')
import s17, s19, s22
from s17 import base, pick, tz2, gid
from s14 import m15
q=m15(); tf=30; B=base(tf,q); per=B['per']; yr=B['b'].t.dt.year.values
C=s22.conds(q,tf,B,'上髭'); k=[x for x in C if x[1]=='直近20本で価格上昇×出来高増' and x[3]=='日足' and x[4]=='確定済み'][0]; cm=C[k]&B['valid']
F,_=s17.tfvals(q,gid(q,240),1); rsi=F['rsi'][B['l']]>=70
for N,h in ((8,4),(80,40)):
    e=B['E'][N]; x=B['X'][N]
    for nm,m_ in (('状態すべて',cm),('うち4時間足RSI70未満',cm&~rsi),('うち4時間足RSI70以上',cm&rsi),('RSI70以上で状態の外',~cm&rsi&B['valid'])):
        idx=pick(np.where(m_)[0],h,e); t0,t1,z=tz2(idx,e,per); print(N,nm,len(idx),round(t0,2),round(t1,2),round(z,2))
    idx=pick(np.where(cm)[0],h,e); r=[]
    for y in range(2017,2027):
        i=idx[yr[idx]==y]; v=x[i]-B['cost'][i]; r.append((y,len(i),round(np.nanmean(x[i]),3),round(v[v>0].sum()/max(-v[v<=0].sum(),1e-9),2)))
    print(N,'年別（年,回数,平均超過%,超過PF）',r)
