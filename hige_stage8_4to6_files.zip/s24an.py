# 第6回aの集計：従来のz・上乗せz・状態だけのz を、系統別に偽データと比べる
import pandas as pd, numpy as np, sys
OUT='/mnt/user-data/outputs/'
def prep(T,dcol):
    T=T.rename(columns={'分類':'基準',dcol:'更新の向き'}); sp=T['条件'].str.split('／',expand=True); T['判定']=np.where(sp[0].str.startswith('終値'),'終値で判定','高値・安値で判定'); T['数え方']=sp[1]
    T['数え方の種類']=np.where(T['数え方'].str.contains('すべて'),'連続',np.where(T['数え方'].str.contains('のうち'),'M本中k本','最後の更新')); return T
def summ(T,zc,A,wick=True):
    az=T[zc].abs().values; out=[]; cols=['取り方','条件を見る足','基準','判定','数え方の種類','数え方','更新の向き']; grp=[('全体',np.ones(len(T),bool))]
    if wick: T['向き']=T['髭'].str[:2]+'×'+T['更新の向き']; cols=['向き','髭の足']+cols
    else: cols=['入る足']+cols
    for k in cols: grp+=[(k+'：'+str(u),(T[k]==u).values) for u in T[k].unique()]
    grp+=[(d+'・'+b+'・'+c,((T['更新の向き']==d)&(T['基準']==b)&(T['数え方の種類']==c)).values) for d in T['更新の向き'].unique() for b in T['基準'].unique() for c in T['数え方の種類'].unique()]
    for nm,sel in grp:
        if sel.sum()<50: continue
        a=A[:,sel]; mx=np.nanmax(a,1); d=dict(系統=nm,通り=int(sel.sum()),最大z_本番=az[sel].max(),最大z_偽平均=mx.mean(),最大z_偽上位5pct=np.percentile(mx,95))
        for k in (3,3.5): c=(a>=k).sum(1); n=int((az[sel]>=k).sum()); d[f'z{k}以上_本番']=n; d[f'z{k}以上_偽平均']=c.mean(); d[f'z{k}以上_偽上位5pct']=np.percentile(c,95); d[f'z{k}_偽が本番以上の割合']=(c>=n).mean()
        out.append(d)
    return pd.DataFrame(out).round(2)
def go():
    R={}; n='stage8_6a_髭×連続更新'
    T=prep(pd.read_pickle(f'T_{n}.pkl'),'トレンドの向き'); R['従来']=(T,summ(T,'z',np.load(f'null_{n}.npy'))); R['従来'][1].to_csv(OUT+n+'_偽データ比較.csv',index=False,encoding='utf-8-sig')
    try:
        S=pd.read_pickle('T_state8_6a.pkl'); sp=S['分類'].str.split('|',expand=True); S['分類']=sp[0]; S['d']=sp[1]; S=prep(S,'d')
        R['状態']=(S,summ(S,'z',np.load('null_state8_6a.npy'),wick=False)); R['状態'][1].to_csv(OUT+'stage8_6a_状態だけ_偽データ比較.csv',index=False,encoding='utf-8-sig')
        Y=S[S.z.abs()>=2.5]; Y.reindex(Y.z.abs().sort_values(ascending=False).index).drop(columns='条件').to_csv(OUT+'stage8_6a_状態だけ_一覧.csv',index=False,encoding='utf-8-sig')
    except FileNotFoundError: pass
    try:
        X=prep(pd.read_pickle('T_add8_6a.pkl'),'向き'); R['上乗せ']=(X,summ(X,'上乗せz',np.load('null_add8_6a.npy'))); R['上乗せ'][1].to_csv(OUT+'stage8_6a_髭の上乗せ_偽データ比較.csv',index=False,encoding='utf-8-sig')
        Y=X[X['上乗せz'].abs()>=2.5]; Y.reindex(Y['上乗せz'].abs().sort_values(ascending=False).index).drop(columns='条件').to_csv(OUT+'stage8_6a_髭の上乗せ_一覧.csv',index=False,encoding='utf-8-sig')
        k=['髭の足','髭','大きさ','基準','条件','更新の向き','条件を見る足','取り方','経過']; T=T.merge(X[k+['上乗せz']],on=k,how='left'); R['従来']=(T,R['従来'][1])
    except FileNotFoundError: pass
    Y=T[T.z.abs()>=2.5]; Y.reindex(Y.z.abs().sort_values(ascending=False).index).drop(columns='条件').to_csv(OUT+n+'_一覧.csv',index=False,encoding='utf-8-sig')
    pd.to_pickle(R,'R6a.pkl'); return R
if __name__=='__main__': go()
