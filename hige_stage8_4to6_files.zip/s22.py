# 第8段 第4回：髭 × 出来高（D-3）。A 直前平均比／B 時間帯比／C 突出／D 増減の流れ／E 値動き×出来高／F 上げ足・下げ足の偏り／G 値幅あたりの出来高。枠組みは s18 と同じ
# 形成中の上位足は「同じ経過時点どうし」で比べる（直前の各足の、開始から同じ本数の15分足までの値と比較）
import pandas as pd, numpy as np, sys, time, warnings; warnings.filterwarnings('ignore')
from numba import njit
import s17, s18, s19, s20
from s17 import gid, TFN, OUT, base, pick, tz2, NS, LAB
from s18 import nullz
from s19 import prevmax
from s14 import m15
from s1 import atr_
@njit(cache=True)
def same_elapsed(g,st,ln,Vc,eff):
    # 各15分足 i（上位足 j の k 本目）について、直前の上位足 p の「k 本目まで」の累積出来高 c[p] を使った統計
    m=len(g); R5=np.full(m,np.nan); R20=np.full(m,np.nan); R100=np.full(m,np.nan); MX=np.full((3,m),np.nan); MN=np.full((2,m),np.nan); D1=np.full(m,np.nan); GM=np.full(m,np.nan); c=np.zeros(100); ef=np.zeros(20)
    for i in range(m):
        j=g[i]; k=i-st[j]; nb=min(j,100)
        for a in range(nb):
            p=j-1-a; idx=st[p]+min(k,ln[p]-1); c[a]=Vc[idx]
            if a<20: ef[a]=eff[idx]
        v=Vc[i]
        if nb>=5: R5[i]=v/max(c[:5].mean(),1e-9)
        if nb>=20: R20[i]=v/max(c[:20].mean(),1e-9); MX[0,i]=c[:20].max(); MN[0,i]=c[:20].min(); GM[i]=np.nanmedian(ef)
        if nb>=24: D1[i]=((v+c[:4].sum())/5)/max(c[4:24].mean(),1e-9)
        if nb>=50: MX[1,i]=c[:50].max(); MN[1,i]=c[:50].min()
        if nb>=100: R100[i]=v/max(c.mean(),1e-9); MX[2,i]=c.max()
    return R5,R20,R100,MX,MN,D1,GM
_E={}
def expected(q):
    # 時間帯比の分母：過去20（60）営業日の同じ時刻の15分足の出来高の平均。当日は含めない
    if 'e' not in _E:
        hm=(q.t.dt.hour*100+q.t.dt.minute).values; v=q.volume.astype(float)
        _E['e']={20:v.groupby(hm).transform(lambda s:s.shift().rolling(20,min_periods=5).mean()).values,60:v.groupby(hm).transform(lambda s:s.shift().rolling(60,min_periods=20).mean()).values}
    return _E['e']
BANDS=((0,0.5,'0.5倍未満'),(0.5,0.8,'0.5〜0.8倍'),(0.8,1.2,'0.8〜1.2倍'),(1.2,1.5,'1.2〜1.5倍'),(1.5,2,'1.5〜2倍'),(2,3,'2〜3倍'),(3,1e9,'3倍以上'))
def tfv4(q,g,s,U):
    up=s>0; tk=dict(up='上昇',dn='下落',yo='陽線',hi='高値') if up else dict(up='下落',dn='上昇',yo='陰線',hi='安値'); ab=('上','下') if up else ('下','上')
    pc=s*q.close.values; po=s*q.open.values; ph=(q.high.values if up else -q.low.values); pl=(q.low.values if up else -q.high.values); v=q.volume.values.astype(float); G=int(g.max())+1; m=len(q)
    first=np.r_[True,g[1:]!=g[:-1]]; end=np.r_[g[1:]!=g[:-1],True]; st=np.where(first)[0]; ln=np.diff(np.r_[st,m])
    def gcum(x): c=np.cumsum(x); return c-(c[st[g]]-x[st[g]])
    H=pd.Series(ph).groupby(g).cummax().values; L=pd.Series(pl).groupby(g).cummin().values; O=po[first][g]; Vc=gcum(v)
    Cg=pc[end]; Og=po[first]; Hg=H[end]; Lg=L[end]; Vg=Vc[end]; cs=pd.Series(Cg); hs=pd.Series(Hg); ls=pd.Series(Lg)
    def lag(x,k): y=np.full(G+k,np.nan); y[k:]=x; return y[g]
    EV=expected(q); rel={}
    for n,e in EV.items(): bad=gcum(np.isnan(e).astype(float)); rel[n]=np.where(bad==0,Vc/np.maximum(gcum(np.nan_to_num(e)),1e-9),np.nan)
    r=rel[20]; RG=r[end]; rs=pd.Series(RG); atr=lag(atr_(hs,ls,cs).values,1); rng=(H-L)/atr; eff=np.where(rng>0,r/np.where(rng>0,rng,1),np.nan)
    R5,R20,R100,MX,MN,D1,GM=same_elapsed(g.astype(np.int64),st.astype(np.int64),ln.astype(np.int64),Vc,eff)
    F={}
    def add(cat,name,v_): F[cat,name]=np.nan_to_num(v_).astype(bool)
    with np.errstate(invalid='ignore'):
        for a,b,nm in BANDS: add('A 水準（直前平均比）',f'直前20本比が{nm}',(R20>=a)&(R20<b)); add('B 水準（時間帯比）',f'時間帯比（20営業日）が{nm}',(r>=a)&(r<b))
        for N,R in ((5,R5),(100,R100)):
            add('A 水準（直前平均比）',f'直前{N}本比が0.7倍未満',R<0.7); add('A 水準（直前平均比）',f'直前{N}本比が1.5倍以上',R>=1.5); add('A 水準（直前平均比）',f'直前{N}本比が2倍以上',R>=2)
        add('B 水準（時間帯比）','時間帯比（60営業日）が0.7倍未満',rel[60]<0.7); add('B 水準（時間帯比）','時間帯比（60営業日）が1.5倍以上',rel[60]>=1.5); add('B 水準（時間帯比）','時間帯比（60営業日）が2倍以上',rel[60]>=2)
        for k,N in enumerate((20,50,100)): add('C 突出',f'出来高が直前{N}本の中で最大',Vc>MX[k])
        for k,N in enumerate((20,50)): add('C 突出',f'出来高が直前{N}本の中で最小',Vc<MN[k])
        add('D 増減の流れ','直近5本の平均が、その前20本の1.3倍以上（生の出来高）',D1>=1.3); add('D 増減の流れ','直近5本の平均が、その前20本の0.7倍以下（生の出来高）',D1<=0.7)
        d2=((lag(rs.rolling(4).sum().values,1)+r)/5)/lag(rs.rolling(20).mean().values,5)
        add('D 増減の流れ','直近5本の平均が、その前20本の1.3倍以上（時間帯比）',d2>=1.3); add('D 増減の流れ','直近5本の平均が、その前20本の0.7倍以下（時間帯比）',d2<=0.7)
        r1,r2,r3=lag(RG,1),lag(RG,2),lag(RG,3)
        add('D 増減の流れ','出来高が3本連続で増加（時間帯比）',(r>r1)&(r1>r2)&(r2>r3)); add('D 増減の流れ','出来高が3本連続で減少（時間帯比）',(r<r1)&(r1<r2)&(r2<r3))
        add('D 増減の流れ','出来高が前の足より増加（時間帯比）',r>r1); add('D 増減の流れ','出来高が前の足より減少（時間帯比）',r<r1)
        for N in (5,10,20):
            cur=(lag(rs.rolling(N-1).sum().values,1)+r)/N; prv=lag(rs.rolling(N).mean().values,N); c0=lag(Cg,N)
            for pn,pm in ((tk['up'],pc>c0),(tk['dn'],pc<c0)):
                add('E 値動き×出来高',f'直近{N}本で価格{pn}×出来高増',pm&(cur>prv)); add('E 値動き×出来高',f'直近{N}本で価格{pn}×出来高減',pm&(cur<prv))
        uv=pd.Series(Vg*(Cg>Og))
        for N in (10,20):
            sh=(lag(uv.rolling(N-1).sum().values,1)+Vc*(pc>O))/(lag(pd.Series(Vg).rolling(N-1).sum().values,1)+Vc)
            add('F 上げ足・下げ足の偏り',f'直近{N}本で{tk["yo"]}の出来高が60%以上',sh>=0.6); add('F 上げ足・下げ足の偏り',f'直近{N}本で{tk["yo"]}の出来高が40%以下',sh<=0.4)
        OB=np.cumsum(np.nan_to_num(np.sign(np.diff(Cg,prepend=np.nan)))*Vg); obv=lag(OB,1)+np.sign(pc-lag(Cg,1))*Vc; o20=lag(OB,20)
        add('F 上げ足・下げ足の偏り',f'OBVが20本前より{ab[0]}',obv>o20); add('F 上げ足・下げ足の偏り',f'OBVが20本前より{ab[1]}',obv<o20)
        nh=H>lag(hs.rolling(20).max().values,1); om=lag(pd.Series(OB).rolling(20).max().values,1); wd='最高' if up else '最低'
        add('F 上げ足・下げ足の偏り',f'{tk["hi"]}が直前20本{tk["hi"]}を更新、OBVも直前20本の{wd}を更新',nh&(obv>om)); add('F 上げ足・下げ足の偏り',f'{tk["hi"]}が直前20本{tk["hi"]}を更新、OBVは{wd}を更新せず',nh&(obv<=om))
        M,VV=prevmax(Hg,RG,20)
        add('F 上げ足・下げ足の偏り',f'{tk["hi"]}が直前20本{tk["hi"]}を更新、出来高は前回{tk["hi"]}の足より少ない',(H>M[g])&(r<VV[g])); add('F 上げ足・下げ足の偏り',f'{tk["hi"]}が直前20本{tk["hi"]}を更新、出来高は前回{tk["hi"]}の足より多い',(H>M[g])&(r>VV[g]))
        ge=eff/GM
        add('G 値幅あたりの出来高','値幅あたりの出来高が直前20本の中央値の1.5倍以上（出来高の割に動かない）',ge>=1.5); add('G 値幅あたりの出来高','値幅あたりの出来高が直前20本の中央値の0.67倍以下（出来高の割に動いた）',ge<=0.67)
    e=np.where(end,np.arange(m),-1); e=np.maximum.accumulate(e); Cf={k:np.where(e>=0,v_[np.clip(e,0,None)],False) for k,v_ in F.items()}
    return F,Cf
_C={}
def conds(q,tf,B,side):
    s=1 if side=='上髭' else -1; out={}
    for U in (15,30,60,240,1440):
        if U<tf: continue
        if (U,s) not in _C: _C[U,s]=tfv4(q,gid(q,U),s,U)
        F,Cf=_C[U,s]
        for mode,V in (('同じ足',F),) if U==tf else (('形成中',F),('確定済み',Cf)):
            for (cat,nm),v in V.items():
                if U==1440 and mode=='確定済み' and cat.startswith('B'): continue
                out[cat,nm,cat[0],TFN[U],mode]=v[B['l']]
    return out
def state(name='state8_4',NR=100,seed=7):
    # 状態だけ（髭なし）。上髭側の条件一式＋下髭側はF（向きのある条件）のうち上髭側と名前が違うものだけ
    q=m15(); rows=[]; NZ=[]; rng=np.random.default_rng(seed); us=rng.uniform(0.1,0.9,NR); buf=np.zeros(NR); t0=time.time()
    for tf in (60,30,15):
        B=base(tf,q); w0=B['warm']; sfts=(us*(B['n']-w0)).astype(np.int64); per=B['per']; hold={N:int(np.ceil(N*15/tf)) for N in NS}; seen=set()
        for d in ('上髭','下髭'):
            for key,cm in conds(q,tf,B,d).items():
                if key in seen: continue
                seen.add(key); ix=np.where(cm&B['valid'])[0]
                if len(ix)<90: continue
                for N in NS:
                    e=B['E'][N]; idx=pick(ix,hold[N],e); p=per[idx]; n1=int(p.sum()); n0=len(p)-n1
                    if n0<60 or n1<30: continue
                    t_0,t_1,z=tz2(idx,e,per); za=tz2(idx,B['EA'][N],per)[2]; sg=1 if z>0 else -1; pf=[]
                    for k in (0,1): v=sg*B['X'][N][idx[p==k]]-B['cost'][idx[p==k]]; pf.append(round(v[v>0].sum()/max(-v[v<=0].sum(),1e-9),2))
                    nullz(idx,e,per,w0,sfts,buf); NZ.append(buf.astype(np.float32)); cat,cn,_,un,mode=key
                    rows.append((TFN[tf],cat,cn,un,mode,LAB[N],'買い' if z>0 else '売り',n0,round(t_0,2),pf[0],n1,round(t_1,2),pf[1],round(z,2),round(za,2)))
        print(tf,len(rows),int(time.time()-t0),'秒',flush=True)
    T=pd.DataFrame(rows,columns=['入る足','分類','条件','条件を見る足','取り方','経過','売買','17-22 回数','17-22 t','17-22 超過PF','23-26 回数','23-26 t','23-26 超過PF','z','z（ATR単位）'])
    T.to_pickle(f'T_{name}.pkl'); np.save(f'null_{name}.npy',np.array(NZ).T); print('本番',len(T))
if __name__=='__main__':
    a=sys.argv[1]
    if a=='main': s18.run('stage8_4_髭×出来高',conds)
    if a=='add': s20.run('add8_4',conds)
    if a=='state': state()
    if a=='test':
        q=m15()
        for U in (15,60,240,1440):
            F,Cf=tfv4(q,gid(q,U),1,U); print(U,len(F)); print({k[1][:22]:round(float(v[20000:].mean()),3) for k,v in F.items()}); print('確定',{k[1][:14]:round(float(v[20000:].mean()),3) for k,v in list(Cf.items())[:14]})
