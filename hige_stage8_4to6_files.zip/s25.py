# 第8段 第6回b：髭足と水準の関係（髭足が水準を抜けたか・戻されたか・届かなかったか、更新の幅、上昇前の水準まで戻したか、前の並びとの掛け合わせ18条件）。高値側・安値側の両方を、上髭・下髭の両方に当てる
# 水準は、髭足が始まる時点で確定している足だけで作る（上位足の形成中の足は含めない）
import pandas as pd, numpy as np, sys, pickle, warnings; warnings.filterwarnings('ignore')
import s11, s17, s18, s20, s20b, s22, s24
from s17 import gid, TFN
from s18 import streak
from s14 import m15, link
_I={};_G={};_L={}
def ids(q):
    if 'x' not in _I:
        gd=s11.groups(q,'日足'); ic=q.t.groupby(gd).transform('max').dt.isocalendar(); gw=(ic.year.values.astype(np.int64)*100+ic.week.values.astype(np.int64)); hr=q.t.dt.hour.values
        _I['x']=dict(day=np.unique(gd,return_inverse=True)[1],week=np.unique(gw,return_inverse=True)[1]); _I['x']['ses']=_I['x']['day']*2+((hr>=8)&(hr<16))
    return _I['x']
def levels(q,U,s):
    # 確定足 j が終わった時点で使える水準（j を含む）。s=-1 は価格を反転（安値側）
    if (U,s) in _G: return _G[U,s]
    I=ids(q); g=(I['week'] if U=='W' else gid(q,U)).astype(np.int64); pc=s*q.close.values; po=s*q.open.values; ph=(q.high.values if s>0 else -q.low.values); pl=(q.low.values if s>0 else -q.high.values)
    first=np.r_[True,g[1:]!=g[:-1]]; end=np.r_[g[1:]!=g[:-1],True]; Hg=pd.Series(ph).groupby(g).max().values; Lg=pd.Series(pl).groupby(g).min().values; Og=po[first]; hs=pd.Series(Hg); ls=pd.Series(Lg); G=len(Hg); Lv={}; scope={}
    if U=='W': Lv['前週']=Hg
    else:
        Lv['1本前']=Hg
        for N in (5,10,20,50): Lv[f'直前{N}本']=hs.rolling(N).max().values
        for nm,k in (('当日','day'),('セッション','ses'),('今週','week')):
            if (nm=='当日' and U>=1440) or (nm=='セッション' and U>240): continue
            ig=I[k][first]; Lv[nm]=hs.groupby(ig).cummax().values; scope[nm]=(ig,k)
        for k in (3,5):
            left=hs.rolling(k).max().shift().values; right=hs[::-1].rolling(k).max().shift()[::-1].values
            with np.errstate(invalid='ignore'): sv=np.where((Hg>left)&(Hg>right),Hg,np.nan)
            Lv[f'スイング（前後{k}本）']=pd.Series(sv).shift(k).ffill().values
    r=streak(np.r_[False,Hg[1:]>Hg[:-1]]).astype(np.int64); j=np.arange(G); so=np.where(r>=2,Og[np.clip(j-r+1,0,G-1)],np.nan)
    back={'前の足の始値':Og,'前の足の反対側の端':Lg,'直前3本の反対側の端':ls.rolling(3).min().values,'直前5本の反対側の端':ls.rolling(5).min().values,'2本以上続いた更新の最初の足の始値':so}
    X={}
    if U!='W':
        D,_=s24.tfv6(q,g,s,U)
        for ref in ('1本前','直前20本','当日'):
            if (ref,('高' if s>0 else '安')+'値が超えた') in D: X[ref]=s24.stats(D[ref,('高' if s>0 else '安')+'値が超えた'][0])['since']
    _G[U,s]=(g,end,Lv,scope,back,X); return _G[U,s]
def conds(q,tf,B,side):
    if tf in _L: return _L[tf]
    l=B['l']; n=B['n']; a=B['a']; I=ids(q); out={}
    if tf==15: f=l
    else: P=pickle.load(open(f'P{tf}.pkl','rb')); f,_=link(P['b'],q,tf)
    fb=np.clip(f-1,0,None)
    for s,dn in ((1,'高値側'),(-1,'安値側')):
        wH=B['h'] if s>0 else -B['lw']; wC=s*B['c']; pp=np.r_[np.nan,wC[:-1]]
        for U in (15,30,60,240,1440,'W'):
            g,end,Lv,scope,back,X=levels(q,U,s); jb=g[fb]-(~end[fb]).astype(np.int64); ok=(f>=1)&(jb>=0); j=np.clip(jb,0,None)
            un='週足' if U=='W' else TFN[U]; mode='上位足' if (U=='W' or U>tf) else ('同じ足' if U==tf else '短い足'); W={}
            with np.errstate(invalid='ignore'):
                for nm,arr in Lv.items():
                    L=np.where(ok,arr[j],np.nan)
                    if nm in scope: ig,k=scope[nm]; L=np.where(ig[j]==I[k][np.clip(f,0,None)],L,np.nan)
                    W[nm]=L; bl=pp<=L; ab=pp>L; hi=wH>L; cl=wC>L; d=(L-wH)/a; w=(wH-L)/a
                    for cn,v in (('初めて抜けて維持',bl&hi&cl),('抜けたが戻された',bl&hi&~cl),('手前で止まった（ATR0.3倍以内）',bl&(wH<=L)&(d<=0.3)),('届かず遠い',bl&(wH<=L)&(d>0.3)),('先に抜けていて維持',ab&cl),('先に抜けていて割り込んだ',ab&(wC<=L)),
                                 ('抜けた幅がATRの0.2倍未満',bl&hi&(w<0.2)),('抜けた幅がATRの0.2〜0.5倍',bl&hi&(w>=0.2)&(w<0.5)),('抜けた幅がATRの0.5倍以上',bl&hi&(w>=0.5))): out[nm,cn,dn,un,mode]=np.nan_to_num(v).astype(bool)
                for nm,arr in back.items(): out['戻し','終値が'+nm+'まで戻した',dn,un,mode]=np.nan_to_num(ok&(wC<=arr[j])).astype(bool)
                for ref,since in X.items():
                    L=W[ref]; sv=since[j]
                    for pn,pm in (('直前の足が更新していた',sv==0),('直前10本に更新がなかった',sv>=10)):
                        for cn,v in (('抜けて維持',(wH>L)&(wC>L)),('抜けたが戻された',(wH>L)&(wC<=L)),('届かなかった',wH<=L)): out['掛け合わせ：'+ref,pn+'×'+cn,dn,un,mode]=np.nan_to_num(v&pm&ok).astype(bool)
    _L.clear(); _L[tf]=out; return out
if __name__=='__main__':
    a=sys.argv[1]; nm='stage8_6b_髭足と水準の関係'
    if a=='main': s18.run(nm,conds)
    if a=='add': s20b.run('add8_6b',conds,NR=50)   # s20b＝偽データ側にも最低回数を設けた版
    if a=='state': s22.conds=lambda q,tf,B,side:{(k[0]+'|'+k[2],)+k[1:]:v for k,v in conds(q,tf,B,side).items()}; s22.state('state8_6b')
    if a=='test':
        q=m15(); B=s17.base(60,q); C=conds(q,60,B,'上髭'); v=B['valid']; print(len(C))
        for k in C:
            if k[2]=='高値側' and ((k[0] in ('直前20本','戻し','掛け合わせ：直前20本','前週','スイング（前後3本）') and k[3] in ('1時間足','週足')) or (k[0]=='1本前' and k[3]=='日足')): print(k[0],k[3],k[4],k[1],round(C[k][v].mean(),3))
