# Pine ログ（寄り天売り v0.1）と Python の照合版 yref.py を1件ずつ比べる
#   使い方：python3 pcheck.py <Pineログ.csv> <出力xlsx> <CFD1分> <CFD5分> <先物5分> [追加のCFD1分 追加のCFD5分 追加の先物5分]
#     前の3本は BarExport（ld.py の形）、追加の3本は TradingView のチャート書き出し（time,open,high,low,close）でもよい
#     同じ時刻が両方にあるときは追加の方を使う
import sys, re, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/yt/code'); sys.path.insert(0, '/home/claude/yt/chk')
import ld, yref

def load(path):
    head = open(path, encoding='utf-8-sig').readline()
    if head.strip().lower().startswith('time,open'):
        d = pd.read_csv(path); d['m'] = (d.time // 60).astype('int64')
        return d[['m', 'open', 'high', 'low', 'close']]
    d = ld.bars(path); return d[['m', 'open', 'high', 'low', 'close']]

def merge(a, b):
    if b is None: return a.sort_values('m').reset_index(drop=True)
    x = pd.concat([a[~a.m.isin(b.m)], b]); return x.sort_values('m').reset_index(drop=True)

def num(s): return float(s.replace(',', '')) if s not in ('NaN', 'na') else np.nan

def parse_log(path):
    L = pd.read_csv(path, encoding='utf-8-sig'); L.columns = ['日時', 'メッセージ']
    D, T = [], []
    for msg in L.メッセージ:
        kv = dict(re.findall(r'(\w+)=(\S+(?: \d\d:\d\d)?)', msg))
        if msg.startswith('DAY'):
            D.append(dict(日=kv['d'], fA=num(kv['fA']), x9=num(kv['x9']), x95=num(kv['x95']), c905=num(kv['c905']), lv3=num(kv['lv3'])))
        elif msg.startswith(('ENTRY', 'EXIT', 'SKIP')):
            T.append(dict(種類=msg.split()[0], ルール=kv['rule'], 時刻=kv['t'], 値段=num(kv.get('E', kv.get('px', 'NaN'))),
                          損切り値=num(kv['SL']) if 'SL' in kv else np.nan, 理由=kv.get('why', ''), 損益=num(kv['yen']) if 'yen' in kv else np.nan))
    return pd.DataFrame(D), pd.DataFrame(T)

def day_values(c1, c5, f5, days):
    """Python 側の DAY の値（yref と同じ取り方）"""
    FM = f5.m.values; FO = f5.open.values; PM = c1.m.values; PO = c1.open.values; CM = c5.m.values; CO = c5.open.values
    out = []
    for d in days:
        m0 = int(pd.Timestamp(d + ' 08:45', tz='Asia/Tokyo').timestamp() // 60)
        ia, i9, i95 = (yref.first_ge(FM, m0 + k) for k in (0, 15, 20))
        fA = FO[ia] if ia is not None and FM[ia] == m0 else np.nan
        x9 = (FO[i9] / fA - 1) * 100 if i9 is not None else np.nan
        x95 = (FO[i95] / fA - 1) * 100 if i95 is not None else np.nan
        k = yref.first_ge(PM, m0 + 20); src = 'CFD1分'
        if k is not None: c905 = PO[k]
        else:
            k = yref.first_ge(CM, m0 + 20); c905 = CO[k] if k is not None else np.nan; src = 'CFD5分（1分足なし）'
        lv3 = c905 * (1 - 0.5 * x95 / 100) if x95 >= yref.TH['③'] * 100 else np.nan
        out.append(dict(日=d, fA=fA, x9=x9, x95=x95, c905=c905, lv3=lv3, c905の元=src))
    return pd.DataFrame(out)

if __name__ == '__main__':
    a = sys.argv[1:]; logp, outp = a[0], a[1]
    base = [load(p) for p in a[2:5]]; add = [load(p) for p in a[5:8]] if len(a) >= 8 else [None] * 3
    c1, c5, f5 = (merge(x, y) for x, y in zip(base, add))
    PD, PT = parse_log(logp)
    d0, d1 = PD.日.min(), (pd.Timestamp(PD.日.max()) + pd.Timedelta(days=1)).strftime('%Y-%m-%d')
    YT = yref.run(c1, c5, f5, d0, d1)
    # データのある日（先物の 8:45 の足と CFD 1分足の 9:05 の足がある日）
    def has(M, d, hm):
        t = int(pd.Timestamp(f'{d} {hm}', tz='Asia/Tokyo').timestamp() // 60); return bool(len(M) and np.isin(t, M))
    YD = day_values(c1, c5, f5, PD.日.tolist())
    YD['Pythonの1分足'] = [('あり' if has(c1.m.values, d, '09:05') else 'なし') for d in YD.日]
    # ---- DAY の比較
    C = PD.merge(YD, on='日', suffixes=('_Pine', '_Python'))
    for k, tol in (('fA', 0.01), ('x9', 0.0006), ('x95', 0.0006), ('c905', 0.01), ('lv3', 0.6)):
        p, q = C[k + '_Pine'], C[k + '_Python']
        C[k + '_一致'] = np.where(p.isna() & q.isna(), '○', np.where((p - q).abs() <= tol, '○', np.where(q.isna(), '（Pythonのデータなし）', '×')))
    C['①の対象'] = np.where(C.x9_Pine >= 0.3095, '待機', '')
    C['②の対象'] = np.where(C.x95_Pine >= 0.3812, '売り', '')
    C['③の対象'] = np.where(C.x95_Pine >= 0.4849, '待機', '')
    # ---- トレードの比較（Python は口座で「入る」になったものと、見送り）
    Y = YT.copy(); Y['日'] = Y.日.astype(str)
    PE = PT[PT.種類 == 'ENTRY'].rename(columns={'時刻': '入る時刻', '値段': '入る値段'})
    PX = PT[PT.種類 == 'EXIT'].rename(columns={'時刻': '手じまう時刻', '値段': '手じまう値段'})
    PE['日'] = PE.入る時刻.str[:10]; PX['日'] = PX.手じまう時刻.str[:10]
    PE['n'] = PE.groupby(['日', 'ルール']).cumcount(); PX['n'] = PX.groupby(['日', 'ルール']).cumcount()
    P2 = PE[['日', 'ルール', 'n', '入る時刻', '入る値段', '損切り値']].merge(PX[['日', 'ルール', 'n', '手じまう時刻', '手じまう値段', '理由', '損益']], on=['日', 'ルール', 'n'], how='left')
    PS = PT[PT.種類 == 'SKIP'].copy(); PS['日'] = PS.時刻.str[:10]
    Y['n'] = Y.groupby(['日', 'ルール']).cumcount()
    M = Y.merge(P2, on=['日', 'ルール', 'n'], how='outer', suffixes=('_Python', '_Pine'))
    M['入る時刻_一致'] = np.where(M.入る時刻_Python == M.入る時刻_Pine, '○', '×')
    M['入る値段_差'] = M.入る値段_Pine - M.入る値段_Python
    M['手じまう時刻_一致'] = np.where(M.手じまう時刻_Python == M.手じまう時刻_Pine, '○', '×')
    M['手じまう値段_差'] = M.手じまう値段_Pine - M.手じまう値段_Python
    M['理由_一致'] = np.where(M.理由_Python == M.理由_Pine, '○', '×')
    M['損益_差'] = M.損益_Pine - M.損益_Python
    def judge(r):
        if r.口座 in ('入らない（手じまい後）', '入らない（2本保有中）'):
            sk = PS[(PS.日 == r.日) & (PS.ルール == r.ルール)]
            return '○（両方見送り）' if len(sk) else '×（Python は見送り、Pine は記録なし）' if pd.isna(r.入る時刻_Pine) else '×（Python は見送り、Pine は入った）'
        if pd.isna(r.入る時刻_Pine): return '×（Pine になし）'
        if pd.isna(r.入る時刻_Python): return '×（Python になし）'
        ok = r.入る時刻_一致 == '○' and r.手じまう時刻_一致 == '○' and r.理由_一致 == '○' and abs(r.入る値段_差) <= 1 and abs(r.手じまう値段_差) <= 1 and abs(r.損益_差) <= 15
        return '○' if ok else '×'
    M['判定'] = M.apply(judge, axis=1)
    cols = ['判定', '日', 'ルール', '口座', '入る時刻_Python', '入る時刻_Pine', '入る値段_Python', '入る値段_Pine', '入る値段_差', '損切り値',
            '手じまう時刻_Python', '手じまう時刻_Pine', '手じまう値段_Python', '手じまう値段_Pine', '手じまう値段_差', '理由_Python', '理由_Pine', '損益_Python', '損益_Pine', '損益_差',
            '先物の動き_900_pct', '先物の動き_905_pct']
    M = M.sort_values(['日', '入る時刻_Python', 'ルール'], na_position='last')[cols]
    pd.to_pickle(dict(C=C, M=M, PD=PD, PT=PT, YT=YT), outp + '.pkl')
    pd.set_option('display.width', 250)
    print(C.to_string(index=False)); print(M.to_string(index=False))
