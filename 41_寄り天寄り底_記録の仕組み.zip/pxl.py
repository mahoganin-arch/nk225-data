# 照合結果を Excel にまとめる：python3 pxl.py <pcheck の .pkl> <出力xlsx>
import sys, pandas as pd, numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
R = pd.read_pickle(sys.argv[1]); C, M = R['C'], R['M']
F = 'Arial'; HF = PatternFill('solid', fgColor='DDE4EE'); OK = PatternFill('solid', fgColor='E2F0D9'); NG = PatternFill('solid', fgColor='F8D7DA'); NA = PatternFill('solid', fgColor='EEEEEE')
thin = Side(style='thin', color='BBBBBB'); B = Border(left=thin, right=thin, top=thin, bottom=thin)
wb = Workbook()
def sheet(ws, title, note, df, fmt={}):
    ws['A1'] = title; ws['A1'].font = Font(name=F, bold=True, size=13)
    r0 = 2
    for n in note: ws.cell(r0, 1, n).font = Font(name=F, size=10, color='555555'); r0 += 1
    r0 += 1
    for j, c in enumerate(df.columns, 1):
        x = ws.cell(r0, j, c); x.font = Font(name=F, bold=True); x.fill = HF; x.border = B; x.alignment = Alignment(wrap_text=True, vertical='center')
    for i, row in enumerate(df.itertuples(index=False), r0 + 1):
        for j, v in enumerate(row, 1):
            if isinstance(v, float) and np.isnan(v): v = None
            x = ws.cell(i, j, v); x.font = Font(name=F); x.border = B
            col = df.columns[j - 1]
            if col in fmt: x.number_format = fmt[col]
            if isinstance(v, str) and (v == '○' or v.startswith('○')): x.fill = OK
            elif isinstance(v, str) and v.startswith('×'): x.fill = NG
            elif isinstance(v, str) and v.startswith('（'): x.fill = NA
    for j, c in enumerate(df.columns, 1):
        w = max([len(str(c))] + [len(str(v)) for v in df.iloc[:, j - 1].tolist()]) * 1.6 + 2
        ws.column_dimensions[get_column_letter(j)].width = min(max(w, 8), 34)
    ws.freeze_panes = ws.cell(r0 + 1, 1)
# ---- 結論
ws = wb.active; ws.title = '結論'
nt = len(M); nok = (M.判定.str.startswith('○')).sum()
day_cols = [c for c in C.columns if c.endswith('_一致')]
cmp = C[day_cols]; n_ng = (cmp == '×').sum()
L = [('寄り天売り Pine v0.1 と Python 照合版（yref.py）の照合', ''),
     ('', ''),
     ('期間', f"{C.日.min()} 〜 {C.日.max()}（Pine ログの範囲、{len(C)}日）"),
     ('トレード', f"{nt}件中 {nok}件が一致（入る時刻・値段、手じまう時刻・値段、理由、損益）"),
     ('毎日の値（先物 8:45・9:00・9:05、9:05 の CFD、③の値段）', '先物の値はデータのある日すべて一致。9:05 の CFD 始値と③の値段は、9/28〜10/9 で Pine の方が 0.5 低い（下の注意1）'),
     ('①の待機日', '9/30・10/2・10/9・10/19 の4日。どちらも合図なし。Python の5分RSI の最大は 66.8〜68.6 で、70 に届いていない'),
     ('結論', 'v0.1 は Python と同じ動き。このまま記録に使える'),
     ('', ''),
     ('注意1：0.5 の差', '9/28〜10/9 の CFD の値段は、10/12 の BarExport（1円単位に丸めた形）から。Pine は 0.5 刻みの元の値段。10/19 は新しいチャート書き出し（0.5 刻み）で、差は 0。損益の差は最大 0.05円'),
     ('注意2：Python のデータがない日', '10/12（祝日取引）：先物の5分足が 10/12 夜からしかない。10/13〜10/16：CFD 1分足がない（9:05 の CFD は5分足の始値で代用）。どの日も先物の動きは境目に届かず、合図は出ない日'),
     ('注意3：照合で差が出うる場面（まだ起きていない）', '②と③が同じ足で入り、その足で②が損切りになると、Python は③を「手じまい後」で見送り、Pine は③に入る。実際の売買は Pine の動きが正しい'),
     ('次の照合', 'これからは週1回など、Pine ログと3本（CFD 1分・CFD 5分・先物 5分）を同じ期間で上げてもらえれば、同じ手順で照合する（chk/pcheck.py）')]
for i, (a, b) in enumerate(L, 1):
    ws.cell(i, 1, a).font = Font(name=F, bold=(i == 1 or a in ('結論',)), size=13 if i == 1 else 11)
    ws.cell(i, 2, b).font = Font(name=F, bold=(a == '結論')); ws.cell(i, 2).alignment = Alignment(wrap_text=True, vertical='top'); ws.cell(i, 1).alignment = Alignment(wrap_text=True, vertical='top')
ws.column_dimensions['A'].width = 30; ws.column_dimensions['B'].width = 90
# ---- トレード
M2 = M.copy()
sheet(wb.create_sheet('トレードの照合'), 'トレードの照合（1件ずつ）', ['損益は1枚＝68,800円換算、コスト13円控除後。差＝Pine − Python', '判定：入る・手じまうの時刻と理由が同じ、値段の差1以内、損益の差15円以内なら ○'], M2,
      {c: '#,##0.0' for c in M2.columns if '値段' in c or c == '損切り値'} | {c: '#,##0.0' for c in M2.columns if '損益' in c} | {'先物の動き_900_pct': '0.000', '先物の動き_905_pct': '0.000'})
# ---- 毎日
C2 = C[['日', '①の対象', '②の対象', '③の対象', 'fA_Pine', 'fA_Python', 'fA_一致', 'x9_Pine', 'x9_Python', 'x9_一致', 'x95_Pine', 'x95_Python', 'x95_一致', 'c905_Pine', 'c905_Python', 'c905_一致', 'c905の元', 'lv3_Pine', 'lv3_Python', 'lv3_一致', 'Pythonの1分足']].copy()
C2.columns = ['日', '①', '②', '③', '先物8:45_Pine', '先物8:45_Python', '先物8:45_一致', '9:00の動き%_Pine', '9:00の動き%_Python', '9:00_一致', '9:05の動き%_Pine', '9:05の動き%_Python', '9:05_一致',
              '9:05のCFD_Pine', '9:05のCFD_Python', '9:05のCFD_一致', '9:05のCFDの元', '③の値段_Pine', '③の値段_Python', '③の値段_一致', 'Pythonの1分足']
C2['9:05のCFD_一致'] = np.where((C2['9:05のCFD_Pine'] - C2['9:05のCFD_Python']).abs() <= 0.51, '○（0.5の丸め）', C2['9:05のCFD_一致'])
C2['9:05のCFD_一致'] = np.where((C2['9:05のCFD_Pine'] - C2['9:05のCFD_Python']).abs() <= 0.01, '○', C2['9:05のCFD_一致'])
sheet(wb.create_sheet('毎日の値の照合'), '毎日の値の照合（Pine の DAY ログと Python）', ['境目：① 9:00 の動き 0.3095% 以上、② 9:05 の動き 0.3812% 以上、③ 9:05 の動き 0.4849% 以上',
      '③の値段＝9:05 の CFD 始値 ×（1 − 0.5 × 9:05 の動き）。③の対象日だけ'], C2,
      {c: '#,##0.0' for c in C2.columns if '先物8:45' in c or 'CFD_' in c and '一致' not in c or '③の値段_P' in c} | {c: '0.000' for c in C2.columns if '動き%' in c})
wb.save(sys.argv[2])
