# 比べる相手の記録：9時台の逆張り売り48形（8:45→9:00・9:05 × 元からある入り方24）を、決めたルールで記録だけ計算する
#   ルール（強さ×手じまい）は 2017〜2026/10/8 で選んだもの（Y11「48形の一覧」の 今の強さ・利確・損切り・時間）＝ rules48.json に固定
#   強さの境目は 2017〜2021 年の先物の動きの分位（分析と同じ）＝ cuts48.json に固定。コストは毎回13円、1枚＝68,800円換算
#   1形ずつ単独（口座の決まりなし）。あわせて、今の3本（yref.py、口座の決まりあり）も同じデータで計算する
#
#   使い方：python3 rec48.py <開始日> <終了日の翌日> <作業フォルダ> <データ...>
#     データ：CFD1分・CFD5分・先物5分 の組を、古い順に何組でも（BarExport でも、チャートの書き出し time,open,... でもよい）
#             例） c1.csv c5.csv f5.csv 新c1.csv 新c5.csv 新f5.csv   同じ時刻は後のファイルを使う
#   出力：<作業フォルダ>/rec48.pkl（トレード・日ごとのデータの有無・3本）
import sys, os, json, numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, '/home/claude/yt/code'); sys.path.insert(0, '/home/claude/yt/an'); sys.path.insert(0, HERE)
import ld
OBS = {'8:45→9:00': 15, '8:45→9:05': 20}
QN = ['全部', '上位50%', '上位33%', '上位20%', '上位15%', '上位10%', '上位5%']

def load(path):
    head = open(path, encoding='utf-8-sig').readline()
    if head.strip().lower().startswith('time,open'):
        d = pd.read_csv(path); d['m'] = (d.time // 60).astype('int64')
    else:
        d = ld.bars(path)
    d = d[['m', 'open', 'high', 'low', 'close']].copy(); d['volume'] = np.nan
    return d

def merge(paths):
    x = None
    for p in paths:
        d = load(p)
        x = d if x is None else pd.concat([x[~x.m.isin(d.m)], d])
    x = x.sort_values('m').drop_duplicates('m', keep='last').reset_index(drop=True)
    x['t'] = pd.to_datetime(x.m * 60, unit='s', utc=True).dt.tz_convert('Asia/Tokyo')
    return x

def prep(work, files):
    O = os.path.join(work, 'out') + '/'; os.makedirs(O, exist_ok=True)
    g = [files[i::3] for i in range(3)]
    D = {n: merge(p) for n, p in zip(('c1', 'c5', 'f5'), g)}
    for n, d in D.items(): d.to_pickle(O + n + '.pkl')
    return O, D

def frozen():
    return json.load(open(os.path.join(HERE, 'cuts48.json'))), json.load(open(os.path.join(HERE, 'rules48.json')))

def day_check(D, start, end, cuts):
    """日中のセッションごとに、記録に使えるか。
       対象外：先物の動きがどの形の境目にも届かない（1分足がなくても結果は「入らない」で確定）
       確定：先物の 8:45・9:00・9:05 と、CFD 1分足が 8:45〜15:45（引けの足）まである
       暫定：引けまでのデータがない（書き出しが取引中など）。その日のトレードは合計に入れない"""
    f5, c1 = D['f5'], D['c1']; FM = f5.m.values; FO = f5.open.values; out = []
    lo9 = min(cuts['8:45→9:00'][5:]); lo95 = min(cuts['8:45→9:05'][5:])     # 48形の強さは 上位10% か 上位5%
    for d in pd.date_range(start, pd.Timestamp(end) - pd.Timedelta(days=1)):
        ds = d.strftime('%Y-%m-%d'); m0 = int(pd.Timestamp(ds + ' 08:45', tz='Asia/Tokyo').timestamp() // 60)
        has = lambda t: bool(np.isin(t, FM))
        n1 = int(((c1.m >= m0) & (c1.m < m0 + 420)).sum()); end1 = bool(np.isin(m0 + 420, c1.m.values))
        nf = int(((FM >= m0) & (FM < m0 + 425)).sum())
        if nf == 0 and n1 == 0: continue
        x9 = FO[FM == m0 + 15][0] / FO[FM == m0][0] - 1 if has(m0) and has(m0 + 15) else np.nan
        x95 = FO[FM == m0 + 20][0] / FO[FM == m0][0] - 1 if has(m0) and has(m0 + 20) else np.nan
        if np.isnan(x9) or np.isnan(x95): st = 'データなし（先物の 8:45〜9:05）'
        elif x9 < lo9 and x95 < lo95: st = '対象外（どの形の境目にも届かない）'
        elif n1 >= 380 and end1: st = '確定'
        else: st = '暫定（引けまでのデータがない）'
        out.append(dict(日=ds, 先物_9時の動き_pct=x9 * 100, 先物_9時5分の動き_pct=x95 * 100, CFD1分足の本数=n1, 引けの足=('あり' if end1 else 'なし'), 判定=st))
    return pd.DataFrame(out)

def run(start, end, work, files):
    O, D = prep(work, files)
    os.environ['YT_OUT'] = O
    import ev, paths
    s = ev.sessions(); s.to_pickle(O + 'sess.pkl'); paths.build()
    import xeng, yref
    cuts, rules = frozen()
    PM, PO, PH, PC = xeng.PM, xeng.PO, xeng.PH, xeng.PC
    s = pd.read_pickle(O + 'sess.pkl').sort_values('m').reset_index(drop=True)
    last = xeng.FM[np.searchsorted(xeng.FM, s.end.values - 1) - 1]
    T0 = pd.Timestamp(start, tz='Asia/Tokyo'); T1 = pd.Timestamp(end, tz='Asia/Tokyo')
    R = {(r['観察'], r['入る']): r for r in rules}
    rows = []
    for i, r in s.iterrows():
        if r.kind != 'D' or not (T0 <= r.t < T1): continue
        m0 = r.m; tcap = last[i]; tam = m0 + 165
        pcl = np.nan; ncl = np.nan
        for j in range(i - 1, max(i - 4, -1), -1):
            if s.kind[j] == 'N' and np.isnan(ncl): ncl = PC[max(np.searchsorted(PM, s.end[j]) - 1, 0)]
            if s.kind[j] == 'D': pcl = xeng.px(xeng.CM, xeng.CO, last[j]); break
        B = xeng.px(xeng.CM, xeng.CO, m0)
        for ob, L in OBS.items():
            a, b = m0, m0 + L
            pa, pb = xeng.px(xeng.FM, xeng.FO, a), xeng.px(xeng.FM, xeng.FO, b)
            if not (np.isfinite(pa) and np.isfinite(pb)) or pb <= pa: continue
            x = pb / pa - 1; c0 = xeng.px(xeng.CM, xeng.CO, b)
            if not np.isfinite(c0) or not np.isfinite(B): continue
            ql = sum(abs(x) >= c for c in cuts[ob][1:])
            mv = x * c0
            for (ob2, code), rr in R.items():
                if ob2 != ob or ql < rr['q']: continue
                tr = xeng.trigger(code, a, b, c0, mv)
                if tr is None: continue
                te, fill = tr; te = int(te)
                ja = np.searchsorted(PM, a); j0 = np.searchsorted(PM, te)
                peak0 = PH[ja:j0].max() if j0 > ja else -np.inf
                fillv = None if (fill is None or (isinstance(fill, float) and np.isnan(fill))) else float(fill)
                pnl, tt = xeng.sim((te, fillv, mv, tcap, tam, peak0, B, pcl, ncl), want_time=True)
                v = float(pnl[rr['e']])
                if np.isnan(v): continue
                jj = np.searchsorted(PM, te); e = fillv if fillv is not None else PO[jj]
                xp = e - (v + xeng.COST) / xeng.UNIT * e
                ts = lambda m: pd.Timestamp(int(m) * 60, unit='s', tz='UTC').tz_convert('Asia/Tokyo').strftime('%Y-%m-%d %H:%M')
                rows.append(dict(日=r.t.strftime('%Y-%m-%d'), 観察=ob, 入る=code, 強さ=QN[rr['q']], 利確=rr['利確'], 損切り=rr['損切り'], 時間=rr['時間'],
                                 先物の動き_pct=x * 100, 入る時刻=ts(PM[jj]), 入る値段=e, 手じまう時刻=ts(tt[rr['e']]), 手じまう値段=xp, 損益=v))
    T = pd.DataFrame(rows)
    Y3 = yref.run(D['c1'], D['c5'], D['f5'], start, end)
    DC = day_check(D, start, end, cuts)
    st = dict(zip(DC.日, DC.判定))
    if len(T): T['その日の判定'] = T.日.map(st)
    if len(Y3): Y3['その日の判定'] = Y3.日.astype(str).map(st)
    pd.to_pickle(dict(T=T, Y3=Y3, DC=DC, start=start, end=end, rules=rules), os.path.join(work, 'rec48.pkl'))
    return T, Y3, DC

if __name__ == '__main__':
    a = sys.argv[1:]
    T, Y3, DC = run(a[0], a[1], a[2], a[3:])
    pd.set_option('display.width', 250)
    print(DC.to_string(index=False)); print(T.round(1).to_string(index=False)); print(Y3.drop(columns=['_te', '_tx']).round(1).to_string(index=False))
