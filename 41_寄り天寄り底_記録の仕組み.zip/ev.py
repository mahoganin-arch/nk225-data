# 寄りイベント表：日中(8:45→9:00)・夜間(寄り→寄り+L)、先物の動き(観察)とCFDのその後
import numpy as np, pandas as pd
import os; O=os.environ.get('YT_OUT','/home/claude/yt/out/')
f5=pd.read_pickle(O+'f5.pkl'); c5=pd.read_pickle(O+'c5.pkl')
def idx(d):
    m=d.m.values; return m, d.open.values, d.close.values
FM,FO,FC=idx(f5); CM,CO,CC=idx(c5)
def px(M,Op,t,tol=5):
    i=np.searchsorted(M,t)            # 最初の足 m>=t
    ok=(i<len(M)); i2=np.minimum(i,len(M)-1)
    ok&=(M[i2]-t)<tol
    return np.where(ok,Op[i2],np.nan)
def sessions():
    g=np.diff(FM,prepend=FM[0]-999)>=30
    s=f5[g].copy(); hm=s.t.dt.hour*60+s.t.dt.minute
    s['kind']=np.where(hm==525,'D',np.where(hm.isin([990,1020]),'N','x'))
    s=s[s.kind!='x']
    # セッションの終わり（次の30分以上の空きの直前の足の終わり）
    e=np.r_[np.where(np.diff(FM)>=30)[0],len(FM)-1]
    ends=FM[e]+5
    s['end']=ends[np.searchsorted(ends,s.m.values)]
    return s[['m','t','kind','end']].reset_index(drop=True)
if __name__=='__main__':
    s=sessions(); print(s.kind.value_counts()); print(s.head()); s.to_pickle(O+'sess.pkl')
