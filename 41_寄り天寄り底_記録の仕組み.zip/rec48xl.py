# 記録（48形と今の3本）を Excel にまとめる：python3 rec48xl.py <rec48.pkl> <出力xlsx> [メモ（日=内容;日=内容）]
import sys, numpy as np, pandas as pd, openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
R = pd.read_pickle(sys.argv[1]); T, Y3, DC, rules = R['T'], R['Y3'], R['DC'], R['rules']
NOTE = dict(x.split('=', 1) for x in sys.argv[3].split(';')) if len(sys.argv) > 3 else {}
F = 'Arial'; HF = PatternFill('solid', fgColor='DDE4EE'); POS = Font(name=F, color='006100'); NEG = Font(name=F, color='C00000')
thin = Side(style='thin', color='BBBBBB'); BD = Border(left=thin, right=thin, top=thin, bottom=thin)
OK = '確定'
MAP3 = {('8:45→9:00', 'RSI5'): '①', ('8:45→9:05', '+5'): '②', ('8:45→9:05', 'c50'): '③'}
# 過去の目安（Y11：2019〜2026/10/8 の本当の前向き）
ws = openpyxl.load_workbook('/home/claude/yt/res39/Y11_寄り天寄り底_9時台の逆張り売り_記録の候補.xlsx', read_only=True)['48形の一覧']
rows = list(ws.iter_rows(values_only=True)); H = rows[2]; PAST = pd.DataFrame([r for r in rows[3:] if r[0]], columns=H)
PAST = PAST[['観察', '入る', '件数', '合計', '平均', 'PF']].rename(columns={'件数': '過去_件数', '合計': '過去_合計', '平均': '過去_1回平均', 'PF': '過去_PF'})
YRS_PAST = (pd.Timestamp('2026-10-08') - pd.Timestamp('2019-01-01')).days / 365.25

def st(v):
    v = np.asarray(v, float)
    if len(v) == 0: return dict(件数=0, 勝率=np.nan, PF=np.nan, 合計=0.0, 一回平均=np.nan, 最悪=np.nan, 最大DD=0.0)
    eq = np.cumsum(v); dd = (np.maximum.accumulate(np.r_[0, eq])[1:] - eq).max(); gl = -v[v < 0].sum()
    return dict(件数=len(v), 勝率=(v > 0).mean(), PF=v[v > 0].sum() / gl if gl > 0 else np.nan, 合計=v.sum(), 一回平均=v.mean(), 最悪=v.min(), 最大DD=dd)

Tc = T[T.その日の判定 == OK] if len(T) else T
Yc = Y3[(Y3.その日の判定 == OK) & (Y3.口座 == '入る')] if len(Y3) else Y3
# ---- 形ごと
FORM = []
for r in rules:
    g = Tc[(Tc.観察 == r['観察']) & (Tc.入る == r['入る'])] if len(Tc) else Tc
    FORM.append(dict(観察=r['観察'], 入る=r['入る'], 今の3本=MAP3.get((r['観察'], r['入る']), ''), 強さ=['全部', '上位50%', '上位33%', '上位20%', '上位15%', '上位10%', '上位5%'][r['q']],
                     利確=r['利確'], 損切り=r['損切り'], 時間=r['時間'], **st(g.損益.values if len(g) else [])))
FORM = pd.DataFrame(FORM).merge(PAST, on=['観察', '入る'], how='left').sort_values(['観察', '入る']).reset_index(drop=True)
# ---- 日ごと（3本と48形の平均）
days = DC[DC.判定 == OK].日.tolist()
DAY = []
for d in days:
    t = Tc[Tc.日 == d]; y = Yc[Yc.日.astype(str) == d]
    DAY.append(dict(日=d, 先物_9時_pct=DC.set_index('日').loc[d, '先物_9時の動き_pct'], 先物_9時5分_pct=DC.set_index('日').loc[d, '先物_9時5分の動き_pct'],
                    今の3本_件数=len(y), 今の3本_損益=y.損益.sum(), 入った形の数=len(t), 四十八形の合計=t.損益.sum(), 四十八形の平均_1形あたり=t.損益.sum() / 48))
DAY = pd.DataFrame(DAY)
s3 = st(Yc.損益.values if len(Yc) else []); per_form = FORM.合計.values
# ---- Excel
wb = Workbook()
def table(ws, r0, df, fmt={}):
    for j, c in enumerate(df.columns, 1):
        x = ws.cell(r0, j, c); x.font = Font(name=F, bold=True); x.fill = HF; x.border = BD; x.alignment = Alignment(wrap_text=True, vertical='center')
    for i, row in enumerate(df.itertuples(index=False), r0 + 1):
        for j, v in enumerate(row, 1):
            if isinstance(v, (float, np.floating)) and not np.isfinite(v): v = None
            if isinstance(v, np.generic): v = v.item()
            x = ws.cell(i, j, v); x.border = BD; c = df.columns[j - 1]
            x.font = (POS if isinstance(v, (int, float)) and v > 0 else NEG if isinstance(v, (int, float)) and v < 0 else Font(name=F)) if ('損益' in c or '合計' in c or '平均' in c or c in ('最悪',)) else Font(name=F)
            for k, f in fmt.items():
                if k in c: x.number_format = f
    for j, c in enumerate(df.columns, 1):
        w = max([len(str(c))] + [len(str(v)) for v in df.iloc[:, j - 1].tolist()] if len(df) else [len(str(c))]) * 1.5 + 2
        ws.column_dimensions[get_column_letter(j)].width = min(max(w, 8), 30)
    return r0 + len(df) + 2
def head(ws, title, notes):
    ws['A1'] = title; ws['A1'].font = Font(name=F, bold=True, size=13)
    for i, n in enumerate(notes, 2): ws.cell(i, 1, n).font = Font(name=F, size=10, color='555555')
    return len(notes) + 3
NUM = {'損益': '#,##0', '合計': '#,##0', '平均': '#,##0.0', '最悪': '#,##0', '最大DD': '#,##0', '勝率': '0%', 'PF': '0.00', '_pct': '0.000', '値段': '#,##0.0'}
# 1. 説明と今の結果
ws = wb.active; ws.title = '説明と今の結果'
r = head(ws, f'寄り天売り：今の3本と比べる相手（9時台の48形）の記録　{R["start"]}〜{(pd.Timestamp(R["end"]) - pd.Timedelta(days=1)).strftime("%Y-%m-%d")}',
         ['記録だけ（お金は入れない）。コストは毎回13円、1枚＝68,800円換算。合計に入れるのは「確定」の日だけ',
          '48形：8:45→9:00・9:05 × 元からある入り方24。ルールは 2017〜2026/10/8 で選んだもの（Y11）。1形ずつ単独で記録（口座の決まりなし）',
          '今の3本：Pine と同じルール（Python 照合版 yref.py）。売りは2本まで・手じまい後は入らない',
          '計算の確認：2021〜2026/10/8 の48形の全4,066トレードで分析のエンジン（xeng.py）と一致（差は保存の丸めで1円未満）。①②③と同じ形は照合版 yref.py と完全一致'])
cmp = pd.DataFrame([
    dict(項目='今の3本（口座の決まりあり）', **{k: s3[k] for k in ('件数', '勝率', 'PF', '合計', '一回平均', '最悪', '最大DD')}),
    dict(項目='48形の平均（1形あたりの合計）', 件数=FORM.件数.sum() / 48, 合計=per_form.mean()),
    dict(項目='48形のうち合計がプラスの形', 件数=int((per_form > 0).sum()), 合計=np.nan),
    dict(項目='48形のうち入った形', 件数=int((FORM.件数 > 0).sum()), 合計=np.nan)])
r = table(ws, r, cmp, NUM)
ws.cell(r, 1, '日の判定').font = Font(name=F, bold=True); r += 1
DC2 = DC.copy(); DC2['メモ'] = DC2.日.map(NOTE).fillna('')
extra = [dict(日=k, 判定='データなし（Python）', メモ=v) for k, v in NOTE.items() if k not in set(DC2.日)]
DC2 = pd.concat([DC2, pd.DataFrame(extra)]).sort_values('日') if extra else DC2
r = table(ws, r, DC2, NUM)
for i, n in enumerate(['見方：今の3本 と 48形の平均 を比べると「3本の選び方に意味があったか」、48形の平均そのものの向きで「寄り天の現象が続いているか」が分かる',
                       '注意：3本も48形も同じ日（先物が大きく上げた日）に入るので、件数がたまるまでは差が出にくい。判断の基準は別に決める（引き継ぎメモ4章）',
                       '過去の目安（Y11、2019〜2026/10/8 の本当の前向き）：48形の平均 +5,825円／形（約7.8年、1年あたり約750円）'], r):
    ws.cell(i, 1, n).font = Font(name=F, size=10)
ws.column_dimensions['A'].width = 34
# 2. 形ごと
ws = wb.create_sheet('形ごとの成績'); r = head(ws, '48形の記録（確定の日だけ）と過去の目安', ['過去＝Y11 の 2019〜2026/10/8 の本当の前向き（各年のルールはその年より前のデータ）。今の3本の列：Pine の①②③と同じ形'])
table(ws, r, FORM, NUM); ws.freeze_panes = ws.cell(r + 1, 3)
# 3. 日ごと
ws = wb.create_sheet('日ごとの比較'); r = head(ws, '日ごと：今の3本と48形', ['48形の平均＝その日の48形の損益の合計 ÷ 48（入らなかった形は0円）'])
table(ws, r, DAY, NUM)
# 4. トレード
ws = wb.create_sheet('48形のトレード'); r = head(ws, '48形のトレード一覧', ['暫定の日は、引けまでのデータがない（書き出しが取引中など）。次の書き出しで確定する'])
table(ws, r, T if len(T) else pd.DataFrame(columns=['日']), NUM); ws.freeze_panes = ws.cell(r + 1, 4)
ws = wb.create_sheet('3本のトレード'); r = head(ws, '今の3本のトレード（Python 照合版）', ['口座＝売りは2本まで・その日に手じまったら入らない'])
table(ws, r, Y3.drop(columns=['_te', '_tx']) if len(Y3) else pd.DataFrame(columns=['日']), NUM)
wb.save(sys.argv[2])
print(cmp.round(1).to_string(index=False)); print(DAY.round(1).to_string(index=False))
