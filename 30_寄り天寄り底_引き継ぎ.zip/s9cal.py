# 5-2 SQ・祝日・月末月初を条件として検証（順張り・逆張り、現行・先物基準）
#   印（窓の日付：D>Nは引けた日、N>Dは日中セッションの日）：SQ週(メジャー)、SQ週(ミニ)、SQ当日、SQ前日、祝日前日、祝日翌日(連休明け含む)、祝日取引中、月末3営業日、月初3営業日
#   条件：入る（印あり）／避ける（印なし）を条件なしに足す
#   評価：ステップ2と同じ（単点／周辺、5つの評価の形、13pt控除後、選ぶ期間で最悪−1,000円以上・15件以上）
import sys, datetime as dt, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/work/01/code'); from common6 import CB, P
W = '/home/claude/work'; SP = 13.0; WORST = -1000; MINSEL = 15
SEGS = {'D>N': ['D>N'], 'N>D': ['N>D'], '両方の窓': ['D>N', 'N>D']}
FRi = np.arange(12); SKi = np.r_[1:18, 0]; TMi = np.r_[1:9, 0]
PERM = np.array([(f * 18 + s) * 9 + t for f in FRi for s in SKi for t in TMi])
cal = pd.read_pickle(W + '/OUT2/cal.pkl'); lib, nodata = cal['lib'], cal['nodata']
def isbiz(x): return x.weekday() < 5 and x not in nodata and not (x > dt.date(2026, 10, 8) and x in lib)
def sqdate(y, m):
    first = dt.date(y, m, 1); x = first + dt.timedelta(days=(4 - first.weekday()) % 7 + 7)
    while not isbiz(x): x -= dt.timedelta(days=1)
    return x
def prevbiz(x):
    x -= dt.timedelta(days=1)
    while not isbiz(x): x -= dt.timedelta(days=1)
    return x
def nextwd(x, step):
    x += dt.timedelta(days=step)
    while x.weekday() >= 5: x += dt.timedelta(days=step)
    return x
def bizdays(y, m):
    x = dt.date(y, m, 1); out = []
    while x.month == m:
        if isbiz(x): out.append(x)
        x += dt.timedelta(days=1)
    return out
toD = lambda m: pd.Timestamp(int(m) * 60, unit='s', tz='Asia/Tokyo').date()
def flags(ev):
    rows = []
    for r in ev.itertuples():
        Wd = toD(r.pend) if r.kind == 'D>N' else toD(r.qm0); sq = sqdate(Wd.year, Wd.month); bd = bizdays(Wd.year, Wd.month); major = Wd.month in (3, 6, 9, 12)
        sqwk = Wd.isocalendar()[:2] == sq.isocalendar()[:2]
        rows.append({'SQ週(メジャー)': sqwk and major, 'SQ週(ミニ)': sqwk and not major, 'SQ当日': Wd == sq, 'SQ前日': Wd == prevbiz(sq),
                     '祝日前日': nextwd(Wd, 1) in lib, '祝日翌日(連休明け含む)': nextwd(Wd, -1) in lib, '祝日取引中': Wd in lib, '月末3営業日': Wd in bd[-3:], '月初3営業日': Wd in bd[:3]})
    return pd.DataFrame(rows)
def schemes():
    yield 'S1 前半→後半', [(lambda y: y <= 2021, lambda y: y >= 2022, 0)]
    yield 'S2 22-23→24-26', [(lambda y: (y >= 2022) & (y <= 2023), lambda y: y >= 2024, 0)]
    yield 'WF後半', [((lambda y, t=t: (y >= 2022) & (y < t)), (lambda y, t=t: y == t), t) for t in range(2023, 2027)]
    yield 'WF全期間', [((lambda y, t=t: y < t), (lambda y, t=t: y == t), t) for t in range(2022, 2027)]
    yield 'WF直近3年', [((lambda y, t=t: (y >= t - 3) & (y < t)), (lambda y, t=t: y == t), t) for t in range(2022, 2027)]
NY = {'S1 前半→後半': 4.77, 'S2 22-23→24-26': 2.77, 'WF後半': 3.77, 'WF全期間': 4.77, 'WF直近3年': 4.77}
def nbr_mean(A):
    V = np.nan_to_num(A); C = (~np.isnan(A)).astype(np.float32); Vs = np.zeros_like(V); Cs = np.zeros_like(C)
    pad = [(1, 1)] * 4; Vp = np.pad(V, pad); Cp = np.pad(C, pad); J, a, b, c = A.shape
    for d0 in range(3):
        for d1 in range(3):
            for d2 in range(3):
                for d3 in range(3):
                    Vs += Vp[d0:d0 + J, d1:d1 + a, d2:d2 + b, d3:d3 + c]; Cs += Cp[d0:d0 + J, d1:d1 + a, d2:d2 + b, d3:d3 + c]
    return np.where(C > 0, Vs / np.maximum(Cs, 1), np.nan)
def maxdd(v):
    c = np.cumsum(v); return float((np.maximum.accumulate(np.r_[0, c])[1:] - c).max()) if len(v) else np.nan
def load(d):
    Y = np.load(d + '/Y.npy', mmap_mode='r'); en = pd.read_pickle(d + '/en.pkl'); ev = pd.read_pickle(d + '/evt.pkl')
    en = en.join(ev[['kind', 'long', 't0']], on='ev'); en['yr'] = en.t0.dt.year
    en['px'] = en.ent.values if 'ent' in en else ev.B.values[en.ev.values]
    FL = flags(ev); return Y, en, FL.iloc[en.ev.values].reset_index(drop=True)
def evaluate(Y, en, mask, wins):
    XP = np.array(sorted(en.x.unique())); out = []
    for w in wins:
        fam = {}
        for j, x in enumerate(XP):
            idx = np.nonzero((~en.long.values) & mask & np.isclose(en.x.values, x) & np.isin(en.kind.values, SEGS[w]))[0]; idx = idx[np.argsort(en.m.values[idx])]
            G = np.asarray(Y[idx], dtype=np.float32) / 100 * P; ppt = (P / en.px.values[idx]).astype(np.float32)
            fam[j] = dict(yr=en.yr.values[idx], N=G - SP * ppt[:, None])
        Js = sorted(fam)
        for scn, splits in schemes():
            res = {'単点': [], '周辺': []}; pk = {'単点': [], '周辺': []}
            for selfn, tstfn, ty in splits:
                Mn = np.full((len(Js), 1944), np.nan, np.float32); Wst = np.full((len(Js), 1944), np.nan, np.float32); cnt = np.zeros(len(Js), int)
                for q, j in enumerate(Js):
                    s = selfn(fam[j]['yr']); cnt[q] = s.sum()
                    if cnt[q] >= MINSEL: Ns = fam[j]['N'][s]; Mn[q] = Ns.mean(0); Wst[q] = Ns.min(0)
                if not (cnt >= MINSEL).any(): continue
                SM = nbr_mean(Mn[:, PERM].reshape(len(Js), 12, 18, 9)).reshape(len(Js), 1944); SMc = np.full_like(SM, np.nan); SMc[:, PERM] = SM
                okw = Wst >= WORST
                for meth, score in (('単点', Mn), ('周辺', SMc)):
                    sc = np.where(np.isnan(Mn), -np.inf, score); sc2 = np.where(okw, sc, -np.inf); use = sc2 if np.isfinite(sc2).any() else sc
                    q, e = np.unravel_index(int(np.argmax(use)), use.shape); j = Js[q]; t = tstfn(fam[j]['yr'])
                    res[meth] += list(fam[j]['N'][t, e]); pk[meth].append('%g%%%s' % (XP[j], CB[e]))
            for meth in ('単点', '周辺'):
                v = np.array(res[meth]); out.append(dict(窓=w, 評価=scn, 選び方=meth, 件数=len(v), 年件数=len(v) / NY[scn], 平均=v.mean() if len(v) else np.nan, 最悪=v.min() if len(v) else np.nan, 最大DD=maxdd(v), 選ばれた点=' '.join(pk[meth])))
    return out
if __name__ == '__main__':
    rows = []
    RUNS = [('現行', '順張り', W + '/T'), ('先物基準', '順張り', W + '/F6W/T6'), ('現行', '逆張り', W + '/R'), ('先物基準', '逆張り', W + '/F6W/R6')]
    for lab, side, d in RUNS:
        Y, en, FL = load(d)
        conds = [('条件なし', '', np.ones(len(en), bool))] + [(f, m, (FL[f].values if m == '入る' else ~FL[f].values)) for f in FL.columns for m in ('入る', '避ける')]
        for f, m, mask in conds:
            for r in evaluate(Y, en, mask, SEGS): r.update(定義=lab, 向き=side, 印=f, 使い方=m); rows.append(r)
            print(lab, side, f, m, len(rows), flush=True)
    O = pd.DataFrame(rows); O.to_pickle(W + '/S9cal.pkl')
