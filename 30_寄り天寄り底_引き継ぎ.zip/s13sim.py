# 運用方針のシミュレーター（1口座、同時に最大1〜2本）
#   候補のトレード（s13trades.py、前向き検証の年ごとのルール）を、窓ごとに入る時刻の順に処理する
#   候補の集まり（窓の種類・向きごとに上位N本、選ぶ期間の1回あたり平均の順）と、同時に出たときの優先順位（同じ順位）は、確かめる年より前のデータだけで決める
#   方針：
#     S  最良1本      … 窓の種類ごとに、向きを問わず選ぶ期間で最良の候補1本だけ
#     A1 先着1本      … 最初に出たシグナルだけ（持っている間は他を無視）
#     A2 ドテン       … 1本まで。反対向きのシグナルが出たら、持っているものをその値段で手じまって入れ替える
#     B  両建て       … 買い1本・売り1本まで
#     C1 同じ向き2本  … 1本目と同じ向きなら2本目（どの候補でも）。反対向きは無視
#     C2 同じ向き2本（独立）… 2本目は条件の重なり（Ochiai）が0.3未満の候補だけ
#     D1 両建て＋2本目 … 合計2本まで（反対向きも同じ向きも可）
#     D2 両建て＋2本目（独立）… 同じ向きの2本目は独立の候補だけ
#   入り直し：なし（その窓で一度手じまったら終わり）／あり（先物が寄り後に前セッションの終値に届く＝窓が閉まるまでは入り直す）
#   候補の集まりの作り方（感度）：代表(0.5)、代表(0.4)、代表(0.6)、代表(0.5・年件数順)、全候補
#   順位の基準（感度）：選ぶ期間の1回あたり平均（合意した基準）／選ぶ期間の合計（件数の少ない候補が上に来すぎないか確かめるため）
import sys, itertools, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/work/01/code'); import ld
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.spatial.distance import squareform
W = '/home/claude/work'
C = pd.read_pickle(W + '/S12cands.pkl'); C = C[~C['出所'].str.startswith('S6逆張り')].set_index('id')
SETS = pd.read_pickle(W + '/S12sets.pkl'); ROW, ENT = SETS['ROW'], SETS['ENT']
T0 = pd.read_pickle(W + '/S13trades.pkl')
# ---- 窓が閉まる時刻（先物が寄り後に前セッションの終値に届いた足の始まり）
f5 = ld.bars(W + '/data/f5.csv', until='2026-10-09'); f1 = ld.bars(W + '/data/f1.csv', until='2026-10-09')
f1 = f1[f1.t >= pd.Timestamp('2023-10-16 08:45', tz='Asia/Tokyo')]; fx = pd.concat([f5[f5.m < f1.m.iloc[0]], f1], ignore_index=True)
fm = fx.m.values; fh = fx.high.values; fl = fx.low.values; fo = fx.open.values
evF = pd.read_pickle(W + '/F6W/T6/evt.pkl'); fill = {}
qend = {}
for r in evF.itertuples():
    a = np.searchsorted(fm, r.qm0); b = a + 2000; up = r.gap > 0
    z = np.nonzero(fl[a:b] <= r.B)[0] if up else np.nonzero(fh[a:b] >= r.B)[0]
    fill[r.i] = float(fm[a + z[0]]) if len(z) else np.inf
# ---- 独立の判定（入る側の条件の重なり）
def ochiai(a, b):
    A, B_ = ENT[a], ENT[b]; d = np.sqrt(len(A) * len(B_)); return len(A & B_) / d if d else 0.0
IND = {}
def indep(a, b):
    k = (min(a, b), max(a, b))
    if k not in IND: IND[k] = a != b and ochiai(a, b) < .3
    return IND[k]
# ---- 候補の集まり（グループの区切りを変えた代表）
def reps(thr, order):
    out = set(C.index[C['使い方'] == '基本'])
    for side in ('順張り', '逆張り'):
        for kind in ('入る', '避ける'):
            sub = C[(C['向き'] == side) & (C['使い方'] != '基本') & ((C['使い方'] == '避ける') if kind == '避ける' else (C['使い方'] != '避ける'))]
            ids = list(sub.index); n = len(ids)
            if n == 1: out |= set(ids); continue
            L = [ROW[i] for i in ids]; S = np.eye(n)
            for a in range(n):
                for b in range(a + 1, n):
                    d = np.sqrt(len(L[a]) * len(L[b])); S[a, b] = S[b, a] = len(L[a] & L[b]) / d if d else 0
            g = fcluster(linkage(squareform(1 - S, checks=False), 'average'), 1 - thr, 'distance')
            df = sub.assign(g=g)
            keys = ['選び方数', '最小', '年件数'] if order == '最悪順' else ['年件数', '選び方数', '最小']
            out |= set(df.sort_values(['g'] + keys, ascending=[True, False, False, False]).groupby('g').head(1).index)
    return out
UNIV = {'代表(0.5)': reps(.5, '最悪順'), '代表(0.4)': reps(.4, '最悪順'), '代表(0.6)': reps(.6, '最悪順'), '代表(0.5・年件数順)': reps(.5, '年件数順'), '全候補': set(C.index)}
print({k: len(v) for k, v in UNIV.items()}, flush=True)
SEL = {'WF全期間': lambda y, t: y < t, 'WF後半': lambda y, t: (y >= 2022) & (y < t)}
def maxdd(v):
    c = np.cumsum(v); return float((np.maximum.accumulate(np.r_[0, c])[1:] - c).max()) if len(v) else np.nan
def run_window(tr, pol, reent, fill_t):
    """tr: その窓の候補トレード（入る時刻・順位の順）。戻り値：実際に持ったトレードの一覧（損益は手じまいの見直し後）"""
    held = []; done = []; closed_any = False
    for r in tr:
        tin = r['入る時刻']
        still = []
        for h in held:
            if h['手じまう時刻'] <= tin: done.append(h); closed_any = True
            else: still.append(h)
        held = still
        if closed_any and (not reent or tin >= fill_t): continue          # 手じまいが出た後は、入り直しありで窓が閉まる前のときだけ新しく入る
        same = [h for h in held if h['向き'] == r['向き']]; opp = [h for h in held if h['向き'] != r['向き']]
        new = dict(r); new['種類'] = '1本目' if not held else ''
        if pol in ('S', 'A1'):
            if held: continue
        elif pol == 'A2':
            if same: continue
            if opp:
                h = opp[0]; h['損益'] = h['向き'] * (r['入る値段'] - h['入る値段']) * h['円per値'] - 13 * h['円per値']; h['手じまう時刻'] = tin; h['手じまう値段'] = r['入る値段']; h['ドテンで手じまい'] = True
                done.append(h); held = []; new['種類'] = 'ドテン'
        elif pol == 'B':
            if same: continue
            if opp: new['種類'] = '両建て'
        elif pol in ('C1', 'C2'):
            if opp or len(held) >= 2: continue
            if same:
                if pol == 'C2' and not indep(same[0]['id'], r['id']): continue
                if same[0]['id'] == r['id']: continue
                new['種類'] = '2本目'
        elif pol in ('D1', 'D2'):
            if len(held) >= 2: continue
            if same:
                if same[0]['id'] == r['id'] or (pol == 'D2' and not indep(same[0]['id'], r['id'])): continue
                new['種類'] = '2本目'
            elif opp: new['種類'] = '両建て'
        held.append(new)
    return done + held
def simulate(scn, meth, univ, N, pol, reent, rank='平均'):
    T = T0[(T0['評価'] == scn) & (T0['選び方'] == meth) & T0['id'].isin(UNIV[univ])]
    out = []
    for t, Tt in T.groupby('t'):
        ins = Tt[SEL[scn](Tt['年'].values, t)].groupby('id')['損益'].agg(['mean', 'sum', 'size']); ins = ins[ins['size'] >= 15]['mean' if rank == '平均' else 'sum']   # 順位の基準：選ぶ期間の1回あたり平均（合意）／合計（感度）
        test = Tt[Tt['年'] == t].copy(); test['順位'] = -test['id'].map(ins); test = test[test['順位'].notna()]
        # 窓の種類・向きごとに上位N本（Sは窓の種類ごとに最良1本）
        keep = []
        for kind in ('D>N', 'N>D'):
            tk = test[test['窓の種類'] == kind]
            if pol == 'S':
                ids = tk.groupby('id')['順位'].first().sort_values().head(1).index; keep.append(tk[tk['id'].isin(ids)])
            else:
                for side, g in tk.groupby(tk['id'].map(C['向き'])):
                    ids = g.groupby('id')['順位'].first().sort_values().head(N).index; keep.append(g[g['id'].isin(ids)])
        test = pd.concat(keep).sort_values(['セッション', '入る時刻', '順位'])
        for s, tr in test.groupby('セッション', sort=False):
            got = run_window(tr.to_dict('records'), pol, reent, fill.get(s, np.inf))
            for h in got: h['確かめる年'] = t; out.append(h)
    return pd.DataFrame(out)
def summarize(H):
    if not len(H): return {}
    H = H.sort_values('手じまう時刻'); v = H['損益'].values; ny = H['確かめる年'].nunique()
    w = H.groupby('セッション')['損益'].sum()
    r = dict(件数=len(H), 年あたり件数=len(H) / ny, 合計=v.sum(), 年あたり合計=v.sum() / ny, 一回平均=v.mean(), 最大DD=maxdd(v), 合計割る最大DD=v.sum() / maxdd(v) if maxdd(v) > 0 else np.nan,
             最悪の1窓=w.min(), 窓の数=len(w), 二本目の数=int((H['種類'] == '2本目').sum()), 二本目の平均=H.loc[H['種類'] == '2本目', '損益'].mean(),
             一本目の平均=H.loc[H['種類'] == '1本目', '損益'].mean(), 両建ての数=int((H['種類'] == '両建て').sum()), ドテンの数=int((H['種類'] == 'ドテン').sum()),
             マイナスの年=int((H.groupby('確かめる年')['損益'].sum() < 0).sum()))
    for y, g in H.groupby('確かめる年'): r[str(y)] = g['損益'].sum()
    return r
if __name__ == '__main__':
    rows = []; POLS = ['S', 'A1', 'A2', 'B', 'C1', 'C2', 'D1', 'D2']; SC = sys.argv[1]
    grid = [(SC, meth, univ, N) for meth in ('周辺', '単点') for univ in UNIV for N in (1, 5, 10, 20)]
    for i, (scn, meth, univ, N) in enumerate(grid):
        for pol in POLS:
            if pol == 'S' and N != 1: continue
            for reent in (False, True):
                for rank in ('平均', '合計'):
                    H = simulate(scn, meth, univ, N, pol, reent, rank)
                    rows.append(dict(評価=scn, 選び方=meth, 候補の集まり=univ, N=N, 方針=pol, 入り直し=reent, 順位の基準=rank, **summarize(H)))
        print(i + 1, len(grid), flush=True)
        pd.DataFrame(rows).to_pickle(W + '/S13sim_%s.pkl' % SC)
