# 新しい指標（F7）と既存（F6）の全区分のふるい分け（逆張り・順張り × 現行・先物基準 × 3窓）
#   尺度：1エントリーの「1,944決済の平均損益（13pt控除後）」。条件なし（同じ窓・乖離幅・期間）との差＝上乗せ。乖離幅ごとのtと差の中央値
#   区分の境目は前半（2017〜2021）のデータだけで決める。1時間足の出来高の指標（2022/12以降）だけは2023年で決め、2024〜26年でふるう
#   通過：前半と後半で上乗せの向きが同じ、かつ後半の中央t の絶対値 ≥ 1（後半のみの指標は 2024-26 の中央t の絶対値 ≥ 1.5）
#   向き：上乗せプラス→「入る」、マイナス→「避ける」（その区分以外で入る）
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/work/01/code'); from common6 import P, jname
W = '/home/claude/work'; SP = 13.0
SEGS = {'D>N': ['D>N'], 'N>D': ['N>D'], '両方の窓': ['D>N', 'N>D']}
LATE = ('前セッション最後1時間の出来高比', '出来高最多価格まで', '出来高最多価格をまたいだ', '出来高の多い価格帯の端まで')
def load(d):
    Y = np.load(d + '/Y.npy', mmap_mode='r'); en = pd.read_pickle(d + '/en.pkl'); ev = pd.read_pickle(d + '/evt.pkl')
    en = en.join(ev[['kind', 'long', 't0']], on='ev'); en['yr'] = en.t0.dt.year
    px = en.ent.values if 'ent' in en else ev.B.values[en.ev.values]
    try: MN = np.load(d + '/mnet_gross.npy')
    except FileNotFoundError:
        MN = np.zeros(len(en), np.float32)
        for a in range(0, len(en), 5000): MN[a:a + 5000] = np.asarray(Y[a:a + 5000], np.float32).mean(1) / 100 * P
        np.save(d + '/mnet_gross.npy', MN)
    F = pd.concat([pd.read_pickle(d + '/F6.pkl').drop(columns=['時']), pd.read_pickle(d + '/F7.pkl')], axis=1)
    return Y, en, MN - SP * P / px, F
def make_bins(F, sel):
    out = {}
    for c in F.columns:
        v = F[c].values.astype(float); fin = ~np.isnan(v); vt = v[sel & fin]; u = np.unique(vt)
        if len(vt) < 100: continue
        if len(u) <= 6:
            for x in u: out[(c, '=%g' % x)] = v == x
            continue
        q3 = np.quantile(vt, [1 / 3, 2 / 3]); b3 = np.searchsorted(q3, v, side='right')
        for i, lab in enumerate(['3分割:低', '3分割:中', '3分割:高']): out[(c, lab)] = fin & (b3 == i)
        q5 = np.quantile(vt, [.2, .4, .6, .8]); b5 = np.searchsorted(q5, v, side='right')
        for i in range(5): out[(c, '5分割:%d' % (i + 1))] = fin & (b5 == i)
        lo, hi = np.quantile(vt, [.1, .9]); out[(c, '下位10%')] = fin & (v <= lo); out[(c, '上位10%')] = fin & (v >= hi)
    return out
def uplift(Bm, MN, en, ok, period, kinds, XP):
    T = []; D = []
    for x in XP:
        e = ok & period & np.isin(en.kind.values, kinds) & np.isclose(en.x.values, x)
        if e.sum() < 60: continue
        m = MN[e].astype(np.float64); Be = Bm[:, e].astype(np.float64); n = Be.sum(1); s = Be @ m; q = Be @ (m * m)
        mu = np.where(n > 0, s / np.maximum(n, 1), np.nan); var = np.where(n > 1, (q - n * mu ** 2) / np.maximum(n - 1, 1), np.nan)
        with np.errstate(all='ignore'): t = (mu - m.mean()) / np.sqrt(var / np.maximum(n, 1))
        d = mu - m.mean(); t[n < 20] = np.nan; d[n < 20] = np.nan; T.append(t); D.append(d)
    if not T: return [np.full(Bm.shape[0], np.nan)] * 2
    T = np.array(T); D = np.array(D); good = (~np.isnan(T)).sum(0) >= 6
    with np.errstate(all='ignore'): return np.where(good, np.nanmedian(T, 0), np.nan), np.where(good, np.nanmedian(D, 0), np.nan)
if __name__ == '__main__':
    RUNS = [('現行', '順張り', W + '/T'), ('先物基準', '順張り', W + '/F6W/T6'), ('現行', '逆張り', W + '/R'), ('先物基準', '逆張り', W + '/F6W/R6')]
    rows = []
    for lab, side, d in RUNS:
        Y, en, MN, F = load(d); ok = ~en.long.values; yr = en.yr.values; XP = np.array(sorted(en.x.unique()))
        Fa = F.drop(columns=list(LATE)); Fl = F[list(LATE)]
        ba = make_bins(Fa, ok & (yr <= 2021)); bl = make_bins(Fl, ok & (yr == 2023))
        for bins, late in ((ba, False), (bl, True)):
            keys = list(bins); Bm = np.array([bins[k] for k in keys])
            for w, kinds in SEGS.items():
                if late: tA, dA = uplift(Bm, MN, en, ok, yr == 2023, kinds, XP); tB, dB = uplift(Bm, MN, en, ok, yr >= 2024, kinds, XP)
                else: tA, dA = uplift(Bm, MN, en, ok, yr <= 2021, kinds, XP); tB, dB = uplift(Bm, MN, en, ok, yr >= 2022, kinds, XP)
                cov = Bm[:, ok & np.isin(en.kind.values, kinds) & (yr >= 2022)].mean(1)
                for i, k in enumerate(keys):
                    rows.append(dict(定義=lab, 向き=side, 窓=w, 指標=k[0], 指標名=jname(k[0]), 区分=k[1], 後半のみ=late, 該当率=cov[i], 前半t=tA[i], 前半上乗せ=dA[i], 後半t=tB[i], 後半上乗せ=dB[i]))
        print(lab, side, len(rows), flush=True)
    S = pd.DataFrame(rows)
    S['通過'] = (np.sign(S['前半上乗せ']) == np.sign(S['後半上乗せ'])) & np.where(S['後半のみ'], S['後半t'].abs() >= 1.5, S['後半t'].abs() >= 1.0) & (S['該当率'] >= .03)
    S['使い方'] = np.where(S['後半上乗せ'] > 0, '入る', '避ける'); S['新しい指標'] = ~S['指標'].isin(pd.read_pickle(W + '/T/F6.pkl').columns)
    S.to_pickle(W + '/S10scr.pkl')
    print(S.groupby(['定義', '向き', '窓'])['通過'].agg(['sum', 'size']).to_string())
