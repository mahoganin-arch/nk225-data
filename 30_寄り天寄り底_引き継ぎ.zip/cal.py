# 取引所の休場日カレンダー：祝日ライブラリ＋年末年始、先物データの欠けと突き合わせ
import sys, datetime as dt, pandas as pd, numpy as np, holidays
sys.path.insert(0, sys.argv[1]); import ld
f = ld.bars(sys.argv[2], until='2026-10-09'); f['d'] = f.t.dt.date; day = f[f.t.dt.hour.between(9, 14)].d.unique(); dayset = set(day)
jp = holidays.Japan(years=range(2016, 2028))
lib = set(d for d in jp if d.weekday() < 5) | set(dt.date(y, m, dd) for y in range(2016, 2028) for m, dd in ((12, 31), (1, 2), (1, 3)) if dt.date(y, m, dd).weekday() < 5)
rng = pd.date_range('2017-01-05', '2026-10-08', freq='B').date
nodata = set(d for d in rng if d not in dayset)
libr = set(d for d in rng if d in lib)
print('平日で先物の日中データなし', len(nodata), ' ライブラリ上の休場', len(libr))
print('データなしだがライブラリは営業日:', sorted(nodata - libr)); print('ライブラリは休場だがデータあり（祝日取引など）:', sorted(libr - nodata))
pd.to_pickle(dict(lib=lib, nodata=nodata), sys.argv[3])
