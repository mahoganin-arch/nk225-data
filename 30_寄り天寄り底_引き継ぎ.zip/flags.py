# 候補の絞り込み＋SQ・祝日・月末月初の印ごとの成績
import sys, itertools, datetime as dt, pandas as pd, numpy as np
d = sys.argv[1]; Y = np.load(d + '/Y.npy'); en = pd.read_pickle(d + '/en.pkl'); ev = pd.read_pickle(d + '/evt.pkl'); R = pd.read_pickle(d + '/rows.pkl'); cal = pd.read_pickle(d + '/cal.pkl'); P = 68800
FR = [.1, .2, .3, .4, .5, .6, .7, .8, .9, 1.0, 1.25, 1.5]; SK = [0, .1, .2, .3, .4, .5, .6, .75, .9, 1, 1.25, 1.5, 2, 2.5, 3, 4, 5, 6]; TM = [0, 15, 30, 60, 90, 120, 180, 240, 360]
CBI = {(round(a, 3), round(b, 3), int(c)): i for i, (a, b, c) in enumerate(itertools.product(FR, SK, TM))}
lib, nodata = cal['lib'], cal['nodata']
def isbiz(x): return x.weekday() < 5 and x not in nodata and not (x > dt.date(2026, 10, 8) and x in lib)
# 窓の日付：日中→夜間は引けた日、夜間→日中は日中セッションの日
toD = lambda m: pd.Timestamp(int(m) * 60, unit='s', tz='Asia/Tokyo').date()
ev['W'] = [toD(r.pend) if r.kind == 'D>N' else toD(r.qm0) for r in ev.itertuples()]
def sqdate(y, m):
    first = dt.date(y, m, 1); fri = first + dt.timedelta(days=(4 - first.weekday()) % 7 + 7); x = fri
    while not isbiz(x): x -= dt.timedelta(days=1)
    return x
def prevbiz(x):
    x -= dt.timedelta(days=1)
    while not isbiz(x): x -= dt.timedelta(days=1)
    return x
def nextwd(x, step):
    x += dt.timedelta(days=step)
    while x.weekday() >= 5: x += dt.timedelta(days=step)
    return x
def bizdays(y, m):
    x = dt.date(y, m, 1); out = []
    while x.month == m:
        if isbiz(x): out.append(x)
        x += dt.timedelta(days=1)
    return out
FL = {}
for r in ev.itertuples():
    W = r.W; sq = sqdate(W.year, W.month); bd = bizdays(W.year, W.month); major = W.month in (3, 6, 9, 12)
    sqwk = W.isocalendar()[:2] == sq.isocalendar()[:2]
    FL[r.Index] = {'SQ週(メジャー)': sqwk and major, 'SQ週(ミニ)': sqwk and not major, 'SQ当日': W == sq, 'SQ前日': W == prevbiz(sq),
                   '祝日前日': nextwd(W, 1) in lib, '祝日翌日(連休明け含む)': nextwd(W, -1) in lib, '祝日取引中': W in lib,
                   '月末3営業日': W in bd[-3:], '月初3営業日': W in bd[:3]}
FLAGS = list(next(iter(FL.values())).keys()); Fe = pd.DataFrame.from_dict(FL, orient='index')[FLAGS]
print('印ごとの窓の数（全期間）', Fe.sum().to_dict())
en = en.join(ev[['kind', 'long', 't0']], on='ev').join(Fe, on='ev'); en['seg'] = np.where(en.long, '週末祝日', en.kind); en['half'] = np.where(en.t0.dt.year <= 2021, 'A', 'B')
t = pd.to_datetime(en.m * 60, unit='s', utc=True).dt.tz_convert('Asia/Tokyo'); en['wd'] = t.dt.dayofweek; en['hr'] = t.dt.hour; en['dir'] = np.where(en.d < 0, '上', '下')
# 候補の絞り込み：平均+20円以上、各半期20件以上、5年中4年以上で年3回以上
R = R[R['窓'] != '週末祝日'].copy()
def ok(r, h): return (r[h + '平均'] >= 20) & (r[h + '件数'] >= 20) & (r[h + '年数'] >= 4)
m = np.where(R['選び方'].isin(['両方で最良']), ok(R, '前半') & ok(R, '後半'), np.where(R['選び方'].str.startswith('前半'), ok(R, '前半'), ok(R, '後半')))
C = R[m].copy(); C['決済キー'] = list(zip(C['利確'].round(3), C['損切り'].round(3), C['時間切れ'].astype(int)))
C = C.groupby(['窓', '乖離幅%', '粒度', '条件', '決済キー'], sort=False).agg(**{c: (c, 'first') for c in C.columns if c not in ('窓', '乖離幅%', '粒度', '条件', '決済キー', '選び方')}, 選び方=('選び方', lambda v: '・'.join(sorted(set(v))))).reset_index()
print('候補数', len(C), C['選び方'].str.contains('両方').sum(), '両方を含む')
WD = {k: i for i, k in enumerate('月火水木金土日')}
def mask(row):
    mk = (en.seg.values == row['窓']) & np.isclose(en.x.values, row['乖離幅%'])
    for tok in row['条件'].split():
        if tok in WD: mk &= en.wd.values == WD[tok]
        elif tok.endswith('時'): mk &= en.hr.values == int(tok[:-1])
        elif tok in ('上', '下'): mk &= en.dir.values == tok
    return mk
LONG = []; SUMM = []
for i, row in C.iterrows():
    mk = mask(row); y = Y[mk, CBI[row['決済キー']]].astype(float) / 100 * P; sub = en[mk]
    hA = (sub.half == 'A').values; hB = ~hA
    assert abs(y[hA].mean() - row['前半平均']) < 0.6 or hA.sum() == 0, (row['条件'], y[hA].mean(), row['前半平均'])
    best = []
    for fl in FLAGS:
        on = sub[fl].values.astype(bool); rec = [i, fl]
        for h in (hA, hB):
            for s_ in (on, ~on):
                v = y[h & s_]; rec += [len(v), v.mean() if len(v) else np.nan, (v > 0).mean() * 100 if len(v) else np.nan]
        LONG.append(rec)
        aon, aoff, bon, boff = rec[3], rec[6], rec[9], rec[12]
        if (rec[2] >= 3 or rec[8] >= 3) and (np.nan_to_num(aoff) > row['前半平均'] or rec[2] == 0) and (np.nan_to_num(boff) > row['後半平均'] or rec[8] == 0) and (np.nan_to_num(aon, nan=1e9) < 0 or np.nan_to_num(bon, nan=1e9) < 0): best.append(fl)
    SUMM.append('、'.join(best))
C['除外すると両半期とも改善する印'] = SUMM
L = pd.DataFrame(LONG, columns=['候補番号', '印', '前半_該当件数', '前半_該当平均', '前半_該当勝率', '前半_除外後件数', '前半_除外後平均', '前半_除外後勝率', '後半_該当件数', '後半_該当平均', '後半_該当勝率', '後半_除外後件数', '後半_除外後平均', '後半_除外後勝率'])
C.to_pickle(d + '/cand.pkl'); L.to_pickle(d + '/candflag.pkl'); en[['seg', 'x', 'half'] + FLAGS].to_pickle(d + '/enflags.pkl')
print('除外で改善する印がある候補', int((C['除外すると両半期とも改善する印'] != '').sum()))
print(pd.Series([f for s in SUMM for f in s.split('、') if f]).value_counts().to_string())
# 印の全体傾向（条件なし、決済固定）
rows = []
for ex, lab in (((1.0, 1, 0), '完全埋め・損切り1倍'), ((1.0, 2, 0), '完全埋め・損切り2倍'), ((1.0, 0, 0), '完全埋め・損切りなし')):
    y = Y[:, CBI[ex]].astype(float) / 100 * P
    for seg in ('D>N', 'N>D'):
        for x in (.1, .2, .3, .4):
            for fl in FLAGS:
                for h in ('A', 'B'):
                    base = (en.seg.values == seg) & np.isclose(en.x.values, x) & (en.half.values == h); on = base & en[fl].values.astype(bool); off = base & ~en[fl].values.astype(bool)
                    rows.append((lab, seg, x, fl, '前半' if h == 'A' else '後半', on.sum(), y[on].mean() if on.any() else np.nan, (y[on] > 0).mean() * 100 if on.any() else np.nan, off.sum(), y[off].mean(), (y[off] > 0).mean() * 100))
G = pd.DataFrame(rows, columns=['決済', '窓', '乖離幅%', '印', '半期', '該当件数', '該当平均', '該当勝率', 'それ以外件数', 'それ以外平均', 'それ以外勝率']); G.to_pickle(d + '/flagbase.pkl')
pd.set_option('display.width', 250); print(G[(G['決済'] == '完全埋め・損切り2倍') & (G['乖離幅%'] == .2)].round(1).to_string(index=False))
