import pandas as pd, numpy as np
def wilder(s, n): return s.ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
def ind(b, mas):
    o, h, l, cl = b.o, b.h, b.l, b.c; pc = cl.shift(1); out = {}
    dlt = cl.diff(); up = wilder(dlt.clip(lower=0), 14); dn = wilder((-dlt).clip(lower=0), 14)
    out['rsi'] = 100 - 100 / (1 + up / dn.replace(0, np.nan)) - 50
    tr = pd.concat([h - l, (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1); atr = wilder(tr, 14)
    um = h.diff(); dm = -l.diff(); pdm = um.where((um > dm) & (um > 0), 0.0); mdm = dm.where((dm > um) & (dm > 0), 0.0)
    pdi = 100 * wilder(pdm, 14) / atr; mdi = 100 * wilder(mdm, 14) / atr
    out['adx'] = wilder(100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, np.nan), 14); out['di'] = pdi - mdi
    macd = cl.ewm(span=12, adjust=False).mean() - cl.ewm(span=26, adjust=False).mean(); out['macdh'] = (macd - macd.ewm(span=9, adjust=False).mean()) / cl * 100; out['macd'] = macd / cl * 100
    mid = lambda n: (h.rolling(n).max() + l.rolling(n).min()) / 2
    tk, kj = mid(9), mid(26); sa = ((tk + kj) / 2).shift(26); sb = mid(52).shift(26); top = np.maximum(sa, sb); bot = np.minimum(sa, sb)
    out['kijun'] = (cl - kj) / cl * 100; out['tk'] = (tk - kj) / cl * 100
    out['cloud'] = pd.Series(np.where(sa.isna() | sb.isna(), np.nan, np.where(cl > top, 1.0, np.where(cl < bot, -1.0, 0.0))), index=b.index); out['cloudd'] = (cl - (top + bot) / 2) / cl * 100
    hc = ((o + h + l + cl) / 4).values; ho = np.empty(len(b)); ho[0] = (o.iloc[0] + cl.iloc[0]) / 2
    for i in range(1, len(b)): ho[i] = (ho[i - 1] + hc[i - 1]) / 2
    col = np.sign(hc - ho); run = np.zeros(len(b))
    for i in range(len(b)): run[i] = col[i] if i == 0 or col[i] != col[i - 1] else run[i - 1] + col[i]
    out['ha'] = pd.Series(col, index=b.index); out['harun'] = pd.Series(run, index=b.index)
    sm = {p: cl.rolling(p).mean() for p in mas}
    for p in mas: out['ma%d' % p] = (cl - sm[p]) / sm[p] * 100
    f_, s_ = mas[0], mas[1] if len(mas) > 1 else mas[0]
    out['slope_s'] = sm[f_].pct_change(5) * 100
    if 75 in sm: out['slope75'] = sm[75].pct_change(5) * 100
    if 200 in sm:
        out['maord'] = pd.Series(np.where(sm[200].isna(), np.nan, np.where((sm[20] > sm[75]) & (sm[75] > sm[200]), 1.0, np.where((sm[20] < sm[75]) & (sm[75] < sm[200]), -1.0, 0.0))), index=b.index)
    if 13 in sm: out['ma13x26'] = (sm[13] - sm[26]) / sm[26] * 100
    out['ret5'] = cl.pct_change(5) * 100; out['ret20'] = cl.pct_change(20) * 100; out['atr'] = atr / cl * 100
    return pd.DataFrame(out)
