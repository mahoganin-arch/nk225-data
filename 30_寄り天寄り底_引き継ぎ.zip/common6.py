import itertools, numpy as np, pandas as pd
from math import erf, sqrt
P = 68800
FR = [.1, .2, .3, .4, .5, .6, .7, .8, .9, 1.0, 1.25, 1.5]; SK = [0, .1, .2, .3, .4, .5, .6, .75, .9, 1, 1.25, 1.5, 2, 2.5, 3, 4, 5, 6]; TM = [0, 15, 30, 60, 90, 120, 180, 240, 360]
CB = list(itertools.product(FR, SK, TM)); NCB = len(CB)
def load(d):
    Y = np.load(d + '/Y.npy', mmap_mode='r'); en = pd.read_pickle(d + '/en.pkl'); ev = pd.read_pickle(d + '/evt.pkl'); F = pd.read_pickle(d + '/F6.pkl')
    en = en.join(ev[['kind', 'long', 't0']], on='ev'); en['yr'] = en.t0.dt.year; en['half'] = np.where(en.yr <= 2021, 'A', 'B')
    t = pd.to_datetime(en.m * 60, unit='s', utc=True).dt.tz_convert('Asia/Tokyo'); en['wd'] = t.dt.dayofweek; en['hr'] = t.dt.hour; en['dir'] = np.where(en.d < 0, '上', '下')
    return Y, en, F
def theme(k):
    if k in ('曜日', '時', '寄り後', '経過分'): return 'time'
    if k in ('前セッション騰落', '引け前60分', '引け位置', '上に離れた', '寄り時の窓', '前日高安まで', '節目まで', '節目を越えた'): return 'ctx'
    b, _, tf = k.rpartition('_')
    if b == 'atr' or k in ('前セッション値幅', '平均値幅20', '停止中値幅'): return 'vol'
    if b == 'adx': return 'adx'
    return 'long' if tf in ('4h', 'D', 'W') else 'short'
TF = {'5m': '5分', '15m': '15分', '60m': '60分', '4h': '4時間', 'D': '日足', 'W': '週足'}
NM = {'rsi': 'RSI', 'adx': 'ADX', 'di': 'DMI差', 'macdh': 'MACDヒスト', 'macd': 'MACD', 'kijun': '基準線乖離', 'tk': '転換−基準', 'cloud': '雲位置', 'cloudd': '雲乖離', 'ha': '平均足色', 'harun': '平均足連続', 'slope_s': '短期MA傾き', 'slope75': '75MA傾き', 'maord': 'MA並び', 'ma13x26': '13−26MA', 'ret5': '5本騰落', 'ret20': '20本騰落', 'atr': 'ATR'}
def jname(k):
    b, _, tf = k.rpartition('_')
    if tf in TF: return TF[tf] + (NM.get(b) or (b.replace('ma', '') + 'MA乖離'))
    return k
def bins_for(v, kind):
    """値の配列 → [(ラベル, bool配列)]。数値は3分割・5分割・上下10%、少数の値は各値"""
    ok = ~np.isnan(v); u = np.unique(v[ok]); out = []
    if len(u) <= 6:
        for x in u: out.append(('=%g' % x, v == x))
        return out
    q3 = np.nanquantile(v, [1 / 3, 2 / 3]); b3 = np.searchsorted(q3, v, side='right')
    for i, lab in enumerate(['3分割:低', '3分割:中', '3分割:高']): out.append((lab, ok & (b3 == i)))
    q5 = np.nanquantile(v, [.2, .4, .6, .8]); b5 = np.searchsorted(q5, v, side='right')
    for i in range(5): out.append(('5分割:%d' % (i + 1), ok & (b5 == i)))
    lo, hi = np.nanquantile(v, [.1, .9]); out.append(('下位10%', ok & (v <= lo))); out.append(('上位10%', ok & (v >= hi)))
    return out
pval = np.vectorize(lambda tt: 1 - erf(abs(tt) / sqrt(2)))
