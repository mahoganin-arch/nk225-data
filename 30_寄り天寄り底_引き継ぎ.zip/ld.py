import pandas as pd

AL = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
IDX = {c: i for i, c in enumerate(AL)}

def _old(s, rows):
    # 旧形式： K~分,始値,高値,安値,終値,出来高;...;~E
    for p in s.split('~', 1)[1].split(';'):
        q = p.split(',')
        if len(q) == 6:
            try: rows.append([float(x) for x in q])
            except ValueError: pass

def _head(s):
    if not s.endswith('~E'):
        raise ValueError('コメントが途中で切れています: ' + s[:40])
    head, meta, body, _ = s.split('~')
    t0, base, tick, tf = meta.split(',')
    return int(head[1:]), int(t0), int(base), float(tick), int(tf), body

def _new(s, rows):
    # 圧縮版(Z)： Z本数~開始分,基準値,ティック幅,足の分数~a,b,c,d[,g[,出来高]];...;~E
    n, t, pc, tick, tf, body = _head(s)
    recs = [x for x in body.split(';') if x]
    if len(recs) != n:
        raise ValueError('本数が合いません: ' + s[:40])
    for i, x in enumerate(recs):
        f = x.split(',')
        a, b, c, d = (int(v) for v in f[:4])
        g = int(f[4]) if len(f) > 4 else (0 if i == 0 else tf)
        v = float(f[5]) if len(f) > 5 else float('nan')
        t += g; o = pc + a; pc = o + d
        rows.append([t, o * tick, (o + b) * tick, (o - c) * tick, pc * tick, v])

def _new3(s, rows):
    # 高圧縮版(Y)： Y本数~開始分,基準値,ティック幅,足の分数~本体~E
    #   本体 = 足ごとに [*経過分][!始値の飛び] 高値幅 安値幅 終値差 （62進・可変長）
    n, t, pc, tick, tf, body = _head(s)
    i = 0; L = len(body); cnt = 0; nan = float('nan')
    def num():
        nonlocal i
        ch = body[i]
        if ch == '.':
            v = IDX[body[i + 1]] * 62 + IDX[body[i + 2]]; i += 3
        elif ch == '_':
            v = ((IDX[body[i + 1]] * 62 + IDX[body[i + 2]]) * 62 + IDX[body[i + 3]]) * 62 + IDX[body[i + 4]]; i += 5
        else:
            v = IDX[ch]; i += 1
        return v
    unzz = lambda z: z // 2 if z % 2 == 0 else -(z + 1) // 2
    while i < L:
        g = 0 if cnt == 0 else tf; a = 0
        if body[i] == '*': i += 1; g = num()
        if body[i] == '!': i += 1; a = unzz(num())
        b = num(); c = num(); d = unzz(num())
        t += g; o = pc + a; pc = o + d
        rows.append([t, o * tick, (o + b) * tick, (o - c) * tick, pc * tick, nan]); cnt += 1
    if cnt != n:
        raise ValueError('本数が合いません: ' + s[:40])

def bars(f, until=None):
    """トレード一覧CSV（1つ、または複数のリスト）から足データを復元。
    旧形式・圧縮版(Z)・高圧縮版(Y)を自動判別。
    until='2026-10-09' のように渡すと、その日時(JST)より前の足だけを返す。"""
    rows = []
    for name in ([f] if isinstance(f, str) else f):
        for s in pd.read_csv(name)['シグナル'].dropna().unique():
            s = str(s)
            if '~' not in s: continue
            (_new3 if s.startswith('Y') else _new if s.startswith('Z') else _old)(s, rows)
    d = pd.DataFrame(rows, columns=['m', 'open', 'high', 'low', 'close', 'volume'])
    d = d.drop_duplicates('m').sort_values('m').reset_index(drop=True)
    d['t'] = pd.to_datetime(d.m * 60, unit='s', utc=True).dt.tz_convert('Asia/Tokyo')
    if until is not None:
        d = d[d.t < pd.Timestamp(until, tz='Asia/Tokyo')].reset_index(drop=True)
    return d

if __name__ == '__main__':
    import sys
    for f in sys.argv[1:]:
        d = bars(f); print(f, len(d), d.t.iloc[0], d.t.iloc[-1]); print(d.groupby(d.t.dt.year).size().to_dict())
