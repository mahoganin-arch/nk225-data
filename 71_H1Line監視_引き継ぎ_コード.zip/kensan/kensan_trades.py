"""「検算の書き出し」ストラテジーの取引一覧（CSV か Excel）から、15分足ごとの値を取り出して照らし合わせる。
使い方：python3 kensan_trades.py 取引一覧.csv fut 出力.xlsx
"""
import sys, re, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/kensan'); import kensan
NAMES = ['分', 'close', '検_H1Line', '検_H4Line', '検_D1Line', '検_A', '検_H1Lineの山', '検_H1Lineの谷', '検_macd15m-1H', '検_signal15m-1H', '検_macd1D-1W', '検_signal1H-4H', '検_遅K', '検_インジ合計',
         '検_買いにそろった本数', '検_週の線が月の線の上', '検_1H遅K', '検_1H遅D', '検_1時間足の終わり', '検_買いの重なり', '検_売りの重なり', '検_合図A', '検_合図B', '検_持ち高A', '検_持ち高B']
def parse(path):
    raw = pd.read_excel(path) if str(path).lower().endswith(('.xlsx', '.xls')) else pd.read_csv(path, encoding='utf-8-sig')
    cells = [str(v) for col in raw.columns for v in raw[col].values if isinstance(v, str) and '~' in v and v.startswith('K')]
    rows = []; vers = set()
    for c in cells:
        m = re.match(r'K(\d+)~(.*)~E', c, re.S)
        if not m: continue
        vers.add(int(m.group(1)))
        for b in m.group(2).split(';'):
            f = b.split(',')
            if len(f) != len(NAMES): continue
            rows.append([float(x) if x not in ('', 'NaN') else np.nan for x in f])
    df = pd.DataFrame(rows, columns=NAMES).drop_duplicates('分').sort_values('分').reset_index(drop=True)
    df['time'] = (df['分'] * 60).astype(np.int64); df['検_版'] = max(vers) if vers else np.nan
    return df
if __name__ == '__main__':
    df = parse(sys.argv[1]); print('取り出した15分足', len(df))
    df['_t'] = df['time']
    kensan.main(df, sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None, warm=0)
