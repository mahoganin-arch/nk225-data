"""検算：TradingView の「チャートデータをエクスポート」（15分足、インジの「検算用の値」を出した状態）を、研究と同じ論理の Python の計算と1本ずつ照らし合わせる。
使い方：python3 kensan.py 書き出したファイル.csv fut|cfd [出力.xlsx]
"""
import sys, pickle, numpy as np, pandas as pd
REF = pickle.load(open('/home/claude/bs/g/kensan_ref.pkl', 'rb'))
COLS = {  # 書き出しの列名 → (研究の値, 許す差, 種類)
    '検_H1Line': ('h1', 3.0, '線'), '検_H4Line': ('h4', 3.0, '線'), '検_D1Line': ('d1', 5.0, '線'), '検_A': ('A', 5.0, '値幅'),
    '検_H1Lineの山': ('h1pk', 3.0, '線'), '検_H1Lineの谷': ('h1vl', 3.0, '線'), '検_macd15m-1H': ('mc1', 3.0, '線'), '検_signal15m-1H': ('sg1', 3.0, '線'),
    '検_macd1D-1W': ('mc96', 10.0, '線'), '検_signal1H-4H': ('sg4', 3.0, '線'), '検_遅K': ('sk', 1.0, 'ストキャス'), '検_インジ合計': ('cnt', 0.0, '数'),
    '検_買いにそろった本数': ('agree', 0.0, '数'), '検_週の線が月の線の上': ('dUp', 0.0, '数'), '検_1H遅K': ('sk60', 1.0, 'ストキャス'), '検_1H遅D': ('sd60', 1.0, 'ストキャス'),
    '検_買いの重なり': ('buyOv', 0.0, '数'), '検_売りの重なり': ('sellOv', 0.0, '数')}
RULES = [1, 3, 5, 7, 11, 12, 22, 27, 28, 29, 30, 31, 32, 33, 34]   # 研究と同じ論理を書き直してあるルール（アラートの15本）
def read_tv(path):
    df = pd.read_csv(path)
    tc = [c for c in df.columns if str(c).lower() in ('time', '時間', '日時')][0]
    t = df[tc]
    if pd.api.types.is_numeric_dtype(t): ts = t.astype(np.int64).values
    else: ts = np.array([int(x.timestamp()) for x in pd.to_datetime(t.astype(str), utc=True)], np.int64)
    df['_t'] = ts; return df
def bits(x, lo):
    x = np.nan_to_num(np.asarray(x, float)).astype(np.int64); return {r: ((x >> (r - lo)) & 1).astype(bool) for r in RULES if lo <= r < lo + 19}
def main(path, inst, out=None, warm=6000):
    R = REF[inst]; df = read_tv(path) if isinstance(path, str) else path
    pos = pd.Series(np.arange(len(R['t'])), index=R['t']); k = pos.reindex(df['_t'].values).values
    ok = ~np.isnan(k); df = df[ok].reset_index(drop=True); k = k[ok].astype(int)
    if len(df) == 0: print('時刻が1本も合いません（15分足か、時刻の書き出し形式を確かめてください）'); return
    ver = sorted(set(df['検_版'].dropna().astype(int))) if '検_版' in df.columns else ['（版の列なし＝2026-10-28c より前の版）']
    rep = [dict(項目='Pine の版', 結果=', '.join(str(v) for v in ver)), dict(項目='照らし合わせた15分足', 結果=f"{len(df)}本（{pd.to_datetime(df._t.iloc[0], unit='s', utc=True).tz_convert('Asia/Tokyo'):%Y/%m/%d}〜{pd.to_datetime(df._t.iloc[-1], unit='s', utc=True).tz_convert('Asia/Tokyo'):%Y/%m/%d}）。研究のデータは 2026/10/9 まで")]
    if len(df) == 0: print('時刻が1本も合いません（15分足か、時刻の書き出し形式を確かめてください）'); return
    if 'close' in df.columns:
        dc = df['close'].values - R['c'][k]; g = (pd.Series(dc) != pd.Series(dc).shift()).cumsum(); G = pd.DataFrame({'t': df._t.values, 'd': dc}).groupby(g.values).agg(t0=('t', 'first'), d=('d', 'first'), n=('d', 'size')); G = G[G.n > 20]
        rep.append(dict(項目='値段の差（データ）', 結果='研究と同じ' if (G.d.abs() < 0.01).all() else '限月ごとに一定の差：' + '、'.join(f"{pd.to_datetime(a, unit='s', utc=True).tz_convert('Asia/Tokyo'):%Y/%m/%d}から{b:+.0f}円" for a, b in zip(G.t0, G.d))))
    use = np.arange(len(df)) >= min(warm, len(df) // 3)   # 線が落ち着くまでの最初の足は数えない
    rows = []
    # 値そのもの（終値も）
    if 'close' in df.columns:
        d = np.abs(df['close'].values - R['c'][k]); rows.append(dict(値='終値（データそのもの）', 本数=int(use.sum()), 許す差=0.0, 差の中央値=np.median(d[use]), 一致率=np.mean(d[use] <= 0.001) * 100, いちばん大きい差=d[use].max()))
    for col, (key, tol, kind) in COLS.items():
        if col not in df.columns: rows.append(dict(値=col, 本数=0, 備考='書き出しにこの列がない')); continue
        a = df[col].values.astype(float); b = np.asarray(R[key], float)[k]; m = use & ~np.isnan(a) & ~np.isnan(b)
        d = np.abs(a - b); rows.append(dict(値=col, 本数=int(m.sum()), 許す差=tol, 差の中央値=np.median(d[m]) if m.any() else np.nan, 一致率=np.mean(d[m] <= tol + 1e-9) * 100 if m.any() else np.nan, いちばん大きい差=d[m].max() if m.any() else np.nan,
                                最初にずれた時刻=str(pd.to_datetime(df._t.values[m][np.argmax(d[m] > tol + 1e-9)], unit='s', utc=True).tz_convert('Asia/Tokyo')) if (m.any() and (d[m] > tol + 1e-9).any()) else ''))
    V = pd.DataFrame(rows)
    # 合図
    srows = []; mis = []
    if '検_合図A' in df.columns and '検_合図B' in df.columns:
        tvb = {**bits(df['検_合図A'], 0), **bits(df['検_合図B'], 19)}; rfb = {**bits(R['mA'][k], 0), **bits(R['mB'][k], 19)}
        for r in RULES:
            a = tvb[r] & use; b = rfb[r] & use; both = a & b
            srows.append(dict(No=r, TradingViewの合図=int(a.sum()), 研究の合図=int(b.sum()), 一致=int(both.sum()), 研究のうち一致率=both.sum() / max(b.sum(), 1) * 100, TradingViewのうち一致率=both.sum() / max(a.sum(), 1) * 100))
            for i in np.nonzero(a ^ b)[0][:30]:
                mis.append(dict(No=r, 時刻=str(pd.to_datetime(df._t.values[i], unit='s', utc=True).tz_convert('Asia/Tokyo')), どちらだけ='TradingViewだけ' if a[i] else '研究だけ'))
    S = pd.DataFrame(srows)
    # 持ち高（入ってから手じまうまで）。No.7 は利確の「2本目の線」の候補の線が Python では少ないので参考
    prow = []
    if '検_持ち高A' in df.columns and '検_持ち高B' in df.columns:
        tvp = {**bits(df['検_持ち高A'], 0), **bits(df['検_持ち高B'], 19)}; rfp = {**bits(R['pA'][k], 0), **bits(R['pB'][k], 19)}
        for r in RULES:
            a = tvp[r] & use; b = rfp[r] & use; anyp = (tvp[r] | rfp[r]) & use
            ea = a & ~np.r_[False, a[:-1]]; eb = b & ~np.r_[False, b[:-1]]
            prow.append(dict(No=r, 持っていた足_TradingView=int(a.sum()), 持っていた足_研究=int(b.sum()), どちらかが持っていた足のうち一致率=((a == b) & anyp).sum() / max(anyp.sum(), 1) * 100,
                             入った回数_TradingView=int(ea.sum()), 入った回数_研究=int(eb.sum()), 備考='参考（利確の線の候補が違う）' if r == 7 else ''))
            for i in np.nonzero((a ^ b) & (np.r_[True, (a ^ b)[:-1]] == False))[0][:15]:
                mis.append(dict(No=r, 時刻=str(pd.to_datetime(df._t.values[i], unit='s', utc=True).tz_convert('Asia/Tokyo')), どちらだけ='持ち高：TradingViewだけ' if a[i] else '持ち高：研究だけ'))
    P = pd.DataFrame(prow); M = pd.DataFrame(mis)
    bad_v = V[(V.本数 > 0) & (V.一致率 < 99)] if '一致率' in V else V.iloc[0:0]
    bad_s = S[((S.研究の合図 > 0) | (S.TradingViewの合図 > 0)) & ((S.研究のうち一致率 < 95) | (S.TradingViewのうち一致率 < 95))] if len(S) else S
    rep.append(dict(項目='値', 結果='すべて許す差の中（99%以上）' if len(bad_v) == 0 else 'ずれがある：' + '、'.join(bad_v.値.tolist())))
    rep.append(dict(項目='合図', 結果=('書き出しに合図の列がない' if len(S) == 0 else ('15本すべて95%以上一致（合図のなかったルールを除く）' if len(bad_s) == 0 else 'ずれがある：No.' + '、'.join(str(x) for x in bad_s.No.tolist())))))
    bad_p = P[(P.No != 7) & ((P.持っていた足_研究 > 0) | (P.持っていた足_TradingView > 0)) & ((P.どちらかが持っていた足のうち一致率 < 98) | ((P.入った回数_TradingView - P.入った回数_研究).abs() > np.maximum(2, 0.05 * P.入った回数_研究)))] if len(P) else P
    rep.append(dict(項目='持ち高（手じまい）', 結果=('書き出しに持ち高の列がない' if len(P) == 0 else ('すべて98%以上一致・入った回数も同じくらい（No.7 は参考）' if len(bad_p) == 0 else 'ずれがある：No.' + '、'.join(str(x) for x in bad_p.No.tolist())))))
    rep.append(dict(項目='見方', 結果='値は最初の6000本（線が落ち着くまで）を除いて比べる。合図は研究のうち95%以上・TradingViewのうち95%以上の一致で OK。ずれたら「ずれた合図」のシートの時刻をチャートで見る'))
    Rp = pd.DataFrame(rep)
    pd.set_option('display.width', 250); print(Rp.to_string(index=False)); print(V.round(2).to_string(index=False)); print(S.round(1).to_string(index=False)); print(P.round(1).to_string(index=False))
    if out:
        with pd.ExcelWriter(out) as w:
            Rp.to_excel(w, 'まとめ', index=False); V.to_excel(w, '値', index=False); S.to_excel(w, '合図', index=False); P.to_excel(w, '持ち高', index=False); M.to_excel(w, 'ずれた合図', index=False)
    return Rp, V, S, P, M
if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None)
