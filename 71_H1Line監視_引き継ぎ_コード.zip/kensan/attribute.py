"""照合で残ったずれを、1件ずつ原因に分ける（データの違いか、説明のつかないものか）。"""
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/kensan'); from kensan import bits
def run(pkl, refname, out=None):
    df = pd.read_pickle(pkl); R = pickle.load(open('/home/claude/bs/g/kensan_ref.pkl', 'rb'))[refname]
    pos = pd.Series(np.arange(len(R['t'])), index=R['t']); k = pos.reindex(df.time).values; ok = ~np.isnan(k); d = df[ok].reset_index(drop=True); k = k[ok].astype(int)
    jt = pd.to_datetime(d.time, unit='s', utc=True).dt.tz_convert('Asia/Tokyo'); n = len(d)
    warm = (jt < pd.Timestamp('2024-03-01', tz='Asia/Tokyo')).values      # チャートの計算の始まり（D1Line が合うまで）
    dend = (jt >= pd.Timestamp('2026-09-14', tz='Asia/Tokyo')).values     # 研究のデータの終わりの近く（研究の持ち高が途中で切れる）
    pdiff = d.close.values != R['c'][k]
    roll = np.zeros(n, bool)
    for i in np.nonzero(pdiff)[0]: roll[max(0, i - 8):i + 400] = True     # 乗り換えの足から約1週間
    adiff = np.abs(d['検_A'].values - R['A'][k]) > 0.01
    udiff = d['検_週の線が月の線の上'].values != R['dUp'][k]
    tvb = {**bits(d['検_合図A'], 0), **bits(d['検_合図B'], 19)}; rfb = {**bits(R['mA'][k], 0), **bits(R['mB'][k], 19)}
    tvp = {**bits(d['検_持ち高A'], 0), **bits(d['検_持ち高B'], 19)}; rfp = {**bits(R['pA'][k], 0), **bits(R['pB'][k], 19)}
    SELL = {5, 11, 32, 33, 34}
    def cause(i, r):
        if warm[i]: return 'チャートの計算の始まり'
        if dend[i]: return '研究のデータの終わり'
        if r in SELL and udiff[i]: return '週の線と月の線の差'
        if roll[i] or adiff[i]: return '限月の乗り換え'
        return '説明なし'
    rows = []; other = []
    for r in sorted(tvb):
        x = np.nonzero(tvb[r] ^ rfb[r])[0]
        for i in x:
            c = cause(i, r); rows.append(dict(No=r, 種類='合図', 原因=c))
            if c == '説明なし': other.append(dict(No=r, 種類='合図', 時刻=jt[i].strftime('%Y-%m-%d %H:%M'), どちら='TVだけ' if tvb[r][i] else '研究だけ'))
        m = tvp[r] ^ rfp[r]; st = np.nonzero(m & ~np.r_[False, m[:-1]])[0]
        for i in st:
            e = i
            while e < n and m[e]: e += 1
            # 持ち高のずれの始まりの近く（4本前まで）に合図のずれがあれば、その原因にそろえる
            j0 = max(0, i - 4); sx = [j for j in range(j0, i + 1) if tvb[r][j] ^ rfb[r][j]]
            c = cause(sx[0], r) if sx else cause(i, r)
            if c == '説明なし' and r in SELL and udiff[max(0, i - 400):i + 1].any(): c = '週の線と月の線の差'
            rows.append(dict(No=r, 種類='持ち高', 原因=c, 本数=e - i))
            if c == '説明なし': other.append(dict(No=r, 種類='持ち高', 時刻=jt[i].strftime('%Y-%m-%d %H:%M'), 本数=e - i, どちら='TVだけ持つ' if tvp[r][i] else '研究だけ持つ'))
    A = pd.DataFrame(rows); O = pd.DataFrame(other)
    S = A.assign(本数=A.get('本数', pd.Series(1, index=A.index)).fillna(1)).groupby(['種類', '原因']).agg(件数=('No', 'size'), 本数=('本数', 'sum')).reset_index()
    if out:
        with pd.ExcelWriter(out) as w: S.to_excel(w, '原因ごと', index=False); O.to_excel(w, '説明のつかないもの', index=False)
    return S, O
if __name__ == '__main__':
    S, O = run(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None)
    pd.set_option('display.width', 200); print(S.to_string(index=False)); print(O.to_string(index=False))
