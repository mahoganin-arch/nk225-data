import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from m3_eval import TR, EXITS, FSN
OUT = '/home/claude/out/3分足_Zerch手法の検証_2026-10-25.xlsx'
r1 = lambda d: d.round(1)
O = pd.read_pickle('/home/claude/bs/g/m3rep.pkl'); S = {}
S['まとめ'] = pd.DataFrame({'': [
    '3分足チャートの線を画像（IMG_7610）で特定：m15Line＝H系の線（15分足の式を3分足で m=5）、3分足線＝EMA12（緑）、15分足線＝EMA60（マゼンタ）。誤差はEMA12 1円、EMA60 2円、m15Line 6円。',
    'データ：CFD 1分足 2020-11〜、ミニ 1分足 2023-10〜（限月つなぎ調整）。2026-10-09 以降は使っていない。入るのは合図の次の足の始値、セッションの終わりで必ず手じまい。',
    'コスト：実コスト（ミニ5・CFD7）、値段をそろえた損益（nrm）、13円コスト（n13）。比べる相手：同じ向き・同じ手じまい・同じ方向確認でランダムな時刻に入った場合。',
    '4つの確認＝ミニ前半(〜2025-03)・ミニ後半・CFD前半(〜2023-06)・CFD後半。でたらめな線（線になめらかなずれを足したもの）5組と比べて、線の情報が本物か確かめた。',
    '【結果1】ブログのルールそのまま（3分足線×m15のクロスで入り、逆クロスで出る、損切り30〜50円）は、コスト後ほぼゼロかマイナス。売りは全部マイナス。損切り30〜50円は成績を下げる。',
    '【結果2】線の情報は弱いが本物：4つともランダムより良い形は本物13%、でたらめ7〜11%。4つともプラスかつランダムより良い形は本物4.4%、でたらめ1.7〜2.8%。',
    '【結果3】頑丈なトリガー（でたらめな線より明らかに良い）：3分足線×H1Line上抜け買い、m15の向き転換買い、3分足線×m15上抜け買い、周期型クロス買い、H1Lineの向き転換売り、15分足線×m15下抜け売り。',
    '【結果4】ブログの「値幅サイン」「3つのサイン」はでたらめな線と差がない（3つのサイン反発はむしろでたらめの方が良い）。4H・日足のストキャス×MACDの形は件数が少なすぎて判断できない。',
    '【結果5】方向確認で一番効くのは 1H速ストキャスの向き と 3分速ストキャス低位（押し目）。1H・4H・日足をそろえるのは件数が減るだけで効かない。',
    '【結果6】本当の前向き（前の年だけで選んで翌年に使う）では上位5本は続かない（順位相関0）。全部の候補の平均は CFD +1.7・ミニ +6.0 だが、でたらめな線も同じくらい。13円コストではマイナス。',
    '【結果7】一番良く見えた形（H1Line反発買い＋15分速ストキャス向き＋3分速K>遅K、セッション終わりまで）は 1セッション1回に限ると CFD +14.7・ミニ +30.6（13円で +8.7・+22.6）。合図が同じ日に固まるので、表の件数ほどの確かさはない。',
    '【結論】3分足でブログのやり方をそのまま使っても、コスト後の優位性はほぼ無い。15分足チャートで見つけた候補（H1Line山の押し目買い +43〜66、C+ +48〜70）の方がずっと良い。3分足は入る時刻を細かく合わせる道具として使うのが現実的。',
    '分からないもの：PriceHight（200以下で弱い）・寄り付きの逆指値の値段・Indi07・矢印は式が不明なので検証していない。',
]})
S['線の特定'] = pd.DataFrame([
    ('3分足線（緑）', 'EMA(12)＝macd 3m-15m', '1.2円'), ('15分足線（マゼンタ）', 'EMA(60)＝macd 15m-1H', '2.3円'),
    ('m15Line（白・灰）', 'H系の線の式 m=5（15分÷3分）', '6.3円（m=4.9 だと18円、m=5.1 だと32円）'),
    ('H1Line（3分足チャート上）', 'H系の線の式 m=20（15分足チャートの H1Line と同じ線）', '画像では未照合'),
    ('速ストキャス・遅ストキャス', '(35,21,21)・(140,84,84) をチャートの時間足で', '15分足で照合済み'),
], columns=['線', '式', '画像との差（中央値）'])
S['ブログのルールそのまま'] = r1(O['rules'])
S['線の効き目'] = O['null'].round(3)
J = O['trig'][['トリガー', '売買', '線を使う', 'n', 'p', 'p_n', 'z', 'pp', 'pp_n', 'med']].rename(columns={
    'n': '形の数', 'p': '本物：4つともランダムより良い割合', 'p_n': 'でたらめな線の平均', 'z': '頑丈さ(z)', 'pp': '本物：さらに4つともプラス', 'pp_n': 'でたらめ：同', 'med': '差の最小の中央値'})
S['トリガーの頑丈さ'] = J.round(3)
F = O['filt'].drop(columns=['fset', 'fam']).rename(columns={'改善4つとも': '本物：4つとも改善した割合', '改善_でたらめ': 'でたらめな線', '変化中央': '差の変化（中央値）', '変化_でたらめ': 'でたらめ：同'})
S['方向確認の効き目'] = F.round(3)
B = pd.read_pickle('/home/claude/bs/g/m3best.pkl'); B['dir'] = B['dir'].map({1: '買い', -1: '売り'})
S['トリガーごとの一番良い形（参考）'] = B.rename(columns={'trig': 'トリガー', 'dir': '売買', 'exit': '手じまい', 'f': '方向確認', 'min': '4つの平均の最小', 'dmin': 'ランダムとの差の最小', 'nmin': '件数最小',
                                                 'cfd年+': 'CFD プラスの年', 'cfd平均': 'CFD 1回平均', 'cfd13円': 'CFD 13円', 'cfd件': 'CFD 件数', 'fut年+': 'ミニ プラスの年', 'fut平均': 'ミニ 1回平均', 'fut13円': 'ミニ 13円', 'fut件': 'ミニ 件数'})
S['上位300（参考・選びすぎ）'] = r1(O['top'])
N = pd.read_pickle('/home/claude/bs/g/m3nest.pkl')
s = N.groupby(['grp', 'inst', 'fam'])[['上位5 合計', '上位5 合計13円', '上位5 件数']].sum().join(N.groupby(['grp', 'inst', 'fam'])[['全部の平均', '全部の平均13円', '順位相関']].mean()).reset_index()
s['inst'] = s.inst.map({'fut': 'ミニ', 'cfd': 'CFD'}); s['fam'] = s.fam.map(lambda f: '本物' if f == 'W' else f'でたらめ {f}')
S['本当の前向き'] = r1(s.rename(columns={'grp': '選び方', 'inst': '商品', 'fam': '線'}))
y = N[N.fam == 'W'].pivot_table(index=['grp', 'inst'], columns='t', values=['上位5 合計', '全部の平均']).round(1); y.columns = [f'{a} {b}' for a, b in y.columns]
S['前向き 年ごと'] = y.reset_index()
S['確かめ（独立計算）'] = pd.DataFrame([
    ('H1Line反発(0.08A)買い＋15分速ストキャス向き＋3分速K>遅K・セッション終わり', 'CFD', '全部', 13431, 34.4, 28.4, 0.563, '一致（集計 13431件・34.4）'),
    ('同上', 'CFD', '1セッション1回', 1112, 14.7, 8.7, 0.535, '年：2021 +1.5／2022 +0.6／2023 +33.8／2024 +7.6／2025 +11.6／2026 +42.2'),
    ('同上', 'ミニ', '全部', 5476, 50.8, 42.8, 0.59, '一致（集計 5476件・50.8）'),
    ('同上', 'ミニ', '1セッション1回', 436, 30.6, 22.6, 0.534, '年：2024 +29.0／2025 +33.3／2026 +23.9'),
], columns=['形', '商品', '数え方', '件数', '1回平均(nrm)', '13円', '勝率', 'メモ'])
with pd.ExcelWriter(OUT, engine='openpyxl') as w:
    for k, v in S.items(): v.to_excel(w, sheet_name=k[:31], index=False)
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
wb = load_workbook(OUT)
for ws in wb.worksheets:
    for c in ws[1]: c.font = Font(bold=True); c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
    for col in ws.columns:
        L = max(len(str(c.value or '')) for c in list(col)[:200]); ws.column_dimensions[col[0].column_letter].width = min(max(8, L * 1.6), 60)
    ws.freeze_panes = 'A2'
ws = wb['まとめ']; ws.column_dimensions['A'].width = 120
for row in ws.iter_rows(min_row=2):
    for c in row: c.alignment = Alignment(wrap_text=True, vertical='top')
wb.save(OUT); print('ok')
