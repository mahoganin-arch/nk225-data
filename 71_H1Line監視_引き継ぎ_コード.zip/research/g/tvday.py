"""TradingView の日足（夜間は翌日の日付、日中15:45〜15:15で終わる）を5分足から作り、週の線・月の線を計算する。"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs'); sys.path.insert(0, '/home/claude/bs/g')
from h_lines import hfilt
def tv_daily(inst):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); tm = X['tm']
    t = pd.to_datetime(tm, unit='s', utc=True).tz_convert('Asia/Tokyo'); hm = t.hour * 60 + t.minute
    dstart = 525 if inst == 'fut' else 420   # 日中の始まり（ミニ 8:45、CFD 7:00）
    dend = 935 if inst == 'fut' else 1020    # 日中の終わりの目安（ミニ 15:35 ころまで、CFD 17:00）
    isday = (hm >= dstart) & (hm < dend + 15)
    dd = pd.Series(t.normalize()).values
    ds = np.unique(dd[isday])  # 日中のある日
    ds_start = np.array([pd.Timestamp(d).tz_localize(None) for d in ds], 'datetime64[ns]')
    # 夜間の足は、その後に来る日中の日付
    tl = t.tz_localize(None).values
    nxt = np.searchsorted(ds_start + np.timedelta64(dstart, 'm'), tl, side='left')
    lab = np.where(isday, np.searchsorted(ds_start, dd.astype('datetime64[ns]')), nxt)
    lab = np.clip(lab, 0, len(ds) - 1)
    df = pd.DataFrame({'lab': lab, 'c': X['c'], 'tm': tm}); g = df.groupby('lab').agg(c=('c', 'last'), tend=('tm', 'last'))
    c = g.c.values; b = hfilt(c, 5); u = hfilt(c, 20)
    return g.tend.values + 300, b, u
def tv_dup_at(inst, tend_bar):
    te, b, u = tv_daily(inst); k = np.searchsorted(te, tend_bar, side='right') - 1
    return np.where(k >= 0, b[np.maximum(k, 0)] > u[np.maximum(k, 0)], False)
