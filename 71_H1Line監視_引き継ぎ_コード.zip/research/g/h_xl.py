import sys, glob, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter
import h_sig as G, h_pk, h_agg

OUT = '/home/claude/out/Hライン_MACD_戦略の網羅的検証_2026-10-25.xlsx'
INST = {'fut': 'ミニ', 'cfd': 'CFD'}
R = pd.read_pickle('/home/claude/bs/g/form.pkl')

def r1(df): return df.round(1)

sheets = {}
# ---- まとめ（後で文章を入れる）
sheets['まとめ'] = None
sheets['説明'] = None

# ---- 形としての強さ
def formtab(lvl, keys):
    out = []
    for inst in ['fut', 'cfd']:
        T = R[(inst, lvl)].copy(); T.insert(0, '商品', INST[inst]); out.append(T)
    T = pd.concat(out)
    T['売買'] = T['dir'].map({1: '買い', -1: '売り'})
    cols = ['商品'] + [k for k in keys if k != 'dir'] + ['売買', '全体_件数',
            '全体_nrm_本物', '全体_nrm_偶然', '全体_nrm_z', '前半_nrm_本物', '前半_nrm_z', '後半_nrm_本物', '後半_nrm_z',
            '全体_net_本物', '全体_net_z', '全体_n13_本物', '全体_n13_z', '2019〜26_nrm_本物', '2019〜26_nrm_z']
    T = T[cols].rename(columns={'grp': '線の種類', 'line': '線', 'kind': '入り方', 'tp': '利確', 'sl': '損切り', 'tm': '時間', 'tf': '判定足', 'b': '近さ(A)',
                                '全体_件数': '件数（合図×決済）'})
    T.columns = [c.replace('_nrm_', ' そろえた ').replace('_net_', ' 実コスト ').replace('_n13_', ' 13円 ').replace('本物', '本物').replace('偶然', 'でたらめ平均') for c in T.columns]
    return r1(T)
sheets['形としての強さ'] = formtab('形', ['grp', 'kind', 'dir'])
fl = formtab('形×線', ['grp', 'line', 'kind', 'dir'])
sheets['形×線'] = fl.sort_values(['線の種類', '線', '入り方', '売買', '商品'])
sheets['決済の要素'] = pd.concat([formtab('利確', ['tp', 'grp', 'dir']), formtab('損切り', ['sl', 'grp', 'dir']), formtab('時間', ['tm', 'grp', 'dir'])])
sheets['判定足と近さ'] = formtab('判定足×近さ', ['kind', 'tf', 'b', 'dir'])

# ---- 形の前向き
Y = pd.read_pickle('/home/claude/bs/g/form_year.pkl'); keys = ['grp', 'line', 'kind', 'dir']; rows = []
for t in range(2020, 2027):
    sc = {}
    for inst in ['fut', 'cfd']:
        avg, cnt = Y[inst]; ys = [y for y in h_agg.YEARS if y < t]
        tot = (avg[ys] * cnt[ys]).sum(axis=1) / cnt[ys].sum(axis=1)
        real = tot.xs('W', level='fam'); nul = tot.drop('W', level='fam').groupby(level=keys)
        sc[inst] = (real - nul.mean()) / nul.std()
    zmin = pd.concat(sc, axis=1).min(axis=1).sort_values(ascending=False)
    for rank, (k, zz) in enumerate(zmin.head(3).items()):
        r = {'確かめる年': t, '順位': rank + 1, '形（その年より前のデータで選んだ）': f"{k[1]} {k[2]} {'買い' if k[3] == 1 else '売り'}", '選んだ時の z（2商品の小さい方）': zz}
        for inst in ['fut', 'cfd']:
            avg, cnt = Y[inst]; real = avg[t].xs('W', level='fam').loc[k]; nul = avg[t].drop('W', level='fam').loc[k]
            r[f'{INST[inst]} その年 本物'] = real; r[f'{INST[inst]} その年 でたらめ平均'] = nul.mean()
        rows.append(r)
sheets['形の前向き'] = r1(pd.DataFrame(rows))

# ---- 本当の前向き
NR = pd.concat([pd.read_pickle(f) for f in glob.glob('/home/claude/bs/g/hnest_*_*.pkl') if '_tr_' not in f])
s = NR.groupby(['inst', 'var', 'grp', 'fam'])[['top5_nrm', 'top5_n13', 'top5_net', 'top5_n']].sum().reset_index()
q = NR.groupby(['inst', 'var', 'grp', 'fam'])[['avg_nrm', 'pos_t', 'rho']].mean().reset_index()
out = []
for (inst, var, grp), g in s.groupby(['inst', 'var', 'grp']):
    w = g[g.fam == 'W'].iloc[0]; nl = g[g.fam != 'W']; qq = q[(q.inst == inst) & (q['var'] == var) & (q.grp == grp)]
    out.append({'商品': INST[inst], 'コストの見方': var, '群': grp, '上位5本 そろえた合計（本物）': w.top5_nrm, '上位5本 でたらめ中央': nl.top5_nrm.median(),
                '本物がでたらめを上回る割合': (w.top5_nrm > nl.top5_nrm).mean(), '上位5本 13円（本物）': w.top5_n13, '上位5本 実コスト pt（本物）': w.top5_net, '件数': w.top5_n,
                '群全体の1回平均（本物）': qq[qq.fam == 'W'].avg_nrm.mean(), '群全体の1回平均（でたらめ）': qq[qq.fam != 'W'].avg_nrm.mean(),
                '翌年への順位相関（本物）': qq[qq.fam == 'W'].rho.mean(), '翌年への順位相関（でたらめ）': qq[qq.fam != 'W'].rho.mean()})
sheets['本当の前向き'] = r1(pd.DataFrame(out))
yy = NR[NR.fam == 'W'].pivot_table(index=['inst', 'var', 'grp'], columns='t', values='top5_nrm', aggfunc='sum').reset_index()
yy['inst'] = yy.inst.map(INST); sheets['前向き 年ごと'] = r1(yy.rename(columns={'inst': '商品', 'var': 'コストの見方', 'grp': '群'}))
cnt = NR[NR.t == 2026].pivot_table(index=['inst', 'var', 'grp'], columns='fam', values='ncand').reset_index()
cnt['でたらめ 最小'] = cnt[[c for c in cnt if str(c).startswith('r')]].min(axis=1); cnt['でたらめ 最大'] = cnt[[c for c in cnt if str(c).startswith('r')]].max(axis=1)
cnt = cnt[['inst', 'var', 'grp', 'W', 'でたらめ 最小', 'でたらめ 最大']].rename(columns={'inst': '商品', 'var': 'コストの見方', 'grp': '群', 'W': '本物'}); cnt['商品'] = cnt['商品'].map(INST)
sheets['候補群の数'] = cnt
DF = pd.read_csv('/home/claude/bs/g/hdefs.csv', index_col=0); sel = []
for inst in ['fut', 'cfd']:
    T = pd.read_pickle(f'/home/claude/bs/g/hnest_tr_{inst}_W.pkl'); T = T[T['var'] == '実コスト'].merge(DF[['grp', 'line', 'kind']].rename(columns={'grp': '線の種類'}), left_on='def', right_index=True)
    x = T.groupby(['grp', '線の種類', 'line', 'kind', 'dir']).agg(件数=('nrm', 'size'), そろえた合計=('nrm', 'sum')).reset_index(); x.insert(0, '商品', INST[inst]); sel.append(x)
sel = pd.concat(sel); sel['dir'] = sel['dir'].map({1: '買い', -1: '売り'})
sheets['前向きで選ばれた形'] = r1(sel.rename(columns={'grp': '群', 'line': '線', 'kind': '入り方', 'dir': '売買'}).sort_values(['商品', '群', '件数'], ascending=[True, True, False]))

# ---- 本命
E = pd.read_pickle('/home/claude/bs/g/pk_exits.pkl'); E['inst'] = E.inst.map(INST)
sheets['本命 決済の表'] = r1(E.rename(columns={'inst': '商品', 'line': '線', 'tp': '利確', 'sl': '損切り', 'tm': '時間', 'real': '本物 1回平均（そろえた円）', 'null': 'でたらめ6種の平均', 'z': 'z'}))
ex = G.EXITS.index((3, 1, 2)); rows = []
for inst in ['fut', 'cfd']:
    variants = {'代表ルール': h_pk.trades(inst, 'W', 'H1Line 山', '反発', 15, 0.05, ex), '1日1回だけ': h_pk.trades(inst, 'W', 'H1Line 山', '反発', 15, 0.05, ex, oneday=True),
                '入りを5分遅らせる': h_pk.delayed(inst, 'W', 'H1Line 山', '反発', 15, 0.05, ex),
                '谷（H1Line 谷）で同じルール': h_pk.trades(inst, 'W', 'H1Line 谷', '反発', 15, 0.05, ex)}
    for f in ['r0', 'r1', 'r2', 'r3', 'r4', 'r5']: variants[f'でたらめな線 {f}'] = h_pk.trades(inst, f, 'H1Line 山', '反発', 15, 0.05, ex)
    for k, T in variants.items():
        c = T.nrm.cumsum(); dd = (c.cummax() - c).max()
        r = {'商品': INST[inst], '形': k, '件数': len(T), '1回平均 実コスト(pt)': T.net.mean(), '1回平均 そろえた(円)': T.nrm.mean(), '1回平均 13円': T.n13.mean(),
             'そろえた合計': T.nrm.sum(), '最大DD': dd, '合計÷最大DD': T.nrm.sum() / dd, '勝率': (T.nrm > 0).mean(), 'PF': T.nrm[T.nrm > 0].sum() / -T.nrm[T.nrm < 0].sum()}
        r.update({str(y): v for y, v in T.groupby('yr').nrm.sum().items()}); rows.append(r)
sheets['本命 年ごとと確認'] = r1(pd.DataFrame(rows))
rows = []
for inst in ['fut', 'cfd']:
    T = h_pk.trades(inst, 'W', 'H1Line 山', '反発', 15, 0.05, ex); g = T.pt * 68800 / T.e; fin = T.nrm - (g - {'fut': 5, 'cfd': 7}[inst])
    rows.append({'商品': INST[inst], **{f'コスト {c}円': (g - c + fin).mean() for c in [0, 5, 7, 13, 20, 30, 40]}})
sheets['本命 コストの感度'] = r1(pd.DataFrame(rows))

# ---- 線で止まるか
TT = []
for inst in ['fut', 'cfd']:
    T = pd.read_pickle(f'/home/claude/bs/g/touch_{inst}.pkl')
    for half, ys in [('全体', range(2018, 2027)), ('前半', range(2018, 2023)), ('後半', range(2023, 2027))]:
        g = T[T.yr.isin(ys)].groupby(['fam', 'line', 'X'])[['n', 'bounce', 'brk']].sum(); g['rate'] = g.bounce / (g.bounce + g.brk)
        p = g.rate.unstack('fam'); nul = p[[c for c in p if c != 'W']]; n = g.n.unstack('fam')['W']
        TT.append(pd.DataFrame({'商品': INST[inst], '期間': half, '触れた回数': n, '反発率 本物(%)': p.W * 100, '反発率 でたらめ平均(%)': nul.mean(axis=1) * 100,
                                '差(ポイント)': (p.W - nul.mean(axis=1)) * 100, 'z': (p.W - nul.mean(axis=1)) / nul.std(axis=1)}).reset_index())
sheets['線で止まるか'] = (pd.concat(TT).rename(columns={'line': '線', 'X': '幅(A)'})).round(2)

# ---- 条件
C = pd.read_pickle('/home/claude/bs/g/cond.pkl'); C = C[(C.feat != 0) & (C.feat_name != '曜日×時間') & (C.n_前半 >= 200) & (C.n_後半 >= 200)]
W = C[C.fam == 'W'].set_index(['inst', 'g2', 'dir', 'feat_name', 'val_name'])
N = C[C.fam != 'W'].groupby(['inst', 'g2', 'dir', 'feat_name', 'val_name'])[['up_前半', 'up_後半']].mean()
X = W[['n_前半', 'n_後半', 'avg_前半', 'avg_後半', 'up_前半', 'up_後半']].join(N, rsuffix='_偶然')
X['線に特有_前半'] = X['up_前半'] - X['up_前半_偶然']; X['線に特有_後半'] = X['up_後半'] - X['up_後半_偶然']
X = X.reset_index(); X['inst'] = X.inst.map(INST); X['dir'] = X['dir'].map({1: '買い', -1: '売り'})
P = X.pivot_table(index=['g2', 'dir', 'feat_name', 'val_name'], columns='inst', values=['up_前半', 'up_後半', '線に特有_前半', '線に特有_後半', 'n_前半', 'n_後半'])
P.columns = [f'{b} {a}' for a, b in P.columns]; P = P.dropna().reset_index()
sp = P[[c for c in P if '線に特有' in c]]
P['4つとも同じ向き（線に特有）'] = (np.sign(sp).nunique(axis=1) == 1)
P['線に特有の最小の大きさ'] = sp.abs().min(axis=1) * np.sign(sp.mean(axis=1))
P = P.rename(columns={'g2': '入り方', 'dir': '売買', 'feat_name': '条件', 'val_name': '値'}).sort_values(['4つとも同じ向き（線に特有）', '線に特有の最小の大きさ'], ascending=[False, False])
sheets['条件の全体傾向'] = r1(P)

# ---- 重なり
O = pd.read_pickle('/home/claude/bs/g/ovl.pkl')
def dd(s): c = s.cumsum(); return float((c.cummax() - c).max())
rows = [{'戦略': c, '取引した日数': int((O[c] != 0).sum()), '合計（そろえた円）': O[c].sum(), '最大DD': dd(O[c]), '合計÷最大DD': O[c].sum() / dd(O[c])} for c in O.columns]
combos = {'窓埋め＋寄り天②': ['窓埋め', '寄り天②'], '＋分水嶺（ミニ）': ['窓埋め', '寄り天②', '分水嶺 日の線上抜け（ミニ）'], '＋H1山の押し目買い（ミニ）': ['窓埋め', '寄り天②', 'H1山押し目買い（ミニ）'],
          '＋分水嶺＋H1山（ミニ）': ['窓埋め', '寄り天②', '分水嶺 日の線上抜け（ミニ）', 'H1山押し目買い（ミニ）'], '＋分水嶺＋H1山（CFD）': ['窓埋め', '寄り天②', '分水嶺 日の線上抜け（CFD）', 'H1山押し目買い（CFD）']}
for k, v in combos.items():
    s_ = O[v].sum(axis=1); rows.append({'戦略': k, '取引した日数': int((s_ != 0).sum()), '合計（そろえた円）': s_.sum(), '最大DD': dd(s_), '合計÷最大DD': s_.sum() / dd(s_)})
ov = r1(pd.DataFrame(rows)); corr = O.corr().round(2).reset_index().rename(columns={'src': '日ごとの損益の相関'})
sheets['窓埋め・寄り天・分水嶺との重なり'] = (ov, corr)

with pd.ExcelWriter(OUT, engine='openpyxl') as w:
    for name, df in sheets.items():
        if df is None:
            pd.DataFrame({'': []}).to_excel(w, sheet_name=name, index=False)
        elif isinstance(df, tuple):
            df[0].to_excel(w, sheet_name=name, index=False); df[1].to_excel(w, sheet_name=name, index=False, startrow=len(df[0]) + 3)
        else:
            df.to_excel(w, sheet_name=name, index=False)
print('ok')
