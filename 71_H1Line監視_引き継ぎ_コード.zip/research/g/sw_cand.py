"""頑丈なトリガーを先に決め、手じまい（と方向確認1つ）だけを前の年で選んで翌年に使う前向き。ランダムな入りにも同じ手順を当てて、上げ相場の分を差し引く。
対象：上位足スイング（15・60・240・D）と、15分足の網羅（k）・3分足（m3）・15分足ブログ（m15）の調べ直し。
出力：cand_fwd.pkl
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')

def load(study):
    if study.startswith('sw'):
        tf = study[3:]; import sw_agg
        Zs = {i: sw_agg.agg(tf, i, 'W') for i in ['fut', 'cfd']}
        TR = pd.read_csv(f'/home/claude/bs/g/sw_trigs_{tf}.csv').iloc[:, 0].tolist(); G = [f"{t}{'買' if k == 1 else '売'}" for t in TR for k in (0, 1)]
        dirs = np.array([1 if k == 1 else -1 for t in TR for k in (0, 1)]); EX = pd.read_csv(f'/home/claude/bs/g/sw_exits_{tf}.csv').手じまい.tolist()
        FL = pd.read_csv(f'/home/claude/bs/g/sw_filters_{tf}.csv').iloc[:, 0].tolist(); F = ['なし'] + FL; nF = 16
        rep = pd.read_pickle(f'/home/claude/bs/g/swrep_{tf}.pkl')['trig']; y0 = 2018
    else:
        rep = pd.read_pickle(f'/home/claude/bs/g/xrep_{study}.pkl')['trig']; EX = pd.read_csv('/home/claude/bs/g/xlib_rules.csv').手じまい.tolist()
        if study == 'k':
            Zs = {i: dict(np.load(f'/home/claude/bs/g/xk_{i}_W.npz')) for i in ['fut', 'cfd']}
            DF = pd.read_csv('/home/claude/bs/g/kdefs.csv', index_col=0); G = [f"{a}{'買' if d == 1 else '売'}" for a, d in zip(DF.trig, DF.dir)]; dirs = DF.dir.values
            F = ['なし'] + pd.read_csv('/home/claude/bs/g/kfilters.csv').iloc[:, 0].tolist(); y0 = 2018
        else:
            Zs = {i: dict(np.load(f'/home/claude/bs/g/xm_{study}_{i}_W.npz')) for i in ['fut', 'cfd']}
            TR = pd.read_csv(f'/home/claude/bs/g/{study}_trigs.csv').iloc[:, 0].tolist(); G = [f"{t}{'買' if k == 1 else '売'}" for t in TR for k in (0, 1)]
            dirs = np.array([1 if k == 1 else -1 for t in TR for k in (0, 1)]); from m3_sig import FILTERS; F = ['なし'] + list(FILTERS); y0 = 2020 if study == 'm3' else 2018
        nF = Zs['fut']['cnt'].shape[1]
        if F is None: F = [f'方向確認{k}' for k in range(nF)]
    return Zs, G, dirs, EX, F, nF, rep, y0

def fwd(Zs, g, y0, years, nmin=20, use_f=False, rnd=None):
    """rnd=+1/-1 ならランダムな入り（方向確認なし）"""
    rows = []
    for t in years:
        ty = t - y0 + 2; sc = None
        for inst, Z in Zs.items():
            if rnd is None:
                c = Z['cnt'][g, :, 2:ty].sum(-1); s = Z['nrm'][g, :, 2:ty, :].sum(-2)
                if not use_f: c = c[:1]; s = s[:1]
            else:
                k = 1 if rnd > 0 else 0; c = Z['cntR'][k:k + 1, 2:ty].sum(-1); s = Z['nrmR'][k:k + 1, 2:ty, :].sum(-2)
            if c.sum() == 0: continue
            a = np.where((c >= nmin)[:, None], s / np.maximum(c, 1)[:, None], np.nan)
            sc = a if sc is None else np.where(np.isnan(a), sc, np.where(np.isnan(sc), a, np.minimum(sc, a)))
        if sc is None or np.all(np.isnan(sc)): continue
        f, e = np.unravel_index(np.nanargmax(sc), sc.shape)
        for inst, Z in Zs.items():
            if rnd is None:
                n = Z['cnt'][g, f, ty]; v = Z['nrm'][g, f, ty, e]; v13 = Z['n13'][g, f, ty, e]
            else:
                k = 1 if rnd > 0 else 0; n = Z['cntR'][k, ty]; v = Z['nrmR'][k, ty, e]; v13 = Z['n13R'][k, ty, e]
            if n == 0: continue
            rows.append(dict(t=t, inst=inst, f=int(f), e=int(e), n=float(n), sum=float(v), sum13=float(v13)))
    return pd.DataFrame(rows)

def run():
    out = []; det = []
    for study in ['sw_15', 'sw_60', 'sw_240', 'sw_D', 'k', 'm15', 'm3']:
        Zs, G, dirs, EX, F, nF, rep, y0 = load(study)
        years = range(2022, 2027) if study == 'm3' else range(2020, 2027)
        rep = rep.copy(); rep['頑丈さ(z)'] = rep['頑丈さ(z)'].fillna(0)
        cand = rep[(rep['両方そろう割合'] >= 0.15) & (rep['頑丈さ(z)'] >= 2)].トリガー.tolist()
        R = {d: fwd(Zs, None, y0, years, rnd=d) for d in (1, -1)}
        for nm in cand:
            g = G.index(nm); d = dirs[g]
            for use_f in (False, True):
                X = fwd(Zs, g, y0, years, use_f=use_f)
                if len(X) == 0: continue
                rr = R[d]
                for inst in ['fut', 'cfd']:
                    x = X[X.inst == inst]; r = rr[rr.inst == inst]
                    if len(x) == 0 or x.n.sum() == 0: continue
                    out.append(dict(調べ=study, トリガー=nm, 方向確認も選ぶ=use_f, 商品={'fut': 'ミニ', 'cfd': 'CFD'}[inst], 件数=x.n.sum(), 前向き1回平均=x['sum'].sum() / x.n.sum(),
                                    前向き13円=x.sum13.sum() / x.n.sum(), 前向き合計=x['sum'].sum(), プラスの年=f"{(x['sum'] > 0).sum()}/{len(x)}",
                                    ランダム同じ向き1回平均=r['sum'].sum() / max(r.n.sum(), 1), 両方そろう割合=float(rep.set_index('トリガー').loc[nm, '両方そろう割合']), 頑丈さ=float(rep.set_index('トリガー').loc[nm, '頑丈さ(z)'])))
                    for _, q in x.iterrows():
                        det.append(dict(調べ=study, トリガー=nm, 方向確認も選ぶ=use_f, 商品=q.inst, 年=q.t, 方向確認=F[q.f] if q.f < len(F) else q.f, 手じまい=EX[q.e], 件数=q.n, 合計=q['sum']))
        print(study, len(cand), flush=True)
    O = pd.DataFrame(out); O['ランダムとの差'] = O.前向き1回平均 - O.ランダム同じ向き1回平均
    pd.to_pickle(dict(sum=O, det=pd.DataFrame(det)), '/home/claude/bs/g/cand_fwd.pkl')
    pd.set_option('display.width', 250); pd.set_option('display.max_rows', 300)
    print(O[~O.方向確認も選ぶ].round(1).to_string())

if __name__ == '__main__':
    run()
