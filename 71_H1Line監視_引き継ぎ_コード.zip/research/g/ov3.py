"""採用ルール同士の重なり：ある合図の直近1時間（同じ足を含む）に、ほかの採用ルールの合図がいくつ出ていたかで成績を分ける。"""
import pickle, numpy as np, pandas as pd, sys
BUY = [1, 3, 7, 12, 22, 27, 28, 29, 30, 31]; SELL = [5, 11, 32, 33, 34]
def load(src):
    if src == 'emu':
        e1 = pickle.load(open('/home/claude/bs/g/emu_research.pkl', 'rb')); e2 = pickle.load(open('/home/claude/bs/g/emu2.pkl', 'rb'))
        T = {}
        for inst in ['fut', 'cfd']:
            for r in BUY + SELL:
                t = (e2[(inst, r)] if (inst, r) in e2 else e1[(inst, 'clock', r)])['tr']; t = t[t.yr >= 2020]
                T[(inst, r)] = (t.i5.values.astype(np.int64), t.x5.values.astype(np.int64), t.v.values.astype(float), t.yr.values)
        return T
    return pickle.load(open('/home/claude/bs/g/ov3_research.pkl', 'rb'))
def run(T, W=12):
    rows = []; pairs = []
    for inst in ['fut', 'cfd']:
        for r in BUY + SELL:
            i5, x5, v, yr = T[(inst, r)]
            same = BUY if r in BUY else SELL; opp = SELL if r in BUY else BUY
            def near(s):
                j = T[(inst, s)][0]; j = np.sort(j); a = np.searchsorted(j, i5 - W, 'left'); b = np.searchsorted(j, i5, 'right'); return (b - a) > 0
            ns = sum(near(s).astype(int) for s in same if s != r); no = sum(near(s).astype(int) for s in opp)
            for s in same:
                if s == r: continue
                m = near(s); pairs.append(dict(商品=inst, ルール=r, 一緒に出たルール=s, 一緒の回数=int(m.sum()), 一緒の1回平均=v[m].mean() if m.any() else np.nan, 単独の1回平均=v[~m].mean()))
            for lab, m in [('ほかに出ていない', ns == 0), ('同じ向きが1つ', ns == 1), ('同じ向きが2つ以上', ns >= 2), ('逆向きも出ていた', no >= 1)]:
                vv = v[m]; y = yr[m]
                rows.append(dict(商品=inst, ルール=r, 向き='買い' if r in BUY else '売り', 重なり=lab, 回数=int(m.sum()), 一回平均=vv.mean() if m.any() else np.nan, 勝率=(vv > 0).mean() * 100 if m.any() else np.nan,
                                 前半の1回平均=vv[y <= 2022].mean() if (y <= 2022).any() else np.nan, 後半の1回平均=vv[y >= 2023].mean() if (y >= 2023).any() else np.nan, 全体の1回平均=v.mean()))
    return pd.DataFrame(rows), pd.DataFrame(pairs)
def pooled(D, T, W=12):
    """ルールごとの平均の違いを取り除くため、各合図の値から「そのルールの全体平均」を引いてから、重なりの区分ごとにまとめる"""
    out = []
    for inst in ['fut', 'cfd']:
        for side, RS in [('買い', BUY), ('売り', SELL)]:
            acc = {}
            for r in RS:
                i5, x5, v, yr = T[(inst, r)]; same = RS; opp = SELL if side == '買い' else BUY
                def near(s):
                    j = np.sort(T[(inst, s)][0]); return (np.searchsorted(j, i5, 'right') - np.searchsorted(j, i5 - W, 'left')) > 0
                ns = sum(near(s).astype(int) for s in same if s != r); no = sum(near(s).astype(int) for s in opp); d = v - v.mean()
                for lab, m in [('ほかに出ていない', ns == 0), ('同じ向きが1つ', ns == 1), ('同じ向きが2つ以上', ns >= 2), ('逆向きも出ていた', no >= 1)]:
                    a = acc.setdefault(lab, [[], []]); a[0].append(d[m]); a[1].append(yr[m])
            for lab, (ds, ys) in acc.items():
                d = np.concatenate(ds); y = np.concatenate(ys)
                se = d.std(ddof=1) / np.sqrt(len(d)) if len(d) > 1 else np.nan
                out.append(dict(商品=inst, 向き=side, 重なり=lab, 回数=len(d), ルールの平均との差=d.mean(), t値=d.mean() / se if se else np.nan, 前半の差=d[y <= 2022].mean(), 後半の差=d[y >= 2023].mean()))
    return pd.DataFrame(out)
if __name__ == '__main__':
    src = sys.argv[1]; T = load(src); D, P = run(T); Q = pooled(D, T)
    pd.to_pickle(dict(D=D, P=P, Q=Q), f'/home/claude/bs/g/ov3_{src}_out.pkl')
    pd.set_option('display.width', 250); print(Q.round(1).to_string()); print(D[D.商品 == 'fut'].round(0).to_string())
