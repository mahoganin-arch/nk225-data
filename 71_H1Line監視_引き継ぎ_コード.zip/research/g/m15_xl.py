import numpy as np, pandas as pd
OUT='/home/claude/out/15分足_ブログ観点と3分足タイミング_2026-10-25.xlsx'
def rl(s):
    if not isinstance(s,str): return s
    for a,b in [('H1Line(15分足の線)','H4Line'),('H1Line','H4Line'),('m15','H1Line'),('15分足線','1H線(EMA48)'),('3分足線','15分足線(EMA12)'),('3分','15分')]: s=s.replace(a,b)
    return s
def RL(df): 
    df=df.copy()
    for c in df.columns:
        if df[c].dtype==object: df[c]=df[c].map(rl)
    return df
O=pd.read_pickle('m15rep.pkl'); S={}
S['まとめ']=pd.DataFrame({'':[
 '【確認への答え】前回の15分足の検証には、ブログ由来の観点（上位足ストキャス・速K×遅K・周期/値幅・3つのサイン・1Hと4Hの同じ位置クロス）が入っていなかった。今回3分足と同じやり方で15分足チャートに当てはめた（5分足 2017〜、ミニ・CFD）。',
 '当てはめ方：3分足チャートの m15Line→15分足の H1Line、3分足線(EMA12)→15分足線(EMA12)、15分足線(EMA60)→1H線(EMA48)、H1Line→H4Line。ストキャスはチャート(15分)と 1H・4H・日足。損切りは なし／0.1A／0.25A／0.5A。',
 '【15分足の結果1】線を使うブログの形は、でたらめな線と差がない（4つともランダムより良い割合：本物 9.1%、でたらめ 4〜10%）。3分足（本物13%・でたらめ7〜11%）より線の情報はさらに弱い。',
 '【結果2】頑丈に見えたのは売りの一部：15分足線×1H線のデッドクロス売り、周期型クロス売り、4H 速K×遅K(MACD)デッドクロス売り（ランダムより良い割合 33%／でたらめ 22%）。ただし4つともプラスまでそろうのは少ない（1〜14%）。',
 '【結果3】方向確認で一番効いたのは 日足の遅ストキャスの向き（4つとも改善 35%、でたらめ 15%）と 価格がH4Lineの同じ側（19%、でたらめ 7%）。1H・4H・日足の速ストキャスをそろえるのは効かない。',
 '【結果4】前向き（前の年だけで選ぶ）：上位5本は続かず、全部の平均もでたらめな線と同じくらい。ブログの形だけで新しい戦略は作れない。',
 '【次の確かめ：3分足でタイミングを合わせる】15分足の候補 A・A+・E2・C+ が出たあと、3分足の合図（3分足線とm15、m15の向き、速K>遅K、速ストキャス低位から上向き、m15Lineや入値−0.1Aの指値）を30/60/120分待った。',
 '結果：どの待ち方も8つ（4候補×2商品）のうち前半・後半とも良くなったのは最大3つ。合計の利益が増えたのはほとんど無い。待つと良いトレードを取り逃がす（見送ったトレードの方が成績が良いことが多い）。→ 15分足の合図ですぐ入るのが一番良い。',
 '【おまけ：候補に日足の遅ストキャスを足す】「日足遅ストキャス上向き＋価格がH4Lineの上」をAに足すと ミニ +43→+59、CFD +33→+43、A+ では ミニ +66→+91、CFD +28→+64（CFD 9/9年プラス）。件数は 94〜317 と少なく、後から見つけた形なので、2026/10/9 以降の前向きで確かめる候補にとどめる。C+ には逆効果。',
 '分からないもの（全時間足で未検証）：PriceHight・寄り付きの逆指値の値段・Indi07・矢印。']})
S['線の対応']=pd.DataFrame([('m15Line','H1Line（H系の式 m=4）'),('3分足線 EMA12','15分足線 EMA12（macd 15m-1H）'),('15分足線 EMA60','1H線 EMA48（macd 1H-4H）'),('H1Line (m=20)','H4Line（m=16）'),('3分の速/遅ストキャス','15分の速/遅ストキャス'),('15分・1H・4H・日足ストキャス','15分(チャートそのもの)・1H・4H・日足')],columns=['3分足チャートでの名前','15分足チャートで使ったもの'])
S['15分足 線の効き目']=O['null'].round(3)
J=O['trig'][['トリガー','売買','線を使う','n','p','p_n','z','pp','pp_n','med']].rename(columns={'n':'形の数','p':'本物：4つともランダムより良い割合','p_n':'でたらめな線の平均','z':'頑丈さ(z)','pp':'本物：さらに4つともプラス','pp_n':'でたらめ：同','med':'差の最小の中央値'})
S['15分足 トリガーの頑丈さ']=RL(J).round(3)
F=O['filt'].drop(columns=['fset','fam']).rename(columns={'改善4つとも':'本物：4つとも改善した割合','改善_でたらめ':'でたらめな線','変化中央':'差の変化（中央値）','変化_でたらめ':'でたらめ：同'})
S['15分足 方向確認の効き目']=RL(F).round(3)
S['15分足 ルールそのまま']=RL(O['rules']).round(1)
S['15分足 上位300(参考)']=RL(O['top']).round(1)
N=pd.read_pickle('m15nest.pkl'); s=N.groupby(['grp','inst','fam'])[['上位5 合計','上位5 合計13円','上位5 件数']].sum().join(N.groupby(['grp','inst','fam'])[['全部の平均','全部の平均13円','順位相関']].mean()).reset_index()
s['inst']=s.inst.map({'fut':'ミニ','cfd':'CFD'}); s['fam']=s.fam.map(lambda f:'本物' if f=='W' else f'でたらめ {f}')
S['15分足 本当の前向き']=s.rename(columns={'grp':'選び方','inst':'商品','fam':'線'}).round(1)
T=pd.read_pickle('m3timing_sum.pkl'); R=pd.read_pickle('m3timing_rob.pkl').reset_index()
S['3分足タイミング 頑丈さ']=R.rename(columns={'良くなった':'1回平均が良くなった数(8つ中)','前後とも':'前半・後半とも良くなった数','合計も増':'合計も増えた数','平均の差(中央)':'1回平均の差（中央値）'}).round(1)
S['3分足タイミング 全部']=T.round(1)
S['候補×日足ストキャス']=pd.read_pickle('cand_dstoch.pkl').round(1)
with pd.ExcelWriter(OUT,engine='openpyxl') as w:
    for k,v in S.items(): v.to_excel(w,sheet_name=k[:31],index=False)
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
wb=load_workbook(OUT)
for ws in wb.worksheets:
    for c in ws[1]: c.font=Font(bold=True); c.fill=PatternFill('solid',fgColor='DDEBF7'); c.alignment=Alignment(wrap_text=True,vertical='top')
    for col in ws.columns:
        L=max(len(str(c.value or '')) for c in list(col)[:200]); ws.column_dimensions[col[0].column_letter].width=min(max(8,L*1.6),60)
    ws.freeze_panes='A2'
ws=wb['まとめ']; ws.column_dimensions['A'].width=120
for row in ws.iter_rows(min_row=2):
    for c in row: c.alignment=Alignment(wrap_text=True,vertical='top')
wb.save(OUT); print('ok',[ (w.title,w.max_row) for w in wb])
