import numpy as np, pandas as pd
OUT='/home/claude/out/候補と近い候補の一覧_買い売り_2026-10-26.xlsx'
X=pd.read_pickle('cand_list.pkl'); YRS=[str(y) for y in range(2020,2027)]
base=['調べ','ルール','条件','判定','外れた理由','頑丈さz']
per=lambda L:[f'{L} 件数',f'{L} 一回平均',f'{L} ランダム1回平均',f'{L} 合計',f'{L} プラスの年',f'{L} 最大DD',f'{L} 勝率',f'{L} 平均保有時間']+[f'{L} {y}' for y in YRS]
cols=base+per('ミニ')+per('CFD')+['合計(両商品)']
for L in ['ミニ','CFD']: X[f'{L} ランダムとの差']=X[f'{L} 一回平均']-X[f'{L} ランダム1回平均']
cols=cols[:6]+['ミニ ランダムとの差','CFD ランダムとの差']+cols[6:]
X['ルール']=X.ルール.str.replace('^(k|sw15|sw60|sw240|swD|zt):','',regex=True)
def grp(df):
    g=df.sort_values('合計(両商品)',ascending=False).groupby(['調べ','ルール'],sort=False)
    top=g.head(1).copy(); top['同じルールの候補の数']=g.size().values if False else top.apply(lambda r: ((df.調べ==r.調べ)&(df.ルール==r.ルール)).sum(),axis=1)
    top['ほかの条件']=top.apply(lambda r:' / '.join(df[(df.調べ==r.調べ)&(df.ルール==r.ルール)&(df.条件!=r.条件)].条件.head(8)),axis=1)
    return top
named=[('15分足(網羅)','H1Line 山 反発0.1買','そのまま','A'),('15分足(網羅)','H1Line 山 反発0.1買','方向確認：インジ6本そろう','A+'),('15分足(網羅)','PSAR 買い買','方向確認：15m-1H陽転','E2に近い形（1H-4H陽転は入っていない）'),
       ('15分足(網羅)','macd 1D-1W 反発0.25買','方向確認：15m-1H陽転','C+に近い形（1H-4H陽転は入っていない）'),('15分足スイング','1H・4H 同じ位置でクロス買','そのまま','上位足スイングの候補'),
       ('1時間足','EMA48×H4Line買','そのまま','上位足スイングの候補'),('1時間足','H4Lineの向き転換買','そのまま','上位足スイングの候補'),
       ('15分足セオリー','H1Line 表タッチ（抜けて4時間以内）買','そのまま','セオリー'),('15分足セオリー','H1Line 抜けて終値2本上に居続けた買','そのまま','セオリー'),
       ('15分足セオリー','H1Line 表側で届かずに切り返し（0.05A以内・触れず）買','そのまま','タッチの幅'),('15分足セオリー','H1Line 谷の値に届かずに反発（0.1A以内・触れず）買','そのまま','タッチの幅'),
       ('15分足セオリー','1H下げ周期の終わりで再浮上（1H低位でゴールデン・4H上げ周期）買','そのまま','セオリー'),('15分足セオリー','ハーモニック売りの否定（X点を越えたら買い）買','そのまま','セオリー'),
       ('15分足セオリー','ハーモニック買い D点確定（比率の誤差20%）買','そのまま','タッチの幅'),
       ('15分足セオリー','H4Line 割れて終値2本下に居続けた売','そのまま','セオリー（売り）'),('15分足セオリー','D1Line 下でもみ合ってから割る売','そのまま','セオリー（売り）'),
       ('15分足セオリー','H4Line 裏タッチ 近さ0.15A（割れて4時間以内）売','そのまま','タッチの幅（売り）')]
N=[]
for s,r,c,lab in named:
    q=X[(X.調べ==s)&(X.ルール==r)&(X.条件.isin([c]))]
    if len(q): q=q.copy(); q.insert(0,'前回までの呼び名',lab); N.append(q)
    for c2 in ['避ける','入る条件']:
        q2=X[(X.調べ==s)&(X.ルール==r)&(X.条件==c2)]
        if len(q2) and c=='そのまま': q2=q2.copy(); q2.insert(0,'前回までの呼び名',lab+'（'+c2+'つき）'); N.append(q2)
N=pd.concat(N)
cnt=X.groupby(['向き','判定']).size().unstack().fillna(0).astype(int)
S={}
S['まとめ']=pd.DataFrame({'':[
 '【ご質問1：今回のセオリー検証も「入らない条件」を含めて調べたか】前回お送りした時点では、セオリーの163ルールには入らない条件・入る条件を当てはめていなかった。今回、前回までと同じ方法（83の状態から、前の年だけで「避ける」「入る条件」を最大2つ選び翌年に当てはめる、両商品×前後半の4つで成り立つものだけ）で、163ルールすべてに当てはめ直した。',
 '  ただし「方向確認（線の傾き・陽転など）」と「入らない条件」を同時に重ねた形はまだ。方向確認ありのルールは「全ルール成績表」の数字（方向確認1つ）をそのまま使っている。',
 '【一覧の作り方】すべて前向き（2020〜2026、手じまいは前の年で選ぶ）・ポジション1つずつ・ミニとCFDの両方。対象は約9,000（全ルール成績表の方向確認あり＋方向確認なしの全ルールとセオリーのルールのそのまま／避ける／入る条件）。',
 '  候補の条件（ミニ・CFDとも）：①合計プラス ②7年中5年以上プラス ③1回平均がランダム（同じ向き・同じ条件・同じ手じまいの選び方）より良い ④1つずつで70回以上 ⑤線を使うルールはでたらめな線より頑丈（z≥2）。「近いが外れた」＝①〜⑤のうち1つだけ満たさない。',
 f"  数：買い 候補{cnt.loc['買い','候補']}・近いが外れた{cnt.loc['買い','近いが外れた']}、売り 候補{cnt.loc['売り','候補']}・近いが外れた{cnt.loc['売り','近いが外れた']}（約9,000のうち）。買いは同じルールの条件違いが多いので、ルールごとに一番良いものにまとめた表も付けた。",
 '【売りの候補（19）の中心】H4Line に関するものがほとんど：H4Line に下から近づいて反落（0.15A、方向確認：遅ストキャス低位／15m-1H陽転／近くに支え）、H4Line 裏タッチ 0.15A、H4Line を割って終値2本下に居続ける、終値×H4Line 売り（避ける条件つき）。ほかに H1Line 山の値で反発の売り（入る条件つき）、D1Line の下でもみ合ってから割る売り、1時間足の遅K×遅D売り（避ける条件つき）。ランダムな売りは1回 −10〜−140 なので、どれもランダムよりはっきり良い。',
 '【買いの候補の中心】1時間足の EMA12×signal 陽転・EMA48 反発・H4Line 向き転換・EMA48×H4Line、15分足の PSAR 買い・15m-1H 陽転・インジ5本／6本、H1Line の表側で届かずに切り返し・上から届かずに反発、4時間足の EMA72 反発 など。',
 '【前回までに名前を挙げた候補の判定】（シート「前回までの候補の判定」）A（H1Line山の押し目買い）＝候補（避ける条件つきも候補）。A+（インジ6本そろう）＝候補。E2・C+ に近い形（15m-1H陽転のみ）＝候補。1時間足の EMA48×H4Line 買い・H4Line 向き転換買い＝候補（避ける条件つきも候補）。15分足スイングの「1H・4H 同じ位置でクロス」買い＝④件数不足（53回）で近いが外れた。',
 '  セオリー：H1Line 表タッチ買い＝候補。H1Line 表側で届かずに切り返し・H1Line 谷の値で届かずに反発＝候補（避ける・入る条件つきも候補）。ハーモニック買い（誤差20%）＝候補。H1Line 抜けて2本居続け＝③CFDでランダムに負けて近いが外れた。1H下げ周期の終わりの再浮上・ハーモニック売りの否定＝② CFD のプラスの年が足りず近いが外れた。',
 '  売り：H4Line 割れて終値2本下・H4Line 裏タッチ0.15A・D1Line の下でもみ合ってから割る＝候補。D1Line もみ合い割れは「避ける」条件つきで さらに良い（ミニ +95・CFD +91、ランダム −33／−24）。H4Line 系の売りは、条件をつけると悪くなる。',
 '【注意】約9,000の中から選んでいるので、偶然で通ったものも混じる。⑤の頑丈さと、2026/10/9 以降の前向きで確かめるのが前提。ランダムの1回平均は、全ルール成績表の分は「重ねて持つ」ときの値、それ以外は同じ条件のランダムの値で、少し基準が違う。']})
S['前回までの候補の判定']=N[['前回までの呼び名']+cols].round(1)
S['売り 候補']=X[(X.向き=='売り')&(X.判定=='候補')].sort_values('合計(両商品)',ascending=False)[cols].round(1)
S['売り 近いが外れた']=X[(X.向き=='売り')&(X.判定=='近いが外れた')].sort_values('合計(両商品)',ascending=False)[cols].round(1)
b=X[(X.向き=='買い')&(X.判定=='候補')]
S['買い 候補（ルールごと）']=grp(b)[['同じルールの候補の数','ほかの条件']+cols].round(1)
S['買い 候補（全部）']=b.sort_values('合計(両商品)',ascending=False)[cols].round(1)
bn=X[(X.向き=='買い')&(X.判定=='近いが外れた')]
S['買い 近いが外れた（ルールごと）']=grp(bn)[['同じルールの候補の数','ほかの条件']+cols].round(1)
S['買い 近いが外れた（全部）']=bn.sort_values('合計(両商品)',ascending=False)[cols].round(1)
PL=pd.read_pickle('cond_tr_zt.pkl')['picks']; S['セオリーの条件（年ごと）']=PL
with pd.ExcelWriter(OUT,engine='openpyxl') as w:
    for k,v in S.items(): v.to_excel(w,sheet_name=k[:31],index=False)
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
wb=load_workbook(OUT)
for ws in wb.worksheets:
    for cc in ws[1]: cc.font=Font(bold=True); cc.fill=PatternFill('solid',fgColor='DDEBF7'); cc.alignment=Alignment(wrap_text=True,vertical='top')
    for col in ws.columns:
        L=max(len(str(x.value or '')) for x in list(col)[:80]); ws.column_dimensions[col[0].column_letter].width=min(max(8,L*1.3),45)
    ws.freeze_panes='C2'
ws=wb['まとめ']; ws.column_dimensions['A'].width=130; ws.freeze_panes='A2'
for row in ws.iter_rows(min_row=2):
    for cc in row: cc.alignment=Alignment(wrap_text=True,vertical='top')
wb.save(OUT)
pd.set_option('display.width',300)
print(N[['前回までの呼び名','条件','判定','外れた理由','ミニ 一回平均','ミニ ランダム1回平均','CFD 一回平均','CFD ランダム1回平均','ミニ 合計','CFD 合計','ミニ プラスの年','CFD プラスの年','ミニ 件数']].round(1).to_string())
print(len(S['買い 候補（ルールごと）']), len(S['買い 近いが外れた（ルールごと）']))
