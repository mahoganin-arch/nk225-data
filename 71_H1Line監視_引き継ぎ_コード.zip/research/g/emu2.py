"""Pine の新しいルール（No.7・11・27〜34）を Python で書き直し、研究の合図（方向確認つき）と突き合わせ、同じ手じまいの成績も比べる。"""
import sys, numpy as np, pandas as pd, pickle
sys.path.insert(0,'/home/claude/bs'); sys.path.insert(0,'/home/claude/bs/g')
import emu
from h_lines import ema, hfilt
from k_ind import stoch
from rs3 import seq
REF=68800.0
def extra(B, inst, X):
    c,h,l,A=B['c'],B['h'],B['l'],B['A']; o=B['o']
    mc96,_=emu.f_sig(c,96); _,sg4=emu.f_sig(c,4); sk,_=stoch(h,l,c,140,84,84)
    i1k,_=stoch(h,l,c,5,3,3); c1=np.where(i1k>=60,1,np.where(i1k<=40,-1,0))
    rise=[]
    for m in range(1,6):
        mm=ema(c,int(12*m))-ema(c,int(26*m)); p=np.r_[np.nan,mm[:-1]]; rise.append(np.where(mm>p,1,np.where(mm<p,-1,0)))
    rise=np.stack(rise,1); allRed=(c1==1)&(rise>0).all(1); agree=(c1==1).astype(int)+(rise>0).sum(1)
    # 1時間足の遅ストキャス（時計区切り）・EMA48・H4Line
    g60,end60,G=emu.hour_bars(o,h,l,c,None if False else pd.Series(X['tm']).groupby(np.cumsum(np.r_[0,B['is15'][:-1]])).first().values[:len(c)],B['sesId'],'clock')
    x=G.c.values; sk60,sd60=stoch(G.h.values,G.l.values,x,140,84,84); b60=hfilt(x,4); e48=ema(x,48)
    # 確定した1時間足の値：その15分足が1時間足の終わりならその足、違えば1つ前の1時間足
    idx=np.where(end60,g60,g60-1); ok=idx>=0
    sk60c=np.where(ok,sk60[np.maximum(idx,0)],np.nan); sd60c=np.where(ok,sd60[np.maximum(idx,0)],np.nan)
    e48b=np.where(end60,(e48-b60)[g60]>0,False)
    return dict(mc96=mc96,sg4=sg4,sk=sk,allRed=allRed,agree=agree,sk60c=sk60c,sd60c=sd60c,e48above=e48b)
def sigs(B,E):
    c,h,l,A=B['c'],B['h'],B['l'],B['A']; ses=B['sesId']; pc=np.r_[np.nan,c[:-1]]
    def bounce(L,b,d):
        pL=np.r_[np.nan,L[:-1]]
        return ((pc>pL+b)&(l<=L+b)&(c>L)) if d==1 else ((pc<pL-b)&(h>=L-b)&(c<L))
    pk=B['h1pk']; ppk=np.r_[np.nan,pk[:-1]]; brk=(pc<ppk)&(c>=pk)
    S={}
    S[7]=emu.once(bounce(pk,0.1*A,1),ses)&E['allRed']
    S[11]=emu.once(bounce(B['h4'],0.15*A,-1),ses)&(E['sk']>=50)
    S[27]=emu.once(brk,ses)&E['allRed']
    S[28]=emu.once(bounce(pk,0.05*A,1),ses)&(B['mc1']>np.r_[np.nan,B['mc1'][:-1]])
    S[29]=emu.once(bounce(pk,0.15*A,1),ses)&E['allRed']
    S[30]=B['sig3'].astype(bool)&E['e48above']
    S[31]=emu.once(bounce(E['mc96'],0.1*A,1),ses)&(B['h1']>np.r_[np.nan,B['h1'][:-1]])
    S[32]=emu.once(bounce(B['h4'],0.05*A,-1),ses)&(B['cnt']<=-4)
    h4=B['h4']; S[33]=((h4-np.r_[np.nan,h4[:-1]])<0)&((np.r_[np.nan,h4[:-1]]-np.r_[np.nan,np.nan,h4[:-2]])>=0)&(E['sk60c']<E['sd60c'])
    S[34]=emu.once(bounce(E['sg4'],0.25*A,-1),ses)&(E['sk']>=50)
    for k in S: S[k]=S[k]&~np.isnan(A)&(A>0)
    return S
# (型, 損切り, 本数, 週末, 向き, 利確)  型：1 H4下向き 2 D1割れ 3 2本目の線 4 H1上抜け 8 1H D1下向き 10 週末だけ 11 H4上向き 12 決まった利確
EX={7:(3,'sl05',0,1,1,None),11:(4,'sl05',0,1,-1,None),27:(2,'sl05',0,1,1,None),28:(1,'sl05',0,1,1,None),29:(1,None,0,1,1,None),30:(8,None,240,0,1,None),31:(10,None,0,1,1,None),
    32:(11,'sl05',0,1,-1,None),33:(12,None,960,0,-1,('A',1.0)),34:(12,'line',0,1,-1,('P',200.0))}
def run(B,E,sig,r,cost):
    t,slm,cap,wk,dr,tp=EX[r]; c,h,l,o,A=B['c'],B['h'],B['l'],B['o'],B['A']; n=len(c)
    h4=B['h4']; d1=B['d1']; dh=np.diff(h4,prepend=np.nan); pdh=np.r_[np.nan,dh[:-1]]
    ev={1:(dh<0)&(pdh>=0),2:(c<d1)&(np.r_[np.nan,c[:-1]]>=np.r_[np.nan,d1[:-1]]),4:(c>B['h1'])&(np.r_[np.nan,c[:-1]]<=np.r_[np.nan,B['h1'][:-1]]),8:B['u60dn'].astype(bool),11:(dh>0)&(pdh<=0)}.get(t,np.zeros(n,bool))
    # 2本目の線（研究と同じ19本の線は使えないので H系3本＋山谷＋macd/signal 15m-1H の近いもので代用せず、ここでは型3は研究エンジンで比べる）
    LM=np.stack([B['h1'],B['h4'],B['d1'],B['mc1'],B['sg1'],B['h1pk'],B['h1vl']],1)
    # 1時間足の本数
    hc=np.cumsum(B['end60'].astype(int))
    out=[]; inpos=False
    for i in range(n):
        if inpos:
            x=np.nan
            if not np.isnan(sl) and ((dr==1 and l[i]<=sl) or (dr==-1 and h[i]>=sl)): x=min(o[i],sl) if dr==1 else max(o[i],sl)
            if np.isnan(x) and not np.isnan(tpv) and ((dr==1 and h[i]>=tpv) or (dr==-1 and l[i]<=tpv)): x=max(o[i],tpv) if dr==1 else min(o[i],tpv)
            if np.isnan(x):
                unit=hc[i]-hc0 if r==30 else i-ei
                if ev[i] or (cap>0 and unit>=cap) or (wk and B['weekEnd'][i]): x=c[i]
            if not np.isnan(x): out.append((B['i5'][ei],B['i5'][i],e,x)); inpos=False
        if not inpos and sig[i]:
            inpos=True; e=c[i]; ei=i; hc0=hc[i]
            sl=e-dr*0.5*A[i] if slm=='sl05' else (E['sg4'][i]-dr*0.25*A[i] if slm=='line' else np.nan)
            tpv=np.nan
            if tp is not None: tpv=e+dr*(tp[1]*A[i] if tp[0]=='A' else tp[1])
            if t==3:
                dist=(LM[i]-e)*dr; dd=np.sort(dist[dist>0.05*A[i]]); tpv=e+dr*dd[1] if len(dd)>1 else np.nan
    T=pd.DataFrame(out,columns=['i5','x5','e','x']); T['v']=(T.x-T.e)*dr*REF/T.e-cost; return T
if __name__=='__main__':
    res={}
    for inst in ['fut','cfd']:
        X=dict(np.load(f'/home/claude/bs/g/data_{inst}.npz'))
        B=emu.build(inst,'clock'); K=np.load(f'/home/claude/bs/g/kind_{inst}_W.npz'); B['is15']=K['is15']
        g60,end60,G=emu.hour_bars(B['o'],B['h'],B['l'],B['c'],pd.Series(X['tm']).groupby(np.cumsum(np.r_[0,K['is15'][:-1]])).first().values[:len(B['c'])],B['sesId'],'clock'); B['end60']=end60
        E=extra(B,inst,X); S=sigs(B,E)
        for r in EX:
            T=run(B,E,S[r],r,5.0 if inst=='fut' else 7.0); T['yr']=X['yr'][T.i5.values]; res[(inst,r)]=dict(sig=B['i5'][S[r]],tr=T)
        print(inst,flush=True)
    pickle.dump(res,open('/home/claude/bs/g/emu2.pkl','wb'))
