"""売りの合図を「買いの手じまい・見送り」に使ったときの効き目（アラートの買い10ルール、1つずつ・前向き、2020〜2026）。
早めに手じまい：持っている間に売りの合図が出たら、その足の終値で手じまう。見送り：直前 W 時間に売りの合図があれば買いに入らない。
出力：ss_riskoff.pkl
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from ss_cand import BUY, seq_idx, dd_of
RU = pd.read_csv('/home/claude/bs/g/ss_rules.csv')
T = pd.concat([pd.read_pickle('/home/claude/bs/g/tr2.pkl'), pd.read_pickle('/home/claude/bs/g/tr_zt.pkl')], ignore_index=True); T['rule'] = T.rule.astype(str)
T = T[T.rule.isin(BUY) & (T.yr >= 2020)]
rows = []
for inst in ['fut', 'cfd']:
    X = np.load(f'/home/claude/bs/g/data_{inst}.npz'); c = X['c'].astype(float); cost = 5.0 if inst == 'fut' else 7.0
    B = []
    for r in BUY:
        g = T[(T.rule == r) & (T.inst == inst)]; k = seq_idx(g.i5.values, g.x5.values); B.append(g.iloc[k])
    B = pd.concat(B); bi = B.i5.values; bx = B.x5.values; bv = B.v.values.astype(float); byr = B.yr.values
    base_tot = bv.sum(); base_dd = dd_of(bx, bv)
    Z = np.load(f'/home/claude/bs/g/ss_{inst}_W.npz')
    for r in range(len(RU)):
        s = np.sort(Z['i'][Z['rule'] == r])
        if len(s) == 0: continue
        # 早めに手じまい
        k = np.searchsorted(s, bi, side='right'); nx = np.where(k < len(s), s[np.minimum(k, len(s) - 1)], 10**12)
        hit = nx < bx
        v2 = bv.copy(); v2[hit] = (c[nx[hit]] - c[bi[hit]]) * 68800.0 / c[bi[hit]] - cost; x2 = np.where(hit, nx, bx)
        # 見送り（4時間・1日）
        out = dict(市場=inst, ルール=RU.名前[r], 観点=RU.観点[r], 線を使う=RU.線を使う[r], 買いの回数=len(bv), 買いだけ合計=base_tot, 買いだけ最大DD=base_dd,
                   早め手じまい_回数=int(hit.sum()), 早め手じまい_合計=v2.sum(), 早め手じまい_最大DD=dd_of(x2, v2))
        for yy in range(2020, 2027): out[f'早め {yy}'] = v2[byr == yy].sum() - bv[byr == yy].sum()
        for W, lab in [(48, '4時間'), (288, '1日')]:
            k2 = np.searchsorted(s, bi, side='right') - 1; pv = np.where(k2 >= 0, s[np.maximum(k2, 0)], -10**12)
            skip = (bi - pv) <= W
            out[f'見送り{lab}_回数'] = int(skip.sum()); out[f'見送り{lab}_合計'] = bv[~skip].sum(); out[f'見送り{lab}_最大DD'] = dd_of(bx[~skip], bv[~skip]); out[f'見送り{lab}_見送った分の1回平均'] = bv[skip].mean() if skip.any() else np.nan
        rows.append(out)
R = pd.DataFrame(rows)
for p in ['早め手じまい', '見送り4時間', '見送り1日']:
    R[f'{p}_合計の差'] = R[f'{p}_合計'] - R.買いだけ合計; R[f'{p}_DDの減り(%)'] = 100 * (1 - R[f'{p}_最大DD'] / R.買いだけ最大DD)
R.to_pickle('/home/claude/bs/g/ss_riskoff.pkl')
W = R.pivot_table(index='ルール', columns='市場', values=['早め手じまい_合計の差', '早め手じまい_DDの減り(%)', '見送り1日_合計の差', '見送り1日_DDの減り(%)', '見送り4時間_合計の差', '見送り4時間_DDの減り(%)', '早め手じまい_回数'])
pd.set_option('display.width', 320); pd.set_option('display.max_rows', 100); pd.set_option('display.max_colwidth', 50)
print(W.round(0).sort_values(('早め手じまい_DDの減り(%)', 'fut'), ascending=False).to_string())
