"""k（15分足の網羅）の方向確認なしルールに、前の年で選んだ入る・避ける条件を当てはめる（ルールもランダムも同じ条件・同じ手じまい）"""
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from rs3b import with_conditions
DF = pd.read_csv('/home/claude/bs/g/kdefs.csv', index_col=0)
res = pickle.load(open('/home/claude/bs/g/rs3_k_res0.pkl', 'rb'))
res2 = {k: {inst: (v[0], v[1], v[2], v[3], v[5]) for inst, v in d.items()} for k, d in res.items()}
Dc = with_conditions(res2, lambda k: (f"k:{DF.trig[k[0]]}{'買' if DF.dir[k[0]] == 1 else '売'}", int(DF.dir[k[0]]), True), '/home/claude/bs/g/cond.pkl', lambda k: '15分足(網羅)')
Dc.to_pickle('/home/claude/bs/g/rs3_kc.pkl'); print(Dc.shape)
