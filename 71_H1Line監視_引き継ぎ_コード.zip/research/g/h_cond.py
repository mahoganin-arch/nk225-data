"""条件（印・曜日・時間・地合い・線の並び）の全体傾向。
グループ（線の種類×売買の向き）ごとに、条件の各値の1回平均（全設定をまとめる）から、その入り方全体の1回平均を引いた「上乗せ」を、
前半（2018〜22）・後半（2023〜26）、ミニ・CFD、本物・でたらめ（r0〜r5）で出す。
「線に特有」＝ 本物の上乗せ − でたらめの上乗せの平均。
出力：cond.pkl
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
DF = pd.read_csv('/home/claude/bs/g/hdefs.csv', index_col=0)
FE = pd.read_csv('/home/claude/bs/g/hfeats.csv')
H = {'前半': range(2018, 2023), '後半': range(2023, 2027)}

def one(inst, fam):
    cols = ['def', 'feat', 'val'] + [f'{c}{y}' for c in ['n', 'nrm'] for y in range(2018, 2027)]
    A = pd.read_parquet(f'/home/claude/bs/g/hagg_{inst}_{fam}.parquet', columns=cols)
    A['grp'] = DF.grp.values[A['def']]; A['kind'] = DF.kind.values[A['def']]; A['dir'] = DF.dir.values[A['def']]
    A['g2'] = np.where(A.grp == 'クロス', 'クロス', A.kind)
    out = []
    for hn, ys in H.items():
        A[f'n_{hn}'] = A[[f'n{y}' for y in ys]].sum(1); A[f'r_{hn}'] = A[[f'nrm{y}' for y in ys]].sum(1)
    S = A.groupby(['g2', 'dir', 'feat', 'val'])[[f'{p}_{h}' for p in 'nr' for h in H]].sum().reset_index()
    for hn in H:
        S[f'avg_{hn}'] = S[f'r_{hn}'] / S[f'n_{hn}']
        base = S[S.feat == 0].set_index(['g2', 'dir'])[f'avg_{hn}']
        S[f'up_{hn}'] = S[f'avg_{hn}'] - base.reindex(pd.MultiIndex.from_frame(S[['g2', 'dir']])).values
    S['inst'] = inst; S['fam'] = fam
    return S

if __name__ == '__main__':
    R = []
    for inst in ['fut', 'cfd']:
        for fam in ['W'] + [f'r{k}' for k in range(6)]:
            R.append(one(inst, fam)); print(inst, fam, flush=True)
    R = pd.concat(R).merge(FE, on=['feat', 'val'])
    R.to_pickle('/home/claude/bs/g/cond.pkl')
