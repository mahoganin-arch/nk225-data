"""上位足スイング検証の集計と評価。方向確認：なし＋15＋2つの組み合わせ105＝121。
出力：swagg_{tf}_{inst}_{fam}.npz、swrep_{tf}.pkl
"""
import sys, itertools, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from x_k import gadd
from x_eval2 import combos, nested
REF = 68800.0; COST = {'fut': 5.0, 'cfd': 7.0}; NB = 11; NF0 = 15
FSETS = [()] + [(a,) for a in range(NF0)] + list(itertools.combinations(range(NF0), 2))
MASKS = np.array([sum(1 << a for a in fs) for fs in FSETS], np.int64)
FAMS = ['W', 'r0', 'r1', 'r2', 'r3', 'r4']

def money(inst, S):
    sc = (REF / S['e'])[:, None]; fin = S['nt'] * (0.03 / 365 * REF) if inst == 'cfd' else 0.0
    R = S['R'].astype(float); return R * sc - COST[inst] - fin, R * sc - 13 - fin

def agg(tf, inst, fam):
    S = dict(np.load(f'/home/claude/bs/g/swsig_{tf}_{inst}_{fam}.npz')); Q = dict(np.load(f'/home/claude/bs/g/swrand_{tf}_{inst}_{fam}.npz'))
    NT = len(pd.read_csv(f'/home/claude/bs/g/sw_trigs_{tf}.csv')); G = NT * 2; NE = S['R'].shape[1]; NF = len(FSETS)
    nrm, n13 = money(inst, S); g = S['trig'].astype(np.int64) * 2 + (S['d'] > 0); yr = S['yr']; f = S['f'].astype(np.int64)
    cnt = np.zeros(G * NF * NB); s1 = np.zeros((G * NF * NB, NE)); s2 = np.zeros((G * NF * NB, NE))
    for k, msk in enumerate(MASKS):
        m = (f & msk) == msk
        for b in ((yr[m] >= 2023).astype(np.int64), yr[m] - 2018 + 2):
            kk = (g[m] * NF + k) * NB + b; cnt += np.bincount(kk, minlength=G * NF * NB); gadd(s1, kk, nrm[m]); gadd(s2, kk, n13[m])
    rn, r13 = money(inst, Q); ry = Q['yr']; cR = np.zeros(2 * NB); r1 = np.zeros((2 * NB, NE)); r2 = np.zeros((2 * NB, NE))
    for b in ((ry >= 2023).astype(np.int64), ry - 2018 + 2):
        kk = (Q['d'] > 0).astype(np.int64) * NB + b; cR += np.bincount(kk, minlength=2 * NB); gadd(r1, kk, rn); gadd(r2, kk, r13)
    return dict(cnt=cnt.reshape(G, NF, NB), nrm=s1.reshape(G, NF, NB, NE), n13=s2.reshape(G, NF, NB, NE), cntR=cR.reshape(2, NB), nrmR=r1.reshape(2, NB, NE), n13R=r2.reshape(2, NB, NE))

def report(tf, nmin=20):
    TR = pd.read_csv(f'/home/claude/bs/g/sw_trigs_{tf}.csv').iloc[:, 0].tolist(); EX = pd.read_csv(f'/home/claude/bs/g/sw_exits_{tf}.csv'); FL = pd.read_csv(f'/home/claude/bs/g/sw_filters_{tf}.csv').iloc[:, 0].tolist()
    FN = ['なし' if not fs else '＋'.join(FL[a] for a in fs) for fs in FSETS]
    Gn = [f"{t}{'買' if k == 1 else '売'}" for t in TR for k in (0, 1)]; dirs = np.array([1 if k == 1 else -1 for t in TR for k in (0, 1)])
    out = {}; rows = []; trig = []; nests = []
    for fam in FAMS:
        Zs = {i: agg(tf, i, fam) for i in ['fut', 'cfd']}
        C = combos(Zs, dirs, nmin=nmin); ok = C['ok']; both = (C['dmin'] > 0) & (C['amin'] > 0)
        rows.append(dict(線='本物' if fam == 'W' else f'でたらめ {fam}', 形の数=int(ok.sum()), 四つともランダムより良い=np.nanmean(np.where(ok, C['dmin'] > 0, np.nan)),
                         四つともプラス=np.nanmean(np.where(ok, C['amin'] > 0, np.nan)), 両方=np.nanmean(np.where(ok, both, np.nan))))
        pg = np.nanmean(np.where(ok, both, np.nan).reshape(len(Gn), -1), 1)
        trig.append(pd.DataFrame({'fam': fam, 'トリガー': Gn, '両方そろう割合': pg}))
        N, pk = nested(Zs, 2018, range(2020, 2027), dirs, nmin=nmin); N['fam'] = fam; nests.append(N)
        if fam == 'W':
            out['picks'] = pd.DataFrame([dict(年=t, 順位=r + 1, トリガー=Gn[g], 方向確認=FN[ff], 手じまい=EX.手じまい[e]) for t, v in pk.items() for r, (g, ff, e) in enumerate(v)])
            m = ok & both; g_, f_, e_ = np.nonzero(m); o = np.argsort(-C['amin'][m])[:300]
            out['top'] = pd.DataFrame({'トリガー': np.array(Gn)[g_[o]], '方向確認': np.array(FN)[f_[o]], '手じまい': EX.手じまい.values[e_[o]], '4つの平均の最小': C['amin'][m][o],
                                       'ランダムとの差の最小': C['dmin'][m][o], '4つの平均': C['amean'][m][o], '件数最小': C['nmin'][m][o]})
            # なし（方向確認なし）で、トリガーごとの一番良い手じまい
            a0 = np.where(ok[:, 0, :], C['amin'][:, 0, :], np.nan); d0 = np.where(ok[:, 0, :], C['dmin'][:, 0, :], np.nan)
            arg = np.nanargmax(np.nan_to_num(a0, nan=-1e18), 1)
            out['best'] = pd.DataFrame({'トリガー': Gn, '一番良い手じまい': EX.手じまい.values[arg], '4つの平均の最小': a0[np.arange(len(Gn)), arg], 'ランダムとの差の最小': d0[np.arange(len(Gn)), arg],
                                        '件数(ミニ+CFD 全期間)': [Zs['fut']['cnt'][gg, 0, 2:].sum() + Zs['cfd']['cnt'][gg, 0, 2:].sum() for gg in range(len(Gn))]})
            # 方向確認の効き目（1つずつ、なしと比べて4つとも改善した割合）
            Dd = C['D']; okk = ok
            fe = []
            for k in range(1, NF0 + 1):
                mm = okk[:, k, :] & okk[:, 0, :]
                imp = (Dd[:, :, k, :] > Dd[:, :, 0, :]).all(0)
                fe.append(dict(方向確認=FN[k], 四つとも改善した割合=imp[mm].mean() if mm.any() else np.nan, 数=int(mm.sum())))
            out['filt'] = pd.DataFrame(fe).sort_values('四つとも改善した割合', ascending=False)
            out['Z'] = Zs
    T = pd.concat(trig); W = T[T.fam == 'W'].set_index('トリガー'); Nn = T[T.fam != 'W'].groupby('トリガー').agg(でたらめ=('両方そろう割合', 'mean'), でたらめsd=('両方そろう割合', 'std'))
    J = W.join(Nn); J['頑丈さ(z)'] = (J['両方そろう割合'] - J['でたらめ']) / J['でたらめsd'].replace(0, np.nan)
    out['null'] = pd.DataFrame(rows); out['trig'] = J.drop(columns='fam').reset_index().sort_values('両方そろう割合', ascending=False)
    NS = pd.concat(nests); out['nest_year'] = NS
    out['nest'] = NS.groupby(['inst', 'fam'])[['上位5合計', '上位5合計13円', '上位5件数']].sum().join(NS.groupby(['inst', 'fam'])[['全部の平均', '順位相関']].mean()).reset_index()
    Zs = out.pop('Z')
    pd.to_pickle(out, f'/home/claude/bs/g/swrep_{tf}.pkl')
    pd.set_option('display.width', 250); pd.set_option('display.max_rows', 200)
    print('====', tf); print(out['null'].round(3).to_string()); print(out['nest'].round(0).to_string()); print(out['trig'].head(15).round(3).to_string()); print(out['filt'].head(8).round(3).to_string())

if __name__ == '__main__':
    for tf in sys.argv[1].split(','): report(tf)
