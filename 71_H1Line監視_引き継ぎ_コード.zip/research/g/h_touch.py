"""線で止まるか（利確・損切りの置き場所として使えるか）。
線に上から近づいて触れた（5分足の安値が線以下、1本前の終値は線より上）とき、
 その後、触れた値段から +X 戻るのが先か（反発）、線から −X 抜けるのが先か（突破）を数える。下からも同じ（向きを反転）。
X ＝ 0.1A・0.25A（A＝20日平均の日足値幅）。同じ線の触れは、前の触れから12本（60分）以上あけたものだけ。
期限：セッション終わり（どちらにも届かなければ「どちらでもない」）。
本物の線とでたらめな線の反発率を比べる。出力：touch_{inst}.pkl
"""
import sys, numpy as np, pandas as pd
from numba import njit
sys.path.insert(0, '/home/claude/bs/g')
from h_lines import NAMES, NL

@njit(cache=True)
def touches(o, h, l, c, Lv, A, endS, X, yr):
    n = len(o); out = np.zeros((n, 4), np.int64); k = 0; last = -100
    for i in range(1, n):
        Lp = Lv[i - 1]; a = A[i]
        if np.isnan(Lp) or not a > 0 or i - last < 12: continue
        d = 0
        if c[i - 1] > Lp and l[i] <= Lp: d = 1     # 上から触れた → 反発なら上へ
        elif c[i - 1] < Lp and h[i] >= Lp: d = -1  # 下から触れた → 反発なら下へ
        if d == 0: continue
        last = i
        up = Lp + d * X * a; dn = Lp - d * X * a; res = 0
        for j in range(i, endS[i] + 1):
            hitdn = (l[j] <= dn) if d == 1 else (h[j] >= dn)
            hitup = (h[j] >= up) if d == 1 else (l[j] <= up)
            if j == i: hitup = False  # 触れた足の中の順番は分からないので、触れた足では突破だけ数える
            if hitdn: res = 2; break
            if hitup: res = 1; break
        out[k, 0] = i; out[k, 1] = d; out[k, 2] = res; out[k, 3] = yr[i]; k += 1
    return out[:k]

def run(inst, fams):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz'))
    e = np.nonzero(X['end_ses'])[0]; endS = e[np.searchsorted(e, np.arange(len(X['o'])))]
    rows = []
    for fam in fams:
        L = np.load(f'/home/claude/bs/g/hl_{inst}_{fam}.npz')['L'].astype(np.float64)
        for li in range(NL):
            for x in (0.1, 0.25):
                T = touches(X['o'], X['h'], X['l'], X['c'], L[:, li], X['avg20'].astype(float), endS, x, X['yr'])
                for y in range(2018, 2027):
                    m = T[:, 3] == y
                    for d in (1, -1):
                        mm = m & (T[:, 1] == d)
                        rows.append(dict(inst=inst, fam=fam, line=NAMES[li], X=x, yr=y, side=d, n=int(mm.sum()),
                                         bounce=int((T[mm, 2] == 1).sum()), brk=int((T[mm, 2] == 2).sum())))
        print(inst, fam, flush=True)
    pd.DataFrame(rows).to_pickle(f'/home/claude/bs/g/touch_{inst}.pkl')

if __name__ == '__main__':
    run(sys.argv[1], sys.argv[2].split(','))
