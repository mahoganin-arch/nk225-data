"""合図ごとに条件を付け、入り方 × 決済 × 条件 × 年 の成績を集計する（分水嶺 g_agg と同じ形）。
コスト：
  net ＝ 実コスト（ミニ往復5pt・CFD往復7pt、CFDは7時をまたぐごとに金利調整額 年3%）
  nrm ＝ 今の値段にそろえた損益（pt×68,800÷入った値段）− 実コスト
  n13 ＝ 今の値段にそろえた損益 − 13（窓埋め・寄り天のコスト統一と同じ）
出力：hagg_{inst}_{fam}.parquet（合計 n≥20 だけ）、hfeats.csv
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs'); sys.path.insert(0, '/home/claude/bs/g')
import eng2, eng3
from h_lines import NAMES

COST = {'fut': 5.0, 'cfd': 7.0}
REF = 68800.0
YEARS = list(range(2018, 2027))
NY = len(YEARS)

def bins(x, edges):
    b = np.digitize(x, edges)
    return np.where(np.isnan(x), -1, b)

def pnl(inst, S):
    R = S['R'].astype(np.float64); cost = COST[inst]
    net = R - cost; nrm = R * (REF / S['e'])[:, None] - cost; n13 = R * (REF / S['e'])[:, None] - 13.0
    if inst == 'cfd':
        fin = S['nt'].astype(np.float64) * 0.03 / 365
        net = net - fin * S['e'][:, None]; nrm = nrm - fin * REF; n13 = n13 - fin * REF
    return net, nrm, n13

def features(inst, fam, X, S, DF, B, H):
    n = len(S['i']); i = S['i']; di = S['d']; e = S['e']
    dr = DF['dir'].values[di]; A = X['avg20'][i]
    L = H['L'][i].astype(float); sl = H['slope'][i].astype(int)
    # 分水嶺（本物）の週・日の線
    side = {}
    for j, key in enumerate(['wk', 'day']):
        P, ok = B[key]; Lp = eng3.per_lines(P, ok, 'W', inst, j); W = Lp.W.values[X['pid_' + key]][i]
        side[key] = np.where(np.isnan(W), -1, ((e - W) * dr > 0).astype(int))
    tf = DF['tf'].values[di]; pc = np.full(n, np.nan)
    for t in (5, 15, 30, 60):
        m = tf == t
        if not m.any(): continue
        if t == 5:
            pc[m] = X['c'][i[m] - 1]
        else:
            ch = np.nonzero(X[f'tf{t}'])[0]; k = np.searchsorted(ch, i[m]) - 1
            pc[m] = X['c'][ch[np.maximum(k, 0)]]
    h1, h4, d1 = L[:, 0], L[:, 1], L[:, 2]
    order = np.where(np.isnan(d1), -1, np.where((h1 - h4) * dr > 0, 1, 0) + np.where((h4 - d1) * dr > 0, 1, 0))
    def macdside(m):
        a = NAMES.index(f'macd {m}'); b = NAMES.index(f'signal {m}')
        v = (L[:, a] - L[:, b]) * dr
        return np.where(np.isnan(v), -1, (v > 0).astype(int))
    F = {}
    F['全体'] = (np.zeros(n, int), ['全体'])
    F['曜日'] = (X['wd'][i], ['月', '火', '水', '木', '金', '土'])
    F['時間'] = (X['hr'][i], [f'{h}時' for h in range(24)])
    F['曜日×時間'] = (X['wd'][i] * 24 + X['hr'][i], [f'{w} {h}時' for w in '月火水木金土' for h in range(24)])
    F['時間帯'] = (X['dayses'][i].astype(int), ['夜間', '日中'])
    for k, lab in [('sqw_major', 'SQ週（メジャー）'), ('sqw_minor', 'SQ週（ミニ）'), ('sq_day', 'SQ日'), ('hol_trade', '祝日の取引日'),
                   ('hol_before', '祝日の前日'), ('hol_after', '祝日の翌日'), ('month_end', '月末2日'), ('month_start', '月初2日')]:
        F[lab] = (X['mk_' + k][i].astype(int), ['以外', '該当'])
    F['寄りの窓（A比）'] = (bins(X['ses_gap'][i] * dr / A, [-0.25, -0.05, 0.05, 0.25]), ['逆向き 0.25超', '逆向き 0.05〜0.25', 'ほぼ無し', '同じ向き 0.05〜0.25', '同じ向き 0.25超'])
    F['前日の値幅÷20日平均'] = (bins(X['prevr'][i] / A, [0.6, 0.8, 1.0, 1.3]), ['0.6未満', '0.6〜0.8', '0.8〜1.0', '1.0〜1.3', '1.3以上'])
    F['20日平均からの乖離（向き付き%）'] = (bins((e - X['ma20'][i]) * dr / e * 100, [-2, -0.5, 0.5, 2]), ['−2%未満', '−2〜−0.5%', '±0.5%', '0.5〜2%', '2%以上'])
    F['日足RSI14'] = (bins(X['rsi_d'][i], [30, 50, 70]), ['30未満', '30〜50', '50〜70', '70以上'])
    F['勢い（A比）'] = (bins((e - pc) * dr / A, [0.0, 0.05, 0.1, 0.2]), ['逆向き', '0〜0.05', '0.05〜0.1', '0.1〜0.2', '0.2以上'])
    for k, nm in enumerate(['H1Line', 'H4Line', 'D1Line']):
        F[f'{nm}の傾き'] = (np.where(sl[:, k] == 0, -1, (sl[:, k] * dr > 0).astype(int)), ['逆向き', '同じ向き'])
    F['価格とD1Lineの側'] = (np.where(np.isnan(d1), -1, ((e - d1) * dr > 0).astype(int)), ['反対側', '同じ側'])
    F['価格とH4Lineの側'] = (np.where(np.isnan(h4), -1, ((e - h4) * dr > 0).astype(int)), ['反対側', '同じ側'])
    F['H系の並び（H1・H4・D1）'] = (order, ['逆の並び', '混ざる', '向きの並び'])
    F['MACD 1H-4H の向き'] = (macdside('1H-4H'), ['逆向き', '同じ向き'])
    F['MACD 4H-1D の向き'] = (macdside('4H-1D'), ['逆向き', '同じ向き'])
    F['MACD 1D-1W の向き'] = (macdside('1D-1W'), ['逆向き', '同じ向き'])
    F['週の分水嶺の側'] = (side['wk'], ['反対側', '同じ側'])
    F['日の分水嶺の側'] = (side['day'], ['反対側', '同じ側'])
    return F

def agg(inst, fam):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); S = dict(np.load(f'/home/claude/bs/g/hsig_{inst}_{fam}.npz'))
    H = dict(np.load(f'/home/claude/bs/g/hl_{inst}_{fam}.npz'))
    DF = pd.read_csv('/home/claude/bs/g/hdefs.csv', index_col=0); B = eng2.base(inst)
    F = features(inst, fam, X, S, DF, B, H); del H
    yr = X['yr'][S['i']]; yi = yr - YEARS[0]
    keepsig = (yi >= 0) & (yi < NY)
    for k in ['d', 'i', 'e', 'R', 'nt']: S[k] = S[k][keepsig]
    F = {k: (v[0][keepsig], v[1]) for k, v in F.items()}; yi = yi[keepsig]
    net, nrm, n13 = pnl(inst, S)
    blocks = []; meta = []
    fnames = list(F.keys())
    order = np.argsort(S['d'], kind='stable'); dsorted = S['d'][order]
    bounds = np.r_[0, np.nonzero(np.diff(dsorted))[0] + 1, len(dsorted)]
    for a, b in zip(bounds[:-1], bounds[1:]):
        idx = order[a:b]; di = int(S['d'][idx[0]])
        ny = net[idx]; nr = nrm[idx]; nq = n13[idx]; yy = yi[idx]
        valid = ~np.isnan(ny)
        for fi, fname in enumerate(fnames):
            code, labs = F[fname]; cd = code[idx]; k = len(labs); ok = cd >= 0
            key = np.where(ok, cd * NY + yy, -1)
            for col in range(48):
                v = ok & valid[:, col]
                if v.sum() < 20: continue
                kk = key[v]; x = ny[v, col]; z = nr[v, col]; w = nq[v, col]; K = k * NY
                cnt = np.bincount(kk, minlength=K).reshape(k, NY)
                keep = np.nonzero(cnt.sum(1) >= 20)[0]
                if len(keep) == 0: continue
                arr = [cnt, np.bincount(kk, x, K).reshape(k, NY), np.bincount(kk, z, K).reshape(k, NY), np.bincount(kk, w, K).reshape(k, NY),
                       np.bincount(kk, np.where(x > 0, x, 0), K).reshape(k, NY), np.bincount(kk, np.where(x < 0, -x, 0), K).reshape(k, NY),
                       np.bincount(kk, (x > 0).astype(float), K).reshape(k, NY)]
                blocks.append(np.concatenate([q[keep] for q in arr], 1).astype(np.float32))
                meta.append(np.stack([np.full(len(keep), di), np.full(len(keep), col), np.full(len(keep), fi), keep], 1).astype(np.int16))
    M = np.concatenate(blocks); Me = np.concatenate(meta)
    cols = [f'{s}{y}' for s in ['n', 'net', 'nrm', 'n13', 'pos', 'neg', 'win'] for y in YEARS]
    A = pd.DataFrame(M, columns=cols)
    for j, nm in enumerate(['def', 'exit', 'feat', 'val']): A.insert(j, nm, Me[:, j])
    A.to_parquet(f'/home/claude/bs/g/hagg_{inst}_{fam}.parquet')
    pd.DataFrame([(fi, fn, vi, lb) for fi, fn in enumerate(fnames) for vi, lb in enumerate(F[fn][1])], columns=['feat', 'feat_name', 'val', 'val_name']).to_csv('/home/claude/bs/g/hfeats.csv', index=False)
    print(inst, fam, len(A), flush=True)

if __name__ == '__main__':
    for fam in sys.argv[2].split(','):
        agg(sys.argv[1], fam)
