"""本命の形（H1Line の山・谷への押し目買い）の取り出しと確認。"""
import sys, numpy as np, pandas as pd
sys.path.insert(0,'/home/claude/bs/g')
import h_sig as G, h_agg
DF=pd.read_csv('/home/claude/bs/g/hdefs.csv',index_col=0)
def trades(inst,fam,line,kind,tf,b,ex,dr=1,oneday=False):
    X=np.load(f'/home/claude/bs/g/data_{inst}.npz'); S=np.load(f'/home/claude/bs/g/hsig_{inst}_{fam}.npz')
    d=DF[(DF.line==line)&(DF.kind==kind)&(DF.tf==tf)&(DF.b==b)&(DF.dir==dr)].index[0]
    m=S['d']==d; i=S['i'][m]
    PN=h_agg.pnl(inst,{'R':S['R'][m],'e':S['e'][m],'nt':S['nt'][m]})
    T=pd.DataFrame({'i':i,'e':S['e'][m],'pt':S['R'][m][:,ex],'net':PN[0][:,ex],'nrm':PN[1][:,ex],'n13':PN[2][:,ex]})
    T['t']=pd.to_datetime(X['tm'][i],unit='s',utc=True).tz_convert('Asia/Tokyo'); T['yr']=T.t.dt.year; T['day']=X['pid_day'][i]
    T=T[(T.yr>=2018)&T.net.notna()]
    if oneday: T=T.drop_duplicates('day')
    return T

def delayed(inst,fam,line,kind,tf,b,ex,dr=1):
    """入りを1本（5分）遅らせ、次の5分足の始値で入る。損切りの基準の線は合図の時の値。"""
    X=dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); S=np.load(f'/home/claude/bs/g/hsig_{inst}_{fam}.npz')
    H=np.load(f'/home/claude/bs/g/hl_{inst}_{fam}.npz')['L'].astype(float)
    from h_lines import NAMES
    d=DF[(DF.line==line)&(DF.kind==kind)&(DF.tf==tf)&(DF.b==b)&(DF.dir==dr)].index[0]
    m=S['d']==d; i=S['i'][m]
    o,h,l,c=X['o'],X['h'],X['l'],X['c']; n=len(o)
    eW=np.nonzero(X['end_wk'])[0]; endW=eW[np.searchsorted(eW,np.arange(n))]
    eS=np.nonzero(X['end_ses'])[0]; endS=eS[np.searchsorted(eS,np.arange(n))]
    ok=(i+1<n)&(endS[i]>i); i=i[ok]; si=i+1; se=o[si]
    Lr=H[i,NAMES.index(line)]; A=X['avg20'][i].astype(float)
    tpn=S['tpn'][m][ok]-S['e'][m][ok]+se
    R,XI=G.evalx(o,h,l,c,si,se,dr,Lr,A,tpn,endW,endS)
    nt=(X['pid_day'][XI]-X['pid_day'][si][:,None]).astype(np.int8)
    PN=h_agg.pnl(inst,{'R':R,'e':se,'nt':nt})
    T=pd.DataFrame({'i':si,'e':se,'pt':R[:,ex],'net':PN[0][:,ex],'nrm':PN[1][:,ex],'n13':PN[2][:,ex]})
    T['t']=pd.to_datetime(X['tm'][si],unit='s',utc=True).tz_convert('Asia/Tokyo'); T['yr']=T.t.dt.year
    return T[T.yr>=2018]
