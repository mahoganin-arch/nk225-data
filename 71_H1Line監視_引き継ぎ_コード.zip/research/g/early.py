import numpy as np, pandas as pd, sys
sys.path.insert(0,'/home/claude/bs/g')
from ss_cand import seq_idx
T=pd.concat([pd.read_pickle('tr2.pkl'),pd.read_pickle('tr_zt.pkl')],ignore_index=True); T['rule']=T.rule.astype(str); T=T[T.yr>=2018]
ALERT=['zt:H1Line 表側で届かずに切り返し（0.05A以内・触れず）買','zt:H1Line 谷の値に届かずに反発（0.1A以内・触れず）買','k:H1Line 山 反発0.1買','sw60:H4Lineの向き転換買','k:macd 15m-1H×signal 15m-1H 上順買','k:インジ5本 買い買','sw60:EMA48×H4Line買','k:PSAR 買い買','sw60:EMA12×EMA48買','k:H1Line×macd 15m-1H 下逆買']
rows=[]
for (rule,inst),g in T.groupby(['rule','inst']):
    if not rule.endswith('買'): continue
    for per,m in [('早',(g.yr<=2021)),('後',(g.yr>=2022))]:
        x=g[m]; k=seq_idx(x.i5.values,x.x5.values); v=x.v.values[k]; yrs=x.yr.values[k]
        rows.append(dict(rule=rule,inst=inst,per=per,n=len(v),avg=v.mean() if len(v) else np.nan,tot=v.sum(),pos=int((pd.Series(v).groupby(yrs).sum()>0).sum()) if len(v) else 0))
R=pd.DataFrame(rows).pivot_table(index='rule',columns=['per','inst'],values=['n','avg','tot','pos'])
R.columns=[f'{a}_{b}_{c}' for a,b,c in R.columns]; R=R.reset_index()
st=R.rule.str.split(':').str[0]; rnd={s:R[R.rule==f'rand:{s}:買'] for s in st.unique()}
for p in ['早','後']:
    for i in ['fut','cfd']:
        R[f'rand_{p}_{i}']=[rnd[s][f'avg_{p}_{i}'].values[0] if len(rnd[s]) else np.nan for s in st]
R=R[~R.rule.str.startswith('rand')]
sel=(R.tot_早_fut>0)&(R.tot_早_cfd>0)&(R.avg_早_fut>R.rand_早_fut)&(R.avg_早_cfd>R.rand_早_cfd)&(R.n_早_fut>=40)&(R.n_早_cfd>=40)&(R.pos_早_fut>=3)&(R.pos_早_cfd>=3)
R['早で選べた']=sel; R['アラート']=R.rule.isin(ALERT)
for lab,m in [('全部の買い',np.ones(len(R),bool)),('2018〜21で選べた',sel),('選べなかった',~sel),('アラートの10',R.アラート)]:
    x=R[m]; print(lab,len(x),'後の1回平均 ミニ',round(x.avg_後_fut.mean(),1),'ランダム',round(x.rand_後_fut.mean(),1),'CFD',round(x.avg_後_cfd.mean(),1),'ランダム',round(x.rand_後_cfd.mean(),1),
        '後でランダムより良い割合',round(((x.avg_後_fut>x.rand_後_fut)&(x.avg_後_cfd>x.rand_後_cfd)).mean(),2))
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',50)
print(R[R.アラート][['rule','早で選べた','n_早_fut','avg_早_fut','rand_早_fut','avg_早_cfd','rand_早_cfd','n_後_fut','avg_後_fut','rand_後_fut','avg_後_cfd','rand_後_cfd','pos_後_fut','pos_後_cfd']].round(0).to_string())
R.to_pickle('early.pkl')
