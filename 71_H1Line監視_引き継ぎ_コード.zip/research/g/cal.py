"""相場全体の特徴（暦・時間帯）と、買い・売りのルールへの効き目。
1) 相場全体：セッションごと・1時間ごとの値動き（始値→終値、A で割る）と値幅を、曜日・時間帯・月末月初・祝日・SQ・FOMC・月で分ける（ミニ・CFD、年ごと）。
2) ルール：アラートの買い10ルール（1つずつ・前向き）と、売り（H4Line裏タッチ系）の入りを同じ分け方で見る。ランダムな入りとも比べる。
3) 見送り：前の年までに「両商品・前後半ですべてマイナス」の分類を、次の年に見送る（前向き）。
出力：cal.pkl
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from ss_cand import BUY, seq_idx, dd_of
FOMC = """2018-01-31 2018-03-21 2018-05-02 2018-06-13 2018-08-01 2018-09-26 2018-11-08 2018-12-19
2019-01-30 2019-03-20 2019-05-01 2019-06-19 2019-07-31 2019-09-18 2019-10-30 2019-12-11
2020-01-29 2020-03-03 2020-03-15 2020-04-29 2020-06-10 2020-07-29 2020-09-16 2020-11-05 2020-12-16
2021-01-27 2021-03-17 2021-04-28 2021-06-16 2021-07-28 2021-09-22 2021-11-03 2021-12-15
2022-01-26 2022-03-16 2022-05-04 2022-06-15 2022-07-27 2022-09-21 2022-11-02 2022-12-14
2023-02-01 2023-03-22 2023-05-03 2023-06-14 2023-07-26 2023-09-20 2023-11-01 2023-12-13
2024-01-31 2024-03-20 2024-05-01 2024-06-12 2024-07-31 2024-09-18 2024-11-07 2024-12-18
2025-01-29 2025-03-19 2025-05-07 2025-06-18 2025-07-30 2025-09-17 2025-10-29 2025-12-10
2026-01-28 2026-03-18 2026-04-29 2026-06-17 2026-07-29 2026-09-16""".split()
FOMC = set(pd.to_datetime(FOMC).date)
WD = ['月', '火', '水', '木', '金']

def bar_feats(inst):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz'))
    t = pd.to_datetime(X['tm'], unit='s', utc=True).tz_convert('Asia/Tokyo'); n = len(t)
    pid = X['pid_day']; first = np.r_[True, pid[1:] != pid[:-1]]
    tdate = pd.Series(np.where(first, t.date, None)).ffill().values  # 取引日（日中の始まりの日付）
    tdate = pd.to_datetime(tdate).date
    td = pd.Series(sorted(set(tdate))); nxt = dict(zip(td, td.shift(-1))); prv = dict(zip(td, td.shift(1)))
    hm = (t.hour * 60 + t.minute).values
    F = {}
    F['曜日'] = np.array([WD[d.weekday()] if d.weekday() < 5 else '他' for d in tdate])
    zone = np.select([(hm >= 525) & (hm < 690), (hm >= 690) & (hm < 765), (hm >= 765) & (hm < 945), (hm >= 945) & (hm < 1320), (hm >= 1320) | (hm < 120), (hm >= 120) & (hm < 360)],
                     ['日中 前場（8:45〜11:30）', '昼（11:30〜12:45）', '日中 後場（12:45〜15:45）', '夜間 前半（15:45〜22:00）', '米国時間（22:00〜2:00）', '夜間 後半（2:00〜6:00）'], '早朝（6:00〜8:45）')
    F['時間帯'] = zone
    F['セッション'] = np.where(X['dayses'], '日中', '夜間')
    F['月'] = np.array([f'{d.month}月' for d in tdate])
    for k, lab in [('month_end', '月末2日'), ('month_start', '月初2日'), ('hol_before', '祝日の前日'), ('hol_after', '祝日の翌日（連休明け）'), ('hol_trade', '祝日の取引'),
                   ('sqw_major', 'SQ週（3・6・9・12月）'), ('sqw_minor', 'SQ週（その他の月）'), ('sq_day', 'SQの日')]:
        F[lab] = np.where(X['mk_' + k], 'はい', 'いいえ')
    sqd = set(np.array(tdate)[X['mk_sq_day'].astype(bool)])
    F['SQの前日'] = np.where([nxt.get(d) in sqd for d in tdate], 'はい', 'いいえ')
    F['FOMCの日（発表を含む夜間）'] = np.where([d in FOMC for d in tdate], 'はい', 'いいえ')
    F['FOMCの翌日'] = np.where([prv.get(d) in FOMC for d in tdate], 'はい', 'いいえ')
    F['FOMCの前日'] = np.where([nxt.get(d) in FOMC for d in tdate], 'はい', 'いいえ')
    F['3月・9月の月末（配当の権利）'] = np.where(X['mk_month_end'] & np.isin([d.month for d in tdate], [3, 9]), 'はい', 'いいえ')
    F['年末年始（12/24〜1/7）'] = np.where([(d.month == 12 and d.day >= 24) or (d.month == 1 and d.day <= 7) for d in tdate], 'はい', 'いいえ')
    F['お盆（8/10〜8/20）'] = np.where([d.month == 8 and 10 <= d.day <= 20 for d in tdate], 'はい', 'いいえ')
    F['月の中の位置'] = np.array(['上旬' if d.day <= 10 else ('中旬' if d.day <= 20 else '下旬') for d in tdate])
    return X, t, F

def market(inst, X, F):
    """セッションごとと1時間ごとの値動き（A で割る）"""
    A = X['avg20'].astype(float); o = X['o'].astype(float); c = X['c'].astype(float); h = X['h'].astype(float); l = X['l'].astype(float)
    out = {}
    for unit, key in [('セッション', X['pid_ses']), ('1時間', np.cumsum(np.r_[0, X['tf60'][:-1].astype(int)]))]:
        g = pd.DataFrame({'k': key, 'o': o, 'c': c, 'h': h, 'l': l, 'A': A, 'yr': X['yr'], 'i': np.arange(len(o))})
        a = g.groupby('k').agg(o=('o', 'first'), c=('c', 'last'), h=('h', 'max'), l=('l', 'min'), A=('A', 'first'), yr=('yr', 'first'), i=('i', 'first'))
        a = a[(a.yr >= 2018) & (a.A > 0)]
        a['ret'] = (a.c - a.o) / a.A; a['rng'] = (a.h - a.l) / a.A
        for f, v in F.items(): a[f] = v[a.i.values]
        out[unit] = a.reset_index(drop=True)
    return out

def summarize(M, unit):
    rows = []
    for f in [k for k in M['fut'][unit].columns if k not in ('o', 'c', 'h', 'l', 'A', 'yr', 'i', 'ret', 'rng')]:
        for val in sorted(set(M['fut'][unit][f]) | set(M['cfd'][unit][f])):
            row = dict(分け方=f, 値=val)
            for inst, L in [('fut', 'ミニ'), ('cfd', 'CFD')]:
                a = M[inst][unit]; base_r = a.ret.mean(); base_g = a.rng.mean(); m = a[f] == val; x = a[m]
                if len(x) < 10: continue
                ys = x.groupby('yr').ret.mean()
                row.update({f'{L} 回数': len(x), f'{L} 平均の動き(A)': x.ret.mean(), f'{L} 全体との差(A)': x.ret.mean() - base_r,
                            f'{L} t値': (x.ret.mean() - base_r) / (x.ret.std(ddof=1) / np.sqrt(len(x))) if len(x) > 2 else np.nan,
                            f'{L} 値幅（全体比）': x.rng.mean() / base_g, f'{L} 0.5A以上下げた割合': (x.ret <= -0.5).mean(), f'{L} 0.5A以上上げた割合': (x.ret >= 0.5).mean(),
                            f'{L} 上げた年': int((ys > 0).sum()), f'{L} 年の数': int(len(ys))})
            rows.append(row)
    return pd.DataFrame(rows)

def trades_table():
    T = pd.concat([pd.read_pickle('/home/claude/bs/g/tr2.pkl'), pd.read_pickle('/home/claude/bs/g/tr_zt.pkl'), pd.read_pickle('/home/claude/bs/g/tr_ss.pkl')], ignore_index=True)
    T['rule'] = T.rule.astype(str); return T

SELLS = ['zt:H4Line 裏タッチ 近さ0.15A（割れて4時間以内）売', 'zt:H4Line 割れて終値2本下に居続けた売', 'ss:E 下げ相場（D1Lineの下・D1Line下向き）で H4Line裏タッチ0.15A売']

def rule_sets(T):
    sets = {}
    for inst in ['fut', 'cfd']:
        B = []
        for r in BUY:
            g = T[(T.rule == r) & (T.inst == inst) & (T.yr >= 2018)]; B.append(g.iloc[seq_idx(g.i5.values, g.x5.values)])
        sets[('アラートの買い10ルール', inst)] = pd.concat(B)
        g = T[(T.rule == 'rand:k:買') & (T.inst == inst) & (T.yr >= 2018)]; sets[('ランダムな買い', inst)] = g
        for r in SELLS:
            g = T[(T.rule == r) & (T.inst == inst) & (T.yr >= 2018)]; sets[(r.split(':', 1)[1], inst)] = g.iloc[seq_idx(g.i5.values, g.x5.values)]
        g = T[(T.rule == 'rand:zt:売') & (T.inst == inst) & (T.yr >= 2018)]; sets[('ランダムな売り', inst)] = g
    return sets

def rule_effect(sets, FF):
    rows = []
    names = sorted(set(k[0] for k in sets), key=lambda s: list(dict.fromkeys(k[0] for k in sets)).index(s))
    for nm in names:
        for f in FF['fut']:
            vals = sorted(set(FF['fut'][f]) | set(FF['cfd'][f]))
            for val in vals:
                row = dict(対象=nm, 分け方=f, 値=val)
                for inst, L in [('fut', 'ミニ'), ('cfd', 'CFD')]:
                    g = sets[(nm, inst)]; g = g[g.yr >= 2020]; fv = FF[inst][f][g.i5.values]; m = fv == val; v = g.v.values.astype(float)
                    if m.sum() < 5: continue
                    ys = pd.Series(v[m]).groupby(g.yr.values[m]).sum()
                    row.update({f'{L} 回数': int(m.sum()), f'{L} 1回平均': v[m].mean(), f'{L} それ以外の1回平均': v[~m].mean() if (~m).any() else np.nan, f'{L} 合計': v[m].sum(),
                                f'{L} プラスの年': int((ys > 0).sum()), f'{L} 2020〜22 1回平均': v[m & (g.yr.values <= 2022)].mean(), f'{L} 2023〜26 1回平均': v[m & (g.yr.values >= 2023)].mean()})
                rows.append(row)
    return pd.DataFrame(rows)

def walk_skip(sets, FF, target):
    """前の年までのデータで「見送る分類」を選び、次の年に当てはめる"""
    flags = [(f, val) for f in FF['fut'] for val in sorted(set(FF['fut'][f]))]
    res = []; log = []
    G = {inst: sets[(target, inst)] for inst in ['fut', 'cfd']}
    FV = {inst: {f: FF[inst][f][G[inst].i5.values] for f in FF[inst]} for inst in ['fut', 'cfd']}
    for t in range(2020, 2027):
        picks = []
        for f, val in flags:
            ok = True; tot = 0; cnt = 0
            for inst in ['fut', 'cfd']:
                g = G[inst]; m = (FV[inst][f] == val); yr = g.yr.values; v = g.v.values.astype(float)
                tr = yr < t; ty = np.unique(yr[tr]); mid = ty[len(ty) // 2]
                for half in (yr < mid, yr >= mid):
                    mm = m & tr & half
                    if mm.sum() < 15 or v[mm].mean() >= 0 or v[mm].mean() >= v[tr & half].mean(): ok = False
                cnt += (m & tr).sum(); tot += (tr).sum()
            if ok and cnt <= 0.3 * tot: picks.append((f, val))
        log.append(dict(年=t, 見送る分類=' / '.join(f'{f}={v}' for f, v in picks)))
        for inst in ['fut', 'cfd']:
            g = G[inst]; yr = g.yr.values; v = g.v.values.astype(float); te = yr == t
            skip = np.zeros(len(g), bool)
            for f, val in picks: skip |= FV[inst][f] == val
            res.append(dict(年=t, 市場=inst, 回数=int(te.sum()), 合計=v[te].sum(), 見送った回数=int((te & skip).sum()), 見送った分の合計=v[te & skip].sum(), 見送り後の合計=v[te & ~skip].sum()))
    R = pd.DataFrame(res); L = pd.DataFrame(log)
    dd = {}
    for inst in ['fut', 'cfd']:
        g = G[inst]; yr = g.yr.values; v = g.v.values.astype(float); x = g.x5.values; keep = np.ones(len(g), bool)
        for t in range(2020, 2027):
            pk = L[L.年 == t].見送る分類.values[0]
            for s in [p for p in pk.split(' / ') if p]:
                f, val = s.rsplit('=', 1); keep[(yr == t) & (FV[inst][f] == val)] = False
        sel = yr >= 2020; dd[inst] = (dd_of(x[sel], v[sel]), dd_of(x[sel & keep], v[sel & keep]))
    return R, L, dd

def run():
    MK = {}; FF = {}
    for inst in ['fut', 'cfd']:
        X, t, F = bar_feats(inst); FF[inst] = F; MK[inst] = market(inst, X, F); print(inst, 'feats', flush=True)
    S_ses = summarize(MK, 'セッション'); S_hr = summarize(MK, '1時間')
    T = trades_table(); sets = rule_sets(T); E = rule_effect(sets, FF)
    WS = {}
    for tg in ['アラートの買い10ルール', 'ランダムな買い'] + [s.split(':', 1)[1] for s in SELLS]:
        WS[tg] = walk_skip(sets, FF, tg)
    # 年ごとの相場全体（セッション）
    YR = {inst: MK[inst]['セッション'].groupby(['yr', 'セッション']).ret.agg(['mean', 'count']).unstack() for inst in ['fut', 'cfd']}
    pd.to_pickle(dict(ses=S_ses, hr=S_hr, eff=E, ws=WS, yr=YR), '/home/claude/bs/g/cal.pkl')
    pd.set_option('display.width', 330); pd.set_option('display.max_rows', 300); pd.set_option('display.max_colwidth', 40)
    c = ['分け方', '値', 'ミニ 回数', 'ミニ 平均の動き(A)', 'ミニ t値', 'ミニ 値幅（全体比）', 'ミニ 上げた年', 'CFD 回数', 'CFD 平均の動き(A)', 'CFD t値', 'CFD 値幅（全体比）', 'CFD 上げた年']
    print(S_ses[c].round(3).to_string())
    for tg, (R, L, dd) in WS.items():
        print('==', tg, dd); print(L.to_string()); print(R.groupby('市場')[['合計', '見送った分の合計', '見送り後の合計']].sum().round(0))

if __name__ == '__main__':
    run()
