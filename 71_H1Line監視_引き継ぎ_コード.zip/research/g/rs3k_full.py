import sys, pickle; sys.path.insert(0,'/home/claude/bs/g')
from rs3 import study_k
D,res=study_k(); pickle.dump(res,open('/home/claude/bs/g/rs3_k_resall.pkl','wb')); print('saved',len(res))
