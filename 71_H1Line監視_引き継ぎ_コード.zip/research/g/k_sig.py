"""組み合わせ戦略の全格子の売買（15分足の確定で判定、5分足で手じまいを追う）。
入り方（トリガー）：
  線21本 × [近づいて反発（近さ 0.05・0.1・0.15・0.25A）、抜け] × 向き2
  傾きの転換（陽転・陰転）：H系3本・macd5本・signal5本 × 向き2（陽転で買い・陰転で売り）
  線どうしのクロス 10組 × クロスの向き2 × 売買の向き2（順・逆）
  インジ：速ストキャス k×d、遅ストキャス k×d、Indi01〜06 が全部同じ色になった、6本中5本、PSAR 反転、Indi02〜06（MACD5本）が全部同じ向きになった × 向き2
1つのトリガーは1セッションに最初の合図だけ。合図の時の「方向確認の状態」（17種）をビットで記録。
手じまい36通り：規則12（60分・240分・セッション終わり・週の終わり・速ストキャス逆クロス・遅ストキャス逆クロス・インジ5本逆・PSAR反転・
  15m-1H 逆クロス・H1Line 傾き反転・次の線・2本目の線）× 損切り3（なし・線の0.25A先・入った値段から0.5A）。
出力：ksig_{inst}_{fam}.npz、kdefs.csv、kfilters.csv
"""
import sys, numpy as np, pandas as pd, itertools
from numba import njit
sys.path.insert(0, '/home/claude/bs'); sys.path.insert(0, '/home/claude/bs/g')
import g_sig as G

LN = pd.read_csv('/home/claude/bs/g/k_lnames.csv').iloc[:, 0].tolist(); IN = pd.read_csv('/home/claude/bs/g/k_inames.csv').iloc[:, 0].tolist()
NL = len(LN)
PAIRS = [('H1Line', 'H4Line'), ('H4Line', 'D1Line'), ('H1Line', 'D1Line'), ('H1Line', 'macd 15m-1H'), ('H1Line', 'signal 15m-1H')] + \
        [(f'macd {m}', f'signal {m}') for m in ['15m-1H', '1H-4H', '4H-1D', '1D-1W', '週足']]
SLOPED = LN[:13]
RULES = ['60分', '240分', 'セッション終わり', '週の終わり', '速ストキャス逆クロス', '遅ストキャス逆クロス', 'インジ5本逆', 'PSAR反転', '15m-1H逆クロス', 'H1Line傾き反転', '次の線', '2本目の線']
SLS = ['なし', '線の0.25A先', '0.5A']
FILTERS = ['速ストキャス向き', '遅ストキャス向き', '速ストキャス低位', '遅ストキャス低位', 'インジ6本そろう', 'インジ5本以上', 'MACD5本そろう', 'PSAR向き',
           '15m-1H陽転', '1H-4H陽転', '15m-1H傾き', 'H1Line傾き', 'H系の並び', 'D1Lineの側', '近くに支え', '先が空いている', 'Indi01向き']

def defs():
    rows = []
    for li, kind, dr in itertools.product(range(NL), ['反発0.05', '反発0.1', '反発0.15', '反発0.25', '抜け'], (1, -1)):
        rows.append(dict(trig=f'{LN[li]} {kind}', grp='線', line=LN[li], kind=kind, dir=dr, a=li, b=-1, cd=0))
    for nm, dr in itertools.product(SLOPED, (1, -1)):
        rows.append(dict(trig=f'{nm} {"陽転" if dr == 1 else "陰転"}', grp='傾きの転換', line=nm, kind='陽転' if dr == 1 else '陰転', dir=dr, a=LN.index(nm), b=-1, cd=0))
    for (fa, sl), cd, dr in itertools.product(PAIRS, (1, -1), (1, -1)):
        rows.append(dict(trig=f'{fa}×{sl} {"上" if cd == 1 else "下"}{"順" if cd == dr else "逆"}', grp='クロス', line=f'{fa}×{sl}', kind=('上' if cd == 1 else '下') + ('順' if cd == dr else '逆'),
                         dir=dr, a=LN.index(fa), b=LN.index(sl), cd=cd))
    for nm, dr in itertools.product(['速ストキャス', '遅ストキャス', 'インジ6本', 'インジ5本', 'PSAR', 'MACD5本'], (1, -1)):
        rows.append(dict(trig=f'{nm} {"買い" if dr == 1 else "売り"}', grp='インジ', line=nm, kind=nm, dir=dr, a=-1, b=-1, cd=0))
    return pd.DataFrame(rows)

def ind_states(I):
    fk, fd, sk, sd, i1 = I[:, 0], I[:, 1], I[:, 2], I[:, 3], I[:, 4]
    rise = I[:, 5:10]; ps = I[:, 10]
    c1 = np.where(i1 >= 60, 1, np.where(i1 <= 40, -1, 0))
    cnt = c1 + np.nansum(rise, 1)  # -6..6
    return fk, fd, sk, sd, c1, rise, ps, cnt

@njit(cache=True)
def gen(c, h, l, pid, is15, kind, dr, Lv, L2, A, cd, trig_arr, pend):
    """kind 0..3 反発(b=0.05,0.1,0.15,0.25) 4 抜け 5 傾き転換 6 クロス 7 インジ（trig_arr：その足で合図が出たか）"""
    n = len(c); out = np.empty(n, np.int64); k = 0; lastp = -1
    bands = np.array([0.05, 0.1, 0.15, 0.25])
    pc = np.nan; pL = np.nan; pdf = np.nan; lo = np.inf; hi = -np.inf; ps = 0.0; pps = 0.0
    for i in range(n):
        lo = min(lo, l[i]); hi = max(hi, h[i])
        if not is15[i]: continue
        p = pid[i]; a = A[i]; L = Lv[i]
        ok = p != lastp and not pend[i] and a > 0
        hit = False
        if kind <= 3:
            b = bands[kind] * a
            if ok and not np.isnan(L) and not np.isnan(pL) and not np.isnan(pc):
                if dr == 1: hit = pc > pL + b and lo <= L + b and c[i] > L
                else: hit = pc < pL - b and hi >= L - b and c[i] < L
        elif kind == 4:
            if ok and not np.isnan(L) and not np.isnan(pL) and not np.isnan(pc):
                hit = (pc < pL and c[i] >= L) if dr == 1 else (pc > pL and c[i] <= L)
        elif kind == 5:
            s = 0.0
            if not np.isnan(L) and not np.isnan(pL): s = 1.0 if L > pL else (-1.0 if L < pL else ps)
            if ok and s != 0 and ps != 0: hit = (s == dr and ps == -dr)
            ps = s
        elif kind == 6:
            df = Lv[i] - L2[i]
            if ok and not np.isnan(df) and not np.isnan(pdf):
                hit = (cd == 1 and pdf <= 0 and df > 0) or (cd == -1 and pdf >= 0 and df < 0)
            pdf = df
        else:
            hit = ok and trig_arr[i]
        if hit:
            out[k] = i; k += 1; lastp = p
        pc = c[i]; pL = L; lo = np.inf; hi = -np.inf
    return out[:k]

@njit(cache=True)
def nxt(ev):
    """ev: (n,) bool → その足より後で最初に ev が立つ位置（無ければ n）"""
    n = len(ev); out = np.empty(n, np.int64); j = n
    for i in range(n - 1, -1, -1):
        out[i] = j
        if ev[i]: j = i
    return out

@njit(cache=True)
def evalx(o, h, l, c, si, dr, Lr, A, tp1, tp2, endW, endS, NX):
    """NX: (6, n) 逆側のイベント（速ストキャス・遅ストキャス・インジ5本・PSAR・15m-1H・H1Line）の次の位置（この向き用）"""
    m = len(si); R = np.full((m, 36), np.nan, np.float32); XI = np.zeros((m, 36), np.int32)
    for q in range(m):
        i = si[q]; e = c[i]; d = dr; jW = endW[i]; jS = min(endS[i], jW)
        tend = np.empty(12, np.int64)
        tend[0] = min(i + 12, jS); tend[1] = min(i + 48, jW); tend[2] = jS; tend[3] = jW
        for k in range(6): tend[4 + k] = min(NX[k, i], jW)
        tend[10] = jS; tend[11] = jS
        tps = np.array([tp1[q], tp2[q]])
        sl = np.empty(2); sl[0] = Lr[q] - d * 0.25 * A[q]; sl[1] = e - d * 0.5 * A[q]
        sli = np.full(2, -1, np.int64); slx = np.zeros(2); tpi = np.full(2, -1, np.int64); tpx = np.zeros(2)
        jmax = tend.max()
        for j in range(i + 1, jmax + 1):
            for a in range(2):
                if sli[a] < 0 and ((d == 1 and l[j] <= sl[a]) or (d == -1 and h[j] >= sl[a])):
                    sli[a] = j; slx[a] = min(o[j], sl[a]) if d == 1 else max(o[j], sl[a])
                if tpi[a] < 0 and not np.isnan(tps[a]) and ((d == 1 and h[j] >= tps[a]) or (d == -1 and l[j] <= tps[a])):
                    tpi[a] = j; tpx[a] = max(o[j], tps[a]) if d == 1 else min(o[j], tps[a])
        col = 0
        for r in range(12):
            for s in range(3):
                te = tend[r]; x = c[te]; xi = te
                if r >= 10:
                    a = r - 10
                    if tpi[a] >= 0 and tpi[a] <= te: xi = tpi[a]; x = tpx[a]
                if s >= 1 and sli[s - 1] >= 0 and sli[s - 1] <= xi:
                    xi = sli[s - 1]; x = slx[s - 1]
                R[q, col] = d * (x - e); XI[q, col] = xi; col += 1
    return R, XI

def run(inst, fam, rand=None):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); K = np.load(f'/home/claude/bs/g/kind_{inst}_{fam}.npz')
    KW = np.load(f'/home/claude/bs/g/kind_{inst}_W.npz')
    LM = K['L'].astype(np.float64); I = KW['I'].astype(np.float64); is15 = K['is15']
    DF = defs()
    if rand is None:
        DF.to_csv('/home/claude/bs/g/kdefs.csv', index_label='def'); pd.Series(FILTERS).to_csv('/home/claude/bs/g/kfilters.csv', index=False)
    else:
        DF = pd.DataFrame([dict(trig=f'ランダム{sd}', grp='ランダム', line='R', kind='R', dir=dr, a=-1, b=-1, cd=0) for sd, dr, _ in rand])
    o, h, l, c = X['o'], X['h'], X['l'], X['c']; n = len(o); A = X['avg20'].astype(float)
    pid = X['pid_ses']; pend = X['end_ses']
    eW = np.nonzero(X['end_wk'])[0]; endW = eW[np.searchsorted(eW, np.arange(n))]
    eS = np.nonzero(X['end_ses'])[0]; endS = eS[np.searchsorted(eS, np.arange(n))]
    fk, fd, sk, sd, c1, rise, ps, cnt = ind_states(I)
    def cross(a, b):
        s = np.sign(a - b); s[~is15] = np.nan
        s = pd.Series(s).ffill().values; ps_ = np.r_[np.nan, s[:-1]]
        up = is15 & (s > 0) & (ps_ <= 0); dn = is15 & (s < 0) & (ps_ >= 0)
        return up, dn
    def onset(cond):
        cc = cond.astype(float); cc[~is15] = np.nan; cc = pd.Series(cc).ffill().fillna(0).values
        pc = np.r_[0, cc[:-1]]; return is15 & (cc > 0) & (pc == 0)
    fup, fdn = cross(fk, fd); sup, sdn = cross(sk, sd)
    allr = (c1 == 1) & np.all(rise > 0, 1); allb = (c1 == -1) & np.all(rise < 0, 1)
    TRIG = {('速ストキャス', 1): fup, ('速ストキャス', -1): fdn, ('遅ストキャス', 1): sup, ('遅ストキャス', -1): sdn,
            ('インジ6本', 1): onset(allr), ('インジ6本', -1): onset(allb), ('インジ5本', 1): onset(cnt >= 5), ('インジ5本', -1): onset(cnt <= -5),
            ('PSAR', 1): onset(ps > 0), ('PSAR', -1): onset(ps < 0), ('MACD5本', 1): onset(np.all(rise > 0, 1)), ('MACD5本', -1): onset(np.all(rise < 0, 1))}
    m1a, m1b = LM[:, LN.index('macd 15m-1H')], LM[:, LN.index('signal 15m-1H')]
    m4a, m4b = LM[:, LN.index('macd 1H-4H')], LM[:, LN.index('signal 1H-4H')]
    up1, dn1 = cross(m1a, m1b)
    h1s = np.sign(np.diff(LM[:, 0], prepend=np.nan)); h1s[~is15] = np.nan; h1s = pd.Series(h1s).replace(0, np.nan).ffill().values
    ph1 = np.r_[np.nan, h1s[:-1]]
    h1up = is15 & (h1s > 0) & (ph1 < 0); h1dn = is15 & (h1s < 0) & (ph1 > 0)
    # 手じまいのイベント（買い用＝下向きのイベント、売り用＝上向き）
    ev_long = [fdn, sdn, is15 & (cnt <= -5 + 0), onset(ps < 0), dn1, h1dn]
    ev_short = [fup, sup, is15 & (cnt >= 5), onset(ps > 0), up1, h1up]
    ev_long[2] = is15 & (cnt <= -4); ev_short[2] = is15 & (cnt >= 4)  # 6本中5本が逆色（逆5本＝合計 −4 以下）
    NXL = np.stack([nxt(e) for e in ev_long]); NXS = np.stack([nxt(e) for e in ev_short])
    # 方向確認の状態（買い向き=+1 の時の値。売りは反転）
    hs = lambda k: IN.index(k)
    st = {}
    st['速ストキャス向き'] = np.sign(fk - fd); st['遅ストキャス向き'] = np.sign(sk - sd)
    st['速ストキャス低位'] = np.where(fk < 30, 1, np.where(fk > 70, -1, 0)); st['遅ストキャス低位'] = np.where(sk < 50, 1, -1)
    st['インジ6本そろう'] = np.where(allr, 1, np.where(allb, -1, 0)); st['インジ5本以上'] = np.where(cnt >= 4, 1, np.where(cnt <= -4, -1, 0))
    st['MACD5本そろう'] = np.where(np.all(rise > 0, 1), 1, np.where(np.all(rise < 0, 1), -1, 0)); st['PSAR向き'] = ps
    st['15m-1H陽転'] = np.sign(m1a - m1b); st['1H-4H陽転'] = np.sign(m4a - m4b)
    st['15m-1H傾き'] = I[:, hs('macd 15m-1H 傾き')]; st['H1Line傾き'] = I[:, hs('H1Line 傾き')]
    h1, h4, d1 = LM[:, 0], LM[:, 1], LM[:, 2]
    st['H系の並び'] = np.where((h1 > h4) & (h4 > d1), 1, np.where((h1 < h4) & (h4 < d1), -1, 0)); st['D1Lineの側'] = np.sign(c - d1)
    st['Indi01向き'] = c1.astype(float)
    S_def = []; S_i = []; S_R = []; S_nt = []; S_f = []
    for di, r in DF.iterrows():
        dr = int(r.dir)
        if r.grp == '線': kind = ['反発0.05', '反発0.1', '反発0.15', '反発0.25', '抜け'].index(r.kind)
        elif r.grp == '傾きの転換': kind = 5
        elif r.grp == 'クロス': kind = 6
        else: kind = 7
        Lv = LM[:, int(r.a)] if r.a >= 0 else c.astype(float); L2 = LM[:, int(r.b)] if r.b >= 0 else Lv
        ta = rand[di][2] if rand is not None else (TRIG[(r.line, dr)] if kind == 7 else np.zeros(n, bool))
        si = gen(c, h, l, pid, is15, kind, dr, Lv, L2, A, int(r.cd), ta, pend)
        si = si[X['yr'][si] >= 2018]
        if len(si) == 0: continue
        e = c[si]; Ai = A[si]; Lr = Lv[si] if kind <= 4 else e.copy()
        M = LM[si]; dist = (M - e[:, None]) * dr
        dd = np.where(dist > 0.05 * Ai[:, None], dist, np.inf); dd.sort(1)
        tp1 = np.where(np.isfinite(dd[:, 0]), e + dr * dd[:, 0], np.nan); tp2 = np.where(np.isfinite(dd[:, 1]), e + dr * dd[:, 1], np.nan)
        R, XI = evalx(o, h, l, c, si, dr, Lr, Ai, tp1, tp2, endW, endS, NXL if dr == 1 else NXS)
        nts = (X['pid_day'][XI] - X['pid_day'][si][:, None]).astype(np.int8)
        # 状態ビット
        bits = np.zeros(len(si), np.int32)
        for fi, fn in enumerate(FILTERS):
            if fn == '近くに支え':
                v = (np.where(dist < 0, -dist, np.inf) <= 0.15 * Ai[:, None]).any(1)
            elif fn == '先が空いている':
                v = ~((dist > 0) & (dist <= 0.25 * Ai[:, None])).any(1)
            else:
                v = st[fn][si] * dr > 0
            bits |= (v.astype(np.int32) << fi)
        S_def.append(np.full(len(si), di, np.int32)); S_i.append(si); S_R.append(R); S_nt.append(nts); S_f.append(bits)
    np.savez(f'/home/claude/bs/g/ksig_{inst}_{fam}.npz' if rand is None else f'/home/claude/bs/g/krand_{inst}.npz', d=np.concatenate(S_def), i=np.concatenate(S_i), e=c[np.concatenate(S_i)],
             R=np.concatenate(S_R), nt=np.concatenate(S_nt), f=np.concatenate(S_f))
    print(inst, fam, sum(len(x) for x in S_i), flush=True)

if __name__ == '__main__':
    run(sys.argv[1], sys.argv[2])
