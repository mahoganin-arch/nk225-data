"""セオリーのルールの評価：手じまい225通り＋運用の手じまい3つ（上げ波の売りは1Hストキャスが上を向いたら逃げる／次の線で半分利確・残りは1Hストキャスが逆を向くまで／MACDの線を目標）。
でたらめな線（3組）と比べる頑丈さ、前向き（手じまいは前の年で選ぶ）、1つずつ持つ、ランダムな入りと比べる。
出力：zt_eval.pkl
"""
import sys, numpy as np, pandas as pd
from numba import njit
sys.path.insert(0, '/home/claude/bs/g')
from x_core import ctx5, simulate, money, NE, LN
from zt_rules import up_stoch
from x_eval2 import combos
RLc = pd.read_csv('/home/claude/bs/g/xlib_rules.csv').手じまい.tolist()
EXTRA = ['上げ波の売りは早逃げ（1Hストキャスが逆を向いたら）', '次の線で半分利確・残りは1Hストキャスが逆を向くまで', 'MACDの線（4H-1D・1D-1W・週足）で利確', '1Hストキャスが逆を向いたら（損切り 線の0.25A先）']
ALLX = RLc + EXTRA; NX_ = len(ALLX); YRS = list(range(2018, 2027))
RU = pd.read_csv('/home/claude/bs/g/zt_rules.csv')

@njit(cache=True)
def extra(SI, D, E, A, LR, TP1, TPM, o, h, l, c, endW, NX1, R):
    for q in range(len(SI)):
        i = SI[q]; d = D[q]; e = E[q]; a = A[q]; end = endW[i]; t1 = min(NX1[i], end)
        # 0：1Hストキャスが逆を向いたら（損切りなし）
        R[q, 0] = (c[t1] - e) * d
        # 1：次の線で半分、残りは t1
        half = np.nan
        for j in range(i + 1, t1 + 1):
            if not np.isnan(TP1[q]) and ((d == 1 and h[j] >= TP1[q]) or (d == -1 and l[j] <= TP1[q])):
                half = (max(o[j], TP1[q]) - e) if d == 1 else (e - min(o[j], TP1[q])); break
        R[q, 1] = 0.5 * (half if not np.isnan(half) else (c[t1] - e) * d) + 0.5 * (c[t1] - e) * d
        # 2：MACD の線で利確（週の終わりまで）
        x = (c[end] - e) * d
        for j in range(i + 1, end + 1):
            if not np.isnan(TPM[q]) and ((d == 1 and h[j] >= TPM[q]) or (d == -1 and l[j] <= TPM[q])):
                x = (max(o[j], TPM[q]) - e) if d == 1 else (e - min(o[j], TPM[q])); break
        R[q, 2] = x
        # 3：t1 まで、損切り 線の0.25A先
        sl = LR[q] - d * 0.25 * a; x = (c[t1] - e) * d
        for j in range(i + 1, t1 + 1):
            if (d == 1 and l[j] <= sl) or (d == -1 and h[j] >= sl):
                x = ((min(o[j], sl) - e) if d == 1 else (e - max(o[j], sl))); break
        R[q, 3] = x

def nxt(ev):
    n = len(ev); idx = np.nonzero(ev)[0]; k = np.searchsorted(idx, np.arange(n), side='right')
    out = np.full(n, n - 1, np.int64); ok = k < len(idx); out[ok] = idx[k[ok]]; return out

def pnl_all(inst, fam, SI, D, LR, C=None):
    C = C or ctx5(inst, fam)
    if len(SI) > 60000:
        parts = [pnl_all(inst, fam, SI[a:a + 60000], D[a:a + 60000], LR[a:a + 60000], C)[:2] for a in range(0, len(SI), 60000)]
        return np.concatenate([p[0] for p in parts]), np.concatenate([p[1] for p in parts]), C
    R, NT, HB = simulate(C, SI, D, LR); nrm, _ = money(inst, R, C['c'][SI], NT)
    X5 = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); S1 = up_stoch(inst, '60', X5['tm'] + 300)
    s = np.sign(np.nan_to_num(S1['fk'] - S1['fd'])); p = np.r_[0, s[:-1]]
    NXd = {1: nxt((s < 0) & (p >= 0)), -1: nxt((s > 0) & (p <= 0))}
    E = C['c'][SI]; A = C['A'][SI]; M = C['LM'][SI]; dist = (M - E[:, None]) * D[:, None]; dd = np.where(dist > 0.05 * A[:, None], dist, np.inf); dd.sort(1)
    TP1 = np.where(np.isfinite(dd[:, 0]), E + D * dd[:, 0], np.nan)
    mi = [LN.index(k) for k in ['macd 4H-1D', 'macd 1D-1W', 'macd 週足', 'signal 4H-1D', 'signal 1D-1W', 'signal 週足']]
    dm = np.where(dist[:, mi] > 0.05 * A[:, None], dist[:, mi], np.inf).min(1); TPM = np.where(np.isfinite(dm), E + D * dm, np.nan)
    RX = np.zeros((len(SI), 4)); endW = C['ends'][2]
    for dr in (1, -1):
        m = D == dr
        if m.any():
            r_ = np.zeros((m.sum(), 4)); extra(SI[m], D[m], E[m], A[m], LR[m], TP1[m], TPM[m], C['o'], C['h'], C['l'], C['c'], endW, NXd[dr], r_); RX[m] = r_
    sc = 68800.0 / E; cost = 5.0 if inst == 'fut' else 7.0
    xi = np.minimum(SI + HB.max(1), len(C['c']) - 1)
    fin = (C['pid_day'][np.minimum(SI + 1440, len(C['c']) - 1)] - C['pid_day'][SI]) * 0  # 追加の手じまいの金利は小さいので省く（週まで）
    nx = RX * sc[:, None] - cost
    V = np.concatenate([nrm.astype(np.float32), nx.astype(np.float32)], 1); del nrm, R
    XO = np.concatenate([(SI[:, None] + HB).astype(np.int32), np.repeat(np.minimum(np.where(D == 1, NXd[1][SI], NXd[-1][SI]), endW[SI])[:, None], 4, 1).astype(np.int32)], 1)
    return V, XO, C

def run():
    out = {}; AGG = {}
    for inst in ['fut', 'cfd']:
        for fam in ['W', 'r0', 'r1', 'r2']:
            Z = dict(np.load(f'/home/claude/bs/g/zt_{inst}_{fam}.npz')); SI = Z['i'].astype(np.int64); D = Z['d'].astype(np.int64); LR = Z['lr'].astype(float)
            V, XO, C = pnl_all(inst, fam, SI, D, LR); yr = C['yr'][SI]; rr = Z['rule']
            nR = len(RU); cnt = np.zeros((nR, 1, 2 + len(YRS))); s = np.zeros((nR, 1, 2 + len(YRS), NX_))
            for b, key in [(0, yr <= 2022), (1, yr >= 2023)]:
                np.add.at(cnt[:, 0, b], rr[key], 1); np.add.at(s[:, 0, b], rr[key], V[key])
            for k, y in enumerate(YRS):
                m = yr == y; np.add.at(cnt[:, 0, 2 + k], rr[m], 1); np.add.at(s[:, 0, 2 + k], rr[m], V[m])
            # ランダム
            rng = np.random.default_rng(11 + (inst == 'cfd'))
            ok = np.nonzero(C['is15'] & (C['yr'] >= 2018) & (np.arange(len(C['c'])) < C['ends'][0]) & ~np.isnan(C['A']))[0]
            ri = np.sort(rng.choice(ok, 15000, replace=False)); RI = np.r_[ri, ri]; RD = np.r_[np.ones(15000, np.int64), -np.ones(15000, np.int64)]
            VR, XR, _ = pnl_all(inst, fam, RI, RD, C['c'][RI].astype(float), C); ry = C['yr'][RI]
            cR = np.zeros((2, 2 + len(YRS))); sR = np.zeros((2, 2 + len(YRS), NX_)); di = (RD > 0).astype(int)
            for b, key in [(0, ry <= 2022), (1, ry >= 2023)]:
                np.add.at(cR[:, b], di[key], 1); np.add.at(sR[:, b], di[key], VR[key])
            for k, y in enumerate(YRS):
                m = ry == y; np.add.at(cR[:, 2 + k], di[m], 1); np.add.at(sR[:, 2 + k], di[m], VR[m])
            AGG[(inst, fam)] = dict(cnt=cnt, nrm=s, n13=s, cntR=cR, nrmR=sR, n13R=sR)
            if fam == 'W':
                out[inst] = dict(SI=SI, D=D, rule=rr, yr=yr, V=V.astype(np.float32), XO=XO, RI=RI, RD=RD, ry=ry, VR=VR.astype(np.float32), XR=XR)
            print(inst, fam, flush=True)
    pd.to_pickle(dict(agg=AGG, tr=out), '/home/claude/bs/g/zt_raw.pkl')

def report():
    Rw = pd.read_pickle('/home/claude/bs/g/zt_raw.pkl'); AGG = Rw['agg']; TRd = Rw['tr']
    dirs = np.where(RU.向き == '買', 1, -1)
    # 頑丈さ：両方そろう割合（手じまい229通りのうち、4つの確認すべてでランダムより良くプラス）
    P = {}
    for fam in ['W', 'r0', 'r1', 'r2']:
        C = combos({i: AGG[(i, fam)] for i in ['fut', 'cfd']}, dirs, nmin=20)
        both = (C['dmin'] > 0) & (C['amin'] > 0); P[fam] = np.nanmean(np.where(C['ok'], both, np.nan)[:, 0, :], 1)
        if fam == 'W': CW = C
    N = np.stack([P[f] for f in ['r0', 'r1', 'r2']]); z = (P['W'] - N.mean(0)) / N.std(0, ddof=1).clip(1e-3)
    rows = []
    for r in range(len(RU)):
        row = dict(ルール=RU.名前[r], 向き=RU.向き[r], 両方そろう割合=P['W'][r], でたらめ=N.mean(0)[r], 頑丈さz=z[r])
        a = np.where(CW['ok'][r, 0], CW['amin'][r, 0], np.nan)
        if np.isfinite(a).any():
            e = int(np.nanargmax(a)); row.update(一番良い手じまい=ALLX[e], 一番良い手じまいの4つの最小=a[e], ランダムとの差の最小=CW['dmin'][r, 0, e])
        # 前向き：年ごとに手じまいを選ぶ（両商品の前の年までの平均の小さいほう）、1つずつ持つ
        for inst in ['fut', 'cfd']:
            L = 'ミニ' if inst == 'fut' else 'CFD'; T = TRd[inst]; m = T['rule'] == r
            tot = 0; n = 0; ys = []; rtot = 0; rn = 0
            for t in range(2020, 2027):
                ty = t - 2018 + 2; sc = None
                for ii in ['fut', 'cfd']:
                    Z = AGG[(ii, 'W')]; c = Z['cnt'][r, 0, 2:ty].sum()
                    if c < 20: continue
                    a2 = Z['nrm'][r, 0, 2:ty].sum(0) / c; sc = a2 if sc is None else np.minimum(sc, a2)
                if sc is None: continue
                e = int(np.argmax(sc)); mm = m & (T['yr'] == t)
                ii_ = T['SI'][mm]; v = T['V'][mm, e]; xo = T['XO'][mm, e]; o = np.argsort(ii_); last = -1; s_ = 0; k_ = 0
                for qq in o:
                    if ii_[qq] > last: s_ += v[qq]; k_ += 1; last = xo[qq]
                tot += s_; n += k_; ys.append(s_)
                # ランダム（同じ向き、同じ手じまい、同じ回数まで間引いて1つずつ）
                mr = (T['RD'] == dirs[r]) & (T['ry'] == t); idx = np.nonzero(mr)[0]
                if len(idx) and mm.sum():
                    rs = np.random.default_rng(r * 100 + t).choice(idx, min(len(idx), int(mm.sum())), replace=False)
                    ri = T['RI'][rs]; vr = T['VR'][rs, e]; xr = T['XR'][rs, e]; o2 = np.argsort(ri); last = -1
                    for qq in o2:
                        if ri[qq] > last: rtot += vr[qq]; rn += 1; last = xr[qq]
            row.update({f'{L} 前向き1つずつ 件数': n, f'{L} 前向き1つずつ 合計': tot, f'{L} 前向き1回平均': tot / max(n, 1), f'{L} プラスの年': f"{sum(x > 0 for x in ys)}/{len(ys)}",
                        f'{L} ランダム1回平均': rtot / max(rn, 1)})
        rows.append(row)
    O = pd.DataFrame(rows)
    O['ランダムより良い(両商品)'] = (O['ミニ 前向き1回平均'] > O['ミニ ランダム1回平均']) & (O['CFD 前向き1回平均'] > O['CFD ランダム1回平均'])
    O['前向きで両商品プラス'] = (O['ミニ 前向き1つずつ 合計'] > 0) & (O['CFD 前向き1つずつ 合計'] > 0)
    # 運用の手じまいの効き目：4つの確認の平均（全ルール、元の基準との比較）
    base = RLc.index('セッション終わり・損切り 線の0.25A先'); ex_rows = []
    for k, nm in enumerate(EXTRA):
        e = len(RLc) + k; a = CW['amean'][:, 0, e]; b = CW['amean'][:, 0, base]
        for dd, lab in [(1, '買い'), (-1, '売り')]:
            m = (dirs == dd) & np.isfinite(a) & np.isfinite(b)
            ex_rows.append(dict(手じまい=nm, 向き=lab, ルール数=int(m.sum()), 基準より良くなった割合=(a[m] > b[m]).mean(), 四つの平均_中央=np.median(a[m]), 基準の四つの平均_中央=np.median(b[m])))
    pd.to_pickle(dict(rules=O, extra=pd.DataFrame(ex_rows)), '/home/claude/bs/g/zt_eval.pkl')
    pd.set_option('display.width', 280); pd.set_option('display.max_rows', 100)
    print(O[['ルール', '向き', '両方そろう割合', 'でたらめ', '頑丈さz', 'ミニ 前向き1回平均', 'ミニ ランダム1回平均', 'CFD 前向き1回平均', 'CFD ランダム1回平均', 'ミニ 前向き1つずつ 合計', 'CFD 前向き1つずつ 合計', 'ミニ プラスの年', 'CFD プラスの年', 'ミニ 前向き1つずつ 件数']].round(2).to_string())
    print(pd.DataFrame(ex_rows).round(2).to_string())

if __name__ == '__main__':
    if sys.argv[1] == 'run': run()
    report()
