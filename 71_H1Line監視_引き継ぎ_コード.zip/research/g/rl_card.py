"""全ルールの成績表（前向き 2020〜2026）と、どの段階で落ちたか。下げ相場の日の成績も出す。
出力：rl_card.pkl
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from rl_build import YRS, NDAY, DAY0
STUD = ['swD', 'sw240', 'sw60', 'sw15', 'k']
SLAB = {'swD': '日足', 'sw240': '4時間足', 'sw60': '1時間足', 'sw15': '15分足(スイング)', 'k': '15分足(網羅・日中〜週)'}

def regime(inst):
    """下げ相場の日：日足の終値 < EMA60 かつ EMA60 が20日前より下"""
    X = dict(np.load(f'/home/claude/bs/g/sw_D_{inst}.npz')); c = pd.Series(X['c']); e60 = c.ewm(span=60, adjust=False).mean()
    dn = (c < e60) & (e60 < e60.shift(20))
    t = pd.to_datetime(X['t'], unit='s', utc=True).tz_convert('Asia/Tokyo').tz_localize(None).normalize()
    k = ((t - DAY0).days).values; flag = np.zeros(NDAY, bool); ok = (k >= 0) & (k < NDAY)
    # その日の判定を次の日以降に（日足が確定してから）
    s = pd.Series(np.nan, index=range(NDAY)); s.iloc[k[ok]] = dn.values[ok].astype(float); s = s.shift(1).ffill().fillna(0).astype(bool)
    return s.values

def dd(x):
    cs = np.cumsum(x); return float((np.maximum.accumulate(cs) - cs).max())

def run():
    rows = []
    REG = {i: regime(i) for i in ['fut', 'cfd']}
    rob = {}
    for s in STUD:
        if s == 'k':
            t = pd.read_pickle('/home/claude/bs/g/xrep_k.pkl')['trig']
        else:
            t = pd.read_pickle(f'/home/claude/bs/g/swrep_{s[2:]}.pkl')['trig']
        rob[s] = t.set_index('トリガー')[['両方そろう割合', '頑丈さ(z)']]
    for s in STUD:
        R = pd.read_csv(f'/home/claude/bs/g/rl_rules_{s}.csv')
        Z = {i: dict(np.load(f'/home/claude/bs/g/rl_{s}_{i}.npz')) for i in ['fut', 'cfd']}
        for j, r in R.iterrows():
            key = f"{r.トリガー}{r.向き}"
            b, z = rob[s].loc[key].values if key in rob[s].index else (np.nan, np.nan)
            row = dict(調べ=SLAB[s], トリガー=r.トリガー, 向き=r.向き, 方向確認=r.方向確認, 頑丈さ_両方そろう割合=b, 頑丈さ_z=z, rid=f'{s}:{j}')
            for i in ['fut', 'cfd']:
                L = 'ミニ' if i == 'fut' else 'CFD'; Q = Z[i]
                na = Q['ny'][j].sum(); aa = Q['ay'][j].sum() / max(na, 1); ra = Q['ry'][j].sum() / max(Q['rn'][j].sum(), 1)
                n1 = Q['cy'][j].sum(); s1 = Q['sy'][j].sum(); d = Q['daily'][j]
                row.update({f'{L} 全部重ね 件数': na, f'{L} 全部重ね 1回平均': aa, f'{L} ランダム 1回平均': ra, f'{L} ランダムとの差': aa - ra,
                            f'{L} 1つずつ 件数': n1, f'{L} 1つずつ 1回平均': s1 / max(n1, 1), f'{L} 1つずつ 合計': s1, f'{L} 最大DD': dd(d),
                            f'{L} プラスの年': int((Q['sy'][j] > 0).sum()), f'{L} 下げ相場の日の損益': float(d[REG[i]].sum()), f'{L} それ以外の日': float(d[~REG[i]].sum())})
                for k, t in enumerate(YRS): row[f'{L} {t}'] = Q['sy'][j][k]
            rows.append(row)
    C = pd.DataFrame(rows)
    # 段階
    C['段階1 線の情報が頑丈（両方そろう15%以上・z2以上、トリガーのみ）'] = (C['頑丈さ_両方そろう割合'] >= .15) & (C['頑丈さ_z'] >= 2)
    C['段階2 前向き（重ねて持つ）でランダムより良い（両商品）'] = (C['ミニ ランダムとの差'] > 0) & (C['CFD ランダムとの差'] > 0)
    C['段階3 1つずつでプラス・5年以上プラス（両商品）'] = (C['ミニ 1つずつ 合計'] > 0) & (C['CFD 1つずつ 合計'] > 0) & (C['ミニ プラスの年'] >= 5) & (C['CFD プラスの年'] >= 5)
    C['合計(両商品・1つずつ)'] = C['ミニ 1つずつ 合計'] + C['CFD 1つずつ 合計']
    C['下げ相場の日(両商品)'] = C['ミニ 下げ相場の日の損益'] + C['CFD 下げ相場の日の損益']
    pd.to_pickle(dict(card=C, reg={i: REG[i] for i in REG}), '/home/claude/bs/g/rl_card.pkl')
    print(len(C)); print(C.groupby('調べ')[[c for c in C.columns if c.startswith('段階')]].sum())

if __name__ == '__main__':
    run()
