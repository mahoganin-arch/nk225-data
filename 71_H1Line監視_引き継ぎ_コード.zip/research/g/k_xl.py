import sys, glob, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter
import k_rules

OUT = '/home/claude/out/Hライン_インジ組み合わせ検証_2026-10-25.xlsx'
INST = {'fut': 'ミニ', 'cfd': 'CFD'}
DF = pd.read_csv('/home/claude/bs/g/kdefs.csv', index_col=0); FS = pd.read_csv('/home/claude/bs/g/kfsets.csv')
r1 = lambda d: d.round(1)
sheets = {'まとめ': None, '説明': None}

# 逆算した式
sheets['逆算したインジ'] = pd.DataFrame([
    ('下段のストキャス（速い方・83/85/87_PERIOD の後ろ側）', 'Stochastic(%K 35, %D 21, スローイング 21)', 'チャートの時間足で計算（5,3,3 の7倍）', '24枚の表示値と照合：差の中央値 0.16'),
    ('下段のストキャス（遅い方）', 'Stochastic(%K 140, %D 84, スローイング 84)', '同上（5,3,3 の28倍）', '差の中央値 0.12'),
    ('Indi01(5)', 'Stochastic(5,3,3) の %K', '60以上 赤・40以下 青・その間 黄', '表示値の差 平均1.4、色の一致 98%'),
    ('Indi02〜06', 'MT5標準 MACD(12m, 26m, 9m：シグナルはSMA) の本線、m＝1,2,3,4,5', '本線が前の足より上がれば赤、下がれば青', '本線の差 0.5〜1.6、色の一致 99〜100%'),
    ('Indi07', '特定できず', '6状態（赤・暗い赤・青・暗い青など）', '単独・上位足・2条件の組み合わせで最大85%の一致'),
    ('ローソク足の矢印', '特定できず', '青・ピンク・オレンジ・白抜き', '線のクロス・転換・ストキャス・PSAR・インジの色変化と照合して一致せず'),
    ('PSAR', '標準（0.02, 0.2）と仮定', '', '画像の点との照合はしていない'),
], columns=['表示', '特定した式', '色・使い方', '確かめ方'])

# 画像のルールそのまま
R = pd.concat([k_rules.evaluate(i) for i in ['fut', 'cfd']]); R['inst'] = R.inst.map(INST)
sheets['画像のルールそのまま'] = r1(R.rename(columns={'inst': '商品', 'ランダム同条件': 'ランダムな時刻に入った場合（同じ向き・手じまい・方向確認）'}))

# 線の効き目（本物とでたらめの頑丈さ）
res = pd.read_pickle('/home/claude/bs/g/kformnull.pkl')
summ = []
for fam, P in res.items():
    q = P['差の最小']; summ.append({'線': '本物' if fam == 'W' else f'でたらめ {fam}', '形の数': len(P), '4つともランダムより良い割合': (q > 0).mean(), '上位1%の値': q.quantile(.99), '上位0.1%の値': q.quantile(.999), '最大': q.max()})
sheets['線の効き目'] = r1(pd.DataFrame(summ)).round(3)
rows = []
for fam, P in res.items():
    P = P.copy(); P['pos'] = P['差の最小'] > 0
    g = P.groupby('def').agg(pos=('pos', 'mean'), med=('差の最小', 'median')); g['fam'] = fam; rows.append(g.reset_index())
Rr = pd.concat(rows); W = Rr[Rr.fam == 'W'].set_index('def'); N = Rr[Rr.fam != 'W'].groupby('def').agg(pos_n=('pos', 'mean'), pos_sd=('pos', 'std'), med_n=('med', 'mean'))
J = W.join(N).join(DF[['trig', 'grp', 'dir']]); J['z'] = (J.pos - J.pos_n) / J.pos_sd.replace(0, np.nan)
J['売買'] = J['dir'].map({1: '買い', -1: '売り'})
sheets['トリガーの頑丈さ'] = r1(J.sort_values('pos', ascending=False)[['trig', 'grp', '売買', 'pos', 'pos_n', 'z', 'med', 'med_n']].rename(columns={
    'trig': 'トリガー', 'grp': '種類', 'pos': '本物：4つともランダムより良い方向確認の割合', 'pos_n': 'でたらめな線の平均', 'med': '本物：差の最小の中央値', 'med_n': 'でたらめ：同'}))

# 方向確認の効き目
FE = pd.read_pickle('/home/claude/bs/g/kfilteff.pkl')
W = FE[FE.fam == 'W'].set_index('fset'); N = FE[FE.fam != 'W'].groupby('fset').agg(n_mean=('改善4つとも', 'mean'), n_med=('変化中央', 'mean'))
J2 = W.join(N).sort_values('改善4つとも', ascending=False)
J2['種類'] = np.where(J2.name.str.contains('ストキャス|インジ|MACD5本|PSAR|Indi01') & ~J2.name.str.contains('陽転|傾き|並び|側|支え|空いて'), 'インジだけ（でたらめと公平に比べられる）', '線を使う（でたらめは参考）')
sheets['方向確認の効き目'] = r1(J2[['name', 'k', '種類', '改善4つとも', 'n_mean', '変化中央', 'n_med', 'トリガー数']].rename(columns={
    'name': '方向確認', 'k': '数', '改善4つとも': '本物：2商品×2期間すべてで改善したトリガーの割合', 'n_mean': 'でたらめな線の平均', '変化中央': '本物：ランダムとの差の変化（中央値）', 'n_med': 'でたらめ：同'})).round(3)

# 形の上位（参考：選びすぎ）
P = pd.read_pickle('/home/claude/bs/g/kform.pkl'); P = P[P['件数最小'] >= 30].sort_values('差の最小', ascending=False).head(300)
P['売買'] = P['dir'].map({1: '買い', -1: '売り'})
sheets['形の上位300（参考）'] = r1(P[['trig', '売買', 'name', '差の最小', '差_前半_fut', '差_後半_fut', '差_前半_cfd', '差_後半_cfd', 'a_前半_fut', 'a_後半_fut', 'a_前半_cfd', 'a_後半_cfd', '件数最小']].rename(columns={
    'trig': 'トリガー', 'name': '方向確認', '差の最小': 'ランダムとの差（4つの最小）', 'a_前半_fut': 'ミニ前半 1回平均', 'a_後半_fut': 'ミニ後半', 'a_前半_cfd': 'CFD前半', 'a_後半_cfd': 'CFD後半'}))

# 本命候補
C = pd.read_pickle('/home/claude/bs/g/kcands.pkl'); Y = pd.read_pickle('/home/claude/bs/g/kcands_y.pkl')
sheets['候補 手じまい別'] = r1(C)
sheets['候補 年ごと'] = r1(Y)

# 前向き
NR = pd.concat([pd.read_pickle(f) for f in glob.glob('/home/claude/bs/g/knest_*_*.pkl') if '_tr_' not in f])
s = NR.groupby(['inst', 'var', 'grp', 'fam'])[['top5_nrm', 'top5_n13', 'top5_n']].sum().reset_index()
q = NR.groupby(['inst', 'var', 'grp', 'fam'])[['avg_nrm', 'rho']].mean().reset_index()
out = []
for (inst, var, grp), g in s.groupby(['inst', 'var', 'grp']):
    w = g[g.fam == 'W']; nl = g[g.fam != 'W']
    if len(w) == 0: continue
    w = w.iloc[0]; qq = q[(q.inst == inst) & (q['var'] == var) & (q.grp == grp)]
    out.append({'商品': INST[inst], 'コストの見方': var, '群': grp, '上位5本 そろえた合計（本物）': w.top5_nrm, 'でたらめの中央': nl.top5_nrm.median() if len(nl) else np.nan,
                '本物が上回る割合': (w.top5_nrm > nl.top5_nrm).mean() if len(nl) else np.nan, 'でたらめの数': len(nl), '件数': w.top5_n,
                '群全体の1回平均（本物）': qq[qq.fam == 'W'].avg_nrm.mean(), '群全体の1回平均（でたらめ）': qq[qq.fam != 'W'].avg_nrm.mean(), '翌年への順位相関': qq[qq.fam == 'W'].rho.mean()})
sheets['本当の前向き（組み合わせ）'] = r1(pd.DataFrame(out))
yy = NR[NR.fam == 'W'].pivot_table(index=['inst', 'var', 'grp'], columns='t', values='top5_nrm', aggfunc='sum').reset_index(); yy['inst'] = yy.inst.map(INST)
sheets['前向き 年ごと'] = r1(yy.rename(columns={'inst': '商品', 'var': 'コストの見方', 'grp': '群'}))
T = pd.read_pickle('/home/claude/bs/g/ktrigfwd.pkl'); T['inst'] = T.inst.map(INST)
TT = T.pivot_table(index=['fam', 't'], columns='inst', values=['差', '成績', '件数']); TT.columns = [f'{b} {a}' for a, b in TT.columns]; TT = TT.reset_index(); TT['fam'] = TT.fam.map(lambda f: '本物' if f == 'W' else f'でたらめ {f}')
sheets['トリガーの前向き'] = r1(TT.rename(columns={'fam': '線', 't': '確かめる年'}))
pk = pd.read_pickle('/home/claude/bs/g/ktrigfwd_picks.pkl')
sheets['トリガーの前向き 選ばれた'] = pd.DataFrame([{'確かめる年': t, '選ばれたトリガー（頑丈さ）': ' / '.join(f"{a}{'買' if b == 1 else '売'}({c})" for a, b, c in v)} for (f, t), v in pk.items() if f == 'W'])

with pd.ExcelWriter(OUT, engine='openpyxl') as w:
    for name, df in sheets.items():
        (pd.DataFrame({'': []}) if df is None else df).to_excel(w, sheet_name=name[:31], index=False)
print('ok')
