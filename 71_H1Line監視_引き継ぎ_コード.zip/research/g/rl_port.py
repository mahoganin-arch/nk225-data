"""ルールの組み合わせ（前向き）。各ルールは1枚・1つずつ持つ。t 年（2022〜2026）に使う組み合わせを、2020〜t−1 の前向きの成績だけで選ぶ。
選び方：両商品の「合計 ÷ 最大ドローダウン」の小さいほうが一番大きくなるように、1つずつ足していく（最大8本、同じトリガーは2本まで）。
型：A 自由に選ぶ／B 売りを2本以上入れる／C 1本だけ／D 前回の4候補（固定）／E 買って持ち続ける（比べるため）
出力：rl_port.pkl
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from rl_build import YRS, NDAY, DAY0
REF = 68800.0
STUD = ['swD', 'sw240', 'sw60', 'sw15', 'k']

def load():
    C = pd.read_pickle('/home/claude/bs/g/rl_card.pkl'); card = C['card']; REG = C['reg']
    D = {i: [] for i in ['fut', 'cfd']}
    for s in STUD:
        for i in ['fut', 'cfd']: D[i].append(np.load(f'/home/claude/bs/g/rl_{s}_{i}.npz')['daily'])
    D = {i: np.concatenate(v) for i, v in D.items()}
    days = DAY0 + pd.to_timedelta(np.arange(NDAY), unit='D'); yr = days.year.values
    return card, D, yr, REG

def bh(inst):
    X = dict(np.load(f'/home/claude/bs/g/sw_D_{inst}.npz')); c = X['c']
    t = pd.to_datetime(X['t'], unit='s', utc=True).tz_convert('Asia/Tokyo').tz_localize(None).normalize(); k = ((t - DAY0).days).values
    d = np.zeros(NDAY); ok = (k >= 0) & (k < NDAY); ch = np.r_[0, np.diff(c)] * REF / c; d[k[ok]] = ch[ok]; return d

def score(P, yr, train):
    s = []
    for i in P:
        x = P[i][np.isin(yr, train)]; cs = np.cumsum(x); dd = (np.maximum.accumulate(cs) - cs).max()
        s.append(x.sum() / (dd + 3000))
    return min(s)

def greedy(cands, D, yr, train, K=8, need_sell=0, sells=None, trig=None):
    pick = []; P = {i: np.zeros(D[i].shape[1]) for i in D}; best = -1e9; cnt = {}
    def add_best(pool):
        nonlocal best
        bs, bj = -1e9, None
        for j in pool:
            if j in pick or cnt.get(trig[j], 0) >= 2: continue
            Q = {i: P[i] + D[i][j] for i in D}; sc = score(Q, yr, train)
            if sc > bs: bs, bj = sc, j
        return bs, bj
    for _ in range(need_sell):
        bs, bj = add_best([j for j in cands if sells[j]])
        if bj is None: break
        pick.append(bj); cnt[trig[bj]] = cnt.get(trig[bj], 0) + 1
        for i in D: P[i] += D[i][bj]
        best = bs
    while len(pick) < K:
        bs, bj = add_best(cands)
        if bj is None or bs <= best: break
        pick.append(bj); cnt[trig[bj]] = cnt.get(trig[bj], 0) + 1; best = bs
        for i in D: P[i] += D[i][bj]
    return pick

def run():
    card, D, yr, REG = load(); sells = (card.向き == '売').values; trig = (card.調べ + card.トリガー + card.向き).values
    BH = {i: bh(i) for i in D}
    FIX = []
    for s, t in [('15分足(スイング)', '1H・4H 同じ位置でクロス'), ('1時間足', 'EMA48×H4Line'), ('1時間足', 'H4Lineの向き転換'), ('15分足(網羅・日中〜週)', 'H1Line 山 反発0.1')]:
        q = card.index[(card.調べ == s) & (card.トリガー == t) & (card.向き == '買') & (card.方向確認 == 'なし')]
        if len(q): FIX.append(int(q[0]))
    rows = []; picks = []
    for t in range(2022, 2027):
        train = list(range(2020, t))
        ok = np.ones(len(card), bool)
        for i in D:
            x = D[i][:, np.isin(yr, train)]; ok &= x.sum(1) > 0
        cands = np.nonzero(ok)[0]
        V = {'A 自由に選ぶ': greedy(cands, D, yr, train, trig=trig), 'B 売りを2本以上入れる': greedy(cands, D, yr, train, need_sell=2, sells=sells, trig=trig),
             'C 1本だけ': greedy(cands, D, yr, train, K=1, trig=trig), 'D 前回の4候補（固定）': FIX}
        for v, pk in V.items():
            for r, j in enumerate(pk): picks.append(dict(年=t, 型=v, 順=r + 1, 調べ=card.調べ[j], トリガー=card.トリガー[j], 向き=card.向き[j], 方向確認=card.方向確認[j]))
            for i in D:
                x = D[i][pk].sum(0) if len(pk) else np.zeros(D[i].shape[1]); m = yr == t; xx = x[m]; cs = np.cumsum(xx)
                rows.append(dict(年=t, 型=v, 商品='ミニ' if i == 'fut' else 'CFD', 本数=len(pk), 合計=xx.sum(), 最大DD=(np.maximum.accumulate(cs) - cs).max(),
                                 下げ相場の日=x[m & REG[i]].sum(), それ以外の日=x[m & ~REG[i]].sum()))
        for i in D:
            m = yr == t; xx = BH[i][m]; cs = np.cumsum(xx)
            rows.append(dict(年=t, 型='E 買って持ち続ける（1枚）', 商品='ミニ' if i == 'fut' else 'CFD', 本数=1, 合計=xx.sum(), 最大DD=(np.maximum.accumulate(cs) - cs).max(),
                             下げ相場の日=BH[i][m & REG[i]].sum(), それ以外の日=BH[i][m & ~REG[i]].sum()))
        print(t, flush=True)
    R = pd.DataFrame(rows); PK = pd.DataFrame(picks)
    S = R.groupby(['型', '商品']).agg(合計=('合計', 'sum'), プラスの年=('合計', lambda s: f'{(s > 0).sum()}/{len(s)}'), 一番悪い年=('合計', 'min'), 年の最大DD=('最大DD', 'max'),
                                      下げ相場の日=('下げ相場の日', 'sum'), それ以外の日=('それ以外の日', 'sum')).reset_index()
    pd.to_pickle(dict(year=R, sum=S, picks=PK), '/home/claude/bs/g/rl_port.pkl')
    pd.set_option('display.width', 250); print(S.round(0).to_string()); print(R.pivot_table(index=['型', '商品'], columns='年', values='合計').round(0).to_string())

if __name__ == '__main__':
    run()
