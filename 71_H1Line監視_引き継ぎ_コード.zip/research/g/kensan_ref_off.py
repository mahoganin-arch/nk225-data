"""TradingView のつなぎ足に合わせて、研究の値段を限月ごとの差だけずらした検算の元を作る（差は書き出しから測る）。
使い方：python3 kensan_ref_off.py fut 取り出した書き出し.pkl 名前
"""
import sys, numpy as np, pandas as pd, pickle
inst, src, name = sys.argv[1], sys.argv[2], sys.argv[3]
X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz'))
REF = pickle.load(open('/home/claude/bs/g/kensan_ref.pkl', 'rb')); R = REF[inst]
df = pd.read_pickle(src); pos = pd.Series(np.arange(len(R['t'])), index=R['t']); k = pos.reindex(df.time).values; ok = ~np.isnan(k)
d = pd.DataFrame({'t': df.time.values[ok], 'diff': df.close.values[ok] - R['c'][k[ok].astype(int)]})
d = d[d['diff'] != d['diff'].shift()]   # 差が変わる時刻
seg = d[(d['diff'].shift(-1) != d['diff'])]
# 差の区切り：長く続くものだけ
D = pd.DataFrame({'t': df.time.values[ok], 'diff': df.close.values[ok] - R['c'][k[ok].astype(int)]})
grp = (D['diff'] != D['diff'].shift()).cumsum(); G = D.groupby(grp).agg(t0=('t', 'first'), diff=('diff', 'first'), n=('diff', 'size')); G = G[G.n > 20].reset_index(drop=True)
off = np.full(len(X['tm']), G['diff'].iloc[0])
for _, g in G.iterrows(): off[X['tm'] >= g.t0] = g['diff']
print(G.to_string())
for kk in ['o', 'h', 'l', 'c']: X[kk] = X[kk] + off
np.savez(f'/home/claude/bs/g/data_{inst}_off.npz', **X)
_load = np.load
def load2(p, *a, **kw):
    p = str(p)
    if p.endswith(f'/data_{inst}.npz'): p = p.replace(f'/data_{inst}.npz', f'/data_{inst}_off.npz')
    return _load(p, *a, **kw)
np.load = load2
sys.path.insert(0, '/home/claude/bs'); sys.path.insert(0, '/home/claude/bs/g')
import emu3
from emu3_run import run_all
X2, B, E, S = emu3.build_all(inst)
KL = np.load(f'/home/claude/bs/g/kind_{inst}_W.npz')['L'].astype(float); B['LM19'] = KL[B['i5']] + off[B['i5']][:, None]
n = len(B['c']); P = {v: k for k, v in enumerate(B['i5'])}; pA = np.zeros(n); pB = np.zeros(n); mA = np.zeros(n); mB = np.zeros(n)
for r in emu3.ALERT_BUY + emu3.ALERT_SELL:
    tr = run_all(B, E, S[r], r, 5.0 if inst == 'fut' else 7.0); ip = np.zeros(n, bool)
    for a, b in zip(tr.i5.values, tr.x5.values): ip[P[a]:P[b]] = True
    if r < 19: pA += ip * 2.0 ** r; mA += S[r] * 2.0 ** r
    else: pB += ip * 2.0 ** (r - 19); mB += S[r] * 2.0 ** (r - 19)
REF[name] = dict(t=B['tstart'], h1=B['h1'], h4=B['h4'], d1=B['d1'], A=B['A'], h1pk=B['h1pk'], h1vl=B['h1vl'], mc1=B['mc1'], sg1=B['sg1'], mc96=E['mc96'], sg4=E['sg4'], sk=E['sk'],
                 cnt=B['cnt'], agree=E['agree'], dUp=B['dUpTV'].astype(float), sk60=E['sk60c'], sd60=E['sd60c'], buyOv=B['buyOv'], sellOv=B['sellOv'], mA=mA, mB=mB, pA=pA, pB=pB, c=B['c'], end60=B['end60'].astype(float))
pickle.dump(REF, open('/home/claude/bs/g/kensan_ref.pkl', 'wb')); print('ok', name)
