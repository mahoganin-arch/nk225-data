"""形としての強さ：条件なし（全体）で、形ごとに全設定を平均した成績。"""
import sys,numpy as np,pandas as pd
YEARS=list(range(2018,2027))
def fam_table(inst,fam,levels=(('形',['grp','kind','dir']),('形×線',['grp','line','kind','dir']))):
    DF=pd.read_csv('/home/claude/bs/g/hdefs.csv',index_col=0)
    A=pd.read_parquet(f'/home/claude/bs/g/hagg_{inst}_{fam}.parquet',filters=[('feat','=',0)])
    A=A.merge(DF[['grp','line','kind','dir','tf','b']],left_on='def',right_index=True)
    out=[]
    for lvl,keys in levels:
        g=A.groupby(keys)
        S=g[[f'{c}{y}' for c in ['n','net','nrm','n13'] for y in YEARS]].sum()
        S['nconf']=g.size(); S['lvl']=lvl
        out.append(S.reset_index())
    O=pd.concat(out); O['inst']=inst; O['fam']=fam
    return O
def summ(O,ys,c):
    return O[[f'{c}{y}' for y in ys]].sum(1)/O[[f'n{y}' for y in ys]].sum(1)
if __name__=='__main__':
    O=fam_table(sys.argv[1],sys.argv[2])
    f=O[O.lvl=='形'].copy()
    for c in ['net','nrm','n13']: f[c+'全']=summ(f,YEARS,c)
    f['nrm前']=summ(f,range(2018,2023),'nrm'); f['nrm後']=summ(f,range(2023,2027),'nrm')
    f['プラス年']=sum((f[f'nrm{y}']>0).astype(int) for y in YEARS)
    pd.set_option('display.width',250)
    print(f[['grp','kind','dir','nconf','net全','nrm全','n13全','nrm前','nrm後','プラス年']].round(1).to_string())
