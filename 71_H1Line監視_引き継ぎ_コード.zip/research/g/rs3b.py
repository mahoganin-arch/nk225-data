"""候補の選び直し（v3）の続き：上位足スイング（sw15・sw60・sw240・swD、方向確認つきも）、セオリー（zt）、売りの深掘り（ss）。
条件（入る・避ける）は方向確認なしのルールに、前の年で選んだ条件をルールとランダムの両方に当てはめる。
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from rs3 import YRS, one_stats, rand_stats, compare, seq
REF = 68800.0; COST = {'fut': 5.0, 'cfd': 7.0}
LAB = {'15': '15分足スイング', '60': '1時間足', '240': '4時間足', 'D': '日足'}

def to5(inst, tf):
    X5 = np.load(f'/home/claude/bs/g/data_{inst}.npz'); Xs = np.load(f'/home/claude/bs/g/sw_{tf}_{inst}.npz')
    end5 = X5['tm'] + 300; m = np.clip(np.searchsorted(end5, Xs['tend'], side='left'), 0, len(end5) - 1); return m

def study_sw(tf):
    FL = ['なし'] + pd.read_csv(f'/home/claude/bs/g/sw_filters_{tf}.csv').iloc[:, 0].tolist(); EX = pd.read_csv(f'/home/claude/bs/g/sw_exits_{tf}.csv').手じまい.tolist(); EXI = {n: k for k, n in enumerate(EX)}
    TR = pd.read_csv(f'/home/claude/bs/g/sw_trigs_{tf}.csv').iloc[:, 0].tolist()
    RR = pd.read_csv(f'/home/claude/bs/g/rl_rules_sw{tf}.csv')
    ch = {(int(r.g), int(r.f)): {y: (EXI.get(r[f'手じまい{y}'], -1) if isinstance(r[f'手じまい{y}'], str) else -1) for y in YRS} for _, r in RR.iterrows()}
    res = {}
    for inst in ['fut', 'cfd']:
        S = dict(np.load(f'/home/claude/bs/g/swsig_{tf}_{inst}_W.npz')); Q = dict(np.load(f'/home/claude/bs/g/swrand_{tf}_{inst}_W.npz')); m5 = to5(inst, tf)
        def val(Z, idx, e):
            v = Z['R'][idx, e].astype(float) * REF / Z['e'][idx] - COST[inst]
            if inst == 'cfd': v = v - Z['nt'][idx, e] * 0.03 / 365 * REF
            return v
        gS = S['trig'].astype(np.int64) * 2 + (S['d'] > 0); okS = S['yr'] >= 2020; okQ = Q['yr'] >= 2020
        for (g, f), cc in ch.items():
            m = (gS == g) & okS
            if f > 0: m &= ((S['f'] >> (f - 1)) & 1).astype(bool)
            idx = np.nonzero(m)[0]; e = np.array([cc[y] for y in S['yr'][idx]], int); ok = e >= 0; idx, e = idx[ok], e[ok]
            i = S['i'][idx]; x = np.minimum(i + S['hb'][idx, e], len(m5) - 1)
            dr = 1 if g % 2 == 1 else -1; mq = ((Q['d'] > 0) == (dr == 1)) & okQ
            if f > 0: mq &= ((Q['f'] >> (f - 1)) & 1).astype(bool)
            iq = np.nonzero(mq)[0]; eq = np.array([cc[y] for y in Q['yr'][iq]], int); okq = eq >= 0; iq, eq = iq[okq], eq[okq]
            xq = np.minimum(Q['i'][iq] + Q['hb'][iq, eq], len(m5) - 1)
            res.setdefault((g, f), {})[inst] = (m5[i], m5[x], val(S, idx, e), S['yr'][idx], [(m5[Q['i'][iq]], m5[xq], val(Q, iq, eq), Q['yr'][iq])])
    rows = []
    for (g, f), dct in res.items():
        row = dict(調べ=LAB[tf], ルール=f"sw{tf}:{TR[g // 2]}{'買' if g % 2 == 1 else '売'}", 向き='買い' if g % 2 == 1 else '売り', 方向確認=FL[f], 条件='そのまま')
        for inst, L in [('fut', 'ミニ'), ('cfd', 'CFD')]:
            if inst not in dct: continue
            i5, x5, v, yr, pools = dct[inst]
            row.update(one_stats(i5, x5, v, yr, f'{L} ')); row.update(rand_stats(pools, f'{L} ランダム')); compare(row, L)
        rows.append(row)
    return pd.DataFrame(rows), res

def study_theory(kind):
    """kind='zt'（セオリー）または 'ss'（売りの深掘り：手じまいの選び方3通り）"""
    raw = pd.read_pickle(f'/home/claude/bs/g/{kind}_raw.pkl'); AGG = raw['agg']; TRd = raw['tr']; RU = pd.read_csv(f'/home/claude/bs/g/{kind}_rules.csv')
    if kind == 'zt':
        from zt_eval import ALLX
    else:
        from ss_eval import ALLX
    short = np.array([('セッション' in x or '日の終わり' in x) and '週' not in x for x in ALLX])
    SUB = {'zt': {'zt': np.ones(len(ALLX), bool)}, 'ss': {'ss': np.ones(len(ALLX), bool), 'ssS': short, 'ssL': ~short}}[kind]
    Z2 = {i: AGG[(i, 'W')] for i in ['fut', 'cfd']}
    def pick(r, mask):
        ch = {}
        for t in YRS:
            ty = t - 2018 + 2; sc = None
            for ii in ['fut', 'cfd']:
                c = Z2[ii]['cnt'][r, 0, 2:ty].sum()
                if c < 20: continue
                a = Z2[ii]['nrm'][r, 0, 2:ty].sum(0) / c; sc = a if sc is None else np.minimum(sc, a)
            ch[t] = -1 if sc is None else int(np.argmax(np.where(mask, sc, -np.inf)))
        return ch
    res = {}
    for pre, mask in SUB.items():
        for r in range(len(RU)):
            cc = pick(r, mask); dr = 1 if RU.向き[r] == '買' else -1
            for inst in ['fut', 'cfd']:
                T = TRd[inst]; m = np.nonzero((T['rule'] == r) & (T['yr'] >= 2020))[0]
                e = np.array([cc[y] for y in T['yr'][m]], int); ok = e >= 0; m, e = m[ok], e[ok]
                mr = np.nonzero((T['RD'] == dr) & (T['ry'] >= 2020))[0]; er = np.array([cc[y] for y in T['ry'][mr]], int); okr = er >= 0; mr, er = mr[okr], er[okr]
                res.setdefault((pre, r), {})[inst] = (T['SI'][m], T['XO'][m, e], T['V'][m, e].astype(float), T['yr'][m], [(T['RI'][mr], T['XR'][mr, er], T['VR'][mr, er].astype(float), T['ry'][mr])])
    rows = []
    lab = {'zt': '15分足セオリー', 'ss': '売りの深掘り（手じまい全部から）', 'ssS': '売りの深掘り（短め）', 'ssL': '売りの深掘り（長め）'}
    for (pre, r), dct in res.items():
        row = dict(調べ=lab[pre], ルール=f"{pre}:{RU.名前[r]}{RU.向き[r]}", 向き='買い' if RU.向き[r] == '買' else '売り', 方向確認='なし', 条件='そのまま')
        for inst, L in [('fut', 'ミニ'), ('cfd', 'CFD')]:
            i5, x5, v, yr, pools = dct[inst]
            row.update(one_stats(i5, x5, v, yr, f'{L} ')); row.update(rand_stats(pools, f'{L} ランダム')); compare(row, L)
        rows.append(row)
    return pd.DataFrame(rows), res

_FC = {}
def fast_feats(inst, i5, d):
    """全部の5分足の特徴を一度だけ作って、入った足の行を取り出す（cond.feats と同じ値）"""
    from cond import feats
    key = (inst, d)
    if key not in _FC:
        n = len(np.load(f'/home/claude/bs/g/data_{inst}.npz')['c'])
        F, names = feats(pd.DataFrame({'inst': inst, 'i5': np.arange(n), 'd': d})); _FC[key] = (F, names)
    F, names = _FC[key]; return F[np.asarray(i5, np.int64)], names

def with_conditions(res, names_fn, condf, study_lab):
    """方向確認なしのルールに、前の年で選んだ入る・避ける条件を当てはめる（ルールもランダムも）"""
    from cond import feats, apply
    from cand_list import parse
    C = pd.read_pickle(condf); PL = C['picks']
    rows = []
    # 特徴を作る（ルールの入りとランダムの入り）
    for key, dct in res.items():
        nm, dr, ok = names_fn(key)
        if not ok: continue
        sub = PL[PL.rule == nm]
        if len(sub) == 0: continue
        for mode, md in [('避ける', 'avoid'), ('入る条件', 'require')]:
            row = dict(調べ=study_lab(key), ルール=nm, 向き='買い' if dr == 1 else '売り', 方向確認='なし', 条件=mode)
            for inst, L in [('fut', 'ミニ'), ('cfd', 'CFD')]:
                i5, x5, v, yr, pools = dct[inst]
                F, names = fast_feats(inst, i5, dr)
                keep = np.zeros(len(i5), bool); rp = []
                for t in YRS:
                    s = sub[(sub.t == t) & (sub.型 == mode)]
                    if len(s) == 0: continue
                    pk = parse(s.条件.values[0], names); m = yr == t; keep[m] = apply(F[m], pk, md)
                pools2 = []
                for (ri, rx, rv, ry) in pools:
                    FR, _ = fast_feats(inst, ri, dr); kr = np.zeros(len(ri), bool)
                    for t in YRS:
                        s = sub[(sub.t == t) & (sub.型 == mode)]
                        if len(s) == 0: continue
                        pk = parse(s.条件.values[0], names); m = ry == t; kr[m] = apply(FR[m], pk, md)
                    pools2.append((ri[kr], rx[kr], rv[kr], ry[kr]))
                row.update(one_stats(i5[keep], x5[keep], v[keep], yr[keep], f'{L} ')); row.update(rand_stats(pools2, f'{L} ランダム')); compare(row, L)
            rows.append(row)
    return pd.DataFrame(rows)

if __name__ == '__main__':
    import pickle
    st = sys.argv[1]
    if st.startswith('sw'):
        tf = st[2:]; D, res = study_sw(tf)
        TR = pd.read_csv(f'/home/claude/bs/g/sw_trigs_{tf}.csv').iloc[:, 0].tolist()
        Dc = with_conditions(res, lambda k: (f"sw{tf}:{TR[k[0] // 2]}{'買' if k[0] % 2 == 1 else '売'}", 1 if k[0] % 2 == 1 else -1, k[1] == 0), '/home/claude/bs/g/cond.pkl', lambda k: LAB[tf])
        pd.concat([D, Dc], ignore_index=True).to_pickle(f'/home/claude/bs/g/rs3_{st}.pkl'); print(st, D.shape, Dc.shape)
    elif st in ('zt', 'ss'):
        D, res = study_theory(st); RU = pd.read_csv(f'/home/claude/bs/g/{st}_rules.csv')
        lab = {'zt': '15分足セオリー', 'ss': '売りの深掘り（手じまい全部から）', 'ssS': '売りの深掘り（短め）', 'ssL': '売りの深掘り（長め）'}
        Dc = with_conditions(res, lambda k: (f"{k[0]}:{RU.名前[k[1]]}{RU.向き[k[1]]}", 1 if RU.向き[k[1]] == '買' else -1, True), f'/home/claude/bs/g/cond_tr_{st}.pkl', lambda k: lab[k[0]])
        pd.concat([D, Dc], ignore_index=True).to_pickle(f'/home/claude/bs/g/rs3_{st}.pkl'); print(st, D.shape, Dc.shape)
