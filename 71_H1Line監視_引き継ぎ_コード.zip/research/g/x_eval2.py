"""手じまい拡張の調べ直しの共通評価。配列 cnt[G,F,B]、nrm/n13[G,F,B,E]、ランダム cntR[2,B]、nrmR[2,B,E]。
B：0 前半・1 後半・2〜 年。G ごとの向き dirs[G]（+1/-1）。"""
import numpy as np, pandas as pd

def combos(Zs, dirs, nmin=30, stat='nrm'):
    """4つの確認（商品×前半後半）：平均・ランダムとの差。返り値：dict（配列 [G,F,E]）"""
    A = []; Dd = []; N = []
    rd = (np.asarray(dirs) > 0).astype(int)
    for inst, Z in Zs.items():
        for b in (0, 1):
            c = Z['cnt'][:, :, b]; a = Z[stat][:, :, b, :] / np.maximum(c, 1)[..., None]
            ar = Z[stat + 'R'][:, b, :] / np.maximum(Z['cntR'][:, b], 1)[:, None]
            A.append(a); Dd.append(a - ar[rd][:, None, :]); N.append(np.broadcast_to(c[..., None], a.shape))
    A = np.stack(A); Dd = np.stack(Dd); N = np.stack(N)
    ok = (N >= nmin).all(0)
    return dict(amin=np.where(ok, A.min(0), np.nan), dmin=np.where(ok, Dd.min(0), np.nan), amean=np.where(ok, A.mean(0), np.nan), nmin=N.min(0), ok=ok, A=A, D=Dd)

def nested(Zs, y0, years, dirs, nmin=30, top=5):
    """t 年より前で選び t 年に使う。選び方：4つの…ではなく、商品ごとの前の年までの平均の最小（両商品にデータがあれば）。トリガー（G）は重ねない。"""
    rows = []; picks = {}
    for t in years:
        ty = t - y0 + 2
        sc = None
        for inst, Z in Zs.items():
            c = Z['cnt'][:, :, 2:ty].sum(-1); s = Z['nrm'][:, :, 2:ty, :].sum(-2); a = s / np.maximum(c, 1)[..., None]
            ok = (c >= nmin)[..., None] & np.ones(a.shape, bool)
            v = np.where(ok, a, np.nan)
            if c.sum() == 0: continue
            sc = v if sc is None else np.where(np.isnan(v), sc, np.where(np.isnan(sc), v, np.minimum(sc, v)))
        if sc is None: continue
        flat = np.argsort(-np.nan_to_num(sc, nan=-1e18), axis=None); G, F, E = np.unravel_index(flat, sc.shape)
        pick = []; used = set()
        for g, f, e in zip(G, F, E):
            if np.isnan(sc[g, f, e]) or sc[g, f, e] <= 0: break
            if g in used: continue
            used.add(g); pick.append((g, f, e))
            if len(pick) == top: break
        picks[t] = pick
        pos = np.nan_to_num(sc, nan=-1) > 0
        for inst, Z in Zs.items():
            ct = Z['cnt'][:, :, ty]; st = Z['nrm'][:, :, ty, :]; qt = Z['n13'][:, :, ty, :]
            if ct.sum() == 0: continue
            n_t = np.broadcast_to(ct[..., None], st.shape)
            r = dict(t=t, inst=inst, 候補数=int(pos.sum()), 上位5合計=sum(st[x] for x in pick), 上位5合計13円=sum(qt[x] for x in pick), 上位5件数=sum(n_t[x] for x in pick))
            m = pos & (n_t > 0); r['全部の平均'] = st[m].sum() / max(n_t[m].sum(), 1)
            s5 = pos & (n_t >= 5)
            r['順位相関'] = pd.Series(sc[s5]).rank().corr(pd.Series(st[s5] / n_t[s5]).rank()) if s5.sum() > 20 else np.nan
            rows.append(r)
    return pd.DataFrame(rows), picks
