import numpy as np, pandas as pd, sys
sys.path.insert(0,'.')
OUT='/home/claude/out/調べ直しと上位足スイング_2026-10-26.xlsx'
def rl(s):
    if not isinstance(s,str): return s
    for a,b in [('H1Line(15分足の線)','H4Line'),('H1Line','H4Line'),('m15','H1Line'),('15分足線','1H線(EMA48)'),('3分足線','15分足線(EMA12)'),('3分','15分')]: s=s.replace(a,b)
    return s
def RL(df):
    df=df.copy()
    for c in df.columns:
        if df[c].dtype==object: df[c]=df[c].map(rl)
    return df
K={s:pd.read_pickle(f'xrep_{s}.pkl') for s in ['k','m15','m3']}; SWR={tf:pd.read_pickle(f'swrep_{tf}.pkl') for tf in ['15','60','240','D']}
CF=pd.read_pickle('cand_fwd.pkl'); NV=pd.read_pickle('nov.pkl')
LAB={'k':'15分足の網羅（Hライン×インジ）','m15':'15分足チャートのブログ観点','m3':'3分足のブログ観点'}; TFL={'15':'15分足','60':'1時間足','240':'4時間足','D':'日足'}
S={}
S['まとめ']=pd.DataFrame({'':[
 '【やったこと1：調べ直し】15分足の網羅（278トリガー×方向確認18）、15分足チャートのブログ観点、3分足のブログ観点を、手じまい225通り（最長2日・週の終わりまで持つ型を含む）で計算し直した。でたらめな線（2〜3組）とランダムな入りと比べ、前半・後半×ミニ・CFDの4つで確かめた。',
 '【やったこと2：上位足】15分足・1時間足・4時間足・日足のチャートで、線（H系の線・EMA）とストキャス（チャート＋上の3つの時間足）から 約34トリガー×2向き×方向確認121×手じまい96（最長：15分足960本・1H 240本・4H 120本・日足120本、週末の持ち越しあり、CFDは金利も引く）。でたらめな線5組とランダムな入りと比べた。2018〜2026-10-08。',
 '【結果1：線の情報】15分足の網羅は手じまいを広げても本物の線が強い（両方そろう形 6.2%、でたらめ 2.8〜3.6%）。上位足ほど差が大きい：1時間足 8.2%対3.7〜5.0%、4時間足 6.7%対2.2〜3.5%、日足 4.3%対1.3〜3.3%、15分足スイング 4.9%対2.9〜4.0%。3分足と15分足のブログ観点は、手じまいを広げてもでたらめな線と差がない。',
 '【結果2：長く持つと良くなるが、多くは上げ相場の分】手じまいを広げると成績は大きく上がるが、ランダムに入っても同じだけ上がる。合図の価値は「ランダムな入りとの差」で見る必要がある。売りは、どの時間足でもほぼ全部ダメ。',
 '【結果3：全部の形から上位5本を選ぶやり方は、どの時間足でも翌年に続かない】（順位相関0）。線の情報はあっても、1つの形を選び抜くと選びすぎになる。',
 '【結果4：頑丈な合図を先に決め、手じまいだけ前の年で選ぶ（前向き）】さらに「ポジションは1つだけ」で、ランダムな入り（同じ手順）と比べると、ランダムより はっきり良いのは次の形（1回平均、ミニ／CFD、カッコはランダム）：',
 '  ・15分足チャート「1H・4H の速ストキャスが同じ位置で上にクロス」で買い：+744（+145）／+562（+3）、6/7年プラス。ただし件数は年8回ほど（合計53〜60回）。',
 '  ・1時間足「EMA48 が H4Line を上抜け」で買い：+472（+346）／+307（+93）。「H4Lineが上向きに変わる」で買い：+473（+316）／+309（+306）、7/7年プラス。手じまいは「終値がD1Lineを下に抜けたら」が多く選ばれる（平均5日ほど持つ）。',
 '  ・15分足「H1Lineの山の値まで押して反発（0.1A）」で買い（前回の候補A）：+126（+37）／+74（+64）。',
 '  ・4時間足「EMA72まで押して反発」は全部重ねて持つと良く見えたが、1つずつにするとランダムと同じ。日足は件数が少なすぎて判断できない。',
 '【結論】線とストキャスには本物の情報があり、上位足ほどはっきりする。ただし儲けの大半は「上げ相場で買って長く持つ」ことから来ている。合図の上乗せがはっきりあるのは、15分足の「1H・4H同じ位置クロス買い」、1時間足の「H4Line向き転換買い／EMA48×H4Line買い」、15分足の「H1Line山の押し目買い（A）」。どれも 2026/10/9 以降の前向きで確かめる。',
 '確かめ：1時間足「H4Line向き転換買い・終値がD1Lineを下に抜けたら手じまい・1つずつ」を別に書いた計算で出し直し、件数と1回平均がエンジンと一致（ミニ 143回・+566.5、CFD 148回・+418.7）。',
 '注意：頑丈な合図の選び方は全期間で決めている（手じまいだけ前向き）。ミニの限月の乗り換えコストは入れていない（四半期に1回、5円程度）。']})
for s in ['k','m15','m3']:
    f=RL if s=='m15' else (lambda d:d)
    S[f'調べ直し 線の効き目 {s}']=K[s]['null'].round(3)
    S[f'調べ直し トリガー {s}']=f(K[s]['trig']).round(2)
    S[f'調べ直し 前向き {s}']=K[s]['nest'].round(1)
    S[f'調べ直し 上位300 {s}']=f(K[s]['top']).round(1)
rows=[]
for tf,O in SWR.items():
    x=O['null'].copy(); x.insert(0,'チャート',TFL[tf]); rows.append(x)
S['上位足 線の効き目']=pd.concat(rows).round(3)
for tf,O in SWR.items():
    S[f'上位足 トリガー {TFL[tf]}']=O['trig'].round(3)
    S[f'上位足 方向確認 {TFL[tf]}']=O['filt'].round(3)
    S[f'上位足 一番良い手じまい {TFL[tf]}']=O['best'].round(1)
    S[f'上位足 上位300 {TFL[tf]}']=O['top'].round(1)
rows=[]
for tf,O in SWR.items():
    x=O['nest'].copy(); x.insert(0,'チャート',TFL[tf]); rows.append(x)
S['上位足 前向き(上位5本)']=pd.concat(rows).round(0)
S['頑丈な合図 前向き']=CF['sum'].round(1)
S['頑丈な合図 年ごとの手じまい']=CF['det'].round(0)
S['1つずつ持つ・ランダムと比べる']=NV.round(1)
with pd.ExcelWriter(OUT,engine='openpyxl') as w:
    for k,v in S.items(): v.to_excel(w,sheet_name=k[:31],index=False)
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
wb=load_workbook(OUT)
for ws in wb.worksheets:
    for c in ws[1]: c.font=Font(bold=True); c.fill=PatternFill('solid',fgColor='DDEBF7'); c.alignment=Alignment(wrap_text=True,vertical='top')
    for col in ws.columns:
        L=max(len(str(c.value or '')) for c in list(col)[:150]); ws.column_dimensions[col[0].column_letter].width=min(max(8,L*1.5),55)
    ws.freeze_panes='A2'
ws=wb['まとめ']; ws.column_dimensions['A'].width=130
for row in ws.iter_rows(min_row=2):
    for c in row: c.alignment=Alignment(wrap_text=True,vertical='top')
wb.save(OUT); print(len(wb.worksheets),[w.title for w in wb])
