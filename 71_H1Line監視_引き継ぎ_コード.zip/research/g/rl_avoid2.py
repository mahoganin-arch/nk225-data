"""避ける状況を「効く種類だけ」に絞った二段の前向き：2020〜2023 の前向きの結果で効く状況の種類を決め、2024〜2026 にだけ当てはめる。"""
import numpy as np, pandas as pd
from rl_avoid import FEAT, NUM
T = pd.read_pickle('/home/claude/bs/g/rl_avoid_trades.pkl'); FW = pd.read_pickle('/home/claude/bs/g/rl_avoid.pkl')['fw']
# 1) 2020〜2023 で、選ばれたときに避けた分が両商品ともマイナスだった状況の種類
rows = []
for _, r in FW[(FW.t <= 2023) & (FW.避ける状況 != '')].iterrows():
    for c in r.避ける状況.split(' / '): rows.append(dict(状況=c.split('=')[0], inst=r.inst, v=r.避けた分の合計, n=r.見送り))
F = pd.DataFrame(rows).groupby(['状況', 'inst']).agg(v=('v', 'sum'), n=('n', 'sum')).reset_index(); F['avg'] = F.v / F.n
ok = F.pivot(index='状況', columns='inst', values='avg'); allowed = [FEAT.index(s) for s in ok.index[(ok < 0).all(1)]]
print('使う状況', [FEAT[k] for k in allowed])
def pick(tr, te, feats):
    cand = []
    for k in feats:
        col = f'c{k}'
        if k in NUM:
            q = np.nanquantile(tr[col], [1 / 3, 2 / 3]); bt = np.where(tr[col].isna(), -1, np.digitize(tr[col], q)); be = np.where(te[col].isna(), -1, np.digitize(te[col], q))
        else:
            bt = tr[col].fillna(-1).astype(int).values; be = te[col].fillna(-1).astype(int).values
        for b in np.unique(bt):
            if b < 0: continue
            inb = bt == b
            if inb.mean() > 0.5 or inb.sum() < 20: continue
            good = True; gain = 0
            for inst in tr.inst.unique():
                mi = (tr.inst == inst).values; x_in = tr.v.values[mi & inb]; x_all = tr.v.values[mi]
                if len(x_in) < 10 or x_in.mean() >= 0 or x_in.mean() > x_all.mean() - x_all.std() / np.sqrt(len(x_in)): good = False; break
                gain += -x_in.sum()
            if good: cand.append((gain, k, b, be == b))
    cand.sort(key=lambda z: -z[0]); return cand[:2]
out = []
for rule, g in T.groupby('rule'):
    for t in (2024, 2025, 2026):
        tr = g[g.yr < t]; te = g[g.yr == t]
        if len(te) == 0 or (tr.inst.value_counts() < 30).any(): continue
        pk = pick(tr, te, allowed); av = np.zeros(len(te), bool)
        for _, k, b, m in pk: av |= m
        for inst in te.inst.unique():
            mi = (te.inst == inst).values
            out.append(dict(rule=rule, t=t, inst=inst, 件数=int(mi.sum()), 見送り=int((mi & av).sum()), そのまま合計=te.v.values[mi].sum(), 避けたあと合計=te.v.values[mi & ~av].sum(), 避けた分の合計=te.v.values[mi & av].sum(),
                            避ける状況=' / '.join(f'{FEAT[k]}={b}' for _, k, b, _ in pk)))
O = pd.DataFrame(out); s = O.groupby('inst')[['件数', '見送り', 'そのまま合計', '避けたあと合計', '避けた分の合計']].sum()
s['避けた分1回平均'] = s.避けた分の合計 / s.見送り; s['そのまま1回平均'] = s.そのまま合計 / s.件数; s['避けたあと1回平均'] = s.避けたあと合計 / (s.件数 - s.見送り); print(s.round(1))
r = O.groupby('rule')[['そのまま合計', '避けたあと合計']].sum(); print('良くなったルールの割合', (r.避けたあと合計 > r.そのまま合計).mean(), len(r))
pd.to_pickle(dict(allowed=[FEAT[k] for k in allowed], F=F, fw=O, sum=s.reset_index()), '/home/claude/bs/g/rl_avoid2.pkl')
