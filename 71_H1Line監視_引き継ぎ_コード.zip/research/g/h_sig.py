"""H系ライン・MACD系ラインの全格子の売買を作る（分水嶺 g_sig と同じ形）。
入り方：線17本（H1/H4/D1Line、MACDmacd 4本、MACDsignal 4本、H系の山・谷 6本）×［抜け6・反発9・指値タッチ3］×向き2
      ＋ 線どうしのクロス 7組 × 判定足2（15・60分）× クロスの向き2 × 売買の向き2
決済48通り：利確4（次の線・0.25A・0.5A・無し）× 損切り3（線の0.1A先・0.25A先・無し）× 時間4（60分・240分・セッション終わり・週の終わり）
A ＝ 前日までの20日平均の日足値幅（近さ・利確・損切りの単位）。1つの入り方は1セッションに最初の合図だけ。
出力：hsig_{inst}_{fam}.npz、hdefs.csv
"""
import sys, numpy as np, pandas as pd, itertools
from numba import njit
sys.path.insert(0, '/home/claude/bs'); sys.path.insert(0, '/home/claude/bs/g')
import g_sig as G
from h_lines import NAMES, NL

KINDS = [('抜け', tf, b) for tf in (15, 30, 60) for b in (0.0, 0.05)] + \
        [('反発', tf, b) for tf in (15, 30, 60) for b in (0.0, 0.05, 0.1)] + \
        [('指値', 5, b) for b in (0.0, 0.05, 0.1)]
PAIRS = [('H1Line', 'H4Line'), ('H4Line', 'D1Line'), ('H1Line', 'D1Line'),
         ('macd 15m-1H', 'signal 15m-1H'), ('macd 1H-4H', 'signal 1H-4H'), ('macd 4H-1D', 'signal 4H-1D'), ('macd 1D-1W', 'signal 1D-1W')]
TPS = ['次の線', '0.25A', '0.5A', '無し']
SLS = ['線の0.1A先', '線の0.25A先', '無し']
TIMES = ['60分', '240分', 'セッション終わり', '週の終わり']
EXITS = list(itertools.product(range(4), range(3), range(4)))

def group_of(name):
    if name.startswith('macd'): return 'MACDmacd'
    if name.startswith('signal'): return 'MACDsignal'
    if '山' in name or '谷' in name: return 'Peakline'
    return 'H系'

def defs():
    rows = []
    for li, (k, tf, b), dr in itertools.product(range(NL), KINDS, (1, -1)):
        rows.append(dict(line=NAMES[li], grp=group_of(NAMES[li]), kind=k, tf=tf, b=b, dir=dr, a=li, bb=-1, cross=0))
    for (fa, sl), tf, cd, dr in itertools.product(PAIRS, (15, 60), (1, -1), (1, -1)):
        rows.append(dict(line=f'{fa}×{sl}', grp='クロス', kind='クロス' + ('上' if cd == 1 else '下') + ('順' if cd == dr else '逆'),
                         tf=tf, b=0.0, dir=dr, a=NAMES.index(fa), bb=NAMES.index(sl), cross=cd))
    return pd.DataFrame(rows)

@njit(cache=True)
def gen(o, h, l, c, pid, chk, th, tl, Lv, L2, A, kind, b, dr, cd, pend):
    n = len(o)
    out_i = np.empty(n, np.int64); out_e = np.empty(n); out_l = np.empty(n); k = 0
    pc = np.nan; pL = np.nan; pdf = np.nan; lastp = -1
    for i in range(n):
        L = Lv[i]; a = A[i]; p = pid[i]
        if kind == 2:  # 指値タッチ：足の始まりで分かっている線（1本前の足の終わりの値）
            if i > 0 and p != lastp and pid[i - 1] == p and not pend[i]:
                Lp = Lv[i - 1]
                if not np.isnan(Lp) and a > 0:
                    lim = Lp + b * a if dr == 1 else Lp - b * a
                    pcl = c[i - 1]
                    if dr == 1 and pcl > lim and l[i] <= lim:
                        out_i[k] = i; out_e[k] = min(o[i], lim); out_l[k] = Lp; k += 1; lastp = p
                    elif dr == -1 and pcl < lim and h[i] >= lim:
                        out_i[k] = i; out_e[k] = max(o[i], lim); out_l[k] = Lp; k += 1; lastp = p
            continue
        if not chk[i]:
            continue
        if kind == 3:  # クロス
            df = Lv[i] - L2[i]
            if p != lastp and not np.isnan(df) and not np.isnan(pdf) and a > 0 and not pend[i]:
                if (cd == 1 and pdf <= 0 and df > 0) or (cd == -1 and pdf >= 0 and df < 0):
                    out_i[k] = i; out_e[k] = c[i]; out_l[k] = c[i]; k += 1; lastp = p
            pdf = df
            continue
        if p != lastp and not np.isnan(L) and not np.isnan(pL) and a > 0 and not np.isnan(pc) and not pend[i]:
            hit = False
            if kind == 0:  # 抜け：前の判定足の終値が線の手前、今の終値が線の b×A 先
                if dr == 1:
                    hit = pc < pL and c[i] >= L + b * a
                else:
                    hit = pc > pL and c[i] <= L - b * a
            else:  # 反発：前の判定足の終値は線の b×A 先より向こう、判定足の中で線の b×A 以内まで来て、終値は線の手前
                if dr == 1:
                    hit = pc > pL + b * a and tl[i] <= L + b * a and c[i] > L
                else:
                    hit = pc < pL - b * a and th[i] >= L - b * a and c[i] < L
            if hit:
                out_i[k] = i; out_e[k] = c[i]; out_l[k] = L; k += 1; lastp = p
        pc = c[i]; pL = L
    return out_i[:k], out_e[:k], out_l[:k]

@njit(cache=True)
def evalx(o, h, l, c, si, se, dr, Lr, A, tpn, endP, endS):
    m = len(si); R = np.full((m, 48), np.nan, np.float32); XI = np.zeros((m, 48), np.int32)
    for q in range(m):
        i = si[q]; e = se[q]; d = dr; jP = endP[i]; jS = min(endS[i], jP)
        tp = np.empty(3); tp[0] = tpn[q]; tp[1] = e + d * 0.25 * A[q]; tp[2] = e + d * 0.5 * A[q]
        sl = np.empty(2); sl[0] = Lr[q] - d * 0.1 * A[q]; sl[1] = Lr[q] - d * 0.25 * A[q]
        tpi = np.full(3, -1, np.int64); tpx = np.zeros(3); sli = np.full(2, -1, np.int64); slx = np.zeros(2)
        for j in range(i + 1, jP + 1):
            for a in range(3):
                if tpi[a] < 0 and not np.isnan(tp[a]):
                    if (d == 1 and h[j] >= tp[a]) or (d == -1 and l[j] <= tp[a]):
                        tpi[a] = j; tpx[a] = max(o[j], tp[a]) if d == 1 else min(o[j], tp[a])
            for a in range(2):
                if sli[a] < 0:
                    if (d == 1 and l[j] <= sl[a]) or (d == -1 and h[j] >= sl[a]):
                        sli[a] = j; slx[a] = min(o[j], sl[a]) if d == 1 else max(o[j], sl[a])
        tend = np.empty(4, np.int64)
        tend[0] = min(i + 12, jS); tend[1] = min(i + 48, jP); tend[2] = jS; tend[3] = jP
        col = 0
        for a in range(4):
            for s in range(3):
                for t in range(4):
                    te = tend[t]; x = c[te]; xi = te
                    if s < 2 and sli[s] >= 0 and sli[s] <= xi:
                        xi = sli[s]; x = slx[s]
                    if a < 3 and tpi[a] >= 0 and tpi[a] < xi:  # 同じ足なら損切りを先に
                        xi = tpi[a]; x = tpx[a]
                    R[q, col] = d * (x - e); XI[q, col] = xi
                    col += 1
    return R, XI

def run(inst, fams):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz'))
    DF = defs(); DF.to_csv('/home/claude/bs/g/hdefs.csv', index_label='def')
    o, h, l, c = X['o'], X['h'], X['l'], X['c']; n = len(o)
    THL = {tf: G.tf_hl(X, tf) for tf in (5, 15, 30, 60)}
    endidx = {}
    for key in ['wk', 'ses']:
        e = np.nonzero(X['end_' + key])[0]
        endidx[key] = e[np.searchsorted(e, np.arange(n))]
    A = X['avg20'].astype(float)
    pid = X['pid_ses']; pend = X['end_ses']
    for fam in fams:
        H = np.load(f'/home/claude/bs/g/hl_{inst}_{fam}.npz'); LM = H['L'].astype(np.float64)
        S_def = []; S_i = []; S_e = []; S_R = []; S_tp = []; S_nt = []
        for di, r in DF.iterrows():
            kind = {'抜け': 0, '反発': 1, '指値': 2}.get(r.kind, 3)
            th, tl = THL[int(r.tf)]; chk = X[f'tf{int(r.tf)}']
            Lv = LM[:, int(r.a)]; L2 = LM[:, int(r.bb)] if r.bb >= 0 else Lv
            si, se, sl_ = gen(o, h, l, c, pid, chk, th, tl, Lv, L2, A, kind, float(r.b), int(r.dir), int(r.cross), pend)
            if len(si) == 0: continue
            dr = int(r.dir); Ai = A[si]
            M = LM[si]
            beyond = (M - se[:, None]) * dr > 0.05 * Ai[:, None]
            cand = np.where(beyond, np.abs(M - se[:, None]), np.inf).min(1)
            tpn = np.where(np.isfinite(cand), se + dr * cand, np.nan)
            R, XI = evalx(o, h, l, c, si, se, dr, sl_, Ai, tpn, endidx['wk'], endidx['ses'])
            nts = (X['pid_day'][XI] - X['pid_day'][si][:, None]).astype(np.int8)
            S_def.append(np.full(len(si), di, np.int32)); S_i.append(si); S_e.append(se); S_R.append(R); S_tp.append(tpn); S_nt.append(nts)
        np.savez(f'/home/claude/bs/g/hsig_{inst}_{fam}.npz', d=np.concatenate(S_def), i=np.concatenate(S_i), e=np.concatenate(S_e),
                 R=np.concatenate(S_R), tpn=np.concatenate(S_tp), nt=np.concatenate(S_nt))
        print(inst, fam, sum(len(x) for x in S_i), flush=True)

if __name__ == '__main__':
    run(sys.argv[1], sys.argv[2].split(','))
