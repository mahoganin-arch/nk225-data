"""3分足検証の評価。4つの確認（ミニ・CFD × 前半・後半）で、ランダムな時刻（同じ向き・手じまい・方向確認）との差と、損益そのものを見る。"""
import os, sys, numpy as np, pandas as pd
P = os.environ.get('PFX', 'm3')
sys.path.insert(0, '/home/claude/bs/g')
from m3_agg import FSETS, YRS
from m3_sig import EXITS, FILTERS
TR = pd.read_csv(f'/home/claude/bs/g/{P}_trigs.csv').iloc[:, 0].tolist()
FSN = ['なし' if not fs else '＋'.join(FILTERS[a] for a in fs) for fs in FSETS]
INST = ['fut', 'cfd']; ST = {'net': 0, 'nrm': 1, 'n13': 2}

def load(inst, fam):
    Z = dict(np.load(f'/home/claude/bs/g/{P}agg_{inst}_{fam}.npz')); return Z

def checks(fam, stat='nrm', nmin=30):
    """(fset, exit, td) ごとの 4つの確認の 平均・ランダム平均・件数"""
    out = {}
    for inst in INST:
        Z = load(inst, fam); s = ST[stat]
        c = Z['cnt'][:, None, :, :]  # fset,1,td,NB
        a = Z['sum'][s] / np.maximum(c, 1)
        cR = Z['cntR'][:, None, :, :]; aR = Z['sumR'][s] / np.maximum(cR, 1)
        td = np.arange(c.shape[2]) % 2
        aR = aR[:, :, td, :]; cRr = np.broadcast_to(cR[:, :, td, :], aR.shape)
        for h in (0, 1):
            out[(inst, h)] = (a[..., h], aR[..., h], np.broadcast_to(c[..., h], a[..., h].shape), cRr[..., h])
    return out

def table(fam, stat='nrm', nmin=30):
    C = checks(fam, stat)
    keys = list(C)
    A = np.stack([C[k][0] for k in keys]); R = np.stack([C[k][1] for k in keys]); N = np.stack([C[k][2] for k in keys]); NR = np.stack([C[k][3] for k in keys])
    D = A - R; ok = (N >= nmin).all(0) & (NR >= 50).all(0)
    F, E, T = np.nonzero(ok)
    df = pd.DataFrame({'fset': F, 'exit': E, 'td': T})
    for j, (inst, h) in enumerate(keys):
        nm = {'fut': 'ミニ', 'cfd': 'CFD'}[inst] + ('前半' if h == 0 else '後半')
        df[f'{nm} 平均'] = A[j][ok]; df[f'{nm} 差'] = D[j][ok]; df[f'{nm} 件数'] = N[j][ok]
    df['差の最小'] = D.min(0)[ok]; df['平均の最小'] = A.min(0)[ok]; df['件数最小'] = N.min(0)[ok]
    df['trig'] = df.td // 2; df['dir'] = np.where(df.td % 2 == 1, 1, -1)
    return df

def names(df):
    df = df.copy(); df.insert(0, 'トリガー', [TR[t] for t in df.trig]); df.insert(1, '売買', df.dir.map({1: '買い', -1: '売り'}))
    df.insert(2, '手じまい', [EXITS[e] for e in df.exit]); df.insert(3, '方向確認', [FSN[f] for f in df.fset]); return df

if __name__ == '__main__':
    df = table(sys.argv[1] if len(sys.argv) > 1 else 'W')
    print(len(df), (df['差の最小'] > 0).mean(), (df['平均の最小'] > 0).mean())
