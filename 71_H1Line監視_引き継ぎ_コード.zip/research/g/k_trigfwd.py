"""トリガーの前向き：確かめる年 t ごとに、t より前の年を2つに分け、2商品×2期間の4つすべてでランダムより良い方向確認の割合（頑丈さ）が高いトリガー上位5つを選び、
t 年に方向確認なしで売買したときの、ランダムとの差・1回平均（手じまい36通りの平均）を見る。本物とでたらめ（線を使うトリガーだけ）。"""
import sys, numpy as np, pandas as pd
sys.path.insert(0,'/home/claude/bs/g')
from k_formfwd import yearly, RY, DF, YEARS
out=[]; picks={}
for fam in ['W','r0','r1','r2','r3','r4','r5']:
    D={}
    for inst in ['fut','cfd']:
        M,N=yearly(inst,fam); dirs=DF.dir.values[M.index.get_level_values(0)]
        rk=pd.MultiIndex.from_arrays([dirs,M.index.get_level_values(1)]); Rv=RY[inst].reindex(rk).values
        D[inst]=(pd.DataFrame(M.values-Rv,index=M.index,columns=YEARS),M,N)
    common=D['fut'][0].index.intersection(D['cfd'][0].index)
    D={k:(a.loc[common],b.loc[common],c.loc[common]) for k,(a,b,c) in D.items()}
    for t in range(2020,2027):
        ys=[y for y in YEARS if y<t]; k=len(ys); h1=ys[:(k+1)//2]; h2=ys[(k+1)//2:]
        pos=None; okall=None
        for inst in ['fut','cfd']:
            Dm,M,N=D[inst]
            for hh in (h1,h2):
                w=N[[f'n{y}' for y in hh]].values; v=np.nan_to_num(Dm[hh].values)
                s=(v*w).sum(1)/np.maximum(w.sum(1),1); ok=w.sum(1)>=15
                p=(s>0)&ok; pos=p if pos is None else pos&p; okall=ok if okall is None else okall&ok
        idx=D['fut'][0].index
        T=pd.DataFrame({'pos':pos,'ok':okall},index=idx).reset_index()
        T=T[T.ok]; T['grp']=DF.grp.values[T['def']]; T=T[T.grp!='インジ']
        sc=T.groupby('def').pos.mean().sort_values(ascending=False)
        top=list(sc.index[:5]); picks[(fam,t)]=[(DF.trig[d],DF.dir[d],round(sc[d],2)) for d in top]
        for inst in ['fut','cfd']:
            Dm,M,N=D[inst]
            v=[(Dm.loc[(d,0),t],M.loc[(d,0),f'a{t}'],N.loc[(d,0),f'n{t}']) for d in top if (d,0) in Dm.index]
            v=[x for x in v if np.isfinite(x[0]) and x[2]>0]
            w=np.array([x[2] for x in v])
            out.append(dict(fam=fam,t=t,inst=inst,差=np.average([x[0] for x in v],weights=w),成績=np.average([x[1] for x in v],weights=w),件数=w.sum()))
    print(fam,flush=True)
O=pd.DataFrame(out); O.to_pickle('/home/claude/bs/g/ktrigfwd.pkl'); pd.to_pickle(picks,'/home/claude/bs/g/ktrigfwd_picks.pkl')
pd.set_option('display.width',250)
print(O.pivot_table(index='fam',columns='inst',values='差',aggfunc='mean').round(1))
print(O[O.fam=='W'].pivot_table(index='t',columns='inst',values=['差','成績','件数']).round(1))
for t in range(2020,2027): print(t,picks[('W',t)])
