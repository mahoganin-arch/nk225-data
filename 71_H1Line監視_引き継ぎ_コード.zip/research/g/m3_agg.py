"""3分足検証の集計。区切り：前半・後半（CFD 2023-07、ミニ 2025-04 で分ける）＋ 年 2020〜2026（9区切り）。
方向確認：なし＋15つ＋2つの組み合わせ105 ＝121。損益：net・nrm・n13（h_agg と同じ）。
出力：m3agg_{inst}_{fam}.npz（本物のトリガー cnt/sum と、ランダムな時刻 cntR/sumR）
"""
import os, sys, itertools, numpy as np, pandas as pd
P = os.environ.get('PFX', 'm3')
sys.path.insert(0, '/home/claude/bs/g')
import h_agg
from m3_sig import FILTERS
NF = len(FILTERS)
FSETS = [()] + [(a,) for a in range(NF)] + list(itertools.combinations(range(NF), 2))
MASKS = np.array([sum(1 << a for a in fs) for fs in FSETS], np.int64)
if P == 'm3':
    SPLIT = {'cfd': pd.Timestamp('2023-07-01', tz='Asia/Tokyo'), 'fut': pd.Timestamp('2025-04-01', tz='Asia/Tokyo')}; YRS = list(range(2020, 2027)); NB = 2 + len(YRS)
else:
    SPLIT = {'cfd': pd.Timestamp('2023-01-01', tz='Asia/Tokyo'), 'fut': pd.Timestamp('2023-01-01', tz='Asia/Tokyo')}; YRS = list(range(2018, 2027)); NB = 2 + len(YRS)

def buckets(inst, X, i):
    t = pd.to_datetime(X['t'][i], unit='s', utc=True).tz_convert('Asia/Tokyo')
    half = (t >= SPLIT[inst]).astype(int); yr = t.year.values - YRS[0]
    return half, yr

def agg(inst, S, X, ngroup, gidx):
    R = S['R'].astype(np.float64); cost = h_agg.COST[inst]; sc = (h_agg.REF / S['e'])[:, None]
    net = R - cost; nrm = R * sc - cost; n13 = R * sc - 13.0  # セッション内で必ず手じまうので CFD の金利調整はかからない
    half, yr = buckets(inst, X, S['i']); f = S['f'].astype(np.int64)
    cnt = np.zeros((len(FSETS), ngroup, NB), np.float32)
    sm = np.zeros((3, len(FSETS), 36, ngroup, NB), np.float32); win = np.zeros((len(FSETS), 36, ngroup, NB), np.float32)
    for k, msk in enumerate(MASKS):
        sel = (f & msk) == msk
        g = gidx[sel]; hb = half[sel]; yb = yr[sel] + 2
        Ms = np.concatenate([net[sel], nrm[sel], n13[sel], (net[sel] > 0)], 1)
        for bk in (hb, yb):
            key = g * NB + bk; cnt[k] += np.bincount(key, minlength=ngroup * NB).reshape(ngroup, NB)
            if len(key) == 0: continue
            o = np.argsort(key, kind='stable'); kk = key[o]; u, st = np.unique(kk, return_index=True)
            r = np.add.reduceat(Ms[o], st, axis=0); full = np.zeros((ngroup * NB, 144)); full[u] = r
            full = full.reshape(ngroup, NB, 4, 36).transpose(2, 3, 0, 1)
            sm[:, k] += full[:3]; win[k] += full[3]
    return cnt, sm, win

def run(inst, fam):
    X = dict(np.load(f'/home/claude/bs/g/{P}_{inst}.npz'))
    S = dict(np.load(f'/home/claude/bs/g/{P}sig_{inst}_{fam}.npz')); NT = int(S['trig'].max()) + 1
    c, s, w = agg(inst, S, X, NT * 2, S['trig'].astype(np.int64) * 2 + (S['d'] > 0))
    Q = dict(np.load(f'/home/claude/bs/g/{P}rand_{inst}_{fam}.npz'))
    cR, sR, wR = agg(inst, Q, X, 2, (Q['d'] > 0).astype(np.int64))
    np.savez_compressed(f'/home/claude/bs/g/{P}agg_{inst}_{fam}.npz', cnt=c, sum=s, win=w, cntR=cR, sumR=sR, winR=wR)
    print(inst, fam, flush=True)

if __name__ == '__main__':
    for inst in sys.argv[1].split(','):
        for fam in sys.argv[2].split(','):
            run(inst, fam)
