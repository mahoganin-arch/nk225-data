import sys; sys.path.insert(0,'/home/claude/bs/g')
import numpy as np, pandas as pd
from k_form import form, rand_form, H
DF=pd.read_csv('/home/claude/bs/g/kdefs.csv',index_col=0)
RF={inst:rand_form(inst) for inst in ['fut','cfd']}
res={}
for fam in ['W','r0','r1','r2','r3','r4','r5']:
    out=[]
    for inst in ['fut','cfd']:
        F=form(inst,fam); F['dir']=DF.dir.values[F['def']]; F=F.merge(RF[inst],on=['dir','fset'],how='left'); F['inst']=inst; out.append(F)
    O=pd.concat(out)
    for h in H: O[f'差_{h}']=O[f'a_{h}']-O[f'r_{h}']
    P=O.pivot_table(index=['def','fset'],columns='inst',values=['差_前半','差_後半','n_前半','n_後半'])
    P.columns=[f'{a}_{b}' for a,b in P.columns]; P=P.dropna().reset_index()
    P['差の最小']=P[['差_前半_fut','差_後半_fut','差_前半_cfd','差_後半_cfd']].min(axis=1)
    P['件数最小']=P[['n_前半_fut','n_後半_fut','n_前半_cfd','n_後半_cfd']].min(axis=1)
    P['grp']=DF.grp.values[P['def']]
    P=P[(P['件数最小']>=30)&(P.grp!='インジ')]
    res[fam]=P
    q=P['差の最小']; print(fam,len(P),'4つともプラス',round((q>0).mean(),3),'上位1%',round(q.quantile(.99),1),'上位0.1%',round(q.quantile(.999),1),'最大',round(q.max(),1),flush=True)
pd.to_pickle(res,'/home/claude/bs/g/kformnull.pkl')
