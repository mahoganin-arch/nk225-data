"""Excel の前に作る中間ファイル：form_year.pkl（形×線の年ごとの1回平均）、pk_exits.pkl（本命の決済48通り × 本物・でたらめ）。"""
import sys; sys.path.insert(0, '/home/claude/bs/g')
import numpy as np, pandas as pd, h_form, h_pk, h_sig as G
from h_agg import YEARS
keys = ['grp', 'line', 'kind', 'dir']; Y = {}
for inst in ['fut', 'cfd']:
    A = h_form.base_rows(inst)
    S = A.groupby(keys + ['fam'])[[f'{c}{y}' for c in ['n', 'nrm'] for y in YEARS]].sum()
    Y[inst] = (pd.DataFrame({y: S[f'nrm{y}'] / S[f'n{y}'] for y in YEARS}), pd.DataFrame({y: S[f'n{y}'] for y in YEARS}))
pd.to_pickle(Y, '/home/claude/bs/g/form_year.pkl')
fams = ['W', 'r0', 'r1', 'r2', 'r3', 'r4', 'r5']; rows = []
for inst in ['fut', 'cfd']:
    for line in ['H1Line 山', 'H1Line 谷']:
        for ex, (a, b_, c) in enumerate(G.EXITS):
            v = {f: h_pk.trades(inst, f, line, '反発', 15, 0.05, ex).nrm.mean() for f in fams}
            nul = np.array([v[f] for f in fams[1:]])
            rows.append(dict(inst=inst, line=line, tp=G.TPS[a], sl=G.SLS[b_], tm=G.TIMES[c], real=v['W'], null=nul.mean(), z=(v['W'] - nul.mean()) / nul.std()))
pd.DataFrame(rows).to_pickle('/home/claude/bs/g/pk_exits.pkl')
