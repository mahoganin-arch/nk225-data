"""H系ライン・MACD系ラインを15分足で計算し、5分足に「その足の終わりで分かっている値」として載せる。
fam='W'：本物。fam='r0'〜：でたらめ（本物の線に、滑らかなでたらめのずれを足した線。ずれの大きさは
 その線と価格の距離の中央値に合わせる。山・谷の水平線とクロスも、でたらめな線から作り直す）。
出力：/home/claude/bs/g/hl_{inst}_{fam}.npz
  L   : (n, NL) 5分足 i の終わりで分かっている線の値（15分足の区切りでは、その15分足の終値を入れた値）
  slope: (n, 3) H1/H4/D1Line の傾きの符号（同じく i の終わりで分かっている）
"""
import sys, numpy as np, pandas as pd
from scipy.signal import lfilter
sys.path.insert(0, '/home/claude/bs')
import eng2

SIG, OMG, RE, ZR = 0.12168, 0.06562, 0.17286, 0.05151
HL = [('H1Line', 4), ('H4Line', 16), ('D1Line', 96)]
MAC = [('15m-1H', 1), ('1H-4H', 4), ('4H-1D', 16), ('1D-1W', 96)]
NAMES = [n for n, _ in HL] + [f'macd {n}' for n, _ in MAC] + [f'signal {n}' for n, _ in MAC] + \
        [f'{n} {k}' for n, _ in HL for k in ('山', '谷')]
SPAN = dict([(n, 12 * m) for n, m in HL] + [(f'macd {n}', 12 * m) for n, m in MAC] + [(f'signal {n}', 26 * m) for n, m in MAC])
NL = len(NAMES)

def hfilt(x, m):
    R = np.exp(-SIG / m); th = OMG / m; A1 = -2 * R * np.cos(th); A2 = R * R; zr = np.exp(-ZR / m)
    gA = (1 + A1 + A2) / (1 - zr); u = x - x[0]
    w = lfilter([gA, -gA * zr], [1, A1, A2], u)
    p = np.exp(-RE / m); B1 = -2 * p; B2 = p * p
    return lfilter([1 + B1 + B2], [1, B1, B2], w) + x[0]

def ema(x, n):
    a = 2 / (n + 1)
    return lfilter([a], [1, -(1 - a)], x, zi=[(1 - a) * x[0]])[0]

def bars15(d):
    k = d.t.dt.floor('15min')
    g = d.groupby(k, sort=True)
    B = g.agg(c=('c', 'last'))
    last_i = g.apply(lambda s: s.index[-1]).values  # 15分足の最後の5分足の位置
    return B, last_i

def peaks(L):
    """傾きの向きが変わった点の値（山・谷）。k 本目の終わりで分かる値。"""
    d = np.diff(L, prepend=np.nan)
    up = d > 0; dn = d < 0
    pk = np.full(len(L), np.nan); vl = np.full(len(L), np.nan)
    turn_pk = np.r_[False, dn[1:] & (d[:-1] >= 0)]; turn_vl = np.r_[False, up[1:] & (d[:-1] <= 0)]
    pk[turn_pk] = L[np.nonzero(turn_pk)[0] - 1]; vl[turn_vl] = L[np.nonzero(turn_vl)[0] - 1]
    return pd.Series(pk).ffill().values, pd.Series(vl).ffill().values, np.sign(np.nan_to_num(d))

def build(inst, fam):
    B = eng2.base(inst); d = B['d']
    b15, last_i = bars15(d)
    x = b15.c.values.astype(float); n15 = len(x)
    lines = {}
    for nm, m in HL: lines[nm] = hfilt(x, m)
    for nm, m in MAC:
        e12 = ema(x, 12 * m); e26 = ema(x, 26 * m)
        lines[f'macd {nm}'] = e12
        lines[f'signal {nm}'] = e26 + ema(e12 - e26, 9 * m)
    if fam != 'W':
        rng = np.random.default_rng(777 * int(fam[1:]) + (0 if inst == 'fut' else 1))
        # 日足の平均値幅（15分足の位置に）
        P, _ = B['day']; avg20 = (P.h - P.l).rolling(20).mean().shift(1)
        pid15 = d['day'].values[last_i]
        A15 = pd.Series(pid15).map(pd.Series(avg20.values, index=P.index)).values
        for nm in list(lines):
            L = lines[nm]; s = SPAN[nm]
            z = rng.standard_normal(n15)
            z = ema(ema(z, s), s); z = (z - z.mean()) / z.std()
            dist = np.abs(x - L) / A15
            c = np.nanmedian(dist[int(3 * s):]) if np.isfinite(dist[int(3 * s):]).any() else 0.3
            lines[nm] = L + c * np.nan_to_num(A15, nan=np.nanmedian(A15)) * z
    slopes = []
    for nm, _ in HL:
        pk, vl, sg = peaks(lines[nm]); lines[f'{nm} 山'] = pk; lines[f'{nm} 谷'] = vl; slopes.append(sg)
    M15 = np.stack([lines[k] for k in NAMES], 1)
    S15 = np.stack(slopes, 1)
    # 5分足へ：i が15分足の最後の足ならその15分足の値、そうでなければ1つ前の15分足の値
    n = len(d); k15 = np.searchsorted(last_i, np.arange(n))  # i を含む15分足の番号
    is_last = np.zeros(n, bool); is_last[last_i] = True
    idx = np.where(is_last, k15, k15 - 1)
    ok = idx >= 0
    L = np.full((n, NL), np.nan, np.float32); L[ok] = M15[idx[ok]]
    SL = np.zeros((n, 3), np.int8); SL[ok] = S15[idx[ok]]
    # 立ち上がり（ならし期間）：2018年より前は使わない
    warm = d.t.values < np.datetime64('2018-01-01T00:00')
    L[warm] = np.nan
    np.savez_compressed(f'/home/claude/bs/g/hl_{inst}_{fam}.npz', L=L, slope=SL)
    print(inst, fam, n, flush=True)

if __name__ == '__main__':
    for inst in sys.argv[1].split(','):
        for fam in sys.argv[2].split(','):
            build(inst, fam)
