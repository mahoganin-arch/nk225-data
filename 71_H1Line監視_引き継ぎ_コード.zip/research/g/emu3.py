"""Pine 2026-10-28c（売りは週の線が月の線の上だけ・売りの重なり）を Python で書き直して確かめる。
1) 売りの条件を当てた合図が、研究（同じ条件）の合図と一致するか
2) 売りの重なり（★）の回数と成績が、研究の重なりの調べと合うか
3) 点検パネル用：アラートのルールの1年あたりの合図の数、1日あたりの1時間足の数
4) 検算用：15分足ごとの内部の値（TradingView から書き出した値と照らし合わせる元）
"""
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs'); sys.path.insert(0, '/home/claude/bs/g')
import emu, emu2
from emu3_run import run_all
from tvday import tv_dup_at
from rs3b import fast_feats
ALERT_BUY = [1, 3, 7, 12, 22, 27, 28, 29, 30, 31]; ALERT_SELL = [5, 11, 32, 33, 34]; CORE = [5, 11, 32]
def build_all(inst):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz'))
    B = emu.build(inst, 'clock'); K = np.load(f'/home/claude/bs/g/kind_{inst}_W.npz'); B['is15'] = K['is15']
    tstart = pd.Series(X['tm']).groupby(np.cumsum(np.r_[0, K['is15'][:-1]])).first().values[:len(B['c'])]
    g60, end60, G = emu.hour_bars(B['o'], B['h'], B['l'], B['c'], tstart, B['sesId'], 'clock'); B['end60'] = end60; B['tstart'] = tstart
    E = emu2.extra(B, inst, X)
    cal = X['mk_sqw_minor'][B['i5']].astype(bool)
    S = emu.signals(B, cal); S.update(emu2.sigs(B, E))
    dUpTV = tv_dup_at(inst, B['tend']); B['dUpTV'] = dUpTV
    for r in ALERT_SELL: S[r] = S[r] & dUpTV
    n = len(B['c'])
    def ov(rules):
        cnt = np.zeros(n, int)
        for r in rules:
            sig = S[r].astype(int); cs = np.cumsum(np.r_[0, sig]); cnt += ((cs[np.arange(1, n + 1)] - cs[np.maximum(np.arange(1, n + 1) - 5, 0)]) > 0).astype(int)
        return cnt
    B['buyOv'] = ov(ALERT_BUY); B['sellOv'] = ov(ALERT_SELL)
    return X, B, E, S
if __name__ == '__main__':
    OUT = {}; REFV = {}
    for inst in ['fut', 'cfd']:
        X, B, E, S = build_all(inst); yr = B['yr']; L = 'ミニ' if inst == 'fut' else 'CFD'
        # 1) 研究の合図（同じ条件）と比べる
        T = pickle.load(open('/home/claude/bs/g/ov3_research.pkl', 'rb'))
        rows = []
        for r in ALERT_SELL:
            i5, x5, v, ry = T[(inst, r)]; F, nm = fast_feats(inst, i5, -1); up = F[:, nm.index('日足 週の線が月の線の上')] == 1
            rs = set(i5[up & (ry >= 2020)].tolist()); es = set(B['i5'][S[r] & (yr >= 2020)].tolist())
            rows.append(dict(商品=L, No=r, 研究の合図=len(rs), Pineの合図=len(es), 一致=len(rs & es)))
        # 2) 売りの重なり：入った足で★がつくか（Pine と同じく、ポジションを持っていない時だけ入る）
        for r in CORE:
            ex = (emu.run_rule(B, S[r], r, 5.0 if inst == 'fut' else 7.0) if r == 5 else emu2.run(B, E, S[r], r, 5.0 if inst == 'fut' else 7.0))
            pos = {v: k for k, v in enumerate(B['i5'])}; ib = np.array([pos[i] for i in ex.i5.values]); st = (B['sellOv'][ib] - 1) >= 2
            ey = X['yr'][ex.i5.values]; m = ey >= 2020
            rows[[x['No'] for x in rows].index(r)].update({'入った回数': int(m.sum()), '1回平均': ex.v[m].mean(), '★の回数': int((st & m).sum()), '★の1回平均': ex.v[st & m].mean(), '★なしの1回平均': ex.v[~st & m].mean(),
                                                            '★の前半': ex.v[st & m & (ey <= 2022)].mean(), '★の後半': ex.v[st & m & (ey >= 2023)].mean()})
        OUT[(inst, 'cmp')] = pd.DataFrame(rows)
        # 3) 1年あたりの合図の数（2020〜2026、アラートのルール）と1日あたりの1時間足の数
        yrs = (B['tend'][yr >= 2020][-1] - B['tend'][yr >= 2020][0]) / (365.25 * 86400)
        OUT[(inst, 'rate')] = {r: S[r][yr >= 2020].sum() / yrs for r in ALERT_BUY + ALERT_SELL}
        jd = pd.to_datetime(B['tend'], unit='s', utc=True).tz_convert('Asia/Tokyo')
        day = ((B['tend'] - (6 * 3600 if inst == 'fut' else 7 * 3600) + 9 * 3600) // 86400)
        hp = pd.Series(B['end60'].astype(int)).groupby(day).sum(); OUT[(inst, 'hours')] = hp[hp > 0].median(), hp[hp > 0].mean()
        OUT[(inst, 'strongS_rate')] = sum(((B['sellOv'] - 1) >= 2)[S[r] & (yr >= 2020)].sum() for r in CORE) / yrs
        # 4) 検算の元
        n = len(B['c']); pos = {v: k for k, v in enumerate(B['i5'])}; pA = np.zeros(n); pB = np.zeros(n); TR = {}
        for r in ALERT_BUY + ALERT_SELL:
            tr = run_all(B, E, S[r], r, 5.0 if inst == 'fut' else 7.0); TR[r] = tr; ip = np.zeros(n, bool)
            for a, b in zip(tr.i5.values, tr.x5.values): ip[pos[a]:pos[b]] = True
            if r < 19: pA += ip * 2.0 ** r
            else: pB += ip * 2.0 ** (r - 19)
        OUT[(inst, 'trades')] = TR
        mA = np.zeros(len(B['c'])); mB = np.zeros(len(B['c']))
        for r in ALERT_BUY + ALERT_SELL:
            if r < 19: mA += S[r] * 2.0 ** r
            else: mB += S[r] * 2.0 ** (r - 19)
        REFV[inst] = dict(t=B['tstart'], h1=B['h1'], h4=B['h4'], d1=B['d1'], A=B['A'], h1pk=B['h1pk'], h1vl=B['h1vl'], mc1=B['mc1'], sg1=B['sg1'], mc96=E['mc96'], sg4=E['sg4'], sk=E['sk'],
                          cnt=B['cnt'], agree=E['agree'], dUp=B['dUpTV'].astype(float), sk60=E['sk60c'], sd60=E['sd60c'], buyOv=B['buyOv'], sellOv=B['sellOv'], mA=mA, mB=mB, pA=pA, pB=pB, c=B['c'])
        print(inst, flush=True)
    pickle.dump(OUT, open('/home/claude/bs/g/emu3.pkl', 'wb')); pickle.dump(REFV, open('/home/claude/bs/g/kensan_ref.pkl', 'wb'))
    pd.set_option('display.width', 250)
    for inst in ['fut', 'cfd']:
        print(OUT[(inst, 'cmp')].round(0).to_string()); print({k: round(v, 1) for k, v in OUT[(inst, 'rate')].items()}, '1日の1時間足', OUT[(inst, 'hours')], '★/年', round(OUT[(inst, 'strongS_rate')], 1))
