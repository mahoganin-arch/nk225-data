import sys; sys.path.insert(0,'/home/claude/bs/g')
import numpy as np, pandas as pd, g_ovl, h_pk, h_sig as G
EX=G.EXITS.index((3,1,2))
def ours():
    out=[]
    for inst,lab in [('fut','H1山押し目買い（ミニ）'),('cfd','H1山押し目買い（CFD）')]:
        T=h_pk.trades(inst,'W','H1Line 山','反発',15,0.05,EX)
        out.append(pd.DataFrame({'date':(T.t-pd.Timedelta(hours=6,minutes=5)).dt.date,'pnl':T.nrm.values,'src':lab}))
    B=pd.read_pickle('/home/claude/bs/g/bunsui_cand.pkl')
    for inst,lab in [('fut','分水嶺 日の線上抜け（ミニ）'),('cfd','分水嶺 日の線上抜け（CFD）')]:
        b=B[B.inst==inst]; out.append(pd.DataFrame({'date':(b.t-pd.Timedelta(hours=6,minutes=5)).dt.date,'pnl':b.nrm.values,'src':lab}))
    return pd.concat(out)
if __name__=='__main__':
    P=g_ovl.combine(ours()).fillna(0)
    P.to_pickle('/home/claude/bs/g/ovl.pkl')
    def dd(s): c=s.cumsum(); return float((c.cummax()-c).max())
    rows=[]
    for c in P.columns: rows.append(dict(src=c,日数=int((P[c]!=0).sum()),合計=P[c].sum(),最大DD=dd(P[c])))
    print(pd.DataFrame(rows).round(0).to_string())
    print(P.corr().round(2).to_string())
    combos={'窓埋め＋寄り天②':['窓埋め','寄り天②'],
            '＋分水嶺（ミニ）':['窓埋め','寄り天②','分水嶺 日の線上抜け（ミニ）'],
            '＋H1山（ミニ）':['窓埋め','寄り天②','H1山押し目買い（ミニ）'],
            '＋分水嶺＋H1山（ミニ）':['窓埋め','寄り天②','分水嶺 日の線上抜け（ミニ）','H1山押し目買い（ミニ）'],
            '＋分水嶺＋H1山（CFD）':['窓埋め','寄り天②','分水嶺 日の線上抜け（CFD）','H1山押し目買い（CFD）']}
    for k,v in combos.items():
        s=P[v].sum(1); print(k, round(s.sum()), round(dd(s)), round(s.sum()/dd(s),1))
    both=((P['H1山押し目買い（ミニ）']!=0)&(P['分水嶺 日の線上抜け（ミニ）']!=0)).sum(); print('同じ日（ミニ）',both)
