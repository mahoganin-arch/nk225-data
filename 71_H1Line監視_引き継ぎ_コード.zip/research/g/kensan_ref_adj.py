"""TradingView の「つなぎ足の調整（バックアジャスト）」に合わせた検算の元を作る。
限月の乗り換えの時刻より前の値段を、つなぎの差だけずらす（研究のデータは調整なし）。
使い方：python3 kensan_ref_adj.py fut 2026-09-10T15:00 175
"""
import sys, numpy as np, pandas as pd, pickle
inst, cut, gap = sys.argv[1], sys.argv[2], float(sys.argv[3])
X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz'))
tc = int(pd.Timestamp(cut, tz='Asia/Tokyo').timestamp()); m = X['tm'] < tc
for k in ['o', 'h', 'l', 'c']: X[k] = np.where(m, X[k] + gap, X[k])
np.savez(f'/home/claude/bs/g/data_{inst}_adj.npz', **X)
_load = np.load
def load2(p, *a, **kw):
    p = str(p)
    if p.endswith(f'/data_{inst}.npz'): p = p.replace(f'/data_{inst}.npz', f'/data_{inst}_adj.npz')
    return _load(p, *a, **kw)
np.load = load2
sys.path.insert(0, '/home/claude/bs'); sys.path.insert(0, '/home/claude/bs/g')
import emu3
from emu3_run import run_all
X2, B, E, S = emu3.build_all(inst)
n = len(B['c']); pos = {v: k for k, v in enumerate(B['i5'])}; pA = np.zeros(n); pB = np.zeros(n); mA = np.zeros(n); mB = np.zeros(n)
for r in emu3.ALERT_BUY + emu3.ALERT_SELL:
    tr = run_all(B, E, S[r], r, 5.0 if inst == 'fut' else 7.0); ip = np.zeros(n, bool)
    for a, b in zip(tr.i5.values, tr.x5.values): ip[pos[a]:pos[b]] = True
    if r < 19: pA += ip * 2.0 ** r; mA += S[r] * 2.0 ** r
    else: pB += ip * 2.0 ** (r - 19); mB += S[r] * 2.0 ** (r - 19)
REF = pickle.load(open('/home/claude/bs/g/kensan_ref.pkl', 'rb'))
REF[inst + '_adj'] = dict(t=B['tstart'], h1=B['h1'], h4=B['h4'], d1=B['d1'], A=B['A'], h1pk=B['h1pk'], h1vl=B['h1vl'], mc1=B['mc1'], sg1=B['sg1'], mc96=E['mc96'], sg4=E['sg4'], sk=E['sk'],
                          cnt=B['cnt'], agree=E['agree'], dUp=B['dUpTV'].astype(float), sk60=E['sk60c'], sd60=E['sd60c'], buyOv=B['buyOv'], sellOv=B['sellOv'], mA=mA, mB=mB, pA=pA, pB=pB, c=B['c'])
pickle.dump(REF, open('/home/claude/bs/g/kensan_ref.pkl', 'wb')); print('ok', inst + '_adj')
