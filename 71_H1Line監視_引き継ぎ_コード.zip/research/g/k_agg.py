"""組み合わせの集計：トリガー × 手じまい36 × 方向確認（なし・1つ・2つの組み合わせ）× 年（2018〜2026）。
損益は h_agg と同じ3種（net 実コスト・nrm そろえた・n13 13円）。合計 n≥20 だけ残す。出力：kagg_{inst}_{fam}.parquet
"""
import sys, itertools, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
import h_agg
from k_sig import FILTERS
YEARS = list(range(2018, 2027)); NY = len(YEARS)
NF = len(FILTERS)
FSETS = [()] + [(a,) for a in range(NF)] + list(itertools.combinations(range(NF), 2))
MASKS = np.array([sum(1 << a for a in fs) for fs in FSETS], np.int64)

def run(inst, fam):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); S = dict(np.load(f'/home/claude/bs/g/ksig_{inst}_{fam}.npz'))
    net, nrm, n13 = h_agg.pnl(inst, S)
    yi = X['yr'][S['i']] - YEARS[0]; f = S['f'].astype(np.int64)
    order = np.argsort(S['d'], kind='stable'); ds = S['d'][order]; bnd = np.r_[0, np.nonzero(np.diff(ds))[0] + 1, len(ds)]
    blocks = []; meta = []
    for a, b in zip(bnd[:-1], bnd[1:]):
        idx = order[a:b]; di = int(S['d'][idx[0]])
        Y = np.zeros((len(idx), NY)); Y[np.arange(len(idx)), yi[idx]] = 1
        nt_, ne_, nr_, nq_ = net[idx], nrm[idx], n13[idx], f[idx]
        for k, msk in enumerate(MASKS):
            sel = (nq_ & msk) == msk
            if sel.sum() < 20: continue
            Ys = Y[sel]; x = nt_[sel]; z = ne_[sel]; w = nr_[sel]
            cnt = Ys.sum(0)  # 年ごとの件数（全部の決済で同じ）
            parts = [np.repeat(cnt[None, :], 36, 0), (Ys.T @ x).T, (Ys.T @ z).T, (Ys.T @ w).T,
                     (Ys.T @ np.where(x > 0, x, 0)).T, (Ys.T @ np.where(x < 0, -x, 0)).T, (Ys.T @ (x > 0)).T]
            blocks.append(np.concatenate(parts, 1).astype(np.float32))
            meta.append(np.stack([np.full(36, di), np.arange(36), np.full(36, k)], 1).astype(np.int16))
    M = np.concatenate(blocks); Me = np.concatenate(meta)
    cols = [f'{s}{y}' for s in ['n', 'net', 'nrm', 'n13', 'pos', 'neg', 'win'] for y in YEARS]
    A = pd.DataFrame(M, columns=cols)
    for j, nm in enumerate(['def', 'exit', 'fset']): A.insert(j, nm, Me[:, j])
    A.to_parquet(f'/home/claude/bs/g/kagg_{inst}_{fam}.parquet')
    pd.DataFrame({'fset': range(len(FSETS)), 'name': ['なし' if not fs else '＋'.join(FILTERS[a] for a in fs) for fs in FSETS], 'k': [len(fs) for fs in FSETS]}).to_csv('/home/claude/bs/g/kfsets.csv', index=False)
    print(inst, fam, len(A), flush=True)

if __name__ == '__main__':
    run(sys.argv[1], sys.argv[2])
