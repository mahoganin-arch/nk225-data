"""②：年をまたいで安定した条件を、全期間で固定して当てはめる（ルールとランダムの両方）。v3 と同じ基準で判定。"""
import sys, pickle, numpy as np, pandas as pd, numba
sys.path.insert(0, '/home/claude/bs/g')
import rs3
@numba.njit(cache=True)
def _seq(i5, x5):
    o = np.argsort(i5, kind='mergesort'); out = np.empty(len(o), np.int64); n = 0; last = -1
    for q in o:
        if i5[q] > last:
            out[n] = q; n += 1; last = x5[q]
    return out[:n]
def seqf(i5, x5): return _seq(np.asarray(i5, np.int64), np.asarray(x5, np.int64))
rs3.seq = seqf
from rs3 import one_stats, rand_stats, compare
import rs3b
from rs3b import fast_feats
FIX = [('SQ週を避ける', 'avoid', [('SQ週', 1)]), ('月末月初を避ける', 'avoid', [('月末月初', 1)]), ('休日の前後を避ける', 'avoid', [('休日の前後', 1)]),
       ('SQ週と月末月初を避ける', 'avoid', [('SQ週', 1), ('月末月初', 1)]),
       ('週の線が月の線の上だけ', 'require', [('日足 週の線が月の線の上', 1)]), ('週の線が月の線の下だけ', 'require', [('日足 週の線が月の線の上', 0)]),
       ('週の線が月の線の上だけ＋SQ週を避ける', 'mix', [('日足 週の線が月の線の上', 1)], ),
       ('上位足に下向きなしだけ', 'require', [('下向きの上位足の数(1H・4H・日足)', 0)]), ('上位足に下向きが1つ以上', 'avoid', [('下向きの上位足の数(1H・4H・日足)', 0)])]
def mask(F, names, fx):
    lab, mode, pk = fx[0], fx[1], fx[2]
    idx = [(names.index(a), b) for a, b in pk]
    if mode == 'avoid':
        m = np.ones(len(F), bool)
        for f, v in idx: m &= F[:, f] != v
    else:
        m = np.ones(len(F), bool)
        for f, v in idx: m &= F[:, f] == v
        if mode == 'mix': m &= F[:, names.index('SQ週')] != 1
    return m
def collect():
    R = {}
    DF = pd.read_csv('/home/claude/bs/g/kdefs.csv', index_col=0); FL = ['なし'] + pd.read_csv('/home/claude/bs/g/kfilters.csv').iloc[:, 0].tolist()
    K = pickle.load(open('/home/claude/bs/g/rs3_k_resall.pkl', 'rb'))
    for (g, f), d in K.items():
        R[('15分足(網羅)', f"k:{DF.trig[g]}{'買' if DF.dir[g] == 1 else '売'}", FL[f], int(DF.dir[g]))] = {i: (a[0], a[1], a[2], a[3], a[5]) for i, a in d.items()}
    for tf in ['15', '60', '240', 'D']:
        D, res = rs3b.study_sw(tf); TR = pd.read_csv(f'/home/claude/bs/g/sw_trigs_{tf}.csv').iloc[:, 0].tolist(); FLs = ['なし'] + pd.read_csv(f'/home/claude/bs/g/sw_filters_{tf}.csv').iloc[:, 0].tolist()
        for (g, f), d in res.items():
            R[(rs3b.LAB[tf], f"sw{tf}:{TR[g // 2]}{'買' if g % 2 == 1 else '売'}", FLs[f], 1 if g % 2 == 1 else -1)] = d
        print('sw', tf, flush=True)
    for st in ['zt', 'ss']:
        D, res = rs3b.study_theory(st); RU = pd.read_csv(f'/home/claude/bs/g/{st}_rules.csv')
        lab = {'zt': '15分足セオリー', 'ss': '売りの深掘り（手じまい全部から）', 'ssS': '売りの深掘り（短め）', 'ssL': '売りの深掘り（長め）'}
        for (pre, r), d in res.items():
            R[(lab[pre], f"{pre}:{RU.名前[r]}{RU.向き[r]}", 'なし', 1 if RU.向き[r] == '買' else -1)] = d
        print(st, flush=True)
    return R
if __name__ == '__main__':
    R = collect(); print('rules', len(R), flush=True)
    AD = {1: ('15分足セオリー', 'zt:H1Line 谷の値に届かずに反発（0.1A以内・触れず）買', 'なし'), 3: ('1時間足', 'sw60:H4Lineの向き転換買', 'なし'), 7: ('15分足(網羅)', 'k:H1Line 山 反発0.1買', 'インジ6本そろう'),
          12: ('1時間足', 'sw60:EMA48×H4Line買', 'なし'), 22: ('1時間足', 'sw60:EMA12×EMA48買', 'なし'), 27: ('15分足(網羅)', 'k:H1Line 山 抜け買', 'インジ6本そろう'),
          28: ('15分足(網羅)', 'k:H1Line 山 反発0.05買', '15m-1H傾き'), 29: ('15分足(網羅)', 'k:H1Line 山 反発0.15買', 'インジ6本そろう'), 30: ('1時間足', 'sw60:H4Lineの向き転換買', 'EMA48がH4Lineの同じ側'),
          31: ('15分足(網羅)', 'k:macd 1D-1W 反発0.1買', 'H1Line傾き'), 5: ('15分足セオリー', 'zt:H4Line 裏タッチ 近さ0.15A（割れて4時間以内）売', 'なし'), 11: ('15分足(網羅)', 'k:H4Line 反発0.15売', '遅ストキャス低位'),
          32: ('15分足(網羅)', 'k:H4Line 反発0.05売', 'インジ5本以上'), 33: ('15分足スイング', 'sw15:H4Lineの向き転換売', '1H遅ストキャス向き'), 34: ('15分足(網羅)', 'k:signal 1H-4H 反発0.25売', '遅ストキャス低位')}
    OV = {}
    for no, (lab, nm, fl) in AD.items():
        key = [k for k in R if k[0] == lab and k[1] == nm and k[2] == fl]; assert len(key) == 1, (no, key)
        for inst in ['fut', 'cfd']:
            a = R[key[0]][inst]; OV[(inst, no)] = (np.asarray(a[0], np.int64), np.asarray(a[1], np.int64), np.asarray(a[2], float), np.asarray(a[3]))
    pickle.dump(OV, open('/home/claude/bs/g/ov3_research.pkl', 'wb')); print('ov saved', flush=True)
    rows = []; n = 0
    for (lab, nm, fl, dr), dct in R.items():
        if set(dct) != {'fut', 'cfd'}: continue
        for fx in [('そのまま', 'none', [])] + FIX:
            row = dict(調べ=lab, ルール=nm, 向き='買い' if dr == 1 else '売り', 方向確認=fl, 条件=fx[0])
            for inst, L in [('fut', 'ミニ'), ('cfd', 'CFD')]:
                i5, x5, v, yr, pools = dct[inst]
                if fx[1] == 'none': keep = np.ones(len(i5), bool); p2 = pools
                else:
                    F, names = fast_feats(inst, i5, dr); keep = mask(F, names, fx); p2 = []
                    for (ri, rx, rv, ry) in pools:
                        FR, _ = fast_feats(inst, ri, dr); kr = mask(FR, names, fx); p2.append((ri[kr], rx[kr], rv[kr], ry[kr]))
                row.update(one_stats(i5[keep], x5[keep], v[keep], yr[keep], f'{L} ')); row.update(rand_stats(p2, f'{L} ランダム')); compare(row, L)
            rows.append(row)
        n += 1
        if n % 300 == 0: print(n, flush=True)
    pd.DataFrame(rows).to_pickle('/home/claude/bs/g/fixc.pkl'); print('done', len(rows))
