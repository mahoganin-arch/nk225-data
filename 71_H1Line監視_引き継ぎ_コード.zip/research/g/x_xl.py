import numpy as np, pandas as pd
OUT='/home/claude/out/手じまい拡張の検証_2026-10-25.xlsx'
O=pd.read_pickle('xeval.pkl'); R=pd.read_pickle('xrisk.pkl'); RL=pd.read_csv('xlib_rules.csv')
N=O['nest']; ns=N.groupby(['候補','商品'])[['件数','選んだ手じまいの合計','基準の合計','選んだ13円','基準13円']].sum().reset_index()
S={}
S['まとめ']=pd.DataFrame({'':[
 '手じまいを 12〜9通り → 75ルール×損切り3＝225通り に広げた（時間・日／週の終わり・円と0.○Aの利確・トレール・建値移動・半分利確・時間で切る・利益の戻し・線やストキャスの反転・直近安値の損切り・最大2日保有）。',
 '入りは15分足の候補11形（A・A+・B・C・C+・D・D+・E・E2・F）と、比べるためのランダムな入り（買い・売り 各15,000）。5分足 2018〜2026-10-08、ミニ・CFD。コストは今までと同じ（CFDの持ち越し金利も入れた）。基準＝今まで使っていた「セッション終わり・損切り 線の0.25A先」。',
 '【結果1】ご指摘どおり、手じまいで成績は大きく変わる。候補の合図のあとは、ランダムより「有利に動く幅」が大きい（セッション内の中央値 0.16〜0.25A、ランダム 0.13〜0.15A）。週まで見ると差はさらに広がる。',
 '【結果2】一番効くのは「長く持つ」こと：セッション終わりで切らず、日の終わり〜24時間（損切り 入値から0.5A）まで持つと、A は ミニ +43→+105、CFD +33→+105（どちらも9/9年プラス）。A+(インジ6本) は ミニ +66→+135、CFD +28→+148。',
 '【結果3】これは上げ相場の分だけではない：ランダム買いも長く持つと良くなるが（ミニ +11→+29、CFD +6→+17）、候補の上乗せはそれより大きい（A：ランダムとの差 ミニ +32→+76、CFD +27→+88）。',
 '【結果4】ただし代わりに：最大ドローダウンは約2倍（A ミニ 4,594→11,451、CFD 7,709→10,009）、1回の最悪も大きくなる。平均保有は約5時間→約17時間。ミニは週末の持ち越しもある。',
 '【結果5】損の小さい選び方：「トレール0.25A（週まで）・損切り 線の0.25A先」。A+ CFD +28→+80 で最大DD 5,086→2,457、9/9年プラス。A でも ミニ +43→+48・CFD +33→+43（DD は ミニでやや増え、CFDは同じくらい）。',
 '【結果6】半分利確・建値移動・1時間で切る・円での利確は、ほぼ良くならない（利益を早く削ってしまう）。売りの候補（B・F）は手じまいを変えても良くならない（Fだけ少し）。',
 '【結果7】前向き（前の年だけで手じまいを選ぶ）：候補ごとに選ぶと合計は 基準の約2〜3.5倍（ミニ 49.5万 対 22.9万、CFD 49.3万 対 14.0万）。全候補で1つに決めると年によって基準を下回る年もある（2020年、2025年ミニ）。',
 '【おすすめ】A・A+・E2 は「24時間（上限 週の終わり）・損切り 入値から0.5A」か「日の終わり・損切り 入値から0.5A」を本命、損を小さくしたいときは「トレール0.25A（週まで）」。どれも 2026/10/9 以降の前向きで確かめる。',
 '注意：2018〜2026 は大きな上げ相場。長く持つ買いは下げ相場で崩れやすいので、前向きでは日足の向き（前回の 日足遅ストキャス・H4Line の上）と合わせて見る。']})
S['手じまい一覧(225)']=RL
S['合図のあと動いた幅']=O['mfe'].round(2)
S['手じまいごとのまとめ']=O['exit'].round(1)
S['主な候補×主な手じまい']=R.round(1)
S['候補×手じまい 全部']=O['cand'].round(1)
S['前向き 候補ごとに選ぶ']=ns.round(0)
S['前向き 年ごとの選択']=N.round(0)
S['前向き 全候補で1つ']=O['nest_all'].round(0)
with pd.ExcelWriter(OUT,engine='openpyxl') as w:
    for k,v in S.items(): v.to_excel(w,sheet_name=k[:31],index=False)
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
wb=load_workbook(OUT)
for ws in wb.worksheets:
    for c in ws[1]: c.font=Font(bold=True); c.fill=PatternFill('solid',fgColor='DDEBF7'); c.alignment=Alignment(wrap_text=True,vertical='top')
    for col in ws.columns:
        L=max(len(str(c.value or '')) for c in list(col)[:200]); ws.column_dimensions[col[0].column_letter].width=min(max(8,L*1.5),55)
    ws.freeze_panes='A2'
ws=wb['まとめ']; ws.column_dimensions['A'].width=120
for row in ws.iter_rows(min_row=2):
    for c in row: c.alignment=Alignment(wrap_text=True,vertical='top')
wb.save(OUT); print([(w.title,w.max_row) for w in wb])
