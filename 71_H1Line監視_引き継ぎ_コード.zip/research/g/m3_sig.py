"""3分足チャート（Zerch 手法）の検証：トリガー × 手じまい36 × 方向確認。
入る：シグナル足の終わりで判定 → 次の足の始値。セッションの終わりで必ず手じまい。
手じまい（9）：3分足線×m15の逆クロス／m15の向きが逆に変わる／終値がm15を逆に抜ける／3分足線×15分足線の逆クロス／
  20本（1時間）／60本（3時間）／セッションの終わり／利確0.25A／利確0.5A
損切り（4）：なし／30円／50円／0.15A（同じ足で利確と損切りの両方に届いたら損切りが先）
fam='W' 本物の線、'r*' でたらめな線（線＋なめらかなずれ）。ストキャスは価格だけで決まるので共通。
出力：m3sig_{inst}_{fam}.npz（イベント：i 足, d 向き, trig, f 方向確認ビット, R 36 の損益pt, e 入値）
"""
import os, sys, numpy as np, pandas as pd
P = os.environ.get('PFX', 'm3')
from numba import njit
sys.path.insert(0, '/home/claude/bs/g')
from h_lines import ema

EXITS = [f'{r}・{s}' for r in ['3分足線×m15逆クロス', 'm15の向き転換', '終値がm15を逆に抜け', '3分足線×15分足線逆クロス', '20本(1時間)', '60本(3時間)', 'セッション終わり', '利確0.25A', '利確0.5A']
         for s in (['損切りなし', '損切り30円', '損切り50円', '損切り0.15A'] if P == 'm3' else ['損切りなし', '損切り0.1A', '損切り0.25A', '損切り0.5A'])]
SLV = np.array([0.0, 30.0, 50.0, -0.15] if P == 'm3' else [0.0, -0.1, -0.25, -0.5])
FILTERS = ['1H速ストキャス向き', '4H速ストキャス向き', '日足速ストキャス向き', '1H・4H・日足そろう', '15分速ストキャス向き', '3分 速K>遅K',
           '3分 遅ストキャス向き', '15分足線がm15の同じ側', 'm15の傾き', 'H1Line(15分足の線)の傾き', '4H遅ストキャス向き', '日足遅ストキャス向き',
           '日中だけ', '3分速ストキャス低位(押し目)', '価格がH1Lineの同じ側']

@njit(cache=True)
def sim(J, Dr, o, h, l, c, send, A, S, R, SLV):
    n = len(J)
    for q in range(n):
        j = J[q]; d = Dr[q]; e = o[j]; a = A[j]; end = send[j]
        for s in range(4):
            v = SLV[s]; sl = v if v >= 0 else -v * a
            done = np.zeros(9, np.bool_); res = np.zeros(9)
            left = 9
            for k in range(j, end + 1):
                # 損切り（足の中）
                if sl > 0:
                    stop = e - d * sl
                    hit = (l[k] <= stop) if d == 1 else (h[k] >= stop)
                    if hit:
                        px = stop
                        if k > j or True:
                            if d == 1 and o[k] < stop: px = o[k]
                            if d == -1 and o[k] > stop: px = o[k]
                        for r in range(9):
                            if not done[r]: res[r] = (px - e) * d; done[r] = True
                        left = 0; break
                # 利確（足の中）
                for r in (7, 8):
                    if not done[r]:
                        tp = e + d * (0.25 if r == 7 else 0.5) * a
                        if (d == 1 and h[k] >= tp) or (d == -1 and l[k] <= tp):
                            px = tp
                            if d == 1 and o[k] > tp: px = o[k]
                            if d == -1 and o[k] < tp: px = o[k]
                            res[r] = (px - e) * d; done[r] = True; left -= 1
                # 足の終わりの判定 → 次の足の始値（セッションの最後なら終値）
                last = k == end
                nx = c[k] if last else o[k + 1]
                for r in range(4):
                    if not done[r] and k >= 1:
                        if S[r, k] * d < 0 and S[r, k - 1] * d >= 0:
                            res[r] = (nx - e) * d; done[r] = True; left -= 1
                if not done[4] and k - j + 1 >= 20: res[4] = (nx - e) * d; done[4] = True; left -= 1
                if not done[5] and k - j + 1 >= 60: res[5] = (nx - e) * d; done[5] = True; left -= 1
                if last:
                    for r in range(9):
                        if not done[r]: res[r] = (c[k] - e) * d; done[r] = True
                    left = 0
                if left <= 0: break
            for r in range(9):
                R[q, r * 4 + s] = res[r]

def lines(X, fam, inst):
    x = X['c'].astype(float); L = {k: X[k].astype(float) for k in ['m15', 'h1', 'e12', 'e60']}
    if fam != 'W':
        rng = np.random.default_rng(991 * int(fam[1:]) + (0 if inst == 'fut' else 1)); n = len(x)
        A = np.nan_to_num(X['A'], nan=np.nanmedian(X['A']))
        for k, s in [('m15', 60), ('h1', 240), ('e12', 12), ('e60', 60)]:
            z = rng.standard_normal(n); z = ema(ema(z, s), s); z = (z - z.mean()) / z.std()
            c = np.nanmedian(np.abs(x - L[k])[3000:] / A[3000:]); L[k] = L[k] + c * A * z
    return L

def sg(v): return np.sign(np.nan_to_num(v)).astype(np.int8)

def triggers(X, L):
    c = X['c'].astype(float); h = X['h'].astype(float); lo = X['l'].astype(float); A = X['A']
    m15, h1, e12, e60 = L['m15'], L['h1'], L['e12'], L['e60']
    T = {}
    def cross(a, b):
        s = sg(a - b); p = np.r_[0, s[:-1]]
        return (s > 0) & (p <= 0), (s < 0) & (p >= 0)
    T['3分足線×m15クロス'] = cross(e12, m15)
    T['終値×m15クロス'] = cross(c, m15)
    T['15分足線×m15クロス'] = cross(e60, m15)
    T['3分足線×15分足線クロス'] = cross(e12, e60)
    T['3分足線×H1Lineクロス'] = cross(e12, h1)
    ms = sg(np.diff(m15, prepend=np.nan)); pm = np.r_[0, ms[:-1]]
    T['m15の向き転換'] = ((ms > 0) & (pm <= 0), (ms < 0) & (pm >= 0))
    hs = sg(np.diff(h1, prepend=np.nan)); ph = np.r_[0, hs[:-1]]
    T['H1Lineの向き転換'] = ((hs > 0) & (ph <= 0), (hs < 0) & (ph >= 0))
    gc, dc = T['3分足線×m15クロス']
    s60 = sg(np.diff(e60, prepend=np.nan))
    below = (e60 < m15) & (s60 < 0); above = (e60 > m15) & (s60 > 0)
    # 値幅抵抗のサイン：15分足線がm15の下を這う中での3分足線の上抜け → 失敗するなら売り（逆張り）
    T['値幅サイン逆張り'] = (dc & (e60 > m15), gc & (e60 < m15))
    T['値幅型クロス(15分足線が逆側)'] = (gc & (e60 < m15), dc & (e60 > m15))
    T['周期型クロス(15分足線も同じ側)'] = (gc & (e60 > m15), dc & (e60 < m15))
    # 二度目のクロス：逆向きのクロスから20本以内
    def recent(ev, nb):
        idx = np.nonzero(ev)[0]; out = np.zeros(len(ev), bool)
        k = np.searchsorted(idx, np.arange(len(ev)), side='left') - 1
        ok = k >= 0; out[ok] = (np.arange(len(ev))[ok] - idx[k[ok]]) <= nb
        return out
    T['3分足線×m15 再クロス(20本内)'] = (gc & recent(dc, 20), dc & recent(gc, 20))
    # 線への接近（タッチと見なす）からの反発
    def touch(top, bot, w):
        pc = np.r_[np.nan, c[:-1]]
        b = (lo <= top + w * A) & (c > top) & (pc > top)
        s = (h >= bot - w * A) & (c < bot) & (pc < bot)
        return b, s
    for w in (0.03, 0.08):
        T[f'm15反発({w}A)'] = touch(m15, m15, w)
        T[f'H1Line反発({w}A)'] = touch(h1, h1, w)
        T[f'15分足線反発({w}A)'] = touch(e60, e60, w)
    top = np.fmax(np.fmax(m15, e60), h1); bot = np.fmin(np.fmin(m15, e60), h1)
    tight = (top - bot) <= 0.08 * A
    for w in (0.03, 0.08):
        b, s = touch(top, bot, w); T[f'3つのサイン反発({w}A)'] = (b & tight, s & tight)
    pc = np.r_[np.nan, c[:-1]]
    T['3つのサイン抜け'] = (tight & (c > top) & (pc <= top), tight & (c < bot) & (pc >= bot))
    # ストキャス
    T['3分 速K×遅K(MACD)クロス'] = cross(X['fk'], X['sk'])
    T['3分 速K×速Dクロス'] = cross(X['fk'], X['fd'])
    T['3分 遅K×遅Dクロス'] = cross(X['sk'], X['sd'])
    T['15分 速K×遅Kクロス'] = cross(X['fk15'], X['sk15'])
    T['1H 速K×遅Kクロス'] = cross(X['fk60'], X['sk60'])
    T['4H 速K×遅K(MACD)クロス'] = cross(X['fk240'], X['sk240'])
    T['4H 速K×速Dクロス'] = cross(X['fk240'], X['fd240'])
    T['日足 速K×速Dクロス'] = cross(X['fkD'], X['fdD'])
    # 1Hと4Hの速ストキャスが同じ位置で（10以内）同じ向きにクロス
    b1, s1 = cross(X['fk60'], X['fd60'])
    same = np.abs(X['fk60'] - X['fk240']) < 10
    T['1H・4H 同じ位置でクロス'] = (b1 & (X['fk240'] > X['fd240']) & same, s1 & (X['fk240'] < X['fd240']) & same)
    # 日足デッド＋4H 速K×遅K デッド（ブログの売りの形）
    b4, s4 = T['4H 速K×遅K(MACD)クロス']
    T['日足の向き＋4H 速K×遅K'] = (b4 & (X['fkD'] > X['fdD']), s4 & (X['fkD'] < X['fdD']))
    return T

def filters(X, L, d):
    """d=+1/-1 の向きに合っているかのビット（足ごと）"""
    m15, h1, e60 = L['m15'], L['h1'], L['e60']; c = X['c']
    al = lambda a, b: (np.nan_to_num(a - b) * d) > 0
    up = lambda v: (np.nan_to_num(np.diff(v, prepend=np.nan)) * d) > 0
    F = [al(X['fk60'], X['fd60']), al(X['fk240'], X['fd240']), al(X['fkD'], X['fdD'])]
    F.append(F[0] & F[1] & F[2])
    F += [al(X['fk15'], X['fd15']), al(X['fk'], X['sk']), al(X['sk'], X['sd']), al(e60, m15), up(m15), up(h1),
          al(X['sk240'], X['sd240']), al(X['skD'], X['sdD'])]
    hm = X['hm']; F.append((hm >= 8 * 60 + 45) & (hm < 15 * 60 + 15))
    F.append((X['fk'] < 30) if d == 1 else (X['fk'] > 70))
    F.append(al(c, h1))
    f = np.zeros(len(c), np.int64)
    for b, v in enumerate(F): f |= (v.astype(np.int64) << b)
    return f

def run(inst, fam, rand=False):
    X = dict(np.load(f'/home/claude/bs/g/{P}_{inst}.npz')); n = len(X['c'])
    L = lines(X, fam, inst)
    ses = X['ses']; last = np.r_[ses[1:] != ses[:-1], True]
    send = np.zeros(n, np.int64); idx = np.nonzero(last)[0]; send = idx[np.searchsorted(idx, np.arange(n))]
    valid = np.zeros(n, bool); valid[:-1] = (ses[1:] == ses[:-1]); valid &= ~np.isnan(X['A']); valid[:3000] = False
    s = lambda v: np.sign(np.nan_to_num(v)).astype(np.int8)
    S = np.stack([s(L['e12'] - L['m15']), s(np.diff(L['m15'], prepend=np.nan)), s(X['c'] - L['m15']), s(L['e12'] - L['e60'])])
    FB = {1: filters(X, L, 1), -1: filters(X, L, -1)}
    if rand:
        rng = np.random.default_rng(5 + (0 if inst == 'fut' else 1) + 10 * (int(fam[1:]) if fam != 'W' else 0))
        ii = np.nonzero(valid)[0]; ii = np.sort(rng.choice(ii, size=len(ii) // 25, replace=False))
        I = np.r_[ii, ii]; D = np.r_[np.ones(len(ii), np.int8), -np.ones(len(ii), np.int8)]; TR = np.full(len(I), -1, np.int16)
        names = []
    else:
        T = triggers(X, L); names = list(T)
        I, D, TR = [], [], []
        for t, nm in enumerate(names):
            hi = any(k in nm for k in ('4H', '日足', '1H', '15分 '))
            for d, ev in zip((1, -1), T[nm]):
                ev = np.nan_to_num(ev).astype(bool)
                if hi:  # 上位足の確定がセッションの最後の足に重なったら、次のセッションの最初の足で入る
                    ev = (ev & valid) | (np.r_[False, (ev & last)[:-1]] & valid)
                ii = np.nonzero(ev & valid)[0]; I.append(ii); D.append(np.full(len(ii), d, np.int8)); TR.append(np.full(len(ii), t, np.int16))
        I, D, TR = np.concatenate(I), np.concatenate(D), np.concatenate(TR)
    # 同じ（足・向き）の損益は1回だけ計算
    key = I.astype(np.int64) * 2 + (D > 0); uk, inv = np.unique(key, return_inverse=True)
    UI = (uk // 2).astype(np.int64); UD = np.where(uk % 2 == 1, 1, -1).astype(np.int64)
    R = np.zeros((len(uk), 36))
    sim(UI + 1, UD, X['o'].astype(float), X['h'].astype(float), X['l'].astype(float), X['c'].astype(float), send, np.nan_to_num(X['A'], nan=500.0), S.astype(np.int64), R, SLV)
    f = np.where(D > 0, FB[1][I], FB[-1][I])
    out = dict(i=I, d=D, trig=TR, f=f, R=R[inv].astype(np.float32), e=X['o'][I + 1].astype(float), nt=np.zeros(len(I), np.int8))
    tag = 'rand' if rand else 'sig'
    np.savez_compressed(f'/home/claude/bs/g/{P}{tag}_{inst}_{fam}.npz', **out)
    if fam == 'W' and not rand: pd.Series(names).to_csv(f'/home/claude/bs/g/{P}_trigs.csv', index=False)
    print(inst, fam, tag, len(I), len(uk), flush=True)

if __name__ == '__main__':
    for inst in sys.argv[1].split(','):
        for fam in sys.argv[2].split(','):
            run(inst, fam, rand=len(sys.argv) > 3)
