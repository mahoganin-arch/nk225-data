"""候補の形の年ごと・手じまい別の成績（ランダムとの比較つき）。"""
import sys; sys.path.insert(0,'/home/claude/bs/g')
import numpy as np, pandas as pd
import h_agg, k_sig as K
from k_agg import MASKS, FSETS
from k_rules import ex, fs
DF=pd.read_csv('/home/claude/bs/g/kdefs.csv',index_col=0)
CANDS=[('A H1Lineの山へ押し目買い（0.1A）','H1Line 山 反発0.1',1,()),
       ('A+ ＋インジ6本そろう','H1Line 山 反発0.1',1,('インジ6本そろう',)),
       ('A+ ＋1H-4H陽転','H1Line 山 反発0.1',1,('1H-4H陽転',)),
       ('B 週足MACDsignal への戻り売り（0.05A）','signal 週足 反発0.05',-1,()),
       ('C 日足MACDmacd への押し目買い（0.25A）','macd 1D-1W 反発0.25',1,()),
       ('C+ ＋15m-1H陽転＋1H-4H陽転','macd 1D-1W 反発0.25',1,('15m-1H陽転','1H-4H陽転')),
       ('D 1H-4H 陽転クロスで買い','macd 1H-4H×signal 1H-4H 上順',1,()),
       ('D+ ＋速ストキャス低位','macd 1H-4H×signal 1H-4H 上順',1,('速ストキャス低位',)),
       ('E PSAR買い＋インジ6本そろう＋15m-1H陽転','PSAR 買い',1,('インジ6本そろう','15m-1H陽転')),
       ('E2 PSAR買い＋15m-1H陽転＋1H-4H陽転','PSAR 買い',1,('15m-1H陽転','1H-4H陽転')),
       ('F H4Lineの山を下抜けで売り＋D1Lineの側','H4Line 山 抜け',-1,('D1Lineの側',))]
EXS=[('セッション終わり','なし'),('セッション終わり','線の0.25A先'),('週の終わり','線の0.25A先'),('240分','なし'),('インジ5本逆','なし'),('速ストキャス逆クロス','なし'),('遅ストキャス逆クロス','なし'),('15m-1H逆クロス','なし'),('次の線','線の0.25A先'),('2本目の線','線の0.25A先')]
def run():
    out=[]; yrs=[]
    for inst in ['fut','cfd']:
        X=dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); S=dict(np.load(f'/home/claude/bs/g/ksig_{inst}_W.npz')); Rr=dict(np.load(f'/home/claude/bs/g/krand_{inst}.npz'))
        net,nrm,n13=h_agg.pnl(inst,S); rn,rr,r13=h_agg.pnl(inst,Rr); yr=X['yr'][S['i']]; ry=X['yr'][Rr['i']]
        for nm,trig,dr,fl in CANDS:
            d=DF.index[(DF.trig==trig)&(DF.dir==dr)][0]; msk=MASKS[fs(*fl)] if fl else 0
            m=(S['d']==d)&((S['f'].astype(np.int64)&msk)==msk); rm=(Rr['d']%2==(0 if dr==1 else 1))&((Rr['f'].astype(np.int64)&msk)==msk)
            for r_,s_ in EXS:
                e=ex(r_,s_); v=nrm[m,e]; c=np.cumsum(v); dd=(np.maximum.accumulate(c)-c).max() if len(c) else np.nan
                out.append(dict(商品='ミニ' if inst=='fut' else 'CFD',形=nm,手じまい=f'{r_}／損切り{s_}',件数=int(m.sum()),実コストpt=np.nanmean(net[m,e]),そろえた=np.nanmean(v),円13=np.nanmean(n13[m,e]),
                                ランダム=np.nanmean(rr[rm,e]),前半=np.nanmean(nrm[m&(yr<=2022),e]),後半=np.nanmean(nrm[m&(yr>=2023),e]),
                                合計=np.nansum(v),最大DD=dd,プラス年=int(sum(np.nansum(nrm[m&(yr==y),e])>0 for y in range(2018,2027))),
                                勝率=np.nanmean(v>0)))
            e=ex('セッション終わり','線の0.25A先')
            yrs.append(dict(商品='ミニ' if inst=='fut' else 'CFD',形=nm,**{str(y):np.nansum(nrm[m&(yr==y),e]) for y in range(2018,2027)}))
    return pd.DataFrame(out),pd.DataFrame(yrs)
if __name__=='__main__':
    O,Y=run(); O.to_pickle('/home/claude/bs/g/kcands.pkl'); Y.to_pickle('/home/claude/bs/g/kcands_y.pkl')
    pd.set_option('display.width',260)
    print(O[O.手じまい=='セッション終わり／損切り線の0.25A先'].round(1).to_string())
    print(Y.round(0).to_string())
