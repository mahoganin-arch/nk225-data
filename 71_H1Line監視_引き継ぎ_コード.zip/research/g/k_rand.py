"""比べる相手：ランダムな時刻（各セッションで15分足の確定を1つ選ぶ）に入る。種5つ × 買い・売り。手じまい・方向確認は k_sig と同じ。"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
import k_sig as K
inst = sys.argv[1]
X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); KW = np.load(f'/home/claude/bs/g/kind_{inst}_W.npz')
is15 = KW['is15']; pid = X['pid_ses']; pend = X['end_ses']; n = len(pid)
idx = np.nonzero(is15 & ~pend & (X['yr'] >= 2018))[0]
rows = []
for seed in range(5):
    rng = np.random.default_rng(seed)
    s = pd.Series(idx).groupby(pid[idx]).apply(lambda g: g.iloc[rng.integers(len(g))]).values
    for dr in (1, -1):
        a = np.zeros(n, bool); a[s] = True; rows.append((seed, dr, a))
K.run(inst, 'W', rand=rows)
