import sys, numpy as np, pandas as pd
sys.path.insert(0,'/home/claude/bs/g')
from cal import bar_feats, trades_table, rule_sets
from ss_cand import dd_of
FF={i:bar_feats(i)[2] for i in ['fut','cfd']}
T=trades_table(); S=rule_sets(T)
def flag(inst,i5,spec):
    m=np.zeros(len(i5),bool)
    for f,v in spec: m|=FF[inst][f][i5]==v
    return m
SK={'FOMCの前日・当日・翌日':[('FOMCの前日','はい'),('FOMCの日（発表を含む夜間）','はい'),('FOMCの翌日','はい')],'月末2日':[('月末2日','はい')],
    'FOMC3日＋月末2日':[('FOMCの前日','はい'),('FOMCの日（発表を含む夜間）','はい'),('FOMCの翌日','はい'),('月末2日','はい')],'夜間の入り':[('セッション','夜間')],'12月':[('月','12月')],'水曜':[('曜日','水')]}
BO={'祝日の前日・翌日':[('祝日の前日','はい'),('祝日の翌日（連休明け）','はい')],'SQ週（3・6・9・12月以外）':[('SQ週（その他の月）','はい')],'SQの前日':[('SQの前日','はい')],'月曜':[('曜日','月')]}
rows=[]
for tg in ['アラートの買い10ルール','ランダムな買い']:
    for inst in ['fut','cfd']:
        g=S[(tg,inst)]; g=g[g.yr>=2020]; v=g.v.values.astype(float); yr=g.yr.values; x=g.x5.values; base=v.sum(); bdd=dd_of(x,v)
        for nm,sp in SK.items():
            m=flag(inst,g.i5.values,sp); d=[-v[m&(yr==y)].sum() for y in range(2020,2027)]
            rows.append(dict(対象=tg,市場=inst,使い方='見送り',分類=nm,回数=int(m.sum()),その分の1回平均=v[m].mean(),合計の差=-v[m].sum(),最大DDの変化=dd_of(x[~m],v[~m])-bdd,良くなった年=sum(z>0 for z in d),**{str(y):z for y,z in zip(range(2020,2027),d)}))
        for nm,sp in BO.items():
            m=flag(inst,g.i5.values,sp); d=[v[m&(yr==y)].sum() for y in range(2020,2027)]
            v2=v+np.where(m,v,0)
            rows.append(dict(対象=tg,市場=inst,使い方='2枚にする',分類=nm,回数=int(m.sum()),その分の1回平均=v[m].mean(),合計の差=v[m].sum(),最大DDの変化=dd_of(x,v2)-bdd,良くなった年=sum(z>0 for z in d),**{str(y):z for y,z in zip(range(2020,2027),d)}))
SL={'日中の入り（夜間だけ売る）':[('セッション','日中')],'月曜':[('曜日','月')],'SQ週（3・6・9・12月以外）':[('SQ週（その他の月）','はい')],'日中＋月曜＋SQ週（その他）':[('セッション','日中'),('曜日','月'),('SQ週（その他の月）','はい')]}
for tg in ['H4Line 裏タッチ 近さ0.15A（割れて4時間以内）売','H4Line 割れて終値2本下に居続けた売','E 下げ相場（D1Lineの下・D1Line下向き）で H4Line裏タッチ0.15A売','ランダムな売り']:
    for inst in ['fut','cfd']:
        g=S[(tg,inst)]; g=g[g.yr>=2020]; v=g.v.values.astype(float); yr=g.yr.values; x=g.x5.values; bdd=dd_of(x,v)
        for nm,sp in SL.items():
            m=flag(inst,g.i5.values,sp); d=[-v[m&(yr==y)].sum() for y in range(2020,2027)]
            rows.append(dict(対象=tg,市場=inst,使い方='見送り',分類=nm,回数=int(m.sum()),その分の1回平均=v[m].mean(),合計の差=-v[m].sum(),最大DDの変化=dd_of(x[~m],v[~m])-bdd,良くなった年=sum(z>0 for z in d),
                 残りの合計=v[~m].sum(),残りの回数=int((~m).sum()),残りのプラスの年=sum(v[~m&(yr==y)].sum()>0 for y in range(2020,2027)),**{str(y):z for y,z in zip(range(2020,2027),d)}))
R=pd.DataFrame(rows); R.to_pickle('/home/claude/bs/g/cal2.pkl')
pd.set_option('display.width',330); pd.set_option('display.max_rows',200); pd.set_option('display.max_colwidth',40)
print(R.round(0).to_string())
