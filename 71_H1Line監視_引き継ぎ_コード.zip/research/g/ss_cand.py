"""売りの深掘り：候補の判定（単体）と、保険としての役立ち（アラートの買い10ルールと一緒に持ったとき）。
対象：ss（手じまい全部から）・ssS（短め）・ssL（長め）× そのまま／避ける／入る条件（条件は前の年で選ぶ）。期間 2020〜2026 の前向き、1つずつ。
単体の候補：両商品で ①合計プラス ②7年中5年以上プラス ③1回平均がランダムより良い ④70回以上 ⑤線を使うルールは でたらめな線より頑丈（z≥2）。
保険：買い10ルール（1つずつ・前向き）の損益に売り1枚を足したときの 最大DD・合計・買いが損した月の売りの損益。
出力：ss_cand.pkl
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from cond import feats, apply
from cand_list import parse, stats, YRS
BUY = ['zt:H1Line 表側で届かずに切り返し（0.05A以内・触れず）買', 'zt:H1Line 谷の値に届かずに反発（0.1A以内・触れず）買', 'k:H1Line 山 反発0.1買', 'sw60:H4Lineの向き転換買',
       'k:macd 15m-1H×signal 15m-1H 上順買', 'k:インジ5本 買い買', 'sw60:EMA48×H4Line買', 'k:PSAR 買い買', 'sw60:EMA12×EMA48買', 'k:H1Line×macd 15m-1H 下逆買']

def seq_idx(i5, x5):
    o = np.argsort(i5, kind='stable'); last = -1; tk = []
    for q in o:
        if i5[q] > last: tk.append(q); last = x5[q]
    return np.array(tk, int)

def month_of(inst):
    X = np.load(f'/home/claude/bs/g/data_{inst}.npz'); t = pd.to_datetime(X['tm'], unit='s', utc=True).tz_convert('Asia/Tokyo')
    return (t.year * 12 + t.month - 1).values

def buy_book():
    T = pd.concat([pd.read_pickle('/home/claude/bs/g/tr2.pkl'), pd.read_pickle('/home/claude/bs/g/tr_zt.pkl')], ignore_index=True); T['rule'] = T.rule.astype(str)
    T = T[T.rule.isin(BUY) & (T.yr >= 2020)]; out = {}
    for inst in ['fut', 'cfd']:
        xs, vs = [], []
        for r in BUY:
            g = T[(T.rule == r) & (T.inst == inst)]; k = seq_idx(g.i5.values, g.x5.values)
            xs.append(g.x5.values[k]); vs.append(g.v.values[k].astype(float))
        out[inst] = (np.concatenate(xs), np.concatenate(vs))
    return out

def dd_of(x, v):
    o = np.argsort(x, kind='stable'); cs = np.cumsum(v[o]); return float((np.maximum.accumulate(np.r_[0, cs]) - np.r_[0, cs]).max())

def hedge(inst, bx, bv, sx, sv, MON):
    tot_b = bv.sum(); dd_b = dd_of(bx, bv)
    x = np.r_[bx, sx]; v = np.r_[bv, sv]; dd_c = dd_of(x, v)
    mb = pd.Series(bv).groupby(MON[bx]).sum(); ms = pd.Series(sv).groupby(MON[sx]).sum().reindex(mb.index, fill_value=0.0)
    lose = mb < 0
    return {'買いだけ合計': tot_b, '買いだけ最大DD': dd_b, '買い＋売り 合計': tot_b + sv.sum(), '買い＋売り 最大DD': dd_c, 'DDの減り(%)': 100 * (1 - dd_c / dd_b) if dd_b > 0 else np.nan,
            '買いが損した月の売り': float(ms[lose].sum()), '買いがもうけた月の売り': float(ms[~lose].sum()), '買いが損した月の数': int(lose.sum()),
            '月の損益の相関': float(np.corrcoef(mb.values, ms.values)[0, 1]) if ms.std() > 0 else np.nan}

def run():
    T = pd.read_pickle('/home/claude/bs/g/tr_ss.pkl'); T = T[T.yr >= 2018].reset_index(drop=True); T['rule'] = T.rule.astype(str)
    F, names = feats(T); C = pd.read_pickle('/home/claude/bs/g/cond_tr_ss.pkl'); PL = C['picks']
    PK = {(r.rule, r.t, r.型): parse(r.条件, names) for r in PL.itertuples()}
    RU = pd.read_csv('/home/claude/bs/g/ss_rules.csv'); Z = pd.read_pickle('/home/claude/bs/g/ss_eval.pkl')['rules']
    zmap = dict(zip(Z.ルール, Z.頑丈さz)); lmap = dict(zip(RU.名前, RU.線を使う)); kmap = dict(zip(RU.名前, RU.観点))
    BB = buy_book(); MON = {i: month_of(i) for i in ['fut', 'cfd']}
    idx = T.groupby('rule').indices; rows = []
    for rule, ix in idx.items():
        if rule.startswith('rand:'): continue
        pre = rule.split(':')[0]; base = rule.split(':', 1)[1][:-1]; rix = idx.get(f'rand:{pre}:売')
        g_i5 = T.i5.values[ix]; g_x5 = T.x5.values[ix]; g_v = T.v.values[ix].astype(float); g_yr = T.yr.values[ix]; g_in = T.inst.values[ix]; Fg = F[ix]
        for mode in ('そのまま', '避ける', '入る条件'):
            keep = g_yr >= 2020; rkeep = T.yr.values[rix] >= 2020; picks_txt = []
            if mode != 'そのまま':
                mm = np.zeros(len(ix), bool); rm = np.zeros(len(rix), bool); md = 'avoid' if mode == '避ける' else 'require'
                for t in YRS:
                    pk = PK.get((rule, t, mode), None)
                    if pk is None: continue
                    picks_txt.append(f"{t}:" + ','.join(f'{names[f]}={v}' for f, v in pk))
                    sel = g_yr == t; mm[sel] = apply(Fg[sel], pk, md)
                    rs = T.yr.values[rix] == t; rm[rs] = apply(F[rix][rs], pk, md)
                keep &= mm; rkeep &= rm
            row = dict(手じまいの型={'ss': '全部から', 'ssS': '短め', 'ssL': '長め'}[pre], 観点=kmap.get(base, ''), ルール=base, 条件=mode, 選んだ条件=' | '.join(picks_txt[-2:]))
            for ins, L in [('fut', 'ミニ'), ('cfd', 'CFD')]:
                m = keep & (g_in == ins); s = stats(g_i5[m], g_x5[m], g_v[m], g_yr[m]); row.update({f'{L} {k}': v for k, v in s.items()})
                mr = rkeep & (T.inst.values[rix] == ins); row[f'{L} ランダム1回平均'] = T.v.values[rix][mr].mean() if mr.any() else np.nan
                k = seq_idx(g_i5[m], g_x5[m]); sx = g_x5[m][k]; sv = g_v[m][k]
                hd = hedge(ins, *BB[ins], sx, sv, MON[ins]); row.update({f'{L} {kk}': vv for kk, vv in hd.items()})
            row['頑丈さz'] = zmap.get(base, np.nan); row['線を使う'] = bool(lmap.get(base, True))
            rows.append(row)
    X = pd.DataFrame(rows); c = {}
    c['①合計プラス'] = (X['ミニ 合計'] > 0) & (X['CFD 合計'] > 0)
    c['②5年以上プラス'] = (X['ミニ プラスの年'] >= 5) & (X['CFD プラスの年'] >= 5)
    c['③ランダムより良い'] = (X['ミニ 一回平均'] > X['ミニ ランダム1回平均']) & (X['CFD 一回平均'] > X['CFD ランダム1回平均'])
    c['④70回以上'] = (X['ミニ 件数'] >= 70) & (X['CFD 件数'] >= 70)
    c['⑤頑丈さ'] = (~X.線を使う) | (X.頑丈さz >= 2)
    for k, v in c.items(): X[k] = v
    ok = np.stack(list(c.values()), 1); X['満たさない数'] = (~ok).sum(1)
    X['単体の判定'] = np.select([X.満たさない数 == 0, X.満たさない数 == 1], ['候補', '近いが外れた'], '外れ')
    X['外れた理由'] = [' / '.join(k for k, v in zip(c, r) if not v) for r in ok]
    # 保険：両商品で DD が5%以上減る・買いが損した月に売りがプラス・ランダムより良い・70回以上・頑丈さ
    X['保険の判定'] = np.where((X['ミニ DDの減り(%)'] >= 5) & (X['CFD DDの減り(%)'] >= 5) & (X['ミニ 買いが損した月の売り'] > 0) & (X['CFD 買いが損した月の売り'] > 0)
                              & c['③ランダムより良い'] & c['④70回以上'] & c['⑤頑丈さ'], '保険の候補', '')
    X['合計(両商品)'] = X['ミニ 合計'] + X['CFD 合計']
    X.to_pickle('/home/claude/bs/g/ss_cand.pkl')
    pd.set_option('display.width', 300); pd.set_option('display.max_colwidth', 50); pd.set_option('display.max_rows', 200)
    print(X.groupby(['手じまいの型', '条件', '単体の判定']).size().unstack(fill_value=0))
    print(X.groupby(['手じまいの型', '条件']).保険の判定.apply(lambda s: (s != '').sum()))
    cols = ['手じまいの型', 'ルール', '条件', '単体の判定', '保険の判定', 'ミニ 件数', 'ミニ 一回平均', 'ミニ ランダム1回平均', 'CFD 一回平均', 'CFD ランダム1回平均', 'ミニ 合計', 'CFD 合計', 'ミニ プラスの年', 'CFD プラスの年', 'ミニ DDの減り(%)', 'CFD DDの減り(%)', '頑丈さz']
    print(X[(X.単体の判定 != '外れ') | (X.保険の判定 != '')].sort_values('合計(両商品)', ascending=False)[cols].round(1).to_string())

if __name__ == '__main__':
    run()
