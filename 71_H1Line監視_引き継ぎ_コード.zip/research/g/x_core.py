"""手じまい225通りを、どんな入りにも使えるようにした共通部分（5分足データ用・3分足/15分足データ用）。"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from x_lib import simall, rules, nxt, SLN
LN = pd.read_csv('/home/claude/bs/g/k_lnames.csv').iloc[:, 0].tolist()
IN = pd.read_csv('/home/claude/bs/g/k_inames.csv').iloc[:, 0].tolist()
RL = rules()
TYP = np.array([r[1] for r in RL], np.int64); P1 = np.array([r[2] for r in RL], float); P2 = np.array([r[3] for r in RL], float)
P3 = np.array([r[4] for r in RL], float); CAP = np.array([r[5] for r in RL], np.int64)
NE = len(RL) * 3
REF = 68800.0; COST = {'fut': 5.0, 'cfd': 7.0}

def endpos(pid):
    n = len(pid); last = np.r_[pid[1:] != pid[:-1], True]; idx = np.nonzero(last)[0]; return idx[np.searchsorted(idx, np.arange(n))]

def _events(c, is15, LMs, fk, fd, sk, sd, ps, ind):
    """LMs：dict 名前→線（H1Line・H4Line・D1Line・macd 15m-1H・signal 15m-1H）。ind：(n,5) インジの向き or None"""
    def cross_dn(a, b):
        s = np.sign(np.nan_to_num(a - b)); p = np.r_[0, s[:-1]]; return (s < 0) & (p >= 0), (s > 0) & (p <= 0)
    ev = {1: [], -1: []}
    for x1, x2 in [(fk, fd), (sk, sd)]:
        dn, up = cross_dn(x1, x2); ev[1].append(dn); ev[-1].append(up)
    pp = np.r_[0, ps[:-1]]; ev[1].append((ps < 0) & (pp >= 0)); ev[-1].append((ps > 0) & (pp <= 0))
    if ind is not None:
        alldn = (ind < 0).all(1); allup = (ind > 0).all(1)
        ev[1].append(alldn & ~np.r_[False, alldn[:-1]]); ev[-1].append(allup & ~np.r_[False, allup[:-1]])
    else:
        ev[1].append(np.zeros(len(c), bool)); ev[-1].append(np.zeros(len(c), bool))
    dn, up = cross_dn(LMs['macd'], LMs['signal']); ev[1].append(dn); ev[-1].append(up)
    for nm in ('H1', 'H4'):
        v = LMs[nm]; s = np.where(is15, np.sign(np.nan_to_num(np.diff(v, prepend=np.nan))), np.nan); s = pd.Series(s).ffill().fillna(0).values
        p = np.r_[0, s[:-1]]; ev[1].append((s < 0) & (p >= 0)); ev[-1].append((s > 0) & (p <= 0))
    for nm in ('H1', 'H4', 'D1'):
        Lv = LMs[nm]; st = np.where(is15, np.sign(np.nan_to_num(c - Lv)), np.nan); st = pd.Series(st).ffill().fillna(0).values
        p = np.r_[0, st[:-1]]; ev[1].append(is15 & (st < 0) & (p >= 0)); ev[-1].append(is15 & (st > 0) & (p <= 0))
    pk = np.r_[np.nan, fk[:-1]]; ev[1].append((pk >= 80) & (fk < 80)); ev[-1].append((pk <= 20) & (fk > 20))
    return {d: np.stack([nxt(np.nan_to_num(v).astype(bool)) for v in ev[d]]) for d in (1, -1)}

def ctx5(inst, fam='W'):
    """15分足チャート（5分足データ）の文脈"""
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); K = dict(np.load(f'/home/claude/bs/g/kind_{inst}_{fam}.npz')); KW = dict(np.load(f'/home/claude/bs/g/kind_{inst}_W.npz'))
    o, h, l, c = [X[k].astype(float) for k in 'ohlc']; LM = K['L'].astype(float); I = KW['I'].astype(float); is15 = K['is15']
    col = {nm: j for j, nm in enumerate(IN)}
    ends = np.stack([endpos(X['pid_ses']), endpos(X['pid_day']), endpos(X['pid_wk'])]).astype(np.int64)
    LMs = {'H1': LM[:, LN.index('H1Line')], 'H4': LM[:, LN.index('H4Line')], 'D1': LM[:, LN.index('D1Line')], 'macd': LM[:, LN.index('macd 15m-1H')], 'signal': LM[:, LN.index('signal 15m-1H')]}
    ind = np.stack([I[:, col[f'Indi0{m}向き']] for m in range(2, 7)], 1)
    NX = _events(c, is15, LMs, I[:, col['速K']], I[:, col['速D']], I[:, col['遅K']], I[:, col['遅D']], I[:, col['PSAR']], ind)
    return dict(o=o, h=h, l=l, c=c, ends=ends, NX=NX, LM=LM, A=X['avg20'].astype(float), pid_day=X['pid_day'], yr=X['yr'], is15=is15, inst=inst, tscale=1.0)

def simulate(C, SI, D, LR, chunk=40000):
    """R：損益pt (n,NE) float32、nt：日をまたいだ回数 (n,NE) int16"""
    n = len(SI); R = np.zeros((n, NE), np.float32); NT = np.zeros((n, NE), np.int16); HB = np.zeros((n, NE), np.int32)
    p1 = P1.copy()
    if C['tscale'] != 1.0:  # 時間のルールは分で合わせる
        tm = (TYP == 0) | (TYP == 7); p1[tm] = np.round(P1[tm] * C['tscale'])
        sw = TYP == 11; p1[sw] = P1[sw]  # 直近の安値は 12/24 の印のまま（足の数）
    for a in range(0, n, chunk):
        sl = slice(a, min(n, a + chunk)); si = SI[sl].astype(np.int64); d = D[sl].astype(np.int64)
        E = C['c'][si]; A = C['A'][si]; M = C['LM'][si]
        dist = (M - E[:, None]) * d[:, None]; dd = np.where(dist > 0.05 * A[:, None], dist, np.inf); dd.sort(1)
        TP1 = np.where(np.isfinite(dd[:, 0]), E + d * dd[:, 0], np.nan); TP2 = np.where(np.isfinite(dd[:, 1]), E + d * dd[:, 1], np.nan)
        for dr in (1, -1):
            m = d == dr
            if not m.any(): continue
            o_ = np.zeros((m.sum(), NE)); x_ = np.zeros((m.sum(), NE), np.int64); mf = np.zeros((m.sum(), 2)); ma = np.zeros((m.sum(), 2))
            simall(si[m], d[m], E[m], A[m], LR[sl][m].astype(float), TP1[m], TP2[m], C['o'], C['h'], C['l'], C['c'], C['ends'], C['NX'][dr], TYP, p1, P2, P3, CAP, o_, x_, mf, ma)
            idx = np.nonzero(m)[0] + a
            R[idx] = o_; NT[idx] = (C['pid_day'][x_] - C['pid_day'][si[m]][:, None]); HB[idx] = x_ - si[m][:, None]
    return R, NT, HB

def money(inst, R, E, NT):
    sc = (REF / E)[:, None]; fin = NT * (0.03 / 365 * REF) if inst == 'cfd' else 0.0
    nrm = R * sc - COST[inst] - fin; n13 = R * sc - 13.0 - fin
    return nrm.astype(np.float32), n13.astype(np.float32)
