"""トレード一覧（入った5分足・出た5分足つき）。方向確認なしの全ルール＋ランダムな入り（調べ×向きごと、手じまいはランダム自身の前向き）。
手じまいは年ごとの前向きの選択（2018・2019 は 2020 年のもの）。出力：tr2.pkl
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from rl_build import choose
REF = 68800.0; COST = {'fut': 5.0, 'cfd': 7.0}

def money_v(inst, R, e, nt):
    return R * REF / e - COST[inst] - (nt * 0.03 / 365 * REF if inst == 'cfd' else 0)

def run():
    out = []
    import sw_agg
    for tf in ['D', '240', '60', '15']:
        R = pd.read_csv(f'/home/claude/bs/g/rl_rules_sw{tf}.csv'); R = R[R.f == 0]
        Zs = {i: sw_agg.agg(tf, i, 'W') for i in ['fut', 'cfd']}
        rc = {dr: choose(Zs, None, 0, rnd=dr) for dr in (0, 1)}
        for inst in ['fut', 'cfd']:
            X5 = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); Xs = dict(np.load(f'/home/claude/bs/g/sw_{tf}_{inst}.npz')); EX = pd.read_csv(f'/home/claude/bs/g/sw_exits_{tf}.csv').手じまい.tolist()
            to5 = lambda j: np.clip(np.searchsorted(X5['tm'] + 300, Xs['tend'][j], side='left'), 0, len(X5['tm']) - 1)
            for tag in ('sig', 'rand'):
                S = dict(np.load(f'/home/claude/bs/g/sw{tag}_{tf}_{inst}_W.npz'))
                if tag == 'sig':
                    gS = S['trig'].astype(np.int64) * 2 + (S['d'] > 0)
                    groups = [(f'sw{tf}:{r.トリガー}{r.向き}', np.nonzero(gS == r.g)[0], {y: r[f'手じまい{max(y, 2020)}'] for y in range(2018, 2027)}) for _, r in R.iterrows()]
                else:
                    groups = [(f'rand:sw{tf}:{"買" if dr == 1 else "売"}', np.nonzero((S['d'] > 0) == (dr == 1))[0], {y: EX[rc[dr][max(y, 2020)]] for y in range(2018, 2027)}) for dr in (0, 1)]
                for name, m, ch in groups:
                    yr = S['yr'][m]; e = np.array([EX.index(ch[y]) if isinstance(ch[y], str) else -1 for y in yr]); ok = e >= 0; m, yr, e = m[ok], yr[ok], e[ok]
                    if len(m) == 0: continue
                    v = money_v(inst, S['R'][m, e].astype(float), S['e'][m], S['nt'][m, e]); i = S['i'][m]; xi = np.minimum(i + S['hb'][m, e], len(Xs['tend']) - 1)
                    out.append(pd.DataFrame(dict(rule=name, inst=inst, i5=to5(i), x5=to5(xi), d=S['d'][m].astype(np.int8), v=v.astype(np.float32), yr=yr.astype(np.int16))))
        print(tf, flush=True)
    from x_core import ctx5, simulate, money
    DF = pd.read_csv('/home/claude/bs/g/kdefs.csv', index_col=0); EXk = pd.read_csv('/home/claude/bs/g/xlib_rules.csv').手じまい.tolist()
    R = pd.read_csv('/home/claude/bs/g/rl_rules_k.csv'); R = R[R.f == 0].set_index('g')
    Zs = {i: dict(np.load(f'/home/claude/bs/g/xk_{i}_W.npz')) for i in ['fut', 'cfd']}; rc = {dr: choose(Zs, None, 0, rnd=dr) for dr in (0, 1)}
    for inst in ['fut', 'cfd']:
        C = ctx5(inst, 'W'); S = dict(np.load(f'/home/claude/bs/g/ksig_{inst}_W.npz'))
        di = S['d'].astype(np.int64); si = S['i'].astype(np.int64); keep = np.isin(di, R.index.values); di, si = di[keep], si[keep]; yr = C['yr'][si]
        ch = np.full(len(si), -1)
        for g, r in R.iterrows():
            mm = di == g
            for y in range(2018, 2027):
                nm = r[f'手じまい{max(y, 2020)}']
                if isinstance(nm, str): ch[mm & (yr == y)] = EXk.index(nm)
        ok = ch >= 0; di, si, yr, ch = di[ok], si[ok], yr[ok], ch[ok]
        dr = DF['dir'].values[di]; a = DF['a'].values[di]; isline = (DF['grp'].values[di] == '線') & (a >= 0)
        LR = np.where(isline, C['LM'][si, np.maximum(a, 0)], C['c'][si])
        for st in range(0, len(si), 50000):
            sl = slice(st, st + 50000)
            Rr, NT, HB = simulate(C, si[sl], dr[sl], LR[sl]); nrm, _ = money(inst, Rr, C['c'][si[sl]], NT); ar = np.arange(len(Rr))
            out.append(pd.DataFrame(dict(rule=[f"k:{DF.trig[g]}{'買' if DF.dir[g] == 1 else '売'}" for g in di[sl]], inst=inst, i5=si[sl], x5=si[sl] + HB[ar, ch[sl]], d=dr[sl].astype(np.int8),
                                         v=nrm[ar, ch[sl]].astype(np.float32), yr=yr[sl].astype(np.int16))))
        rng = np.random.default_rng(11 + (inst == 'cfd'))
        okb = np.nonzero(C['is15'] & (C['yr'] >= 2018) & (np.arange(len(C['c'])) < C['ends'][0]) & ~np.isnan(C['A']))[0]
        ri = np.sort(rng.choice(okb, 20000, replace=False))
        for dd_ in (1, -1):
            Rr, NT, HB = simulate(C, ri, np.full(len(ri), dd_, np.int64), C['c'][ri]); nrm, _ = money(inst, Rr, C['c'][ri], NT)
            yy = C['yr'][ri]; e = np.array([rc[1 if dd_ == 1 else 0][max(y, 2020)] for y in yy]); ar = np.arange(len(ri))
            out.append(pd.DataFrame(dict(rule=f"rand:k:{'買' if dd_ == 1 else '売'}", inst=inst, i5=ri, x5=ri + HB[ar, e], d=np.int8(dd_), v=nrm[ar, e].astype(np.float32), yr=yy.astype(np.int16))))
        print('k', inst, flush=True)
    T = pd.concat(out, ignore_index=True); T['rule'] = T.rule.astype('category'); T.to_pickle('/home/claude/bs/g/tr2.pkl'); print(len(T))

if __name__ == '__main__':
    run()
