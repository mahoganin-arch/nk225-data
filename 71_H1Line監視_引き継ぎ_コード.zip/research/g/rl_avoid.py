"""「この状況では入らないほうが良い」の分析と前向き確認。
ルール：方向確認なしの全トリガー×向き（上位足4つ＋15分足の網羅）。トレード：2018〜2026 の全部の合図（重ねて持つ）、手じまいはそのルールの前向きの手じまい（2018・2019 は 2020 年のもの）。
状況（入った時点で分かるもの）：日足トレンド3種・20日の上げ下げ・20日レンジの位置・荒れ具合・当日の値幅・直前1時間と前日終値からの動き（入る向きで）・日中/夜間・時間帯・曜日・SQ週・月末月初・休日の前後・寄りの窓・日足RSI。
数の状況は前の年までの3等分で区切る。
前向き：t 年より前で「避ける状況」（両商品とも、その区分の平均がマイナスで、全体より明らかに悪い、件数が全体の半分以下）を最大2つ選び、t 年に当てはめる。
出力：rl_avoid.pkl
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from rl_build import YRS
REF = 68800.0; COST = {'fut': 5.0, 'cfd': 7.0}
FEAT = ['日足EMA20からの位置', '日足EMA60の傾き', '20日の上げ下げ', '20日レンジの中の位置', '荒れ具合(値幅の1年比)', '当日ここまでの値幅', '直前1時間の動き(入る向き)', '前日終値からの動き(入る向き)',
        '日中/夜間', '時間帯', '曜日', 'SQ週', '月末月初', '休日の前後', '寄りの窓(入る向き)', '日足RSI']
NUM = [0, 1, 2, 3, 4, 5, 6, 7, 14, 15]

def context(inst):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); c = X['c'].astype(float); A = X['avg20'].astype(float); n = len(c)
    pid = X['pid_day']; dc = pd.Series(c).groupby(pid).last(); dh = pd.Series(X['h']).groupby(pid).max(); dl = pd.Series(X['l']).groupby(pid).min()
    e20 = dc.ewm(span=20, adjust=False).mean(); e60 = dc.ewm(span=60, adjust=False).mean()
    prev = lambda s: s.shift(1).reindex(pid).values  # 前の日までの値
    F = {}
    F[0] = (c - prev(e20)) / A; F[1] = (prev(e60) - prev(e60.shift(20))) / A; F[2] = (prev(dc) - prev(dc.shift(20))) / A
    hh = dh.rolling(20).max(); ll = dl.rolling(20).min(); F[3] = (c - prev(ll)) / (prev(hh) - prev(ll))
    Ad = pd.Series(A).groupby(pid).last(); F[4] = (Ad / Ad.rolling(250, min_periods=60).median()).reindex(pid).values
    dmax = pd.Series(X['h']).groupby(pid).cummax().values; dmin = pd.Series(X['l']).groupby(pid).cummin().values; F[5] = (dmax - dmin) / A
    F['m1h'] = (c - np.r_[np.full(12, np.nan), c[:-12]]) / A; F['pd'] = (c - prev(dc)) / A
    F[8] = X['dayses'].astype(int)
    t = pd.to_datetime(X['tm'], unit='s', utc=True).tz_convert('Asia/Tokyo'); hr = t.hour.values
    F[9] = np.select([(hr >= 8) & (hr < 12), (hr >= 12) & (hr < 16), (hr >= 16) & (hr < 22)], [0, 1, 2], 3)
    F[10] = X['wd']; F[11] = (X['mk_sqw_major'] | X['mk_sqw_minor']).astype(int); F[12] = (X['mk_month_end'] | X['mk_month_start']).astype(int)
    F[13] = (X['mk_hol_before'] | X['mk_hol_after']).astype(int); F['gap'] = X['ses_gap'] / A; F[15] = X['rsi_d']
    return F, X

def trades():
    """ルールごとのトレード（5分足の位置、向き、損益、年）"""
    out = []
    import sw_agg
    for tf in ['D', '240', '60', '15']:
        R = pd.read_csv(f'/home/claude/bs/g/rl_rules_sw{tf}.csv'); R = R[R.f == 0]
        for inst in ['fut', 'cfd']:
            X5 = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); Xs = dict(np.load(f'/home/claude/bs/g/sw_{tf}_{inst}.npz')); S = dict(np.load(f'/home/claude/bs/g/swsig_{tf}_{inst}_W.npz'))
            EX = pd.read_csv(f'/home/claude/bs/g/sw_exits_{tf}.csv').手じまい.tolist(); gS = S['trig'].astype(np.int64) * 2 + (S['d'] > 0)
            i5 = np.searchsorted(X5['tm'] + 300, Xs['tend'][S['i']], side='left'); i5 = np.clip(i5, 0, len(X5['tm']) - 1)
            for _, r in R.iterrows():
                ch = {t: r[f'手じまい{t}'] for t in YRS}
                if not isinstance(ch[2020], str): continue
                ch[2018] = ch[2019] = ch[2020]
                m = np.nonzero(gS == r.g)[0]; yr = S['yr'][m]
                e = np.array([EX.index(ch[y]) if isinstance(ch.get(y), str) else -1 for y in yr]); ok = e >= 0; m, yr, e = m[ok], yr[ok], e[ok]
                v = S['R'][m, e].astype(float) * REF / S['e'][m] - COST[inst] - (S['nt'][m, e] * 0.03 / 365 * REF if inst == 'cfd' else 0)
                out.append(pd.DataFrame(dict(rule=f'sw{tf}:{r.トリガー}{r.向き}', inst=inst, i5=i5[m], d=S['d'][m], v=v, yr=yr)))
    from x_core import ctx5, simulate, money
    DF = pd.read_csv('/home/claude/bs/g/kdefs.csv', index_col=0); EXk = pd.read_csv('/home/claude/bs/g/xlib_rules.csv').手じまい.tolist()
    R = pd.read_csv('/home/claude/bs/g/rl_rules_k.csv'); R = R[R.f == 0].set_index('g')
    for inst in ['fut', 'cfd']:
        C = ctx5(inst, 'W'); S = dict(np.load(f'/home/claude/bs/g/ksig_{inst}_W.npz'))
        di = S['d'].astype(np.int64); si = S['i'].astype(np.int64); keep = np.isin(di, R.index.values); di, si = di[keep], si[keep]
        yr = C['yr'][si]
        ch = np.full(len(si), -1)
        for g, r in R.iterrows():
            mm = di == g
            for y in range(2018, 2027):
                nm = r[f'手じまい{max(y, 2020)}']
                if isinstance(nm, str): ch[mm & (yr == y)] = EXk.index(nm)
        ok = ch >= 0; di, si, yr, ch = di[ok], si[ok], yr[ok], ch[ok]
        dr = DF['dir'].values[di]; a = DF['a'].values[di]; isline = (DF['grp'].values[di] == '線') & (a >= 0)
        LR = np.where(isline, C['LM'][si, np.maximum(a, 0)], C['c'][si])
        for st in range(0, len(si), 60000):
            sl = slice(st, st + 60000)
            Rr, NT, _ = simulate(C, si[sl], dr[sl], LR[sl]); nrm, _ = money(inst, Rr, C['c'][si[sl]], NT)
            v = nrm[np.arange(len(Rr)), ch[sl]].astype(float)
            out.append(pd.DataFrame(dict(rule=[f"k:{DF.trig[g]}{'買' if DF.dir[g] == 1 else '売'}" for g in di[sl]], inst=inst, i5=si[sl], d=dr[sl], v=v, yr=yr[sl])))
    return pd.concat(out, ignore_index=True)

def run():
    T = trades(); print('trades', len(T), flush=True)
    for inst in ['fut', 'cfd']:
        F, X = context(inst); m = T.inst == inst; i5 = T.i5.values[m]; d = T.d.values[m]
        for k in range(16):
            if k == 6: v = F['m1h'][i5] * d
            elif k == 7: v = F['pd'][i5] * d
            elif k == 14: v = F['gap'][i5] * d
            else: v = F[k][i5]
            T.loc[m, f'c{k}'] = v
    T.to_pickle('/home/claude/bs/g/rl_avoid_trades.pkl')
    # 区分
    res = []; fw = []
    for rule, g in T.groupby('rule'):
        for t in range(2020, 2027):
            tr = g[g.yr < t]; te = g[g.yr == t]
            if len(te) == 0 or (tr.inst.value_counts() < 30).any() or tr.inst.nunique() < 1: continue
            cand = []
            for k in range(16):
                col = f'c{k}'
                if k in NUM:
                    q = np.nanquantile(tr[col], [1 / 3, 2 / 3]); bt = np.digitize(tr[col], q); be = np.digitize(te[col], q)
                    bt = np.where(tr[col].isna(), -1, bt); be = np.where(te[col].isna(), -1, be)
                else:
                    bt = tr[col].fillna(-1).astype(int).values; be = te[col].fillna(-1).astype(int).values
                for b in np.unique(bt):
                    if b < 0: continue
                    inb = bt == b
                    if inb.mean() > 0.5 or inb.sum() < 20: continue
                    good = True; gain = 0
                    for inst in tr.inst.unique():
                        mi = (tr.inst == inst).values
                        x_in = tr.v.values[mi & inb]; x_all = tr.v.values[mi]
                        if len(x_in) < 10 or x_in.mean() >= 0 or x_in.mean() > x_all.mean() - 0.5 * x_all.std() / np.sqrt(len(x_in)) * 2: good = False; break
                        gain += -x_in.sum()
                    if good: cand.append((gain, k, b, be == b))
            cand.sort(key=lambda z: -z[0]); pick = cand[:2]
            avoid = np.zeros(len(te), bool)
            for _, k, b, mask in pick: avoid |= mask
            for inst in te.inst.unique():
                mi = (te.inst == inst).values
                fw.append(dict(rule=rule, t=t, inst=inst, 件数=int(mi.sum()), 見送り=int((mi & avoid).sum()), そのまま合計=te.v.values[mi].sum(), 避けたあと合計=te.v.values[mi & ~avoid].sum(),
                               避けた分の合計=te.v.values[mi & avoid].sum(), 避ける状況=' / '.join(f'{FEAT[k]}={b}' for _, k, b, _ in pick)))
    FW = pd.DataFrame(fw)
    # 全期間での状況ごとの成績（参考の表）
    rows = []
    for rule, g in T.groupby('rule'):
        for k in range(16):
            col = f'c{k}'
            if k in NUM:
                q = np.nanquantile(g[col], [1 / 3, 2 / 3]); b = np.where(g[col].isna(), -1, np.digitize(g[col], q))
            else:
                b = g[col].fillna(-1).astype(int).values
            for bb in np.unique(b):
                if bb < 0: continue
                for inst in ['fut', 'cfd']:
                    mi = (g.inst == inst).values & (b == bb)
                    rows.append(dict(rule=rule, 状況=FEAT[k], 区分=int(bb), inst=inst, 件数=int(mi.sum()), 一回平均=g.v.values[mi].mean() if mi.any() else np.nan,
                                     前半=g.v.values[mi & (g.yr.values <= 2022)].mean() if (mi & (g.yr.values <= 2022)).any() else np.nan,
                                     後半=g.v.values[mi & (g.yr.values >= 2023)].mean() if (mi & (g.yr.values >= 2023)).any() else np.nan))
    BIN = pd.DataFrame(rows)
    pd.to_pickle(dict(fw=FW, bins=BIN), '/home/claude/bs/g/rl_avoid.pkl')
    s = FW.groupby('inst')[['件数', '見送り', 'そのまま合計', '避けたあと合計', '避けた分の合計']].sum(); print(s)
    r = FW.groupby('rule')[['そのまま合計', '避けたあと合計']].sum(); print('良くなったルールの割合', (r.避けたあと合計 > r.そのまま合計).mean(), len(r))

if __name__ == '__main__':
    run()
