"""15分足の網羅検証（k_sig の278トリガー）を手じまい225通りで調べ直す。
方向確認：なし＋17つ（1つずつ）。区切り：前半(〜2022)・後半(2023〜)・年2018〜2026。
出力：xk_{inst}_{fam}.npz（cnt[def,fs,b]、sum nrm/n13 [def,fs,b,exit]、ランダム cntR[dir,b] sumR[dir,b,exit]）
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from x_core import ctx5, simulate, money, NE
DF = pd.read_csv('/home/claude/bs/g/kdefs.csv', index_col=0); ND = len(DF); NF = 18; NB = 11

def gadd(out, key, M):
    if len(key) == 0: return
    o = np.argsort(key, kind='stable'); k = key[o]; u, st = np.unique(k, return_index=True)
    out[u] += np.add.reduceat(M[o].astype(np.float64), st, axis=0)

def run(inst, fam):
    C = ctx5(inst, fam); S = dict(np.load(f'/home/claude/bs/g/ksig_{inst}_{fam}.npz'))
    di = S['d'].astype(np.int64); si = S['i'].astype(np.int64); f = S['f'].astype(np.int64)
    dr = DF['dir'].values[di]; a = DF['a'].values[di]; isline = (DF['grp'].values[di] == '線') & (a >= 0)
    LR = np.where(isline, C['LM'][si, np.maximum(a, 0)], C['c'][si])
    yr = C['yr'][si]; half = (yr >= 2023).astype(np.int64); yb = yr - 2018 + 2
    cnt = np.zeros((ND, NF, NB)); s1 = np.zeros((ND * NF * NB, NE)); s2 = np.zeros((ND * NF * NB, NE))
    CH = 30000
    for st in range(0, len(si), CH):
        sl = slice(st, min(len(si), st + CH))
        R, NT, _ = simulate(C, si[sl], dr[sl], LR[sl]); nrm, n13 = money(inst, R, C['c'][si[sl]], NT)
        for k in range(NF):
            m = np.ones(R.shape[0], bool) if k == 0 else ((f[sl] >> (k - 1)) & 1).astype(bool)
            for b in (half[sl], yb[sl]):
                key = (di[sl][m] * NF + k) * NB + b[m]
                cnt.reshape(-1)[:] += np.bincount(key, minlength=ND * NF * NB)
                gadd(s1, key, nrm[m]); gadd(s2, key, n13[m])
        print(inst, fam, st, flush=True)
    # ランダム
    rng = np.random.default_rng(11 + (inst == 'cfd'))
    ok = np.nonzero(C['is15'] & (C['yr'] >= 2018) & (np.arange(len(C['c'])) < C['ends'][0]) & ~np.isnan(C['A']))[0]
    ri = np.sort(rng.choice(ok, 15000, replace=False)); RI = np.r_[ri, ri]; RD = np.r_[np.ones(15000, np.int64), -np.ones(15000, np.int64)]
    R, NT, _ = simulate(C, RI, RD, C['c'][RI]); nrm, n13 = money(inst, R, C['c'][RI], NT)
    ry = C['yr'][RI]; cR = np.zeros((2 * NB)); r1 = np.zeros((2 * NB, NE)); r2 = np.zeros((2 * NB, NE))
    for b in ((ry >= 2023).astype(np.int64), ry - 2018 + 2):
        key = (RD > 0).astype(np.int64) * NB + b; cR += np.bincount(key, minlength=2 * NB); gadd(r1, key, nrm); gadd(r2, key, n13)
    np.savez_compressed(f'/home/claude/bs/g/xk_{inst}_{fam}.npz', cnt=cnt.astype(np.float32), nrm=s1.reshape(ND, NF, NB, NE).astype(np.float32), n13=s2.reshape(ND, NF, NB, NE).astype(np.float32),
                        cntR=cR.reshape(2, NB), nrmR=r1.reshape(2, NB, NE), n13R=r2.reshape(2, NB, NE))
    print('done', inst, fam, flush=True)

if __name__ == '__main__':
    for inst in sys.argv[1].split(','):
        for fam in sys.argv[2].split(','): run(inst, fam)
