"""本当の前向き（分水嶺 g_nest と同じ手順）。各年 t（2020〜2026）について、t より前の年（2018〜t−1）だけで候補群を作り、t 年の成績を見る。
コストの見方2つで別々に候補群を作る：実コスト（net）／13円（n13：今の値段にそろえて毎回13円）。両方で残る候補（両方）も。
- 群の質：t 年の候補全部の1回平均、プラスだった候補の割合、選ぶ期間の点数と t 年の順位相関
- 上位5本の口座：点数の上位5本（同じ入り方は1本まで）を t 年に売買。同じ足・同じ向きは1本、1日2本まで
出力：hnest_{inst}.pkl、hnest_tr_{inst}.pkl
"""
import sys, gc, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs'); sys.path.insert(0, '/home/claude/bs/g')
import eng2
import h_agg, h_scr

SCORE = {'両方で優位': 'min', '安定（幅が広い）': 'min', '少数・高勝率': 'min', '後半で優位': '後半平均', '前半で優位': '前半平均'}

def run(inst, fams, tag=''):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); DF = pd.read_csv('/home/claude/bs/g/hdefs.csv', index_col=0); B = eng2.base(inst)
    res = []; trs = []
    for fam in fams:
        A = pd.read_parquet(f'/home/claude/bs/g/hagg_{inst}_{fam}.parquet')
        S_ = dict(np.load(f'/home/claude/bs/g/hsig_{inst}_{fam}.npz'))
        H = dict(np.load(f'/home/claude/bs/g/hl_{inst}_{fam}.npz'))
        F = h_agg.features(inst, fam, X, S_, DF, B, H); del H; fn = list(F.keys())
        codes = np.stack([F[k][0] for k in fn], 1).astype(np.int16)
        labs = {k: F[k][1] for k in fn}; del F; gc.collect()
        yr = X['yr'][S_['i']]; dayid = X['pid_day'][S_['i']]
        for t in range(2020, 2027):
            ys = list(range(2018, t))
            scr = {}
            for col in ['net', 'n13']:
                h_scr.COL = col
                S, grp, _ = h_scr.screen(A, ys)
                scr[col] = (S[['前半平均', '後半平均']].copy(), grp)
                del S; gc.collect()
            variants = {'実コスト': ('net', None), '13円': ('n13', None), '両方': ('net', 'n13')}
            for vname, (c1, c2) in variants.items():
                Ssc, grp = scr[c1]
                for g in grp:
                    m = grp[g].values.copy()
                    if c2 is not None: m &= scr[c2][1][g].values
                    nt = A[f'n{t}'].values
                    if m.sum() == 0:
                        res.append(dict(inst=inst, fam=fam, t=t, var=vname, grp=g, ncand=0)); continue
                    sel = m & (nt > 0)
                    r = dict(inst=inst, fam=fam, t=t, var=vname, grp=g, ncand=int(m.sum()))
                    for cc in ['net', 'nrm', 'n13']:
                        v = A[f'{cc}{t}'].values
                        r[f'avg_{cc}'] = v[sel].sum() / max(nt[sel].sum(), 1)
                    r['pos_t'] = (A[f'{c1}{t}'].values[sel] > 0).mean() if sel.any() else np.nan
                    sc = np.minimum(Ssc['前半平均'].values, Ssc['後半平均'].values) if SCORE[g] == 'min' else Ssc[SCORE[g]].values
                    sel5 = m & (nt >= 5)
                    r['rho'] = pd.Series(sc[sel5]).rank().corr(pd.Series(A[f'{c1}{t}'].values[sel5] / nt[sel5]).rank()) if sel5.sum() > 10 else np.nan
                    idx = np.nonzero(m)[0]; idx = idx[np.argsort(-sc[idx], kind='stable')]
                    pick = []; used = set()
                    for q in idx:
                        d = int(A['def'].values[q])
                        if d in used: continue
                        used.add(d); pick.append(q)
                        if len(pick) == 5: break
                    T = []
                    for rank, q in enumerate(pick):
                        d = int(A['def'].values[q]); ex = int(A['exit'].values[q]); f = int(A['feat'].values[q]); v = int(A['val'].values[q])
                        mm = (S_['d'] == d) & (codes[:, f] == v) & (yr == t)
                        if not mm.any(): continue
                        PN = h_agg.pnl(inst, {'R': S_['R'][mm], 'e': S_['e'][mm], 'nt': S_['nt'][mm]})
                        T.append(pd.DataFrame({'rank': rank, 'def': d, 'exit': ex, 'feat': fn[f], 'val': labs[fn[f]][v], 'i': S_['i'][mm], 'dir': DF['dir'].values[d],
                                               'e': S_['e'][mm], 'pt': S_['R'][mm, ex], 'net': PN[0][:, ex], 'nrm': PN[1][:, ex], 'n13': PN[2][:, ex], 'day': dayid[mm]}))
                    if T:
                        T = pd.concat(T).sort_values(['i', 'rank']).drop_duplicates(['i', 'dir'])
                        T = T[T.groupby('day').cumcount() < 2]
                        T = T.assign(inst=inst, fam=fam, t=t, var=vname, grp=g); trs.append(T)
                        r.update(top5_net=T.net.sum(), top5_nrm=T.nrm.sum(), top5_n13=T.n13.sum(), top5_n=len(T))
                    else:
                        r.update(top5_net=0.0, top5_nrm=0.0, top5_n13=0.0, top5_n=0)
                    res.append(r)
            del scr; gc.collect()
            print(inst, fam, t, flush=True)
        del A, S_, codes; gc.collect()
        pd.DataFrame(res).to_pickle(f'/home/claude/bs/g/hnest_{inst}{tag}.pkl')
        if trs: pd.concat(trs).to_pickle(f'/home/claude/bs/g/hnest_tr_{inst}{tag}.pkl')

if __name__ == '__main__':
    run(sys.argv[1], sys.argv[2].split(','), sys.argv[3] if len(sys.argv) > 3 else '')
