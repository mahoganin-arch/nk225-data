"""H4Line裏タッチ0.15A売りが効くときを、上の時間足の状態（4H・日足・週足・月足・下落率・騰落率・下向きの時間足の数）と暦で絞り込む。2020〜2026、1つずつ。"""
import sys, numpy as np, pandas as pd
sys.path.insert(0,'/home/claude/bs/g')
from cond import feats
from ss_cand import seq_idx
from cal import bar_feats
R5='zt:H4Line 裏タッチ 近さ0.15A（割れて4時間以内）売'; R6='zt:H4Line 割れて終値2本下に居続けた売'
T=pd.read_pickle('/home/claude/bs/g/tr_zt.pkl'); T['rule']=T.rule.astype(str); T=T[T.rule.isin([R5,R6,'rand:zt:売'])&(T.yr>=2018)].reset_index(drop=True)
F,names=feats(T)
FF={i:bar_feats(i)[2] for i in ['fut','cfd']}
rows=[]
for rule in [R5,R6,'rand:zt:売']:
    for inst in ['fut','cfd']:
        m=(T.rule==rule)&(T.inst==inst)&(T.yr>=2020); g=T[m]; Fg=F[m.values]
        if not rule.startswith('rand'):
            k=seq_idx(g.i5.values,g.x5.values); g=g.iloc[k]; Fg=Fg[k]
        v=g.v.values.astype(float); yr=g.yr.values
        for j,nm in enumerate(names):
            if not any(s in nm for s in ['4H','日足','週足','月足','下落率','騰落率','下向き','1H']): continue
            for val in np.unique(Fg[:,j]):
                if val<0: continue
                s=Fg[:,j]==val
                if s.sum()<15: continue
                ys=pd.Series(v[s]).groupby(yr[s]).sum()
                rows.append(dict(対象=rule.split(':',1)[1],市場=inst,状態=nm,値=int(val),回数=int(s.sum()),割合=s.mean(),一回平均=v[s].mean(),それ以外=v[~s].mean(),合計=v[s].sum(),
                                 前半=v[s&(yr<=2022)].mean(),後半=v[s&(yr>=2023)].mean(),プラスの年=int((ys>0).sum())))
R=pd.DataFrame(rows)
W=R.pivot_table(index=['対象','状態','値'],columns='市場',values=['回数','割合','一回平均','それ以外','前半','後半','合計','プラスの年']).reset_index()
W.columns=[' '.join([c for c in col if c]).strip() for col in W.columns]
ok=(W['一回平均 fut']>W['それ以外 fut'])&(W['一回平均 cfd']>W['それ以外 cfd'])&(W['前半 fut']>0)&(W['後半 fut']>0)&(W['前半 cfd']>0)&(W['後半 cfd']>0)
W['両商品・前後半ともプラスで良い']=ok
W.to_pickle('/home/claude/bs/g/ss_h4.pkl')
pd.set_option('display.width',330); pd.set_option('display.max_rows',300)
x=W[ok&W.対象.str.contains('H4Line')].sort_values(['対象','一回平均 fut'],ascending=False)
print(x[['対象','状態','値','回数 fut','割合 fut','一回平均 fut','それ以外 fut','前半 fut','後半 fut','プラスの年 fut','回数 cfd','一回平均 cfd','それ以外 cfd','前半 cfd','後半 cfd','プラスの年 cfd','合計 fut','合計 cfd']].round(2).to_string())
r=W[W.対象=='rand:zt:売'.split(':',1)[1]] if False else W[W.対象.str.contains('売')&~W.対象.str.contains('H4Line')]
print(len(r))
