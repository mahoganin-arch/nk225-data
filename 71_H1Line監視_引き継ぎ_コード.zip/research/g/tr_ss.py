"""売りの深掘り（ss）のトレード一覧を tr2 と同じ形で作る。手じまいは年ごとの前向き（2018・2019 は 2020 年のもの）。
手じまいの選び方を3通り：ss＝全部から、ssS＝短め（その日・セッションのうち）だけから、ssL＝長め（日をまたぐ）だけから。ランダム（rand:ss*:売）も同じ手順。
出力：tr_ss.pkl
"""
import numpy as np, pandas as pd
Rw = pd.read_pickle('/home/claude/bs/g/ss_raw.pkl'); AGG = Rw['agg']; TR = Rw['tr']; RU = pd.read_csv('/home/claude/bs/g/ss_rules.csv')
from ss_eval import ALLX
short = np.array([('セッション' in x or '日の終わり' in x) and '週' not in x for x in ALLX])
SUB = {'ss': np.ones(len(ALLX), bool), 'ssS': short, 'ssL': ~short}

def pick(Z2, getc, gets, mask):
    ch = {}
    for t in range(2020, 2027):
        ty = t - 2018 + 2; sc = None
        for ii in ['fut', 'cfd']:
            c, s = getc(Z2[ii], ty), gets(Z2[ii], ty)
            if c < 20: continue
            a = s / c; sc = a if sc is None else np.minimum(sc, a)
        ch[t] = -1 if sc is None else int(np.argmax(np.where(mask, sc, -np.inf)))
    ch[2018] = ch[2019] = ch[2020]; return ch

Z2 = {i: AGG[(i, 'W')] for i in ['fut', 'cfd']}
out = []; chosen = []
for pre, mask in SUB.items():
    for r in range(len(RU)):
        ch = pick(Z2, lambda Z, ty: Z['cnt'][r, 0, 2:ty].sum(), lambda Z, ty: Z['nrm'][r, 0, 2:ty].sum(0), mask)
        nm = f"{pre}:{RU.名前[r]}{RU.向き[r]}"
        chosen.append(dict(rule=nm, **{str(t): (ALLX[e] if e >= 0 else '') for t, e in ch.items() if t >= 2020}, 手じまい2027=None))
        for inst in ['fut', 'cfd']:
            T = TR[inst]; m = np.nonzero(T['rule'] == r)[0]
            if len(m) == 0: continue
            e = np.array([ch[y] for y in T['yr'][m]]); ok = e >= 0; m, e = m[ok], e[ok]
            out.append(pd.DataFrame(dict(rule=nm, inst=inst, i5=T['SI'][m], x5=T['XO'][m, e], d=T['D'][m].astype(np.int8), v=T['V'][m, e], yr=T['yr'][m].astype(np.int16))))
    for dd in (-1,):
        k = 0
        ch = pick(Z2, lambda Z, ty: Z['cntR'][k, 2:ty].sum(), lambda Z, ty: Z['nrmR'][k, 2:ty].sum(0), mask)
        for inst in ['fut', 'cfd']:
            T = TR[inst]; m = np.nonzero(T['RD'] == dd)[0]; e = np.array([ch[y] for y in T['ry'][m]])
            out.append(pd.DataFrame(dict(rule=f"rand:{pre}:売", inst=inst, i5=T['RI'][m], x5=T['XR'][m, e], d=np.int8(dd), v=T['VR'][m, e], yr=T['ry'][m].astype(np.int16))))
X = pd.concat(out, ignore_index=True); X['rule'] = X.rule.astype('category'); X.to_pickle('/home/claude/bs/g/tr_ss.pkl')
pd.DataFrame(chosen).to_pickle('/home/claude/bs/g/tr_ss_exits.pkl'); print(len(X), X.rule.nunique())
