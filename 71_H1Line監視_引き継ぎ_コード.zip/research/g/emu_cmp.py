import pickle, numpy as np, pandas as pd, sys
sys.path.insert(0,'/home/claude/bs/g')
from ss_cand import seq_idx
res=pickle.load(open('emu_research.pkl','rb'))
NM={0:'zt:H1Line 表側で届かずに切り返し（0.05A以内・触れず）買',1:'zt:H1Line 谷の値に届かずに反発（0.1A以内・触れず）買',2:'k:H1Line 山 反発0.1買',3:'sw60:H4Lineの向き転換買',4:'k:macd 15m-1H×signal 15m-1H 上順買',5:'zt:H4Line 裏タッチ 近さ0.15A（割れて4時間以内）売',10:'k:インジ5本 買い買',12:'sw60:EMA48×H4Line買',21:'k:PSAR 買い買',22:'sw60:EMA12×EMA48買',24:'k:H1Line×macd 15m-1H 下逆買'}
T=pd.concat([pd.read_pickle('tr2.pkl'),pd.read_pickle('tr_zt.pkl')],ignore_index=True); T['rule']=T.rule.astype(str); T=T[T.rule.isin(NM.values())]
C=pd.read_pickle('cand_list.pkl')
rows=[]
for (inst,hm,r),d in res.items():
    if r==26: continue
    X=np.load(f'data_{inst}.npz'); yr5=X['yr']
    es=set(d['sig'][yr5[d['sig']]>=2018].tolist()); g=T[(T.rule==NM[r])&(T.inst==inst)]; rs=set(g.i5.values.tolist())
    both=len(es&rs)
    tr=d['tr']; tr=tr[tr.yr>=2020]; k=seq_idx(tr.i5.values,tr.x5.values); tr=tr.iloc[k]
    cr=C[(C.ルール==NM[r])&(C.条件=='そのまま')].iloc[0]; L='ミニ' if inst=='fut' else 'CFD'
    ys=tr.groupby('yr').v.sum()
    rows.append(dict(No=r,市場=inst,時間足の区切り=hm,研究の合図=len(rs),Pineの合図=len(es),一致=both,研究のうち一致率=both/max(len(rs),1),Pineのうち一致率=both/max(len(es),1),
       Pine回数=len(tr),Pine1回平均=tr.v.mean(),Pine合計=tr.v.sum(),Pineプラスの年=int((ys>0).sum()),研究回数=cr[f'{L} 件数'],研究1回平均=cr[f'{L} 一回平均'],研究合計=cr[f'{L} 合計'],研究プラスの年=cr[f'{L} プラスの年']))
R=pd.DataFrame(rows); pd.set_option('display.width',300); print(R.round(3).to_string()); R.to_pickle('emu_cmp.pkl')
