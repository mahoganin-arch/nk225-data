"""選び方そのものの前向き：2018〜2021 のデータだけで「線の情報が頑丈な合図」を選び（でたらめな線と比べる段階も 2021 年まで）、
2022〜2026 にその全部を使う（方向確認なし、手じまいは前向きで選んだもの、各1枚・1つずつ）。
出力：rl_early.pkl
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from x_eval2 import combos
from rl_build import YRS, NDAY, DAY0

def early(Z):
    """B を（2018-19, 2020-21）の2区切りにした Z"""
    out = {}
    for k in ('cnt', 'nrm', 'n13'):
        a = Z[k]; h1 = a[:, :, 2:4].sum(2); h2 = a[:, :, 4:6].sum(2); out[k] = np.stack([h1, h2], 2)
    for k in ('cntR', 'nrmR', 'n13R'):
        a = Z[k]; out[k] = np.stack([a[:, 2:4].sum(1), a[:, 4:6].sum(1)], 1)
    return out

def both_frac(Zs, dirs, nmin=15):
    C = combos(Zs, dirs, nmin=nmin); ok = C['ok']; both = (C['dmin'] > 0) & (C['amin'] > 0)
    return np.nanmean(np.where(ok, both, np.nan).reshape(len(dirs), -1), 1)

def run():
    import sw_agg
    sel = []
    for tf, fams in [('D', ['W', 'r0', 'r1', 'r2', 'r3', 'r4']), ('240', ['W', 'r0', 'r1', 'r2', 'r3', 'r4']), ('60', ['W', 'r0', 'r1', 'r2', 'r3', 'r4']), ('15', ['W', 'r0', 'r1', 'r2', 'r3', 'r4']), ('k', ['W', 'r0', 'r1', 'r2'])]:
        P = {}
        for fam in fams:
            if tf == 'k':
                Zs = {i: early(dict(np.load(f'/home/claude/bs/g/xk_{i}_{fam}.npz'))) for i in ['fut', 'cfd']}
                DF = pd.read_csv('/home/claude/bs/g/kdefs.csv', index_col=0); dirs = DF.dir.values; G = [(t, '買' if d == 1 else '売') for t, d in zip(DF.trig, DF.dir)]
            else:
                Zs = {i: early(sw_agg.agg(tf, i, fam)) for i in ['fut', 'cfd']}
                TR = pd.read_csv(f'/home/claude/bs/g/sw_trigs_{tf}.csv').iloc[:, 0].tolist(); G = [(t, '買' if k == 1 else '売') for t in TR for k in (0, 1)]; dirs = np.array([1 if k == 1 else -1 for t in TR for k in (0, 1)])
            P[fam] = both_frac(Zs, dirs)
        W = P['W']; N = np.stack([P[f] for f in fams[1:]]); z = (W - np.nanmean(N, 0)) / np.nanstd(N, 0, ddof=1)
        for j, (t, d) in enumerate(G):
            sel.append(dict(調べ=tf, トリガー=t, 向き=d, 両方そろう割合_2021まで=W[j], でたらめ=np.nanmean(N[:, j]), z_2021まで=z[j]))
        print(tf, flush=True)
    S = pd.DataFrame(sel)
    S['選ばれた'] = (S['両方そろう割合_2021まで'] >= 0.15) & (S['z_2021まで'] >= 2)
    # 2022〜2026 の成績（rl の日ごとの損益）
    card = pd.read_pickle('/home/claude/bs/g/rl_card.pkl')['card']; REG = pd.read_pickle('/home/claude/bs/g/rl_card.pkl')['reg']
    STUD = ['swD', 'sw240', 'sw60', 'sw15', 'k']; Dd = {i: np.concatenate([np.load(f'/home/claude/bs/g/rl_{s}_{i}.npz')['daily'] for s in STUD]) for i in ['fut', 'cfd']}
    lab = {'D': '日足', '240': '4時間足', '60': '1時間足', '15': '15分足(スイング)', 'k': '15分足(網羅・日中〜週)'}
    days = DAY0 + pd.to_timedelta(np.arange(NDAY), unit='D'); yr = days.year.values
    rows = []
    for grp, q in [('選ばれた全部', S.選ばれた), ('選ばれた買い', S.選ばれた & (S.向き == '買')), ('選ばれた売り', S.選ばれた & (S.向き == '売'))]:
        ss = S[q]; idx = []
        for _, r in ss.iterrows():
            k = card.index[(card.調べ == lab[r.調べ]) & (card.トリガー == r.トリガー) & (card.向き == r.向き) & (card.方向確認 == 'なし')]
            if len(k): idx.append(int(k[0]))
        for i in ['fut', 'cfd']:
            x = Dd[i][idx].sum(0) if idx else np.zeros(NDAY); n = max(len(idx), 1)
            for t in range(2022, 2027):
                m = yr == t; xx = x[m]; cs = np.cumsum(xx)
                rows.append(dict(組=grp, 本数=len(idx), 商品='ミニ' if i == 'fut' else 'CFD', 年=t, 合計=xx.sum(), 一本あたり=xx.sum() / n, 最大DD=(np.maximum.accumulate(cs) - cs).max() if len(cs) else 0,
                                 下げ相場の日=x[m & REG[i]].sum(), それ以外の日=x[m & ~REG[i]].sum()))
    R = pd.DataFrame(rows)
    pd.to_pickle(dict(sel=S, year=R), '/home/claude/bs/g/rl_early.pkl')
    pd.set_option('display.width', 250); print(S[S.選ばれた].to_string()); print(R.pivot_table(index=['組', '商品'], columns='年', values='合計').round(0)); print(R.groupby(['組', '商品'])[['合計', '下げ相場の日', 'それ以外の日']].sum().round(0))

if __name__ == '__main__':
    run()
