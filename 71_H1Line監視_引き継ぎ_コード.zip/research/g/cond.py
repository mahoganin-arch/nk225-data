"""ルールごとに「入らない条件」と「入る条件」を前の年だけで選び、翌年に当てはめる（2020〜2026）。
状態：時間足ごとの線・ストキャスの状態 67（15分・1H・4H・日足・週足・月足・下向きの時間足の数・高値からの下落率など）＋ 前回の状況 16。
選び方（どちらも最大2つ、前の年を前後半に分け、両商品×前後半の4つすべてで成り立つものだけ）：
  避ける：その状態の平均がマイナスで、全体より悪い。件数は全体の50%以下・20件以上。
  入る：その状態の平均がプラスで、全体より良い。件数は全体の10%以上・20件以上。
評価：全部重ねて持つ合計と、1つずつ持つ合計（年ごとに）。同じ条件をランダムな入り（同じ調べ・同じ向き）にも当てはめる。
出力：cond.pkl
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from rl_avoid import context, FEAT, NUM
YRS = list(range(2020, 2027))

def feats(T):
    SN = pd.read_csv('/home/claude/bs/g/st_names.csv').iloc[:, 0].tolist()
    names = SN + FEAT; Fm = np.full((len(T), len(names)), -1, np.int8)
    for inst in ['fut', 'cfd']:
        m = (T.inst == inst).values; i5 = T.i5.values[m]; d = T.d.values[m]
        S = np.load(f'/home/claude/bs/g/st_{inst}.npz')['S']; Fm[m, :len(SN)] = S[i5]
        F, X = context(inst)
        for k in range(16):
            v = F['m1h'][i5] * d if k == 6 else F['pd'][i5] * d if k == 7 else F['gap'][i5] * d if k == 14 else F[k][i5]
            v = np.asarray(v, float)
            if k in NUM:
                allv = (F['m1h'] if k == 6 else F['pd'] if k == 7 else F['gap'] if k == 14 else F[k]).astype(float)
                q = np.nanquantile(allv[X['yr'] >= 2018], [1 / 3, 2 / 3]); b = np.digitize(v, q); b[np.isnan(v)] = -1
            else:
                b = np.nan_to_num(v, nan=-1).astype(int)
            Fm[m, len(SN) + k] = b
    return Fm, names

def stats(F, v, inst, half, nv=6):
    """各特徴×値ごとに（商品2×前後半2）の合計と件数 → sums[f, val, 4], cnt[f, val, 4]"""
    g = (inst * 2 + half).astype(np.int64)
    nf = F.shape[1]; key = (np.arange(nf)[None, :] * nv + np.clip(F, 0, nv - 1)) * 4 + g[:, None]
    valid = F >= 0
    s = np.bincount(key[valid], weights=np.broadcast_to(v[:, None], F.shape)[valid], minlength=nf * nv * 4).reshape(nf, nv, 4)
    c = np.bincount(key[valid], minlength=nf * nv * 4).reshape(nf, nv, 4)
    return s, c

def choose(F, v, inst, half, mode, kmax=2):
    picks = []; keep = np.ones(len(v), bool)
    for _ in range(kmax):
        s, c = stats(F[keep], v[keep], inst[keep], half[keep])
        tot_s = np.bincount((inst[keep] * 2 + half[keep]).astype(int), weights=v[keep], minlength=4); tot_c = np.bincount((inst[keep] * 2 + half[keep]).astype(int), minlength=4)
        if (tot_c < 20).any(): break
        base = tot_s / np.maximum(tot_c, 1); mean = s / np.maximum(c, 1); share = c.sum(2) / max(keep.sum(), 1)
        enough = (c >= 5).all(2) & (c.sum(2) >= 20)
        if mode == 'avoid':
            ok = enough & (share <= 0.5) & (mean < 0).all(2) & (mean < base).all(2); gain = -s.sum(2)
        else:
            ok = enough & (share >= 0.1) & (share < 0.95) & (mean > 0).all(2) & (mean > base).all(2); gain = s.sum(2)
        gain = np.where(ok, gain, -np.inf)
        if not np.isfinite(gain).any(): break
        f, val = np.unravel_index(np.argmax(gain), gain.shape); picks.append((int(f), int(val)))
        sel = F[:, f] == val
        keep &= ~sel if mode == 'avoid' else sel
    return picks

def apply(F, picks, mode):
    if not picks: return np.ones(len(F), bool)
    m = np.ones(len(F), bool)
    for f, val in picks:
        m &= (F[:, f] != val) if mode == 'avoid' else (F[:, f] == val)
    return m

def seq_sum(i5, x5, v):
    o = np.argsort(i5, kind='stable'); last = -1; s = 0.0; n = 0
    for q in o:
        if i5[q] > last: s += v[q]; n += 1; last = x5[q]
    return s, n

def run():
    src = sys.argv[1] if len(sys.argv) > 1 else 'tr2'; T = pd.read_pickle(f'/home/claude/bs/g/{src}.pkl'); T = T[T.yr >= 2018].reset_index(drop=True); T['rule'] = T.rule.astype(str).astype('category')
    F, names = feats(T); print('feats', F.shape, flush=True)
    rules = T.rule.cat.categories.tolist(); rows = []; picks_log = []
    idx_by = {r: np.nonzero((T.rule == r).values)[0] for r in rules}
    RC = {}
    for r0 in rules:
        if r0.startswith('rand:'):
            jx = idx_by[r0]; RC[r0] = (T.v.values[jx].astype(float), T.yr.values[jx], T.inst.values[jx], F[jx])
    def randname(r):
        st = r.split(':')[0]; return f"rand:{st}:{r[-1]}"
    for r in rules:
        ix = idx_by[r]; g = T.iloc[ix]; Fg = F[ix]; g_i5 = g.i5.values; g_x5 = g.x5.values; v = g.v.values.astype(float); inst = (g.inst.values == 'cfd').astype(int); yr = g.yr.values
        rr = randname(r) if not r.startswith('rand:') else None
        for t in YRS:
            tr = yr < t; te = yr == t
            if te.sum() == 0 or tr.sum() < 60: continue
            ty = np.unique(yr[tr]); mid = ty[len(ty) // 2] if len(ty) > 1 else ty[0]; half = (yr >= mid).astype(int)
            P = {m: choose(Fg[tr], v[tr], inst[tr], half[tr], m) for m in ('avoid', 'require')}
            for m, pk in P.items():
                picks_log.append(dict(rule=r, t=t, 型={'avoid': '避ける', 'require': '入る条件'}[m], 条件=' かつ '.join(f'{names[f]}={val}' for f, val in pk) if m == 'require' else ' / '.join(f'{names[f]}={val}' for f, val in pk)))
            for k, ins in enumerate(['fut', 'cfd']):
                mi = te & (inst == k)
                if mi.sum() == 0: continue
                row = dict(rule=r, t=t, inst=ins)
                for lab, mask in [('そのまま', np.ones(len(v), bool)), ('避ける', apply(Fg, P['avoid'], 'avoid')), ('入る条件', apply(Fg, P['require'], 'require'))]:
                    mm = mi & mask; row[f'{lab} 件数'] = int(mm.sum()); row[f'{lab} 合計'] = v[mm].sum()
                    s, n = seq_sum(g_i5[mm], g_x5[mm], v[mm]); row[f'{lab} 1つずつ合計'] = s; row[f'{lab} 1つずつ件数'] = n
                    if rr is not None and rr in RC and lab != 'そのまま':
                        v2, y2, i2, F2 = RC[rr]; mode = 'avoid' if lab == '避ける' else 'require'
                        mm2 = (y2 == t) & (i2 == ins) & apply(F2, P[mode], mode)
                        row[f'{lab} ランダム1回平均'] = v2[mm2].mean() if mm2.any() else np.nan
                if rr is not None and rr in RC:
                    v2, y2, i2, F2 = RC[rr]; mm2 = (y2 == t) & (i2 == ins); row['そのまま ランダム1回平均'] = v2[mm2].mean() if mm2.any() else np.nan
                rows.append(row)
        if len(rows) % 200 == 0: print(r, len(rows), flush=True)
    R = pd.DataFrame(rows); PL = pd.DataFrame(picks_log)
    pd.to_pickle(dict(res=R, picks=PL, names=names), '/home/claude/bs/g/cond.pkl' if src == 'tr2' else f'/home/claude/bs/g/cond_{src}.pkl')
    R['向き'] = np.where(R.rule.str.endswith('買'), '買', '売'); R['ランダム'] = R.rule.str.startswith('rand:')
    s = R.groupby(['ランダム', '向き', 'inst'])[[c for c in R.columns if c.endswith('合計')]].sum()
    pd.set_option('display.width', 250); print(s.round(0).to_string())

if __name__ == '__main__':
    run()
