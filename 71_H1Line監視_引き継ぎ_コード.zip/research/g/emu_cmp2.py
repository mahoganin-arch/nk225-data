import pickle, numpy as np, pandas as pd, sys
sys.path.insert(0,'/home/claude/bs/g')
from ss_cand import seq_idx
from zt_eval import ALLX
from x_core import ctx5, simulate, money
res=pickle.load(open('emu_research.pkl','rb'))
Rw=pd.read_pickle('zt_raw.pkl'); RU=pd.read_csv('zt_rules.csv')
EXk=pd.read_csv('xlib_rules.csv').手じまい.tolist()
def summ(i5,x5,v,yr):
    m=yr>=2020; i5,x5,v,yr=i5[m],x5[m],v[m],yr[m]; k=seq_idx(i5,x5); v=v[k]; return len(v), v.mean(), v.sum()
rows=[]
zt={0:('H1Line 表側で届かずに切り返し（0.05A以内・触れず）','最大利益0.5A後、半分戻したら出る（週まで）・損切りなし'),1:('H1Line 谷の値に届かずに反発（0.1A以内・触れず）','終値がD1Lineを逆に抜け（週の終わりまで）・損切りなし'),5:('H4Line 裏タッチ 近さ0.15A（割れて4時間以内）','終値がH1Lineを逆に抜け（週の終わりまで）・損切りなし')}
for inst in ['fut','cfd']:
    Tz=Rw['tr'][inst]
    for r,(nm,ex) in zt.items():
        ri=RU.index[RU.名前==nm][0]; e=ALLX.index(ex); m=Tz['rule']==ri
        n,a,s=summ(Tz['SI'][m],Tz['XO'][m,e],Tz['V'][m,e],Tz['yr'][m])
        em=res[(inst,'clock',r)]['tr']; n2,a2,s2=summ(em.i5.values,em.x5.values,em.v.values,em.yr.values)
        rows.append(dict(市場=inst,No=r,手じまい=ex,研究エンジン回数=n,研究エンジン1回平均=a,研究エンジン合計=s,Pine再現回数=n2,Pine再現1回平均=a2,Pine再現合計=s2))
    C=ctx5(inst,'W'); X=np.load(f'data_{inst}.npz')
    kk={4:'終値がD1Lineを逆に抜け（週の終わりまで）・損切りなし',21:'終値がD1Lineを逆に抜け（週の終わりまで）・損切りなし',2:'H4Lineの向き転換（週の終わりまで）・損切り 入値から0.5A',24:'最大利益0.5A後、半分戻したら出る（週まで）・損切りなし',10:'終値がD1Lineを逆に抜け（週の終わりまで）・損切りなし'}
    for r,ex in kk.items():
        sig=res[(inst,'clock',r)]['sig']; sig=sig[X['yr'][sig]>=2020]
        R,NT,HB=simulate(C,sig,np.ones(len(sig),np.int64),C['c'][sig]); nrm,_=money(inst,R,C['c'][sig],NT); e=EXk.index(ex)
        n,a,s=summ(sig,sig+HB[:,e],nrm[:,e],X['yr'][sig])
        em=res[(inst,'clock',r)]['tr']; n2,a2,s2=summ(em.i5.values,em.x5.values,em.v.values,em.yr.values)
        rows.append(dict(市場=inst,No=r,手じまい=ex,研究エンジン回数=n,研究エンジン1回平均=a,研究エンジン合計=s,Pine再現回数=n2,Pine再現1回平均=a2,Pine再現合計=s2))
R=pd.DataFrame(rows); pd.set_option('display.width',300); pd.set_option('display.max_colwidth',40); print(R.round(1).to_string()); R.to_pickle('emu_cmp2.pkl')
