"""インジ（Indi01〜06）が何本そろったときに入ったかで分けた成績（H1Line山の家族など）。手じまいは方向確認なしのルールと同じ（年ごとの前向き）。ランダムも同じ本数・同じ手じまい・1つずつ。"""
import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0,'/home/claude/bs/g')
from rs3 import one_stats, rand_stats, compare
DF=pd.read_csv('kdefs.csv',index_col=0); IN=pd.read_csv('k_inames.csv').iloc[:,0].tolist()
res=pickle.load(open('rs3_k_res0.pkl','rb'))
AGR={}
for inst in ['fut','cfd']:
    I=np.load(f'kind_{inst}_W.npz')['I'].astype(float); col={n:j for j,n in enumerate(IN)}
    c1=np.where(I[:,col['Indi01']]>=60,1,np.where(I[:,col['Indi01']]<=40,-1,0)); R=np.stack([I[:,col[f'Indi0{m}向き']] for m in range(2,7)],1)
    for d in (1,-1): AGR[(inst,d)]=(c1==d).astype(int)+(R==d).sum(1)
want=['H1Line 山 反発0.05','H1Line 山 反発0.1','H1Line 山 反発0.15','H1Line 山 抜け','H1Line 谷 反発0.1','H4Line 反発0.15','H4Line 反発0.05','macd 1D-1W 反発0.1','H1Line 反発0.05']
rows=[]
for g,r in DF.iterrows():
    if r.trig not in want or (g,0) not in res: continue
    dr=int(r.dir); nm=f"k:{r.trig}{'買' if dr==1 else '売'}"
    for lab,lo,hi in [('6本そろう',6,6),('5本',5,5),('4本',4,4),('3本',3,3),('2本以下',0,2),('5本以上',5,6),('4本以上',4,6),('3本以上',3,6),('すべて（なし）',0,6)]:
        row=dict(ルール=nm,インジがそろった本数=lab)
        for inst,L in [('fut','ミニ'),('cfd','CFD')]:
            i5,x5,v,yr,e,pools=res[(g,0)][inst]; a=AGR[(inst,dr)]; m=(a[i5]>=lo)&(a[i5]<=hi)
            pl=[(p[0][(a[p[0]]>=lo)&(a[p[0]]<=hi)],p[1][(a[p[0]]>=lo)&(a[p[0]]<=hi)],p[2][(a[p[0]]>=lo)&(a[p[0]]<=hi)],p[3][(a[p[0]]>=lo)&(a[p[0]]<=hi)]) for p in pools]
            row.update(one_stats(i5[m],x5[m],v[m],yr[m],f'{L} ')); row.update(rand_stats(pl,f'{L} ランダム')); compare(row,L)
        row['t値の平均']=(row['ミニ t値']+row['CFD t値'])/2; rows.append(row)
R=pd.DataFrame(rows); R.to_pickle('ind_lv.pkl')
pd.set_option('display.width',300); pd.set_option('display.max_rows',200)
print(R[['ルール','インジがそろった本数','ミニ 回数','ミニ 1回平均','ミニ ランダム1回平均','CFD 回数','CFD 1回平均','CFD ランダム1回平均','t値の平均','ミニ 前半の差','ミニ 後半の差','CFD 前半の差','CFD 後半の差','ミニ プラスの年','CFD プラスの年']].round(1).to_string())
