"""形の前向き：確かめる年 t ごとに、t より前の年だけで「ランダムに入るより良い形（トリガー×方向確認、手じまい36通りの平均）」を選び、
t 年の成績（ランダムとの差・そのものの1回平均）を見る。選び方：2商品とも、前の年の差の合計がプラスで、差の小さい方が大きい順に上位10（同じトリガーは1つ）。
本物の線とでたらめな線（r0〜r5）で同じ手順。出力：kformfwd.pkl"""
import sys, numpy as np, pandas as pd
YEARS=list(range(2018,2027))
DF=pd.read_csv('/home/claude/bs/g/kdefs.csv',index_col=0)
def yearly(inst,fam):
    cols=['def','exit','fset']+[f'{c}{y}' for c in ['n','nrm'] for y in YEARS]
    A=pd.read_parquet(f'/home/claude/bs/g/kagg_{inst}_{fam}.parquet',columns=cols)
    for y in YEARS: A[f'a{y}']=A[f'nrm{y}']/A[f'n{y}'].replace(0,np.nan)
    g=A.groupby(['def','fset']); M=g[[f'a{y}' for y in YEARS]].mean(); N=g[[f'n{y}' for y in YEARS]].max()
    return M,N
def ryearly(inst):
    R=pd.read_parquet(f'/home/claude/bs/g/kragg_{inst}.parquet'); R=R[R.col=='nrm']
    for y in YEARS: R[f'a{y}']=R[f's{y}']/R[f'n{y}'].replace(0,np.nan)
    return R.groupby(['dir','fset'])[[f'a{y}' for y in YEARS]].mean()
RY={i:ryearly(i) for i in ['fut','cfd']}
if __name__=='__main__':
  out=[]
  for fam in ['W','r0','r1','r2','r3','r4','r5']:
      D={}
      for inst in ['fut','cfd']:
          M,N=yearly(inst,fam)
          dirs=DF.dir.values[M.index.get_level_values(0)]
          rk=pd.MultiIndex.from_arrays([dirs,M.index.get_level_values(1)])
          Rv=RY[inst].reindex(rk).values
          Dm=pd.DataFrame(M.values-Rv,index=M.index,columns=YEARS); D[inst]=(Dm,M,N)
      grp=DF.grp.values
      for t in range(2020,2027):
          ys=[y for y in YEARS if y<t]
          sc={}
          for inst in ['fut','cfd']:
              Dm,M,N=D[inst]; w=N[[f'n{y}' for y in ys]].values; v=Dm[ys].values
              ok=(w.sum(1)>=30)
              s=np.where(ok,np.nansum(v*w,1)/np.maximum(w.sum(1),1),np.nan); sc[inst]=pd.Series(s,index=Dm.index)
          S=pd.concat(sc,axis=1).dropna(); S['min']=S.min(axis=1)
          S=S[(S['min']>0)]
          S=S[[grp[d]!='インジ' for d in S.index.get_level_values(0)]] if fam!='W' else S
          S=S.sort_values('min',ascending=False)
          pick=[]; used=set()
          for (d,fs),r in S.iterrows():
              if d in used: continue
              used.add(d); pick.append((d,fs))
              if len(pick)==10: break
          for inst in ['fut','cfd']:
              Dm,M,N=D[inst]
              vals=[(Dm.loc[p,t],M.loc[p,f'a{t}'],N.loc[p,f'n{t}']) for p in pick]
              vals=[v for v in vals if np.isfinite(v[0]) and v[2]>0]
              if not vals: continue
              w=np.array([v[2] for v in vals])
              out.append(dict(fam=fam,t=t,inst=inst,差=np.average([v[0] for v in vals],weights=w),成績=np.average([v[1] for v in vals],weights=w),件数=w.sum(),
                              選んだ形=' / '.join(f"{DF.trig[d]}{'買' if DF.dir[d]==1 else '売'}" for d,_ in pick[:3])))
      print(fam,flush=True)
  O=pd.DataFrame(out); O.to_pickle('/home/claude/bs/g/kformfwd.pkl')
  pd.set_option('display.width',250)
  print(O.pivot_table(index=['fam'],columns=['inst'],values='差',aggfunc='mean').round(1))
  print(O[O.fam=='W'][['t','inst','差','成績','件数','選んだ形']].round(1).to_string())
