import numpy as np, pandas as pd
REF=68800.0
from emu2 import EX
EXA=dict(EX)
EXA.update({1:(2,None,0,1,1,None),3:(8,None,240,0,1,None),12:(8,None,240,0,1,None),22:(9,None,240,0,1,None),5:(4,None,0,1,-1,None)})
def run_all(B,E,sig,r,cost):
    t,slm,cap,wk,dr,tp=EXA[r]; c,h,l,o,A=B['c'],B['h'],B['l'],B['o'],B['A']; n=len(c)
    h4=B['h4']; d1=B['d1']; dh=np.diff(h4,prepend=np.nan); pdh=np.r_[np.nan,dh[:-1]]
    ev={1:(dh<0)&(pdh>=0),2:(c<d1)&(np.r_[np.nan,c[:-1]]>=np.r_[np.nan,d1[:-1]]),4:(c>B['h1'])&(np.r_[np.nan,c[:-1]]<=np.r_[np.nan,B['h1'][:-1]]),8:B['u60dn'].astype(bool),11:(dh>0)&(pdh<=0)}.get(t,np.zeros(n,bool))
    # 2本目の線（研究と同じ19本の線は使えないので H系3本＋山谷＋macd/signal 15m-1H の近いもので代用せず、ここでは型3は研究エンジンで比べる）
    LM=B['LM19'] if 'LM19' in B else np.stack([B['h1'],B['h4'],B['d1'],B['mc1'],B['sg1'],B['h1pk'],B['h1vl']],1)
    # 1時間足の本数
    hc=np.cumsum(B['end60'].astype(int))
    out=[]; inpos=False
    for i in range(n):
        if inpos:
            x=np.nan
            if not np.isnan(sl) and ((dr==1 and l[i]<=sl) or (dr==-1 and h[i]>=sl)): x=min(o[i],sl) if dr==1 else max(o[i],sl)
            if np.isnan(x) and not np.isnan(tpv) and ((dr==1 and h[i]>=tpv) or (dr==-1 and l[i]<=tpv)): x=max(o[i],tpv) if dr==1 else min(o[i],tpv)
            if np.isnan(x):
                unit=hc[i]-hc0 if r in (3,12,22,30) else i-ei
                if ev[i] or (cap>0 and unit>=cap) or (wk and B['weekEnd'][i]): x=c[i]
            if not np.isnan(x): out.append((B['i5'][ei],B['i5'][i],e,x)); inpos=False
        if not inpos and sig[i]:
            inpos=True; e=c[i]; ei=i; hc0=hc[i]
            sl=e-dr*0.5*A[i] if slm=='sl05' else (E['sg4'][i]-dr*0.25*A[i] if slm=='line' else np.nan)
            tpv=np.nan
            if tp is not None: tpv=e+dr*(tp[1]*A[i] if tp[0]=='A' else tp[1])
            if t==3:
                dist=(LM[i]-e)*dr; dd=np.sort(dist[dist>0.05*A[i]]); tpv=e+dr*dd[1] if len(dd)>1 else np.nan
    T=pd.DataFrame(out,columns=['i5','x5','e','x']); T['v']=(T.x-T.e)*dr*REF/T.e-cost; return T
