"""15分足チャートで見る線・インジを計算し、5分足に「その足の終わりで分かっている値」として載せる。
線：H1/H4/D1Line、MACDmacd/signal（15m-1H・1H-4H・4H-1D・1D-1W・週足（m=672））、H系の山・谷（6本）＝21本
インジ：ストキャス速い(35,21,21)・遅い(140,84,84) の %K・%D、Indi01＝Stoch(5,3,3)%K、Indi02〜06＝MACD(12m,26m) 本線（m=1..5）の上げ下げ、PSAR(0.02,0.2) の向き
fam='W' 本物、'r*' でたらめ（線だけ。h_lines と同じずれ方）
出力：kind_{inst}_{fam}.npz
"""
import sys, numpy as np, pandas as pd
from scipy.signal import lfilter
sys.path.insert(0, '/home/claude/bs'); sys.path.insert(0, '/home/claude/bs/g')
import eng2
from h_lines import hfilt, ema, bars15, peaks

HL = [('H1Line', 4), ('H4Line', 16), ('D1Line', 96)]
MAC = [('15m-1H', 1), ('1H-4H', 4), ('4H-1D', 16), ('1D-1W', 96), ('週足', 672)]
LNAMES = [n for n, _ in HL] + [f'macd {n}' for n, _ in MAC] + [f'signal {n}' for n, _ in MAC] + [f'{n} {k}' for n, _ in HL for k in ('山', '谷')]
SPAN = dict([(n, 12 * m) for n, m in HL] + [(f'macd {n}', 12 * m) for n, m in MAC] + [(f'signal {n}', 26 * m) for n, m in MAC])

def psar(h, l, step=0.02, mx=0.2):
    n = len(h); up = True; af = step; ep = h[0]; sar = l[0]; dirn = np.zeros(n, np.int8)
    for i in range(1, n):
        sar = sar + af * (ep - sar)
        if up:
            sar = min(sar, l[i - 1], l[i - 2] if i > 1 else l[i - 1])
            if l[i] < sar: up = False; sar = ep; ep = l[i]; af = step
            elif h[i] > ep: ep = h[i]; af = min(af + step, mx)
        else:
            sar = max(sar, h[i - 1], h[i - 2] if i > 1 else h[i - 1])
            if h[i] > sar: up = True; sar = ep; ep = h[i]; af = step
            elif l[i] < ep: ep = l[i]; af = min(af + step, mx)
        dirn[i] = 1 if up else -1
    return dirn

def stoch(H, L, C, K, S, D):
    hh = pd.Series(H).rolling(K).max(); ll = pd.Series(L).rolling(K).min(); c = pd.Series(C)
    k = 100 * (c - ll).rolling(S).sum() / (hh - ll).rolling(S).sum()
    return k.values, k.rolling(D).mean().values

def build(inst, fam):
    B = eng2.base(inst); d = B['d']
    k15 = d.t.dt.floor('15min'); g = d.groupby(k15, sort=True)
    b = g.agg(h=('h', 'max'), l=('l', 'min'), c=('c', 'last'))
    last_i = g.apply(lambda s: s.index[-1]).values
    x = b.c.values.astype(float); H = b.h.values.astype(float); Lw = b.l.values.astype(float); n15 = len(x)
    lines = {}
    for nm, m in HL: lines[nm] = hfilt(x, m)
    for nm, m in MAC:
        e12 = ema(x, 12 * m); e26 = ema(x, 26 * m)
        lines[f'macd {nm}'] = e12; lines[f'signal {nm}'] = e26 + ema(e12 - e26, 9 * m)
    if fam != 'W':
        rng = np.random.default_rng(777 * int(fam[1:]) + (0 if inst == 'fut' else 1))
        P, _ = B['day']; avg20 = (P.h - P.l).rolling(20).mean().shift(1)
        A15 = pd.Series(d['day'].values[last_i]).map(pd.Series(avg20.values, index=P.index)).values
        A15 = np.nan_to_num(A15, nan=np.nanmedian(A15))
        for nm in list(lines):
            s = SPAN[nm]; z = rng.standard_normal(n15); z = ema(ema(z, s), s); z = (z - z.mean()) / z.std()
            dist = np.abs(x - lines[nm]) / A15; c = np.nanmedian(dist[int(min(3 * s, n15 // 2)):])
            lines[nm] = lines[nm] + c * A15 * z
    slopes = []
    for nm, _ in HL:
        pk, vl, sg = peaks(lines[nm]); lines[f'{nm} 山'] = pk; lines[f'{nm} 谷'] = vl; slopes.append(sg)
    M15 = np.stack([lines[k] for k in LNAMES], 1)
    # インジ（本物・でたらめ共通。価格だけで決まる）
    fk, fd = stoch(H, Lw, x, 35, 21, 21); sk, sd = stoch(H, Lw, x, 140, 84, 84); i1, _ = stoch(H, Lw, x, 5, 3, 3)
    rise = []
    for m in range(1, 6):
        mac = ema(x, 12 * m) - ema(x, 26 * m); rise.append(np.sign(np.diff(mac, prepend=np.nan)))
    ps = psar(H, Lw)
    lsl = [np.sign(np.diff(lines[k], prepend=np.nan)) for k in LNAMES[:13]]  # 線の傾き（H系3本・macd5本・signal5本）
    I15 = np.column_stack([fk, fd, sk, sd, i1] + rise + [ps] + lsl)
    INAMES = ['速K', '速D', '遅K', '遅D', 'Indi01'] + [f'Indi0{m+1}向き' for m in range(1, 6)] + ['PSAR'] + [f'{k} 傾き' for k in LNAMES[:13]]
    n = len(d); k = np.searchsorted(last_i, np.arange(n))
    is_last = np.zeros(n, bool); is_last[last_i] = True
    idx = np.where(is_last, k, k - 1); ok = idx >= 0
    L = np.full((n, len(LNAMES)), np.nan, np.float32); L[ok] = M15[idx[ok]]
    I = np.full((n, I15.shape[1]), np.nan, np.float32); I[ok] = I15[idx[ok]]
    warm = d.t.values < np.datetime64('2018-01-01T00:00'); L[warm] = np.nan
    np.savez_compressed(f'/home/claude/bs/g/kind_{inst}_{fam}.npz', L=L, I=I, is15=is_last)
    if fam == 'W':
        pd.Series(LNAMES).to_csv('/home/claude/bs/g/k_lnames.csv', index=False); pd.Series(INAMES).to_csv('/home/claude/bs/g/k_inames.csv', index=False)
    print(inst, fam, n, flush=True)

if __name__ == '__main__':
    for inst in sys.argv[1].split(','):
        for fam in sys.argv[2].split(','):
            build(inst, fam)
