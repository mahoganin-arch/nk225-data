"""売りの深掘り：先に決めた売りのルール（15分足チャート、5分足データの15分足の終わりで判定）。
観点：A 天井・下げの始まり／B 急落の続き／C 行き過ぎの戻し／D 時間帯／E はっきりした下げ相場での戻り売り／F 値幅の拡大。
fam='W' 本物の線、'r*' でたらめな線。価格だけのルールは fam によらず同じ。
出力：ss_{inst}_{fam}.npz（i, d, rule, lr）、ss_rules.csv（名前・向き・観点・線を使うか）
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from zt_rules import up_stoch, zigzag, first
LN = pd.read_csv('/home/claude/bs/g/k_lnames.csv').iloc[:, 0].tolist(); IN = pd.read_csv('/home/claude/bs/g/k_inames.csv').iloc[:, 0].tolist()

def onset(m):
    m = np.asarray(m, bool); return m & ~np.r_[False, m[:-1]]

def build(inst, fam):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); K = dict(np.load(f'/home/claude/bs/g/kind_{inst}_{fam}.npz')); KW = dict(np.load(f'/home/claude/bs/g/kind_{inst}_W.npz'))
    o = X['o'].astype(float); c = X['c'].astype(float); h = X['h'].astype(float); l = X['l'].astype(float); A = X['avg20'].astype(float); is15 = K['is15']
    LM = K['L'].astype(float); I = KW['I'].astype(float); col = {nm: j for j, nm in enumerate(IN)}
    q = np.nonzero(is15)[0]; n = len(q)
    grp = np.cumsum(np.r_[0, is15[:-1]])
    c15 = c[q]; h15 = pd.Series(h).groupby(grp).max().values[:n]; l15 = pd.Series(l).groupby(grp).min().values[:n]; o15 = pd.Series(o).groupby(grp).first().values[:n]
    A15 = A[q]; Ln = {nm: LM[q, LN.index(nm)] for nm in LN}
    end5 = X['tm'][q] + 300
    S1 = up_stoch(inst, '60', end5); S4 = up_stoch(inst, '240', end5); SD = up_stoch(inst, 'D', end5)
    ses = X['pid_ses'][q]; day = X['pid_day'][q]
    ses_first = np.r_[True, ses[1:] != ses[:-1]]
    bar_in_ses = pd.Series(np.ones(n)).groupby(ses).cumsum().values  # 1 からの番号
    pc15 = np.r_[np.nan, c15[:-1]]
    ev = {}; meta = {}
    def put(name, mask, kind, uses_line, lr=None):
        mask = np.asarray(mask, bool) & ~np.isnan(A15)
        ev[name] = (q[mask], (lr[mask] if lr is not None else c15[mask])); meta[name] = (kind, uses_line)
    v1, v4, vD = Ln['H1Line'], Ln['H4Line'], Ln['D1Line']
    sl = lambda v: np.sign(np.nan_to_num(np.diff(v, prepend=np.nan)))
    s1, s4, sD = sl(v1), sl(v4), sl(vD)
    turn_dn = lambda s: (s < 0) & (np.r_[0, s[:-1]] >= 0)
    # ===== A 天井・下げの始まり =====
    for thr in (0.25, 0.5):
        piv = zigzag(h15, l15, thr * np.nan_to_num(A15, nan=np.nanmedian(A15)))
        dbl = np.zeros(n, bool); lh = np.zeros(n, bool)
        # 確定した 山1・谷・山2 のあと、谷の値を終値で割った最初の足
        for k in range(2, len(piv)):
            (i2, j2, v2, t2), (i1, j1, vt, tt), (i0, j0, v0, t0) = piv[k], piv[k - 1], piv[k - 2]
            if not (t2 == 1 and tt == -1 and t0 == 1): continue
            a = A15[i2] if not np.isnan(A15[i2]) else np.nanmedian(A15)
            nxt_end = piv[k + 1][0] if k + 1 < len(piv) else n
            seg = np.arange(i2, min(nxt_end + 1, i2 + 192, n))
            br = seg[(c15[seg] < vt)]
            if len(br) == 0: continue
            b = br[0]
            if abs(v2 - v0) <= 0.1 * a: dbl[b] = True
            if v0 - v2 >= 0.05 * a: lh[b] = True
        put(f'A 二番天井のネックライン割れ（ジグザグ{thr}A）', dbl, 'A 天井・下げの始まり', False)
        put(f'A 高値切り下げのあと安値割れ（ジグザグ{thr}A）', lh, 'A 天井・下げの始まり', False)
    put('A D1Lineが下向きに変わる（価格がH4Line・D1Lineの下）', turn_dn(sD) & (c15 < v4) & (c15 < vD), 'A 天井・下げの始まり', True, vD)
    put('A H4Lineが下向きに変わる（D1Lineの下・D1Line下向き）', turn_dn(s4) & (c15 < vD) & (sD < 0), 'A 天井・下げの始まり', True, v4)
    pairs = [('macd 15m-1H', 'signal 15m-1H'), ('macd 1H-4H', 'signal 1H-4H'), ('macd 4H-1D', 'signal 4H-1D'), ('macd 1D-1W', 'signal 1D-1W')]
    ndn = sum((Ln[a] < Ln[b]).astype(int) for a, b in pairs)
    put('A MACDの線が4つの時間足ですべて陰転（そろった最初の足）', onset(ndn == 4), 'A 天井・下げの始まり', False)
    put('A 3つ以上が陰転・1D-1Wも陰転になった足', onset((ndn >= 3) & (Ln['macd 1D-1W'] < Ln['signal 1D-1W'])), 'A 天井・下げの始まり', False)
    allx = (S1['fk'] < S1['fd']) & (S4['fk'] < S4['fd']) & (SD['fk'] < SD['fd'])
    put('A 1H・4H・日足の速ストキャスがすべてデッド（そろった最初の足）', onset(allx), 'A 天井・下げの始まり', False)
    put('A 同上（日足の速Kが50以上から）', onset(allx) & (SD['fk'] >= 50), 'A 天井・下げの始まり', False)
    # ===== B 急落の続き =====
    pdl = SD['l']; pdh = SD['h']
    brk = (c15 < pdl) & (pc15 >= np.r_[np.nan, pdl[:-1]])
    put('B 前日安値を終値で割る（その日の最初）', first(brk, day), 'B 急落の続き', False)
    put('B 前日安値を終値で割る（H4Lineの下）', first(brk & (c15 < v4), day), 'B 急落の続き', True, v4)
    sl_lo = pd.Series(l15).groupby(ses).cummin().values; prev_lo = pd.Series(sl_lo).groupby(ses).shift(1).values
    sb = (c15 < prev_lo) & (bar_in_ses > 4)
    put('B セッションの安値を終値で割る（開始から1時間後以降、最初）', first(sb, ses), 'B 急落の続き', False)
    put('B セッションの安値割れ（D1Lineの下）', first(sb & (c15 < vD), ses), 'B 急落の続き', True, vD)
    # 窓：セッションの最初の足の始値 − 前のセッションの最後の終値
    prev_close = np.r_[np.nan, c15[:-1]]; gap = np.where(ses_first, o15 - prev_close, np.nan); gap = pd.Series(gap).groupby(ses).transform('first').values
    sopen = pd.Series(np.where(ses_first, o15, np.nan)).groupby(ses).transform('first').values
    pclose = pd.Series(np.where(ses_first, prev_close, np.nan)).groupby(ses).transform('first').values
    for g in (0.2, 0.4):
        put(f'B 窓下げ{g}A以上で最初の15分足が陰線', ses_first & (gap <= -g * A15) & (c15 < o15), 'B 急落の続き', False)
        put(f'C 窓上げ{g}A以上で最初の15分足が陰線（窓埋め狙い）', ses_first & (gap >= g * A15) & (c15 < o15), 'C 行き過ぎの戻し', False)
    put('B 窓下げ0.2Aを1時間たっても埋めない', (bar_in_ses == 4) & (gap <= -0.2 * A15) & (c15 < sopen) & (h15 < pclose), 'B 急落の続き', False)
    rng = h15 - l15
    for w in (0.3, 0.5):
        put(f'B 大陰線（値幅{w}A以上・安値近くで終わる・H1Lineの下）', (rng >= w * A15) & (c15 - l15 <= 0.2 * rng) & (c15 < o15) & (c15 < v1), 'B 急落の続き', True, v1)
    d4 = c15 - np.r_[np.full(4, np.nan), c15[:-4]]
    put('B 1時間で0.5A以上下げた（D1Lineの下・セッションで最初）', first((d4 <= -0.5 * A15) & (c15 < vD), ses), 'B 急落の続き', True, vD)
    for nm in ('H4Line 谷', 'D1Line 谷'):
        v = Ln[nm]; put(f'B {nm}の値を終値で割る', (c15 < v) & (pc15 >= np.r_[np.nan, v[:-1]]), 'B 急落の続き', True, v)
    # ===== C 行き過ぎの戻し =====
    fk, fd = I[q, col['速K']], I[q, col['速D']]; pfk = np.r_[np.nan, fk[:-1]]
    out80 = (pfk >= 80) & (fk < 80)
    for w in (1.0, 1.5):
        put(f'C D1Lineから{w}A以上上で速Kが80を下に出る', out80 & (c15 - vD >= w * A15), 'C 行き過ぎの戻し', True, vD)
    put('C 前日高値をヒゲで越えて終値は下（ダマシ）', first((h15 > pdh) & (c15 < pdh) & (pc15 < pdh), day), 'C 行き過ぎの戻し', False)
    mac_dn = (Ln['macd 15m-1H'] < Ln['signal 15m-1H']) & (np.r_[np.nan, Ln['macd 15m-1H'][:-1]] >= np.r_[np.nan, Ln['signal 15m-1H'][:-1]])
    u16 = c15 - np.r_[np.full(16, np.nan), c15[:-16]]
    put('C 4時間で1A以上上げたあと15m-1H陰転', mac_dn & (pd.Series(u16).rolling(8, min_periods=1).max().values >= A15), 'C 行き過ぎの戻し', False)
    hi3 = (SD['fk'] >= 80) & (S4['fk'] >= 80) & (S1['fk'] >= 80)
    s1x = (S1['fk'] < S1['fd']) & (np.r_[np.nan, S1['fk'][:-1]] >= np.r_[np.nan, S1['fd'][:-1]])
    put('C 日足・4H・1Hの速Kがすべて80以上で1Hデッド', s1x & hi3, 'C 行き過ぎの戻し', False)
    # ===== D 時間帯 =====
    t_ny = pd.to_datetime(end5, unit='s', utc=True).tz_convert('America/New_York'); nyhm = (t_ny.hour * 60 + t_ny.minute).values
    usop = nyhm == 9 * 60 + 45
    put('D 米国の寄り付き最初の15分足が陰線', usop & (c15 < o15), 'D 時間帯', False)
    put('D 米国の寄り付き最初の15分足が陰線（H1Lineの下）', usop & (c15 < o15) & (c15 < v1), 'D 時間帯', True, v1)
    tj = pd.to_datetime(end5, unit='s', utc=True).tz_convert('Asia/Tokyo'); jhm = (tj.hour * 60 + tj.minute).values
    put('D 日中の最初の1時間が陰線（9:45の足で 寄り値より下）', (jhm == 9 * 60 + 45) & (c15 < pd.Series(np.where(jhm == 9 * 60, o15, np.nan)).ffill().values) & (bar_in_ses >= 4), 'D 時間帯', False)
    # ===== E はっきりした下げ相場での戻り売り =====
    Rm = (c15 < vD) & (sD < 0)
    Rs = Rm & (Ln['macd 1D-1W'] < Ln['signal 1D-1W'])
    above1 = c15 > v1; bdn1 = (~above1) & np.r_[False, above1[:-1]]
    last_dn1 = pd.Series(np.where(bdn1, np.arange(n), np.nan)).ffill().values; last_up1 = pd.Series(np.where(above1 & ~np.r_[False, above1[:-1]], np.arange(n), np.nan)).ffill().values
    bs1 = (~above1) & (np.arange(n) - last_dn1 <= 16) & (np.isnan(last_up1) | (last_up1 < last_dn1))
    ura1 = first(bs1 & (h15 >= v1 - 0.1 * A15) & ~bdn1, last_dn1)
    above4 = c15 > v4; bdn4 = (~above4) & np.r_[False, above4[:-1]]
    last_dn4 = pd.Series(np.where(bdn4, np.arange(n), np.nan)).ffill().values; last_up4 = pd.Series(np.where(above4 & ~np.r_[False, above4[:-1]], np.arange(n), np.nan)).ffill().values
    bs4 = (~above4) & (np.arange(n) - last_dn4 <= 16) & (np.isnan(last_up4) | (last_up4 < last_dn4))
    ura4 = first(bs4 & (h15 >= v4 - 0.15 * A15) & ~bdn4, last_dn4)
    pk1 = Ln['H1Line 山']; nr1 = (pc15 < pk1) & (h15 >= pk1 - 0.1 * A15) & (h15 < pk1) & (c15 < pc15)
    ps = I[q, col['PSAR']]; ps_dn = (ps < 0) & (np.r_[0, ps[:-1]] >= 0)
    ind = np.stack([I[q, col[f'Indi0{m}向き']] for m in range(2, 7)], 1); blue = onset((ind < 0).all(1))
    trig = [('H1Line裏タッチ0.1A', ura1, v1), ('H4Line裏タッチ0.15A', ura4, v4), ('H1Line山の値に届かず反落0.1A', nr1, pk1), ('15m-1H陰転', mac_dn, None),
            ('1H速Kデッド（50以上）', s1x & (S1['fk'] >= 50), None), ('PSAR売り', ps_dn, None), ('インジ5本が青', blue, None)]
    for rn, R_ in [('下げ相場（D1Lineの下・D1Line下向き）', Rm), ('強い下げ相場（＋1D-1W陰転）', Rs)]:
        for tn, m, lr in trig:
            put(f'E {rn}で {tn}', R_ & m, 'E 下げ相場の戻り売り', True, lr)
    # ===== F 値幅の拡大 =====
    vol = np.nan_to_num(X['prevr'][q] / np.where(A15 > 0, A15, np.nan))
    put('F 前日の値幅が20日平均の1.5倍以上・D1Lineの下で15m-1H陰転', mac_dn & (vol >= 1.5) & (c15 < vD), 'F 値幅の拡大', True, vD)
    put('F 前日の値幅が20日平均の1.5倍以上・D1Lineの下でH1Line裏タッチ', ura1 & (vol >= 1.5) & (c15 < vD), 'F 値幅の拡大', True, v1)
    names = list(ev)
    I_, D_, R_, LR_ = [], [], [], []
    for r, nm in enumerate(names):
        ii, lr = ev[nm]; ok = (X['yr'][ii] >= 2018) & ~np.isnan(A[ii])
        I_.append(ii[ok]); D_.append(np.full(ok.sum(), -1)); R_.append(np.full(ok.sum(), r)); LR_.append(np.nan_to_num(lr[ok], nan=0) + np.isnan(lr[ok]) * c[ii[ok]])
    np.savez_compressed(f'/home/claude/bs/g/ss_{inst}_{fam}.npz', i=np.concatenate(I_), d=np.concatenate(D_), rule=np.concatenate(R_), lr=np.concatenate(LR_))
    if fam == 'W':
        pd.DataFrame([dict(rule=r, 名前=nm, 向き='売', 観点=meta[nm][0], 線を使う=meta[nm][1]) for r, nm in enumerate(names)]).to_csv('/home/claude/bs/g/ss_rules.csv', index=False)
    print(inst, fam, len(names), {nm: len(ev[nm][0]) for nm in names} if fam == 'W' else sum(len(x) for x in I_), flush=True)

if __name__ == '__main__':
    for inst in sys.argv[1].split(','):
        for fam in sys.argv[2].split(','): build(inst, fam)
