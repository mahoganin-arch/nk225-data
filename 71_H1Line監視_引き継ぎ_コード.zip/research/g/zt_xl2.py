import numpy as np, pandas as pd, re
OUT='/home/claude/out/Zerchセオリーの検証_タッチの幅と届かない切り返し_2026-10-26.xlsx'
E=pd.read_pickle('zt_eval.pkl'); O=E['rules'].copy(); X=E['extra']
cols=['ルール','向き','両方そろう割合','でたらめ','頑丈さz','ミニ 前向き1回平均','ミニ ランダム1回平均','CFD 前向き1回平均','CFD ランダム1回平均','ミニ 前向き1つずつ 合計','CFD 前向き1つずつ 合計','ミニ プラスの年','CFD プラスの年','ミニ 前向き1つずつ 件数','CFD 前向き1つずつ 件数']
O['ミニ ランダムとの差']=O['ミニ 前向き1回平均']-O['ミニ ランダム1回平均']; O['CFD ランダムとの差']=O['CFD 前向き1回平均']-O['CFD ランダム1回平均']
cols+=['ミニ ランダムとの差','CFD ランダムとの差']
# 近さの表
rows=[]
for _,r in O.iterrows():
    m=re.match(r'(H1Line|H4Line|D1Line) (裏タッチ|表タッチ)(?: 近さ([\d.]+)A)?（割れて4時間以内）|(H1Line|H4Line|D1Line) (裏タッチ|表タッチ)(?: 近さ([\d.]+)A)?（抜けて4時間以内）',r.ルール)
    if m:
        g=[x for x in m.groups() if x is not None]; line,kind=g[0],g[1]; w=float(g[2]) if len(g)>2 else 0.05
        rows.append(dict(線=line,形=kind,近さ=w,**{c:r[c] for c in cols[2:]}))
    m2=re.match(r'(H1Line|H4Line|D1Line) (裏側|表側)で届かずに切り返し（([\d.]+)A以内・触れず）',r.ルール)
    if m2:
        rows.append(dict(線=m2.group(1),形=('裏タッチ' if m2.group(2)=='裏側' else '表タッチ')+'（触れずに切り返し）',近さ=float(m2.group(3)),**{c:r[c] for c in cols[2:]}))
T=pd.DataFrame(rows).sort_values(['線','形','近さ'])
S={}
S['まとめ']=pd.DataFrame({'':[
 '【ご質問への答え】これまでは、15分足の網羅（0.05〜0.25Aの4段階）・ブログ観点（0.03/0.08A）・上位足（0.05/0.15U）では「近づいたらタッチ」を入れていたが、セオリー検証の表タッチ・裏タッチは 0.05A の1段階だけで、「届く直前で切り返す（触れない）」「ヒゲで抜けて戻される（ダマシ）」は分けていなかった。今回、92ルールを追加して調べた（合計163）。',
 '  追加したもの：表タッチ・裏タッチの近さ 0／0.03／0.05／0.1／0.15／0.25A、触れずに切り返し（0.05／0.1／0.15A以内で線に触れない）、線に近づいて届かずに反落／反発、ダマシ（ヒゲで線を越えて終値は戻る）、山・谷の値に届かずに反転、山・谷のダマシ、ハーモニックの比率の誤差 5%／20%。',
 '【結果1：H1Line の押し目買いは「触れずに切り返す」方が良い】H1Line を抜けた後、0.05A以内まで押して H1Line に触れずに上がる買い：頑丈さ 0.81（でたらめ 0.05、z 9.6）、前向き1回平均 ミニ +93（ランダム +16）・CFD +67（+42）、両商品 6/7年プラス、ミニ合計 +6.9万（全ルールで一番）。0.1A以内でも z 18。実際に触れた（近さ0）ときは ミニ +76・CFD +66。',
 '【結果2：H1Line の谷の値で、届かずに反発する買い】0.05〜0.15A以内：ミニ +123〜+148、CFD +92〜+111、5〜7/7年プラス。ランダムより +15〜+37 良い。',
 '【結果3：H4Line の裏タッチ売りは「近さ」を広げると両商品で通る】0.05A では ミニだけプラスだったが、0.15A以内まで近づいたら売り：ミニ +37（ランダム −1）・CFD +20（−28）、5/7・6/7年プラス（ミニ +2.1万・CFD +1.3万）。0.1A でも ミニ +22・CFD +21。触れずに切り返す形（0.15A以内）も ミニ +33・CFD +18。→ 売りは「線の手前で止められる」ことが多く、ぴったり触れるのを待つと取り逃がす。',
 '【結果4：ダマシ】H1Line の下抜けのダマシ（ヒゲで割って終値は上）で買い：z 5.6、ミニ +53・CFD +47、6/7・5/7年（ランダムとの差は小さい）。上抜けのダマシで売りは、どの線でもマイナス。',
 '【結果5：ハーモニック】比率の誤差を20%に広げると件数が約400回に増え、買い：ミニ +131（ランダム +55）・CFD +68（+43）、両商品 5/7年プラス。売りは誤差を変えてもマイナス。',
 '【結果6：D1Line・H4Line の押し目買い、山の値での売り】近さを変えても、触れずに切り返す形にしても、良くならない（ランダム並みかそれ以下）。',
 '【まとめ】(1) 「ぴったり触れる」を待つより「近づいて止められる」を拾う方が、H1Line の買いでも H4Line の売りでも良い。(2) 前向きで確かめる候補に、H1Line の表側で触れずに切り返す買い（0.05〜0.1A）、H1Line 谷の値で届かずに反発する買い、H4Line 裏タッチ 0.1〜0.15A の売り、ハーモニック買い（誤差20%）を加える。']})
S['近さごとの成績']=T.round(2)
S['全ルールの成績']=O[cols+['一番良い手じまい']].round(2)
S['運用の手じまい']=X.round(2)
with pd.ExcelWriter(OUT,engine='openpyxl') as w:
    for k,v in S.items(): v.to_excel(w,sheet_name=k[:31],index=False)
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
wb=load_workbook(OUT)
for ws in wb.worksheets:
    for cc in ws[1]: cc.font=Font(bold=True); cc.fill=PatternFill('solid',fgColor='DDEBF7'); cc.alignment=Alignment(wrap_text=True,vertical='top')
    for col in ws.columns:
        L=max(len(str(x.value or '')) for x in list(col)[:100]); ws.column_dimensions[col[0].column_letter].width=min(max(8,L*1.4),50)
    ws.freeze_panes='A2'
ws=wb['まとめ']; ws.column_dimensions['A'].width=130
for row in ws.iter_rows(min_row=2):
    for cc in row: cc.alignment=Alignment(wrap_text=True,vertical='top')
wb.save(OUT); print(T[['線','形','近さ','ミニ 前向き1回平均','CFD 前向き1回平均','ミニ ランダムとの差','CFD ランダムとの差']].round(1).to_string())
