"""15分足の候補（A・A+インジ6本・E2・C+）が出たあと、3分足の合図まで待って入ると良くなるかを調べる。
基準：候補の合図（15分足の終わり）の直後の3分足の始値で入る。待つ：合図から 30/60/120 分以内に3分足の合図が出たら次の3分足の始値で入る（出なければ見送り）。
指値：合図から窓の中で m15Line（3分足チャート）や 入値−0.1A まで下がったら買う。
手じまい：すべて同じ（損切り＝候補の線−0.25A、なければ入値−0.25A／セッションの終わり）。データは3分足（CFD 2020-11〜、ミニ 2023-10〜）。
出力：m3timing.pkl（トレードごと）
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
import k_sig as K
from k_agg import MASKS
from k_rules import ex, fs
DF = pd.read_csv('/home/claude/bs/g/kdefs.csv', index_col=0); LN = pd.read_csv('/home/claude/bs/g/k_lnames.csv').iloc[:, 0].tolist()
CANDS = [('A H1Line山 押し目買い', 'H1Line 山 反発0.1', (), 'H1Line 山'),
         ('A+ ＋インジ6本そろう', 'H1Line 山 反発0.1', ('インジ6本そろう',), 'H1Line 山'),
         ('E2 PSAR買い＋15m-1H陽転＋1H-4H陽転', 'PSAR 買い', ('15m-1H陽転', '1H-4H陽転'), None),
         ('C+ 日足MACDmacd押し目＋15m-1H陽転＋1H-4H陽転', 'macd 1D-1W 反発0.25', ('15m-1H陽転', '1H-4H陽転'), 'macd 1D-1W')]
REF = 68800.0; COST = {'fut': 5.0, 'cfd': 7.0}

def run():
    rows = []
    for inst in ['fut', 'cfd']:
        X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); S = dict(np.load(f'/home/claude/bs/g/ksig_{inst}_W.npz'))
        KI = dict(np.load(f'/home/claude/bs/g/kind_{inst}_W.npz')); M = dict(np.load(f'/home/claude/bs/g/m3_{inst}.npz'))
        t3 = M['t']; o, h, l, c = [M[k].astype(float) for k in 'ohlc']; ses = M['ses']; m15 = M['m15']; e12 = M['e12']; fk = M['fk']; sk = M['sk']
        n3 = len(t3); last = np.r_[ses[1:] != ses[:-1], True]; idx = np.nonzero(last)[0]; send = idx[np.searchsorted(idx, np.arange(n3))]
        st_e12 = e12 > m15; st_sl = np.r_[False, np.diff(m15) > 0]; st_k = fk > sk
        ev_x = st_e12 & ~np.r_[False, st_e12[:-1]]; ev_k = st_k & ~np.r_[False, st_k[:-1]]
        low_turn = (np.r_[np.nan, fk[:-1]] < 30) & (np.diff(fk, prepend=np.nan) > 0)
        ecol = ex('セッション終わり', '線の0.25A先')
        for nm, trig, fl, line in CANDS:
            d = DF.index[(DF.trig == trig) & (DF.dir == 1)][0]; msk = MASKS[fs(*fl)] if fl else 0
            m = (S['d'] == d) & ((S['f'].astype(np.int64) & msk) == msk); si = S['i'][m]; base5 = S['R'][m, ecol]
            T = X['tm'][si] + 300  # 5分足の終わり（UTC秒）
            Lr = KI['L'][si, LN.index(line)].astype(float) if line else X['c'][si].astype(float)
            A = X['avg20'][si]; SL = Lr - 0.25 * A
            for q in range(len(si)):
                j0 = np.searchsorted(t3, T[q])
                if j0 >= n3 or j0 == 0 or t3[j0] - T[q] > 600 or ses[j0] != ses[j0 - 1]: continue
                end = send[j0]; e5 = X['c'][si[q]]
                def sim(j, px):
                    # j の足の中で px で入った後、損切り SL[q] かセッションの終わり
                    for k in range(j, end + 1):
                        if l[k] <= SL[q]:
                            return (min(o[k], SL[q]) if k > j else SL[q]) - px
                    return c[end] - px
                r = dict(inst=inst, cand=nm, t=pd.Timestamp(T[q], unit='s', tz='UTC').tz_convert('Asia/Tokyo'), base5=base5[q], A=A[q])
                if o[j0] <= SL[q]: continue
                r['基準'] = (sim(j0, o[j0]), o[j0])
                for W in (30, 60, 120):
                    lim = min(end, j0 + W // 3 - 1)
                    for vn, cond in [('3分足線がm15の上', st_e12), ('3分足線×m15上抜け', ev_x), ('m15が上向き', st_sl), ('3分 速K>遅K', st_k),
                                     ('3分 速K×遅K上抜け', ev_k), ('3分速ストキャス低位から上向き', low_turn)]:
                        ww = np.nonzero(cond[j0 - 1:lim])[0]  # 判定は足の終わり：j0-1（合図の足）から
                        res = None
                        if len(ww):
                            k = j0 - 1 + ww[0] + 1
                            if k <= end and o[k] > SL[q]: res = (sim(k, o[k]), o[k])
                        r[f'{vn}・{W}分'] = res
                    for vn, lvl in [('指値 m15Line', None), ('指値 入値−0.1A', o[j0] - 0.1 * A[q])]:
                        res = None
                        for k in range(j0, lim + 1):
                            L_ = m15[k - 1] if lvl is None else lvl
                            if L_ <= SL[q]: break
                            if l[k] <= L_:
                                px = min(o[k], L_)
                                if l[k] <= SL[q]: res = (SL[q] - px, px)
                                else:
                                    rr = sim(k + 1, px) if k < end else c[end] - px
                                    res = (rr, px)
                                break
                        r[f'{vn}・{W}分'] = res
                rows.append(r)
    pd.to_pickle(pd.DataFrame(rows), '/home/claude/bs/g/m3timing.pkl'); print(len(rows))

def summarize():
    D = pd.read_pickle('/home/claude/bs/g/m3timing.pkl'); V = [c for c in D.columns if c not in ('inst', 'cand', 't', 'base5', 'A')]
    out = []
    for (inst, cand), g in D.groupby(['inst', 'cand']):
        b = g['基準'].map(lambda x: x[0] * REF / x[1] - COST[inst])
        for v in V:
            val = g[v].map(lambda x: np.nan if x is None else x[0] * REF / x[1] - COST[inst])
            took = val.notna()
            yr = g.t.dt.year
            out.append(dict(商品={'fut': 'ミニ', 'cfd': 'CFD'}[inst], 候補=cand, 入り方=v, 件数=int(took.sum()), 入れた割合=took.mean(),
                            一回平均=val.mean(), 一回平均13円=(val + COST[inst] - 13).mean(), 合計=val.sum(),
                            同じトレードの基準=b[took].mean(), 見送ったトレードの基準=b[~took].mean() if (~took).any() else np.nan,
                            勝率=(val[took] > 0).mean(), プラスの年=f"{sum(val[took & (yr == y)].sum() > 0 for y in sorted(yr.unique()))}/{yr.nunique()}",
                            前半=val[yr <= (2023 if inst == 'cfd' else 2024)].mean(), 後半=val[yr > (2023 if inst == 'cfd' else 2024)].mean()))
    return pd.DataFrame(out)

if __name__ == '__main__':
    run(); S = summarize(); S.to_pickle('/home/claude/bs/g/m3timing_sum.pkl')
    pd.set_option('display.width', 250); pd.set_option('display.max_rows', 400)
    print(S[S.入り方.str.contains('基準|60分')].round(1).to_string())
