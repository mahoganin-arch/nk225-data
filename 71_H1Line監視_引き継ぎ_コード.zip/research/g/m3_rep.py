"""3分足検証のまとめ表を作る → m3rep.pkl（dict of DataFrame）"""
import os, sys, numpy as np, pandas as pd
P = os.environ.get('PFX', 'm3')
sys.path.insert(0, '/home/claude/bs/g')
from m3_eval import table, names, TR, FSN, EXITS
FAMS = ['W', 'r0', 'r1', 'r2', 'r3', 'r4']
LINE_FREE = [i for i, t in enumerate(TR) if ('ストキャス' in t or '速K' in t or '遅K' in t or '同じ位置' in t)]

def run():
    out = {}
    T = {f: table(f) for f in FAMS}
    W = T['W']
    # 1) ブログのルールそのまま（方向確認なし）
    EX = [24, 2, 7, 4, 30, 33]
    b = W[(W.fset == 0) & W.exit.isin(EX)]
    out['rules'] = names(b).drop(columns=['fset', 'exit', 'td', 'trig', 'dir'])
    # 2) 線の効き目：本物とでたらめ
    rows = []
    for f, D in T.items():
        line = ~D.trig.isin(LINE_FREE)
        for lab, m in [('線を使うトリガー', line), ('ストキャスだけのトリガー', ~line)]:
            d = D[m]
            rows.append({'線': '本物' if f == 'W' else f'でたらめ {f}', 'トリガーの種類': lab, '形の数': len(d),
                         '4つともランダムより良い割合': (d['差の最小'] > 0).mean(), '4つともプラスの割合': (d['平均の最小'] > 0).mean(),
                         '両方そろう割合': ((d['差の最小'] > 0) & (d['平均の最小'] > 0)).mean(), '差の最小 上位1%': d['差の最小'].quantile(.99)})
    out['null'] = pd.DataFrame(rows)
    # 3) トリガーごと
    g = []
    for f, D in T.items():
        q = D.assign(p=D['差の最小'] > 0, pp=(D['差の最小'] > 0) & (D['平均の最小'] > 0)).groupby(['trig', 'dir']).agg(p=('p', 'mean'), pp=('pp', 'mean'), n=('p', 'size'), med=('差の最小', 'median'))
        q['fam'] = f; g.append(q.reset_index())
    G = pd.concat(g); Wg = G[G.fam == 'W'].set_index(['trig', 'dir']); Ng = G[G.fam != 'W'].groupby(['trig', 'dir']).agg(p_n=('p', 'mean'), p_sd=('p', 'std'), pp_n=('pp', 'mean'))
    J = Wg.join(Ng); J['z'] = (J.p - J.p_n) / J.p_sd.replace(0, np.nan); J = J.reset_index()
    J.insert(0, 'トリガー', [TR[t] for t in J.trig]); J.insert(1, '売買', J.dir.map({1: '買い', -1: '売り'}))
    J['線を使う'] = ~J.trig.isin(LINE_FREE)
    out['trig'] = J.sort_values('p', ascending=False)
    # 4) 方向確認の効き目：なし と比べた改善
    fr = []
    for f, D in T.items():
        base = D[D.fset == 0].set_index(['trig', 'dir', 'exit'])
        cols = [c for c in D.columns if c.endswith(' 差')]
        for fs, d in D[D.fset > 0].groupby('fset'):
            d = d.set_index(['trig', 'dir', 'exit']); jj = d[cols].join(base[cols], rsuffix='_0', how='inner')
            if len(jj) < 20: continue
            imp = np.all([(jj[c] > jj[c + '_0']).values for c in cols], 0)
            fr.append({'fam': f, 'fset': fs, '改善4つとも': imp.mean(), '変化中央': np.median(jj[cols].min(1) - jj[[c + '_0' for c in cols]].min(1)), '数': len(jj)})
    FR = pd.DataFrame(fr); Wf = FR[FR.fam == 'W'].set_index('fset'); Nf = FR[FR.fam != 'W'].groupby('fset').agg(改善_でたらめ=('改善4つとも', 'mean'), 変化_でたらめ=('変化中央', 'mean'))
    F = Wf.join(Nf).reset_index(); F.insert(0, '方向確認', [FSN[i] for i in F.fset])
    out['filt'] = F.sort_values('改善4つとも', ascending=False)
    # 5) 上位（参考）
    top = W[(W['平均の最小'] > 0) & (W['件数最小'] >= 30)].sort_values('差の最小', ascending=False).head(300)
    out['top'] = names(top).drop(columns=['fset', 'exit', 'td', 'trig', 'dir'])
    out['T_W'] = W
    pd.to_pickle(out, f'/home/claude/bs/g/{P}rep.pkl')
    for k, v in out.items(): print(k, len(v))

if __name__ == '__main__':
    run()
