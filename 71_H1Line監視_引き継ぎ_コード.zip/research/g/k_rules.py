"""画像の使い方をそのまま（選ばずに）ルールにしたものの成績。比べる相手：ランダムな時刻に入って同じ手じまい・同じ方向確認。"""
import sys, numpy as np, pandas as pd
sys.path.insert(0,'/home/claude/bs/g')
import h_agg, k_sig as K
from k_agg import MASKS, FSETS
RULES=K.RULES; SLS=K.SLS; FIL=K.FILTERS
def ex(rule,sl='なし'): return RULES.index(rule)*3+SLS.index(sl)
def fs(*names):
    idx=tuple(sorted(FIL.index(n) for n in names)); return FSETS.index(idx)
CASES=[ # 名前, トリガー(買い), 手じまい, 方向確認
 ('7インジ全部赤で買い→5本青で決済','インジ6本 買い',ex('インジ5本逆'),()),
 ('7インジ全部赤で買い→セッション終わり','インジ6本 買い',ex('セッション終わり'),()),
 ('15m-1H陽転で買い→陰転で決済','macd 15m-1H×signal 15m-1H 上順',ex('15m-1H逆クロス'),()),
 ('15m-1H陽転＋インジ6本赤→陰転で決済','macd 15m-1H×signal 15m-1H 上順',ex('15m-1H逆クロス'),('インジ6本そろう',)),
 ('H1Line陽転で買い→H1Line陰転で決済','H1Line 陽転',ex('H1Line傾き反転'),()),
 ('H1Line×1時間足MACD 上抜けで買い','H1Line×macd 15m-1H 上順',ex('セッション終わり'),()),
 ('速ストキャスGC（遅ストキャス上向き）→速DCで決済','速ストキャス 買い',ex('速ストキャス逆クロス'),('遅ストキャス向き',)),
 ('速ストキャスGC（遅ストキャス低位・上向き）→速DC','速ストキャス 買い',ex('速ストキャス逆クロス'),('遅ストキャス向き','遅ストキャス低位')),
 ('遅ストキャスGCで買い→遅DCで決済','遅ストキャス 買い',ex('遅ストキャス逆クロス'),()),
 ('H1Line近づき反発(0.15A)＋速ストキャス向き→次の線','H1Line 反発0.15',ex('次の線'),('速ストキャス向き',)),
 ('D1Line近づき反発(0.15A)→次の線（裏タッチ狙い）','D1Line 反発0.15',ex('次の線'),()),
 ('H1Lineの山へ押し目買い(0.05A)→セッション終わり','H1Line 山 反発0.05',ex('セッション終わり','線の0.25A先'),()),
 ('H1Lineの山へ押し目買い＋インジ5本以上','H1Line 山 反発0.05',ex('セッション終わり','線の0.25A先'),('インジ5本以上',)),
 ('PSAR反転で買い→PSAR反転で決済','PSAR 買い',ex('PSAR反転'),()),
]
def evaluate(inst):
    X=dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); DF=pd.read_csv('/home/claude/bs/g/kdefs.csv',index_col=0)
    S=dict(np.load(f'/home/claude/bs/g/ksig_{inst}_W.npz')); Rr=dict(np.load(f'/home/claude/bs/g/krand_{inst}.npz'))
    net,nrm,n13=h_agg.pnl(inst,S); rn,rr,r13=h_agg.pnl(inst,Rr)
    yr=X['yr'][S['i']]; ry=X['yr'][Rr['i']]
    out=[]
    for nm,trig,e,fl in CASES:
        for dr,lab in [(1,'買い'),(-1,'売り')]:
            t=trig
            if dr==-1:
                t=t.replace('買い','売り').replace('上順','下順').replace('陽転','陰転')
            d=DF.index[(DF.trig==t)&(DF.dir==dr)]
            if len(d)==0: continue
            d=d[0]; dd=DF.loc[d,'dir']
            msk=MASKS[fs(*fl)] if fl else 0
            m=(S['d']==d)&((S['f'].astype(np.int64)&msk)==msk)
            # ランダム：同じ向きの種5つ全部、同じ方向確認
            rm=(Rr['d']%2==(0 if dd==1 else 1))&((Rr['f'].astype(np.int64)&msk)==msk)
            r=dict(inst=inst,ルール=nm,向き='買い' if dd==1 else '売り',件数=int(m.sum()),
                   実コストpt=np.nanmean(net[m,e]),そろえた=np.nanmean(nrm[m,e]),円13=np.nanmean(n13[m,e]),
                   ランダム同条件=np.nanmean(nrm[:,e][:0]) if False else np.nanmean(rr[rm,e]),
                   前半=np.nanmean(nrm[m&(yr<=2022),e]),後半=np.nanmean(nrm[m&(yr>=2023),e]),
                   ランダム前半=np.nanmean(rr[rm&(ry<=2022),e]),ランダム後半=np.nanmean(rr[rm&(ry>=2023),e]),
                   プラス年=int(sum(np.nansum(nrm[m&(yr==y),e])>0 for y in range(2018,2027))))
            out.append(r)
    return pd.DataFrame(out)
if __name__=='__main__':
    pd.set_option('display.width',250)
    print(evaluate(sys.argv[1]).round(1).to_string())
