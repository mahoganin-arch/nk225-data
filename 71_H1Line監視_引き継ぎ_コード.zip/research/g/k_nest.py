"""組み合わせの本当の前向き（h_nest と同じ手順）。確かめる年 t（2020〜2026）ごとに 2018〜t−1 だけで候補群を作り、上位5本を t 年に売買。
候補の単位：トリガー × 手じまい × 方向確認（なし・1つ・2つ）。コストの見方：実コスト・13円・両方。
出力：knest_{inst}_{fam}.pkl、knest_tr_{inst}_{fam}.pkl
"""
import sys, gc, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
import h_agg, k_scr
from k_agg import MASKS

SCORE = {'両方で優位': 'min', '安定（幅が広い）': 'min', '少数・高勝率': 'min', '後半で優位': '後半平均', '前半で優位': '前半平均'}

def run(inst, fam):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); DF = pd.read_csv('/home/claude/bs/g/kdefs.csv', index_col=0)
    A = pd.read_parquet(f'/home/claude/bs/g/kagg_{inst}_{fam}.parquet')
    S_ = dict(np.load(f'/home/claude/bs/g/ksig_{inst}_{fam}.npz'))
    yr = X['yr'][S_['i']]; dayid = X['pid_day'][S_['i']]; f_ = S_['f'].astype(np.int64)
    res = []; trs = []
    for t in range(2020, 2027):
        ys = list(range(2018, t)); scr = {}
        for col in ['net', 'n13']:
            k_scr.COL = col
            S, grp, _ = k_scr.screen(A, ys); scr[col] = (S[['前半平均', '後半平均']].copy(), grp); del S; gc.collect()
        for vname, (c1, c2) in {'実コスト': ('net', None), '13円': ('n13', None), '両方': ('net', 'n13')}.items():
            Ssc, grp = scr[c1]
            for g in grp:
                m = grp[g].values.copy()
                if c2 is not None: m &= scr[c2][1][g].values
                nt = A[f'n{t}'].values
                r = dict(inst=inst, fam=fam, t=t, var=vname, grp=g, ncand=int(m.sum()))
                if m.sum() == 0: res.append(r); continue
                sel = m & (nt > 0)
                for cc in ['net', 'nrm', 'n13']:
                    r[f'avg_{cc}'] = A[f'{cc}{t}'].values[sel].sum() / max(nt[sel].sum(), 1)
                sc = np.minimum(Ssc['前半平均'].values, Ssc['後半平均'].values) if SCORE[g] == 'min' else Ssc[SCORE[g]].values
                sel5 = m & (nt >= 5)
                r['rho'] = pd.Series(sc[sel5]).rank().corr(pd.Series(A[f'{c1}{t}'].values[sel5] / nt[sel5]).rank()) if sel5.sum() > 10 else np.nan
                idx = np.nonzero(m)[0]; idx = idx[np.argsort(-sc[idx], kind='stable')]
                pick = []; used = set()
                for q in idx:
                    d = int(A['def'].values[q])
                    if d in used: continue
                    used.add(d); pick.append(q)
                    if len(pick) == 5: break
                T = []
                for rank, q in enumerate(pick):
                    d = int(A['def'].values[q]); ex = int(A['exit'].values[q]); fs = int(A['fset'].values[q]); msk = MASKS[fs]
                    mm = (S_['d'] == d) & ((f_ & msk) == msk) & (yr == t)
                    if not mm.any(): continue
                    PN = h_agg.pnl(inst, {'R': S_['R'][mm], 'e': S_['e'][mm], 'nt': S_['nt'][mm]})
                    T.append(pd.DataFrame({'rank': rank, 'def': d, 'exit': ex, 'fset': fs, 'i': S_['i'][mm], 'dir': DF['dir'].values[d], 'e': S_['e'][mm],
                                           'pt': S_['R'][mm, ex], 'net': PN[0][:, ex], 'nrm': PN[1][:, ex], 'n13': PN[2][:, ex], 'day': dayid[mm]}))
                if T:
                    T = pd.concat(T).sort_values(['i', 'rank']).drop_duplicates(['i', 'dir']); T = T[T.groupby('day').cumcount() < 2]
                    T = T.assign(inst=inst, fam=fam, t=t, var=vname, grp=g); trs.append(T)
                    r.update(top5_net=T.net.sum(), top5_nrm=T.nrm.sum(), top5_n13=T.n13.sum(), top5_n=len(T))
                else:
                    r.update(top5_net=0.0, top5_nrm=0.0, top5_n13=0.0, top5_n=0)
                res.append(r)
        del scr; gc.collect(); print(inst, fam, t, flush=True)
    pd.DataFrame(res).to_pickle(f'/home/claude/bs/g/knest_{inst}_{fam}.pkl')
    if trs: pd.concat(trs).to_pickle(f'/home/claude/bs/g/knest_tr_{inst}_{fam}.pkl')

if __name__ == '__main__':
    run(sys.argv[1], sys.argv[2])
