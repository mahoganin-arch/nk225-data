"""形としての強さの偶然の目安を増やす：でたらめな線 r6〜 で、条件なし（全体）の 入り方×決済×年 の合計だけを作る。"""
import sys, os, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
import h_lines, h_sig, h_agg
inst = sys.argv[1]; seeds = range(int(sys.argv[2]), int(sys.argv[3]))
X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz'))
ND = len(pd.read_csv('/home/claude/bs/g/hdefs.csv', index_col=0)); YS = h_agg.YEARS; NY = len(YS)
rows = []
for s in seeds:
    fam = f'r{s}'
    if not os.path.exists(f'/home/claude/bs/g/hl_{inst}_{fam}.npz'): h_lines.build(inst, fam)
    h_sig.run(inst, [fam]); f = f'/home/claude/bs/g/hsig_{inst}_{fam}.npz'; S = dict(np.load(f))
    yi = X['yr'][S['i']] - YS[0]; k = (yi >= 0) & (yi < NY)
    for q in ['d', 'i', 'e', 'R', 'nt']: S[q] = S[q][k]
    yi = yi[k]; net, nrm, n13 = h_agg.pnl(inst, S)
    key = S['d'].astype(np.int64) * NY + yi; K = ND * NY
    M = np.zeros((ND, 48, 4 * NY))
    for col in range(48):
        v = ~np.isnan(net[:, col])
        arr = [np.bincount(key[v], minlength=K)] + [np.bincount(key[v], z[v, col], K) for z in (net, nrm, n13)]
        M[:, col, :] = np.concatenate([a.reshape(ND, NY) for a in arr], 1)
    del S, net, nrm, n13
    R = pd.DataFrame(M.reshape(ND * 48, 4 * NY), columns=[f'{a}{y}' for a in ['n', 'net', 'nrm', 'n13'] for y in YS])
    R.insert(0, 'exit', np.tile(np.arange(48), ND)); R.insert(0, 'def', np.repeat(np.arange(ND), 48)); R.insert(0, 'fam', fam); R.insert(0, 'inst', inst)
    rows.append(R); os.remove(f); print(inst, fam, flush=True)
pd.concat(rows).to_pickle(f'/home/claude/bs/g/hfamnull_{inst}_{seeds.start}.pkl')
