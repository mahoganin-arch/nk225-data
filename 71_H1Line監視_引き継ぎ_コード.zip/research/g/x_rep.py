"""調べ直し（15分足の網羅・15分足ブログ観点・3分足ブログ観点）のまとめ → xrep_{study}.pkl"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from x_eval2 import combos, nested
from x_core import RL as RULES, CAP
RLc = pd.read_csv('/home/claude/bs/g/xlib_rules.csv'); NE = len(RLc)
BASE = int(RLc.index[RLc.手じまい == 'セッション終わり・損切り 線の0.25A先'][0])
SES = np.array([r * 3 + s for r in range(len(RULES)) if CAP[r] == 0 for s in range(3)])

def study(name):
    if name == 'k':
        DF = pd.read_csv('/home/claude/bs/g/kdefs.csv', index_col=0); G = [f"{a}{'買' if d == 1 else '売'}" for a, d in zip(DF.trig, DF.dir)]; dirs = DF.dir.values
        F = ['なし'] + pd.read_csv('/home/claude/bs/g/kfilters.csv').iloc[:, 0].tolist(); fams = ['W', 'r0', 'r1', 'r2']; y0 = 2018; f = lambda i, fam: f'/home/claude/bs/g/xk_{i}_{fam}.npz'
        years = range(2020, 2027)
    else:
        P = name; TR = pd.read_csv(f'/home/claude/bs/g/{P}_trigs.csv').iloc[:, 0].tolist(); G = [f"{t}{'買' if k == 1 else '売'}" for t in TR for k in (0, 1)]; dirs = np.array([1 if k == 1 else -1 for t in TR for k in (0, 1)])
        import os; os.environ['PFX'] = P
        from m3_sig import FILTERS
        F = ['なし'] + list(FILTERS); fams = ['W', 'r0', 'r1']; y0 = 2020 if P == 'm3' else 2018; f = lambda i, fam: f'/home/claude/bs/g/xm_{P}_{i}_{fam}.npz'
        years = range(2022, 2027) if P == 'm3' else range(2020, 2027)
    return G, dirs, F, fams, y0, f, years

def sub(Z, idx):
    Z2 = dict(Z); Z2['nrm'] = Z['nrm'][..., idx]; Z2['n13'] = Z['n13'][..., idx]; Z2['nrmR'] = Z['nrmR'][..., idx]; Z2['n13R'] = Z['n13R'][..., idx]; return Z2

def run(name):
    G, dirs, F, fams, y0, fpath, years = study(name); out = {}
    rows = []; trig = []; nests = []; tops = None
    for fam in fams:
        Zs = {i: {k: v for k, v in np.load(fpath(i, fam)).items()} for i in ['fut', 'cfd']}
        C = combos(Zs, dirs)
        ok = C['ok']
        for lab, idx in [('全部の手じまい', np.arange(NE)), ('セッション内の手じまいだけ', SES), ('基準の手じまいだけ', np.array([BASE]))]:
            dm = C['dmin'][..., idx]; am = C['amin'][..., idx]; o = ok[..., idx]
            rows.append(dict(線='本物' if fam == 'W' else f'でたらめ {fam}', 手じまい=lab, 形の数=int(o.sum()), 四つともランダムより良い=np.nanmean(np.where(o, dm > 0, np.nan)),
                             四つともプラス=np.nanmean(np.where(o, am > 0, np.nan)), 両方=np.nanmean(np.where(o, (dm > 0) & (am > 0), np.nan))))
        # トリガーごと（全部の手じまい）
        both = (C['dmin'] > 0) & (C['amin'] > 0)
        pg = np.nanmean(np.where(ok, both, np.nan).reshape(len(G), -1), 1)
        best = np.nanmax(np.where(ok[:, 0, :], C['amin'][:, 0, :], np.nan), 1)  # 方向確認なしでの一番良い手じまい（4つの最小）
        bse = C['amin'][:, 0, BASE]
        bes = np.nanmax(np.where(ok[:, 0, SES], C['amin'][:, 0, SES], np.nan), 1)
        arg = np.nanargmax(np.where(ok[:, 0, :], C['amin'][:, 0, :], -1e18), 1)
        trig.append(pd.DataFrame({'fam': fam, 'トリガー': G, '両方そろう割合': pg, '基準の手じまい(4つの最小)': bse, 'セッション内で一番良い': bes, '全部で一番良い': best, '一番良い手じまい': [RLc.手じまい[a] for a in arg]}))
        for lab, idx in [('全部の手じまい', np.arange(NE)), ('セッション内の手じまいだけ', SES), ('基準の手じまいだけ', np.array([BASE]))]:
            Zx = {i: sub(z, idx) for i, z in Zs.items()}
            N, pk = nested(Zx, y0, years, dirs); N['fam'] = fam; N['手じまい'] = lab; nests.append(N)
            if fam == 'W' and lab == '全部の手じまい':
                out['picks'] = pd.DataFrame([dict(年=t, 順位=r + 1, トリガー=G[g], 方向確認=F[ff], 手じまい=RLc.手じまい[idx[e]]) for t, v in pk.items() for r, (g, ff, e) in enumerate(v)])
        if fam == 'W':
            m = ok & both
            g_, f_, e_ = np.nonzero(m); v = C['dmin'][m]; o = np.argsort(-C['amin'][m])[:300]
            tops = pd.DataFrame({'トリガー': np.array(G)[g_[o]], '方向確認': np.array(F)[f_[o]], '手じまい': RLc.手じまい.values[e_[o]], '4つの平均の最小': C['amin'][m][o], 'ランダムとの差の最小': v[o], '4つの平均': C['amean'][m][o], '件数最小': C['nmin'][m][o]})
            # 手じまいの型ごと：両方そろう形の中での割合
            ex = pd.Series(RLc.ルール.values[e_]).value_counts(normalize=True).rename('両方そろう形の中での割合')
            out['exit_types'] = ex.reset_index().rename(columns={'index': 'ルール'})
    T = pd.concat(trig); W = T[T.fam == 'W'].set_index('トリガー'); Nn = T[T.fam != 'W'].groupby('トリガー').agg(でたらめ=('両方そろう割合', 'mean'), でたらめsd=('両方そろう割合', 'std'))
    J = W.join(Nn); J['頑丈さ(z)'] = (J['両方そろう割合'] - J['でたらめ']) / J['でたらめsd'].replace(0, np.nan)
    out['null'] = pd.DataFrame(rows); out['trig'] = J.drop(columns=['fam']).reset_index().sort_values('両方そろう割合', ascending=False)
    NS = pd.concat(nests); out['nest_year'] = NS
    out['nest'] = NS.groupby(['手じまい', 'inst', 'fam'])[['上位5合計', '上位5合計13円', '上位5件数']].sum().join(NS.groupby(['手じまい', 'inst', 'fam'])[['全部の平均', '順位相関']].mean()).reset_index()
    out['top'] = tops
    pd.to_pickle(out, f'/home/claude/bs/g/xrep_{name}.pkl')
    pd.set_option('display.width', 250); pd.set_option('display.max_rows', 200)
    print(out['null'].round(3).to_string()); print(out['nest'].round(1).to_string())
    print(out['trig'].head(25).round(1).to_string())

if __name__ == '__main__':
    run(sys.argv[1])
