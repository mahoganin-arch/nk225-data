"""cond.pkl のまとめ → cond_rep.pkl"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from cond import feats

def run():
    C = pd.read_pickle('/home/claude/bs/g/cond.pkl'); R = C['res'].copy(); PL = C['picks']; names = C['names']
    R['向き'] = np.where(R.rule.str.endswith('買'), '買い', '売り'); R['ランダム'] = R.rule.str.startswith('rand:')
    R['調べ'] = R.rule.str.split(':').str[0].where(~R.ランダム, R.rule.str.split(':').str[1])
    modes = ['そのまま', '避ける', '入る条件']
    # 1) 全体
    agg = R.groupby(['ランダム', '向き', 'inst'])[[f'{m} {k}' for m in modes for k in ['件数', '合計', '1つずつ件数', '1つずつ合計']]].sum().reset_index()
    for m in modes:
        agg[f'{m} 1回平均'] = agg[f'{m} 合計'] / agg[f'{m} 件数'].replace(0, np.nan); agg[f'{m} 1つずつ1回平均'] = agg[f'{m} 1つずつ合計'] / agg[f'{m} 1つずつ件数'].replace(0, np.nan)
    # 2) ルールごと（両商品）
    g = R[~R.ランダム].groupby(['rule', '向き', '調べ'])
    P = g[[f'{m} 1つずつ合計' for m in modes] + [f'{m} 1つずつ件数' for m in modes] + [f'{m} 合計' for m in modes] + [f'{m} 件数' for m in modes]].sum()
    for m in modes:
        P[f'{m} プラスの年(両商品)'] = g.apply(lambda d: int((d.groupby('t')[f'{m} 1つずつ合計'].sum() > 0).sum()))
        P[f'{m} 1つずつ1回平均'] = P[f'{m} 1つずつ合計'] / P[f'{m} 1つずつ件数'].replace(0, np.nan)
    for m in ['避ける', '入る条件']:
        P[f'{m} 同じ条件のランダム1回平均'] = g[f'{m} ランダム1回平均'].mean()
        P[f'{m} が良くした(1つずつ合計)'] = P[f'{m} 1つずつ合計'] > P['そのまま 1つずつ合計']
    P['そのまま ランダム1回平均'] = g['そのまま ランダム1回平均'].mean()
    for ins, lab in [('fut', 'ミニ'), ('cfd', 'CFD')]:
        q = R[(~R.ランダム) & (R.inst == ins)].groupby('rule')
        for m in modes: P[f'{lab} {m} 1つずつ合計'] = q[f'{m} 1つずつ合計'].sum()
    P = P.reset_index()
    # 3) 向き別：良くなったルールの割合
    imp = P.groupby(['向き', '調べ']).agg(ルール数=('rule', 'size'), 避けるで良くなった=('避ける が良くした(1つずつ合計)', 'mean'), 入る条件で良くなった=('入る条件 が良くした(1つずつ合計)', 'mean'),
                                       そのまま合計=('そのまま 1つずつ合計', 'sum'), 避ける合計=('避ける 1つずつ合計', 'sum'), 入る条件合計=('入る条件 1つずつ合計', 'sum')).reset_index()
    # 4) 売り：両商品でプラスになったもの
    S = P[(P.向き == '売り')].copy()
    S['両商品プラス(入る条件)'] = (S['ミニ 入る条件 1つずつ合計'] > 0) & (S['CFD 入る条件 1つずつ合計'] > 0)
    S['両商品プラス(避ける)'] = (S['ミニ 避ける 1つずつ合計'] > 0) & (S['CFD 避ける 1つずつ合計'] > 0)
    S['両商品プラス(そのまま)'] = (S['ミニ そのまま 1つずつ合計'] > 0) & (S['CFD そのまま 1つずつ合計'] > 0)
    S = S.sort_values('入る条件 1つずつ合計', ascending=False)
    # 5) 選ばれた条件の種類と、その年の効果
    PL = PL.copy()
    fam = lambda s: s.split(' ')[0] if s.split(' ')[0] in ('15分', '1H', '4H', '日足', '週足', '月足') else ('環境' if ('下向き' in s or '下落率' in s or '騰落率' in s) else '状況')
    rows = []
    for _, r in PL[PL.条件 != ''].iterrows():
        for c in r.条件.replace(' かつ ', ' / ').split(' / '): rows.append(dict(型=r.型, 種類=fam(c), 状態=c.rsplit('=', 1)[0], 値=c.rsplit('=', 1)[1], rule=r.rule, t=r.t))
    K = pd.DataFrame(rows)
    freq = K.groupby(['型', '種類']).size().rename('選ばれた回数').reset_index()
    top = K.groupby(['型', '状態', '値']).size().rename('選ばれた回数').reset_index().sort_values('選ばれた回数', ascending=False).groupby('型').head(40)
    # 6) ランダムな入りの環境地図（全期間、状態ごとの1回平均）
    T = pd.read_pickle('/home/claude/bs/g/tr2.pkl'); T = T[(T.yr >= 2018) & T.rule.str.startswith('rand:')].reset_index(drop=True)
    F, nm = feats(T); env = []
    for rule, idx in T.groupby('rule', observed=True).indices.items():
        for k in range(F.shape[1]):
            for val in np.unique(F[idx, k]):
                if val < 0: continue
                m = idx[F[idx, k] == val]
                if len(m) < 50: continue
                row = dict(ランダム=rule, 状態=nm[k], 値=int(val), 件数=len(m), 割合=len(m) / len(idx))
                for ins, lab in [('fut', 'ミニ'), ('cfd', 'CFD')]:
                    for hh, cond in [('前半', T.yr.values[m] <= 2022), ('後半', T.yr.values[m] >= 2023)]:
                        mm = m[(T.inst.values[m] == ins) & cond]; row[f'{lab}{hh}'] = T.v.values[mm].mean() if len(mm) else np.nan
                vals = [row[c] for c in ['ミニ前半', 'ミニ後半', 'CFD前半', 'CFD後半']]
                row['4つの最小'] = np.nanmin(vals) if np.isfinite(vals).any() else np.nan; row['4つともプラス'] = all(np.isfinite(vals)) and min(vals) > 0
                env.append(row)
    E = pd.DataFrame(env)
    out = dict(agg=agg, rules=P, imp=imp, sells=S, freq=freq, top=top, env=E, picks=PL)
    pd.to_pickle(out, '/home/claude/bs/g/cond_rep.pkl')
    pd.set_option('display.width', 260); pd.set_option('display.max_rows', 100)
    print(agg[['ランダム', '向き', 'inst'] + [f'{m} 1つずつ合計' for m in modes] + [f'{m} 1つずつ1回平均' for m in modes]].round(1).to_string())
    print(imp.round(2).to_string()); print(freq.to_string())
    print(S[['rule', 'そのまま 1つずつ合計', '避ける 1つずつ合計', '入る条件 1つずつ合計', 'ミニ 入る条件 1つずつ合計', 'CFD 入る条件 1つずつ合計', '入る条件 プラスの年(両商品)', '入る条件 1つずつ件数', '入る条件 同じ条件のランダム1回平均', '入る条件 1つずつ1回平均']].head(25).round(0).to_string())
    es = E[E.ランダム.str.endswith('売') & E['4つともプラス']].sort_values('4つの最小', ascending=False); print(es.head(30).round(1).to_string())

if __name__ == '__main__':
    run()
