"""候補の選び直し（v3）：すべてのルール（方向確認つき・売りを含む）を、正しい比べ方で評価する。
比べる相手：同じ向き・同じ方向確認（または同じ入る/避ける条件）・同じ手じまい（ルールがその年に使う手じまい）で、ランダムな時刻に入り、ポジションは1つずつ。
期間：2020〜2026（前向き。手じまいは前の年までで選んだもの、条件も前の年で選んだもの）。
出力：rs3_{study}.pkl（ルールごとの成績）
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
YRS = list(range(2020, 2027))

def seq(i5, x5):
    o = np.argsort(i5, kind='stable'); last = -1; tk = []
    for q in o:
        if i5[q] > last: tk.append(q); last = x5[q]
    return np.array(tk, int)

def one_stats(i5, x5, v, yr, pref):
    tk = seq(i5, x5) if len(i5) else np.array([], int)
    vv = v[tk]; yy = yr[tk]; out = {}
    out[f'{pref}回数'] = len(vv); out[f'{pref}1回平均'] = vv.mean() if len(vv) else np.nan; out[f'{pref}ばらつき'] = vv.std(ddof=1) if len(vv) > 1 else np.nan
    out[f'{pref}合計'] = vv.sum(); ys = pd.Series(vv).groupby(yy).sum() if len(vv) else pd.Series(dtype=float)
    out[f'{pref}プラスの年'] = int((ys > 0).sum())
    for lab, m in [('前半', yy <= 2022), ('後半', yy >= 2023)]:
        out[f'{pref}{lab}1回平均'] = vv[m].mean() if m.any() else np.nan; out[f'{pref}{lab}回数'] = int(m.sum())
    for y in YRS: out[f'{pref}{y}'] = float(vv[yy == y].sum()) if len(vv) else 0.0
    if len(tk):
        cs = np.cumsum(vv[np.argsort(x5[tk], kind='stable')]); out[f'{pref}最大DD'] = float((np.maximum.accumulate(np.r_[0, cs]) - np.r_[0, cs]).max())
    else: out[f'{pref}最大DD'] = 0.0
    return out

def rand_stats(pools, pref):
    """pools：[(i5, x5, v, yr), ...]（種ごと）。種ごとに1つずつ持ち、まとめて平均"""
    vs, ys = [], []
    for i5, x5, v, yr in pools:
        if len(i5) == 0: continue
        tk = seq(i5, x5); vs.append(v[tk]); ys.append(yr[tk])
    if not vs: return {f'{pref}回数': 0, f'{pref}1回平均': np.nan, f'{pref}ばらつき': np.nan, f'{pref}前半1回平均': np.nan, f'{pref}後半1回平均': np.nan}
    v = np.concatenate(vs); y = np.concatenate(ys)
    return {f'{pref}回数': len(v), f'{pref}1回平均': v.mean(), f'{pref}ばらつき': v.std(ddof=1), f'{pref}前半1回平均': v[y <= 2022].mean() if (y <= 2022).any() else np.nan,
            f'{pref}後半1回平均': v[y >= 2023].mean() if (y >= 2023).any() else np.nan, f'{pref}種の数': len(vs)}

def compare(row, L):
    a, b = row.get(f'{L} 1回平均'), row.get(f'{L} ランダム1回平均')
    sa, sb, na, nb = row.get(f'{L} ばらつき'), row.get(f'{L} ランダムばらつき'), row.get(f'{L} 回数'), row.get(f'{L} ランダム回数')
    row[f'{L} ランダムとの差'] = a - b
    se = np.sqrt((sa ** 2) / max(na, 1) + (sb ** 2) / max(nb, 1)) if (na and nb and na > 1 and nb > 1) else np.nan
    row[f'{L} t値'] = (a - b) / se if se and se > 0 else np.nan
    row[f'{L} 前半の差'] = row.get(f'{L} 前半1回平均', np.nan) - row.get(f'{L} ランダム前半1回平均', np.nan)
    row[f'{L} 後半の差'] = row.get(f'{L} 後半1回平均', np.nan) - row.get(f'{L} ランダム後半1回平均', np.nan)

# ---------- 15分足の網羅（k） ----------
def study_k(insts=('fut', 'cfd')):
    from x_core import ctx5, simulate, money
    DF = pd.read_csv('/home/claude/bs/g/kdefs.csv', index_col=0); FL = ['なし'] + pd.read_csv('/home/claude/bs/g/kfilters.csv').iloc[:, 0].tolist()
    EX = pd.read_csv('/home/claude/bs/g/xlib_rules.csv').手じまい.tolist(); EXI = {n: k for k, n in enumerate(EX)}
    RR = pd.read_csv('/home/claude/bs/g/rl_rules_k.csv')
    ch = {}
    for _, r in RR.iterrows():
        ch[(int(r.g), int(r.f))] = {y: (EXI.get(r[f'手じまい{y}'], -1) if isinstance(r[f'手じまい{y}'], str) else -1) for y in YRS}
    res = {}
    for inst in insts:
        C = ctx5(inst, 'W'); S = dict(np.load(f'/home/claude/bs/g/ksig_{inst}_W.npz')); Q = dict(np.load(f'/home/claude/bs/g/krand_{inst}.npz'))
        # ランダムの全部の手じまいの成績
        qi = Q['i'].astype(np.int64); qd = np.where(Q['d'] % 2 == 0, 1, -1).astype(np.int64); qs = (Q['d'] // 2).astype(int); qf = Q['f'].astype(np.int64)
        qy = C['yr'][qi]; keep = qy >= 2020; qi, qd, qs, qf, qy = qi[keep], qd[keep], qs[keep], qf[keep], qy[keep]
        RV = np.zeros((len(qi), len(EX)), np.float32); RX = np.zeros((len(qi), len(EX)), np.int64)
        for a in range(0, len(qi), 30000):
            sl = slice(a, a + 30000); R, NT, HB = simulate(C, qi[sl], qd[sl], C['c'][qi[sl]]); nrm, _ = money(inst, R, C['c'][qi[sl]], NT)
            RV[sl] = nrm; RX[sl] = qi[sl][:, None] + HB
        print(inst, 'random done', len(qi), flush=True)
        di = S['d'].astype(np.int64); si = S['i'].astype(np.int64); sf = S['f'].astype(np.int64); sy = C['yr'][si]
        m0 = sy >= 2020; di, si, sf, sy = di[m0], si[m0], sf[m0], sy[m0]
        order = np.argsort(di, kind='stable'); di, si, sf, sy = di[order], si[order], sf[order], sy[order]
        bnd = np.searchsorted(di, np.arange(len(DF) + 1))
        rules_by_g = {}
        for (g, f) in ch: rules_by_g.setdefault(g, []).append(f)
        g = 0
        while g < len(DF):
            g2 = g; tot = 0
            while g2 < len(DF) and tot + (bnd[g2 + 1] - bnd[g2]) <= 40000: tot += bnd[g2 + 1] - bnd[g2]; g2 += 1
            if g2 == g: g2 = g + 1
            sl = slice(bnd[g], bnd[g2]); ii = si[sl]
            if len(ii):
                dr = DF['dir'].values[di[sl]]; a_ = DF['a'].values[di[sl]]; isline = (DF['grp'].values[di[sl]] == '線') & (a_ >= 0)
                LR = np.where(isline, C['LM'][ii, np.maximum(a_, 0)], C['c'][ii])
                R, NT, HB = simulate(C, ii, dr.astype(np.int64), LR); nrm, _ = money(inst, R, C['c'][ii], NT); XO = ii[:, None] + HB
                for gg in range(g, g2):
                    loc = np.arange(bnd[gg] - bnd[g], bnd[gg + 1] - bnd[g])
                    for f in rules_by_g.get(gg, []):
                        m = loc if f == 0 else loc[((sf[sl][loc] >> (f - 1)) & 1).astype(bool)]
                        if len(m) == 0: continue
                        e = np.array([ch[(gg, f)][y] for y in sy[sl][m]]); ok = e >= 0; m, e = m[ok], e[ok]
                        res.setdefault((gg, f), {})[inst] = (ii[m], XO[m, e], nrm[m, e].astype(float), sy[sl][m], e)
            g = g2
        # ランダム（同じ向き・同じ方向確認・同じ手じまい）
        for (gg, f), dct in res.items():
            if inst not in dct: continue
            dr = DF['dir'].values[gg]; mm = qd == dr
            if f > 0: mm &= ((qf >> (f - 1)) & 1).astype(bool)
            pools = []
            for seed in range(5):
                ms = np.nonzero(mm & (qs == seed))[0]
                if len(ms) == 0: continue
                e = np.array([ch[(gg, f)][y] for y in qy[ms]]); ok = e >= 0; ms, e = ms[ok], e[ok]
                pools.append((qi[ms], RX[ms, e], RV[ms, e].astype(float), qy[ms]))
            dct[inst] = dct[inst] + (pools,)
        print(inst, 'rules done', flush=True)
    rows = []
    for (g, f), dct in res.items():
        row = dict(調べ='15分足(網羅)', ルール=f"k:{DF.trig[g]}{'買' if DF.dir[g] == 1 else '売'}", 向き='買い' if DF.dir[g] == 1 else '売り', 方向確認=FL[f], 条件='そのまま')
        for inst, L in [('fut', 'ミニ'), ('cfd', 'CFD')]:
            if inst not in dct: continue
            i5, x5, v, yr, e, pools = dct[inst]
            row.update(one_stats(i5, x5, v, yr, f'{L} ')); row.update(rand_stats(pools, f'{L} ランダム')); compare(row, L)
        rows.append(row)
    return pd.DataFrame(rows), res

if __name__ == '__main__':
    import pickle
    st = sys.argv[1]
    if st == 'k':
        D, res = study_k()
        D.to_pickle('/home/claude/bs/g/rs3_k.pkl'); print(D.shape)
        pickle.dump({k: v for k, v in res.items() if k[1] == 0}, open('/home/claude/bs/g/rs3_k_res0.pkl', 'wb'))
