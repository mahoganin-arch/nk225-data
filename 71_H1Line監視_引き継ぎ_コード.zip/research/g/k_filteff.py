"""方向確認（フィルター）の効き目：線を使う各トリガーで、方向確認を付けた形と付けない形の「ランダムとの差」の変化を、2商品×2期間で見る。
本物の線とでたらめな線で、改善するトリガーの割合と変化の中央値を比べる。"""
import sys; sys.path.insert(0,'/home/claude/bs/g')
import numpy as np, pandas as pd
from k_form import form, rand_form, H
DF=pd.read_csv('/home/claude/bs/g/kdefs.csv',index_col=0); FS=pd.read_csv('/home/claude/bs/g/kfsets.csv')
RF={i:rand_form(i) for i in ['fut','cfd']}
rows=[]
for fam in ['W','r0','r1','r2','r3','r4','r5']:
    cols=[]
    for inst in ['fut','cfd']:
        F=form(inst,fam); F['dir']=DF.dir.values[F['def']]; F=F.merge(RF[inst],on=['dir','fset'],how='left')
        for h in H:
            F[f'd_{h}']=F[f'a_{h}']-F[f'r_{h}']
        F=F.set_index(['def','fset'])
        for h in H:
            s=F[f'd_{h}']; n=F[f'n_{h}']
            base=s.xs(0,level='fset'); delta=s-base.reindex(s.index.get_level_values(0)).values
            delta[n<20]=np.nan
            cols.append(delta.rename(f'{inst}_{h}'))
    Dl=pd.concat(cols,axis=1).reset_index()
    Dl=Dl[(Dl.fset>0)&(DF.grp.values[Dl['def']]!='インジ')].dropna()
    c=[c for c in Dl.columns if c.startswith(('fut','cfd'))]
    Dl['all4']=(Dl[c]>0).all(axis=1); Dl['med']=Dl[c].median(axis=1)
    g=Dl.groupby('fset').agg(改善4つとも=('all4','mean'),変化中央=('med','median'),トリガー数=('all4','size')).reset_index(); g['fam']=fam
    rows.append(g); print(fam,flush=True)
R=pd.concat(rows).merge(FS,on='fset')
R.to_pickle('/home/claude/bs/g/kfilteff.pkl')
W=R[R.fam=='W'].set_index('fset'); N=R[R.fam!='W'].groupby('fset').agg(n_mean=('改善4つとも','mean'),n_sd=('改善4つとも','std'),n_med=('変化中央','mean'))
J=W.join(N); J['z']=(J['改善4つとも']-J.n_mean)/J.n_sd
pd.set_option('display.width',250)
print(J[J.k==1].sort_values('z',ascending=False)[['name','改善4つとも','n_mean','z','変化中央','n_med','トリガー数']].round(3).to_string())
print(J[J.k==2].sort_values('z',ascending=False)[['name','改善4つとも','n_mean','z','変化中央','n_med']].head(12).round(3).to_string())
