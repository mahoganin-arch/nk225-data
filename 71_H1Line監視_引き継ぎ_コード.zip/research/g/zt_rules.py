"""@CZerch のセオリーを先に決めたルールとして作る（15分足チャート、5分足データの15分足の終わりで判定）。
fam='W' 本物の線、'r*' でたらめな線（kind_{inst}_{fam}）。ストキャス（15分・1H・4H）は価格だけで決まる。
出力：zt_{inst}_{fam}.npz（i 5分足の位置, d 向き, rule, lr 損切りの基準線）、zt_rules.csv
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
LN = pd.read_csv('/home/claude/bs/g/k_lnames.csv').iloc[:, 0].tolist(); IN = pd.read_csv('/home/claude/bs/g/k_inames.csv').iloc[:, 0].tolist()

def up_stoch(inst, tf, end5):
    X = dict(np.load(f'/home/claude/bs/g/sw_{tf}_{inst}.npz')); k = np.searchsorted(X['tend'], end5, side='right') - 1; ok = k >= 0
    out = {}
    for nm in ('fk', 'fd', 'sk', 'sd', 'c', 'h', 'l'):
        a = np.full(len(end5), np.nan); a[ok] = X[nm][k[ok]]; out[nm] = a
    out['k'] = np.where(ok, k, -1); return out

def zigzag(h, l, thr):
    """確定した転換点：(確定した足, 転換点の足, 値, 種類 +1山/-1谷)。thr は足ごとの幅（配列）"""
    piv = []; n = len(h); mode = 0; ext_i = 0; ext_v = h[0]
    lo_i, lo_v, hi_i, hi_v = 0, l[0], 0, h[0]
    for i in range(1, n):
        if mode >= 0:
            if h[i] > hi_v: hi_v, hi_i = h[i], i
            if mode == 1 and hi_v - l[i] >= thr[i]:
                piv.append((i, hi_i, hi_v, 1)); mode = -1; lo_v, lo_i = l[i], i; continue
        if mode <= 0:
            if l[i] < lo_v: lo_v, lo_i = l[i], i
            if mode == -1 and h[i] - lo_v >= thr[i]:
                piv.append((i, lo_i, lo_v, -1)); mode = 1; hi_v, hi_i = h[i], i; continue
        if mode == 0:
            if hi_v - l[i] >= thr[i]: piv.append((i, hi_i, hi_v, 1)); mode = -1; lo_v, lo_i = l[i], i
            elif h[i] - lo_v >= thr[i]: piv.append((i, lo_i, lo_v, -1)); mode = 1; hi_v, hi_i = h[i], i
    return piv

HARM = {'ガートレー': ((0.618, 0.618), (0.382, 0.886), (1.27, 1.618), (0.786, 0.786)), 'バット': ((0.382, 0.5), (0.382, 0.886), (1.618, 2.618), (0.886, 0.886)),
        'バタフライ': ((0.786, 0.786), (0.382, 0.886), (1.618, 2.24), (1.27, 1.618)), 'クラブ': ((0.382, 0.618), (0.382, 0.886), (2.24, 3.618), (1.618, 1.618))}

def harmonics(piv, tol=0.1):
    """XABCD がそろって D が確定した足 → (確定足, 向き +1買い/-1売り, X の値, D の値)"""
    out = []
    for j in range(4, len(piv)):
        X, A, B, C, D = piv[j - 4:j + 1]
        xa = abs(A[2] - X[2]); ab = abs(B[2] - A[2]); bc = abs(C[2] - B[2]); cd = abs(D[2] - C[2]); ad = abs(D[2] - A[2])
        if min(xa, ab, bc) <= 0: continue
        r = (ab / xa, bc / ab, cd / bc, ad / xa)
        for nm, rng in HARM.items():
            if all(lo * (1 - tol) <= v <= hi * (1 + tol) for v, (lo, hi) in zip(r, rng)):
                out.append((D[0], -D[3], X[2], D[2], nm)); break
    return out

def triangles(piv, c, n, look=3):
    """直近3つの山が切り下げ・3つの谷が切り上げ → 上の線・下の線を足ごとに伸ばし、終値で抜けたら合図"""
    up = np.zeros(n, bool); dn = np.zeros(n, bool)
    hs = [p for p in piv if p[3] == 1]; ls = [p for p in piv if p[3] == -1]
    conf = sorted(set(p[0] for p in piv))
    hi_ptr = lo_ptr = 0; active = None
    pv = {p[0]: p for p in piv}
    H = []; Lw = []
    for i in range(n):
        if i in pv:
            p = pv[i]; (H if p[3] == 1 else Lw).append(p)
            if len(H) >= look and len(Lw) >= look:
                h3 = H[-look:]; l3 = Lw[-look:]
                if all(h3[k][2] > h3[k + 1][2] for k in range(look - 1)) and all(l3[k][2] < l3[k + 1][2] for k in range(look - 1)):
                    sh = np.polyfit([q[1] for q in h3], [q[2] for q in h3], 1); sl_ = np.polyfit([q[1] for q in l3], [q[2] for q in l3], 1)
                    active = (sh, sl_, i)
                else:
                    active = None
        if active is not None:
            sh, sl_, i0 = active; uh = sh[0] * i + sh[1]; ul = sl_[0] * i + sl_[1]
            if uh <= ul or i - i0 > 200: active = None; continue
            if c[i] > uh: up[i] = True; active = None
            elif c[i] < ul: dn[i] = True; active = None
    return up, dn

def first(mask, seg):
    seg = pd.Series(seg).fillna(-1).values; out = np.zeros(len(mask), bool); idx = np.nonzero(mask)[0]
    if len(idx) == 0: return out
    _, k = np.unique(seg[idx], return_index=True); out[idx[k]] = True; return out

def build(inst, fam):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); K = dict(np.load(f'/home/claude/bs/g/kind_{inst}_{fam}.npz')); KW = dict(np.load(f'/home/claude/bs/g/kind_{inst}_W.npz'))
    c = X['c'].astype(float); h = X['h'].astype(float); l = X['l'].astype(float); A = X['avg20'].astype(float); n = len(c); is15 = K['is15']
    LM = K['L'].astype(float); I = KW['I'].astype(float); col = {nm: j for j, nm in enumerate(IN)}
    L = {nm: LM[:, LN.index(nm)] for nm in ['H1Line', 'H4Line', 'D1Line', 'H1Line 山', 'H1Line 谷', 'H4Line 山', 'H4Line 谷', 'macd 15m-1H', 'signal 15m-1H']}
    end5 = X['tm'] + 300; S1 = up_stoch(inst, '60', end5); S4 = up_stoch(inst, '240', end5)
    q = np.nonzero(is15)[0]  # 15分足の終わり
    c15 = c[q]; h15 = pd.Series(h).groupby(np.cumsum(np.r_[0, is15[:-1]])).max().values[:len(q)]; l15 = pd.Series(l).groupby(np.cumsum(np.r_[0, is15[:-1]])).min().values[:len(q)]
    A15 = A[q]; ev = {}
    def put(name, d, mask15, lr15=None):
        ii = q[mask15]; ev[(name, d)] = (ii, (lr15[mask15] if lr15 is not None else c15[mask15]))
    rec = lambda flag, nb: pd.Series(flag.astype(float)).rolling(nb, min_periods=1).max().values > 0
    for nm in ['H1Line', 'H4Line', 'D1Line']:
        v = L[nm][q]; above = c15 > v; pa = np.r_[False, above[:-1]]
        bdn = (~above) & pa; bup = above & ~pa
        for nb, lab in [(16, '4時間'), (96, '1日')]:
            # 割れてから戻っていない間 / 抜けてから割れていない間
            last_dn = pd.Series(np.where(bdn, np.arange(len(q)), np.nan)).ffill().values; last_up = pd.Series(np.where(bup, np.arange(len(q)), np.nan)).ffill().values
            since_dn = np.arange(len(q)) - last_dn; since_up = np.arange(len(q)) - last_up
            below_since = (~above) & (since_dn <= nb) & ((np.isnan(last_up)) | (last_up < last_dn))
            above_since = above & (since_up <= nb) & ((np.isnan(last_dn)) | (last_dn < last_up))
            ura = below_since & (h15 >= v - 0.05 * A15) & ~bdn
            omote = above_since & (l15 <= v + 0.05 * A15) & ~bup
            ura = first(ura, last_dn); omote = first(omote, last_up)
            put(f'{nm} 裏タッチ（割れて{lab}以内）', -1, ura, v); put(f'{nm} 表タッチ（抜けて{lab}以内）', 1, omote, v)
        for k_ in (2, 4):
            run = pd.Series(above.astype(int)).groupby((above != np.r_[False, above[:-1]]).cumsum()).cumcount().values + 1
            put(f'{nm} 抜けて終値{k_}本上に居続けた', 1, above & (run == k_), v); put(f'{nm} 割れて終値{k_}本下に居続けた', -1, (~above) & (run == k_), v)
        # 抜けの3つ目の形：上でもみ合ってから、もみ合いの高値を抜ける（8本以上、線の上に居続けた）
        run = pd.Series(above.astype(int)).groupby((above != np.r_[False, above[:-1]]).cumsum()).cumcount().values + 1
        rh = pd.Series(h15).rolling(8).max().shift(1).values; rl = pd.Series(l15).rolling(8).min().shift(1).values
        seg = (above != np.r_[False, above[:-1]]).cumsum(); tight = (rh - rl) <= 0.3 * A15
        put(f'{nm} 上でもみ合ってから抜ける', 1, first(above & (run >= 9) & tight & (c15 > rh) & (np.r_[np.nan, c15[:-1]] <= rh), seg), v)
        put(f'{nm} 下でもみ合ってから割る', -1, first((~above) & (run >= 9) & tight & (c15 < rl) & (np.r_[np.nan, c15[:-1]] >= rl), seg), v)
    # ストキャスの順番：4H のデッドクロスの後、W 時間以内に 1H のデッドクロス → 売り（逆は買い）
    f1, d1 = S1['fk'][q], S1['fd'][q]; f4, d4 = S4['fk'][q], S4['fd'][q]
    def cross(a, b):
        s = np.sign(np.nan_to_num(a - b)); p = np.r_[0, s[:-1]]; return (s > 0) & (p <= 0), (s < 0) & (p >= 0)
    g1, x1 = cross(f1, d1); g4, x4 = cross(f4, d4)
    for W_, lab in [(32, '8時間'), (96, '1日')]:
        put(f'4Hデッド→1Hデッド（{lab}以内）', -1, x1 & rec(x4, W_) & (f4 < d4)); put(f'4Hゴールデン→1Hゴールデン（{lab}以内）', 1, g1 & rec(g4, W_) & (f4 > d4))
    gs1, xs1 = cross(f1, S1['sk'][q]); gs4, xs4 = cross(f4, S4['sk'][q])
    put('4H速K×遅Kデッド→1H速K×遅Kデッド（1日以内）', -1, xs1 & rec(xs4, 96)); put('4H速K×遅Kゴールデン→1H速K×遅Kゴールデン（1日以内）', 1, gs1 & rec(gs4, 96))
    # 上がれる周期で上がれない：1H が上げ周期（ゴールデン〜デッド）の間に、その前の周期の高値を越えられず、デッドクロス → 売り（逆も）
    cyc = np.cumsum(g1 | x1); hi_c = pd.Series(h15).groupby(cyc).max(); lo_c = pd.Series(l15).groupby(cyc).min()
    prev_hi = pd.Series(cyc).map(hi_c.shift(2)).values; prev_lo = pd.Series(cyc).map(lo_c.shift(2)).values
    this_hi = pd.Series(cyc).map(hi_c).values; this_lo = pd.Series(cyc).map(lo_c).values
    cyc_hi_prev = pd.Series(cyc - 1).map(hi_c).values; cyc_lo_prev = pd.Series(cyc - 1).map(lo_c).values
    put('上がれる周期で上がれない（1H上げ周期で前の高値を越えずにデッド）', -1, x1 & (cyc_hi_prev < prev_hi))
    put('下がれる周期で下がれない（1H下げ周期で前の安値を割らずにゴールデン）', 1, g1 & (cyc_lo_prev > prev_lo))
    put('上がれる周期でH1Lineを越えられずデッド', -1, x1 & (pd.Series(cyc - 1).map(pd.Series(c15).groupby(cyc).max()).values < L['H1Line'][q]))
    # 下げ周期の終わりで再浮上：1H 速Kが40以下でゴールデン、4H は上げ周期
    put('1H下げ周期の終わりで再浮上（1H低位でゴールデン・4H上げ周期）', 1, g1 & (f1 < 40) & (f4 > d4)); put('1H上げ周期の終わりで反落（1H高位でデッド・4H下げ周期）', -1, x1 & (f1 > 60) & (f4 < d4))
    # 目線の継続：H4Line を割ってから上に戻るまでの間だけ売りの合図を使う
    v4 = L['H4Line'][q]; below4 = c15 < v4
    s_h1 = np.sign(np.nan_to_num(np.diff(L['H1Line'][q], prepend=np.nan))); h1_dn = (s_h1 < 0) & (np.r_[0, s_h1[:-1]] >= 0); h1_up = (s_h1 > 0) & (np.r_[0, s_h1[:-1]] <= 0)
    ind = np.stack([I[q, col[f'Indi0{m}向き']] for m in range(2, 7)], 1); blue5 = (ind < 0).all(1); red5 = (ind > 0).all(1)
    blue_on = blue5 & ~np.r_[False, blue5[:-1]]; red_on = red5 & ~np.r_[False, red5[:-1]]
    mac_dn = cross(L['macd 15m-1H'][q], L['signal 15m-1H'][q])[1]; mac_up = cross(L['macd 15m-1H'][q], L['signal 15m-1H'][q])[0]
    put('H4Lineの下で H1Line陰転', -1, below4 & h1_dn); put('H4Lineの上で H1Line陽転', 1, ~below4 & h1_up)
    put('H4Lineの下で インジ5本が青に', -1, below4 & blue_on); put('H4Lineの上で インジ5本が赤に', 1, ~below4 & red_on)
    put('H4Lineの下で H1Line陰転＋インジ5本青（3本以内）', -1, below4 & ((h1_dn & rec(blue_on, 3)) | (blue_on & rec(h1_dn, 3))))
    put('H4Lineの上で H1Line陽転＋インジ5本赤（3本以内）', 1, ~below4 & ((h1_up & rec(red_on, 3)) | (red_on & rec(h1_up, 3))))
    put('H4Lineの下で 15m-1H陰転', -1, below4 & mac_dn); put('H4Lineの上で 15m-1H陽転', 1, ~below4 & mac_up)
    put('H4Lineの下で 4Hデッド→1Hデッド', -1, below4 & x1 & rec(x4, 96) & (f4 < d4)); put('H4Lineの上で 4Hゴールデン→1Hゴールデン', 1, ~below4 & g1 & rec(g4, 96) & (f4 > d4))
    # 形：三角持ち合い・ハーモニック（15分足）
    piv = zigzag(h15, l15, 0.25 * np.nan_to_num(A15, nan=np.nanmedian(A15)))
    tu, td = triangles(piv, c15, len(q)); put('三角持ち合いを上抜け（15分足）', 1, tu); put('三角持ち合いを下抜け（15分足）', -1, td)
    hm = harmonics(piv)
    Lall = np.stack([L[k][q] for k in ['H1Line', 'H4Line', 'D1Line', 'H1Line 山', 'H1Line 谷', 'H4Line 山', 'H4Line 谷']], 1)
    for nm in list(HARM) + ['全部']:
        for dd in (1, -1):
            m = np.zeros(len(q), bool); m2 = np.zeros(len(q), bool); lr = c15.copy()
            for (j, dr, xv, dv, kind) in hm:
                if dr != dd or (nm != '全部' and kind != nm): continue
                m[j] = True; lr[j] = dv
                if np.nanmin(np.abs(Lall[j] - dv)) <= 0.1 * A15[j]: m2[j] = True
            lab = 'ハーモニック' + ('' if nm == '全部' else f'（{nm}）') + ('買い' if dd == 1 else '売り')
            put(f'{lab} D点確定', dd, m, lr)
            if nm == '全部': put(f'{lab} D点確定＋D点の近くに線', dd, m2, lr)
    # 売りの否定：ハーモニック売りの後、X 点を越えたら買い（逆も）
    neg_b = np.zeros(len(q), bool); neg_s = np.zeros(len(q), bool)
    for (j, dr, xv, dv, kind) in hm:
        seg = slice(j + 1, min(j + 97, len(q)))
        if dr == -1:
            k = np.nonzero(c15[seg] > xv)[0]
            if len(k): neg_b[j + 1 + k[0]] = True
        else:
            k = np.nonzero(c15[seg] < xv)[0]
            if len(k): neg_s[j + 1 + k[0]] = True
    put('ハーモニック売りの否定（X点を越えたら買い）', 1, neg_b); put('ハーモニック買いの否定（X点を割ったら売り）', -1, neg_s)
    # 寄り付き×線：日中 8:45・夜間 17:00 の最初の15分足の終わりで、H1Line と H4Line の両方の上なら買い、両方の下なら売り
    t = pd.to_datetime(X['tm'][q], unit='s', utc=True).tz_convert('Asia/Tokyo'); hm_ = t.hour * 60 + t.minute
    op = np.isin(hm_.values, [8 * 60 + 55, 17 * 60 + 10])  # 15分足の終わり（8:45〜9:00 の足 → 開始 8:55 の5分足）
    v1 = L['H1Line'][q]
    put('寄り付き：H1Line・H4Lineの上なら買い', 1, op & (c15 > v1) & (c15 > v4)); put('寄り付き：H1Line・H4Lineの下なら売り', -1, op & (c15 < v1) & (c15 < v4))
    put('寄り付き：H1Lineの上・15m-1H陽転なら買い', 1, op & (c15 > v1) & (L['macd 15m-1H'][q] > L['signal 15m-1H'][q]))
    put('寄り付き：H1Lineの下・15m-1H陰転なら売り', -1, op & (c15 < v1) & (L['macd 15m-1H'][q] < L['signal 15m-1H'][q]))
    # ---- 追加：タッチの近さを広げる・届かずに切り返し・ダマシ・ハーモニックの誤差 ----
    for nm in ['H1Line', 'H4Line', 'D1Line']:
        v = L[nm][q]; above = c15 > v; pa = np.r_[False, above[:-1]]; pc15 = np.r_[np.nan, c15[:-1]]
        bdn = (~above) & pa; bup = above & ~pa
        last_dn = pd.Series(np.where(bdn, np.arange(len(q)), np.nan)).ffill().values; last_up = pd.Series(np.where(bup, np.arange(len(q)), np.nan)).ffill().values
        since_dn = np.arange(len(q)) - last_dn; since_up = np.arange(len(q)) - last_up
        below_since = (~above) & (since_dn <= 16) & ((np.isnan(last_up)) | (last_up < last_dn))
        above_since = above & (since_up <= 16) & ((np.isnan(last_dn)) | (last_dn < last_up))
        for w in (0.0, 0.03, 0.1, 0.15, 0.25):
            put(f'{nm} 裏タッチ 近さ{w}A（割れて4時間以内）', -1, first(below_since & (h15 >= v - w * A15) & ~bdn, last_dn), v)
            put(f'{nm} 表タッチ 近さ{w}A（抜けて4時間以内）', 1, first(above_since & (l15 <= v + w * A15) & ~bup, last_up), v)
        for w in (0.05, 0.1, 0.15):
            put(f'{nm} 裏側で届かずに切り返し（{w}A以内・触れず）', -1, first(below_since & (h15 >= v - w * A15) & (h15 < v) & ~bdn, last_dn), v)
            put(f'{nm} 表側で届かずに切り返し（{w}A以内・触れず）', 1, first(above_since & (l15 <= v + w * A15) & (l15 > v) & ~bup, last_up), v)
            # 抜けていない時の、下から近づいて届かずに落ちる（抵抗）／上から近づいて届かずに上がる（支え）
            put(f'{nm} 下から届かずに反落（{w}A以内・触れず）', -1, (~above) & (pc15 < v) & (h15 >= v - w * A15) & (h15 < v) & (c15 < np.r_[np.nan, h15[:-1]]), v)
            put(f'{nm} 上から届かずに反発（{w}A以内・触れず）', 1, above & (pc15 > v) & (l15 <= v + w * A15) & (l15 > v) & (c15 > np.r_[np.nan, l15[:-1]]), v)
        put(f'{nm} ダマシの上抜け（ヒゲで越えて終値は下）で売り', -1, (pc15 < v) & (h15 > v) & (c15 < v), v)
        put(f'{nm} ダマシの下抜け（ヒゲで割って終値は上）で買い', 1, (pc15 > v) & (l15 < v) & (c15 > v), v)
    for nm in ['H1Line 山', 'H4Line 山']:
        v = L[nm][q]; pc15 = np.r_[np.nan, c15[:-1]]
        for w in (0.05, 0.1, 0.15):
            put(f'{nm}の値に届かずに反落（{w}A以内・触れず）', -1, (pc15 < v) & (h15 >= v - w * A15) & (h15 < v) & (c15 < pc15), v)
        put(f'{nm}の値をヒゲで越えて終値は下（ダマシ）で売り', -1, (pc15 < v) & (h15 > v) & (c15 < v), v)
    for nm in ['H1Line 谷', 'H4Line 谷']:
        v = L[nm][q]; pc15 = np.r_[np.nan, c15[:-1]]
        for w in (0.05, 0.1, 0.15):
            put(f'{nm}の値に届かずに反発（{w}A以内・触れず）', 1, (pc15 > v) & (l15 <= v + w * A15) & (l15 > v) & (c15 > pc15), v)
        put(f'{nm}の値をヒゲで割って終値は上（ダマシ）で買い', 1, (pc15 > v) & (l15 < v) & (c15 > v), v)
    for tol in (0.05, 0.2):
        hm2 = harmonics(piv, tol=tol)
        for dd in (1, -1):
            m = np.zeros(len(q), bool); lr = c15.copy()
            for (j, dr, xv, dv, kind) in hm2:
                if dr == dd: m[j] = True; lr[j] = dv
            put(f"ハーモニック{'買い' if dd == 1 else '売り'} D点確定（比率の誤差{int(tol * 100)}%）", dd, m, lr)
    names = sorted(set(k for k in ev), key=lambda z: list(ev).index(z))
    I_, D_, R_, LR_ = [], [], [], []
    for r, (nm, d) in enumerate(names):
        ii, lr = ev[(nm, d)]; ok = (X['yr'][ii] >= 2018) & ~np.isnan(A[ii])
        I_.append(ii[ok]); D_.append(np.full(ok.sum(), d)); R_.append(np.full(ok.sum(), r)); LR_.append(np.nan_to_num(lr[ok], nan=0) + np.isnan(lr[ok]) * c[ii[ok]])
    np.savez_compressed(f'/home/claude/bs/g/zt_{inst}_{fam}.npz', i=np.concatenate(I_), d=np.concatenate(D_), rule=np.concatenate(R_), lr=np.concatenate(LR_))
    if fam == 'W': pd.DataFrame([dict(rule=r, 名前=nm, 向き='買' if d == 1 else '売') for r, (nm, d) in enumerate(names)]).to_csv('/home/claude/bs/g/zt_rules.csv', index=False)
    print(inst, fam, len(names), sum(len(x) for x in I_), flush=True)

if __name__ == '__main__':
    for inst in sys.argv[1].split(','):
        for fam in sys.argv[2].split(','): build(inst, fam)
