"""候補と「近いが外れた」ものの一覧（買い・売り）。すべて前向き（2020〜2026、手じまいは前の年で選ぶ）・ポジション1つずつ。
対象：(1) 全ルール成績表（方向確認あり）、(2) 方向確認なしの全ルールとセオリーのルール：そのまま／避ける条件つき／入る条件つき（条件は前の年で選ぶ）。
候補の条件（ミニ・CFD の両方で）：①合計プラス ②7年中5年以上プラス ③1回平均がランダム（同じ向き・同じ条件）より良い ④1つずつで70回以上 ⑤線を使うルールは でたらめな線より頑丈（z≥2）。
近いが外れた：①〜⑤のうち1つだけ満たさない。
出力：cand_list.pkl
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from cond import feats, apply
YRS = list(range(2020, 2027))

def parse(s, names):
    if not isinstance(s, str) or s == '': return []
    out = []
    for c in s.replace(' かつ ', ' / ').split(' / '):
        a, b = c.rsplit('=', 1); out.append((names.index(a), int(b)))
    return out

def stats(i5, x5, v, yr, hold_scale=5 / 60):
    o = np.argsort(i5, kind='stable'); last = -1; tk = []
    for q in o:
        if i5[q] > last: tk.append(q); last = x5[q]
    tk = np.array(tk, int)
    if len(tk) == 0: return dict(件数=0, 一回平均=np.nan, 合計=0.0, 最大DD=0.0, 勝率=np.nan, 平均保有時間=np.nan, プラスの年=0, **{str(y): 0.0 for y in YRS})
    vv = v[tk]; oo = np.argsort(x5[tk], kind='stable'); cs = np.cumsum(vv[oo]); dd = float((np.maximum.accumulate(cs) - cs).max())
    yy = yr[tk]; ys = {str(y): float(vv[yy == y].sum()) for y in YRS}
    return dict(件数=len(tk), 一回平均=float(vv.mean()), 合計=float(vv.sum()), 最大DD=dd, 勝率=float((vv > 0).mean()), 平均保有時間=float(((x5[tk] - i5[tk]) * hold_scale).mean()),
                プラスの年=int(sum(ys[str(y)] > 0 for y in YRS)), **ys)

def from_trades(src, condf):
    T = pd.read_pickle(f'/home/claude/bs/g/{src}.pkl'); T = T[T.yr >= 2018].reset_index(drop=True); T['rule'] = T.rule.astype(str)
    F, names = feats(T); C = pd.read_pickle(condf); PL = C['picks']
    PK = {(r.rule, r.t, r.型): parse(r.条件, names) for r in PL.itertuples()}
    idx = T.groupby('rule').indices; rows = []
    rand = {k: v for k, v in idx.items() if k.startswith('rand:')}
    for rule, ix in idx.items():
        if rule.startswith('rand:'): continue
        st = rule.split(':')[0]; rk = f"rand:{st}:{rule[-1]}"; rix = rand.get(rk)
        g_i5 = T.i5.values[ix]; g_x5 = T.x5.values[ix]; g_v = T.v.values[ix].astype(float); g_yr = T.yr.values[ix]; g_in = T.inst.values[ix]; Fg = F[ix]
        for mode in ('そのまま', '避ける', '入る条件'):
            keep = g_yr >= 2020; rkeep = None if rix is None else (T.yr.values[rix] >= 2020)
            if mode != 'そのまま':
                mm = np.zeros(len(ix), bool); rm = np.zeros(len(rix), bool) if rix is not None else None
                md = 'avoid' if mode == '避ける' else 'require'
                for t in YRS:
                    pk = PK.get((rule, t, mode), None)
                    if pk is None: continue
                    sel = g_yr == t; mm[sel] = apply(Fg[sel], pk, md)
                    if rix is not None:
                        rs = T.yr.values[rix] == t; rm[rs] = apply(F[rix][rs], pk, md)
                keep &= mm
                if rix is not None: rkeep &= rm
            row = dict(src=src, ルール=rule, 条件=mode)
            for ins, L in [('fut', 'ミニ'), ('cfd', 'CFD')]:
                m = keep & (g_in == ins); s = stats(g_i5[m], g_x5[m], g_v[m], g_yr[m])
                row.update({f'{L} {k}': v for k, v in s.items()})
                if rix is not None:
                    mr = rkeep & (T.inst.values[rix] == ins); row[f'{L} ランダム1回平均（全部）'] = T.v.values[rix][mr].mean() if mr.any() else np.nan
                    if mr.any():
                        ri5 = T.i5.values[rix][mr]; rx5 = T.x5.values[rix][mr]; rv = T.v.values[rix][mr]
                        o = np.argsort(ri5, kind='stable'); last = -1; acc = []
                        for qq in o:
                            if ri5[qq] > last: acc.append(rv[qq]); last = rx5[qq]
                        row[f'{L} ランダム1回平均'] = float(np.mean(acc))
                    else: row[f'{L} ランダム1回平均'] = np.nan
            rows.append(row)
    return pd.DataFrame(rows)

def run():
    A = from_trades('tr2', '/home/claude/bs/g/cond.pkl'); B = from_trades('tr_zt', '/home/claude/bs/g/cond_tr_zt.pkl'); print('trades done', flush=True)
    # 頑丈さ（トリガー）
    rob = {}
    for s, f in [('k', 'xrep_k'), ('sw15', 'swrep_15'), ('sw60', 'swrep_60'), ('sw240', 'swrep_240'), ('swD', 'swrep_D')]:
        t = pd.read_pickle(f'/home/claude/bs/g/{f}.pkl')['trig']
        for _, r in t.iterrows(): rob[f'{s}:{r.トリガー}'] = r['頑丈さ(z)']
    Z = pd.read_pickle('/home/claude/bs/g/zt_eval.pkl')['rules']
    for _, r in Z.iterrows(): rob[f'zt:{r.ルール}{r.向き}'] = r['頑丈さz'] if not str(r.get('注意', '')).startswith('線を使わない') else np.nan
    X = pd.concat([A, B], ignore_index=True)
    # 全ルール成績表のうち、方向確認ありのもの
    C = pd.read_pickle('/home/claude/bs/g/rl_card.pkl')['card']; C = C[C.方向確認 != 'なし']
    lab = {'日足': 'swD', '4時間足': 'sw240', '1時間足': 'sw60', '15分足(スイング)': 'sw15', '15分足(網羅・日中〜週)': 'k'}
    rows = []
    for _, r in C.iterrows():
        row = dict(src='rl_card', ルール=f"{lab[r.調べ]}:{r.トリガー}{r.向き}", 条件=f'方向確認：{r.方向確認}')
        for L in ['ミニ', 'CFD']:
            row.update({f'{L} 件数': r[f'{L} 1つずつ 件数'], f'{L} 一回平均': r[f'{L} 1つずつ 1回平均'], f'{L} 合計': r[f'{L} 1つずつ 合計'], f'{L} 最大DD': r[f'{L} 最大DD'],
                        f'{L} プラスの年': r[f'{L} プラスの年'], f'{L} ランダム1回平均': r[f'{L} ランダム 1回平均'], **{f'{L} {y}': r[f'{L} {y}'] for y in YRS}})
        rows.append(row)
    X = pd.concat([X, pd.DataFrame(rows)], ignore_index=True)
    X['向き'] = np.where(X.ルール.str.endswith('買'), '買い', '売り'); X['頑丈さz'] = X.ルール.map(rob)
    X['調べ'] = X.ルール.str.split(':').str[0].map({'k': '15分足(網羅)', 'sw15': '15分足スイング', 'sw60': '1時間足', 'sw240': '4時間足', 'swD': '日足', 'zt': '15分足セオリー'})
    line_free = X.ルール.str.contains('ストキャス|速K|遅K|同じ位置|PSAR|周期|デッド|ゴールデン|ハーモニック|三角|インジ5本|インジ6本|MACD5本') & ~X.ルール.str.contains('Line|EMA')
    c = {}
    c['①合計プラス'] = (X['ミニ 合計'] > 0) & (X['CFD 合計'] > 0)
    c['②5年以上プラス'] = (X['ミニ プラスの年'] >= 5) & (X['CFD プラスの年'] >= 5)
    c['③ランダムより良い'] = (X['ミニ 一回平均'] > X['ミニ ランダム1回平均']) & (X['CFD 一回平均'] > X['CFD ランダム1回平均'])
    c['④70回以上'] = (X['ミニ 件数'] >= 70) & (X['CFD 件数'] >= 70)
    c['⑤頑丈さ'] = line_free | (X['頑丈さz'] >= 2)
    for k, v in c.items(): X[k] = v
    ok = np.stack(list(c.values()), 1); X['満たさない数'] = (~ok).sum(1)
    X['判定'] = np.select([X.満たさない数 == 0, X.満たさない数 == 1], ['候補', '近いが外れた'], '外れ')
    X['外れた理由'] = [' / '.join(k for k, v in zip(c, row) if not v) for row in ok]
    X['合計(両商品)'] = X['ミニ 合計'] + X['CFD 合計']
    X.to_pickle('/home/claude/bs/g/cand_list_v2.pkl')
    print(X.groupby(['向き', '判定']).size()); print(X[X.判定 == '候補'].groupby(['向き', '調べ', '条件']).size().head(60))

if __name__ == '__main__':
    run()
