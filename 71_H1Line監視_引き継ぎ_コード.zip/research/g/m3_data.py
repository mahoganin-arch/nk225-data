"""3分足チャートの検証用データ。
ミニ：OSE NK225M1! 1分足（2023-10〜）を fut5a の限月つなぎ調整で連続化。CFD：FOREXCOM JP225 1分足（2020-11〜）。
3分足（時刻の0分起点）にまとめ、線とインジを「その足の終わりで分かっている値」で持つ。2026-10-09 6:00 以降は使わない。
線（3分足チャート上）：m15Line=hfilt(m=5)、H1Line=hfilt(20)、3分足線=EMA12、15分足線=EMA60、1H線=EMA240（macd 1H-4H 相当）
  signal 3m-15m = EMA26+EMA(EMA12-EMA26,9)、signal 15m-1H（m=5）
インジ：3分足 速ストキャス(35,21,21)・遅ストキャス(140,84,84) の K・D、上位足（15m・1H・4H・日足）の 速/遅ストキャス（確定した足の値）
出力：m3_{inst}.npz
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/code'); sys.path.insert(0, '/home/claude/bs/g')
from ld import bars
from h_lines import hfilt, ema
from k_ind import stoch
D = '/home/claude/mahoganin-arch/nk225-data/'
CUT = pd.Timestamp('2026-10-09 06:00', tz='Asia/Tokyo')

def load1m(inst):
    if inst == 'fut':
        d = bars(D + 'BarExport3_OSE_NK225M1!_2026-10-12.csv')
        f = pd.read_pickle('/home/claude/bs/fut5a.pkl'); off = pd.Series((f.open_a - f.open).values, index=f.m.values)
        o = off.reindex((d.m // 5 * 5).values).values
        o = pd.Series(o).ffill().bfill().values
        for c in ['open', 'high', 'low', 'close']: d[c] = d[c] + o
    else:
        d = bars(D + 'cfd-BarExport3_FOREXCOM_JP225_2026-10-12.csv')
    d = d[d.t < CUT].set_index('t')[['open', 'high', 'low', 'close']]
    return d

def agg(d, rule):
    return d.resample(rule, label='left', closed='left').agg({'open': 'first', 'high': 'max', 'low': 'min', 'close': 'last'}).dropna()

def build(inst):
    d1 = load1m(inst); b = agg(d1, '3min')
    x = b.close.values.astype(float); H = b.high.values.astype(float); L = b.low.values.astype(float)
    out = dict(t=b.index.as_unit('s').asi8, o=b.open.values, h=H, l=L, c=x)
    out['m15'] = hfilt(x, 5); out['h1'] = hfilt(x, 20)
    out['e12'] = ema(x, 12); out['e60'] = ema(x, 60); out['e240'] = ema(x, 240)
    for nm, m in [('s1', 1), ('s5', 5)]:
        e12 = ema(x, 12 * m); e26 = ema(x, 26 * m); out[nm] = e26 + ema(e12 - e26, 9 * m)
    out['fk'], out['fd'] = stoch(H, L, x, 35, 21, 21); out['sk'], out['sd'] = stoch(H, L, x, 140, 84, 84)
    # 上位足：確定した足の値を、その足の終わり以降の3分足に載せる
    bt = b.index
    for tf, rule in [('15', '15min'), ('60', '60min'), ('240', '240min'), ('D', None)]:
        if rule:
            B = agg(d1, rule); end = B.index + pd.Timedelta(rule)
        else:
            sh = pd.Timedelta(hours=6, minutes=5) if inst == 'fut' else pd.Timedelta(hours=7)
            g = d1.groupby((d1.index - sh).normalize())
            B = g.agg(open=('open', 'first'), high=('high', 'max'), low=('low', 'min'), close=('close', 'last'))
            end = pd.DatetimeIndex(g.apply(lambda s: s.index[-1]).values).tz_localize('UTC').tz_convert('Asia/Tokyo') + pd.Timedelta('1min')
        h_, l_, c_ = B.high.values.astype(float), B.low.values.astype(float), B.close.values.astype(float)
        fk, fd = stoch(h_, l_, c_, 35, 21, 21); sk, sd = stoch(h_, l_, c_, 140, 84, 84)
        # 3分足 j の終わり = bt[j]+3min。確定している上位足 = end <= その時刻 の最後
        k = np.searchsorted(end.values, (bt + pd.Timedelta('3min')).values, side='right') - 1
        for nm, v in [('fk', fk), ('fd', fd), ('sk', sk), ('sd', sd)]:
            a = np.full(len(bt), np.nan); ok = k >= 0; a[ok] = v[k[ok]]; out[f'{nm}{tf}'] = a
    # 日の区切り・セッション
    sh = pd.Timedelta(hours=6, minutes=5) if inst == 'fut' else pd.Timedelta(hours=7)
    s = (bt - sh).tz_localize(None); day = s.normalize()
    hm = bt.hour * 60 + bt.minute
    dayses = ((hm >= 8 * 60) & (hm < 16 * 60 + 15)) if inst == 'fut' else ((bt.hour >= 7) & (bt.hour < 17))
    ses = day + pd.to_timedelta(np.where(dayses, 0, 12), unit='h')
    out['day'] = pd.DatetimeIndex(day).as_unit('s').asi8; out['ses'] = pd.DatetimeIndex(ses).as_unit('s').asi8
    out['yr'] = bt.year.values; out['hm'] = hm.values
    # 前日までの20日平均値幅（A）
    dr = pd.Series(H, index=day).groupby(level=0).max() - pd.Series(L, index=day).groupby(level=0).min()
    A = dr.rolling(20).mean().shift(1); out['A'] = A.reindex(day).values
    np.savez_compressed(f'/home/claude/bs/g/m3_{inst}.npz', **out)
    print(inst, len(b), bt[0], bt[-1], flush=True)

if __name__ == '__main__':
    for i in sys.argv[1].split(','): build(i)
