"""15分足チャート版（ブログの見方を15分足に当てはめる）。5分足（ミニは限月つなぎ調整、2017〜／CFD 2017-03〜）から作る。
キーは m3 と同じ名前で持つが中身は：m15→H1Line(hfilt m=4)、h1→H4Line(m=16)、e12→EMA12(15m-1H)、e60→EMA48(1H-4H)。
ストキャス：チャート(15分)の速/遅、上位足 15(=15分そのもの)・60・240・日足。出力：m15_{inst}.npz
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs'); sys.path.insert(0, '/home/claude/bs/g')
import eng
from h_lines import hfilt, ema
from k_ind import stoch
import m3_data
def build(inst):
    d = eng.load(inst); d1 = d.set_index('t')[['o', 'h', 'l', 'c']].rename(columns={'o': 'open', 'h': 'high', 'l': 'low', 'c': 'close'})
    b = m3_data.agg(d1, '15min')
    x = b.close.values.astype(float); H = b.high.values.astype(float); L = b.low.values.astype(float)
    out = dict(t=b.index.as_unit('s').asi8, o=b.open.values, h=H, l=L, c=x)
    out['m15'] = hfilt(x, 4); out['h1'] = hfilt(x, 16); out['e12'] = ema(x, 12); out['e60'] = ema(x, 48); out['e240'] = ema(x, 192)
    out['fk'], out['fd'] = stoch(H, L, x, 35, 21, 21); out['sk'], out['sd'] = stoch(H, L, x, 140, 84, 84)
    bt = b.index
    for tf, rule in [('15', '15min'), ('60', '60min'), ('240', '240min'), ('D', None)]:
        if rule:
            B = m3_data.agg(d1, rule); end = B.index + pd.Timedelta(rule)
        else:
            sh = pd.Timedelta(hours=6, minutes=5) if inst == 'fut' else pd.Timedelta(hours=7)
            g = d1.groupby((d1.index - sh).normalize())
            B = g.agg(open=('open', 'first'), high=('high', 'max'), low=('low', 'min'), close=('close', 'last'))
            end = pd.DatetimeIndex(g.apply(lambda s: s.index[-1]).values).tz_localize('UTC').tz_convert('Asia/Tokyo') + pd.Timedelta('5min')
        fk, fd = stoch(B.high.values.astype(float), B.low.values.astype(float), B.close.values.astype(float), 35, 21, 21)
        sk, sd = stoch(B.high.values.astype(float), B.low.values.astype(float), B.close.values.astype(float), 140, 84, 84)
        k = np.searchsorted(end.values, (bt + pd.Timedelta('15min')).values, side='right') - 1
        for nm, v in [('fk', fk), ('fd', fd), ('sk', sk), ('sd', sd)]:
            a = np.full(len(bt), np.nan); ok = k >= 0; a[ok] = v[k[ok]]; out[f'{nm}{tf}'] = a
    sh = pd.Timedelta(hours=6, minutes=5) if inst == 'fut' else pd.Timedelta(hours=7)
    s = (bt - sh).tz_localize(None); day = s.normalize(); hm = bt.hour * 60 + bt.minute
    dayses = ((hm >= 8 * 60) & (hm < 16 * 60 + 15)) if inst == 'fut' else ((bt.hour >= 7) & (bt.hour < 17))
    ses = day + pd.to_timedelta(np.where(dayses, 0, 12), unit='h')
    out['day'] = pd.DatetimeIndex(day).as_unit('s').asi8; out['ses'] = pd.DatetimeIndex(ses).as_unit('s').asi8; out['yr'] = bt.year.values; out['hm'] = hm.values
    dr = pd.Series(H, index=day).groupby(level=0).max() - pd.Series(L, index=day).groupby(level=0).min()
    out['A'] = dr.rolling(20).mean().shift(1).reindex(day).values
    np.savez_compressed(f'/home/claude/bs/g/m15_{inst}.npz', **out); print(inst, len(b), bt[0], bt[-1], flush=True)
if __name__ == '__main__':
    for i in sys.argv[1].split(','): build(i)
