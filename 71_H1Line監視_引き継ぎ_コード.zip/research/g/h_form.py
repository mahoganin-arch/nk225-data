"""形としての強さ（条件なし・選ばない）：入り方を形でまとめ、全部の設定（判定足・近さ・決済）を平均した成績を、
本物とでたらめ（r0〜r14）で比べる。z ＝（本物 − でたらめの平均）÷ でたらめの標準偏差。
まとめ方：形（種類×売買の向き）、形×線、決済の要素（利確・損切り・時間）× 種類 × 向き。
期間：全体（2018〜26）・前半（2018〜22）・後半（2023〜26）・2019〜26（前向きと同じ年）。損益：net・nrm・n13（1回平均）。
出力：form.pkl
"""
import sys, glob, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from h_agg import YEARS
import h_sig as G

DF = pd.read_csv('/home/claude/bs/g/hdefs.csv', index_col=0)
EX = pd.DataFrame(G.EXITS, columns=['tp', 'sl', 'tm'])
EX['tp'] = EX.tp.map(dict(enumerate(G.TPS))); EX['sl'] = EX.sl.map(dict(enumerate(G.SLS))); EX['tm'] = EX.tm.map(dict(enumerate(G.TIMES)))
PER = {'全体': YEARS, '前半': list(range(2018, 2023)), '後半': list(range(2023, 2027)), '2019〜26': list(range(2019, 2027))}

def base_rows(inst):
    out = []
    for fam in ['W'] + [f'r{k}' for k in range(6)]:
        A = pd.read_parquet(f'/home/claude/bs/g/hagg_{inst}_{fam}.parquet', filters=[('feat', '=', 0)])
        A = A[['def', 'exit'] + [f'{c}{y}' for c in ['n', 'net', 'nrm', 'n13'] for y in YEARS]]
        A['fam'] = fam; out.append(A)
    for f in glob.glob(f'/home/claude/bs/g/hfamnull_{inst}_*.pkl'):
        B = pd.read_pickle(f); out.append(B.drop(columns='inst'))
    A = pd.concat(out, ignore_index=True)
    A = A.merge(DF[['grp', 'line', 'kind', 'dir', 'tf', 'b']], left_on='def', right_index=True).merge(EX, left_on='exit', right_index=True)
    # 合計 n≥20 の格子だけ（本物の集計と同じ）
    A = A[A[[f'n{y}' for y in YEARS]].sum(1) >= 20]
    return A

def table(A, keys):
    cols = [f'{c}{y}' for c in ['n', 'net', 'nrm', 'n13'] for y in YEARS]
    S = A.groupby(keys + ['fam'])[cols].sum()
    rows = {}
    for pn, ys in PER.items():
        n = S[[f'n{y}' for y in ys]].sum(axis=1)
        for c in ['net', 'nrm', 'n13']:
            rows[(pn, c)] = S[[f'{c}{y}' for y in ys]].sum(axis=1) / n
        rows[(pn, 'n')] = n
    T = pd.DataFrame(rows)
    out = []
    for k, g in T.groupby(level=keys):
        g = g.droplevel(keys)
        if 'W' not in g.index: continue
        real = g.loc['W']; nul = g.drop('W')
        r = {'keys': k}
        for (pn, c) in T.columns:
            if c == 'n':
                r[f'{pn}_件数'] = real[(pn, c)]; continue
            mu = nul[(pn, c)].mean(); sd = nul[(pn, c)].std()
            r[f'{pn}_{c}_本物'] = real[(pn, c)]; r[f'{pn}_{c}_偶然'] = mu; r[f'{pn}_{c}_z'] = (real[(pn, c)] - mu) / sd if sd > 0 else np.nan
        r['偶然の数'] = len(nul)
        out.append(r)
    O = pd.DataFrame(out)
    K = pd.DataFrame(O.pop('keys').tolist() if len(keys) > 1 else [[x] for x in O['keys']] if 'keys' in O else None, columns=keys) if False else None
    kk = pd.DataFrame([x if isinstance(x, tuple) else (x,) for x in [r['keys'] for r in out]], columns=keys)
    return pd.concat([kk, O.drop(columns=['keys'], errors='ignore')], axis=1)

if __name__ == '__main__':
    res = {}
    for inst in ['fut', 'cfd']:
        A = base_rows(inst)
        res[(inst, '形')] = table(A, ['grp', 'kind', 'dir'])
        res[(inst, '形×線')] = table(A, ['grp', 'line', 'kind', 'dir'])
        res[(inst, '利確')] = table(A, ['tp', 'grp', 'dir'])
        res[(inst, '損切り')] = table(A, ['sl', 'grp', 'dir'])
        res[(inst, '時間')] = table(A, ['tm', 'grp', 'dir'])
        res[(inst, '判定足×近さ')] = table(A, ['kind', 'tf', 'b', 'dir'])
        print(inst, flush=True)
    pd.to_pickle(res, '/home/claude/bs/g/form.pkl')
