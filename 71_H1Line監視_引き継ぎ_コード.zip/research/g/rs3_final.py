"""候補の選び直し（v3）のまとめ：基準を当てはめて、買い・売りの候補を出す。偶然で通る割合（にせのルール）も出す。"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from rs3 import seq
FILES = ['rs3_k', 'rs3_kc', 'rs3_sw15', 'rs3_sw60', 'rs3_sw240', 'rs3_swD', 'rs3_zt', 'rs3_ss']

def robust_map():
    rob = {}
    for s, f in [('k', 'xrep_k'), ('sw15', 'swrep_15'), ('sw60', 'swrep_60'), ('sw240', 'swrep_240'), ('swD', 'swrep_D')]:
        t = pd.read_pickle(f'/home/claude/bs/g/{f}.pkl')['trig']
        for _, r in t.iterrows(): rob[f'{s}:{r.トリガー}'] = r['頑丈さ(z)']
    Z = pd.read_pickle('/home/claude/bs/g/zt_eval.pkl')['rules']
    for _, r in Z.iterrows(): rob[f'zt:{r.ルール}{r.向き}'] = r['頑丈さz']
    S = pd.read_pickle('/home/claude/bs/g/ss_eval.pkl')['rules']; RU = pd.read_csv('/home/claude/bs/g/ss_rules.csv'); lu = dict(zip(RU.名前, RU.線を使う))
    for _, r in S.iterrows():
        for p in ('ss', 'ssS', 'ssL'): rob[f'{p}:{r.ルール}{r.向き}'] = r['頑丈さz'] if lu.get(r.ルール, True) else np.nan
    return rob, lu

def pseudo(nrule=300, reps=1500, seed=3):
    """にせのルール：ランダムな入りの中から同じ数を選び、残りのランダムと比べる（効き目のない合図が基準を通る割合）"""
    T = pd.concat([pd.read_pickle(f'/home/claude/bs/g/{f}.pkl') for f in ['tr2', 'tr_zt']], ignore_index=True); T['rule'] = T.rule.astype(str)
    T = T[T.rule.str.startswith('rand:') & (T.yr >= 2020)]
    rng = np.random.default_rng(seed); out = []
    for rr in ['rand:k:買', 'rand:k:売', 'rand:zt:買', 'rand:zt:売', 'rand:sw60:買', 'rand:sw60:売']:
        G = {i: T[(T.rule == rr) & (T.inst == i)] for i in ['fut', 'cfd']}
        for _ in range(reps // 6):
            row = {'元': rr}
            for i, L in [('fut', 'ミニ'), ('cfd', 'CFD')]:
                g = G[i]; m = rng.random(len(g)) < min(0.5, 3 * nrule / len(g)); a = g[m]; b = g[~m]
                ka = seq(a.i5.values, a.x5.values); kb = seq(b.i5.values, b.x5.values)
                va = a.v.values[ka]; vb = b.v.values[kb]; ya = a.yr.values[ka]; yb = b.yr.values[kb]
                d = va.mean() - vb.mean(); se = np.sqrt(va.var() / len(va) + vb.var() / len(vb))
                row[f'{L} t値'] = d / se; row[f'{L} 差'] = d
                row[f'{L} 前半の差'] = va[ya <= 2022].mean() - vb[yb <= 2022].mean(); row[f'{L} 後半の差'] = va[ya >= 2023].mean() - vb[yb >= 2023].mean()
            out.append(row)
    return pd.DataFrame(out)

def criteria(X, rob, lu):
    X = X.copy()
    base = X.ルール.str.split(':', n=1).str[1].str[:-1]
    X['頑丈さz'] = X.ルール.map(rob)
    line_free = X.ルール.str.contains('ストキャス|速K|遅K|同じ位置|PSAR|周期|デッド|ゴールデン|ハーモニック|三角|インジ5本|インジ6本|MACD5本|窓|前日|セッションの安値|米国|日中の最初|大陰線|1時間で|ジグザグ|MACDの線|速ストキャス') & ~X.ルール.str.contains('Line|EMA')
    ssm = X.ルール.str.match(r'^ss[SL]?:'); line_free = np.where(ssm, ~base.map(lu).fillna(True).astype(bool), line_free)
    X['線を使わない'] = line_free
    c = {}
    c['①合計プラス'] = (X['ミニ 合計'] > 0) & (X['CFD 合計'] > 0)
    c['②5年以上プラス'] = (X['ミニ プラスの年'] >= 5) & (X['CFD プラスの年'] >= 5)
    c['③ランダムより良い'] = (X['ミニ ランダムとの差'] > 0) & (X['CFD ランダムとの差'] > 0)
    c['④70回以上'] = (X['ミニ 回数'] >= 70) & (X['CFD 回数'] >= 70)
    c['⑤でたらめな線より頑丈'] = X.線を使わない | (X.頑丈さz >= 2)
    c['⑥差がはっきり（t値の平均1.5以上）'] = ((X['ミニ t値'] + X['CFD t値']) / 2) >= 1.5
    c['⑦前半も後半もランダムより良い'] = (X['ミニ 前半の差'] > 0) & (X['ミニ 後半の差'] > 0) & (X['CFD 前半の差'] > 0) & (X['CFD 後半の差'] > 0)
    for k, v in c.items(): X[k] = v
    ok = np.stack([np.asarray(v, bool) for v in c.values()], 1); X['満たさない数'] = (~ok).sum(1)
    X['外れた理由'] = [' / '.join(k for k, v in zip(c, r) if not v) for r in ok]
    base5 = ok[:, [0, 1, 2, 3, 4, 6]].all(1)
    X['判定'] = np.select([ok.all(1), base5, X.満たさない数 == 1], ['強い候補', '候補', '近いが外れた'], '外れ')
    X['t値の平均'] = (X['ミニ t値'] + X['CFD t値']) / 2
    X['合計(両商品)'] = X['ミニ 合計'] + X['CFD 合計']
    return X

if __name__ == '__main__':
    import os
    D = pd.concat([pd.read_pickle(f'/home/claude/bs/g/{f}.pkl') for f in FILES if os.path.exists(f'/home/claude/bs/g/{f}.pkl')], ignore_index=True)
    rob, lu = robust_map(); X = criteria(D, rob, lu)
    P = pseudo()
    rate = {'③': ((P['ミニ 差'] > 0) & (P['CFD 差'] > 0)).mean(), '⑥': (((P['ミニ t値'] + P['CFD t値']) / 2) >= 1.5).mean(),
            '⑦': ((P['ミニ 前半の差'] > 0) & (P['ミニ 後半の差'] > 0) & (P['CFD 前半の差'] > 0) & (P['CFD 後半の差'] > 0)).mean()}
    rate['③⑥⑦'] = ((P['ミニ 差'] > 0) & (P['CFD 差'] > 0) & (((P['ミニ t値'] + P['CFD t値']) / 2) >= 1.5) & (P['ミニ 前半の差'] > 0) & (P['ミニ 後半の差'] > 0) & (P['CFD 前半の差'] > 0) & (P['CFD 後半の差'] > 0)).mean()
    real = {'③': X['③ランダムより良い'].mean(), '⑥': X['⑥差がはっきり（t値の平均1.5以上）'].mean(), '⑦': X['⑦前半も後半もランダムより良い'].mean(),
            '③⑥⑦': (X['③ランダムより良い'] & X['⑥差がはっきり（t値の平均1.5以上）'] & X['⑦前半も後半もランダムより良い']).mean()}
    pd.to_pickle(dict(X=X, P=P, rate=rate, real=real), '/home/claude/bs/g/rs3_final.pkl')
    print('にせのルールで通る割合', {k: round(v, 3) for k, v in rate.items()}); print('本物のルールで通る割合', {k: round(v, 3) for k, v in real.items()})
    print(X.groupby(['向き', '判定']).size())
    pd.set_option('display.width', 330); pd.set_option('display.max_colwidth', 55); pd.set_option('display.max_rows', 300)
    cols = ['調べ', 'ルール', '方向確認', '条件', '判定', 'ミニ 回数', 'ミニ 1回平均', 'ミニ ランダム1回平均', 'ミニ t値', 'CFD 1回平均', 'CFD ランダム1回平均', 'CFD t値', 'ミニ 前半の差', 'ミニ 後半の差', 'CFD 前半の差', 'CFD 後半の差', 'ミニ プラスの年', 'CFD プラスの年', '頑丈さz']
    for dr in ['買い', '売り']:
        print('==', dr); print(X[(X.向き == dr) & X.判定.isin(['強い候補', '候補'])].sort_values('t値の平均', ascending=False)[cols].head(60).round(1).to_string())
