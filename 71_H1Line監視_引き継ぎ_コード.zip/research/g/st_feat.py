"""時間足ごとの線・ストキャスの状態（15分・1H・4H・日足）＋環境（下向きの時間足の数・直近高値からの下落率など）を、5分足の各足に「その時点で分かっている値」として載せる。
出力：st_{inst}.npz（S[n5, k] int8、-1＝不明）、st_names.csv
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
TFS = [('15', '15分'), ('60', '1H'), ('240', '4H'), ('D', '日足')]
LN = {'15': ('H1Line', 'H4Line'), '60': ('H4Line', 'D1Line'), '240': ('D1Line', '週の線'), 'D': ('週の線', '月の線')}

def cut(x, edges):
    b = np.digitize(x, edges).astype(np.int8); b[np.isnan(x)] = -1; return b

def build(inst):
    X5 = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); end5 = X5['tm'] + 300; n5 = len(end5)
    cols = []; names = []
    down = []
    for tf, lab in TFS:
        X = dict(np.load(f'/home/claude/bs/g/sw_{tf}_{inst}.npz')); c = X['c']; U = X['U']; b = X['base']; u = X['up']
        bn, un = LN[tf]
        sl = lambda v: np.sign(np.nan_to_num(np.diff(v, prepend=np.nan)))
        F = {}
        F[f'{lab} 価格が{bn}の上'] = (c > b).astype(np.int8)
        F[f'{lab} {bn}からの距離(U)'] = cut((c - b) / U, [-0.5, -0.1, 0.1, 0.5])
        F[f'{lab} {bn}の傾き上'] = (sl(b) > 0).astype(np.int8)
        F[f'{lab} {un}の傾き上'] = (sl(u) > 0).astype(np.int8)
        F[f'{lab} 価格が{un}の上'] = (c > u).astype(np.int8)
        F[f'{lab} {bn}が{un}の上'] = (b > u).astype(np.int8)
        F[f'{lab} 陽転(EMA12>signal)'] = (X['e12'] > X['sig']).astype(np.int8)
        F[f'{lab} EMA12が中のEMAの上'] = (X['e12'] > X['emid']).astype(np.int8)
        F[f'{lab} 速Kの位置'] = cut(X['fk'], [20, 50, 80])
        F[f'{lab} 速K>速D'] = np.where(np.isnan(X['fk'] - X['fd']), -1, X['fk'] > X['fd']).astype(np.int8)
        F[f'{lab} 遅Kの位置'] = cut(X['sk'], [20, 50, 80])
        F[f'{lab} 遅K>遅D'] = np.where(np.isnan(X['sk'] - X['sd']), -1, X['sk'] > X['sd']).astype(np.int8)
        F[f'{lab} PSAR上'] = (X['ps'] > 0).astype(np.int8)
        F[f'{lab} {bn}の山との距離(U)'] = cut((c - X['base_pk']) / U, [-1, -0.25, 0, 0.25])
        F[f'{lab} {bn}の谷との距離(U)'] = cut((c - X['base_vl']) / U, [-0.25, 0, 0.25, 1])
        if tf == 'D':
            F['週足 速K>速D'] = np.where(np.isnan(X['fk1'] - X['fd1']), -1, X['fk1'] > X['fd1']).astype(np.int8)
            F['週足 速Kの位置'] = cut(X['fk1'], [20, 50, 80]); F['月足 速K>速D'] = np.where(np.isnan(X['fk2'] - X['fd2']), -1, X['fk2'] > X['fd2']).astype(np.int8)
            hi60 = pd.Series(c).rolling(60, min_periods=20).max().values; F['直近60日高値からの下落率'] = cut((c - hi60) / hi60 * 100, [-12, -7, -3])
            r20 = (c / np.r_[np.full(20, np.nan), c[:-20]] - 1) * 100; F['20日の騰落率(%)'] = cut(r20, [-5, -2, 2, 5])
        k = np.searchsorted(X['tend'], end5, side='right') - 1
        dn = ((c < b) & (sl(b) < 0)).astype(np.int8)
        for nm, v in F.items():
            a = np.full(n5, -1, np.int8); ok = k >= 0; a[ok] = v[k[ok]]; cols.append(a); names.append(nm)
        a = np.zeros(n5, np.int8); ok = k >= 0; a[ok] = dn[k[ok]]; down.append(a)
    cols.append(np.sum(down, 0).astype(np.int8)); names.append('下向きの時間足の数(4つのうち)')
    cols.append((down[1] + down[2] + down[3]).astype(np.int8)); names.append('下向きの上位足の数(1H・4H・日足)')
    S = np.stack(cols, 1)
    np.savez_compressed(f'/home/claude/bs/g/st_{inst}.npz', S=S); pd.Series(names).to_csv('/home/claude/bs/g/st_names.csv', index=False)
    print(inst, S.shape, flush=True)

if __name__ == '__main__':
    for i in ['fut', 'cfd']: build(i)
