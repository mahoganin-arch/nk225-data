import pickle, numpy as np, pandas as pd, sys
sys.path.insert(0,'/home/claude/bs/g')
from rs3 import seq
res=pickle.load(open('emu2.pkl','rb')); DF=pd.read_csv('kdefs.csv',index_col=0); FL=['なし']+pd.read_csv('kfilters.csv').iloc[:,0].tolist()
K={7:('H1Line 山 反発0.1',1,'インジ6本そろう'),11:('H4Line 反発0.15',-1,'遅ストキャス低位'),27:('H1Line 山 抜け',1,'インジ6本そろう'),28:('H1Line 山 反発0.05',1,'15m-1H傾き'),29:('H1Line 山 反発0.15',1,'インジ6本そろう'),31:('macd 1D-1W 反発0.1',1,'H1Line傾き'),32:('H4Line 反発0.05',-1,'インジ5本以上'),34:('signal 1H-4H 反発0.25',-1,'遅ストキャス低位')}
SW={30:('60','H4Lineの向き転換',1,'EMA48がH4Lineの同じ側'),33:('15','H4Lineの向き転換',-1,'1H遅ストキャス向き')}
V3=pd.read_pickle('rs3_final.pkl')['X']
rows=[]
for inst in ['fut','cfd']:
    X=np.load(f'data_{inst}.npz'); S=np.load(f'ksig_{inst}_W.npz'); yr5=X['yr']
    for r,(t,d,f) in K.items():
        g=DF.index[(DF.trig==t)&(DF.dir==d)][0]; fi=FL.index(f); m=(S['d']==g)&(((S['f']>>(fi-1))&1)==1)&(yr5[S['i']]>=2018)
        rs=set(S['i'][m].tolist()); es=set(res[(inst,r)]['sig'][yr5[res[(inst,r)]['sig']]>=2018].tolist())
        rows.append((inst,r,len(rs),len(es),len(rs&es)))
    for r,(tf,t,d,f) in SW.items():
        Z=np.load(f'swsig_{tf}_{inst}_W.npz'); TR=pd.read_csv(f'sw_trigs_{tf}.csv').iloc[:,0].tolist(); FLs=['なし']+pd.read_csv(f'sw_filters_{tf}.csv').iloc[:,0].tolist()
        Xs=np.load(f'sw_{tf}_{inst}.npz'); end5=X['tm']+300; to5=np.clip(np.searchsorted(end5,Xs['tend'],side='left'),0,len(end5)-1)
        g=TR.index(t); fi=FLs.index(f); m=(Z['trig']==g)&((Z['d']>0)==(d==1))&(((Z['f']>>(fi-1))&1)==1)&(Z['yr']>=2018)
        rs=set(to5[Z['i'][m]].tolist()); es=set(res[(inst,r)]['sig'][yr5[res[(inst,r)]['sig']]>=2018].tolist())
        rows.append((inst,r,len(rs),len(es),len(rs&es)))
R=pd.DataFrame(rows,columns=['市場','No','研究の合図','Pineの合図','一致']); R['研究のうち一致率']=R.一致/R.研究の合図; R['Pineのうち一致率']=R.一致/R.Pineの合図
# 成績（Pine の手じまいは2026年までのデータで選んだもの＝全期間に当てはめると少し有利）
NM={7:('k:H1Line 山 反発0.1買','インジ6本そろう'),11:('k:H4Line 反発0.15売','遅ストキャス低位'),27:('k:H1Line 山 抜け買','インジ6本そろう'),28:('k:H1Line 山 反発0.05買','15m-1H傾き'),29:('k:H1Line 山 反発0.15買','インジ6本そろう'),30:('sw60:H4Lineの向き転換買','EMA48がH4Lineの同じ側'),31:('k:macd 1D-1W 反発0.1買','H1Line傾き'),32:('k:H4Line 反発0.05売','インジ5本以上'),33:('sw15:H4Lineの向き転換売','1H遅ストキャス向き'),34:('k:signal 1H-4H 反発0.25売','遅ストキャス低位')}
out=[]
for (inst,r),d in res.items():
    T=d['tr']; T=T[T.yr>=2020]; k=seq(T.i5.values,T.x5.values); T=T.iloc[k]
    y=V3[(V3.ルール==NM[r][0])&(V3.方向確認==NM[r][1])&(V3.条件=='そのまま')].iloc[0]; L='ミニ' if inst=='fut' else 'CFD'
    out.append(dict(市場=inst,No=r,Pine回数=len(T),Pine1回平均=T.v.mean(),Pine合計=T.v.sum(),Pineプラスの年=int((T.groupby('yr').v.sum()>0).sum()),研究回数=y[f'{L} 回数'],研究1回平均=y[f'{L} 1回平均'],研究合計=y[f'{L} 合計']))
O=pd.DataFrame(out); M=R.merge(O,on=['市場','No']); pd.set_option('display.width',250); print(M.round(2).to_string()); M.to_pickle('emu2_cmp.pkl')
