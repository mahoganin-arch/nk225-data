import sys, numpy as np, pandas as pd
sys.path.insert(0,'/home/claude/bs/g')
from cond import feats
from ss_cand import seq_idx
from cal import bar_feats
R5='zt:H4Line 裏タッチ 近さ0.15A（割れて4時間以内）売'; R6='zt:H4Line 割れて終値2本下に居続けた売'
T=pd.read_pickle('tr_zt.pkl'); T['rule']=T.rule.astype(str); T=T[T.rule.isin([R5,R6,'rand:zt:売'])&(T.yr>=2018)].reset_index(drop=True)
F,names=feats(T); FF={i:bar_feats(i)[2] for i in ['fut','cfd']}
cal=np.array([FF[i]['SQ週（その他の月）'][j]=='はい' for i,j in zip(T.inst.values,T.i5.values)])
FILT={'なし':np.ones(len(T),bool)}
for nm in ['日足 週の線が月の線の上','日足 週の線の傾き上','日足 月の線の傾き上','週足 速K>速D','日足 遅K>遅D','4H 週の線の傾き上','1H 速K>速D']:
    FILT[nm+'（上げ）']=F[:,names.index(nm)]==1
FILT['SQ週（その他）を除く']=~cal
FILT['日足 週の線が月の線の上＋SQ週を除く']=FILT['日足 週の線が月の線の上（上げ）']&~cal
rows=[]
for rule in [R5,R6,'rand:zt:売']:
    for fn,fm in FILT.items():
        row=dict(対象=rule.split(':',1)[1],条件=fn)
        for inst,L in [('fut','ミニ'),('cfd','CFD')]:
            m=(T.rule==rule)&(T.inst==inst)&fm; g=T[m]
            if not rule.startswith('rand'): g=g.iloc[seq_idx(g.i5.values,g.x5.values)]
            v=g.v.values.astype(float); yr=g.yr.values
            for lab,s in [('2018〜21',yr<=2021),('2022〜26',yr>=2022)]:
                row[f'{L} {lab} 回数']=int(s.sum()); row[f'{L} {lab} 1回平均']=v[s].mean(); row[f'{L} {lab} 合計']=v[s].sum()
            ys=pd.Series(v[yr>=2022]).groupby(yr[yr>=2022]).sum(); row[f'{L} 2022〜26 プラスの年']=f'{int((ys>0).sum())}/5'
        rows.append(row)
R=pd.DataFrame(rows); R.to_pickle('ss_h4b.pkl')
pd.set_option('display.width',330); print(R.round(0).to_string())
