"""3分足検証の本当の前向き。確かめる年 t（2022〜2026）ごとに、t より前の年（ミニ・CFD）だけで選び、t 年の成績を見る。
選び方：A＝損益（そろえた）の最小で選ぶ、B＝ランダムとの差の最小で選ぶ。上位5本（トリガー×向きは重ねない）と、選んだ条件を満たす全部の平均。
出力：m3nest.pkl
"""
import os, sys, numpy as np, pandas as pd
P = os.environ.get('PFX', 'm3')
sys.path.insert(0, '/home/claude/bs/g')
from m3_agg import YRS
INST = ['fut', 'cfd']; FAMS = ['W', 'r0', 'r1', 'r2', 'r3', 'r4']

def yarr(inst, fam):
    Z = dict(np.load(f'/home/claude/bs/g/{P}agg_{inst}_{fam}.npz'))
    c = Z['cnt'][..., 2:]; s = Z['sum'][..., 2:]; cR = Z['cntR'][..., 2:]; sR = Z['sumR'][..., 2:]
    return c, s, cR, sR

def run():
    res = []
    for fam in FAMS:
        Y = {i: yarr(i, fam) for i in INST}
        for t in range(YRS[0] + 2, 2027):
            ty = t - YRS[0]
            sc = {}
            for i in INST:
                c, s, cR, sR = Y[i]; ntr = c[..., :ty].sum(-1)  # fset,td
                a = s[1][..., :ty].sum(-1) / np.maximum(ntr[:, None, :], 1)  # fset,exit,td
                td = np.arange(c.shape[1]) % 2
                aR = (sR[1][..., :ty].sum(-1) / np.maximum(cR[..., :ty].sum(-1)[:, None, :], 1))[:, :, td]
                ok = np.broadcast_to((ntr >= 30)[:, None, :], a.shape)
                sc[i] = (a, a - aR, ok)
            for g, k in [('損益で選ぶ', 0), ('ランダムとの差で選ぶ', 1)]:
                okc = sc['cfd'][2]
                vf = np.where(sc['fut'][2], sc['fut'][k], np.inf)
                score = np.where(okc, np.minimum(sc['cfd'][k], vf), -np.inf)
                flat = np.argsort(-score, axis=None)
                F, E, T = np.unravel_index(flat, score.shape)
                pick = []; used = set()
                for f, e, tt in zip(F, E, T):
                    if not np.isfinite(score[f, e, tt]) or score[f, e, tt] <= 0: break
                    if tt in used: continue
                    used.add(tt); pick.append((f, e, tt))
                    if len(pick) == 5: break
                pos = score > 0
                for i in INST:
                    c, s, cR, sR = Y[i]
                    n_t = np.broadcast_to(c[:, None, :, ty], score.shape); p_t = s[1][..., ty]; q_t = s[2][..., ty]
                    r = dict(fam=fam, t=t, grp=g, inst=i, 候補数=int(pos.sum()))
                    m = pos & (n_t > 0)
                    r['全部の平均'] = p_t[m].sum() / max(n_t[m].sum(), 1)
                    r['全部の平均13円'] = q_t[m].sum() / max(n_t[m].sum(), 1)
                    sel5 = pos & (n_t >= 5)
                    r['順位相関'] = pd.Series(score[sel5]).rank().corr(pd.Series(p_t[sel5] / n_t[sel5]).rank()) if sel5.sum() > 20 else np.nan
                    r['上位5 合計'] = sum(p_t[x] for x in pick); r['上位5 合計13円'] = sum(q_t[x] for x in pick); r['上位5 件数'] = sum(n_t[x] for x in pick)
                    r['上位5'] = ' / '.join(f'{f}-{e}-{tt}' for f, e, tt in pick)
                    res.append(r)
        print(fam, flush=True)
    pd.DataFrame(res).to_pickle(f'/home/claude/bs/g/{P}nest.pkl')

if __name__ == '__main__':
    run()
