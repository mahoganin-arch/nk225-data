"""形（トリガー × 方向確認）ごとに、手じまい36通りを平均した1回平均（そろえた円）を、前半・後半で出し、
ランダムな時刻に入る相手（同じ向き・同じ方向確認・同じ手じまい）との差を見る。でたらめな線（r0〜r5）とも比べる（線を使うトリガー）。"""
import sys, numpy as np, pandas as pd
YEARS=list(range(2018,2027)); H={'前半':list(range(2018,2023)),'後半':list(range(2023,2027))}
def form(inst,fam,col='nrm'):
    cols=['def','exit','fset']+[f'{c}{y}' for c in ['n',col] for y in YEARS]
    A=pd.read_parquet(f'/home/claude/bs/g/kagg_{inst}_{fam}.parquet',columns=cols)
    for h,ys in H.items():
        A[f'a_{h}']=A[[f'{col}{y}' for y in ys]].sum(1)/A[[f'n{y}' for y in ys]].sum(1).replace(0,np.nan)
        A[f'n_{h}']=A[[f'n{y}' for y in ys]].sum(1)
    g=A.groupby(['def','fset'])
    F=g[['a_前半','a_後半']].mean(); F['n_前半']=g['n_前半'].max(); F['n_後半']=g['n_後半'].max(); F['nexit']=g.size()
    return F.reset_index()
def rand_form(inst,col='nrm'):
    R=pd.read_parquet(f'/home/claude/bs/g/kragg_{inst}.parquet'); R=R[R.col==col]
    for h,ys in H.items(): R[f'r_{h}']=R[[f's{y}' for y in ys]].sum(1)/R[[f'n{y}' for y in ys]].sum(1).replace(0,np.nan)
    return R.groupby(['dir','fset'])[['r_前半','r_後半']].mean().reset_index()
if __name__=='__main__':
    DF=pd.read_csv('/home/claude/bs/g/kdefs.csv',index_col=0); FS=pd.read_csv('/home/claude/bs/g/kfsets.csv')
    out=[]
    for inst in ['fut','cfd']:
        F=form(inst,'W'); F['dir']=DF.dir.values[F['def']]
        F=F.merge(rand_form(inst),on=['dir','fset'],how='left'); F['inst']=inst
        out.append(F)
    O=pd.concat(out)
    for h in H: O[f'差_{h}']=O[f'a_{h}']-O[f'r_{h}']
    P=O.pivot_table(index=['def','fset'],columns='inst',values=['差_前半','差_後半','a_前半','a_後半','n_前半','n_後半'])
    P.columns=[f'{a}_{b}' for a,b in P.columns]; P=P.dropna(subset=['差_前半_fut','差_後半_fut','差_前半_cfd','差_後半_cfd']).reset_index()
    P['差の最小']=P[['差_前半_fut','差_後半_fut','差_前半_cfd','差_後半_cfd']].min(axis=1)
    P['件数最小']=P[['n_前半_fut','n_後半_fut','n_前半_cfd','n_後半_cfd']].min(axis=1)
    P=P.merge(DF[['trig','grp','dir']],left_on='def',right_index=True).merge(FS[['fset','name','k']],on='fset')
    P.to_pickle('/home/claude/bs/g/kform.pkl')
    pd.set_option('display.width',250)
    Q=P[P['件数最小']>=30].sort_values('差の最小',ascending=False)
    print(Q[['trig','dir','name','差の最小','差_前半_fut','差_後半_fut','差_前半_cfd','差_後半_cfd','a_後半_fut','a_後半_cfd','件数最小']].head(30).round(1).to_string())
    print('全体：4つともプラスの割合',(P[P['件数最小']>=30]['差の最小']>0).mean().round(3), '形の数',(P['件数最小']>=30).sum())
