"""手じまいを広げた検証（約75ルール × 損切り3 ＝ 225通り）。15分足の候補（k_cands の11形）とランダムな入り。
入る：候補の合図の足の終値（k_sig と同じ）。データ：5分足 2018〜2026-10-08。
出力：xlib_{inst}.npz（R 損益pt, XI 出た足, MFE/MAE）, xlib_rules.csv
"""
import sys, numpy as np, pandas as pd
from numba import njit
sys.path.insert(0, '/home/claude/bs/g')
from k_cands import CANDS
from k_agg import MASKS
from k_rules import fs
DF = pd.read_csv('/home/claude/bs/g/kdefs.csv', index_col=0)
LN = pd.read_csv('/home/claude/bs/g/k_lnames.csv').iloc[:, 0].tolist()
IN = pd.read_csv('/home/claude/bs/g/k_inames.csv').iloc[:, 0].tolist()
CAPN = ['セッション終わり', '日の終わり', '週の終わり']
EVN = ['速ストキャス逆クロス', '遅ストキャス逆クロス', 'PSAR反転', 'インジ5本逆', '15m-1H逆クロス', 'H1Lineの向き転換', 'H4Lineの向き転換',
       '終値がH1Lineを逆に抜け', '終値がH4Lineを逆に抜け', '終値がD1Lineを逆に抜け', '速Kが80(20)を出る']

def rules():
    R = []  # (名前, typ, p1, p2, p3, cap)
    for n, cp in [(6, 0), (12, 0), (24, 0), (48, 0), (48, 2), (96, 2), (288, 2), (576, 2)]:
        R.append((f'{n * 5}分で手じまい（上限 {CAPN[cp]}）', 0, n, 0, 0, cp))
    for cp in range(3): R.append((CAPN[cp], 1, 0, 0, 0, cp))
    for y in (20, 30, 50, 80, 120, 200): R.append((f'利確{y}円（{CAPN[0]}まで）', 2, y, 0, 0, 0))
    for y in (50, 120, 200): R.append((f'利確{y}円（{CAPN[2]}まで）', 2, y, 0, 0, 2))
    for a in (.1, .15, .25, .35, .5, .75, 1.0): R.append((f'利確{a}A（{CAPN[0]}まで）', 3, a, 0, 0, 0))
    for a in (.5, 1.0): R.append((f'利確{a}A（{CAPN[2]}まで）', 3, a, 0, 0, 2))
    for a in (.1, .15, .25, .35, .5): R.append((f'トレール{a}A（{CAPN[0]}まで）', 4, a, 0, 0, 0))
    for a in (.25, .5): R.append((f'トレール{a}A（{CAPN[2]}まで）', 4, a, 0, 0, 2))
    R.append(('+0.1Aで建値に損切りを上げる（セッション終わりまで）', 5, .1, 0, 0, 0))
    R.append(('+0.2Aで建値に損切りを上げる（セッション終わりまで）', 5, .2, 0, 0, 0))
    R.append(('+0.2Aで建値・利確0.5A', 5, .2, .5, 0, 0))
    R.append(('半分利確0.25A・残りセッション終わり', 6, .25, 0, 0, 0))
    R.append(('半分利確0.25A・残りトレール0.25A', 6, .25, 1, .25, 0))
    R.append(('半分を次の線で利確・残りセッション終わり', 6, -1, 0, 0, 0))
    R.append(('半分を次の線で利確・残り週の終わり', 6, -1, 0, 0, 2))
    R.append(('半分利確0.5A・残りトレール0.25A（週まで）', 6, .5, 1, .25, 2))
    R.append(('1時間後にマイナスなら切る（セッション終わりまで）', 7, 12, 0, 0, 0))
    R.append(('2時間後にマイナスなら切る（セッション終わりまで）', 7, 24, 0, 0, 0))
    R.append(('最大利益0.25A後、半分戻したら出る（セッションまで）', 8, .25, .5, 0, 0))
    R.append(('最大利益0.5A後、半分戻したら出る（週まで）', 8, .5, .5, 0, 2))
    R.append(('次の線で利確（セッションまで）', 9, 1, 0, 0, 0))
    R.append(('次の線で利確（週まで）', 9, 1, 0, 0, 2))
    R.append(('2本目の線で利確（週まで）', 9, 2, 0, 0, 2))
    for k, nm in enumerate(EVN):
        for cp in (0, 2): R.append((f'{nm}（{CAPN[cp]}まで）', 10, k, 0, 0, cp))
    R.append(('直近1時間の安値(高値)で損切り（セッションまで）', 11, 12, 0, 0, 0))
    R.append(('直近2時間の安値(高値)で損切り（週まで）', 11, 24, 0, 0, 2))
    return R

SLN = ['損切りなし', '損切り 線の0.25A先', '損切り 入値から0.5A']

@njit(cache=True)
def simall(SI, D, E, A, LR, TP1, TP2, o, h, l, c, ends, NX, typ, p1, p2, p3, cap, out, xo, mfe, mae):
    n = len(SI); nr = len(typ)
    for q in range(n):
        i = SI[q]; d = D[q]; e = E[q]; a = A[q]; jW = ends[2, i]
        # MFE/MAE（セッション・週）
        hw = e; lw = e
        for j in range(i + 1, jW + 1):
            if d == 1:
                hw = max(hw, h[j]); lw = min(lw, l[j])
            else:
                hw = min(hw, l[j]); lw = max(lw, h[j])
            if j == ends[0, i]:
                mfe[q, 0] = (hw - e) * d / a; mae[q, 0] = (e - lw) * d / a
        mfe[q, 1] = (hw - e) * d / a; mae[q, 1] = (e - lw) * d / a
        sw12 = l[max(i - 11, 0):i + 1].min() if d == 1 else h[max(i - 11, 0):i + 1].max()
        sw24 = l[max(i - 23, 0):i + 1].min() if d == 1 else h[max(i - 23, 0):i + 1].max()
        for r in range(nr):
            end = ends[cap[r], i]; t = typ[r]
            for s in range(3):
                slp = np.nan
                if s == 1: slp = LR[q] - d * 0.25 * a
                elif s == 2: slp = e - d * 0.5 * a
                tgt = -1
                if t == 0: tgt = min(i + int(p1[r]), end)
                elif t == 1: tgt = end
                elif t == 7: tgt = min(i + int(p1[r]), end)
                elif t == 10: tgt = min(NX[int(p1[r]), i], end)
                tp = np.nan
                if t == 2: tp = e + d * p1[r]
                elif t == 3: tp = e + d * p1[r] * a
                elif t == 9: tp = TP1[q] if p1[r] == 1 else TP2[q]
                elif t == 5 and p2[r] > 0: tp = e + d * p2[r] * a
                dyn = np.nan
                if t == 11:
                    dyn = (sw12 if p1[r] == 12 else sw24) - d * 0.05 * a
                    if (dyn - e) * d >= 0: dyn = e - d * 0.05 * a
                # 半分利確
                half = t == 6; tp_h = np.nan; got_h = False; res_h = 0.0
                if half: tp_h = (TP1[q] if p1[r] < 0 else e + d * p1[r] * a)
                best = e; be_on = False; pnl = 0.0; xi = end; done = False
                for j in range(i + 1, end + 1):
                    # 動く損切り（前の足までの値で決める）
                    stp = slp
                    if t == 4 or (half and p2[r] == 1 and got_h):
                        w = p1[r] if t == 4 else p3[r]
                        ts = best - d * w * a
                        if np.isnan(stp) or (ts - stp) * d > 0: stp = ts
                    if t == 5 and be_on:
                        if np.isnan(stp) or (e - stp) * d > 0: stp = e
                    if t == 11:
                        if np.isnan(stp) or (dyn - stp) * d > 0: stp = dyn
                    if t == 8 and (best - e) * d >= p1[r] * a:
                        gb = e + (best - e) * (1 - p2[r])
                        if np.isnan(stp) or (gb - stp) * d > 0: stp = gb
                    if not np.isnan(stp) and ((d == 1 and l[j] <= stp) or (d == -1 and h[j] >= stp)):
                        px = min(o[j], stp) if d == 1 else max(o[j], stp)
                        pnl = (px - e) * d; xi = j; done = True; break
                    # 半分利確
                    if half and not got_h and not np.isnan(tp_h) and ((d == 1 and h[j] >= tp_h) or (d == -1 and l[j] <= tp_h)):
                        px = max(o[j], tp_h) if d == 1 else min(o[j], tp_h)
                        got_h = True; res_h = (px - e) * d
                    # 利確
                    if not np.isnan(tp) and ((d == 1 and h[j] >= tp) or (d == -1 and l[j] <= tp)):
                        px = max(o[j], tp) if d == 1 else min(o[j], tp)
                        pnl = (px - e) * d; xi = j; done = True; break
                    if d == 1: best = max(best, h[j])
                    else: best = min(best, l[j])
                    if t == 5 and (best - e) * d >= p1[r] * a: be_on = True
                    if j == tgt:
                        if t == 7 and (c[j] - e) * d >= 0:
                            tgt = end
                            if j == end:
                                pnl = (c[j] - e) * d; xi = j; done = True; break
                            continue
                        pnl = (c[j] - e) * d; xi = j; done = True; break
                    if j == end:
                        pnl = (c[j] - e) * d; xi = j; done = True; break
                if not done:
                    pnl = (c[end] - e) * d; xi = end
                if half:
                    pnl = 0.5 * (res_h if got_h else pnl) + 0.5 * pnl
                out[q, r * 3 + s] = pnl; xo[q, r * 3 + s] = xi

def nxt(ev):
    n = len(ev); idx = np.nonzero(ev)[0]; k = np.searchsorted(idx, np.arange(n), side='right')
    out = np.full(n, n - 1, np.int64); ok = k < len(idx); out[ok] = idx[k[ok]]; return out

def run(inst):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); K = dict(np.load(f'/home/claude/bs/g/kind_{inst}_W.npz'))
    S = dict(np.load(f'/home/claude/bs/g/ksig_{inst}_W.npz'))
    o, h, l, c = [X[k].astype(float) for k in 'ohlc']; n = len(c); LM = K['L'].astype(float); I = K['I'].astype(float); is15 = K['is15']
    ends = np.stack([X['end_ses'], X['end_day'], X['end_wk']]).astype(np.int64) if X['end_ses'].max() < n else None
    # end_* が期間番号なら足の位置に直す
    def endpos(pid):
        last = np.r_[pid[1:] != pid[:-1], True]; idx = np.nonzero(last)[0]; return idx[np.searchsorted(idx, np.arange(n))]
    ends = np.stack([endpos(X['pid_ses']), endpos(X['pid_day']), endpos(X['pid_wk'])]).astype(np.int64)
    col = {nm: j for j, nm in enumerate(IN)}
    def cross_dn(a, b):
        s = np.sign(np.nan_to_num(a - b)); p = np.r_[0, s[:-1]]; return (s < 0) & (p >= 0), (s > 0) & (p <= 0)
    ev = {1: [], -1: []}
    for k, (x1, x2) in enumerate([(I[:, col['速K']], I[:, col['速D']]), (I[:, col['遅K']], I[:, col['遅D']])]):
        dn, up = cross_dn(x1, x2); ev[1].append(dn); ev[-1].append(up)
    ps = I[:, col['PSAR']]; pp = np.r_[0, ps[:-1]]; ev[1].append((ps < 0) & (pp >= 0)); ev[-1].append((ps > 0) & (pp <= 0))
    ind = np.stack([I[:, col[f'Indi0{m}向き']] for m in range(2, 7)], 1)
    alldn = (ind < 0).all(1); allup = (ind > 0).all(1)
    ev[1].append(alldn & ~np.r_[False, alldn[:-1]]); ev[-1].append(allup & ~np.r_[False, allup[:-1]])
    dn, up = cross_dn(LM[:, LN.index('macd 15m-1H')], LM[:, LN.index('signal 15m-1H')]); ev[1].append(dn); ev[-1].append(up)
    for nm in ('H1Line 傾き', 'H4Line 傾き'):
        s = I[:, col[nm]]; p = np.r_[0, s[:-1]]; ev[1].append((s < 0) & (p >= 0)); ev[-1].append((s > 0) & (p <= 0))
    for nm in ('H1Line', 'H4Line', 'D1Line'):
        Lv = LM[:, LN.index(nm)]; st = np.where(is15, np.sign(np.nan_to_num(c - Lv)), np.nan); st = pd.Series(st).ffill().fillna(0).values
        p = np.r_[0, st[:-1]]; ev[1].append(is15 & (st < 0) & (p >= 0)); ev[-1].append(is15 & (st > 0) & (p <= 0))
    fk = I[:, col['速K']]; pk = np.r_[np.nan, fk[:-1]]; ev[1].append((pk >= 80) & (fk < 80)); ev[-1].append((pk <= 20) & (fk > 20))
    NX = {d: np.stack([nxt(np.nan_to_num(v).astype(bool)) for v in ev[d]]) for d in (1, -1)}
    # 入り：候補とランダム
    E_si, E_d, E_c, E_lr = [], [], [], []
    for ci, (nm, trig, dr, fl) in enumerate(CANDS):
        di = DF.index[(DF.trig == trig) & (DF.dir == dr)][0]; msk = MASKS[fs(*fl)] if fl else 0; r = DF.loc[di]
        m = (S['d'] == di) & ((S['f'].astype(np.int64) & msk) == msk); si = S['i'][m]
        lr = LM[si, int(r.a)] if (r.a >= 0 and r.grp == '線') else c[si]
        E_si.append(si); E_d.append(np.full(len(si), dr)); E_c.append(np.full(len(si), ci)); E_lr.append(lr)
    rng = np.random.default_rng(11 + (inst == 'cfd'))
    ok = np.nonzero(is15 & (X['yr'] >= 2018) & (np.arange(n) < ends[0]) & ~np.isnan(X['avg20']))[0]
    for dr in (1, -1):
        si = np.sort(rng.choice(ok, 15000, replace=False)); E_si.append(si); E_d.append(np.full(len(si), dr)); E_c.append(np.full(len(si), -1 if dr == 1 else -2)); E_lr.append(c[si])
    SI = np.concatenate(E_si).astype(np.int64); D = np.concatenate(E_d).astype(np.int64); CI = np.concatenate(E_c); LR = np.concatenate(E_lr).astype(float)
    E = c[SI]; A = X['avg20'][SI].astype(float)
    M = LM[SI]; dist = (M - E[:, None]) * D[:, None]; dd = np.where(dist > 0.05 * A[:, None], dist, np.inf); dd.sort(1)
    TP1 = np.where(np.isfinite(dd[:, 0]), E + D * dd[:, 0], np.nan); TP2 = np.where(np.isfinite(dd[:, 1]), E + D * dd[:, 1], np.nan)
    RL = rules(); typ = np.array([r[1] for r in RL], np.int64); p1 = np.array([r[2] for r in RL], float); p2 = np.array([r[3] for r in RL], float); p3 = np.array([r[4] for r in RL], float); cap = np.array([r[5] for r in RL], np.int64)
    out = np.zeros((len(SI), len(RL) * 3)); xo = np.zeros((len(SI), len(RL) * 3), np.int64); mfe = np.zeros((len(SI), 2)); mae = np.zeros((len(SI), 2))
    for dr in (1, -1):
        m = D == dr; idx = np.nonzero(m)[0]
        o_ = np.zeros((m.sum(), out.shape[1])); x_ = np.zeros_like(o_, dtype=np.int64); mf = np.zeros((m.sum(), 2)); ma = np.zeros((m.sum(), 2))
        simall(SI[m], D[m], E[m], A[m], LR[m], TP1[m], TP2[m], o, h, l, c, ends, NX[dr], typ, p1, p2, p3, cap, o_, x_, mf, ma)
        out[idx] = o_; xo[idx] = x_; mfe[idx] = mf; mae[idx] = ma
    nt = (X['pid_day'][xo] - X['pid_day'][SI][:, None]).astype(np.int16)
    np.savez_compressed(f'/home/claude/bs/g/xlib_{inst}.npz', SI=SI, D=D, CI=CI, E=E, A=A, R=out.astype(np.float32), nt=nt, H=(xo - SI[:, None]).astype(np.int32), mfe=mfe, mae=mae, yr=X['yr'][SI])
    pd.DataFrame([(f'{r[0]}・{s}', r[0], s) for r in RL for s in SLN], columns=['手じまい', 'ルール', '損切り']).to_csv('/home/claude/bs/g/xlib_rules.csv', index=False)
    print(inst, len(SI), out.shape, flush=True)

if __name__ == '__main__':
    for i in sys.argv[1].split(','): run(i)
