"""ポジションは1つだけ（持っている間の合図は見送る）で、前向きに選んだ手じまい（年ごと）を使った成績。
ランダムな入りも同じ手順（同じ件数くらいを無作為に選び、1つずつ）で比べる。最大ドローダウンも出す。
出力：nov.pkl
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from x_core import ctx5, simulate, money
REF = 68800.0; COST = {'fut': 5.0, 'cfd': 7.0}
D = pd.read_pickle('/home/claude/bs/g/cand_fwd.pkl')['det']; D = D[~D.方向確認も選ぶ]
SW = [('sw_240', 'EMA72反発(0.05U)買'), ('sw_240', 'EMA72反発(0.15U)買'), ('sw_240', 'D1Lineの山の値で反発(0.1U)買'), ('sw_60', 'EMA12×EMA48買'), ('sw_60', 'H4Lineの向き転換買'),
      ('sw_60', 'EMA12×signal(陽転・陰転)買'), ('sw_60', 'D1Lineの山の値で反発(0.1U)買'), ('sw_60', 'EMA48×H4Line買'), ('sw_15', '1H・4H 同じ位置でクロス買'), ('sw_15', '終値×H1Line買'), ('sw_D', 'PSAR反転買')]
KK = ['H1Line 谷 反発0.05買', 'H1Line×macd 15m-1H 下逆買', 'macd 1H-4H×signal 1H-4H 上順買', 'H1Line 山 反発0.1買', 'H1Line 谷 反発0.1買', 'PSAR 買い買', 'macd 15m-1H×signal 15m-1H 上順買']

def seq(i, xi, v, yr):
    o = np.argsort(i, kind='stable'); last = -1; take = []
    for q in o:
        if i[q] > last: take.append(q); last = xi[q]
    take = np.array(take, int); return take

def stats(v, yr, lab):
    cs = np.cumsum(v); dd = (np.maximum.accumulate(cs) - cs).max() if len(v) else np.nan
    return dict(件数=len(v), 一回平均=v.mean() if len(v) else np.nan, 合計=v.sum(), 最大DD=dd, 勝率=(v > 0).mean() if len(v) else np.nan,
                プラスの年=f"{sum(v[yr == y].sum() > 0 for y in np.unique(yr))}/{len(np.unique(yr))}", **{str(y): v[yr == y].sum() for y in range(2020, 2027)})

def run():
    rows = []; rng = np.random.default_rng(5)
    for study, trig in SW:
        tf = study[3:]; EX = pd.read_csv(f'/home/claude/bs/g/sw_exits_{tf}.csv').手じまい.tolist(); TR = pd.read_csv(f'/home/claude/bs/g/sw_trigs_{tf}.csv').iloc[:, 0].tolist()
        t0 = TR.index(trig[:-1]); dr = 1 if trig.endswith('買') else -1
        for inst in ['fut', 'cfd']:
            S = dict(np.load(f'/home/claude/bs/g/swsig_{tf}_{inst}_W.npz')); Q = dict(np.load(f'/home/claude/bs/g/swrand_{tf}_{inst}_W.npz'))
            dd = D[(D.調べ == study) & (D.トリガー == trig) & (D.商品 == inst)].set_index('年').手じまい
            for lab, A in [('合図', S), ('ランダム', Q)]:
                m = (A['trig'] == t0) & (A['d'] == dr) if lab == '合図' else (A['d'] == dr)
                m &= np.isin(A['yr'], dd.index.values)
                idx = np.nonzero(m)[0]
                if lab == 'ランダム':  # 合図と同じくらいの件数に間引く
                    k = ((S['trig'] == t0) & (S['d'] == dr) & np.isin(S['yr'], dd.index.values)).sum(); idx = np.sort(rng.choice(idx, min(len(idx), k), replace=False))
                ecol = np.array([EX.index(dd[y]) for y in A['yr'][idx]])
                R = A['R'][idx, ecol].astype(float); nt = A['nt'][idx, ecol]; hb = A['hb'][idx, ecol]; e = A['e'][idx]
                v = R * REF / e - COST[inst] - (nt * 0.03 / 365 * REF if inst == 'cfd' else 0)
                i = A['i'][idx]; tk = seq(i, i + hb, v, A['yr'][idx])
                for mode, sel in [('全部（重ねて持つ）', np.arange(len(idx))), ('1つずつ', tk)]:
                    rows.append(dict(調べ=study, トリガー=trig, 商品={'fut': 'ミニ', 'cfd': 'CFD'}[inst], 入り=lab, 持ち方=mode, 平均保有本数=hb[sel].mean(), **stats(v[sel], A['yr'][idx][sel], lab)))
    # 15分足の網羅（k）：トレードをもう一度計算
    DF = pd.read_csv('/home/claude/bs/g/kdefs.csv', index_col=0); RLc = pd.read_csv('/home/claude/bs/g/xlib_rules.csv').手じまい.tolist()
    for inst in ['fut', 'cfd']:
        C = ctx5(inst, 'W'); S = dict(np.load(f'/home/claude/bs/g/ksig_{inst}_W.npz'))
        ok = np.nonzero(C['is15'] & (C['yr'] >= 2020) & (np.arange(len(C['c'])) < C['ends'][0]) & ~np.isnan(C['A']))[0]
        for trig in KK:
            di = DF.index[(DF.trig == trig[:-1]) & (DF.dir == 1)][0]; r = DF.loc[di]
            dd = D[(D.調べ == 'k') & (D.トリガー == trig) & (D.商品 == inst)].set_index('年').手じまい
            m = (S['d'] == di) & np.isin(C['yr'][S['i']], dd.index.values); si = S['i'][m].astype(np.int64)
            LR = C['LM'][si, int(r.a)] if (r.grp == '線' and r.a >= 0) else C['c'][si]
            ri = np.sort(rng.choice(ok, len(si), replace=False))
            for lab, ii, lr in [('合図', si, LR), ('ランダム', ri, C['c'][ri])]:
                Rr, NT, HB = simulate(C, ii, np.ones(len(ii), np.int64), lr); nrm, _ = money(inst, Rr, C['c'][ii], NT)
                yr = C['yr'][ii]; ecol = np.array([RLc.index(dd[y]) for y in yr])
                v = nrm[np.arange(len(ii)), ecol].astype(float); hb = HB[np.arange(len(ii)), ecol]; tk = seq(ii, ii + hb, v, yr)
                for mode, sel in [('全部（重ねて持つ）', np.arange(len(ii))), ('1つずつ', tk)]:
                    rows.append(dict(調べ='k(15分足の網羅)', トリガー=trig, 商品={'fut': 'ミニ', 'cfd': 'CFD'}[inst], 入り=lab, 持ち方=mode, 平均保有本数=hb[sel].mean() / 3, **stats(v[sel], yr[sel], lab)))
    O = pd.DataFrame(rows); O.to_pickle('/home/claude/bs/g/nov.pkl')
    pd.set_option('display.width', 300); pd.set_option('display.max_rows', 300)
    print(O[O.持ち方 == '1つずつ'][['調べ', 'トリガー', '商品', '入り', '件数', '一回平均', '合計', '最大DD', '勝率', 'プラスの年', '平均保有本数']].round(1).to_string())

if __name__ == '__main__':
    run()
