"""全ルールの成績表の材料。ルール＝（調べ, トリガー, 向き, 方向確認なし or 1つ）。
手じまいは年ごとに「前の年までの成績（両商品の小さいほう）」で選ぶ（前向き）。2020〜2026 を前向きで記録。
ポジションは1つだけ（持っている間の合図は見送る）。損益は手じまった日に記録（日ごとの損益）。
ランダムな入り：上位足は同じ方向確認つき、15分足の網羅は方向確認なし。
出力：rl_{study}_{inst}.npz（日ごとの損益 daily[rule, day]、年ごとの件数・合計、全部重ねたときの平均）, rl_rules_{study}.csv
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
REF = 68800.0; COST = {'fut': 5.0, 'cfd': 7.0}
DAY0 = pd.Timestamp('2018-01-01'); NDAY = (pd.Timestamp('2026-10-10') - DAY0).days + 1
YRS = list(range(2020, 2027))

def choose(Zs, g, f, nmin=20, rnd=None):
    """年ごとに選ぶ手じまい（なければ -1）"""
    out = {}
    for t in YRS:
        ty = t - 2018 + 2; sc = None
        for inst, Z in Zs.items():
            if rnd is None:
                c = Z['cnt'][g, f, 2:ty].sum(); s = Z['nrm'][g, f, 2:ty, :].sum(0)
            else:
                c = Z['cntR'][rnd, 2:ty].sum(); s = Z['nrmR'][rnd, 2:ty, :].sum(0)
            if c < nmin: continue
            a = s / c; sc = a if sc is None else np.minimum(sc, a)
        out[t] = -1 if sc is None else int(np.argmax(sc))
    return out

def seq(i, xi):
    o = np.argsort(i, kind='stable'); last = -1; take = []
    for q in o:
        if i[q] > last: take.append(q); last = xi[q]
    return np.array(take, int)

def record(v, yr, xday, i, xi):
    """1つずつ持ったときの日ごとの損益と年ごとの件数・合計、全部重ねたときの合計・件数"""
    d = np.zeros(NDAY, np.float32); cy = np.zeros(len(YRS)); sy = np.zeros(len(YRS)); ay = np.zeros(len(YRS)); ny = np.zeros(len(YRS))
    for k, t in enumerate(YRS):
        m = yr == t; ay[k] = v[m].sum(); ny[k] = m.sum()
    tk = seq(i, xi)
    np.add.at(d, xday[tk], v[tk])
    for k, t in enumerate(YRS):
        m = yr[tk] == t; cy[k] = m.sum(); sy[k] = v[tk][m].sum()
    return d, cy, sy, ay, ny

def daynum(utc_s):
    t = pd.to_datetime(utc_s, unit='s', utc=True).tz_convert('Asia/Tokyo').tz_localize(None).normalize()
    return np.clip(((t - DAY0).days).values, 0, NDAY - 1)

def build_sw(tf):
    import sw_agg
    Zs = {i: sw_agg.agg(tf, i, 'W') for i in ['fut', 'cfd']}
    TR = pd.read_csv(f'/home/claude/bs/g/sw_trigs_{tf}.csv').iloc[:, 0].tolist(); FL = ['なし'] + pd.read_csv(f'/home/claude/bs/g/sw_filters_{tf}.csv').iloc[:, 0].tolist()
    EX = pd.read_csv(f'/home/claude/bs/g/sw_exits_{tf}.csv').手じまい.tolist(); NF = 16
    rules = []
    for g in range(len(TR) * 2):
        for f in range(NF):
            n = Zs['fut']['cnt'][g, f, 2:].sum() + Zs['cfd']['cnt'][g, f, 2:].sum()
            if n < 60: continue
            rules.append((g, f))
    ch = [choose(Zs, g, f) for g, f in rules]
    for inst in ['fut', 'cfd']:
        X = dict(np.load(f'/home/claude/bs/g/sw_{tf}_{inst}.npz')); S = dict(np.load(f'/home/claude/bs/g/swsig_{tf}_{inst}_W.npz')); Q = dict(np.load(f'/home/claude/bs/g/swrand_{tf}_{inst}_W.npz'))
        tend = X['tend']; out = {k: [] for k in ['daily', 'cy', 'sy', 'ay', 'ny', 'ry', 'rn']}
        gS = S['trig'].astype(np.int64) * 2 + (S['d'] > 0)
        rc = {(dr, f): choose(Zs, None, f, rnd=dr) for dr in (0, 1) for f in [0]}
        for (g, f), cc in zip(rules, ch):
            m = (gS == g) & (S['yr'] >= 2020)
            if f > 0: m &= ((S['f'] >> (f - 1)) & 1).astype(bool)
            idx = np.nonzero(m)[0]; yr = S['yr'][idx]; e = np.array([cc[y] for y in yr]); ok = e >= 0; idx, yr, e = idx[ok], yr[ok], e[ok]
            R = S['R'][idx, e].astype(float); nt = S['nt'][idx, e]; hb = S['hb'][idx, e]
            v = R * REF / S['e'][idx] - COST[inst] - (nt * 0.03 / 365 * REF if inst == 'cfd' else 0)
            i = S['i'][idx]; xi = np.minimum(i + hb, len(tend) - 1)
            d, cy, sy, ay, ny = record(v, yr, daynum(tend[xi]), i, xi)
            # ランダム（同じ向き・同じ方向確認、手じまいはランダム自身の前向きで選ぶ）
            dr = g % 2; mr = (Q['d'] > 0) == (dr == 1); mr &= Q['yr'] >= 2020
            if f > 0: mr &= ((Q['f'] >> (f - 1)) & 1).astype(bool)
            ir = np.nonzero(mr)[0]; er = np.array([rc[(dr, 0)][y] for y in Q['yr'][ir]])
            vr = Q['R'][ir, er].astype(float) * REF / Q['e'][ir] - COST[inst] - (Q['nt'][ir, er] * 0.03 / 365 * REF if inst == 'cfd' else 0)
            ry = np.array([vr[Q['yr'][ir] == t].sum() for t in YRS]); rn = np.array([(Q['yr'][ir] == t).sum() for t in YRS])
            for k, x in zip(['daily', 'cy', 'sy', 'ay', 'ny', 'ry', 'rn'], [d, cy, sy, ay, ny, ry, rn]): out[k].append(x)
        np.savez_compressed(f'/home/claude/bs/g/rl_sw{tf}_{inst}.npz', **{k: np.array(v) for k, v in out.items()})
    pd.DataFrame([dict(調べ=f'sw{tf}', トリガー=TR[g // 2], 向き='買' if g % 2 == 1 else '売', 方向確認=FL[f], g=g, f=f, **{f'手じまい{t}': (EX[c[t]] if c[t] >= 0 else '') for t in YRS})
                  for (g, f), c in zip(rules, ch)]).to_csv(f'/home/claude/bs/g/rl_rules_sw{tf}.csv', index=False)
    print('sw', tf, len(rules), flush=True)

def build_k():
    from x_core import ctx5, simulate, money
    DF = pd.read_csv('/home/claude/bs/g/kdefs.csv', index_col=0); FL = ['なし'] + pd.read_csv('/home/claude/bs/g/kfilters.csv').iloc[:, 0].tolist()
    EX = pd.read_csv('/home/claude/bs/g/xlib_rules.csv').手じまい.tolist(); NF = 18
    Zs = {i: dict(np.load(f'/home/claude/bs/g/xk_{i}_W.npz')) for i in ['fut', 'cfd']}
    rules = [(g, f) for g in range(len(DF)) for f in range(NF) if Zs['fut']['cnt'][g, f, 2:].sum() + Zs['cfd']['cnt'][g, f, 2:].sum() >= 60]
    ch = [choose(Zs, g, f) for g, f in rules]
    for inst in ['fut', 'cfd']:
        C = ctx5(inst, 'W'); S = dict(np.load(f'/home/claude/bs/g/ksig_{inst}_W.npz')); X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz'))
        di = S['d'].astype(np.int64); si = S['i'].astype(np.int64); m0 = C['yr'][si] >= 2020
        di, si, ff = di[m0], si[m0], S['f'][m0].astype(np.int64)
        dr = DF['dir'].values[di]; a = DF['a'].values[di]; isline = (DF['grp'].values[di] == '線') & (a >= 0)
        LR = np.where(isline, C['LM'][si, np.maximum(a, 0)], C['c'][si])
        R, NT, HB = simulate(C, si, dr, LR); nrm, _ = money(inst, R, C['c'][si], NT); del R
        yr_all = C['yr'][si]; xd_base = daynum(X['tm'])
        # ランダム
        rng = np.random.default_rng(11 + (inst == 'cfd'))
        ok = np.nonzero(C['is15'] & (C['yr'] >= 2020) & (np.arange(len(C['c'])) < C['ends'][0]) & ~np.isnan(C['A']))[0]
        ri = np.sort(rng.choice(ok, 15000, replace=False)); RI = np.r_[ri, ri]; RD = np.r_[np.ones(15000, np.int64), -np.ones(15000, np.int64)]
        Rr, NTr, _ = simulate(C, RI, RD, C['c'][RI]); nrr, _ = money(inst, Rr, C['c'][RI], NTr); ryr = C['yr'][RI]
        rc = {d_: choose(Zs, None, 0, rnd=d_) for d_ in (0, 1)}
        RB = {}
        for d_ in (0, 1):
            m = (RD > 0) == (d_ == 1); e = np.array([rc[d_][y] for y in ryr[m]]); vv = nrr[np.nonzero(m)[0], e]
            RB[d_] = (np.array([vv[ryr[m] == t].sum() for t in YRS]), np.array([(ryr[m] == t).sum() for t in YRS]))
        out = {k: [] for k in ['daily', 'cy', 'sy', 'ay', 'ny', 'ry', 'rn']}
        order = np.argsort(di, kind='stable'); bnd = np.searchsorted(di[order], np.arange(len(DF) + 1))
        for (g, f), cc in zip(rules, ch):
            idx = order[bnd[g]:bnd[g + 1]]
            if f > 0: idx = idx[((ff[idx] >> (f - 1)) & 1).astype(bool)]
            yr = yr_all[idx]; e = np.array([cc[y] for y in yr], int); ok = e >= 0; idx, yr, e = idx[ok], yr[ok], e[ok]
            v = nrm[idx, e].astype(float); i = si[idx]; xi = np.minimum(i + HB[idx, e], len(X['tm']) - 1)
            d, cy, sy, ay, ny = record(v, yr, xd_base[xi], i, xi)
            ry, rn = RB[1 if DF['dir'].values[g] == 1 else 0]
            for k, x in zip(['daily', 'cy', 'sy', 'ay', 'ny', 'ry', 'rn'], [d, cy, sy, ay, ny, ry, rn]): out[k].append(x)
        np.savez_compressed(f'/home/claude/bs/g/rl_k_{inst}.npz', **{k: np.array(v) for k, v in out.items()})
        del nrm, NT, HB
    pd.DataFrame([dict(調べ='k', トリガー=DF.trig[g], 向き='買' if DF.dir[g] == 1 else '売', 方向確認=FL[f], g=g, f=f, **{f'手じまい{t}': (EX[c[t]] if c[t] >= 0 else '') for t in YRS})
                  for (g, f), c in zip(rules, ch)]).to_csv('/home/claude/bs/g/rl_rules_k.csv', index=False)
    print('k', len(rules), flush=True)

if __name__ == '__main__':
    for s in sys.argv[1].split(','):
        build_k() if s == 'k' else build_sw(s)
