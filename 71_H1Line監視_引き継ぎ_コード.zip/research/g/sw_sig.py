"""上位足スイング検証：トリガー × 手じまい（32ルール×損切り3＝96）× 方向確認15。入るのは合図の足の終値。最長保有 HMAX 本。
出力：swsig_{tf}_{inst}_{fam}.npz / swrand_{tf}_{inst}_{fam}.npz、sw_trigs_{tf}.csv、sw_exits_{tf}.csv
"""
import sys, numpy as np, pandas as pd
from numba import njit
sys.path.insert(0, '/home/claude/bs/g')
from h_lines import ema, peaks
NAMES = {'15': ('H1Line', 'H4Line', 'EMA48'), '60': ('H4Line', 'D1Line', 'EMA48'), '240': ('D1Line', '週の線', 'EMA72'), 'D': ('週の線', '月の線', 'EMA60')}
UPN = {'15': ['1H', '4H', '日足'], '60': ['4H', '日足', '週足'], '240': ['日足', '週足', '月足'], 'D': ['週足', '月足', '月足']}
HMAX = {'15': 960, '60': 240, '240': 120, 'D': 120}
WARM = {'15': 3000, '60': 1500, '240': 400, 'D': 250}
SPAN = {'15': (48, 192, 48), '60': (48, 288, 48), '240': (72, 360, 72), 'D': (60, 240, 60)}

def exits(tf):
    bn, un, mn = NAMES[tf]; R = []
    for n in (1, 2, 4, 8, 16, 32, 64): R.append((f'{n}本で手じまい', 0, n, 0, 0))
    R.append((f'最長{HMAX[tf]}本まで持つ', 1, 0, 0, 0))
    for a in (.25, .5, 1, 2): R.append((f'利確{a}U', 3, a, 0, 0))
    for a in (.25, .5, 1): R.append((f'トレール{a}U', 4, a, 0, 0))
    R.append(('+0.5Uで建値に損切りを上げる', 5, .5, 0, 0))
    R.append(('半分利確0.5U・残りトレール0.5U', 6, .5, 0, .5))
    R.append(('4本後にマイナスなら切る', 7, 4, 0, 0))
    R.append(('最大利益1U後、半分戻したら出る', 8, 1, .5, 0))
    EV = [f'終値が{bn}を逆に抜け', f'終値が{un}を逆に抜け', f'EMA12×{bn} 逆クロス', f'EMA12×{mn} 逆クロス', f'{bn}の向き転換', f'{un}の向き転換',
          '速ストキャス逆クロス', '遅ストキャス逆クロス', '速Kが80(20)を出る', 'PSAR反転', 'EMA12×signal 逆クロス', f'{UPN[tf][0]}速ストキャス逆クロス']
    for k, e in enumerate(EV): R.append((e, 10, k, 0, 0))
    R.append(('直近5本の安値(高値)で損切り', 11, 5, 0, 0)); R.append(('直近10本の安値(高値)で損切り', 11, 10, 0, 0))
    return R, ['損切りなし', '損切り 線の0.25U先', '損切り 入値から1U']

@njit(cache=True)
def sim(SI, D, LR, o, h, l, c, U, NX, typ, p1, p2, p3, hmax, R, XO):
    n = len(c)
    for q in range(len(SI)):
        i = SI[q]; d = D[q]; e = c[i]; a = U[i]; end = min(i + hmax, n - 1)
        lo5 = l[max(i - 4, 0):i + 1].min() if d == 1 else h[max(i - 4, 0):i + 1].max()
        lo10 = l[max(i - 9, 0):i + 1].min() if d == 1 else h[max(i - 9, 0):i + 1].max()
        for r in range(len(typ)):
            t = typ[r]
            for s in range(3):
                slp = np.nan
                if s == 1: slp = LR[q] - d * 0.25 * a
                elif s == 2: slp = e - d * 1.0 * a
                tgt = -1
                if t == 0 or t == 7: tgt = min(i + int(p1[r]), end)
                elif t == 10: tgt = min(NX[int(p1[r]), i], end)
                tp = e + d * p1[r] * a if t == 3 else np.nan
                dyn = np.nan
                if t == 11:
                    dyn = (lo5 if p1[r] == 5 else lo10) - d * 0.05 * a
                    if (dyn - e) * d >= 0: dyn = e - d * 0.05 * a
                half = t == 6; tp_h = e + d * p1[r] * a if half else np.nan; got = False; rh = 0.0
                best = e; be = False; pnl = 0.0; xi = end; done = False
                for j in range(i + 1, end + 1):
                    stp = slp
                    if t == 4 or (half and got):
                        w = p1[r] if t == 4 else p3[r]; ts = best - d * w * a
                        if np.isnan(stp) or (ts - stp) * d > 0: stp = ts
                    if t == 5 and be:
                        if np.isnan(stp) or (e - stp) * d > 0: stp = e
                    if t == 11:
                        if np.isnan(stp) or (dyn - stp) * d > 0: stp = dyn
                    if t == 8 and (best - e) * d >= p1[r] * a:
                        gb = e + (best - e) * (1 - p2[r])
                        if np.isnan(stp) or (gb - stp) * d > 0: stp = gb
                    if not np.isnan(stp) and ((d == 1 and l[j] <= stp) or (d == -1 and h[j] >= stp)):
                        px = min(o[j], stp) if d == 1 else max(o[j], stp)
                        pnl = (px - e) * d; xi = j; done = True; break
                    if half and not got and ((d == 1 and h[j] >= tp_h) or (d == -1 and l[j] <= tp_h)):
                        px = max(o[j], tp_h) if d == 1 else min(o[j], tp_h); got = True; rh = (px - e) * d
                    if not np.isnan(tp) and ((d == 1 and h[j] >= tp) or (d == -1 and l[j] <= tp)):
                        px = max(o[j], tp) if d == 1 else min(o[j], tp); pnl = (px - e) * d; xi = j; done = True; break
                    best = max(best, h[j]) if d == 1 else min(best, l[j])
                    if t == 5 and (best - e) * d >= p1[r] * a: be = True
                    if j == tgt:
                        if t == 7 and (c[j] - e) * d >= 0:
                            tgt = end
                        else:
                            pnl = (c[j] - e) * d; xi = j; done = True; break
                    if j == end:
                        pnl = (c[j] - e) * d; xi = j; done = True; break
                if not done: pnl = (c[end] - e) * d; xi = end
                if half: pnl = 0.5 * (rh if got else pnl) + 0.5 * pnl
                R[q, r * 3 + s] = pnl; XO[q, r * 3 + s] = xi

def nxt(ev):
    n = len(ev); idx = np.nonzero(ev)[0]; k = np.searchsorted(idx, np.arange(n), side='right')
    out = np.full(n, n - 1, np.int64); ok = k < len(idx); out[ok] = idx[k[ok]]; return out

def sg(v): return np.sign(np.nan_to_num(v)).astype(np.int8)

def crossp(a, b):
    s = sg(a - b); p = np.r_[0, s[:-1]]; return (s > 0) & (p <= 0), (s < 0) & (p >= 0)

def lines(X, tf, inst, fam):
    x = X['c']; L = {k: X[k].astype(float).copy() for k in ('base', 'up', 'e12', 'emid')}
    if fam != 'W':
        rng = np.random.default_rng(313 * int(fam[1:]) + 7 * list(NAMES).index(tf) + (inst == 'cfd')); n = len(x)
        U = np.nan_to_num(X['U'], nan=np.nanmedian(X['U'])); w = WARM[tf]
        for k, s in zip(('base', 'up', 'emid'), SPAN[tf]):
            z = rng.standard_normal(n); z = ema(ema(z, s), s); z = (z - z.mean()) / z.std()
            cc = np.nanmedian(np.abs(x - L[k])[w:] / U[w:]); L[k] = L[k] + cc * U * z
        z = rng.standard_normal(n); z = ema(ema(z, 12), 12); z = (z - z.mean()) / z.std(); cc = np.nanmedian(np.abs(x - L['e12'])[w:] / U[w:]); L['e12'] = L['e12'] + cc * U * z
    for k in ('base', 'up'):
        pk, vl, _ = peaks(L[k]); L[k + '_pk'] = pk; L[k + '_vl'] = vl
    return L

def triggers(X, L, tf):
    bn, un, mn = NAMES[tf]; c = X['c']; h = X['h']; lo = X['l']; U = X['U']; T = {}
    base, up, e12, em = L['base'], L['up'], L['e12'], L['emid']
    T[f'終値×{bn}'] = crossp(c, base); T[f'EMA12×{bn}'] = crossp(e12, base); T[f'{mn}×{bn}'] = crossp(em, base)
    T[f'EMA12×{mn}'] = crossp(e12, em); T[f'EMA12×{un}'] = crossp(e12, up); T[f'終値×{un}'] = crossp(c, up)
    for k, nm in (('base', bn), ('up', un)):
        s = sg(np.diff(L[k], prepend=np.nan)); p = np.r_[0, s[:-1]]; T[f'{nm}の向き転換'] = ((s > 0) & (p <= 0), (s < 0) & (p >= 0))
    gc, dc = T[f'EMA12×{bn}']
    T['周期型クロス'] = (gc & (em > base), dc & (em < base)); T['値幅型クロス'] = (gc & (em < base), dc & (em > base))
    def recent(ev, nb):
        idx = np.nonzero(ev)[0]; k = np.searchsorted(idx, np.arange(len(ev)), side='left') - 1; out = np.zeros(len(ev), bool); ok = k >= 0
        out[ok] = (np.arange(len(ev))[ok] - idx[k[ok]]) <= nb; return out
    T['再クロス(5本内)'] = (gc & recent(dc, 5), dc & recent(gc, 5))
    pc = np.r_[np.nan, c[:-1]]
    def touch(top, bot, w):
        return (lo <= top + w * U) & (c > top) & (pc > top), (h >= bot - w * U) & (c < bot) & (pc < bot)
    for w in (0.05, 0.15):
        T[f'{bn}反発({w}U)'] = touch(base, base, w); T[f'{un}反発({w}U)'] = touch(up, up, w); T[f'{mn}反発({w}U)'] = touch(em, em, w)
    for k, nm in (('base', bn), ('up', un)):
        T[f'{nm}の山の値で反発(0.1U)'] = touch(L[k + '_pk'], L[k + '_pk'], 0.1); T[f'{nm}の谷の値で反発(0.1U)'] = touch(L[k + '_vl'], L[k + '_vl'], 0.1)
        T[f'{nm}の山を抜け'] = ((c > L[k + '_pk']) & (pc <= L[k + '_pk']), (c < L[k + '_pk']) & (pc >= L[k + '_pk']))
    top = np.fmax(np.fmax(base, em), up); bot = np.fmin(np.fmin(base, em), up); tight = (top - bot) <= 0.1 * U
    b, s = touch(top, bot, 0.1); T['3つのサイン反発'] = (b & tight, s & tight)
    T['3つのサイン抜け'] = (tight & (c > top) & (pc <= top), tight & (c < bot) & (pc >= bot))
    T['速K×遅K(MACD)'] = crossp(X['fk'], X['sk']); T['速K×速D'] = crossp(X['fk'], X['fd']); T['遅K×遅D'] = crossp(X['sk'], X['sd'])
    u1, u2 = UPN[tf][0], UPN[tf][1]
    T[f'{u1} 速K×遅K'] = crossp(X['fk1'], X['sk1']); T[f'{u1} 速K×速D'] = crossp(X['fk1'], X['fd1']); T[f'{u2} 速K×速D'] = crossp(X['fk2'], X['fd2'])
    b1, s1 = crossp(X['fk1'], X['fd1']); same = np.abs(X['fk1'] - X['fk2']) < 10
    T[f'{u1}・{u2} 同じ位置でクロス'] = (b1 & (X['fk2'] > X['fd2']) & same, s1 & (X['fk2'] < X['fd2']) & same)
    ps = X['ps']; pp = np.r_[0, ps[:-1]]; T['PSAR反転'] = ((ps > 0) & (pp <= 0), (ps < 0) & (pp >= 0))
    T['EMA12×signal(陽転・陰転)'] = crossp(e12, X['sig'])
    return T

def filt_names(tf):
    bn, un, mn = NAMES[tf]; u = UPN[tf]
    return [f'{u[0]}速ストキャス向き', f'{u[1]}速ストキャス向き', f'{u[2]}速ストキャス向き', '上の3つの速ストキャスそろう', '速K>遅K', '遅ストキャス向き',
            f'{mn}が{bn}の同じ側', f'{bn}の傾き', f'{un}の傾き', f'{u[0]}遅ストキャス向き', f'{u[1]}遅ストキャス向き', f'価格が{un}の同じ側',
            '速ストキャス低位(押し目)', 'PSAR向き', 'EMA12>signal(陽転)']

def filters(X, L, d):
    al = lambda a, b: (np.nan_to_num(a - b) * d) > 0
    upf = lambda v: (np.nan_to_num(np.diff(v, prepend=np.nan)) * d) > 0
    F = [al(X['fk1'], X['fd1']), al(X['fk2'], X['fd2']), al(X['fk3'], X['fd3'])]; F.append(F[0] & F[1] & F[2])
    F += [al(X['fk'], X['sk']), al(X['sk'], X['sd']), al(L['emid'], L['base']), upf(L['base']), upf(L['up']), al(X['sk1'], X['sd1']), al(X['sk2'], X['sd2']),
          al(X['c'], L['up']), (X['fk'] < 30) if d == 1 else (X['fk'] > 70), (X['ps'] * d) > 0, al(L['e12'], X['sig'])]
    f = np.zeros(len(X['c']), np.int64)
    for b, v in enumerate(F): f |= (v.astype(np.int64) << b)
    return f

def events(X, L, tf):
    bn, un, mn = NAMES[tf]; c = X['c']; ev = {1: [], -1: []}
    def add(dn_up):
        dn, up = dn_up; ev[1].append(dn); ev[-1].append(up)
    def rev(a, b):
        u, dwn = crossp(a, b); return dwn, u
    add(rev(c, L['base'])); add(rev(c, L['up'])); add(rev(L['e12'], L['base'])); add(rev(L['e12'], L['emid']))
    for k in ('base', 'up'):
        s = sg(np.diff(L[k], prepend=np.nan)); p = np.r_[0, s[:-1]]; ev[1].append((s < 0) & (p >= 0)); ev[-1].append((s > 0) & (p <= 0))
    add(rev(X['fk'], X['fd'])); add(rev(X['sk'], X['sd']))
    fk = X['fk']; pk = np.r_[np.nan, fk[:-1]]; ev[1].append((pk >= 80) & (fk < 80)); ev[-1].append((pk <= 20) & (fk > 20))
    ps = X['ps']; pp = np.r_[0, ps[:-1]]; ev[1].append((ps < 0) & (pp >= 0)); ev[-1].append((ps > 0) & (pp <= 0))
    add(rev(L['e12'], X['sig'])); add(rev(X['fk1'], X['fd1']))
    return {d: np.stack([nxt(np.nan_to_num(v).astype(bool)) for v in ev[d]]) for d in (1, -1)}

def run(tf, inst, fam):
    X = dict(np.load(f'/home/claude/bs/g/sw_{tf}_{inst}.npz')); n = len(X['c'])
    L = lines(X, tf, inst, fam); NX = events(X, L, tf)
    RL, SLN = exits(tf); typ = np.array([r[1] for r in RL], np.int64); p1 = np.array([r[2] for r in RL], float); p2 = np.array([r[3] for r in RL], float); p3 = np.array([r[4] for r in RL], float)
    valid = np.zeros(n, bool); valid[WARM[tf]:n - 1] = True; valid &= ~np.isnan(X['U']) & (X['yr'] >= 2018)
    FB = {1: filters(X, L, 1), -1: filters(X, L, -1)}
    T = triggers(X, L, tf); names = list(T)
    linekey = {f'{NAMES[tf][0]}': 'base', f'{NAMES[tf][1]}': 'up', f'{NAMES[tf][2]}': 'emid'}
    I, D, TR, LR = [], [], [], []
    for t, nm in enumerate(names):
        lv = X['c']
        if '反発' in nm or '抜け' in nm:
            for key, lk in linekey.items():
                if nm.startswith(key):
                    lv = L[lk + ('_pk' if '山' in nm else '_vl' if '谷' in nm else '')]
            if nm.startswith('3つ'): lv = None
        for d, ev in zip((1, -1), T[nm]):
            ii = np.nonzero(np.nan_to_num(ev).astype(bool) & valid)[0]
            if lv is None:
                lr = np.where(d == 1, np.fmax(np.fmax(L['base'], L['emid']), L['up']), np.fmin(np.fmin(L['base'], L['emid']), L['up']))[ii]
            else:
                lr = lv[ii]
            I.append(ii); D.append(np.full(len(ii), d)); TR.append(np.full(len(ii), t)); LR.append(np.nan_to_num(lr, nan=0) + np.isnan(lr) * X['c'][ii])
    I = np.concatenate(I).astype(np.int64); D = np.concatenate(D).astype(np.int64); TR = np.concatenate(TR); LR = np.concatenate(LR).astype(float)
    rng = np.random.default_rng(29 + (inst == 'cfd') + 3 * list(NAMES).index(tf))
    vi = np.nonzero(valid)[0]; ri = np.sort(rng.choice(vi, min(len(vi), 20000), replace=False))
    for tag, (ii, dd, tt, lr) in {'sig': (I, D, TR, LR), 'rand': (np.r_[ri, ri], np.r_[np.ones(len(ri), np.int64), -np.ones(len(ri), np.int64)], np.full(2 * len(ri), -1), X['c'][np.r_[ri, ri]])}.items():
        R = np.zeros((len(ii), len(RL) * 3)); XO = np.zeros((len(ii), len(RL) * 3), np.int64)
        for dr in (1, -1):
            m = dd == dr; r_ = np.zeros((m.sum(), R.shape[1])); x_ = np.zeros((m.sum(), R.shape[1]), np.int64)
            sim(ii[m], dd[m], lr[m], X['o'], X['h'], X['l'], X['c'], np.nan_to_num(X['U'], nan=1e9), NX[dr], typ, p1, p2, p3, HMAX[tf], r_, x_)
            R[m] = r_; XO[m] = x_
        nt = (X['day'][XO] - X['day'][ii][:, None]).astype(np.int16); hb = (XO - ii[:, None]).astype(np.int32)
        f = np.where(dd > 0, FB[1][ii], FB[-1][ii])
        np.savez_compressed(f'/home/claude/bs/g/sw{tag}_{tf}_{inst}_{fam}.npz', i=ii, d=dd, trig=tt, f=f, R=R.astype(np.float32), nt=nt, hb=hb, e=X['c'][ii], yr=X['yr'][ii])
    if fam == 'W':
        pd.Series(names).to_csv(f'/home/claude/bs/g/sw_trigs_{tf}.csv', index=False)
        pd.DataFrame([(f'{r[0]}・{s}', r[0], s) for r in RL for s in SLN], columns=['手じまい', 'ルール', '損切り']).to_csv(f'/home/claude/bs/g/sw_exits_{tf}.csv', index=False)
        pd.Series(filt_names(tf)).to_csv(f'/home/claude/bs/g/sw_filters_{tf}.csv', index=False)
    print(tf, inst, fam, len(I), flush=True)

if __name__ == '__main__':
    for tf in sys.argv[1].split(','):
        for inst in sys.argv[2].split(','):
            for fam in sys.argv[3].split(','): run(tf, inst, fam)
