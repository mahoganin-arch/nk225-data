"""3分足（PFX=m3）・15分足チャート版（PFX=m15）のブログ観点の検証を、手じまい225通りで調べ直す。
入り：m3sig のイベント（トリガー×向きごとに最大4000件を無作為に選ぶ）。入るのは合図の足の終値。
手じまいの線の名前の読みかえ：H1Line→そのチャートの基準線（3分足では m15Line、15分足では H1Line）、H4Line→上の線（H1Line／H4Line）、D1Line→EMA240(3分)／EMA192(15分)、15m-1H→3分足線(EMA12)×signal。
出力：xm_{P}_{inst}_{fam}.npz
"""
import os, sys, numpy as np, pandas as pd
os.environ['PFX'] = sys.argv[1]
sys.path.insert(0, '/home/claude/bs/g')
from x_core import simulate, money, NE, _events
from k_ind import psar
from x_k import gadd
P = sys.argv[1]; NF = 16
SPLIT = {'m3': {'cfd': pd.Timestamp('2023-07-01', tz='Asia/Tokyo'), 'fut': pd.Timestamp('2025-04-01', tz='Asia/Tokyo')},
         'm15': {'cfd': pd.Timestamp('2023-01-01', tz='Asia/Tokyo'), 'fut': pd.Timestamp('2023-01-01', tz='Asia/Tokyo')}}[P]
Y0 = 2020 if P == 'm3' else 2018; NB = 2 + (2027 - Y0)

def endpos(pid):
    n = len(pid); last = np.r_[pid[1:] != pid[:-1], True]; idx = np.nonzero(last)[0]; return idx[np.searchsorted(idx, np.arange(n))]

def ctxm(inst, fam):
    X = dict(np.load(f'/home/claude/bs/g/{P}_{inst}.npz')); sys.argv_backup = None
    import m3_sig
    L = m3_sig.lines(X, fam, inst)
    o, h, l, c = [X[k].astype(float) for k in 'ohlc']; n = len(c)
    day = X['day']; wk = pd.to_datetime(day, unit='s').to_period('W-SUN').start_time.values.astype('datetime64[s]').astype(np.int64)
    ends = np.stack([endpos(X['ses']), endpos(day), endpos(wk)]).astype(np.int64)
    if 's1' not in X:
        from h_lines import ema
        xx = X['c'].astype(float); e12 = ema(xx, 12); e26 = ema(xx, 26); X['s1'] = e26 + ema(e12 - e26, 9)
        e60 = ema(xx, 48); e130 = ema(xx, 104); X['s5'] = e130 + ema(e60 - e130, 36)
    LMs = {'H1': L['m15'], 'H4': L['h1'], 'D1': X['e240'].astype(float), 'macd': L['e12'], 'signal': X['s1'].astype(float)}
    ps = psar(h, l).astype(float)
    NX = _events(c, np.ones(n, bool), LMs, X['fk'], X['fd'], X['sk'], X['sd'], ps, None)
    LM = np.column_stack([L['m15'], L['h1'], L['e12'], L['e60'], X['e240'], X['s1'], X['s5']])
    pid_day = np.unique(day, return_inverse=True)[1]
    t = pd.to_datetime(X['t'], unit='s', utc=True).tz_convert('Asia/Tokyo')
    return dict(o=o, h=h, l=l, c=c, ends=ends, NX=NX, LM=LM, A=X['A'].astype(float), pid_day=pid_day, yr=t.year.values, half=np.asarray(t >= SPLIT[inst]).astype(np.int64),
                is15=np.ones(n, bool), inst=inst, tscale=5 / 3 if P == 'm3' else 1 / 3, L=L)

def run(inst, fam):
    C = ctxm(inst, fam); S = dict(np.load(f'/home/claude/bs/g/{P}sig_{inst}_{fam}.npz'))
    rng = np.random.default_rng(3 + (inst == 'cfd'))
    keep = []
    key = S['trig'].astype(np.int64) * 2 + (S['d'] > 0)
    for k in np.unique(key):
        ix = np.nonzero(key == k)[0]
        keep.append(ix if len(ix) <= 2500 else np.sort(rng.choice(ix, 2500, replace=False)))
    ix = np.concatenate(keep); si = S['i'][ix].astype(np.int64); d = S['d'][ix].astype(np.int64); tr = S['trig'][ix].astype(np.int64); f = S['f'][ix].astype(np.int64)
    ok = ~np.isnan(C['A'][si]); si, d, tr, f = si[ok], d[ok], tr[ok], f[ok]
    NT_ = int(S['trig'].max()) + 1; G = NT_ * 2
    g = tr * 2 + (d > 0); yb = C['yr'][si] - Y0 + 2; hb = C['half'][si]
    cnt = np.zeros(G * NF * NB); s1 = np.zeros((G * NF * NB, NE)); s2 = np.zeros((G * NF * NB, NE))
    for st in range(0, len(si), 30000):
        sl = slice(st, min(len(si), st + 30000))
        R, NT, _ = simulate(C, si[sl], d[sl], C['c'][si[sl]]); nrm, n13 = money(inst, R, C['c'][si[sl]], NT)
        for k in range(NF):
            m = np.ones(R.shape[0], bool) if k == 0 else ((f[sl] >> (k - 1)) & 1).astype(bool)
            for b in (hb[sl], yb[sl]):
                kk = (g[sl][m] * NF + k) * NB + b[m]; cnt += np.bincount(kk, minlength=G * NF * NB); gadd(s1, kk, nrm[m]); gadd(s2, kk, n13[m])
    Q = dict(np.load(f'/home/claude/bs/g/{P}rand_{inst}_{fam}.npz')); ri = Q['i'].astype(np.int64); rd = Q['d'].astype(np.int64)
    sel = np.concatenate([np.sort(rng.choice(np.nonzero(rd == x)[0], min(15000, (rd == x).sum()), replace=False)) for x in (1, -1)])
    ri, rd = ri[sel], rd[sel]; ok = ~np.isnan(C['A'][ri]); ri, rd = ri[ok], rd[ok]
    R, NT, _ = simulate(C, ri, rd, C['c'][ri]); nrm, n13 = money(inst, R, C['c'][ri], NT)
    cR = np.zeros(2 * NB); r1 = np.zeros((2 * NB, NE)); r2 = np.zeros((2 * NB, NE))
    for b in (C['half'][ri], C['yr'][ri] - Y0 + 2):
        kk = (rd > 0).astype(np.int64) * NB + b; cR += np.bincount(kk, minlength=2 * NB); gadd(r1, kk, nrm); gadd(r2, kk, n13)
    np.savez_compressed(f'/home/claude/bs/g/xm_{P}_{inst}_{fam}.npz', cnt=cnt.reshape(G, NF, NB), nrm=s1.reshape(G, NF, NB, NE).astype(np.float32), n13=s2.reshape(G, NF, NB, NE).astype(np.float32),
                        cntR=cR.reshape(2, NB), nrmR=r1.reshape(2, NB, NE), n13R=r2.reshape(2, NB, NE))
    print('done', P, inst, fam, len(si), flush=True)

if __name__ == '__main__':
    for inst in sys.argv[2].split(','):
        for fam in sys.argv[3].split(','): run(inst, fam)
