"""上位足チャート（15分・1H・4H・日足）でのスイング検証用データ。5分足（ミニ 2017〜限月つなぎ調整、CFD 2017-03〜）から作る。
線（チャートごと）：
  15分：基準=H1Line(m4)・上=H4Line(m16)・短=EMA12・中=EMA48
  1H  ：基準=H4Line(m4)・上=D1Line(m24)・短=EMA12・中=EMA48
  4H  ：基準=D1Line(m6)・上=週の線(m30)・短=EMA12・中=EMA72
  日足：基準=週の線(m5)・上=月の線(m20)・短=EMA12・中=EMA60
ストキャス：チャートの速(35,21,21)・遅(140,84,84) と、上の3つの時間足の速・遅（確定した足の値）。
U（値幅の単位）：15分・1H＝20日平均の日足の値幅、4H・日足＝10週平均の週足の値幅。
4H足は MT5 と同じ区切り（日本時間 2・6・10・14・18・22時）。日足は 6:00（CFD 7:00）区切り。
出力：sw_{tf}_{inst}.npz
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs'); sys.path.insert(0, '/home/claude/bs/g')
import eng
from h_lines import hfilt, ema, peaks
from k_ind import stoch, psar
CUT = pd.Timestamp('2026-10-09 06:00', tz='Asia/Tokyo')
SPEC = {'15': (4, 16, 48), '60': (4, 24, 48), '240': (6, 30, 72), 'D': (5, 20, 60)}
UP = {'15': ['60', '240', 'D'], '60': ['240', 'D', 'W'], '240': ['D', 'W', 'M'], 'D': ['W', 'M', 'M']}

def bars(d1, tf, inst):
    sh = pd.Timedelta(hours=6, minutes=5) if inst == 'fut' else pd.Timedelta(hours=7)
    if tf in ('15', '60'):
        g = d1.groupby(d1.index.floor(f'{tf}min'))
    elif tf == '240':
        g = d1.groupby((d1.index - pd.Timedelta(hours=2)).floor('240min'))
    elif tf == 'D':
        g = d1.groupby((d1.index - sh).normalize())
    elif tf == 'W':
        g = d1.groupby((d1.index - sh).tz_localize(None).to_period('W-SUN').start_time)
    elif tf == 'M':
        g = d1.groupby((d1.index - sh).tz_localize(None).to_period('M').start_time)
    B = g.agg(open=('open', 'first'), high=('high', 'max'), low=('low', 'min'), close=('close', 'last'))
    last = g.apply(lambda s: s.index[-1]); end = pd.DatetimeIndex(last.values)
    if end.tz is None: end = end.tz_localize('UTC').tz_convert('Asia/Tokyo')
    B['end'] = end + pd.Timedelta('5min'); B['first'] = pd.DatetimeIndex(g.apply(lambda s: s.index[0]).values).tz_localize('UTC').tz_convert('Asia/Tokyo') if pd.DatetimeIndex(g.apply(lambda s: s.index[0]).values).tz is None else pd.DatetimeIndex(g.apply(lambda s: s.index[0]).values)
    return B.reset_index(drop=True)

def build(tf, inst):
    d = eng.load(inst); d1 = d.set_index('t')[['o', 'h', 'l', 'c']].rename(columns={'o': 'open', 'h': 'high', 'l': 'low', 'c': 'close'})
    B = bars(d1, tf, inst); x = B.close.values.astype(float); H = B.high.values.astype(float); L = B.low.values.astype(float)
    k1, k2, sp = SPEC[tf]
    out = dict(o=B.open.values.astype(float), h=H, l=L, c=x, tend=B.end.dt.tz_convert('UTC').values.astype('datetime64[s]').astype(np.int64))
    out['base'] = hfilt(x, k1); out['up'] = hfilt(x, k2); out['e12'] = ema(x, 12); out['emid'] = ema(x, sp)
    e26 = ema(x, 26); out['sig'] = e26 + ema(out['e12'] - e26, 9)
    for nm in ('base', 'up'):
        pk, vl, _ = peaks(out[nm]); out[f'{nm}_pk'] = pk; out[f'{nm}_vl'] = vl
    out['fk'], out['fd'] = stoch(H, L, x, 35, 21, 21); out['sk'], out['sd'] = stoch(H, L, x, 140, 84, 84)
    out['ps'] = psar(H, L).astype(float)
    for j, u in enumerate(UP[tf]):
        Bu = bars(d1, u, inst)
        fk, fd = stoch(Bu.high.values.astype(float), Bu.low.values.astype(float), Bu.close.values.astype(float), 35, 21, 21)
        sk, sd = stoch(Bu.high.values.astype(float), Bu.low.values.astype(float), Bu.close.values.astype(float), 140, 84, 84)
        k = np.searchsorted(Bu.end.values, B.end.values, side='right') - 1
        for nm, v in [('fk', fk), ('fd', fd), ('sk', sk), ('sd', sd)]:
            a = np.full(len(B), np.nan); ok = k >= 0; a[ok] = v[k[ok]]; out[f'{nm}{j + 1}'] = a
    # U
    D_ = bars(d1, 'D', inst); W_ = bars(d1, 'W', inst)
    if tf in ('15', '60'):
        r = (D_.high - D_.low).rolling(20).mean().shift(1).values; ref = D_
    else:
        r = (W_.high - W_.low).rolling(10).mean().shift(1).values; ref = W_
    k = np.searchsorted(ref['first'].values, B['first'].values, side='right') - 1
    out['U'] = np.where(k >= 0, r[np.maximum(k, 0)], np.nan)
    kd = np.searchsorted(D_['first'].values, B['first'].values, side='right') - 1; out['day'] = kd
    t = B['first'].dt.tz_convert('Asia/Tokyo'); out['yr'] = t.dt.year.values; out['t'] = t.dt.tz_convert('UTC').values.astype('datetime64[s]').astype(np.int64)
    np.savez_compressed(f'/home/claude/bs/g/sw_{tf}_{inst}.npz', **out); print(tf, inst, len(B), t.iloc[0], t.iloc[-1], flush=True)

if __name__ == '__main__':
    for tf in sys.argv[1].split(','):
        for i in sys.argv[2].split(','): build(tf, i)
