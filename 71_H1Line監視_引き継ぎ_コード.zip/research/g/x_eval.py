"""広げた手じまいの評価 → xeval.pkl"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs/g')
from k_cands import CANDS
RL = pd.read_csv('/home/claude/bs/g/xlib_rules.csv'); NE = len(RL)
BASE = RL.index[RL.手じまい == 'セッション終わり・損切り 線の0.25A先'][0]
COST = {'fut': 5.0, 'cfd': 7.0}; REF = 68800.0; INST = ['fut', 'cfd']; IL = {'fut': 'ミニ', 'cfd': 'CFD'}
CN = [c[0] for c in CANDS]

def load(inst):
    Z = dict(np.load(f'/home/claude/bs/g/xlib_{inst}.npz'))
    sc = (REF / Z['E'])[:, None]; R = Z['R'].astype(float)
    fin = (Z['nt'] * 0.03 / 365 * REF) if inst == 'cfd' else 0
    Z['nrm'] = R * sc - COST[inst] - fin; Z['n13'] = R * sc - 13 - fin
    return Z

def run():
    Zs = {i: load(i) for i in INST}; out = {}
    # 1) 有利・不利にどこまで動いたか
    rows = []
    for i, Z in Zs.items():
        for ci in list(range(len(CANDS))) + [-1, -2]:
            m = Z['CI'] == ci
            nm = CN[ci] if ci >= 0 else ('ランダム買い' if ci == -1 else 'ランダム売り')
            r = dict(商品=IL[i], 入り=nm, 件数=int(m.sum()))
            for k, lab in [(0, 'セッション'), (1, '週')]:
                f = Z['mfe'][m, k]; a = Z['mae'][m, k]
                r[f'{lab} 有利に動いた幅 中央(A)'] = np.median(f); r[f'{lab} 不利に動いた幅 中央(A)'] = np.median(a)
                r[f'{lab} 有利0.25A以上の割合'] = (f >= .25).mean(); r[f'{lab} 有利0.5A以上の割合'] = (f >= .5).mean(); r[f'{lab} 不利0.25A以上の割合'] = (a >= .25).mean()
            rows.append(r)
    out['mfe'] = pd.DataFrame(rows)
    # 2) 候補×手じまい の4つの確認
    rows = []
    for ci in range(len(CANDS)):
        dr = CANDS[ci][2]; rid = -1 if dr == 1 else -2
        A = {}
        for i, Z in Zs.items():
            for hh, msk in [('前半', Z['yr'] <= 2022), ('後半', Z['yr'] >= 2023)]:
                m = (Z['CI'] == ci) & msk; mr = (Z['CI'] == rid) & msk
                A[(i, hh)] = (Z['nrm'][m].mean(0), Z['nrm'][mr].mean(0), m.sum(), Z['n13'][m].mean(0))
        for e in range(NE):
            r = dict(候補=CN[ci], 手じまい=RL.手じまい[e], ルール=RL.ルール[e], 損切り=RL.損切り[e])
            imp = []; lift = []; vals = []; n13 = []
            for (i, hh), (a, ar, n, a13) in A.items():
                r[f'{IL[i]}{hh}'] = a[e]; r[f'{IL[i]}{hh} 件数'] = n; vals.append(a[e]); n13.append(a13[e])
                imp.append(a[e] - a[BASE]); lift.append((a[e] - a[BASE]) - (ar[e] - ar[BASE]))
            r['4つの最小'] = min(vals); r['4つの平均'] = np.mean(vals); r['13円 4つの平均'] = np.mean(n13)
            r['基準より良い(4つとも)'] = all(x > 0 for x in imp); r['基準との差 最小'] = min(imp); r['基準との差 平均'] = np.mean(imp)
            r['ランダムでの変化を引いた差 最小'] = min(lift)
            for i, Z in Zs.items():
                m = Z['CI'] == ci; yr = Z['yr'][m]; v = Z['nrm'][m, e]
                r[f'{IL[i]} 全体'] = v.mean(); r[f'{IL[i]} プラスの年'] = f"{sum(v[yr == y].sum() > 0 for y in np.unique(yr))}/{len(np.unique(yr))}"
            rows.append(r)
    C = pd.DataFrame(rows); out['cand'] = C
    # 3) 手じまいごとのまとめ（11候補とランダム）
    g = C.groupby('手じまい').agg(良くなった候補数=('基準より良い(4つとも)', 'sum'), 差の平均=('基準との差 平均', 'median'), ランダム分を引いた最小=('ランダムでの変化を引いた差 最小', 'median'), 平均=('4つの平均', 'median'))
    rr = []
    for i, Z in Zs.items():
        for rid, lab in [(-1, '買い'), (-2, '売り')]:
            m = Z['CI'] == rid; a = Z['nrm'][m].mean(0); rr.append(pd.Series(a - a[BASE], index=RL.手じまい, name=f'ランダム{lab} {IL[i]} 基準との差'))
    g = g.join(pd.concat(rr, axis=1)); out['exit'] = g.sort_values(['良くなった候補数', '差の平均'], ascending=False).reset_index()
    # 4) 前向き：前の年だけで手じまいを選ぶ
    rows = []
    for ci in range(len(CANDS)):
        for t in range(2020, 2027):
            sc = np.full(NE, np.inf)
            for i, Z in Zs.items():
                m = (Z['CI'] == ci) & (Z['yr'] < t)
                if m.sum() >= 20: sc = np.minimum(sc, Z['nrm'][m].mean(0))
            if not np.isfinite(sc).any(): continue
            e = int(np.argmax(sc))
            for i, Z in Zs.items():
                m = (Z['CI'] == ci) & (Z['yr'] == t)
                if m.sum() == 0: continue
                rows.append(dict(候補=CN[ci], 年=t, 商品=IL[i], 選んだ手じまい=RL.手じまい[e], 件数=int(m.sum()), 選んだ手じまいの合計=Z['nrm'][m, e].sum(), 基準の合計=Z['nrm'][m, BASE].sum(),
                                 選んだ13円=Z['n13'][m, e].sum(), 基準13円=Z['n13'][m, BASE].sum()))
    out['nest'] = pd.DataFrame(rows)
    # 全候補で1つの手じまいを選ぶ（選びすぎを減らす）
    rows = []
    for t in range(2020, 2027):
        sc = np.full(NE, np.inf)
        for i, Z in Zs.items():
            m = (Z['CI'] >= 0) & (Z['yr'] < t)
            if m.sum() >= 50:
                # 候補ごとの平均の平均
                per = np.stack([Z['nrm'][m & (Z['CI'] == ci)].mean(0) for ci in range(len(CANDS)) if (m & (Z['CI'] == ci)).sum() >= 10])
                sc = np.minimum(sc, per.mean(0))
        e = int(np.argmax(sc))
        for i, Z in Zs.items():
            m = (Z['CI'] >= 0) & (Z['yr'] == t)
            if m.sum() == 0: continue
            rows.append(dict(年=t, 商品=IL[i], 選んだ手じまい=RL.手じまい[e], 件数=int(m.sum()), 選んだ合計=Z['nrm'][m, e].sum(), 基準の合計=Z['nrm'][m, BASE].sum()))
    out['nest_all'] = pd.DataFrame(rows)
    pd.to_pickle(out, '/home/claude/bs/g/xeval.pkl')

if __name__ == '__main__':
    run(); O = pd.read_pickle('/home/claude/bs/g/xeval.pkl')
    pd.set_option('display.width', 260); pd.set_option('display.max_rows', 300); pd.set_option('display.max_columns', 30)
    print(O['mfe'].round(2).to_string())
    print(O['exit'].head(40).round(1).to_string())
    N = O['nest']; print(N.groupby(['候補', '商品'])[['選んだ手じまいの合計', '基準の合計', '選んだ13円', '基準13円']].sum().round(0).to_string())
    print(N.groupby('商品')[['選んだ手じまいの合計', '基準の合計']].sum())
    print(O['nest_all'].to_string())
