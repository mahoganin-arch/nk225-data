import sys, numpy as np, pandas as pd
YEARS=list(range(2018,2027)); H={'前半':range(2018,2023),'後半':range(2023,2027)}
def uplift(inst,fam,col='nrm'):
    cols=['def','exit','fset']+[f'{c}{y}' for c in ['n',col] for y in YEARS]
    A=pd.read_parquet(f'/home/claude/bs/g/kagg_{inst}_{fam}.parquet',columns=cols)
    DF=pd.read_csv('/home/claude/bs/g/kdefs.csv',index_col=0); FS=pd.read_csv('/home/claude/bs/g/kfsets.csv')
    out={}
    for hn,ys in H.items():
        A[f'n_{hn}']=A[[f'n{y}' for y in ys]].sum(1); A[f's_{hn}']=A[[f'{col}{y}' for y in ys]].sum(1)
    base=A[A.fset==0].set_index(['def','exit'])
    J=A.join(base[['n_前半','s_前半','n_後半','s_後半']],on=['def','exit'],rsuffix='_b')
    J['grp']=DF.grp.values[J['def']]; J['dir']=DF.dir.values[J['def']]
    R=[]
    for hn in H:
        J[f'u_{hn}']=J[f's_{hn}']/J[f'n_{hn}']-J[f's_{hn}_b']/J[f'n_{hn}_b']
    ok=(J.n_前半>=20)&(J.n_後半>=20)&(J.fset>0)
    g=J[ok].groupby(['fset','grp','dir'])
    T=g.agg(u前半=('u_前半','median'),u後半=('u_後半','median'),件数前半=('n_前半','median'),格子=('u_前半','size')).reset_index()
    T=T.merge(FS,on='fset'); T['inst']=inst; T['fam']=fam
    return T
if __name__=='__main__':
    T=uplift(sys.argv[1],sys.argv[2]); pd.set_option('display.width',250)
    t=T[T.k==1].pivot_table(index=['name'],columns=['grp','dir'],values=['u前半','u後半']).round(1)
    print(t.to_string())
