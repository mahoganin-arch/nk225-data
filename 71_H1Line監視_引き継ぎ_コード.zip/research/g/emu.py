"""Pine（前向き検証インジ）の論理を Python でそのまま書き直し、研究の合図・成績と突き合わせる。
・15分足は研究と同じ（5分足を15分ごとにまとめる）。線・インジは研究と同じ式。
・1時間足は2通り：clock＝研究と同じ（時計の0分区切り、8:45〜9:00 は短い足）、session＝TradingView と同じ（セッションの始まりから60分ごと）。
・A は研究の avg20。日足の週の線・月の線は研究の日足（6:05区切り）の確定値。
出力：emu_{inst}.pkl（ルールごとのトレード）
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/bs'); sys.path.insert(0, '/home/claude/bs/g')
from h_lines import hfilt, ema, peaks
from k_ind import stoch, psar
REF = 68800.0
import os
WK = os.environ.get('WK', 'research')

def f_sig(x, m):
    e12 = ema(x, int(round(12 * m))); e26 = ema(x, int(round(26 * m))); return e12, e26 + ema(e12 - e26, int(round(9 * m)))

def hour_bars(o, h, l, c, tstart, ses_id, mode):
    """15分足 → 1時間足。戻り値：各15分足が属する1時間足の番号、その15分足で1時間足が終わるか"""
    if mode == 'clock':
        key = (tstart // 3600).astype(np.int64)
    else:
        first = np.r_[True, ses_id[1:] != ses_id[:-1]]; s0 = pd.Series(np.where(first, tstart, np.nan)).ffill().values
        key = ses_id.astype(np.int64) * 1000 + ((tstart - s0) // 3600).astype(np.int64)
    g = np.r_[0, np.cumsum(key[1:] != key[:-1])]; end = np.r_[g[1:] != g[:-1], True]
    G = pd.DataFrame({'g': g, 'o': o, 'h': h, 'l': l, 'c': c}).groupby('g').agg(o=('o', 'first'), h=('h', 'max'), l=('l', 'min'), c=('c', 'last'))
    return g, end, G

def build(inst, hmode='clock'):
    X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); K = dict(np.load(f'/home/claude/bs/g/kind_{inst}_W.npz')); is15 = K['is15']
    q = np.nonzero(is15)[0]; n = len(q); grp = np.cumsum(np.r_[0, is15[:-1]])
    o = pd.Series(X['o']).groupby(grp).first().values[:n].astype(float); h = pd.Series(X['h']).groupby(grp).max().values[:n].astype(float)
    l = pd.Series(X['l']).groupby(grp).min().values[:n].astype(float); c = X['c'][q].astype(float)
    tend = X['tm'][q] + 300; tstart = pd.Series(X['tm']).groupby(grp).first().values[:n]
    A = X['avg20'][q].astype(float); yr = X['yr'][q]
    jst = pd.to_datetime(tstart, unit='s', utc=True).tz_convert('Asia/Tokyo'); hm = (jst.hour * 60 + jst.minute).values
    jend = pd.to_datetime(tend, unit='s', utc=True).tz_convert('Asia/Tokyo')
    dayS = ((hm >= 480) & (hm < 975)) if inst == 'fut' else ((hm >= 420) & (hm < 1020))
    sesId = np.cumsum(np.r_[0, dayS[1:] != dayS[:-1]])
    weekEnd_pine = (jend.dayofweek.values == 5) & ((jend.hour * 60 + jend.minute).values >= 359)
    weekEnd = X['end_wk'][q].astype(bool) if WK == 'research' else weekEnd_pine
    h1 = hfilt(c, 4); h4 = hfilt(c, 16); d1 = hfilt(c, 96)
    h1pk, h1vl, _ = peaks(h1)
    mc1, sg1 = f_sig(c, 1)
    fk, fd = stoch(h, l, c, 35, 21, 21); i1k, _ = stoch(h, l, c, 5, 3, 3)
    c1 = np.where(i1k >= 60, 1, np.where(i1k <= 40, -1, 0))
    rise = []
    for m in range(1, 6):
        mm = ema(c, int(12 * m)) - ema(c, int(26 * m)); p = np.r_[np.nan, mm[:-1]]; rise.append(np.where(mm > p, 1, np.where(mm < p, -1, 0)))
    rise = np.stack(rise, 1); cnt = c1 + rise.sum(1); allRise = (rise > 0).all(1)
    ps = psar(h, l).astype(int)
    # 1時間足
    g60, end60, G = hour_bars(o, h, l, c, tstart, sesId, hmode)
    x = G.c.values; b60 = hfilt(x, 4); u60 = hfilt(x, 24); e12 = ema(x, 12); e48 = ema(x, 48); e26 = ema(x, 26); s60 = e26 + ema(e12 - e26, 9)
    fk60, fd60 = stoch(G.h.values, G.l.values, x, 35, 21, 21); sk60, _ = stoch(G.h.values, G.l.values, x, 140, 84, 84)
    def turn(v, dn):
        d = np.diff(v, prepend=np.nan); p = np.r_[np.nan, d[:-1]]
        return (d < 0) & (p >= 0) if dn else (d > 0) & (p <= 0)
    H = dict(sig3=turn(b60, False), u60dn=turn(u60, True), sig12=(e48 - b60 > 0) & (np.r_[np.nan, (e48 - b60)[:-1]] <= 0), sig22=(e12 - e48 > 0) & (np.r_[np.nan, (e12 - e48)[:-1]] <= 0))
    h60 = {k: np.where(end60, v[g60], False) for k, v in H.items()}
    # 日足の週の線・月の線（研究の日足、確定した前の日の値）
    D = dict(np.load(f'/home/claude/bs/g/sw_D_{inst}.npz')); k = np.searchsorted(D['tend'], tend, side='right') - 1
    dUp = np.where(k >= 0, D['base'][np.maximum(k, 0)] > D['up'][np.maximum(k, 0)], False)
    return dict(o=o, h=h, l=l, c=c, A=A, yr=yr, tend=tend, i5=q, sesId=sesId, weekEnd=weekEnd, h1=h1, h4=h4, d1=d1, h1pk=h1pk, h1vl=h1vl, mc1=mc1, sg1=sg1,
                fk=fk, cnt=cnt, allRise=allRise, ps=ps, dUp=dUp, **h60, X=X)

def since(c, v):
    above = c > v; pa = np.r_[False, above[:-1]]; bup = above & ~pa; bdn = (~above) & pa
    n = len(c); idx = np.arange(n)
    lastUp = pd.Series(np.where(bup, idx, np.nan)).ffill().values; lastDn = pd.Series(np.where(bdn, idx, np.nan)).ffill().values
    aS = above & ~np.isnan(lastUp) & (idx - lastUp <= 16) & (np.isnan(lastDn) | (lastDn < lastUp))
    bS = (~above) & ~np.isnan(lastDn) & (idx - lastDn <= 16) & (np.isnan(lastUp) | (lastUp < lastDn))
    return aS, bS, bup, bdn, lastUp, lastDn, above

def first_seg(cand, seg):
    out = np.zeros(len(cand), bool); used = set()
    for i in np.nonzero(cand)[0]:
        if not np.isnan(seg[i]) and seg[i] not in used: out[i] = True; used.add(seg[i])
    return out

def once(cond, ses):
    out = np.zeros(len(cond), bool); last = -1
    for i in np.nonzero(cond)[0]:
        if ses[i] != last: out[i] = True; last = ses[i]
    return out

def signals(B, cal=None):
    c, h, l, o, A = B['c'], B['h'], B['l'], B['o'], B['A']; ses = B['sesId']
    pc = np.r_[np.nan, c[:-1]]
    aS1, bS1, bup1, bdn1, lu1, ld1, ab1 = since(c, B['h1']); aS4, bS4, bup4, bdn4, lu4, ld4, ab4 = since(c, B['h4'])
    S = {}
    S[0] = first_seg(aS1 & (l <= B['h1'] + 0.05 * A) & (l > B['h1']) & ~bup1, lu1)
    S[1] = (pc > B['h1vl']) & (l <= B['h1vl'] + 0.1 * A) & (l > B['h1vl']) & (c > pc)
    L = B['h1pk']; pL = np.r_[np.nan, L[:-1]]; b = 0.1 * A
    S[2] = once((pc > pL + b) & (l <= L + b) & (c > L), ses)
    S[3] = B['sig3'].astype(bool)
    m, s_ = B['mc1'], B['sg1']; S[4] = once((m > s_) & (np.r_[np.nan, m[:-1]] <= np.r_[np.nan, s_[:-1]]), ses)
    S[5] = first_seg(bS4 & (h >= B['h4'] - 0.15 * A) & ~bdn4, ld4)
    S[10] = once((B['cnt'] >= 5) & (np.r_[99, B['cnt'][:-1]] < 5), ses)
    S[12] = B['sig12'].astype(bool)
    ps = B['ps']; S[21] = once((ps > 0) & (np.r_[0, ps[:-1]] <= 0), ses)
    S[22] = B['sig22'].astype(bool)
    d = B['h1'] - m; S[24] = once((d < 0) & (np.r_[np.nan, d[:-1]] >= 0), ses)
    sq = cal if cal is not None else np.zeros(len(c), bool)
    S[26] = S[5] & B['dUp'] & ~sq
    for k in S: S[k] = S[k] & ~np.isnan(A) & (A > 0)
    return S

# Pine の手じまい
EXIT = {0: (5, 0, 0, 1), 1: (2, 0, 0, 1), 2: (1, 1, 0, 1), 3: (8, 0, 960, 0), 4: (2, 0, 0, 1), 5: (4, 0, 0, 1), 10: (2, 0, 0, 1), 12: (8, 0, 960, 0),
        21: (2, 0, 0, 1), 22: (9, 0, 960, 0), 24: (5, 0, 0, 1), 26: (4, 0, 0, 1)}  # (型, 損切り0.5A, 本数, 週末)
DIR = {5: -1, 26: -1}

def run_rule(B, sig, r, cost):
    t, slf, cap, wk = EXIT[r]; dr = DIR.get(r, 1)
    c, h, l, o, A = B['c'], B['h'], B['l'], B['o'], B['A']
    h4, d1 = B['h4'], B['d1']; n = len(c)
    dh4 = np.diff(h4, prepend=np.nan); h4dn = (dh4 < 0) & (np.r_[np.nan, dh4[:-1]] >= 0)
    d1dn = (c < d1) & (np.r_[np.nan, c[:-1]] >= np.r_[np.nan, d1[:-1]]); h1up = (c > B['h1']) & (np.r_[np.nan, c[:-1]] <= np.r_[np.nan, B['h1'][:-1]])
    ev = {1: h4dn, 2: d1dn, 4: h1up, 8: B['u60dn'].astype(bool), 5: np.zeros(n, bool), 9: np.zeros(n, bool)}[t]
    out = []; inpos = False
    for i in range(n):
        if inpos:
            x = np.nan; why = ''
            stp = sl
            if t == 5 and (best - e) * dr >= 0.5 * A[i]:
                gb = e + (best - e) * 0.5; stp = gb if np.isnan(stp) else (max(stp, gb) if dr == 1 else min(stp, gb))
            if not np.isnan(stp) and ((dr == 1 and l[i] <= stp) or (dr == -1 and h[i] >= stp)):
                x = min(o[i], stp) if dr == 1 else max(o[i], stp)
            best = max(best, h[i]) if dr == 1 else min(best, l[i])
            if np.isnan(x) and (ev[i] or (cap > 0 and i - ei >= cap) or (wk and B['weekEnd'][i])):
                x = c[i]
            if not np.isnan(x):
                out.append((B['i5'][ei], B['i5'][i], e, x)); inpos = False
        if not inpos and sig[i]:
            inpos = True; e = c[i]; ei = i; best = e; sl = e - dr * 0.5 * A[i] if slf else np.nan
    T = pd.DataFrame(out, columns=['i5', 'x5', 'e', 'x'])
    T['v'] = (T.x - T.e) * dr * REF / T.e - cost; return T

if __name__ == '__main__':
    import pickle
    res = {}
    for inst in ['fut', 'cfd']:
        X = dict(np.load(f'/home/claude/bs/g/data_{inst}.npz'))
        for hm in ['clock', 'session']:
            B = build(inst, hm); cal = X['mk_sqw_minor'][B['i5']].astype(bool)
            S = signals(B, cal)
            for r in EXIT:
                if hm == 'session' and r not in (3, 12, 22): continue
                T = run_rule(B, S[r], r, 5.0 if inst == 'fut' else 7.0); T['yr'] = X['yr'][T.i5.values]
                res[(inst, hm, r)] = dict(sig=B['i5'][S[r]], tr=T)
            print(inst, hm, flush=True)
    pickle.dump(res, open(f'/home/claude/bs/g/emu_{WK}.pkl', 'wb'))
