import sys, numpy as np, pandas as pd
sys.path.insert(0,'/home/claude/bs/g')
import h_agg
from k_agg import MASKS, YEARS, NY
def run(inst):
    X=dict(np.load(f'/home/claude/bs/g/data_{inst}.npz')); S=dict(np.load(f'/home/claude/bs/g/krand_{inst}.npz'))
    net,nrm,n13=h_agg.pnl(inst,S); yi=X['yr'][S['i']]-YEARS[0]; f=S['f'].astype(np.int64); dflag=S['d']%2
    rows=[]
    for df in (0,1):
        sel0=dflag==df
        for k,msk in enumerate(MASKS):
            sel=sel0&((f&msk)==msk)
            if sel.sum()<20: continue
            Y=np.zeros((sel.sum(),NY)); Y[np.arange(sel.sum()),yi[sel]]=1
            cnt=Y.sum(0)
            for nm,arr in [('nrm',nrm),('n13',n13),('net',net)]:
                s=(Y.T@arr[sel]).T  # 36×9
                for e in range(36): rows.append((1 if df==0 else -1,k,e,nm,*cnt,*s[e]))
    cols=['dir','fset','exit','col']+[f'n{y}' for y in YEARS]+[f's{y}' for y in YEARS]
    pd.DataFrame(rows,columns=cols).to_parquet(f'/home/claude/bs/g/kragg_{inst}.parquet'); print(inst,len(rows))
run(sys.argv[1])
