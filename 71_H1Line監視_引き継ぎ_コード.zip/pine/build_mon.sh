#!/bin/bash
# 監視用の部品から3つの .txt を組み立てる
cd /home/claude/pine
cat hdr_mon.pine mon_core.pine mon_ui.pine > 監視_アラート_インジ.txt
cat hdr_mst.pine mon_core.pine ftr_mst.pine > ルール別_ストラテジー.txt
cat hdr_ex.pine mon_core.pine ftr_ex.pine > 検算の書き出し_ストラテジー.txt
